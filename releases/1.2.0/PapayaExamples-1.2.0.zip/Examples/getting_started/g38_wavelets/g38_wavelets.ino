/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:40:01
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe coefficients;
probe Wavelet_tap;
VectorProbe reconstructed;
probe Rebuild_tap;
probe noise_sigma;
probe scaled;
VectorProbe band_energy;
probe Band_energy_tap;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::chirpLinear(10.0f, 400.0f, 4.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  expander signal_split = expander(5);
  dwt Wavelet = dwt(256, DB4, 3, 2000.0);
  dwt Wavelet_for_rebuild = dwt(256, DB4, 3, 2000.0);
  dwt Wavelet_for_denoise = dwt(256, DB4, 3, 2000.0);
  dwt Wavelet_for_reshape = dwt(256, DB4, 3, 2000.0);
  dwt Wavelet_for_band_energy = dwt(256, DB4, 3, 2000.0);
  idwt Rebuild = idwt(Wavelet_for_rebuild);
  dwt_denoise Denoise = dwt_denoise(Wavelet_for_denoise, PP_THRESH_SOFT, 1.0f);
  dwt_subband_gain Reshape = dwt_subband_gain(Wavelet_for_reshape);
  dwt_subband_energy Band_energy = dwt_subband_energy(Wavelet_for_band_energy);
  coefficients = VectorProbe("coefficients");
  Wavelet_tap = probe("Wavelet_o0");
  reconstructed = VectorProbe("reconstructed");
  Rebuild_tap = probe("Rebuild_o0");
  noise_sigma = probe("noise_sigma");
  scaled = probe("scaled");
  band_energy = VectorProbe("band_energy");
  Band_energy_tap = probe("Band energy_o0");

  /* Connect Blocks */
  Source > signal_split;
  signal_split.out(0) > Wavelet;
  signal_split.out(1) > Wavelet_for_rebuild;
  signal_split.out(2) > Wavelet_for_denoise;
  signal_split.out(3) > Wavelet_for_reshape;
  signal_split.out(4) > Wavelet_for_band_energy;
  Wavelet >> coefficients;
  Wavelet > Wavelet_tap;
  Wavelet_for_rebuild > Rebuild;
  Wavelet_for_denoise > Denoise;
  Wavelet_for_reshape > Reshape;
  Wavelet_for_band_energy > Band_energy;
  Rebuild >> reconstructed;
  Rebuild > Rebuild_tap;
  Denoise > noise_sigma;
  Reshape > scaled;
  Band_energy >> band_energy;
  Band_energy > Band_energy_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    coefficients.show();
    Wavelet_tap.show();
    reconstructed.show();
    Rebuild_tap.show();
    noise_sigma.show();
    scaled.show();
    band_energy.show();
    Band_energy_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}