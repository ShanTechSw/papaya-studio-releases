var struct_p_p___thermal___e_k_f =
[
    [ "C_core", "struct_p_p___thermal___e_k_f.html#a18e450adf9cb6e53b1dcc34fd6721867", null ],
    [ "C_surf", "struct_p_p___thermal___e_k_f.html#a896d181a353c979a5858f7e4be718243", null ],
    [ "P_init", "struct_p_p___thermal___e_k_f.html#aa7be802f84dd90e59fc1ef75a2ad0062", null ],
    [ "Q_data", "struct_p_p___thermal___e_k_f.html#a22d08243028dd318dca4efdc1250a07c", null ],
    [ "R_conv", "struct_p_p___thermal___e_k_f.html#a40cf6ddae95af4a638d2d64e0b0035c8", null ],
    [ "R_data", "struct_p_p___thermal___e_k_f.html#af6a3dce97a1396ed70ee1ca3b892f703", null ],
    [ "R_th", "struct_p_p___thermal___e_k_f.html#ae2a2632ba534f1a71aa9a116d74e7fb3", null ],
    [ "T_amb", "struct_p_p___thermal___e_k_f.html#a204b8984a908472eb3da8bb51a1654ba", null ],
    [ "x_init", "struct_p_p___thermal___e_k_f.html#a54f100375315a7eef46fc11381df5116", null ]
];