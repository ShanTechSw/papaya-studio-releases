var classmag2 =
[
    [ "mag2", "classmag2.html#af8c95213ef9261fe41ef022ee5f39a97", null ]
];