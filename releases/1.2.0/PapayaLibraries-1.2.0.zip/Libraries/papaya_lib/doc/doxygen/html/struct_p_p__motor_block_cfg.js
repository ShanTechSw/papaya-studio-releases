var struct_p_p__motor_block_cfg =
[
    [ "config", "struct_p_p__motor_block_cfg.html#af2f5dc5f52ca67ac65be5eb25881caa5", null ],
    [ "id", "struct_p_p__motor_block_cfg.html#a7ae1aa2354ca71b5bcaebb1a23309baa", null ],
    [ "outputCount", "struct_p_p__motor_block_cfg.html#a3cee888afa4fe528abea84048f7c9ea3", null ],
    [ "outputs", "struct_p_p__motor_block_cfg.html#a43d82cf010dfe0b565f96f0160988cbc", null ]
];