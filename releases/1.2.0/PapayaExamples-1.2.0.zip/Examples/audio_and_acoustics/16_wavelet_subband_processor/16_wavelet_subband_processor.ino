/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe shaped_coeffs;
VectorProbe reconstructed;
VectorProbe band_energy;
probe Subband_energy_tap;
probe subband_gain;

/* Global Array Declarations */
float Subband_gain_gains[] = {1.0f, 0.5f, 0.25f, 0.1f, 0.1f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  microphone Microphone = microphone(MIC_L);
  expander fan_3 = expander(3);
  dwt DWT_round_trip = dwt(256, SYM8, 4, 44100.0);
  dwt DWT_energy_path = dwt(256, SYM8, 4, 44100.0);
  dwt DWT_gain_path = dwt(256, SYM8, 4, 44100.0);
  idwt IDWT = idwt(DWT_round_trip);
  dwt_subband_energy Subband_energy = dwt_subband_energy(DWT_energy_path);
  dwt_subband_gain Subband_gain = dwt_subband_gain(DWT_gain_path, Subband_gain_gains);
  shaped_coeffs = VectorProbe("shaped_coeffs");
  reconstructed = VectorProbe("reconstructed");
  band_energy = VectorProbe("band_energy");
  Subband_energy_tap = probe("Subband energ_0");
  subband_gain = probe("subband_gain");

  /* Connect Blocks */
  Microphone > fan_3;
  fan_3.out(0) > DWT_round_trip;
  fan_3.out(1) > DWT_energy_path;
  fan_3.out(2) > DWT_gain_path;
  DWT_round_trip > IDWT;
  DWT_energy_path > Subband_energy;
  DWT_gain_path > Subband_gain;
  DWT_gain_path >> shaped_coeffs;
  IDWT >> reconstructed;
  Subband_energy >> band_energy;
  Subband_energy > Subband_energy_tap;
  Subband_gain > subband_gain;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    shaped_coeffs.show();
    reconstructed.show();
    band_energy.show();
    Subband_energy_tap.show();
    subband_gain.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}