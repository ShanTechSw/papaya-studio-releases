var classbutter_bq =
[
    [ "butterBq", "classbutter_bq.html#a5b9f119217a097a89dc398b17803a88e", null ],
    [ "butterBq", "classbutter_bq.html#ad29d866e8c8515d3d3a9dfa517528d8e", null ]
];