var struct_p_p___i_l_c_config =
[
    [ "L_gain", "struct_p_p___i_l_c_config.html#ae62491f28f7c956a75a9c4aa3293b042", null ],
    [ "Q_gain", "struct_p_p___i_l_c_config.html#a270029beae8244ef665463b89f7d047c", null ],
    [ "trial_length", "struct_p_p___i_l_c_config.html#a121f5442e1ff2d1696c77acf4183f8cc", null ]
];