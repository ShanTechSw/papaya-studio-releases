"""Finding a gateway on the network, lazily.

**Discovery finds routes. Recognition identifies boards.** Nothing here
identifies anything: a gateway is a way of REACHING a PAPAYA, exactly as
a cable is, and it is never the device. Once one answers, Studio runs the
same two round trips against the board behind it that it runs over a
cable, and the record that comes out is the same record keyed to the same
board identity. That is what lets a board move from a bench cable onto a
machine without losing anything recorded against it.

The ladder, and why it is lazy
------------------------------
1. **A cable, if there is one.** Unchanged, instant, still the default.
   Not this module's business; it is first because it is first.
2. **A remembered gateway, tried directly** at its known endpoint. After
   the first day this is the common case, and it should feel like
   plugging in rather than like searching.
3. **Only then, a search**, triggered because a connection was wanted and
   nothing answered. First by asking over mDNS, which is one packet.
4. **An address typed by hand**, which is not the fallback it looks
   like. A gateway that cannot advertise has to be told to somebody, and
   the generated project prints its address on its serial monitor at
   boot for exactly this. Studio remembers it afterwards, so this is a
   once-per-gateway cost and rung 2 covers every day after.

There is a rung between those two that is deliberately absent. Trying the
gateway's port across the subnet finds anything, advertised or not, and
:func:`sweep` implements it. It is not on the automatic path because it
is not safe on every supported radio: see that function.

**Never a background poll.** A search costs multicast traffic on somebody
else's network, and a Studio that hunted continuously would be a Studio
that shows up in a network administrator's logs for no reason.

**Liveness is not discovery.** The heartbeat pings a known endpoint on a
radio's timescale. It must never re-enter this module: a heartbeat that
scans the moment a packet is late turns a hiccup into a scan storm, and
the hiccup was going to resolve itself.

Why this is written out rather than imported
--------------------------------------------
mDNS is a DNS message on a multicast address, and the parts of it needed
to ask "who offers this service" are small. Taking a dependency for it
would put a third-party package inside an installer that ships to users,
with its own licence, its own release cadence and its own CVEs, in
exchange for about two hundred lines. The standard library already has
sockets and struct.

What is deliberately NOT here: registering a service (Studio offers
none), continuous browsing (see the lazy rule above), and DNSSEC. A
gateway that answers is checked by connecting to it, which is a stronger
test than trusting its advertisement -- and that principle is exactly why
the sweep is legitimate rather than a hack: it applies the stronger test
directly instead of waiting for an advertisement that never comes.
"""
from __future__ import annotations

import socket
import struct
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

#: The service a PAPAYA Link gateway advertises. The underscore form is
#: what the convention requires; the name is ours.
SERVICE_TYPE = "_papaya-link._tcp.local."

#: Where a multicast DNS question goes. Not configurable: these are the
#: registered address and port for the protocol, and a different pair is
#: a different protocol nobody is listening to.
MDNS_GROUP = "224.0.0.251"
MDNS_PORT = 5353

#: How long to listen for answers. A search is a one-shot: several
#: gateways may answer and the slowest is still only a few hundred
#: milliseconds away on a local network.
DEFAULT_SEARCH_S = 2.0

#: Where a gateway listens unless its project says otherwise. Registered
#: nowhere; simply out of the way of common services.
#:
#: The same number appears in the connection dialog, in the generated
#: gateway's own source and in the gateway library's header, because each
#: of those is read by someone who should not have to look it up
#: elsewhere. A test pins all of them together: they disagreeing is a
#: Studio that cannot reach a gateway it just generated, and neither end
#: would say why.
DEFAULT_PORT = 8272

# DNS record types, of which four matter here.
_TYPE_A = 1
_TYPE_PTR = 12
_TYPE_TXT = 16
_TYPE_SRV = 33
_CLASS_IN = 1


class DiscoveryError(RuntimeError):
    """A search could not be performed. Distinct from finding nothing,
    which is an ordinary and informative answer."""


@dataclass(frozen=True)
class Discovered:
    """One gateway that answered.

    Deliberately NOT a board. It carries the route and what the gateway
    said about itself, and nothing about the device behind it, because
    this module has no way to know and guessing would put a name on the
    wrong hardware.
    """

    #: The instance name the gateway advertised, for a picker to show.
    name: str
    host: str
    port: int
    #: Whatever the gateway published about itself, unparsed. A gateway
    #: with no board attached says so here, and that is a diagnosable
    #: state rather than a silence.
    properties: Dict[str, str]

    @property
    def endpoint(self) -> str:
        return f"{self.host}:{self.port}"


# ==========================================================================
# DNS messages, only as much as this needs
# ==========================================================================
def encode_name(name: str) -> bytes:
    """A dotted name as length-prefixed labels."""
    out = bytearray()
    for label in name.rstrip(".").split("."):
        raw = label.encode("utf-8")
        if len(raw) > 63:
            raise DiscoveryError(f"label too long in {name!r}")
        out.append(len(raw))
        out.extend(raw)
    out.append(0)
    return bytes(out)


def decode_name(data: bytes, offset: int) -> Tuple[str, int]:
    """A name at *offset*, returning it and where it ended.

    Follows compression pointers, which are not optional: a real
    responder packs an answer by pointing later records at the name in
    the first one, so a parser that cannot follow a pointer reads almost
    nothing from a real reply.

    Jumps are bounded. A pointer loop is the classic way to make a DNS
    parser spin forever, and a hostile or merely broken responder is on
    the same network as the person searching.
    """
    labels: List[str] = []
    jumps = 0
    cursor = offset
    ended_at: Optional[int] = None

    while True:
        if cursor >= len(data):
            raise DiscoveryError("name runs past the end of the message")
        length = data[cursor]

        if length == 0:
            cursor += 1
            break

        if (length & 0xC0) == 0xC0:
            if cursor + 1 >= len(data):
                raise DiscoveryError("truncated compression pointer")
            target = ((length & 0x3F) << 8) | data[cursor + 1]
            if ended_at is None:
                ended_at = cursor + 2
            jumps += 1
            if jumps > 16:
                raise DiscoveryError(
                    "compression pointers loop; refusing to follow further")
            if target >= len(data):
                raise DiscoveryError("compression pointer past the message")
            cursor = target
            continue

        cursor += 1
        if cursor + length > len(data):
            raise DiscoveryError("label runs past the end of the message")
        labels.append(data[cursor:cursor + length].decode("utf-8", "replace"))
        cursor += length

    return ".".join(labels), (ended_at if ended_at is not None else cursor)


def encode_query(service: str = SERVICE_TYPE, transaction_id: int = 0) -> bytes:
    """One question: who offers this service?

    The transaction id is zero because multicast DNS answers are
    multicast too and are matched by content rather than by id. Sending a
    random one would look like it meant something.
    """
    header = struct.pack(">HHHHHH", transaction_id & 0xFFFF, 0x0000,
                         1, 0, 0, 0)
    return header + encode_name(service) + struct.pack(">HH", _TYPE_PTR,
                                                       _CLASS_IN)


def decode_response(data: bytes, service: str = SERVICE_TYPE) -> List[Discovered]:
    """Everything in one reply that offers *service*.

    A reply is assembled from several record types that only mean
    something together: a PTR names an instance, an SRV gives that
    instance its host and port, an A gives that host its address, and a
    TXT carries what the gateway wants to say about itself. Parsing one
    kind and hoping is how a discovery that works against one responder
    fails against another.
    """
    if len(data) < 12:
        return []

    (_id, _flags, questions, answers, authority,
     additional) = struct.unpack_from(">HHHHHH", data)
    cursor = 12

    instances: List[str] = []
    services: Dict[str, Tuple[str, int]] = {}
    addresses: Dict[str, str] = {}
    texts: Dict[str, Dict[str, str]] = {}

    # Parsed as far as the message holds together, and no further. A reply
    # that is truncated, malformed or hostile costs whatever is after the
    # damage and nothing before it: this runs on whatever another machine
    # on the network chose to send, and refusing the whole packet would
    # throw away the gateway named in its first record because of a fault
    # in its last.
    try:
        for _ in range(questions):
            _name, cursor = decode_name(data, cursor)
            cursor += 4

        total = answers + authority + additional
        for _ in range(total):
            if cursor >= len(data):
                break
            name, cursor = decode_name(data, cursor)
            if cursor + 10 > len(data):
                break
            rtype, _rclass, _ttl, rdlength = struct.unpack_from(">HHIH", data,
                                                                cursor)
            cursor += 10
            rdata_end = cursor + rdlength
            if rdata_end > len(data):
                break

            if rtype == _TYPE_PTR and name.rstrip(".") == service.rstrip("."):
                instance, _ = decode_name(data, cursor)
                instances.append(instance)
            elif rtype == _TYPE_SRV and rdlength >= 6:
                _priority, _weight, port = struct.unpack_from(">HHH", data,
                                                              cursor)
                target, _ = decode_name(data, cursor + 6)
                services[name] = (target, port)
            elif rtype == _TYPE_A and rdlength == 4:
                addresses[name] = socket.inet_ntoa(data[cursor:cursor + 4])
            elif rtype == _TYPE_TXT:
                texts[name] = _decode_txt(data[cursor:rdata_end])

            cursor = rdata_end
    except DiscoveryError:
        pass

    found: List[Discovered] = []
    for instance in instances:
        target_port = services.get(instance)
        if target_port is None:
            # An instance with no SRV is an address nobody can connect
            # to. Reporting it would put a row in the picker that fails
            # the moment it is chosen.
            continue
        target, port = target_port
        host = addresses.get(target) or target.rstrip(".")
        found.append(Discovered(
            name=_instance_label(instance, service),
            host=host,
            port=port,
            properties=texts.get(instance, {}),
        ))
    return found


def _instance_label(instance: str, service: str) -> str:
    """The part a person named, without the service suffix."""
    suffix = "." + service.rstrip(".")
    trimmed = instance.rstrip(".")
    if trimmed.endswith(suffix):
        return trimmed[:-len(suffix)]
    return trimmed


def _decode_txt(raw: bytes) -> Dict[str, str]:
    """TXT records are length-prefixed ``key=value`` strings."""
    out: Dict[str, str] = {}
    cursor = 0
    while cursor < len(raw):
        length = raw[cursor]
        cursor += 1
        if length == 0 or cursor + length > len(raw):
            break
        item = raw[cursor:cursor + length].decode("utf-8", "replace")
        cursor += length
        key, _, value = item.partition("=")
        if key:
            out[key] = value
    return out


# ==========================================================================
# The search
# ==========================================================================
def search(timeout_s: float = DEFAULT_SEARCH_S,
           service: str = SERVICE_TYPE) -> List[Discovered]:
    """Ask once, listen for a moment, report what answered.

    A one-shot on purpose. See the lazy rule in the module docstring: a
    Studio that browsed continuously would put multicast traffic on
    somebody else's network for as long as it was open.

    Returns an empty list when nothing answers, which is an ordinary
    answer and not an error. It raises only when the search could not be
    PERFORMED, because "I could not look" and "I looked and there was
    nothing" call for different things from the caller.
    """
    query = encode_query(service)
    deadline = time.monotonic() + max(0.1, float(timeout_s))
    found: Dict[str, Discovered] = {}

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except OSError as exc:
        raise DiscoveryError(f"could not open a socket to search: {exc}")

    try:
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            # Time to live of one: a search is for the local network. A
            # larger value asks routers to carry it further, which is
            # both useless here and rude.
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
            sock.bind(("", 0))
        except OSError as exc:
            raise DiscoveryError(f"could not prepare the search: {exc}")

        try:
            sock.sendto(query, (MDNS_GROUP, MDNS_PORT))
        except OSError as exc:
            raise DiscoveryError(f"the search could not be sent: {exc}")

        while time.monotonic() < deadline:
            sock.settimeout(max(0.05, deadline - time.monotonic()))
            try:
                data, _peer = sock.recvfrom(9000)
            except socket.timeout:
                break
            except OSError:
                break
            try:
                for item in decode_response(data, service):
                    # Keyed by endpoint: one gateway answering twice is
                    # one gateway, and a duplicate row in a picker is a
                    # user wondering which to choose.
                    found.setdefault(item.endpoint, item)
            except DiscoveryError:
                # A malformed reply is one responder's problem, not the
                # search's. Another may still answer correctly.
                continue
    finally:
        try:
            sock.close()
        except OSError:
            pass

    return sorted(found.values(), key=lambda item: (item.name, item.endpoint))


#: How many addresses the sweep talks to at once. High enough that a /24
#: finishes while somebody is still looking at the button, low enough not
#: to be the reason a laptop's Wi-Fi stack falls over.
SWEEP_WORKERS = 64

#: How long one address gets. A gateway on the same subnet answers in
#: milliseconds; this is the patience for one that is merely slow, not a
#: budget for the whole sweep, which runs them in parallel.
SWEEP_TIMEOUT_S = 1.0


def local_ipv4() -> Optional[str]:
    """This machine's address on the interface a gateway would be reached
    through.

    Asked of the routing table rather than of DNS, because a machine's
    host name resolves to all sorts of things and only one of them is the
    interface that would carry this traffic. Connecting a UDP socket
    sends no packet; it only makes the OS choose.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 53))
        return str(sock.getsockname()[0])
    except OSError:
        return None
    finally:
        try:
            sock.close()
        except OSError:
            pass


def sweep(port: int = DEFAULT_PORT, *, probe=None, accepts=None,
          verify: bool = False,
          timeout_s: float = SWEEP_TIMEOUT_S,
          workers: int = SWEEP_WORKERS,
          host_ip: Optional[str] = None) -> List["Discovered"]:
    """Find gateways by trying the port, for radios that cannot advertise.

    **This does not talk to what it finds, and that is a hardware
    constraint rather than a shortcut.**

    A gateway's radio may hold exactly ONE connection. Opening a link
    session against it costs that connection, and this radio needs
    several seconds to re-arm afterwards. Measured on an ST IoT node,
    three times: a sweep that opened link sessions left the gateway
    answering nothing for at least forty seconds, and once it did not
    come back at all. A Search button that breaks the gateway it is
    looking for is worse than no Search button. Bare TCP connects, even
    sixty-four at a time, were harmless in the same measurements.

    So a sweep reports **what is listening on the gateway's port**, and
    the verification is the connection the user is about to make anyway.
    That is this module's own principle, applied where it belongs: a
    gateway that answers is checked by connecting to it. The dialog's
    Test connection button and the connect itself both do exactly that,
    and both say plainly when nothing answers.

    The cost is that something else sitting on this port would be listed
    and would then fail to connect, with a message saying so. That is a
    far smaller price than a discovery that breaks the device.

    Pass ``verify=True`` to check each candidate with a link ping. It is
    honest on hardware that tolerates it and it is NOT the default,
    because the hardware in front of us does not.

    Bounded to the local /24, one-shot, and only when a user pressed a
    button. Never a poll.
    """
    if probe is None:
        from .client import LinkClient

        def probe(host: str, port_: int) -> bool:           # noqa: E306
            client = LinkClient(timeout_s=max(timeout_s, 2.0))
            try:
                if not client.connect(host, int(port_)):
                    return False
                return client.ping() is not None
            except Exception:                               # noqa: BLE001
                return False
            finally:
                client.close()

    me = host_ip or local_ipv4()
    if not me:
        return []

    try:
        import ipaddress

        network = ipaddress.ip_network(f"{me}/24", strict=False)
        hosts = [str(h) for h in network.hosts() if str(h) != me]
    except ValueError:
        return []

    # -- phase 1: who is even listening ---------------------------------
    def _accepts(host: str) -> bool:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout_s)
        try:
            sock.connect((host, int(port)))
            return True
        except OSError:
            return False
        finally:
            try:
                sock.close()
            except OSError:
                pass

    import concurrent.futures

    candidates: List[str] = []
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, int(workers))) as pool:
        touch = accepts if accepts is not None else _accepts
        futures = {pool.submit(touch, host): host for host in hosts}
        for future in concurrent.futures.as_completed(futures):
            try:
                if future.result():
                    candidates.append(futures[future])
            except Exception:                               # noqa: BLE001
                continue

    # -- and that is as far as this goes, unless asked ------------------
    #
    # See the note above: talking to a candidate costs the gateway its
    # one connection and several seconds, and on the radio in front of
    # us it has been measured to cost more than that.
    if not verify:
        return [Discovered(name=host, host=host, port=int(port),
                           properties={"found_by": "listening"})
                for host in sorted(candidates)]

    # Serial, deliberately: several candidates are asked in turn rather
    # than all at once, which is the half of the old sweep that did the
    # damage.
    found: List[Discovered] = []
    for host in sorted(candidates):
        try:
            if probe(host, port):
                found.append(Discovered(name=host, host=host,
                                        port=int(port),
                                        properties={"found_by": "sweep"}))
        except Exception:                                   # noqa: BLE001
            continue

    return sorted(found, key=lambda item: item.endpoint)


def gateways_for_connecting(remembered: Optional[List[str]] = None,
                            *, probe=None, search_fn=None,
                            sweep_fn=None,
                            timeout_s: float = DEFAULT_SEARCH_S,
                            ) -> Tuple[List[Discovered], bool]:
    """The ladder, from rung two down.

    Returns ``(gateways, searched)``. The flag is not decoration: a
    caller that found a remembered gateway and one that had to search
    should say different things, because the second means the address the
    user had has changed.

    ``probe`` and ``search_fn`` are injected so this can be tested
    without a network, and so the caller decides what "answers" means.
    """
    if probe is None:
        from .client import LinkClient

        def probe(host: str, port: int) -> bool:            # noqa: E306
            client = LinkClient(timeout_s=1.5)
            try:
                if not client.connect(host, int(port)):
                    return False
                return client.ping() is not None
            finally:
                client.close()

    # Rung 2: a remembered gateway, tried directly. After the first day
    # this is the common case, and it should feel like plugging in.
    for endpoint in list(remembered or []):
        host, port = _split(endpoint)
        if not host:
            continue
        try:
            if probe(host, port):
                return ([Discovered(name=host, host=host, port=port,
                                    properties={})], False)
        except Exception:                                   # noqa: BLE001
            continue

    # Rung 3: only now, a search, and only because a connection was
    # wanted and nothing answered.
    finder = search_fn if search_fn is not None else search
    try:
        answered = list(finder(timeout_s))
    except DiscoveryError:
        answered = []
    if answered:
        return (answered, True)

    # AND THAT IS WHERE IT STOPS, unless the caller supplies a rung.
    #
    # There is an obvious next step, and it was written, measured and
    # taken back out: try the gateway's port across the subnet. It works,
    # and on the ST IoT node's radio it is not safe. A connection that
    # lands while that gateway is re-arming its listener leaves it
    # serving nobody, and this end cannot know when that is, because the
    # user presses the button whenever they like. Measured both ways:
    # harmless after a long idle, wedged ten seconds after a session
    # closed. A Search that sometimes breaks the gateway it is looking
    # for is worse than a Search that admits it found nothing.
    #
    # sweep() is still there and still honest. A caller that knows its
    # hardware tolerates being probed can pass it in.
    if sweep_fn is not None:
        try:
            return (list(sweep_fn(port=DEFAULT_PORT, probe=probe)), True)
        except Exception:                                   # noqa: BLE001
            return ([], True)
    return ([], True)


def _split(endpoint: str) -> Tuple[str, int]:
    """``host:port`` to its parts, tolerating a missing port."""
    text = (endpoint or "").strip()
    if ":" in text:
        host, _, port = text.rpartition(":")
        try:
            return host.strip(), int(port)
        except ValueError:
            return host.strip(), DEFAULT_PORT
    return text, DEFAULT_PORT


__all__ = [
    "Discovered", "DiscoveryError", "SERVICE_TYPE", "DEFAULT_SEARCH_S",
    "encode_query", "decode_response", "encode_name", "decode_name",
    "search", "sweep", "local_ipv4", "gateways_for_connecting",
]
