/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-11 03:53:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe mrac_lyapunov1;
probe mrac_lyapunov;
probe str_measured;
probe adrc_measured;
probe esc_measured;
probe repetitive_ctrl;
probe mrac_tracking;
probe mrac_measured;

/* Global Struct Declarations */
// Configuration for Mrac_Lyapunov
PP_MRACLyapunovConfig Mrac_Lyapunov_config = {
  .Am = 0.99f,
  .Bm = 0.01f,
  .gamma_x = 1.0f,
  .gamma_r = 1.0f,
  .sigma = 0.01f,
  .theta_max = 10.0f
};

// Configuration for Str
static float Str_desired_poles[2] = {0.5f, 0.3f};
PP_STRConfig Str_config = {
  .na = 2,
  .nb = 2,
  .lambda = 0.98f,
  .P_init = 100.0f,
  .desired_poles = Str_desired_poles
};

// Configuration for Adrc
PP_ADRCConfig Adrc_config = {
  .b0 = 5.0f,
  .omega_o = 100.0f,
  .omega_c = 50.0f,
  .order = 1
};

// Configuration for Esc
PP_ESCConfig Esc_config = {
  .a = 0.1f,
  .omega = 10.0f,
  .k = 1.0f,
  .hpf_wc = 5.0f,
  .lpf_wc = 1.0f
};

// Configuration for Repetitive_Ctrl
PP_RepCtrlConfig Repetitive_Ctrl_config = {
  .period_samples = 100,
  .Q_gain = 0.95f,
  .Kr = 0.5f
};

// Configuration for Mrac
PP_MRACConfig Mrac_config = {
  .Am = 0.99f,
  .Bm = 0.01f,
  .gamma_x = 1.0f,
  .gamma_r = 1.0f
};


/* Global Array Declarations */
float MRAC_LYAPUNOV_plant_numerator[] = {1.0f};
float MRAC_LYAPUNOV_plant_denominator[] = {0.2f, 1.0f};
float STR_plant_numerator[] = {1.0f};
float STR_plant_denominator[] = {0.2f, 1.0f};
float ADRC_plant_numerator[] = {1.0f};
float ADRC_plant_denominator[] = {0.2f, 1.0f};
float ESC_plant_numerator[] = {1.0f};
float ESC_plant_denominator[] = {0.2f, 1.0f};
float REPETITIVE_CTRL_plant_numerator[] = {1.0f};
float REPETITIVE_CTRL_plant_denominator[] = {0.2f, 1.0f};
float MRAC_plant_numerator[] = {1.0f};
float MRAC_plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::square(0.3f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource Source_2 = signalSource::square(0.3f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  expander fan_5 = expander(5);
  expander MRAC_LYAPUNOV_ref = expander(1);
  expander STR_ref = expander(1);
  expander ADRC_ref = expander(1);
  expander ESC_ref = expander(1);
  expander REPETITIVE_CTRL_ref = expander(1);
  mracLyapunov Mrac_Lyapunov = mracLyapunov(&Mrac_Lyapunov_config);
  tf MRAC_LYAPUNOV_plant = tf(MRAC_LYAPUNOV_plant_numerator, 1, MRAC_LYAPUNOV_plant_denominator, 2);
  expander MRAC_LYAPUNOV_fb = expander(2);
  str Str = str(&Str_config);
  tf STR_plant = tf(STR_plant_numerator, 1, STR_plant_denominator, 2);
  expander STR_fb = expander(2);
  adrc Adrc = adrc(&Adrc_config);
  tf ADRC_plant = tf(ADRC_plant_numerator, 1, ADRC_plant_denominator, 2);
  expander ADRC_fb = expander(2);
  node ESC_error = node("[1.0 -1.0]", "[1.0]", Sum);
  esc Esc = esc(&Esc_config);
  tf ESC_plant = tf(ESC_plant_numerator, 1, ESC_plant_denominator, 2);
  expander ESC_fb = expander(2);
  node REPETITIVE_CTRL_error = node("[1.0 -1.0]", "[1.0]", Sum);
  repetitiveCtrl Repetitive_Ctrl = repetitiveCtrl(&Repetitive_Ctrl_config);
  tf REPETITIVE_CTRL_plant = tf(REPETITIVE_CTRL_plant_numerator, 1, REPETITIVE_CTRL_plant_denominator, 2);
  expander REPETITIVE_CTRL_fb = expander(2);
  mrac Mrac = mrac(&Mrac_config);
  tf MRAC_plant = tf(MRAC_plant_numerator, 1, MRAC_plant_denominator, 2);
  expander MRAC_fb = expander(2);
  mrac_lyapunov1 = probe("mrac_lyapunov1");
  mrac_lyapunov = probe("mrac_lyapunov");
  str_measured = probe("str_measured");
  adrc_measured = probe("adrc_measured");
  esc_measured = probe("esc_measured");
  repetitive_ctrl = probe("repetitive_ctrl");
  mrac_tracking = probe("mrac_tracking");
  mrac_measured = probe("mrac_measured");

  /* Connect Blocks */
  Source > fan_5;
  Source_2 > Mrac.in(0);
  fan_5.out(0) > MRAC_LYAPUNOV_ref;
  fan_5.out(1) > STR_ref;
  fan_5.out(2) > ADRC_ref;
  fan_5.out(3) > ESC_ref;
  fan_5.out(4) > REPETITIVE_CTRL_ref;
  MRAC_LYAPUNOV_ref > Mrac_Lyapunov.in(0);
  STR_ref > Str.in(0);
  ADRC_ref > Adrc.in(0);
  ESC_ref > ESC_error.in(0);
  REPETITIVE_CTRL_ref > REPETITIVE_CTRL_error.in(0);
  Mrac_Lyapunov.out(0) > MRAC_LYAPUNOV_plant;
  Mrac_Lyapunov.out(1) > mrac_lyapunov1;
  MRAC_LYAPUNOV_plant > MRAC_LYAPUNOV_fb;
  MRAC_LYAPUNOV_fb.out(0) > Mrac_Lyapunov.in(1);
  MRAC_LYAPUNOV_fb.out(1) > mrac_lyapunov;
  Str > STR_plant;
  STR_plant > STR_fb;
  STR_fb.out(0) > Str.in(1);
  STR_fb.out(1) > str_measured;
  Adrc > ADRC_plant;
  ADRC_plant > ADRC_fb;
  ADRC_fb.out(0) > Adrc.in(1);
  ADRC_fb.out(1) > adrc_measured;
  ESC_error > Esc;
  Esc > ESC_plant;
  ESC_plant > ESC_fb;
  ESC_fb.out(0) > ESC_error.in(1);
  ESC_fb.out(1) > esc_measured;
  REPETITIVE_CTRL_error > Repetitive_Ctrl;
  Repetitive_Ctrl > REPETITIVE_CTRL_plant;
  REPETITIVE_CTRL_plant > REPETITIVE_CTRL_fb;
  REPETITIVE_CTRL_fb.out(0) > REPETITIVE_CTRL_error.in(1);
  REPETITIVE_CTRL_fb.out(1) > repetitive_ctrl;
  Mrac.out(0) > MRAC_plant;
  Mrac.out(1) > mrac_tracking;
  MRAC_plant > MRAC_fb;
  MRAC_fb.out(0) > Mrac.in(1);
  MRAC_fb.out(1) > mrac_measured;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    mrac_lyapunov1.show();
    mrac_lyapunov.show();
    str_measured.show();
    adrc_measured.show();
    esc_measured.show();
    repetitive_ctrl.show();
    mrac_tracking.show();
    mrac_measured.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}