var classcheby2 =
[
    [ "cheby2", "classcheby2.html#a22d451d4237e7036b4fac76f3141d929", null ],
    [ "cheby2", "classcheby2.html#a2d149ff406156ca24495f459b8e8b034", null ]
];