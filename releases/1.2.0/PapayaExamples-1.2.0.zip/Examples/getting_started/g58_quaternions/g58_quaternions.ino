/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe recovered_roll;
probe recovered_pitch;
probe recovered_yaw;
probe composed_w;
probe composed_x;
probe composed_y;
probe composed_z;
probe unused_signals;

input roll;
input pitch;
input yaw;
input norm_mode;
input identity_0;
input identity_1;
input identity_2;
input identity_3;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  roll = input("roll", 0.0f);
  pitch = input("pitch", 0.0f);
  yaw = input("yaw", 0.0f);
  norm_mode = input("norm_mode", 0.0f);
  identity_0 = input("identity_0", 1.0f);
  identity_1 = input("identity_1", 0.0f);
  identity_2 = input("identity_2", 0.0f);
  identity_3 = input("identity_3", 0.0f);
  quatFromEuler To_quaternion = quatFromEuler();
  expander q0_split = expander(3);
  expander q1_split = expander(3);
  expander q2_split = expander(3);
  expander q3_split = expander(3);
  quatToEuler Back_to_angles = quatToEuler();
  quatToRotmat Rotation_matrix = quatToRotmat();
  quatNormConj Normalise = quatNormConj();
  quatMult Compose = quatMult();
  merger unused_bus = merger(9);
  recovered_roll = probe("recovered_roll");
  recovered_pitch = probe("recovered_pitch");
  recovered_yaw = probe("recovered_yaw");
  composed_w = probe("composed_w");
  composed_x = probe("composed_x");
  composed_y = probe("composed_y");
  composed_z = probe("composed_z");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  roll > To_quaternion.in(0);
  pitch > To_quaternion.in(1);
  yaw > To_quaternion.in(2);
  norm_mode > Normalise.in(4);
  identity_0 > Compose.in(4);
  identity_1 > Compose.in(5);
  identity_2 > Compose.in(6);
  identity_3 > Compose.in(7);
  To_quaternion.out(0) > q0_split;
  To_quaternion.out(1) > q1_split;
  To_quaternion.out(2) > q2_split;
  To_quaternion.out(3) > q3_split;
  q0_split.out(0) > Back_to_angles.in(0);
  q0_split.out(1) > Rotation_matrix.in(0);
  q0_split.out(2) > Normalise.in(0);
  q1_split.out(0) > Back_to_angles.in(1);
  q1_split.out(1) > Rotation_matrix.in(1);
  q1_split.out(2) > Normalise.in(1);
  q2_split.out(0) > Back_to_angles.in(2);
  q2_split.out(1) > Rotation_matrix.in(2);
  q2_split.out(2) > Normalise.in(2);
  q3_split.out(0) > Back_to_angles.in(3);
  q3_split.out(1) > Rotation_matrix.in(3);
  q3_split.out(2) > Normalise.in(3);
  Back_to_angles.out(0) > recovered_roll;
  Back_to_angles.out(1) > recovered_pitch;
  Back_to_angles.out(2) > recovered_yaw;
  Rotation_matrix.out(0) > unused_bus.in(0);
  Rotation_matrix.out(1) > unused_bus.in(1);
  Rotation_matrix.out(2) > unused_bus.in(2);
  Rotation_matrix.out(3) > unused_bus.in(3);
  Rotation_matrix.out(4) > unused_bus.in(4);
  Rotation_matrix.out(5) > unused_bus.in(5);
  Rotation_matrix.out(6) > unused_bus.in(6);
  Rotation_matrix.out(7) > unused_bus.in(7);
  Rotation_matrix.out(8) > unused_bus.in(8);
  Normalise.out(0) > Compose.in(0);
  Normalise.out(1) > Compose.in(1);
  Normalise.out(2) > Compose.in(2);
  Normalise.out(3) > Compose.in(3);
  Compose.out(0) > composed_w;
  Compose.out(1) > composed_x;
  Compose.out(2) > composed_y;
  Compose.out(3) > composed_z;
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  roll.enableRemote();
  pitch.enableRemote();
  yaw.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    recovered_roll.show();
    recovered_pitch.show();
    recovered_yaw.show();
    composed_w.show();
    composed_x.show();
    composed_y.show();
    composed_z.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}