var classchorus =
[
    [ "chorus", "classchorus.html#ad5388dd48324e69f011c45d9db3d9690", null ]
];