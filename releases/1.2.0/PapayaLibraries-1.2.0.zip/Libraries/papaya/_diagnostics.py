"""
Opt-in local diagnostics.

Records anonymous usage events to a local log **only when the user opts
in** (Preferences -> General). Nothing is transmitted: there is no
backend, so the feature is free and private by default. The local log
lives in the logs directory, so it is picked up by the "Report a
Problem" bundle: a user who hits trouble can choose to share recent
activity with support, but no data ever leaves the machine on its own.

Disabled by default (opt-in). :func:`log_event` is a cheap no-op when
disabled. When a telemetry backend is added later, only :func:`log_event`
needs to grow an upload path; every call site stays unchanged.
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

from . import _app_paths

_SETTINGS_KEY = "diagnostics/enabled"
_LOG_NAME = "diagnostics.jsonl"


def diagnostics_enabled() -> bool:
    """Whether the user has opted in to local diagnostics (default False)."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        return bool(QSettings("Shanon Technologies", "Papaya Studio").value(
            _SETTINGS_KEY, False, type=bool))
    except Exception:
        return False


def set_diagnostics_enabled(enabled: bool) -> None:
    """Persist the diagnostics opt-in."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        s = QSettings("Shanon Technologies", "Papaya Studio")
        s.setValue(_SETTINGS_KEY, bool(enabled))
        s.sync()
    except Exception:
        pass


def log_path() -> Path:
    """Path to the local diagnostics log (a JSON-lines file)."""
    return _app_paths.logs_dir() / _LOG_NAME


def log_event(event: str, **fields) -> None:
    """Append one diagnostics event as a JSON line.

    A cheap no-op when the user has not opted in. Never raises.
    """
    if not diagnostics_enabled():
        return
    record = {
        "ts": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "event": str(event),
    }
    record.update(fields)
    try:
        with open(log_path(), "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
    except OSError:
        pass


def clear_log() -> None:
    """Delete the local diagnostics log (used when the user opts out)."""
    try:
        log_path().unlink()
    except OSError:
        pass
