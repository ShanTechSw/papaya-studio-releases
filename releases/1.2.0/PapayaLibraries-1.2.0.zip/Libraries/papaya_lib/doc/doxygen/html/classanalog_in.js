var classanalog_in =
[
    [ "analogIn", "classanalog_in.html#ac3473b12e47bb22c0a73aec0948b2b0a", null ],
    [ "analogIn", "classanalog_in.html#aa31f6b83ddc24903762d1c856ffad0a6", null ]
];