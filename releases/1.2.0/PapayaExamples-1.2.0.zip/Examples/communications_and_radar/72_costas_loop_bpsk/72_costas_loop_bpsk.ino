/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe phase_error;
probe quadrature_arm;
probe recovered_bits;

input carrier_rate;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  carrier_rate = input("carrier_rate", 12440.7f);
  signalSource SIM__carrier = signalSource::sine(2000.0f, 0.0f);
  signalSource SIM__data_bits = signalSource::square(80.0f, 0.0f);
  node BPSK_signal = node("[1.0 1.0]", "[1.0]", Mul);
  expander fan_2_2 = expander(2);
  node I_mixer = node("[1.0 1.0]", "[1.0]", Mul);
  butter I_arm_LPF = butter(4, 200.0, passLow);
  expander fan_2_3 = expander(2);
  node phase_detector = node("[1.0 1.0]", "[1.0]", Mul);
  leadLag loop_filter = leadLag(150.0, 60.0, 0.05);
  node NCO_rate = node("[1.0 1.0]", "[1.0]", Sum);
  integrator NCO_phase = integrator();
  expander fan_2 = expander(2);
  cosineFunc LO_cosine = cosineFunc();
  node Q_mixer = node("[1.0 1.0]", "[1.0]", Mul);
  butter Q_arm_LPF = butter(4, 200.0, passLow);
  sineFunc LO_sine = sineFunc();
  sign bit_slicer = sign();
  phase_error = probe("phase_error");
  quadrature_arm = probe("quadrature_arm");
  recovered_bits = probe("recovered_bits");

  /* Connect Blocks */
  carrier_rate > NCO_rate.in(1);
  SIM__carrier > BPSK_signal.in(0);
  SIM__data_bits > BPSK_signal.in(1);
  BPSK_signal > fan_2_2;
  fan_2_2.out(0) > I_mixer.in(0);
  fan_2_2.out(1) > Q_mixer.in(0);
  I_mixer > I_arm_LPF;
  I_arm_LPF > fan_2_3;
  fan_2_3.out(0) > phase_detector.in(0);
  fan_2_3.out(1) > bit_slicer;
  phase_detector > loop_filter;
  loop_filter > NCO_rate.in(0);
  loop_filter > phase_error;
  NCO_rate > NCO_phase;
  NCO_phase > fan_2;
  fan_2.out(1) > LO_cosine;
  fan_2.out(0) > LO_sine;
  LO_cosine > Q_mixer.in(1);
  Q_mixer > Q_arm_LPF;
  Q_arm_LPF > phase_detector.in(1);
  Q_arm_LPF > quadrature_arm;
  LO_sine > I_mixer.in(1);
  bit_slicer > recovered_bits;

  /* Enable Remote Input Control */
  carrier_rate.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    phase_error.show();
    quadrature_arm.show();
    recovered_bits.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}