var searchData=
[
  ['kaiser5_0',['kaiser5',['../_p_a_p_a_y_a_8h.html#aef9b3e5d8856ec7b479ff82df4e4a58da8a86e823e4262b34fda2f5b8c3eabc34',1,'PAPAYA.h']]],
  ['kaiser8_1',['kaiser8',['../_p_a_p_a_y_a_8h.html#aef9b3e5d8856ec7b479ff82df4e4a58da86045129404199f17c57faf41015336d',1,'PAPAYA.h']]]
];
