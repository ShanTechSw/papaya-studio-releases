/**
 * @file    papaya_link_gateway.h
 * @brief   The relay engine: link frames in, board conversation out.
 *
 * A gateway is a host wired to a PAPAYA board that carries the board's
 * conversation to and from PAPAYA Studio over the air. This is the part
 * that decides what to do with each message, and it is deliberately the
 * part that owns nothing: no socket, no thread, no timer, no allocation.
 * A transport feeds it frames and sends what it emits, and the clock is
 * handed in. So the whole of a gateway's behaviour, including the failure
 * paths that are miserable to provoke on real hardware, is reachable from
 * a test with a fake board.
 *
 * What it knows, and what it refuses to know
 * ------------------------------------------
 * It performs five transaction shapes on the board's wire and parses
 * **no opcodes at all**. The far end composed the command and knows what
 * it means; the gateway knows only how a command of that shape is
 * carried. That is what stops a relay having to keep up with a firmware
 * it does not model, and it is worth defending: the moment this file
 * contains a list of opcodes, every firmware change becomes a gateway
 * change too.
 *
 * The rules it exists to enforce
 * ------------------------------
 * **A command may never be abandoned partway.** The board has no
 * inter-frame timeout. A body that stops arriving leaves its receive
 * state machine waiting forever, and nothing short of a reset clears it.
 * So when a command cannot be completed (the link died, a chunk arrived
 * out of order, a new command barged in) the gateway sends the chunks the
 * header declared anyway, as filler. The board then completes its
 * receive, fails the body checksum, and answers an error. An error is
 * recoverable; a stalled state machine is not.
 *
 * **One chunk at a time.** Nothing here ever holds more than one body
 * chunk, whatever the size of the command passing through. That is what
 * makes a 32 KB host viable, and it is why the link splits commands
 * rather than handing over whole ones.
 *
 * **Two opcodes are refused by value.** This is the one place opcode
 * knowledge is admitted, precisely because both would damage the link
 * rather than merely fail: the flow-credit opcode, whose firmware handler
 * reads from the USB endpoint and is meaningless on the board's other
 * wire; and the deprecated live-rate opcode, which the board rejects
 * unconditionally AND latches, so it breaks whatever the gateway does
 * next rather than just itself.
 *
 * **Mode changes and resets are performed, not relayed.** A lost mode
 * byte leaves the board streaming into an endpoint nobody drains,
 * recoverable by nothing short of physical reset. The gateway runs those
 * sequences locally and reports what happened.
 *
 * **Telemetry is a pull turned into a push.** The Monitor expects samples
 * to arrive; the board answers only when asked. A subscription puts the
 * gateway on a schedule and pollTelemetry() is one tick of it.
 *
 * Written for a freestanding target: no allocation, no exceptions, no
 * standard containers, every buffer supplied by the caller.
 */
#pragma once

#include <stdint.h>

#include "papaya_link_protocol.h"

namespace papaya {
namespace link {

/**
 * The board's wire, as the relay needs it.
 *
 * Deliberately shaped as transactions rather than bytes. On the board's
 * wire the master frames every exchange by driving chip-select, so "write
 * some bytes" is not a meaningful request: there is no boundary in a byte
 * stream to drive it from. Each method below is one or more of those
 * framed exchanges, with a known shape.
 *
 * An implementation over the PAPAYA library's relay entry points is in
 * papaya_link_board_port.h.
 */
class BoardPort
{
public:
  virtual ~BoardPort(void) {}

  /** Begin a command: put its header on the wire. */
  virtual void beginCommand(const uint8_t *header, uint16_t length) = 0;

  /** One body chunk, straight to the wire. Never buffered here. */
  virtual void sendBodyChunk(const uint8_t *chunk, uint32_t length) = 0;

  /**
   * Poll until the board answers or the deadline expires.
   *
   * @return bytes written to @p status, or 0 if nothing valid arrived.
   *         Until the board has an answer ready it echoes the request
   *         back, and an echo is exactly the right length to be mistaken
   *         for a reply, so an implementation must check the frame
   *         against its own checksum rather than trust its arrival.
   */
  virtual uint16_t awaitStatus(uint8_t *status, uint16_t capacity) = 0;

  /** The payload the board queued behind a status. */
  virtual uint32_t readDataPayload(uint8_t *out, uint32_t length) = 0;

  /**
   * Probe samples, by explicit byte count.
   *
   * The count is the far end's, always: the board's own read sizes itself
   * from probe objects the running PROGRAM constructed, and a relay
   * constructs none.
   */
  virtual uint32_t readProbes(uint8_t *out, uint32_t length, bool vector) = 0;

  /** Live input values, all in one exchange. Splitting them leaves the
   *  firmware waiting for floats and mis-parsing whatever comes next. */
  virtual bool writeInputs(const uint8_t *values, uint32_t length) = 0;

  /**
   * One opcode byte, one chip-select pulse, nothing polled afterwards.
   *
   * The board's wire carries several exchanges that are a lone opcode,
   * and a cable writes them as one byte. Shape kShapeOpcodeOnly is how
   * the far end asks for that, and this is where it reaches the wire.
   */
  virtual bool sendOpcode(uint8_t opcode) = 0;

  /** Drive the board's reset line. The capability a cable does not have:
   *  a USB host can only ASK a board to reset itself, which is no help
   *  once it has stopped listening. */
  virtual bool resetBoard(void) = 0;

  /** Put the board back where a departing Studio would have left it.
   *
   *  A session that ends properly ends with the host telling the board
   *  to leave data exchange. A session that ends because the peer
   *  vanished never sends that, and the board goes on sampling for
   *  nobody: measured 2026-08-26 on an ESP32-S3, a half-open Studio
   *  left the board with sampling started and data exchange allowed,
   *  and the NEXT Studio then spent about 75 s failing to anchor
   *  against it, on top of the 17 s the gateway itself took to give up.
   *
   *  The gateway is the only thing that knows the client has gone AND
   *  still has the wire, so it is the only thing that can do this.
   *
   *  Default: nothing. A port with no notion of sampling is not obliged
   *  to grow one, and a port that cannot do it safely must not pretend.
   */
  virtual void quiesce(void) {}
};

/**
 * Where the engine's replies go.
 *
 * A sink rather than a returned list, because a returned list means
 * either allocation or a bound on how many replies a message may produce,
 * and both are worse than a callback on a target like this.
 *
 * It takes up to three pieces rather than one buffer, and that is not
 * convenience. A telemetry batch is a payload header followed by samples
 * already sitting in the gateway's scratch, and a command result is a
 * header followed by a status and a data payload sitting in the same
 * place. Joining them to send them would double the memory needed for the
 * largest thing this host carries, on exactly the hosts least able to
 * afford it. The pieces go out where they lie and the checksum is
 * accumulated across them; see encodeFrameHeader() for how.
 */
class FrameSink
{
public:
  virtual ~FrameSink(void) {}

  /** @return false when the link has gone, which stops the engine trying
   *          to finish a conversation with nobody. */
  virtual bool send(uint8_t type, uint16_t seq,
                    const uint8_t *first, uint32_t firstLength,
                    const uint8_t *second, uint32_t secondLength,
                    const uint8_t *third, uint32_t thirdLength) = 0;

  /**
   * How large a frame this transport hands over COMFORTABLY, in bytes.
   *
   * 0 means it does not say, and a caller must then assume nothing.
   *
   * THIS IS WHAT A GATEWAY MAY ANNOUNCE, and it is not the same question
   * as how much memory the gateway has. A batch larger than this is not
   * refused: it is split into several writes, and on a radio driven by a
   * command interface every write costs several round trips whatever it
   * carries. So a host told to size batches by MEMORY would produce
   * frames that are technically deliverable and ruinously slow on
   * exactly the hosts least able to afford it.
   *
   * The engine therefore announces the smaller of this and the buffer a
   * batch is read into. See Gateway::announce().
   */
  virtual uint32_t comfortableFrameBytes(void) const { return 0u; }
};

/**
 * Somewhere to put a telemetry batch that is not the scratch buffer.
 *
 * WHY THIS EXISTS, measured rather than assumed. With one buffer a
 * gateway must finish SENDING a batch before it may start READING the
 * next, because both use the same bytes. Read and send therefore run
 * strictly in sequence, and the slot time is their sum whatever else is
 * true of the host.
 *
 * A stage breaks that. claim() hands out a buffer the sender is not
 * using, so a read may begin while an earlier batch is still going out.
 * On a host with two cores that is the whole difference between the two
 * halves adding up and the two halves overlapping.
 *
 * It is OPTIONAL and the engine works exactly as before without one: a
 * gateway that supplies no stage reads into the scratch buffer and sends
 * from it, which is what every gateway did before this existed and what
 * the smallest ones still do. Nothing here allocates, starts a thread or
 * knows what a socket is; a host that has those things implements this
 * interface and keeps them to itself.
 */
class TelemetryStage
{
public:
  virtual ~TelemetryStage(void) {}

  /**
   * A buffer of at least @p bytes to read the next batch into.
   *
   * @return 0 when every buffer is still in flight, which is a full
   *         stage rather than an error. NEVER BLOCKS: a stage that waited
   *         here would reintroduce exactly the serialisation it exists to
   *         remove, and would do it invisibly.
   */
  virtual uint8_t *claim(uint32_t bytes) = 0;

  /** Give a claimed buffer back unsent. For the read that found the
   *  board had nothing: without this the buffer would leak and the stage
   *  would run dry after as many empty reads as it has slots. */
  virtual void discard(uint8_t *slot) = 0;

  /**
   * Send a claimed buffer, and hand it over.
   *
   * OWNERSHIP PASSES. The stage may write the bytes now or give them to
   * something else that will, so the caller must not read, write or free
   * @p slot again. The stage returns it to its own free list when the
   * bytes have actually gone.
   *
   * @param head  the payload header, which is COPIED because it lives on
   *              the caller's stack and will be gone before an
   *              asynchronous stage gets to it.
   * @return false when the link has gone.
   */
  virtual bool publish(uint8_t type, const uint8_t *head,
                       uint32_t headLength,
                       uint8_t *slot, uint32_t slotLength) = 0;

  /**
   * The largest batch one buffer holds.
   *
   * NOT decoration, and getting it wrong is silent. When a stage is
   * present the scratch buffer no longer carries telemetry, so the
   * scratch's size stops being the bound on a subscription and this
   * becomes it. A gateway that went on refusing against the scratch
   * would accept a batch no buffer can hold, claim() would then return 0
   * for ever, and the far end would see a subscription that succeeded
   * and a stream that never started.
   */
  virtual uint32_t slotBytes(void) const = 0;

  /** Put every buffer back on the free list. Called when a session
   *  begins, so a session that died holding buffers cannot start the
   *  next one short of them. */
  virtual void reset(void) {}

  /**
   * Wait until everything published has gone, or @p timeoutMs passes.
   *
   * Called when a session ENDS, before the socket is closed, and it is
   * not tidiness: a stage that hands batches to another task has bytes
   * in flight referring to a client the caller is about to stop. The
   * bound is what stops a peer that has silently gone from holding the
   * gateway shut.
   */
  virtual void drain(uint32_t timeoutMs) { (void)timeoutMs; }
};

/**
 * Relays one board for one client.
 *
 * The scratch buffer holds one status frame, one data payload, and one
 * telemetry batch. Its size is therefore the real bound on what this host
 * can carry, and a subscription asking for a batch larger than it fits is
 * REFUSED with a reason rather than truncated: half a batch drawn as a
 * whole one is a waveform that is wrong in a way nobody can see.
 */
class Gateway
{
public:
  /** @param scratch   caller-owned working buffer.
   *  @param scratchSize its size. Must be at least kMinScratchSize.
   *  @param stage      optional, and 0 is the behaviour every gateway had
   *                    before it existed: read into the scratch, send
   *                    from the scratch, one at a time. A host that can
   *                    overlap the two halves supplies one. See
   *                    TelemetryStage. */
  Gateway(BoardPort &board, FrameSink &sink, uint8_t *scratch,
          uint32_t scratchSize, TelemetryStage *stage = 0);

  /** Enough for a status frame, a refusal message and a minimal batch.
   *  A real gateway wants far more; this is the floor below which it
   *  cannot function at all. */
  static const uint32_t kMinScratchSize = 256u;

  /** Process one inbound frame, emitting replies through the sink. */
  void handle(const Frame &frame);

  /**
   * Say what this gateway can carry, once, as a session opens.
   *
   * Called by the transport when a client is accepted and BEFORE that
   * client has sent anything, so the number is in the host's hands
   * before it sizes its first subscription. Unsolicited: see
   * encodeWelcome() for why a host that had to ask would pay a round
   * trip at every connect for a number this end already knows.
   *
   * Doing nothing here is a supported gateway, not a broken one: a host
   * that hears no welcome keeps the conservative figure it uses today.
   */
  void announce(void);

  /**
   * Fit the batch ring AFTER construction, once it is known to work.
   *
   * NOT a convenience. Constructed with a stage that then fails to
   * start, this engine advertised the stage's capacity, accepted the
   * subscription, and dropped every batch: claim() answers 0 for ever
   * when there is no writer, so the read never happens and the far end
   * sees a subscription that succeeded and a stream that never started.
   * The program said "live monitoring is slower than this board can
   * manage", which was false; it was dead.
   *
   * So a caller constructs with no stage, starts the stage, and fits it
   * only if it started. Then the fallback is what it claims to be:
   * batches go through the working buffer, one at a time, exactly as on
   * a gateway that never had a ring.
   */
  void useStage(TelemetryStage *stage) { stage_ = stage; }

  /** Seconds are not available here and would not help: the clock a
   *  gateway has is a millisecond counter that WRAPS, roughly every 49
   *  days, and every comparison below is written to survive that. */
  void pollTelemetry(uint32_t nowMs);

  /** Milliseconds until the next poll, or 0xFFFFFFFF when nothing is
   *  subscribed. For a transport deciding how long it may block: it
   *  should wait for whichever comes first, a frame or a batch. */
  uint32_t telemetryDueIn(uint32_t nowMs) const;

  bool isSubscribed(void) const { return subscribed_; }

  /** Counted rather than merely logged: a rising number is the symptom
   *  that distinguishes a bad radio from a bad board. */
  uint32_t flushedCommands(void) const { return flushedCommands_; }
  uint32_t refusedCommands(void) const { return refusedCommands_; }

  /** Slots that went by without a batch. The far end learns the same
   *  thing from the gap in the batch number; this is for whoever is
   *  diagnosing the gateway itself. */
  uint32_t droppedBatches(void) const { return droppedBatches_; }

  /**
   * The largest telemetry batch this gateway can carry, in bytes.
   *
   * The scratch buffer when there is no stage, and the stage's buffer
   * when there is one, because with a stage the scratch carries command
   * results and nothing else. It is what a subscription is refused
   * against, and it is the number a gateway announces at session start
   * so the far end can size batches from the host it is actually talking
   * to rather than from the smallest host in the family.
   */
  uint32_t telemetryCapacity(void) const;

private:
  void onCommand(const Frame &frame);
  void onChunk(const Frame &frame);
  void onSubscribe(const Frame &frame);
  void finish(uint16_t seq);
  void samplingShape(uint16_t seq, uint8_t shape, const uint8_t *header,
                     uint16_t headerLength, const uint8_t *payload,
                     uint32_t payloadLength, uint32_t expectedData);
  void flushPending(void);
  void refuse(uint16_t seq, const char *reason);
  void result(uint16_t seq, uint8_t outcome, const uint8_t *status,
              uint16_t statusLength, const uint8_t *data, uint32_t dataLength);
  const char *refusalReason(const uint8_t *header, uint16_t length) const;

  BoardPort &board_;
  FrameSink &sink_;
  uint8_t *scratch_;
  uint32_t scratchSize_;
  /* Optional. 0 means read and send through scratch_, in sequence. */
  TelemetryStage *stage_;

  /* The command in flight, if any. No body bytes are held: each chunk
   * goes straight to the wire as it arrives. */
  bool pending_;
  uint8_t pendingShape_;
  uint32_t pendingTotalBody_;
  uint32_t pendingReceived_;
  uint32_t pendingExpectedData_;
  uint16_t pendingNextIndex_;

  bool subscribed_;
  Subscription subscription_;
  uint32_t batchSeq_;
  uint32_t nextDueMs_;
  bool scheduleStarted_;

  uint32_t flushedCommands_;
  uint32_t refusedCommands_;
  uint32_t droppedBatches_;
};

}  /* namespace link */
}  /* namespace papaya */
