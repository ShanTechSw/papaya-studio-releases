/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 00:54:18
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe S_curve_profile_tap;
probe S_curve_profile_tap_2;
probe S_curve_profile_tap_3;
probe Motor_tap;
probe Trapezoid_profile_tap;
probe Trapezoid_profile_tap_2;
probe Trapezoid_profile_tap_3;

input target;
input target2;
input scurve_vmax;
input scurve_amax;
input scurve_jerk;
input scurve_start;
input trap_vmax;
input trap_amax;
input trap_start;
input duty_max;
input duty_min;

/* Global Struct Declarations */
// Configuration for Motor
PP_motorBlockCfg Motor_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  1,
  {MotorPosition, NoMotorOutput, NoMotorOutput}
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  target = input("target", 100.0f);
  scurve_vmax = input("scurve_vmax", 200.0f);
  scurve_amax = input("scurve_amax", 1000.0f);
  scurve_jerk = input("scurve_jerk", 10000.0f);
  scurve_start = input("scurve_start", 1.0f);
  duty_max = input("duty_max", 1.0f);
  duty_min = input("duty_min", -1.0f);
  target2 = input("target2", 100.0f);
  trap_vmax = input("trap_vmax", 200.0f);
  trap_amax = input("trap_amax", 1000.0f);
  trap_start = input("trap_start", 1.0f);
  trajScurve S_curve_profile = trajScurve();
  inputShaper Input_shaper = inputShaper(1, 12.0, 0.05);
  gain Kv_feedforward = gain(0.0025);
  gain Ka_feedforward = gain(0.0002);
  node Position_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid Position_PID = pid(0.002, 0.01, 0.0005, 0.01);
  node Command_sum = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  sat Duty_clamp = sat();
  motor Motor = motor(&Motor_config);
  trajTrapezoid Trapezoid_profile = trajTrapezoid();
  S_curve_profile_tap = probe("S-curve_1");
  S_curve_profile_tap_2 = probe("S-curve_2");
  S_curve_profile_tap_3 = probe("S-curve_3");
  Motor_tap = probe("Motor_o0");
  Trapezoid_profile_tap = probe("Trapezoid_0");
  Trapezoid_profile_tap_2 = probe("Trapezoid_1");
  Trapezoid_profile_tap_3 = probe("Trapezoid_2");

  /* Connect Blocks */
  target > S_curve_profile.in(0);
  scurve_vmax > S_curve_profile.in(1);
  scurve_amax > S_curve_profile.in(2);
  scurve_jerk > S_curve_profile.in(3);
  scurve_start > S_curve_profile.in(4);
  duty_max > Duty_clamp.in(0);
  duty_min > Duty_clamp.in(1);
  target2 > Trapezoid_profile.in(0);
  trap_vmax > Trapezoid_profile.in(1);
  trap_amax > Trapezoid_profile.in(2);
  trap_start > Trapezoid_profile.in(3);
  S_curve_profile.out(0) > Input_shaper;
  S_curve_profile.out(1) > Kv_feedforward;
  S_curve_profile.out(2) > Ka_feedforward;
  S_curve_profile.out(1) > S_curve_profile_tap;
  S_curve_profile.out(2) > S_curve_profile_tap_2;
  S_curve_profile.out(3) > S_curve_profile_tap_3;
  Input_shaper > Position_error.in(0);
  Kv_feedforward > Command_sum.in(1);
  Ka_feedforward > Command_sum.in(2);
  Position_error > Position_PID;
  Position_PID > Command_sum.in(0);
  Command_sum > Duty_clamp.in(2);
  Duty_clamp > Motor;
  Motor > Position_error.in(1);
  Motor > Motor_tap;
  Trapezoid_profile.out(0) > Trapezoid_profile_tap;
  Trapezoid_profile.out(1) > Trapezoid_profile_tap_2;
  Trapezoid_profile.out(2) > Trapezoid_profile_tap_3;

  /* Enable Remote Input Control */
  target.enableRemote();
  scurve_vmax.enableRemote();
  scurve_amax.enableRemote();
  scurve_jerk.enableRemote();
  scurve_start.enableRemote();
  duty_max.enableRemote();
  duty_min.enableRemote();
  target2.enableRemote();
  trap_vmax.enableRemote();
  trap_amax.enableRemote();
  trap_start.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    S_curve_profile_tap.show();
    S_curve_profile_tap_2.show();
    S_curve_profile_tap_3.show();
    Motor_tap.show();
    Trapezoid_profile_tap.show();
    Trapezoid_profile_tap_2.show();
    Trapezoid_profile_tap_3.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}