var classhjorth =
[
    [ "hjorth", "classhjorth.html#af7775098371ff3f617892c62551c188a", null ]
];