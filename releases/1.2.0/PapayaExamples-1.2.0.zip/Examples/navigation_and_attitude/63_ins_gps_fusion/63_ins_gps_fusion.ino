/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ins_dead_reckon;
probe fused_position;
probe GPS_INS_EKF_tap;
probe GPS_INS_EKF_tap_2;
probe GPS_INS_EKF_tap_3;
probe GPS_INS_EKF_tap_4;
probe GPS_INS_EKF_tap_5;
probe GPS_INS_EKF_tap_6;
probe ins_drift;
probe gps_outlier;
probe GPS_outlier_gate_tap;

input gps_sigma;
input const_;
input const__2;
input const__3;
input const__4;
input const__5;
input az_zero;

/* Global Struct Declarations */
// Configuration for GPS_INS_EKF
static float GPS_INS_EKF_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float GPS_INS_EKF_R_data[16] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
static float GPS_INS_EKF_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_GPSINS_EKF GPS_INS_EKF_config = {
  .Q_data = GPS_INS_EKF_Q_data,
  .R_data = GPS_INS_EKF_R_data,
  .x_init = GPS_INS_EKF_x_init,
  .P_init = 10.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  gps_sigma = input("gps_sigma", 1.0f);
  az_zero = input("az_zero", 0.0f);
  signalSource SIM__accelerometer = signalSource::multisine(0.2f, 0.3f, 3, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource SIM__GPS_fix = signalSource::sine(0.05f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 10.0f);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  const__3 = input("const", 0.0f);
  const__4 = input("const", 0.0f);
  const__5 = input("const", 0.0f);
  noise SIM__accel_noise = noise(-0.05, 0.05, uniform);
  noise SIM__GPS_noise = noise(-1.7, 1.7, uniform);
  node noisy_accel = node("[1.0 1.0]", "[1.0]", Sum);
  node noisy_GPS = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_2 = expander(2);
  expander fan_2_3 = expander(2);
  integrator INS_velocity = integrator();
  expander fan_2_2 = expander(2);
  integrator INS_position = integrator();
  gpsinsEKF GPS_INS_EKF = gpsinsEKF(&GPS_INS_EKF_config);
  expander fan_3 = expander(2);
  node drift_vs_fusion = node("[1.0 -1.0]", "[1.0]", Sum);
  node gps_residual = node("[1.0 -1.0]", "[1.0]", Sum);
  innovationChi2 GPS_outlier_gate = innovationChi2(1, 6.63);
  ins_dead_reckon = probe("ins_dead_reckon");
  fused_position = probe("fused_position");
  GPS_INS_EKF_tap = probe("GPS/INS EKF_o1");
  GPS_INS_EKF_tap_2 = probe("GPS/INS EKF_o2");
  GPS_INS_EKF_tap_3 = probe("GPS/INS EKF_o3");
  GPS_INS_EKF_tap_4 = probe("GPS/INS EKF_o4");
  GPS_INS_EKF_tap_5 = probe("GPS/INS EKF_o5");
  GPS_INS_EKF_tap_6 = probe("GPS/INS EKF_o6");
  ins_drift = probe("ins_drift_m");
  gps_outlier = probe("gps_outlier_fla");
  GPS_outlier_gate_tap = probe("GPS outlier_0");

  /* Connect Blocks */
  gps_sigma > GPS_outlier_gate.in(1);
  az_zero > GPS_INS_EKF.in(6);
  SIM__accelerometer > noisy_accel.in(0);
  SIM__GPS_fix > noisy_GPS.in(0);
  const_ > SIM__accel_noise;
  const__2 > SIM__GPS_noise;
  const__3 > GPS_INS_EKF.in(1);
  const__4 > GPS_INS_EKF.in(2);
  const__5 > GPS_INS_EKF.in(5);
  SIM__accel_noise > noisy_accel.in(1);
  SIM__GPS_noise > noisy_GPS.in(1);
  noisy_accel > fan_2;
  noisy_GPS > fan_2_3;
  fan_2.out(0) > INS_velocity;
  fan_2.out(1) > GPS_INS_EKF.in(4);
  fan_2_3.out(0) > GPS_INS_EKF.in(0);
  fan_2_3.out(1) > gps_residual.in(0);
  INS_velocity > fan_2_2;
  fan_2_2.out(0) > INS_position;
  fan_2_2.out(1) > GPS_INS_EKF.in(3);
  INS_position > fan_3;
  INS_position > ins_dead_reckon;
  GPS_INS_EKF.out(0) > drift_vs_fusion.in(1);
  GPS_INS_EKF.out(0) > fused_position;
  GPS_INS_EKF.out(1) > GPS_INS_EKF_tap;
  GPS_INS_EKF.out(2) > GPS_INS_EKF_tap_2;
  GPS_INS_EKF.out(3) > GPS_INS_EKF_tap_3;
  GPS_INS_EKF.out(4) > GPS_INS_EKF_tap_4;
  GPS_INS_EKF.out(5) > GPS_INS_EKF_tap_5;
  GPS_INS_EKF.out(6) > GPS_INS_EKF_tap_6;
  fan_3.out(1) > drift_vs_fusion.in(0);
  fan_3.out(0) > gps_residual.in(1);
  drift_vs_fusion > ins_drift;
  gps_residual > GPS_outlier_gate.in(0);
  GPS_outlier_gate.out(1) > gps_outlier;
  GPS_outlier_gate.out(0) > GPS_outlier_gate_tap;

  /* Enable Remote Input Control */
  gps_sigma.enableRemote();
  az_zero.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    ins_dead_reckon.show();
    fused_position.show();
    GPS_INS_EKF_tap.show();
    GPS_INS_EKF_tap_2.show();
    GPS_INS_EKF_tap_3.show();
    GPS_INS_EKF_tap_4.show();
    GPS_INS_EKF_tap_5.show();
    GPS_INS_EKF_tap_6.show();
    ins_drift.show();
    gps_outlier.show();
    GPS_outlier_gate_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}