/**
 * @file    papaya_link_protocol.h
 * @brief   The PAPAYA Link wire format, for a host relaying a board.
 *
 * A gateway is a host wired to a PAPAYA board that carries the board's
 * conversation to and from PAPAYA Studio across a link that is neither
 * the board's wire nor USB: Wi-Fi, Bluetooth, or a serial line to a
 * radio coprocessor. This file is the format those messages travel in,
 * and nothing else. It reads and writes byte buffers, opens no
 * connection, allocates nothing, and holds no state beyond one decoder's
 * own buffer, which is what lets the interesting failures here be tested
 * without a board, a radio or a network.
 *
 * The counterpart at the other end of the link is the identical format,
 * implemented once in Python for the Studio. The two are checked against
 * each other rather than merely written to the same description: a frame
 * either round-trips between them or the build says so.
 *
 * Why a frame at all, on a link that may be TCP
 * ---------------------------------------------
 * TCP would give ordering and delivery for free, so a header with a
 * checksum looks like belt and braces. It is not, for three reasons.
 *
 * - **The link is not always TCP.** Bluetooth is a datagram service with
 *   stack-dependent fragmentation, and a host that reaches its own radio
 *   over a serial line has no stream guarantees at all. A frame that only
 *   survives on one of those has to be re-invented for the others.
 * - **A relay is not a pipe.** The far end must be able to resynchronise
 *   after a truncated write or a half-finished session, and a byte stream
 *   offers nothing to resynchronise TO without a magic to hunt for.
 * - **The payload is a board's command.** Handing the board a subtly
 *   wrong command is materially worse than handing it none, because the
 *   failure then surfaces later and somewhere else. Four bytes to refuse
 *   it here is a good trade.
 *
 * The 400-byte rule, which shapes everything
 * ------------------------------------------
 * A command's body crosses the board's own wire in chunks of
 * @c kBoardChunkSize, and a gateway's job is to put those chunks on that
 * wire. **So a gateway must never need a buffer larger than one chunk**,
 * whatever the size of the command passing through it.
 *
 * That is not a nicety. The smallest hosts this format targets have
 * 32 KB of memory in total, and the largest legitimate command carries an
 * inline waveform table of 65 553 bytes. A link that handed a gateway a
 * whole command would be unusable on those hosts and wasteful on the
 * rest. So a command arrives as a first frame carrying its header and
 * first chunk, followed by chunk frames.
 *
 * Most commands fit entirely in that first frame, which is the point:
 * a design is hundreds of commands and most bodies are a few dozen bytes,
 * so turning every one of them into a three-message handshake would
 * triple the round trips on a link where a round trip is the expensive
 * part. Only the large ones are split.
 *
 * One consequence to carry into the relay, not solved here: the board has
 * **no inter-frame timeout**. A command abandoned partway leaves its
 * receive state machine waiting forever, and nothing short of a reset
 * clears it. A gateway that loses the link mid-command must therefore
 * still send the chunks the header declared, so the board completes its
 * receive, fails the body checksum, and answers an error. An error is
 * recoverable; a stalled state machine is not.
 *
 * Frame layout, little-endian throughout:
 *
 *      0  magic     u16   0x504C, spelling "PL" in a hex dump
 *      2  version   u8
 *      3  type      u8    MessageType
 *      4  seq       u16   wraps; matches a reply to its request
 *      6  length    u32   payload bytes
 *     10  payload   length bytes
 *    10+  checksum  u32   CRC-32 over bytes 0 .. 10+length-1
 *
 * The length is 32 bits because not everything on this link is a command.
 * Chunking bounds command traffic; a telemetry batch or a trace payload
 * is one message and can be larger, and a 16-bit field would cap those at
 * 65535 for no reason.
 *
 * Written for a freestanding target: no allocation, no exceptions, no
 * standard containers, and every buffer supplied by the caller.
 */
#pragma once

#include <stddef.h>
#include <stdint.h>

namespace papaya {
namespace link {

/** "PL", readable in a hex dump, which matters when somebody is staring
 *  at a capture wondering whose bytes these are. */
static const uint16_t kMagic = 0x504Cu;

static const uint8_t kProtocolVersion = 1u;

static const uint32_t kHeaderSize = 10u;
static const uint32_t kChecksumSize = 4u;
static const uint32_t kFrameOverhead = kHeaderSize + kChecksumSize;

/** Generous, and still a bound. A trace download is the large case; this
 *  sits well above it and well below "a corrupt length asks for a
 *  gigabyte". */
static const uint32_t kMaxPayload = 1u << 20;

/**
 * The board's own command chunk size, mirrored here on purpose.
 *
 * Bounding the link's command chunks to the same figure means a gateway
 * needs a buffer of exactly one chunk no matter how large the command is,
 * which is what makes a 32 KB host viable at all.
 *
 * It is NOT a tuning knob. It is the board's constant, and the two ends
 * must agree or a chunk arrives that cannot be forwarded whole.
 */
static const uint16_t kBoardChunkSize = 400u;

/**
 * What a decoder needs to hold to receive everything a gateway is sent.
 *
 * A gateway receives commands, chunks, subscriptions and small control
 * messages; it never receives telemetry, because telemetry is the thing
 * it sends. So the largest inbound frame is a command header plus one
 * body chunk, and a buffer of this size is enough for a relay even though
 * kMaxPayload is far larger. Anything bigger is skipped cleanly rather
 * than overflowing anything, which is the whole reason the figure is
 * stated rather than assumed.
 */
static const uint32_t kRelayFrameBufferSize = kFrameOverhead + 64u + kBoardChunkSize;

/**
 * Numbered in groups, with gaps, because these cross a version boundary
 * the moment one gateway is older than the Studio driving it.
 */
enum MessageType
{
  /* Session. */
  kHello = 0x01,
  kWelcome = 0x02,
  kAuthChallenge = 0x03,
  kAuthResponse = 0x04,

  /* Relaying a board command. */
  kCmd = 0x10,
  kCmdResult = 0x11,
  /** One further body chunk for the command already begun. */
  kCmdChunk = 0x12,

  /* A design, taken whole before any of it reaches the board. */
  kDesignBegin = 0x20,
  kDesignChunk = 0x21,
  kDesignCommit = 0x22,
  kDesignAbort = 0x23,

  /* Things a gateway does locally, never relayed. */
  kMode = 0x30,
  kReset = 0x31,

  /* Telemetry. */
  kSubscribe = 0x40,
  kUnsubscribe = 0x41,
  kTelemetry = 0x42,
  kVectorTelemetry = 0x43,

  /* Driving a running design. */
  kInput = 0x50,

  /* Diagnosis. */
  kEvent = 0x60,
  kPing = 0x70,
  kPong = 0x71,
  kStats = 0x72,
  kBye = 0x7F
};

/**
 * How a relayed command is performed on the board's wire.
 *
 * A gateway implements these six and parses no opcodes at all, which is
 * what stops it drifting away from a firmware it does not model. The far
 * end knows what it is asking for and says which shape it needs.
 */
enum TransactionShape
{
  /** Header, body chunks, then poll for the status. */
  kShapeConfig = 1,
  /** As kShapeConfig, then one further exchange for the payload the
   *  board queued behind that status. */
  kShapeConfigWithData = 2,
  /** Opcode byte, then read a known number of bytes. */
  kShapeProbeRead = 3,
  /** Opcode byte, then the values, whole. */
  kShapeInputWrite = 4,
  /** Header and body, and no poll: the board reboots before it could
   *  answer, so waiting spends the whole deadline and then reports a
   *  failure for a command that did exactly what it was asked. */
  kShapeFireAndForget = 5,
  /** One opcode byte on the wire, nothing before it, nothing after it,
   *  and no poll.
   *
   *  The board's wire carries a handful of exchanges that are a single
   *  byte, and a cable sends them as one byte because a cable can. Every
   *  other shape puts a header on the wire first, and for these that is
   *  not merely wasteful, it is wrong: the board reads byte zero of a
   *  bare header as an opcode, and byte zero is 0x00, which is the
   *  input-write opcode. A mode change sent as a config transaction
   *  therefore did not fail, it made the board expect input values.
   *
   *  The opcode travels in the header's read/write field, where the
   *  board's own protocol puts it and where kShapeProbeRead already
   *  reads it from, so this costs nothing on the wire beyond the shape
   *  value itself. */
  kShapeOpcodeOnly = 6
};

/**
 * What became of a relayed command, as distinct from what the board
 * thought of it.
 *
 * The board's own status byte travels alongside untouched. These say
 * whether the conversation happened at all, which is a gateway's
 * business; judging an error status is the far end's, because it is the
 * one that knows what it asked for.
 */
enum CommandOutcome
{
  /** The board answered. Its status may still be an error. */
  kOutcomeAnswered = 0,
  /** The board never answered within the response deadline. */
  kOutcomeNoAnswer = 1,
  /** Refused before anything reached the wire. */
  kOutcomeRefused = 2,
  /** The link died mid-command; the remainder was flushed so the board's
   *  receive state machine could finish. */
  kOutcomeAbandoned = 3
};

/**
 * CRC-32, zlib polynomial 0xEDB88320 reflected, a byte at a time.
 *
 * The same value Python's zlib.crc32 produces and the same one the
 * board's own protocol uses, so a host already carrying one does not gain
 * a second definition of "correct". Computed bit-serially rather than
 * from a table: a table would be faster and would cost 1 KB of program
 * memory on a target that may have little to spare, and this runs once
 * per frame on a link whose round trip dwarfs it.
 */
uint32_t crc32(const uint8_t *data, uint32_t length);

/** Running state for a checksum computed over pieces that are never in
 *  one buffer together. See encodeFrameHeader(). */
uint32_t crc32Begin(void);
uint32_t crc32Update(uint32_t state, const uint8_t *data, uint32_t length);
uint32_t crc32Finish(uint32_t state);

/* ==================================================================== */
/* Frames                                                               */
/* ==================================================================== */

/** One decoded frame. @c payload points into the decoder's own buffer and
 *  stays valid only until the next call that feeds it. */
struct Frame
{
  uint8_t type;
  uint8_t version;
  uint16_t seq;
  const uint8_t *payload;
  uint32_t payloadLength;
};

/**
 * Serialise one frame into @p out, checksum included.
 *
 * @return bytes written, or 0 if the buffer is too small or the payload
 *         exceeds kMaxPayload. Never writes past @p capacity.
 */
uint32_t encodeFrame(uint8_t *out, uint32_t capacity, uint8_t type,
                     uint16_t seq, const uint8_t *payload,
                     uint32_t payloadLength);

/**
 * Just the header, for a frame sent in pieces.
 *
 * A telemetry batch is a payload header followed by samples that are
 * already sitting in a buffer, and a command result is a header followed
 * by a status and a data payload sitting in another. Copying those into
 * one contiguous buffer to send them would double the memory a gateway
 * needs for the largest thing it carries, on the hosts least able to
 * afford it. So the pieces are sent where they lie and the checksum is
 * accumulated across them:
 *
 * @code
 * uint8_t head[papaya::link::kHeaderSize];
 * encodeFrameHeader(head, sizeof(head), type, seq, total);
 * uint32_t crc = crc32Update(crc32Begin(), head, kHeaderSize);
 * write(head, kHeaderSize);
 * for (each piece) {
 *   crc = crc32Update(crc, piece, pieceLength);
 *   write(piece, pieceLength);
 * }
 * uint8_t tail[4];
 * encodeFrameChecksum(tail, crc32Finish(crc));
 * write(tail, 4);
 * @endcode
 *
 * @param payloadLength the TOTAL of every piece to follow. A header that
 *        disagrees with what is sent desynchronises the far end for the
 *        rest of the session, so it is the caller's one duty here.
 * @return bytes written, or 0.
 */
uint32_t encodeFrameHeader(uint8_t *out, uint32_t capacity, uint8_t type,
                           uint16_t seq, uint32_t payloadLength);

/** The four checksum bytes that close a frame sent in pieces. */
uint32_t encodeFrameChecksum(uint8_t *out, uint32_t capacity,
                             uint32_t checksum);

/**
 * Turns a byte stream back into frames.
 *
 * Incremental because the transports are: TCP delivers whatever it
 * delivers, and a serial link to a radio coprocessor delivers less than
 * that. Feed it arbitrary slices and it yields whole frames.
 *
 * On corruption it resynchronises by hunting for the next magic rather
 * than giving up on the connection. A relay that dropped the link every
 * time a frame was mangled would turn a recoverable glitch into a
 * reconnect, and a reconnect costs the board's session.
 *
 * A frame whose declared length will not fit the buffer is SKIPPED, byte
 * by byte as it arrives, rather than truncated or accumulated. That
 * matters on a host that cannot hold kMaxPayload: without it a corrupt
 * length is either an overflow or a decoder that never resynchronises.
 */
class FrameDecoder
{
public:
  /** @param buffer   caller-owned, at least kFrameOverhead + 1 bytes.
   *  @param capacity its size. kRelayFrameBufferSize is the figure a
   *                  relay needs; see the note on that constant. */
  FrameDecoder(uint8_t *buffer, uint32_t capacity);

  /** Reset to hunting for a frame boundary. Counters are kept: they
   *  describe the link, not the current message. */
  void reset(void);

  /**
   * Consume as much of @p data as advances the decoder by one step.
   *
   * @param used receives how many bytes were taken. Always at least one
   *             when @p length is non-zero, so a caller's loop always
   *             terminates.
   * @param out  filled when the return value is true.
   * @return true when a whole, checksummed frame became available.
   *
   * Usage:
   * @code
   * uint32_t offset = 0;
   * while (offset < n) {
   *   uint32_t used = 0;
   *   papaya::link::Frame frame;
   *   if (decoder.consume(bytes + offset, n - offset, used, frame)) {
   *     handle(frame);
   *   }
   *   offset += used;
   * }
   * @endcode
   */
  bool consume(const uint8_t *data, uint32_t length, uint32_t &used,
               Frame &out);

  /** Frames discarded to regain alignment. A rising count is the symptom
   *  worth surfacing; a single one is a glitch. */
  uint32_t resyncs(void) const { return resyncs_; }

  /** Intact-looking frames too large for this buffer. Distinct from a
   *  resync on purpose: this one means the peer is sending something
   *  this host was never sized to receive, which is a different
   *  diagnosis from a damaged stream. */
  uint32_t oversized(void) const { return oversized_; }

  /** Frames whose version this build does not speak. They are dropped
   *  rather than guessed at; a caller that cares can say so. */
  uint32_t versionMismatches(void) const { return versionMismatches_; }

private:
  enum State { kSync, kHeader, kBody, kDiscard };

  uint8_t *buffer_;
  uint32_t capacity_;
  uint32_t held_;
  uint32_t want_;
  uint32_t discard_;
  State state_;
  uint32_t resyncs_;
  uint32_t oversized_;
  uint32_t versionMismatches_;
};

/* ==================================================================== */
/* Payload codecs                                                       */
/* ==================================================================== */

/** A command's header and its first body chunk, as carried by kCmd. */
struct Command
{
  uint8_t shape;
  const uint8_t *header;
  uint16_t headerLength;
  const uint8_t *firstChunk;
  uint32_t firstChunkLength;
  uint32_t totalBodyLength;
  uint32_t expectedData;
};

/**
 * Payload for kCmd.
 *
 * Carries the shape and already-formed bytes. It does NOT carry an
 * opcode, a block, or anything about what the command means: a gateway is
 * not entitled to an opinion, and giving it one is how a relay starts
 * having to keep up with firmware.
 *
 * @p expectedData is how many bytes come back after the status, which
 * only the far end can know because nothing on the board's wire announces
 * it.
 *
 * @return bytes written, or 0 when the arguments are unusable: a first
 *         chunk above kBoardChunkSize, a total body smaller than the
 *         chunk it starts with, a shape that returns data with no length
 *         stated, or a length stated for a shape that returns none.
 */
uint32_t encodeCommand(uint8_t *out, uint32_t capacity, uint8_t shape,
                       const uint8_t *header, uint16_t headerLength,
                       const uint8_t *firstChunk, uint32_t firstChunkLength,
                       uint32_t totalBodyLength, uint32_t expectedData);

/** Inverse of encodeCommand(). Pointers alias @p payload. */
bool decodeCommand(const uint8_t *payload, uint32_t length, Command &out);

/**
 * Payload for kCmdChunk: one more body chunk.
 *
 * Indexed rather than merely ordered. The transports below this are
 * ordered, but a relay that silently forwarded a chunk out of place would
 * hand the board a body whose checksum fails somewhere far from the
 * cause, and an index makes that a refusal instead.
 */
uint32_t encodeCommandChunk(uint8_t *out, uint32_t capacity, uint16_t index,
                            const uint8_t *chunk, uint32_t chunkLength);

/** Inverse of encodeCommandChunk(). @p chunk aliases @p payload. */
bool decodeCommandChunk(const uint8_t *payload, uint32_t length,
                        uint16_t &index, const uint8_t *&chunk,
                        uint32_t &chunkLength);

/** What a relayed command produced. Pointers alias the payload. */
struct CommandResult
{
  uint8_t outcome;
  const uint8_t *status;
  uint16_t statusLength;
  const uint8_t *data;
  uint32_t dataLength;
};

/**
 * Payload for kCmdResult.
 *
 * A status frame, a data payload, either or neither: a config command
 * answers with a status, a probe read answers with samples and no status
 * at all, and a refusal answers with nothing. Both lengths are stated so
 * the reader never has to infer which case it is holding. An earlier
 * version assumed a status was always present and always seven bytes,
 * which is true of a config command and false of a probe read, so a
 * fixed-size assumption ate the first seven bytes of the samples.
 */
uint32_t encodeCommandResult(uint8_t *out, uint32_t capacity, uint8_t outcome,
                             const uint8_t *status, uint16_t statusLength,
                             const uint8_t *data, uint32_t dataLength);

/**
 * Just the eight fixed bytes, for a result sent in pieces.
 *
 * The status and the data are already somewhere when a gateway answers,
 * and joining them to this would need a buffer as large as the largest
 * reply the host carries. It declares the lengths that will follow; see
 * encodeFrameHeader() for the same idea one layer up.
 */
uint32_t encodeCommandResultHeader(uint8_t *out, uint32_t capacity,
                                   uint8_t outcome, uint16_t statusLength,
                                   uint32_t dataLength);

/** Inverse of encodeCommandResult(). */
bool decodeCommandResult(const uint8_t *payload, uint32_t length,
                         CommandResult &out);

/** A standing instruction to poll the board's probes. */
struct Subscription
{
  uint16_t probeCount;
  uint16_t samplesPerBatch;
  uint16_t vectorCount;
  uint16_t intervalMs;
  uint32_t scalarBytes;
  uint32_t vectorBytes;
};

/**
 * Payload for kSubscribe: what to poll, and how often.
 *
 * Every field exists because the board's wire does not announce it. A
 * probe read is an opcode and then a payload, with no length, no count
 * and no boundary anywhere in the exchange, and the board's own read
 * sizes itself from probe objects the running PROGRAM constructed, which
 * a relay never does. A gateway not told these figures asks for nothing
 * and gets nothing back.
 *
 * @p samplesPerBatch is carried rather than derived because the reader
 * deinterleaves with it: the payload is probe-major, so getting it wrong
 * does not fail, it silently puts every probe's samples under the next
 * probe's name.
 *
 * @return 0 when the subscription asks for no bytes at all, which would
 *         poll the board forever and return nothing, or when the interval
 *         is zero, which is a busy loop on the wire the commands share.
 */
uint32_t encodeSubscribe(uint8_t *out, uint32_t capacity,
                         const Subscription &subscription);

/** Inverse of encodeSubscribe(), refusing the same two cases. */
bool decodeSubscribe(const uint8_t *payload, uint32_t length,
                     Subscription &out);

/** One batch of samples, as carried by kTelemetry and kVectorTelemetry. */
struct TelemetryBatch
{
  uint32_t batchSeq;
  uint64_t timestampUs;
  uint16_t probeCount;
  uint16_t samplesPerProbe;
  const uint8_t *samples;
  uint32_t samplesLength;
};

/**
 * Payload for kTelemetry.
 *
 * @c batchSeq is the whole reason this is not raw samples. The board's
 * monitoring over this wire carries no sequence, no checksum and no gap
 * marker, so a host that misses a batch cannot tell. A gateway stamps
 * one, and a gap in it is the only honest signal that something was
 * dropped.
 *
 * The number counts scheduled polls rather than delivered batches. A slot
 * that produced nothing still spends its number, which is what puts the
 * gap there: numbering per delivered batch would make a stream with a
 * hole in it look continuous.
 */
uint32_t encodeTelemetry(uint8_t *out, uint32_t capacity, uint32_t batchSeq,
                         uint64_t timestampUs, uint16_t probeCount,
                         uint16_t samplesPerProbe, const uint8_t *samples,
                         uint32_t samplesLength);

/** Inverse of encodeTelemetry(). @c samples aliases @p payload. */
bool decodeTelemetry(const uint8_t *payload, uint32_t length,
                     TelemetryBatch &out);

/**
 * Payload for kWelcome: what this gateway can carry, said unprompted.
 *
 * WHY THE GATEWAY VOLUNTEERS IT. The largest telemetry batch a gateway
 * can hold is a fact about the gateway, and until now the host guessed
 * it: one number, 1200 bytes, the single-write limit of the radio on the
 * ST IoT nodes, applied to every gateway including ones with no such
 * limit and thirteen times the memory. On those the guess cost a factor
 * of seven in delivered samples, because the batch depth is sized to fit
 * it and the depth is what a slow poll is multiplied by.
 *
 * UNSOLICITED, at session start, rather than answered on request. A host
 * that has to ask spends a round trip at connect for a number the
 * gateway already knows, and every connect pays it. The precedent is the
 * kEvent frame the engine already sends unasked.
 *
 * BOTH DIRECTIONS DEGRADE TO TODAY'S BEHAVIOUR, which is the whole
 * reason this is a new message rather than a changed one. A gateway
 * flashed before this exists says nothing, and a host that hears nothing
 * keeps the 1200 it uses now. A host older than this ignores a frame
 * type it does not know, which the protocol has always required of both
 * ends. So an old gateway with a new Studio, and a new gateway with an
 * old Studio, both behave exactly as they do today rather than failing.
 *
 * @param maxBatchBytes  the largest scalar or vector batch a
 *        subscription may ask for, in bytes. It is the size of the
 *        buffer a batch is read into, so it is the same number the
 *        gateway refuses a subscription against; announcing anything
 *        larger would announce a batch it would then refuse.
 *
 * A LONGER PAYLOAD IS LAWFUL and must be ignored rather than rejected:
 * that is what lets a later version add a field without this one
 * treating the frame as damaged.
 */
uint32_t encodeWelcome(uint8_t *out, uint32_t capacity,
                       uint32_t maxBatchBytes);

/** Inverse of encodeWelcome(). False when the payload is too short. */
bool decodeWelcome(const uint8_t *payload, uint32_t length,
                   uint32_t &maxBatchBytes);

}  /* namespace link */
}  /* namespace papaya */
