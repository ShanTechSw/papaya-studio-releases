var dir_441f1b18a7bacad090d9bcce14e8b596 =
[
    [ "Arduino.h", "host__arduino__compat_2include_2_arduino_8h.html", "host__arduino__compat_2include_2_arduino_8h" ],
    [ "SPI.h", "host__arduino__compat_2include_2_s_p_i_8h.html", "host__arduino__compat_2include_2_s_p_i_8h" ]
];