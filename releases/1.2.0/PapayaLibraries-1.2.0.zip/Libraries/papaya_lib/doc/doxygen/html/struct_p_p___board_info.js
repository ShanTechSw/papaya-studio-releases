var struct_p_p___board_info =
[
    [ "partNumber", "struct_p_p___board_info.html#ab766821a6ea81b1b525b320156eabce7", null ],
    [ "uniqueId", "struct_p_p___board_info.html#a3a0ecc98f4372ecf0bbefa516315ccb0", null ]
];