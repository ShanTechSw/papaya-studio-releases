/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:24:44
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      ECG / accel   a synthetic electrocardiogram in volts at 72 beats per minute:
 *                    a 1 V R spike with gaussian P, Q, S and T waves around it,
 *                    plus 0.06 V of white noise for the denoiser to remove. The
 *                    denoise_sigma probe should settle near that 0.06 V noise
 *                    level, and the reconstructed trace should show the beats with
 *                    the fuzz gone
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe shrunk_coeffs;
VectorProbe reconstructed;
probe denoise_sigma;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  analogIn ECG___accel = analogIn(AIN1, 1.0, 0.0);
  expander fan_2 = expander(2);
  dwt DWT_db4_L5 = dwt(256, DB4, 5, 2000.0);
  dwt DWT_denoise_path = dwt(256, DB4, 5, 2000.0);
  idwt Reconstruct = idwt(DWT_db4_L5);
  dwt_denoise Denoise_soft = dwt_denoise(DWT_denoise_path, PP_THRESH_SOFT, 1.0f);
  shrunk_coeffs = VectorProbe("shrunk_coeffs");
  reconstructed = VectorProbe("reconstructed");
  denoise_sigma = probe("denoise_sigma");

  /* Connect Blocks */
  ECG___accel > fan_2;
  fan_2.out(0) > DWT_db4_L5;
  fan_2.out(1) > DWT_denoise_path;
  DWT_db4_L5 > Reconstruct;
  DWT_denoise_path > Denoise_soft;
  DWT_denoise_path >> shrunk_coeffs;
  Reconstruct >> reconstructed;
  Denoise_soft > denoise_sigma;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    shrunk_coeffs.show();
    reconstructed.show();
    denoise_sigma.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}