var struct_p_p___s_t_r_config =
[
    [ "desired_poles", "struct_p_p___s_t_r_config.html#a11f0af3cbdd22bb7c47ad9e7f45b3c08", null ],
    [ "lambda", "struct_p_p___s_t_r_config.html#a27038584d94b2c4996a810e0707d6fc2", null ],
    [ "na", "struct_p_p___s_t_r_config.html#a66449e72545e4145e904755dbd49a7b8", null ],
    [ "nb", "struct_p_p___s_t_r_config.html#a329a93faba7d5b9b5a87b7fe6bf6fdeb", null ],
    [ "P_init", "struct_p_p___s_t_r_config.html#aaa915f629f07587ee50b7955a9489604", null ]
];