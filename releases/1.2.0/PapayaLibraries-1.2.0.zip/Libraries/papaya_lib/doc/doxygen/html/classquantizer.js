var classquantizer =
[
    [ "quantizer", "classquantizer.html#a1ec2311cfe52c033d7ae816d47a75193", null ]
];