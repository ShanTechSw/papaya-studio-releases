var host__arduino__compat_2include_2_s_p_i_8h =
[
    [ "SPISettings", "class_s_p_i_settings.html", "class_s_p_i_settings" ],
    [ "PapayaSpiBackend", "class_papaya_spi_backend.html", "class_papaya_spi_backend" ],
    [ "SPIClass", "class_s_p_i_class.html", "class_s_p_i_class" ],
    [ "SPI_HAS_TRANSACTION", "host__arduino__compat_2include_2_s_p_i_8h.html#a54ccd466ea250550206f8766bb874e77", null ],
    [ "LSBFIRST", "host__arduino__compat_2include_2_s_p_i_8h.html#a53c7c9225f8e0f100c249bd7b5cd70b7", null ],
    [ "MSBFIRST", "host__arduino__compat_2include_2_s_p_i_8h.html#a6d4329b653fb6fe6388571ab48465244", null ],
    [ "SPI", "host__arduino__compat_2include_2_s_p_i_8h.html#a56953eb3affc2a9f56e1680bbc537bf7", null ],
    [ "SPI_MODE0", "host__arduino__compat_2include_2_s_p_i_8h.html#af6d9d4aa8ce968611b8f89876648f7cb", null ],
    [ "SPI_MODE1", "host__arduino__compat_2include_2_s_p_i_8h.html#a218d6549002dfadd0a5178e64e400ffa", null ],
    [ "SPI_MODE2", "host__arduino__compat_2include_2_s_p_i_8h.html#a59e749b2b279d68415c264ed3cb02677", null ],
    [ "SPI_MODE3", "host__arduino__compat_2include_2_s_p_i_8h.html#a020d42b777d13f7f64669f0ce5853ba1", null ]
];