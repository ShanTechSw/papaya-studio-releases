var namespacepp__ao__detail =
[
    [ "Frame", "structpp__ao__detail_1_1_frame.html", "structpp__ao__detail_1_1_frame" ],
    [ "cadence_periodic", "namespacepp__ao__detail.html#a2d1008ceb7f02e77ba3d8a50b7ecf6ed", null ],
    [ "AO_CFG_PREDEF_LEN", "namespacepp__ao__detail.html#a54b023fff9632d762e5f0035a4b384d9", null ],
    [ "AO_DAC_FS_MAX", "namespacepp__ao__detail.html#aeecc1132da289f1ab55dcd38cdb8f7e3", null ],
    [ "AO_DEFAULT_LUT", "namespacepp__ao__detail.html#ac357f7274d81db0ffb80510eb0feea60", null ],
    [ "AO_MAX_SAMPLES", "namespacepp__ao__detail.html#a9ad8a22043971b2487df2de3ff885564", null ],
    [ "AO_MIN_LUT", "namespacepp__ao__detail.html#af2d6ac70be798cdec8df985bf71b318f", null ]
];