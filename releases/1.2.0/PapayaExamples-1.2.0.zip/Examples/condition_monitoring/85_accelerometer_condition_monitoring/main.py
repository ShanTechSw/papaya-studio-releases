"""Condition monitoring: the board measures, this script decides.

Run this beside example 85. It builds the diagram on the board, learns what
the machine looks like when it is healthy, then watches the feature bank and
says, in words, what it thinks is happening and why.

    python main.py

The design publishes twenty-four features. This script reads them, and the
whole of its judgement is in two functions near the top, learn_baseline() and
classify(). Neither of them touches the board, so a class can change a rule,
re-run, and see the verdict change without rebuilding anything.

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  severity        how far the overall vibration level has moved from the
                  machine's own healthy level. Ratios, not absolute limits:
                  ISO 10816 gives absolute bands but they are in millimetres
                  per second of VELOCITY, and this design measures
                  acceleration, so an absolute band copied from that standard
                  would be wrong. A machine's own quiet state is the only
                  honest reference an acceleration bench has.

  impulsiveness   crest factor and kurtosis together. A rolling-element
                  defect hits once per ball pass and rings the structure, so
                  the peak rises long before the RMS does. This is the pair
                  that catches a bearing early.

  spectral shift  Hjorth mobility, which is a cheap estimate of the mean
                  frequency of the signal. Energy moving up in frequency
                  means the excitation is no longer the shaft line.

  sensor health   the total specific force, which must stay at 1 g on a
                  machine that is bolted down. If it does not, the sensor has
                  moved and every other number is about something else.

The rules are deliberately written as thresholds on RATIOS to the baseline
rather than on raw values, so they carry over to a different machine, a
different mounting and a different sensitivity without being retuned.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LEARN_SECONDS = 12.0        # how long to watch before forming an opinion
WATCH_SECONDS = 40.0        # how long to monitor afterwards
DECIDE_EVERY = 0.5          # seconds between verdicts

# How many feature vectors a baseline is allowed to be built from. It is a
# COUNT and not a duration because the median of the quietest half needs
# something to be a half of; four readings cannot describe a machine. The
# board emits one vector per analysis window, so the seconds above are how
# long to wait at minimum and this is what actually has to arrive.
BASELINE_ROWS = 8
SWEEP_AXES = True           # visit y and z at the end, then come back to x

# Set this to False on a real machine. The design carries two reference
# traces that are only meaningful while the accelerometer's simulated model
# is active; with it on, the script marks each verdict right or wrong and
# prints a score at the end.
SCORE_AGAINST_REFERENCE = True
REFERENCE_HEALTHY_RMS = 0.02258     # what rms_ref_sim holds on the healthy half
REFERENCE_FAULTED_RMS = 0.05823     # and on the faulted half

# The feature vector, in the order the Feature Stack publishes it.
# Sixteen of these are 200-sample sliding windows. p95_since_start is NOT:
# it is a streaming estimate over every sample since the design started, and
# it is here as a long-run reference rather than as a fault indicator.
FEATURES = (
    "rms", "peak", "peak_to_peak", "crest", "std_dev",
    "skew", "kurtosis", "hjorth_activity", "hjorth_mobility",
    "hjorth_complexity", "zero_crossings", "p95_since_start", "clearance",
    "standing_level", "rectified_mean", "shape_factor", "impulse_factor",
)
# The spectral vector, likewise. Nothing below decides on these, but they are
# read and reported, and they are the obvious place to extend the rules:
# flatness near 1 is broadband noise (looseness, cavitation, a failing lubricant
# film) while flatness near 0 is a few strong lines (unbalance, misalignment).
# Centroid, spread and rolloff are ARRAY POSITIONS, not hertz.
SPECTRAL = ("centroid", "spread", "skew", "kurtosis", "flatness",
            "rolloff", "flux")

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

# Severity bands, as a multiple of the machine's own healthy RMS.
SEVERITY_ALERT = 1.6
SEVERITY_ALARM = 2.5
SEVERITY_TRIP = 5.0

# Impulsiveness. A clean sine reads 1.41 for crest and -1.5 for excess
# kurtosis; broadband noise reads about 3.5 and 0. A defect pushes both up.
CREST_IMPULSIVE = 3.0
KURTOSIS_IMPULSIVE = 0.5

# Clearance factor reacts to a rolling-element defect earlier than crest
# does, so it gets its own, looser trigger: it is allowed to raise a warning
# on its own before crest and kurtosis agree.
CLEARANCE_EARLY = 1.6      # multiple of baseline

# Frequency content. Mobility is normalised by the sampling rate, so a
# ratio is the meaningful quantity, not the value.
MOBILITY_SHIFT = 1.8

# The sensor itself.
GRAVITY_TOLERANCE = 0.08    # g away from 1.0 before the mounting is suspect


def learn_baseline(rows):
    """What this machine looks like when it is behaving.

    *rows* is a list of feature dictionaries. The baseline is the median of
    the quietest half of them, chosen by RMS.

    Taking the median of EVERYTHING would be wrong on a machine that spends
    part of the learning window in trouble, and taking the minimum would be
    wrong on any machine at all, because the minimum of a noisy sample is a
    measure of the noise. The quiet half is the compromise that survives
    both: if the machine was healthy throughout, the quiet half is simply a
    slightly conservative healthy state.
    """
    if len(rows) < 8:
        raise ValueError(f"only {len(rows)} samples: not enough to learn from")
    cut = statistics.median(r["rms"] for r in rows)
    quiet = [r for r in rows if r["rms"] <= cut] or rows
    return {k: statistics.median(r[k] for r in quiet)
            for k in _numeric_keys(quiet)}


def _numeric_keys(rows):
    """Keys every row has and that every row holds a number in.

    reference_rms is None when the reference is switched off, and the
    spectral keys are absent on any reading whose second vector fetch did
    not arrive. Either one turns a median into a TypeError or a KeyError,
    so the shared numeric keys are the only ones summarised.
    """
    keys = set(rows[0])
    for r in rows[1:]:
        keys &= set(r)
    return sorted(k for k in keys
                  if all(isinstance(r[k], (int, float)) for r in rows))


def _ratio(value, base, floor=1e-9):
    return value / base if abs(base) > floor else float("inf")


def classify(row, baseline):
    """One verdict from one (smoothed) feature reading.

    Returns (state, headline, reasons). *state* is one of ok, watch, alert,
    alarm or fault, ordered by how much it should worry you.
    """
    reasons = []

    # The sensor first. Everything else is a statement about the machine,
    # and it is only about the machine if the sensor is still on it.
    gravity_error = abs(row["total_g"] - 1.0)
    if gravity_error > GRAVITY_TOLERANCE:
        return ("fault",
                "the sensor is not where it was",
                [f"total specific force {row['total_g']:.3f} g, which is "
                 f"{gravity_error:.3f} g away from 1. Either the machine is "
                 f"not level any more or the sensor has come loose. Nothing "
                 f"below this line means anything until it is fixed."])

    rms_ratio = _ratio(row["rms"], baseline["rms"])
    crest = row["crest"]
    kurt = row["kurtosis"]
    mobility_ratio = _ratio(row["hjorth_mobility"], baseline["hjorth_mobility"])

    clearance_ratio = _ratio(row.get("clearance", 0.0),
                             baseline.get("clearance", 0.0))
    impulsive = crest >= CREST_IMPULSIVE and kurt >= KURTOSIS_IMPULSIVE
    early = clearance_ratio >= CLEARANCE_EARLY
    shifted_up = mobility_ratio >= MOBILITY_SHIFT

    if rms_ratio >= SEVERITY_TRIP:
        state = "alarm"
    elif rms_ratio >= SEVERITY_ALARM:
        state = "alarm"
    elif rms_ratio >= SEVERITY_ALERT:
        state = "alert"
    elif impulsive or shifted_up or early:
        state = "watch"
    else:
        state = "ok"

    reasons.append(f"level {rms_ratio:.2f}x baseline "
                   f"({row['rms']:.4f} g against {baseline['rms']:.4f} g)")
    if impulsive:
        reasons.append(f"impulsive: crest {crest:.2f} and excess kurtosis "
                       f"{kurt:+.2f}, both above a smooth signal")
    else:
        reasons.append(f"not impulsive: crest {crest:.2f}, excess kurtosis "
                       f"{kurt:+.2f}")
    if early:
        reasons.append(f"clearance factor {clearance_ratio:.2f}x baseline "
                       f"({row.get('clearance', 0.0):.2f}), the earliest of "
                       f"the four dimensionless indicators to move")
    if shifted_up:
        reasons.append(f"energy has moved up in frequency: mobility "
                       f"{mobility_ratio:.2f}x baseline")

    # A drift check that needs no threshold: the windowed peak against the
    # peak the machine has shown since the design started. Above 1 means
    # this window is worse than the machine's own history.
    long_run = _ratio(row["peak"], row.get("p95_since_start", 0.0))
    if long_run >= 1.5:
        reasons.append(f"this window's peak is {long_run:.2f}x the 95th "
                       f"percentile of everything seen since start, so it is "
                       f"not just noise in the baseline")

    # The named diagnosis, in the order a maintenance engineer would rule
    # them out. Impulsiveness is checked before level because a bearing
    # announces itself in the peak while the RMS is still almost normal.
    if impulsive and shifted_up:
        headline = ("rolling-element defect: repeated impacts exciting a "
                    "structural resonance")
    elif impulsive:
        headline = "impacts present: bearing, gear tooth, or something loose"
    elif early and state == "watch":
        headline = ("an early impulsive signature: clearance factor has "
                    "moved before crest and kurtosis agree")
    elif rms_ratio >= SEVERITY_ALERT and not shifted_up:
        headline = ("more vibration at the same frequencies: unbalance, "
                    "misalignment or a changed load")
    elif shifted_up:
        headline = "broadband or high-frequency energy without impacts"
    elif state == "ok":
        headline = "nothing to report"
    else:
        headline = "changed, but not in a pattern this script has a name for"

    return state, headline, reasons


def score_line(state, reference_rms):
    """Was the verdict right? Only meaningful against the simulated model."""
    if reference_rms is None:
        return None
    healthy = abs(reference_rms - REFERENCE_HEALTHY_RMS) < \
        abs(reference_rms - REFERENCE_FAULTED_RMS)
    called_healthy = state in ("ok", "watch")
    return healthy == called_healthy, healthy


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 85_accelerometer_condition_monitoring.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    """One reading: the whole feature vector plus the scalars beside it."""
    if not d.papaya0.readProbesLatest():
        return None
    raw = d.papaya0.readVectProbeLive(d.features, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    values = struct.unpack(f"<{len(FEATURES)}f", raw[:4 * len(FEATURES)])
    row = dict(zip(FEATURES, values))
    spec = d.papaya0.readVectProbeLive(d.spectral, len(SPECTRAL))
    if spec is not None and len(spec) >= 4 * len(SPECTRAL):
        row.update(zip(
            ("spectral_" + k for k in SPECTRAL),
            struct.unpack(f"<{len(SPECTRAL)}f", spec[:4 * len(SPECTRAL)])))
    row["total_g"] = d.a_total_g.getVal()
    row["reference_rms"] = d.rms_ref_sim.getVal() \
        if SCORE_AGAINST_REFERENCE else None
    return row


def smooth(rows):
    """The median of a short burst of readings.

    Kurtosis needs this. Its estimator restarts every window, so a single
    reading of it is taken at an arbitrary point in that restart and can be
    a long way from the settled value.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in _numeric_keys(rows)}
    # Kept as it arrived, not summarised: it is a label, not a measurement.
    out["reference_rms"] = rows[-1].get("reference_rms")
    return out


def collect(d, seconds, into=None, min_rows=0):
    """Readings for *seconds*, and at least *min_rows* of them.

    A FIXED WINDOW IS NOT A ROW COUNT. Each row here is a whole feature
    vector, and the board produces one only when its analysis window is
    full, so the number that arrives in a given number of seconds is set
    by the design and not by this script. Asking for twelve seconds and
    then requiring eight rows is a guess about the board's cadence, and
    when the guess is wrong the run ends with "the board returned almost
    nothing", which reads as a broken board rather than a window that
    was too short.

    So the wall-clock time is a MINIMUM, and *min_rows* is the real
    requirement: keep reading past the window until enough rows exist.
    ``max(seconds * 4, seconds + 20)`` bounds the wait so a board that
    has genuinely stopped producing still returns instead of hanging,
    and the caller reports what it actually got.
    """
    rows = [] if into is None else into
    started = time.monotonic()
    deadline = started + seconds
    hard_stop = started + max(seconds * 4.0, seconds + 20.0)
    while True:
        row = read_row(d)
        if row is not None:
            rows.append(row)
        now = time.monotonic()
        if now >= hard_stop:
            return rows
        if now >= deadline and len(rows) >= min_rows:
            return rows


def show_axis(d, sel_xy, sel_z, name):
    d.papaya0.setInputsLive({d.sel_xy: sel_xy, d.sel_z: sel_z})
    time.sleep(0.4)                     # let every 200-sample window refill
    rows = collect(d, 1.5)
    if not rows:
        print(f"  {name}: no data")
        return
    row = smooth(rows)
    print(f"  {name}: rms {row['rms']:.4f} g   peak {row['peak']:.4f} g   "
          f"crest {row['crest']:.2f}   kurtosis {row['kurtosis']:+.2f}   "
          f"standing level {row['standing_level']:+.4f} g")


def main():
    print("PAPAYA condition monitor")
    print("=" * 72)
    d = load_design()

    print(f"\nLearning this machine's healthy state for "
          f"{LEARN_SECONDS:.0f} s. Leave it running normally.")
    learning = collect(d, LEARN_SECONDS, min_rows=BASELINE_ROWS)
    if len(learning) < BASELINE_ROWS:
        raise SystemExit(
            f"Only {len(learning)} feature vectors arrived, and a baseline "
            f"needs {BASELINE_ROWS}. The board produces one vector per "
            f"analysis window, so either it is not sampling or the design's "
            f"window is long enough that this needs a longer wait.")
    baseline = learn_baseline(learning)
    print(f"  {len(learning)} readings")
    print(f"  baseline rms      {baseline['rms']:.4f} g")
    print(f"  baseline peak     {baseline['peak']:.4f} g")
    print(f"  baseline crest    {baseline['crest']:.2f}")
    print(f"  baseline kurtosis {baseline['kurtosis']:+.2f}")
    print(f"  baseline mobility {baseline['hjorth_mobility']:.3f}")
    print(f"\nAlert at {SEVERITY_ALERT:.1f}x that level, alarm at "
          f"{SEVERITY_ALARM:.1f}x. Impacts are called at crest "
          f"{CREST_IMPULSIVE:.1f} with excess kurtosis "
          f"{KURTOSIS_IMPULSIVE:+.1f}.")

    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)
    started = time.monotonic()
    last_state = None
    last_row = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        last_row = row
        state, headline, reasons = classify(row, baseline)
        tally[state] = tally.get(state, 0) + 1

        scored = score_line(state, row.get("reference_rms"))
        if scored is not None:
            ok, truly_healthy = scored
            right += ok
            wrong += not ok

        # Print every change of mind, and one line a second otherwise, so a
        # long healthy run does not scroll the interesting part away.
        if state != last_state:
            t = time.monotonic() - started
            print(f"\n[{t:6.1f} s]  {state.upper():5s}  {headline}")
            for r in reasons:
                print(f"            {r}")
            if scored is not None:
                truth = "healthy" if scored[1] else "faulted"
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"            {mark} the simulated record, which is "
                      f"{truth} right now")
            last_state = state

    print("\n" + "-" * 72)
    print("Summary")
    for state in ("ok", "watch", "alert", "alarm", "fault"):
        if state in tally:
            print(f"  {state:6s} {tally[state]:4d} decisions")
    if right + wrong:
        print(f"  agreed with the simulated record on {right} of "
              f"{right + wrong} decisions "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "the reference traces keep playing whatever the sensor does.")
    if last_row is not None and "spectral_flatness" in last_row:
        print(f"\n  spectral flatness at the end of the run: "
              f"{last_row['spectral_flatness']:.4f}")
        print("  nothing above decided on it. Near 1 is broadband noise, "
              "near 0 is a few strong lines, and it is the obvious next rule "
              "to add: looseness and cavitation raise it, unbalance does not.")

    if SWEEP_AXES:
        print("\nThe same bearing, measured on each axis in turn:")
        show_axis(d, 1.0, 1.0, "x")
        show_axis(d, -1.0, 1.0, "y")
        show_axis(d, 1.0, -1.0, "z")
        show_axis(d, 1.0, 1.0, "x (back)")

    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
