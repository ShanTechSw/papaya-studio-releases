var classcosine_func =
[
    [ "cosineFunc", "classcosine_func.html#a6e8de9e4dad0d00a317614c6b6ec17ee", null ]
];