"""Choosing Between Signals: read the probes and print them once a second.

Switch, Mux and Demux, and which port the control goes on.

Every 14 seconds it also writes a new value to select, 0 picks the first
input, 1 picks the second, so there is something to watch.

Press Ctrl+C to stop.

Everything below is yours to change. The lists at the top are the
obvious place to start.
"""
import time

import papaya_design

# The probes this design carries.
PROBES = ['switched', 'muxed', 'routed', 'Route_tap']

# The input this design lets your program write, and the values
# to move it through.
INPUT = 'select'
VALUES = [0.0, 1.0]
CHANGE_EVERY = 14.0    # seconds
PRINT_EVERY = 1.0       # seconds

# Build the diagram on the board and start it sampling. Reached
# through the module rather than with "from papaya_design import *",
# because the blocks do not exist until this call has created them.
try:
    papaya_design.papaya_design_init()
except RuntimeError as exc:
    raise SystemExit(
        "The board would not build this design: " + str(exc)
        + ". If the design reads something plugged into the "
        "expansion connector, check that it is attached."
    ) from exc

board = papaya_design.papaya0

print(f"\nReading every {PRINT_EVERY:.0f} s, moving {INPUT} every "
      f"{CHANGE_EVERY:.0f} s. Press Ctrl+C to stop.\n")

next_print = time.monotonic()
next_change = time.monotonic()
step = 0

try:
    while True:
        now = time.monotonic()

        if now >= next_change:
            value = VALUES[step % len(VALUES)]
            board.setInput(getattr(papaya_design, INPUT), value)
            print(f"  -> {INPUT} = {value:+.3f}")
            step += 1
            next_change = now + CHANGE_EVERY

        if now >= next_print and board.readProbesLatest(timeout_ms=250):
            values = {name: getattr(papaya_design, name).getVal()
                      for name in PROBES}
            reading = "   ".join(f"{n}={v:+8.4f}"
                                 for n, v in values.items())
            # The derived number. This is the line worth changing.
            mean = sum(values.values()) / len(values)
            print(f"{reading}   mean={mean:+8.4f}")
            next_print = now + PRINT_EVERY

        time.sleep(0.02)

except KeyboardInterrupt:
    print("\nStopped. The board is left in configuration mode, so "
          "the next program can use it.")
