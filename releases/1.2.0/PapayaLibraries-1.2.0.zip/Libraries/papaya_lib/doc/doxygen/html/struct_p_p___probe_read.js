var struct_p_p___probe_read =
[
    [ "ageBatches", "struct_p_p___probe_read.html#a1f6d14df03ad179c8f32bdf6ad0fa60c", null ],
    [ "ok", "struct_p_p___probe_read.html#aa63204fa25b32bb39f9e29f323f09113", null ],
    [ "samplesPerProbe", "struct_p_p___probe_read.html#abd8513a635f3dae993df46be9604c1d7", null ]
];