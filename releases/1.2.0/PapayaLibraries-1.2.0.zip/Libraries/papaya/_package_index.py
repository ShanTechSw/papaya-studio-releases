"""
Package index for the Papaya Package Manager.

Resolves and fetches the small JSON "package index" that advertises the
latest **Libraries** and **Examples** packages, and downloads / verifies
/ installs a package zip. Pure standard library: no extra dependency,
Qt-free apart from a lazy ``QSettings`` read of the index-URL override.

THE INDEX IS SIGNED, AND THIS MODULE FAILS CLOSED
-------------------------------------------------
``packages.json`` is a signed container: a 68-byte header carrying the key
id and an Ed25519 signature, then the document's exact bytes. It is
verified with :func:`papaya._feed.open_signed_feed` under its own context,
``PP-PKGINDEX-v1``, so a signed update list can never be served in its
place and vice versa.

It used to be a plain ``urllib`` GET whose JSON was parsed directly, with
no signature check of any kind. The ``sha256`` below was then the only
protection an installed package had, and it arrives *in the same document*,
so whoever could serve a hostile package could serve its matching digest.
That is precisely the threat feed signing exists to close, and this path
was not asking for a signature at all. A build with no publishing keys now
refuses every index rather than reading one it cannot check, which is the
same posture :mod:`papaya._update_check` takes and for the same reason.

The document inside the container is a JSON object keyed by package id,
carrying the same document-level fields every signed list here carries::

    {
      "schema":     1,
      "serial":     2026090201,
      "min_key_id": 1,
      "published":  "2026-09-02",
      "libraries": {"version":    "1.1.0",
                    "url":        "https://.../PapayaLibraries-1.1.0.zip",
                    "sha256":     "<64 hex digits>",
                    "size_bytes": 2189431},
      "examples":  {"version":    "1.1.0",
                    "url":        "https://.../PapayaExamples-1.1.0.zip",
                    "sha256":     "<64 hex digits>",
                    "size_bytes": 481022}
    }

``serial`` is the replay floor and only ever rises. It is remembered under
a key of its own rather than shared with the update list: the two
documents are published independently and count independently, so one
shared counter would let whichever published last refuse the other for
ever. ``min_key_id`` DOES share the update list's setting, because
retiring a compromised key is a fact about the key and not about one list,
and a key that may no longer sign a release must not still be able to sign
the packages that get compiled into a user's project.

The zips are exactly the artifacts the release build publishes: each has a
single top-level ``Libraries/`` or ``Examples/`` folder, so the Package
Manager and the release pipeline stay in lock-step.

``sha256`` is REQUIRED and must be 64 hex digits. It used to be optional,
which meant an index that simply omitted it skipped verification in
silence, so an attacker who could serve the index did not have to forge a
digest. Nothing is downloaded now until the field is present and well
formed.

``size_bytes`` is optional, for indexes written before it existed. When
present it tightens the bound on the read and is checked against what
arrived. It can only ever make the bound smaller: the client keeps its own
finite ceiling regardless, because this field arrives from the same index
the checksum exists to distrust.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from . import _feed
from . import _feed_schema
from . import _release_keys

# Placeholder index URL. Override via PAPAYA_PACKAGE_INDEX or the
# QSettings key updates/package_index_url.
DEFAULT_INDEX_URL = "https://shanon-technologies.com/papaya-studio/updates/packages.json"

_USER_AGENT = "PapayaStudio-PackageManager"
_PACKAGE_IDS = ("libraries", "examples")

#: The index's own replay floor, and the SHARED key-retirement floor. See
#: the module docstring for why one is separate and the other is not.
_SERIAL_FLOOR_SETTING = "packages/min_serial"
_KEY_FLOOR_SETTING = "updates/min_key_id"

#: Why the last :func:`fetch_index` returned nothing, as
#: ``(reason, detail)``. Module state rather than a return value so
#: ``fetch_index`` keeps its exact contract, which the Package Manager
#: dialog and the figure tooling both depend on, while a caller that wants
#: to say something truthful about the failure can ask.
#:
#: It exists because the dialog used to blame the user's internet
#: connection for every empty result, including a signature that did not
#: verify and an index that was never published.
_LAST_PROBLEM: tuple[str, str] = ("", "")


def _remember_problem(reason: str, detail: str) -> None:
    global _LAST_PROBLEM
    _LAST_PROBLEM = (reason, detail)


def last_problem() -> tuple[str, str]:
    """``(reason, detail)`` for the most recent fetch. Empty if it worked.

    The reason is one of the ``papaya._feed.REASON_*`` codes.
    """
    return _LAST_PROBLEM


#: A checksum must be exactly 64 hexadecimal digits. Case-insensitive: the
#: security property is that the field is PRESENT and well formed, and
#: rejecting an uppercase digest would only be a trap for a hand-written
#: feed without making anything harder to forge.
_SHA256_RE = re.compile(r"\A[0-9a-fA-F]{64}\Z")

#: Backstop on the download when the index declares no size. Both packages
#: this index advertises are single-digit megabytes; a gigabyte is far past
#: anything legitimate and still finite.
_MAX_DOWNLOAD_BYTES = 1 << 30

#: A zip may expand to this multiple of its compressed size, or to
#: ``_MIN_EXPANSION_ALLOWANCE``, whichever is larger. The Libraries package
#: is the demanding one, because its generated reference pages compress
#: well: roughly eleven to one measured. Fifty gives generous headroom
#: over that while still refusing the thousand-to-one shape of a bomb.
_MAX_EXPANSION_RATIO = 50
_MIN_EXPANSION_ALLOWANCE = 8 << 20

#: Staged downloads older than this are swept. Long enough that a slow link
#: on a large package is never interrupted by another window's sweep.
_STALE_DOWNLOAD_SECONDS = 24 * 60 * 60


@dataclass(frozen=True)
class PackageRelease:
    """One package advertised by the index."""
    package_id: str   # "libraries" | "examples"
    version: str
    url: str
    sha256: str = ""
    #: Expected size of the artifact in bytes, 0 when the index does not
    #: say. Optional so an older index still parses, and used to bound the
    #: read when present.
    size_bytes: int = 0


def index_url() -> str:
    """Resolve the package-index URL: env -> QSettings -> default."""
    env = (os.environ.get("PAPAYA_PACKAGE_INDEX") or "").strip()
    if env:
        return env
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        v = QSettings("Shanon Technologies", "Papaya Studio").value(
            "updates/package_index_url", "", type=str)
        if v:
            return str(v)
    except Exception:
        pass
    return DEFAULT_INDEX_URL


def fetch_index(*, timeout: float = 6.0) -> dict[str, PackageRelease]:
    """Return ``{package_id: PackageRelease}``; empty dict on any failure.

    Nothing below the signature check runs on bytes that have not been
    proven to come from a key this build trusts. The address is checked
    before the request, by the same rule the update list uses, so an
    overridden index address that is not https is refused rather than
    opened.

    The empty dict on failure is the contract, not an oversight: the
    Package Manager still has to show what is installed when the list
    cannot be had. :func:`last_problem` says why, so the dialog can be
    honest about which failure it was.
    """
    try:
        raw = _feed.fetch(index_url(), timeout=timeout,
                          user_agent=_USER_AGENT)
        document = _feed.open_signed_feed(
            raw, _release_keys.CONTEXT_PACKAGE_INDEX,
            key_floor=_feed.stored_floor(_KEY_FLOOR_SETTING),
            serial_floor=_feed.stored_floor(_SERIAL_FLOOR_SETTING))
    except _feed.FeedProblem as problem:
        _remember_problem(problem.reason, problem.detail)
        return {}
    except Exception:                                         # noqa: BLE001
        _remember_problem(_feed.REASON_UNREADABLE, "")
        return {}
    _remember_problem("", "")

    # Raised ONLY now, after the document has been fully accepted, so a
    # forged index can never lock the channel by planting a high floor.
    _feed.raise_floor(_SERIAL_FLOOR_SETTING, document.get("__serial__", 0))
    _feed.raise_floor(_KEY_FLOOR_SETTING,
                      document.get(_feed_schema.FIELD_MIN_KEY_ID, 0))

    out: dict[str, PackageRelease] = {}
    for pid in _PACKAGE_IDS:
        entry = document.get(pid)
        if not isinstance(entry, dict):
            continue
        ver = str(entry.get("version", "")).strip()
        # Checked even though the document is signed. An address read out
        # of a list reaches a network call and, for the notes link on the
        # update side, the desktop's "open this" handler; the update list
        # applies the same rule to every address it reads, and one list
        # being signed is not a reason for the two to disagree about what
        # they are willing to open.
        url = _feed.safe_http_url(entry.get("url", ""))
        if not ver or not url:
            continue
        try:
            size = int(entry.get("size_bytes", 0) or 0)
        except (TypeError, ValueError):
            size = 0
        out[pid] = PackageRelease(
            pid, ver, url, str(entry.get("sha256", "")).strip(),
            max(0, size))
    return out


def _common_top(members: list[str]) -> str:
    """Return the single common top-level zip folder (with '/'), or ''."""
    tops = {m.split("/", 1)[0] for m in members if m}
    return (next(iter(tops)) + "/") if len(tops) == 1 else ""


def _assert_writable(dest_root: Path, package_id: str) -> None:
    """Refuse before downloading if the destination cannot be written.

    Checked up front rather than discovered during extraction. A package
    installed to a system location is read-only to the user running the
    application: on a Linux system install the files live under a
    directory owned by root, and the same is true of any read-only
    application image. Without this check the download ran to completion,
    the checksum verified, and extraction then failed part way through
    with a bare permission error, having already replaced some of the
    files it had managed to write.

    The message names the resolved path and the way out, because the way
    out is not obvious: the location is a setting, and pointing it at a
    folder the user owns is both supported and the intended arrangement.
    """
    probe_parent = dest_root
    while not probe_parent.exists() and probe_parent != probe_parent.parent:
        probe_parent = probe_parent.parent

    if not os.access(probe_parent, os.W_OK):
        raise PermissionError(
            f"The {package_id} package cannot be installed to "
            f"{dest_root}, because that location is not writable by the "
            f"account running Papaya Studio. This is the normal state for "
            f"a system-wide install: the files there belong to the "
            f"administrator, and updating them would need administrator "
            f"rights.\n\n"
            f"Choose a folder you own in Preferences, under Libraries. "
            f"Studio will read from there instead, and the packages can "
            f"then be updated without administrator rights. The files "
            f"already installed are untouched.")


def _require_checksum(release: PackageRelease) -> str:
    """Return the expected digest, or refuse.

    THE DEFECT THIS CLOSES. The guard used to be ``if release.sha256:``,
    and ``sha256`` defaults to empty and comes straight out of the index.
    So an attacker who controls the index does not forge a digest, they
    omit the field, and verification is skipped in silence. A check the
    publisher can switch off is not a check.

    Refusing here, before the request is made, is deliberate: a refusal
    that downloads first is a weaker property and a slower one.
    """
    sha = (release.sha256 or "").strip()
    if not _SHA256_RE.match(sha):
        raise ValueError(
            f"The {release.package_id} package cannot be installed, "
            f"because the update list did not give a usable checksum for "
            f"it. Nothing was downloaded and nothing was changed.\n\n"
            f"This normally means the update list is being edited or is "
            f"incomplete. Try again later, and if it keeps happening "
            f"report it to Shanon Technologies.")
    return sha.lower()


def _require_safe_url(release: PackageRelease) -> str:
    """Return the address to open, or refuse.

    ``fetch_index`` already applies this to everything it parses, so in
    the normal path this is a second check of a value that passed once.
    It is here because this function is the one that opens the address,
    and a ``PackageRelease`` can be built by any caller: the property
    worth having is that the shipped download function never opens an
    address it would not accept, not that its usual caller was careful.
    """
    safe = _feed.safe_http_url(release.url)
    if safe is None:
        raise ValueError(
            f"The {release.package_id} package cannot be installed, "
            f"because the update list gave an address Papaya Studio will "
            f"not open. Nothing was downloaded and nothing was changed."
            f"\n\nPackages are only ever fetched over a secure (https) "
            f"connection. If you have set a custom package address in "
            f"Preferences, clear it to go back to the standard one.")
    return safe


def _staging_dir() -> Path:
    """A download folder this application owns.

    Not the shared temporary directory. That is writable by every process
    running as the same user, so a file verified there and read back
    afterwards can be replaced in between, and what is read back is
    installed. Staging under the application's own cache directory closes
    that window.
    """
    from ._app_paths import cache_dir
    staging = cache_dir("downloads")
    staging.mkdir(parents=True, exist_ok=True)
    return staging


def _sweep_stale_downloads(staging: Path) -> None:
    """Delete abandoned part-files. An interrupted download must not
    accumulate one artifact-sized file per session."""
    cutoff = time.time() - _STALE_DOWNLOAD_SECONDS
    try:
        entries = list(staging.iterdir())
    except OSError:
        return
    for old in entries:
        try:
            if old.is_file() and old.stat().st_mtime < cutoff:
                old.unlink()
        except OSError:
            pass          # another window may be using it; not ours to force


#: Names Windows resolves to a device rather than a file, whatever the
#: extension. Opening one writes to the device: a member called NUL is
#: silently discarded and reported as installed.
_RESERVED_STEMS = frozenset(
    ["con", "prn", "aux", "nul"]
    + [f"com{i}" for i in range(1, 10)]
    + [f"lpt{i}" for i in range(1, 10)])


def _for_message(text: str) -> str:
    """Render an archive-supplied name safely inside a message.

    The name comes from the package, so it is chosen by whoever built the
    package. It reaches a dialog, so it must not be able to carry markup,
    and it must not be long enough to push the rest of the sentence out of
    view. Anything outside a conservative set becomes a question mark
    rather than being dropped, so the reader can still see that something
    unusual was there.
    """
    safe = "".join(
        c if (32 <= ord(c) < 127 and c not in "<>&\"'") else "?"
        for c in text[:80])
    return safe + ("..." if len(text) > 80 else "")


def _safe_relative(rel: str, dest_root: Path) -> Path:
    """Resolve one archive member under *dest_root*, or refuse.

    *dest_root* MUST already be resolved. Comparing a resolved candidate
    against an unresolved root was a real defect: a destination reached
    through a link, a substituted drive, a relative path or any path
    holding a ``..`` segment made every member of a perfectly good package
    fail the containment test, and the refusal told the user their
    package was tampered with. Measured before the fix: an ordinary
    absolute path installed, while ``Path("relset")`` and
    ``base/"sub"/".."/"dotted"`` both refused the whole archive.

    Every arm below was reachable. ``Path(dest) / '../../../../evil.py'``
    resolves outside the destination; ``Path(dest) / 'C:/evil.py'`` and
    ``Path(dest) / '/etc/evil'`` discard the left operand entirely,
    because joining an absolute path replaces rather than appends.

    Checked explicitly AND by resolution. The explicit arms give a reason
    a person can act on; the resolution arm is the backstop that does not
    depend on having enumerated every spelling.
    """
    why = ""
    normalised = rel.replace("\\", "/")
    parts = [q for q in normalised.split("/") if q]

    if not rel or rel in (".", ".."):
        why = "it has no usable name"
    elif "\\" in rel:
        # A zip separator is '/'. A backslash is a literal character in a
        # member name, which becomes a traversal on Windows and a strange
        # filename elsewhere. Refused rather than interpreted.
        why = "it contains a backslash"
    elif rel.startswith("/"):
        why = "it is an absolute path"
    elif len(rel) >= 2 and rel[1] == ":":
        why = "it names a drive"
    elif ".." in parts:
        why = "it points above the destination"
    elif any(q.strip(". ") == "" for q in parts):
        # A component of only dots and spaces is collapsed by the platform
        # onto a directory that already exists, so the write target became
        # a folder and extraction died half way through with a raw error,
        # having already replaced earlier files. Refused during planning,
        # so nothing is written at all.
        why = "one of its names is only dots or spaces"
    elif any(q.split(".")[0].lower() in _RESERVED_STEMS for q in parts):
        why = "one of its names is reserved by the operating system"
    elif "\x00" in rel:
        why = "it contains a null character"

    if not why:
        candidate = (dest_root / rel).resolve()
        # Strict containment. The destination itself is not a valid target:
        # a member can never legitimately BE the folder it installs into.
        if dest_root not in candidate.parents:
            why = "it resolves elsewhere"
        else:
            return candidate

    raise ValueError(
        f"The package was refused because one of the files inside it "
        f"would have been written outside the destination folder "
        f"({_for_message(rel)}: {why}). Nothing was installed.\n\n"
        f"A package that does this is either damaged or not the package "
        f"it claims to be. Do not try the same file again. Report it to "
        f"Shanon Technologies.")


def download_and_install(release: PackageRelease, dest_root: Path,
                         *, progress=None, timeout: float = 120.0) -> None:
    """Download ``release.url``, verify its SHA-256, extract into *dest_root*.

    The zip's single top-level folder (``Libraries/`` or ``Examples/``)
    is stripped so the contents land directly in *dest_root*. Extraction
    is additive (files are overwritten in place) so a failed download
    never destroys the currently-installed package. Raises on any
    failure. ``progress``, if given, is called with
    ``(downloaded_bytes, total_bytes)``.

    ORDER IS THE POINT. The checksum is required before the request is
    made, the read is bounded while it runs, the digest is computed as the
    bytes arrive rather than by reading the file back, and every member of
    the archive is resolved before ANY of them is opened for writing. A
    package that fails at the last of those has still written nothing.
    """
    # Resolved ONCE, here, and used for every later comparison and every
    # write. _safe_relative compares against it, and a resolved candidate
    # can only be compared with a resolved root.
    dest_root = Path(dest_root).resolve()
    expected = _require_checksum(release)
    source_url = _require_safe_url(release)
    _assert_writable(dest_root, release.package_id)

    staging = _staging_dir()
    _sweep_stale_downloads(staging)
    tmp = staging / f"{release.package_id}-{os.getpid()}.part"

    # Bound the read. The declared size TIGHTENS the client's own ceiling
    # and can never raise it: size_bytes arrives from the index, which is
    # the very thing this function refuses to trust, so letting it replace
    # the backstop would hand the bound to whoever serves the index.
    limit = min(release.size_bytes or _MAX_DOWNLOAD_BYTES,
                _MAX_DOWNLOAD_BYTES)

    try:
        req = urllib.request.Request(source_url,
                                     headers={"User-Agent": _USER_AGENT})
        digest = hashlib.sha256()
        with urllib.request.urlopen(                          # noqa: S310
                req, timeout=timeout, context=_feed.tls_context()) as resp:
            total = release.size_bytes or int(
                resp.headers.get("Content-Length", 0) or 0)
            done = 0
            with open(tmp, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    done += len(chunk)
                    if done > limit:
                        raise ValueError(
                            f"The {release.package_id} download was refused "
                            f"because it is larger than the update list said "
                            f"it would be ({done} bytes and still arriving, "
                            f"against a stated size of {limit}). Nothing was "
                            f"installed.")
                    f.write(chunk)
                    digest.update(chunk)
                    if progress is not None:
                        progress(done, total)

        if release.size_bytes and done != release.size_bytes:
            raise ValueError(
                f"The {release.package_id} download was refused because it "
                f"is not the size the update list stated ({done} bytes "
                f"against {release.size_bytes}). Nothing was installed.")

        got = digest.hexdigest()
        if got != expected:
            raise RuntimeError(
                f"SHA-256 mismatch for the {release.package_id} package "
                f"(expected {expected}, got {got}). Download discarded.")

        with zipfile.ZipFile(tmp) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            members = zf.namelist()
            prefix = _common_top(members)

            # A zip declares what it expands to, so a bomb can be refused
            # without inflating a byte of it.
            expansion = sum(i.file_size for i in infos)
            cap = max(done * _MAX_EXPANSION_RATIO, _MIN_EXPANSION_ALLOWANCE)
            if expansion > cap:
                raise ValueError(
                    f"The {release.package_id} package was refused because "
                    f"it would expand to {expansion} bytes, far larger than "
                    f"its download size of {done}. Nothing was installed.")

            # Resolve EVERY member before writing ANY of them.
            planned: list[tuple[zipfile.ZipInfo, Path]] = []
            for info in infos:
                name = info.filename
                rel = (name[len(prefix):]
                       if prefix and name.startswith(prefix) else name)
                if not rel:
                    continue
                planned.append((info, _safe_relative(rel, dest_root)))

            dest_root.mkdir(parents=True, exist_ok=True)
            for info, target in planned:
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as dst:
                    while True:
                        block = src.read(65536)
                        if not block:
                            break
                        dst.write(block)
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
