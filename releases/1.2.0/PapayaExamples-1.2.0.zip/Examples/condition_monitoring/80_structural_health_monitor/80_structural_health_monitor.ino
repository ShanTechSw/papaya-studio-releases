/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe cpu_load_pct;
VectorProbe modal_spectrum_2;
probe structural_comp;
probe pca_score_1;
probe damage_class;
probe unused_signals;

input z_score_normali;
input env_hi;
input env_lo;

/* Global Array Declarations */
float PCA_projection_W[] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
float PCA_projection_mu[] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
uint16_t damage_classifier_feat_idx[] = {0, 65535, 65535};
float damage_classifier_thresh[] = {0.5f, 0.0f, 0.0f};
uint16_t damage_classifier_left[] = {1, 65535, 65535};
uint16_t damage_classifier_right[] = {2, 65535, 65535};
float damage_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  z_score_normali = input("z_score_normali", 0.0f);
  env_hi = input("env_hi", 1000.0f);
  env_lo = input("env_lo", 1e-06f);
  signalSource SIM__accel_1 = signalSource::multisine(100.0f, 50.0f, 5, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.7f);
  signalSource SIM__accel_2 = signalSource::multisine(100.0f, 50.0f, 6, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.7f);
  signalSource SIM__accel_3 = signalSource::multisine(100.0f, 50.0f, 7, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.7f);
  signalSource SIM__cracked_mode_shift = signalSource::sine(180.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.4f);
  cpuLoad CPU_load = cpuLoad();
  node accel_3___fault = node("[1.0 1.0]", "[1.0]", Sum);
  fft_HannWindow modal_FFT = fft_HannWindow(1024);
  expander fan_6 = expander(6);
  fftMagResolver modal_spectrum = fftMagResolver(modal_FFT);
  rootMeanSquare Rms = rootMeanSquare(10);
  variance Variance = variance(10);
  crestFactor Crest_Factor = crestFactor(64);
  zcr Zcr = zcr(256, 0.0);
  peakToPeak Peak_To_Peak = peakToPeak(64);
  expander fan_2 = expander(2);
  absVal rectify = absVal();
  spectralFeatures spectral_features = spectralFeatures(modal_spectrum);
  zScoreNorm z_score_normalise = zScoreNorm(256, 1e-09);
  hjorth Hjorth_complexity = hjorth(128);
  sat keep_positive = sat();
  gain scale_to_1_length = gain(0.1);
  entropy Log_energy = entropy(10);
  pcaProject PCA_projection = pcaProject(7, 2, PCA_projection_W, PCA_projection_mu);
  decisionTree damage_classifier = decisionTree(2, 2, 3, damage_classifier_feat_idx, damage_classifier_thresh, damage_classifier_left, damage_classifier_right, damage_classifier_leaf_val);
  merger unused_bus = merger(10);
  cpu_load_pct = probe("cpu_load_pct");
  modal_spectrum_2 = VectorProbe("modal_spectrum");
  structural_comp = probe("structural_comp");
  pca_score_1 = probe("pca_score_1");
  damage_class = probe("damage_class");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  z_score_normali > z_score_normalise.in(1);
  env_hi > keep_positive.in(0);
  env_lo > keep_positive.in(1);
  SIM__accel_1 > modal_FFT;
  SIM__accel_2 > fan_6;
  SIM__accel_3 > accel_3___fault.in(0);
  SIM__cracked_mode_shift > accel_3___fault.in(1);
  CPU_load > cpu_load_pct;
  accel_3___fault > fan_2;
  modal_FFT > modal_spectrum;
  fan_6.out(0) > Rms;
  fan_6.out(1) > Variance;
  fan_6.out(2) > Crest_Factor;
  fan_6.out(4) > Zcr;
  fan_6.out(5) > Peak_To_Peak;
  fan_6.out(3) > rectify;
  modal_spectrum > spectral_features;
  modal_spectrum >> modal_spectrum_2;
  Rms > PCA_projection.in(1);
  Variance > PCA_projection.in(2);
  Crest_Factor > PCA_projection.in(3);
  Zcr > PCA_projection.in(5);
  Peak_To_Peak > PCA_projection.in(6);
  fan_2.out(0) > z_score_normalise.in(0);
  fan_2.out(1) > Hjorth_complexity;
  rectify > keep_positive.in(2);
  spectral_features.out(0) > unused_bus.in(0);
  spectral_features.out(1) > unused_bus.in(1);
  spectral_features.out(2) > unused_bus.in(2);
  spectral_features.out(3) > unused_bus.in(3);
  spectral_features.out(4) > unused_bus.in(4);
  spectral_features.out(5) > unused_bus.in(5);
  spectral_features.out(6) > unused_bus.in(6);
  z_score_normalise > PCA_projection.in(0);
  Hjorth_complexity.out(1) > unused_bus.in(8);
  Hjorth_complexity.out(2) > unused_bus.in(9);
  Hjorth_complexity.out(0) > structural_comp;
  keep_positive > scale_to_1_length;
  scale_to_1_length > Log_energy;
  Log_energy > PCA_projection.in(4);
  PCA_projection.out(0) > damage_classifier.in(0);
  PCA_projection.out(1) > damage_classifier.in(1);
  PCA_projection.out(0) > pca_score_1;
  damage_classifier.out(1) > unused_bus.in(7);
  damage_classifier.out(0) > damage_class;
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  z_score_normali.enableRemote();
  env_hi.enableRemote();
  env_lo.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    cpu_load_pct.show();
    modal_spectrum_2.show();
    structural_comp.show();
    pca_score_1.show();
    damage_class.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}