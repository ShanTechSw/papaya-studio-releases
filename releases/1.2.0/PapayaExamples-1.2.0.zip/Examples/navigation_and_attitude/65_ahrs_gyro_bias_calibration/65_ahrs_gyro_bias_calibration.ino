/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 500.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe gyro_bias_x;
probe mahony_q0;
probe complementary_0;
probe roll;
probe pitch;
probe yaw;
probe unused_signals;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(500.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__accel_x = signalSource::sine(0.3f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.05f);
  signalSource SIM__accel_y = signalSource::sine(0.4f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.05f);
  signalSource SIM__accel_z = signalSource::sine(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.05f, /*offset=*/ 1.0f);
  signalSource SIM__gyro_x = signalSource::sine(0.6000000000000001f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.6f);
  signalSource SIM__gyro_y = signalSource::sine(0.7f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.6f);
  signalSource SIM__gyro_z = signalSource::sine(0.8f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.6f);
  signalSource SIM__mag_x = signalSource::sine(0.9000000000000001f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.02f, /*offset=*/ 0.5f);
  signalSource SIM__mag_y = signalSource::sine(1.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.02f);
  signalSource SIM__mag_z = signalSource::sine(1.1f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.02f, /*offset=*/ 0.85f);
  imuBiasEst gyro_bias_est = imuBiasEst(64, 0.001, 0.01);
  expander fan_3 = expander(3);
  expander fan_3_2 = expander(3);
  expander fan_3_3 = expander(3);
  expander fan_ax = expander(3);
  expander fan_ay = expander(3);
  expander fan_az = expander(3);
  expander fan_gx = expander(3);
  expander fan_gy = expander(3);
  expander fan_gz = expander(3);
  madgwickAhrs Madgwick_AHRS = madgwickAhrs(0.08);
  mahonyAhrs Mahony_AHRS = mahonyAhrs(1.0, 0.05);
  complementaryAhrs complementary_AHRS = complementaryAhrs(0.98);
  quatToEuler quaternion_to_Euler = quatToEuler();
  merger unused_bus = merger(14);
  gyro_bias_x = probe("gyro_bias_x");
  mahony_q0 = probe("mahony_q0");
  complementary_0 = probe("complementary_0");
  roll = probe("roll_deg");
  pitch = probe("pitch_deg");
  yaw = probe("yaw_deg");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  SIM__accel_x > gyro_bias_est.in(0);
  SIM__accel_y > gyro_bias_est.in(1);
  SIM__accel_z > gyro_bias_est.in(2);
  SIM__gyro_x > gyro_bias_est.in(3);
  SIM__gyro_y > gyro_bias_est.in(4);
  SIM__gyro_z > gyro_bias_est.in(5);
  SIM__mag_x > fan_3;
  SIM__mag_y > fan_3_2;
  SIM__mag_z > fan_3_3;
  gyro_bias_est.out(0) > fan_ax;
  gyro_bias_est.out(1) > fan_ay;
  gyro_bias_est.out(2) > fan_az;
  gyro_bias_est.out(3) > fan_gx;
  gyro_bias_est.out(4) > fan_gy;
  gyro_bias_est.out(5) > fan_gz;
  gyro_bias_est.out(6) > unused_bus.in(0);
  gyro_bias_est.out(7) > unused_bus.in(1);
  gyro_bias_est.out(8) > unused_bus.in(2);
  gyro_bias_est.out(10) > unused_bus.in(3);
  gyro_bias_est.out(11) > unused_bus.in(4);
  gyro_bias_est.out(9) > gyro_bias_x;
  fan_3.out(0) > Madgwick_AHRS.in(6);
  fan_3.out(1) > Mahony_AHRS.in(6);
  fan_3.out(2) > complementary_AHRS.in(6);
  fan_3_2.out(0) > Madgwick_AHRS.in(7);
  fan_3_2.out(1) > Mahony_AHRS.in(7);
  fan_3_2.out(2) > complementary_AHRS.in(7);
  fan_3_3.out(0) > Madgwick_AHRS.in(8);
  fan_3_3.out(1) > Mahony_AHRS.in(8);
  fan_3_3.out(2) > complementary_AHRS.in(8);
  fan_ax.out(0) > Madgwick_AHRS.in(0);
  fan_ax.out(1) > Mahony_AHRS.in(0);
  fan_ax.out(2) > complementary_AHRS.in(0);
  fan_ay.out(0) > Madgwick_AHRS.in(1);
  fan_ay.out(1) > Mahony_AHRS.in(1);
  fan_ay.out(2) > complementary_AHRS.in(1);
  fan_az.out(0) > Madgwick_AHRS.in(2);
  fan_az.out(1) > Mahony_AHRS.in(2);
  fan_az.out(2) > complementary_AHRS.in(2);
  fan_gx.out(0) > Madgwick_AHRS.in(3);
  fan_gx.out(1) > Mahony_AHRS.in(3);
  fan_gx.out(2) > complementary_AHRS.in(3);
  fan_gy.out(0) > Madgwick_AHRS.in(4);
  fan_gy.out(1) > Mahony_AHRS.in(4);
  fan_gy.out(2) > complementary_AHRS.in(4);
  fan_gz.out(0) > Madgwick_AHRS.in(5);
  fan_gz.out(1) > Mahony_AHRS.in(5);
  fan_gz.out(2) > complementary_AHRS.in(5);
  Madgwick_AHRS.out(0) > quaternion_to_Euler.in(0);
  Madgwick_AHRS.out(1) > quaternion_to_Euler.in(1);
  Madgwick_AHRS.out(2) > quaternion_to_Euler.in(2);
  Madgwick_AHRS.out(3) > quaternion_to_Euler.in(3);
  Mahony_AHRS.out(1) > unused_bus.in(5);
  Mahony_AHRS.out(2) > unused_bus.in(6);
  Mahony_AHRS.out(3) > unused_bus.in(7);
  Mahony_AHRS.out(4) > unused_bus.in(8);
  Mahony_AHRS.out(5) > unused_bus.in(9);
  Mahony_AHRS.out(6) > unused_bus.in(10);
  Mahony_AHRS.out(0) > mahony_q0;
  complementary_AHRS.out(1) > unused_bus.in(11);
  complementary_AHRS.out(2) > unused_bus.in(12);
  complementary_AHRS.out(3) > unused_bus.in(13);
  complementary_AHRS.out(0) > complementary_0;
  quaternion_to_Euler.out(0) > roll;
  quaternion_to_Euler.out(1) > pitch;
  quaternion_to_Euler.out(2) > yaw;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    gyro_bias_x.show();
    mahony_q0.show();
    complementary_0.show();
    roll.show();
    pitch.show();
    yaw.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}