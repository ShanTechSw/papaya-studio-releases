"""Shaft-fault triage: the board measures the bands, this script names the fault.

Run this beside example 89.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

Four dimensionless ratios, applied in the order a vibration analyst applies
them. Order matters: misalignment and unbalance both raise a radial
reading, so the tests that separate them are asked FIRST, and the level is
only used afterwards to say how bad it is.

  2x over 1x radial     above 1.5 the fault is misalignment rather than
                        unbalance. A once-per-turn heavy spot cannot make
                        2x; a coupling that is not straight is loaded twice
                        per turn.

  axial 1x over
  radial 1x             above 1.0 the machine is being pushed along its own
                        shaft, which only misalignment does. The stronger
                        of the two misalignment tests and the one most
                        benches never measure.

  half orders over 1x   above 0.3 something is loose enough to move twice
                        per revolution. Nothing else in this list produces
                        half orders.

  harmonics over 1x     above 0.7 the spectrum is a forest rather than a
                        line, which is what a rattle looks like.

Every threshold is on a RATIO, so none of them needs retuning for a
different machine, a different sensor or a different mounting.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "imbalance", "misalignment", "looseness")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "triage"
FEATURES = ("h1x", "h2x", "hharm", "hhalf", "v1x", "v2x",
            "a1x", "a2x", "r_2x", "r_axial", "r_harm",
            "r_half", "state")

# The thresholds, and they are the whole script.
TWO_OVER_ONE = 1.5          # above this: misalignment, not unbalance
AXIAL_OVER_RADIAL = 1.0     # above this: a force along the shaft
# 1.0 and not 0.5. Looseness raises the axial reading too, to 0.56 on this
# record, and at 0.5 the axial test fired on it. Misalignment reads 2.75,
# so there is room.
HALF_ORDER = 0.30           # above this: something is loose
HARMONICS = 0.70            # above this: a forest, not a line
UNBALANCE_LEVEL = 2.0       # multiple of the healthy shaft line

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

BASELINE_1X = 0.0142        # the healthy shaft line on this record, in g


def classify(row):
    """One verdict, with the tests applied in the order they discriminate."""
    reasons = [
        f"shaft line {row['h1x']:.4f} g, 2x {row['h2x']:.4f} g, "
        f"axial 1x {row['a1x']:.4f} g",
        f"ratios: 2x/1x {row['r_2x']:.2f}, axial/radial "
        f"{row['r_axial']:.2f}, harmonics/1x {row['r_harm']:.2f}, "
        f"half/1x {row['r_half']:.2f}",
    ]

    # Looseness first: it is the only fault that produces half orders, so
    # it can be ruled in or out without reference to anything else.
    if row["r_half"] >= HALF_ORDER:
        reasons.append(
            "half orders are present, and nothing but a joint that moves "
            "twice per revolution produces them")
        if row["r_harm"] >= HARMONICS:
            reasons.append(
                f"and the harmonic forest is up as well, {row['r_harm']:.2f} "
                f"of the shaft line, which is the rattle itself")
        return ("looseness", "mechanical looseness: a foot, a bearing "
                "housing or a bolted joint", reasons)

    # Then misalignment, on two independent tests. Either alone is
    # suggestive; both together is a diagnosis.
    two_x = row["r_2x"] >= TWO_OVER_ONE
    axial = row["r_axial"] >= AXIAL_OVER_RADIAL
    if two_x and axial:
        reasons.append(
            "both misalignment tests agree: 2x dominates the radial "
            "reading AND the axial reading is up")
        return ("misalignment", "misalignment at the coupling", reasons)
    if two_x or axial:
        reasons.append(
            "only one of the two misalignment tests is over. Check the "
            "sensor's axial alignment before acting: the axial test is the "
            "stronger one and it is the one a badly aimed sensor loses")
        return ("misalignment", "misalignment, on one test of two", reasons)

    # Only then the level, which says how bad rather than what.
    level = row["h1x"] / max(BASELINE_1X, 1e-12)
    reasons.append(f"shaft line is {level:.2f}x its healthy value, with no "
                   f"2x, no axial component and no harmonics")
    if level >= UNBALANCE_LEVEL:
        return ("imbalance", "unbalance: everything at one times shaft "
                "speed and nothing anywhere else", reasons)
    return ("healthy", "nothing to report", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 89_imbalance_misalignment_looseness.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA shaft-fault triage")
    print("=" * 72)
    print("Thresholds in use, all on dimensionless ratios:")
    print(f"  2x over 1x radial      {TWO_OVER_ONE:.2f}")
    print(f"  axial 1x over radial   {AXIAL_OVER_RADIAL:.2f}")
    print(f"  half orders over 1x    {HALF_ORDER:.2f}")
    print(f"  harmonics over 1x      {HARMONICS:.2f}")
    print("None of them has a unit, so none of them needs changing for "
          "another machine.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
