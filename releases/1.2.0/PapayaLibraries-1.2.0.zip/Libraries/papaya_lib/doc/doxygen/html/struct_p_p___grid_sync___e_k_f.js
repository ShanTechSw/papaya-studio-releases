var struct_p_p___grid_sync___e_k_f =
[
    [ "nom_amplitude", "struct_p_p___grid_sync___e_k_f.html#a890044fa94d98ecf89ba2ad33f9cb5db", null ],
    [ "nom_freq", "struct_p_p___grid_sync___e_k_f.html#ae21b39e340f809decfcfe6f27f935edd", null ],
    [ "P_init", "struct_p_p___grid_sync___e_k_f.html#a34914c34a143fe54e3ebbb2bf660f26e", null ],
    [ "Q_data", "struct_p_p___grid_sync___e_k_f.html#a2684930dfe52e29f991996d23b783db0", null ],
    [ "R_data", "struct_p_p___grid_sync___e_k_f.html#a401100aba1dc6a2ef3d65c43cb6a5f64", null ],
    [ "x_init", "struct_p_p___grid_sync___e_k_f.html#a0471390759f928cf84a269399e239766", null ]
];