/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe S_curve_profile_tap;
probe S_curve_profile_tap_2;
probe S_curve_profile_tap_3;
probe motor_torque;
probe load_position;
probe rigid_reference;
probe load_velocity_2;
VectorProbe resonance;
probe load_spectrum_tap;

input load_target;
input v_max;
input a_max;
input j_max;
input torque_min;
input torque_max;

/* Global Struct Declarations */
// Configuration for SIM__2_mass_drivetrain
static float SIM__2_mass_drivetrain_A_data[4] = {0.0f, 1.0f, -0.998116819821f, 1.99713087008f};
static float SIM__2_mass_drivetrain_B_data[2] = {0.0f, 1.0f};
static float SIM__2_mass_drivetrain_C_data[2] = {0.000985949740875f, 0.0f};
static float SIM__2_mass_drivetrain_D_data[1] = {0.0f};
static float SIM__2_mass_drivetrain_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__2_mass_drivetrain_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__2_mass_drivetrain_A_data,
  .B_data = SIM__2_mass_drivetrain_B_data,
  .C_data = SIM__2_mass_drivetrain_C_data,
  .D_data = SIM__2_mass_drivetrain_D_data,
  .x_init = SIM__2_mass_drivetrain_x_init
};


/* Global Array Declarations */
float SIM__rigid_model_numerator[] = {9.0f};
float SIM__rigid_model_denominator[] = {1.0f, 6.0f, 9.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  load_target = input("load_target", 1.0f);
  v_max = input("v_max", 2.0f);
  a_max = input("a_max", 20.0f);
  j_max = input("j_max", 200.0f);
  torque_min = input("torque_min", -5.0f);
  torque_max = input("torque_max", 5.0f);
  signalSource start = signalSource::step(0.1f, 0.0f, 1.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  trajScurve S_curve_profile = trajScurve();
  inputShaper ZVD_input_shaper = inputShaper(2, 62.8, 0.03);
  expander fan_2 = expander(2);
  node tracking_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid servo_PID = pid(2.0, 8.0, 0.6, 0.008);
  notch anti_resonance_notch = notch(10.0, 8.0);
  sat torque_clamp = sat();
  stateSpace SIM__2_mass_drivetrain = stateSpace(&SIM__2_mass_drivetrain_config);
  expander fan_3 = expander(3);
  tf SIM__rigid_model = tf(SIM__rigid_model_numerator, 1, SIM__rigid_model_denominator, 3);
  derivative load_velocity = derivative(0.01);
  fft load_FFT = fft(512);
  fftMagResolver load_spectrum = fftMagResolver(load_FFT);
  S_curve_profile_tap = probe("S-curve_1");
  S_curve_profile_tap_2 = probe("S-curve_2");
  S_curve_profile_tap_3 = probe("S-curve_3");
  motor_torque = probe("motor_torque");
  load_position = probe("load_position");
  rigid_reference = probe("rigid_reference");
  load_velocity_2 = probe("load_velocity");
  resonance = VectorProbe("resonance_spect");
  load_spectrum_tap = probe("load spectrum_0");

  /* Connect Blocks */
  load_target > S_curve_profile.in(0);
  v_max > S_curve_profile.in(1);
  a_max > S_curve_profile.in(2);
  j_max > S_curve_profile.in(3);
  torque_min > torque_clamp.in(1);
  torque_max > torque_clamp.in(0);
  start > S_curve_profile.in(4);
  S_curve_profile.out(0) > ZVD_input_shaper;
  S_curve_profile.out(1) > S_curve_profile_tap;
  S_curve_profile.out(2) > S_curve_profile_tap_2;
  S_curve_profile.out(3) > S_curve_profile_tap_3;
  ZVD_input_shaper > fan_2;
  fan_2.out(0) > tracking_error.in(0);
  fan_2.out(1) > SIM__rigid_model;
  tracking_error > servo_PID;
  servo_PID > anti_resonance_notch;
  anti_resonance_notch > torque_clamp.in(2);
  torque_clamp > SIM__2_mass_drivetrain;
  torque_clamp > motor_torque;
  SIM__2_mass_drivetrain > fan_3;
  SIM__2_mass_drivetrain > load_position;
  fan_3.out(0) > tracking_error.in(1);
  fan_3.out(1) > load_velocity;
  fan_3.out(2) > load_FFT;
  SIM__rigid_model > rigid_reference;
  load_velocity > load_velocity_2;
  load_FFT > load_spectrum;
  load_spectrum >> resonance;
  load_spectrum > load_spectrum_tap;

  /* Enable Remote Input Control */
  load_target.enableRemote();
  v_max.enableRemote();
  a_max.enableRemote();
  j_max.enableRemote();
  torque_min.enableRemote();
  torque_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    S_curve_profile_tap.show();
    S_curve_profile_tap_2.show();
    S_curve_profile_tap_3.show();
    motor_torque.show();
    load_position.show();
    rigid_reference.show();
    load_velocity_2.show();
    resonance.show();
    load_spectrum_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}