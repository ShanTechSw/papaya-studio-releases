"""A front panel for a diagram running on the board.

The diagram does the hard part on the board, at its own rate, and your
program does the part a PC is good at: a control to turn, a number to
watch, a curve to read, a decision to make. This module is the bridge
between the two, and it is deliberately small: a few calls describe a
panel, and one runs it.

    import papaya.panel as panel

    ui = panel.Panel("Motor rig")
    ui.switch("enable")                  # two states, so a switch
    ui.slider("setpoint", -2.0, 2.0)     # swept by hand, so a slider
    ui.field("gain")                     # typed exactly, so a field
    ui.plot("measured", "command")
    ui.number("error")
    ui.run()

CHOOSING THE CONTROL

Match the control to what the input MEANS, not to what is easiest to
write. A slider accepts any input, which is exactly why it is the wrong
default: an ``enable`` drawn as a slider offers a thousand positions
where the design has two, can write 0.37 to something read as on or off,
and cannot say in words which state the machine is in.

* two states: :meth:`Panel.switch`, or :meth:`Panel.rocker` when it
  stands for a switch bolted to the machine
* named modes: :meth:`Panel.choice`
* a value chosen from a calculation, like a gain: :meth:`Panel.field`
* a value genuinely swept by hand, like a setpoint: :meth:`Panel.slider`

That is a complete program. ``Panel`` attaches to whatever design the
board is carrying, so nothing above names a probe or an input that the
board did not already offer: ask for one it does not have and you are
told, by name, what it does have.

WHAT THE PANEL DOES FOR YOU

* Reads every probe at a steady rate and hands the newest values to each
  widget. One read serves the whole panel, so adding a display costs no
  extra board traffic.
* Writes an input the moment its control moves, and writes several moved
  in the same tick as ONE transfer, so the design never sees a
  half-updated set.
* Stops cleanly. Closing the window, pressing Ctrl+C or letting an
  exception out all take the same path: the design is stopped and the
  link is handed back. A script that leaves the board streaming is the
  one thing that reliably ruins the NEXT run.

WHAT IT DOES NOT DO

It is not the Monitor. There are no cursors, no triggers, no recording
and no analysis, because the Monitor already has those and can be opened
beside your code (Source Editor, the button next to Open Monitor). This
is for the panel the Monitor cannot know about: your knobs, your derived
numbers, your rules.

You can also skip the panel entirely and drive the design yourself with
``papaya.remote.attach()``; this module is built on exactly that and
adds no board capability of its own.
"""

from __future__ import annotations

import contextlib
import sys
import time
import traceback
from typing import (Any, Callable, Dict, Iterable, List, Optional, Sequence,
                    Tuple)

from .remote import RemoteDesign, RemoteDesignError, attach

__all__ = ["Panel", "PanelError", "gui_is_available",
           "GROUP_CREAM", "GROUP_LAVENDER", "GROUP_SKY",
           "PLOT_PAPER", "PLOT_INK", "PLOT_CURVE_COLORS"]

#: Panel background colours, for :meth:`Panel.group`. They are the three
#: the Acrome courseware models use to separate one bank of controls from
#: the next, kept here so a panel that mirrors a model does not have to
#: carry hex codes around: cream for the mode, lavender for the machine's
#: own switches, sky for the one switch that starts the control law.
GROUP_CREAM = "#fef7e8"
GROUP_LAVENDER = "#e6e6ff"
GROUP_SKY = "#e6f5ff"

#: How often the panel reads the board, in milliseconds. Fast enough to
#: look live, slow enough that a Python loop and a paint pass are never
#: the reason a control feels heavy. The board's own rate is unaffected:
#: it samples at the diagram's rate whatever this is, and the panel reads
#: the NEWEST batch, so a slower panel shows fresher data, never older.
DEFAULT_REFRESH_MS = 50

#: How many points each curve keeps. At the default refresh that is a
#: 30-second window, which is what a person watching a step response
#: wants to see. Bounded on purpose: an unbounded trace is a memory leak
#: with a graph in front of it.
DEFAULT_HISTORY = 600

#: What a plot is drawn on. A plot sits in the same light window as the
#: controls, and the curve package's own default is a black rectangle
#: with white text, which on that window reads as a screen that failed
#: to start rather than as a graph waiting for its first reading, and
#: prints as a black block. White paper also gives a printed or
#: projected trace its contrast back, which matters in a lecture room.
PLOT_PAPER = "#ffffff"

#: The ink for a plot's title, axes, tick numbers and legend text. Dark
#: slate rather than pure black: it sits on white without the hard edge
#: of black-on-white and matches the panel's own text.
PLOT_INK = "#3a4256"

#: How strongly the grid is drawn, 0 to 1. Enough to read a value off,
#: not enough to compete with the curve.
PLOT_GRID_ALPHA = 0.25

#: The colours curves are drawn in, in order, reused from the start when
#: a plot has more curves than this. Every one of them is legible on the
#: white paper above and stays distinguishable in greyscale print.
PLOT_CURVE_COLORS = (
    "#002D72",   # deep blue
    "#C97906",   # burnt orange
    "#1B7F70",   # teal
    "#4A3B8C",   # violet
    "#C83D47",   # red
    "#55942B",   # green
    "#7C8A99",   # slate
)

#: How thick a curve is drawn, in pixels. A one-pixel trace disappears
#: on a projector and in print.
PLOT_CURVE_WIDTH = 1.6


class PanelError(RuntimeError):
    """The panel cannot be built or run, and the message says why."""


def gui_is_available() -> bool:
    """True when this interpreter can draw a window.

    Worth asking before :meth:`Panel.run` in a script that has a useful
    non-graphical path, so it can take that path instead of failing.
    """
    try:
        import PyQt6.QtWidgets                             # noqa: F401
    except Exception:                                      # noqa: BLE001
        return False
    return True


#: The painted widget classes, built once the toolkit is known. They
#: cannot be written at module scope: this module is imported by scripts
#: on machines with no GUI toolkit at all, and a class deriving from a Qt
#: widget would need it at import time. See :func:`_require_gui`.
_KIT = None


def _widget_kit(QtCore, QtGui, QtWidgets):
    """The two hand-drawn switches, as the courseware's models draw them.

    The toolkit has no switch. A checkbox is not one (it is a tick), and
    a two-position slider is the very thing these exist to replace, so
    the capsule and the rocker are painted here.
    """
    global _KIT
    if _KIT is not None:
        return _KIT

    #: A mid-grey track with a darker outline and a pale knob, matched to
    #: how the courseware's switches are DRAWN. Their files store no
    #: colour for a switch, so these are read off the rendered control
    #: rather than copied from a stored value; the panel background
    #: colours, which the files do store, are the module constants above.
    TRACK = QtGui.QColor("#9b9b9b")
    TRACK_ON = QtGui.QColor("#7f9dc8")
    EDGE = QtGui.QColor("#6f6f6f")
    KNOB = QtGui.QColor("#dcdcdc")

    class _TwoState(QtWidgets.QAbstractButton):
        """A capsule track with a knob at one end or the other.

        Horizontal reads off to the left, on to the right, the way a
        slider switch does. Vertical is a rocker: thrown up is the on
        state, thrown down the off one.
        """

        def __init__(self, horizontal: bool = True, parent=None) -> None:
            super().__init__(parent)
            self.setCheckable(True)
            self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
            self._horizontal = bool(horizontal)
            self.setFixedSize(QtCore.QSize(76, 32) if horizontal
                              else QtCore.QSize(32, 66))
            self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)

        def paintEvent(self, _event):                      # noqa: N802
            painter = QtGui.QPainter(self)
            painter.setRenderHint(
                QtGui.QPainter.RenderHint.Antialiasing, True)
            box = QtCore.QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
            radius = (box.height() if self._horizontal else box.width()) / 2.0
            painter.setPen(QtGui.QPen(EDGE, 1.4))
            painter.setBrush(TRACK_ON if self.isChecked() else TRACK)
            painter.drawRoundedRect(box, radius, radius)

            size = (box.height() if self._horizontal else box.width()) - 6.0
            if self._horizontal:
                x = (box.right() - 3.0 - size) if self.isChecked() \
                    else (box.left() + 3.0)
                y = box.top() + 3.0
            else:
                x = box.left() + 3.0
                y = (box.top() + 3.0) if self.isChecked() \
                    else (box.bottom() - 3.0 - size)
            painter.setBrush(KNOB)
            painter.setPen(QtGui.QPen(EDGE, 1.2))
            painter.drawEllipse(QtCore.QRectF(x, y, size, size))
            if self.hasFocus():
                painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
                painter.setPen(QtGui.QPen(QtGui.QColor("#3b6ea5"), 1.0,
                                          QtCore.Qt.PenStyle.DotLine))
                painter.drawRoundedRect(box.adjusted(-1, -1, 1, 1),
                                        radius, radius)

    _KIT = {"TwoState": _TwoState}
    return _KIT


def _require_gui():
    """Import the GUI toolkit, or explain what to do about it.

    The advice matters more than the exception. A missing toolkit is not
    a broken installation, it is a package that has not been added yet,
    and the Source Editor installs packages for you.
    """
    try:
        from PyQt6 import QtCore, QtGui, QtWidgets
    except Exception as exc:                               # noqa: BLE001
        raise PanelError(
            "This panel needs the PyQt6 package and it is not installed "
            "for the Python running this script. In PAPAYA Studio open "
            "the Source Editor and use Packages to add PyQt6, then run "
            "this again. Original error: " + str(exc)
        ) from exc
    return QtCore, QtGui, QtWidgets


class _Control:
    """One row of the panel: a widget, and what it reads or writes."""

    __slots__ = ("kind", "name", "widget", "label", "low", "high",
                 "decimals", "callback", "curves", "names",
                 "start", "writes_on_open",
                 # A two-state control: the two values it writes and the
                 # words beside them. A state is not a position on a
                 # scale, so it does not borrow ``low``/``high``.
                 "on_value", "off_value", "on_label", "off_label",
                 # A choice: (label, value) pairs, and the frame's title.
                 "options", "group_name",
                 # A group: its background colour.
                 "color")

    def __init__(self, kind: str, name: str = "") -> None:
        self.kind = kind
        self.name = name
        self.widget = None
        self.label = None
        self.low = 0.0
        self.high = 1.0
        self.decimals = 3
        self.callback: Optional[Callable] = None
        self.curves: List = []
        self.names: List[str] = []
        #: Where the control is parked when the panel opens, which is
        #: not the same thing as a value to send.
        self.start = 0.0
        self.writes_on_open = False
        self.on_value = 1.0
        self.off_value = 0.0
        self.on_label = "On"
        self.off_label = "Off"
        self.options: List[Tuple[str, float]] = []
        self.group_name = ""
        self.color = ""


class Panel:
    """A window of controls and readouts bound to the board's design.

    Building one attaches to the board, so the names you can use are
    known before the window exists and a typo is reported when you make
    it rather than when the panel first refreshes.
    """

    def __init__(self, title: str = "PAPAYA panel", *,
                 design: Optional[RemoteDesign] = None,
                 refresh_ms: int = DEFAULT_REFRESH_MS,
                 history: int = DEFAULT_HISTORY) -> None:
        #: The design the panel drives. Passed in by a script that has
        #: already attached (so the two do not fight over the link), or
        #: attached here for a script that has not.
        #: Whoever opened the link is the one who closes it.
        self._owns_design = design is None
        self.design: RemoteDesign = design if design is not None else attach()
        #: This panel's own event loop while it is running, so it can end
        #: itself without ending a host application's loop.
        self._loop = None
        self.title = str(title or "PAPAYA panel")
        self.refresh_ms = max(10, int(refresh_ms))
        #: How long one refresh waits for a batch. SHORT ON PURPOSE, and
        #: much shorter than the refresh period. The read blocks the
        #: window while it waits, and the board sends a batch every few
        #: tens of milliseconds, so a poll that waited a whole period
        #: would leave the controls feeling heavy on every tick that
        #: happened to fall between batches, for nothing: the next tick
        #: is along in a moment either way.
        self._read_timeout_ms = max(1, min(10, self.refresh_ms))
        self.history = max(2, int(history))
        self._controls: List[_Control] = []
        self._pending_writes: Dict[str, float] = {}
        self._started = False
        self._closing = False
        self._t0 = 0.0
        self._times: List[float] = []
        self._series: Dict[str, List[float]] = {}
        self._on_tick: Optional[Callable[[Dict[str, float]], None]] = None
        self._last_values: Dict[str, float] = {}
        #: Every value this panel has actually sent, by name. See
        #: :meth:`input_value` for why the design's own list cannot serve.
        self._written: Dict[str, float] = {}

    # -- describing the panel ------------------------------------------
    def slider(self, input_name: str, low: float, high: float,
               value: Optional[float] = None, *,
               label: str = "", ticks: Optional[float] = None) -> "Panel":
        """A control that writes one of the design's remote inputs.

        Dragging it writes; releasing it writes nothing extra. The value
        goes out on the next refresh tick together with any other control
        moved in the same tick, as one transfer.

        OPENING A PANEL WRITES NOTHING. The slider starts where the board
        already is, and until you move it nothing is sent. That is not a
        detail: the control has a thousand steps across its range, so
        merely showing the board's own value would round it to the
        nearest step and send that back. Measured before this was fixed,
        a board holding 0.5 with a slider from 0 to 3 was written 0.501
        on the first refresh, and a board holding a value outside the
        slider's range was dragged to the nearest end of it. On a running
        rig that is a step nobody asked for.

        Pass *value* to write one deliberately on the first refresh.

        *ticks* draws a numbered scale under the control, one mark every
        *ticks* units. A setpoint slider that runs from -300 to 300 mm is
        far easier to set to -150 with the scale under it than without,
        which is why the courseware's own sliders carry one.
        """
        self._require_input(input_name)
        if float(high) == float(low):
            raise PanelError(
                f"slider({input_name!r}) was given the same value for its "
                f"low and high ends ({low}). Give it a range to move over, "
                f"or use panel.set({input_name!r}, {low}) for a fixed value.")
        c = _Control("slider", input_name)
        c.low, c.high = float(low), float(high)
        c.label = str(label or input_name)
        c.decimals = 3
        if ticks is not None and float(ticks) <= 0:
            raise PanelError(
                f"slider({input_name!r}) was given a tick spacing of "
                f"{ticks}; it must be above zero.")
        c.options = [] if ticks is None else [("tick", float(ticks))]
        if value is None:
            # Where to PARK the control, which is not the same as a
            # value to send.
            c.start = self._current_input_value(input_name, c.low, c.high)
            c.writes_on_open = False
        else:
            c.start = float(value)
            c.writes_on_open = True
            self._pending_writes[input_name] = float(value)
        self._controls.append(c)
        return self

    def switch(self, input_name: str, *, label: str = "",
               on_label: str = "On", off_label: str = "Off",
               on_value: float = 1.0, off_value: float = 0.0,
               value: Optional[float] = None) -> "Panel":
        """A two-state switch, for an input that has two states.

        WHY THIS EXISTS RATHER THAN A SLIDER. An input that means on or
        off is not a quantity, and drawing it as a slider gets three
        things wrong at once: it offers a thousand positions where two
        exist, it shows a number where a state belongs, and it cannot say
        which end is which. A person looking at ``enable`` at 0.37 cannot
        tell whether the motor is live. The switch has exactly the two
        states the design has, writes exactly the two values it accepts,
        and says in words which one it is in.

        Drawn the way the courseware's own models draw it: a capsule
        track with a round knob, the off word to the left and the on word
        to the right.

        *on_value* and *off_value* are what actually reaches the board,
        so an input whose states are 1 and 2, or 0 and -1, is still a
        switch. Opening the panel writes nothing: the switch starts in
        whichever state the board is already in, and only a press writes.
        Pass *value* to write one deliberately on the first refresh.
        """
        self._require_input(input_name)
        if float(on_value) == float(off_value):
            raise PanelError(
                f"switch({input_name!r}) was given the same value for both "
                f"states ({on_value}). A switch needs two values to choose "
                f"between; for a fixed value use "
                f"panel.set({input_name!r}, {on_value}).")
        if value is not None and float(value) not in (
                float(on_value), float(off_value)):
            raise PanelError(
                f"switch({input_name!r}, value={value}) is not one of the two "
                f"states this switch has ({off_value} and {on_value}). The "
                f"control would show one state and the board would hold "
                f"another; use panel.set({input_name!r}, {value}) if that is "
                f"really what you mean.")
        c = _Control("switch", input_name)
        c.label = str(label or input_name)
        c.on_label, c.off_label = str(on_label), str(off_label)
        c.on_value, c.off_value = float(on_value), float(off_value)
        c.start = self._nearest_state(
            input_name, (c.off_value, c.on_value)) if value is None \
            else float(value)
        c.writes_on_open = value is not None
        if c.writes_on_open:
            self._pending_writes[input_name] = float(value)
        self._controls.append(c)
        return self

    def rocker(self, input_name: str, *, label: str = "",
               up_label: str = "1", down_label: str = "0",
               up_value: float = 1.0, down_value: float = 0.0,
               value: Optional[float] = None) -> "Panel":
        """A two-state switch stood on end, thrown up or down.

        The same control as :meth:`switch` and the same rules; what
        differs is the picture. A rocker is what a model uses for a
        switch that stands for a physical one on the machine (a limit
        switch, a rocker on a panel), where up and down mean something to
        the person looking at the rig rather than on and off.
        """
        self._require_input(input_name)
        if float(up_value) == float(down_value):
            raise PanelError(
                f"rocker({input_name!r}) was given the same value for both "
                f"positions ({up_value}). A rocker needs two values to "
                f"choose between.")
        c = _Control("rocker", input_name)
        c.label = str(label or input_name)
        c.on_label, c.off_label = str(up_label), str(down_label)
        c.on_value, c.off_value = float(up_value), float(down_value)
        c.start = self._nearest_state(
            input_name, (c.off_value, c.on_value)) if value is None \
            else float(value)
        c.writes_on_open = value is not None
        if c.writes_on_open:
            self._pending_writes[input_name] = float(value)
        self._controls.append(c)
        return self

    def choice(self, input_name: str,
               options: Iterable[Any], *,
               label: str = "", group_name: str = "") -> "Panel":
        """One of a fixed set of named states, as radio buttons.

        For an input that selects a MODE. Like :meth:`switch` this exists
        because the states are named things, not points on a scale: a
        mode selector drawn as a slider reads "0.5" when the design has
        no such mode at all.

        *options* is a sequence of ``(label, value)`` pairs, or a mapping
        of label to value. The order given is the order shown.

            ui.choice("mode", [("Initialize", 0.0),
                               ("Position Control", 1.0)])
        """
        self._require_input(input_name)
        pairs: List[Tuple[str, float]] = []
        items = options.items() if isinstance(options, dict) else options
        for item in items:
            try:
                text, value = item
            except (TypeError, ValueError):
                raise PanelError(
                    f"choice({input_name!r}) needs (label, value) pairs; got "
                    f"{item!r}. For example: "
                    f"[('Initialize', 0.0), ('Run', 1.0)].") from None
            pairs.append((str(text), float(value)))
        if len(pairs) < 2:
            raise PanelError(
                f"choice({input_name!r}) needs at least two options; got "
                f"{len(pairs)}. For a single fixed value use "
                f"panel.set({input_name!r}, ...).")
        c = _Control("choice", input_name)
        c.label = str(label or input_name)
        c.options = pairs
        c.group_name = str(group_name)
        c.start = self._nearest_state(input_name, [v for _t, v in pairs])
        c.writes_on_open = False
        self._controls.append(c)
        return self

    def field(self, input_name: str, *, label: str = "",
              digits: int = 6, low: Optional[float] = None,
              high: Optional[float] = None,
              value: Optional[float] = None) -> "Panel":
        """A number you type in and commit with Enter.

        For a value that is CHOSEN rather than swept: a gain, a trim, a
        setpoint read off a calculation. A slider cannot express those
        honestly, because it has to invent a range, and the range then
        decides what the user is allowed to enter. The courseware's own
        models use a typed field for every gain for this reason.

        Nothing is written while you type. The value goes out when you
        press Enter or leave the box, so a half-typed number never
        reaches the board. *low* and *high*, when given, are enforced on
        commit and reported in words rather than silently clamped.

        *digits* is SIGNIFICANT FIGURES, deliberately not the *decimals*
        that :meth:`number` and :meth:`slider` take. A readout of a
        measured quantity wants a fixed number of places so the column
        does not jitter; a gain wants its value shown as written, and
        114.474 with six decimal places is 114.474000, which reads like a
        precision nobody claimed. Two names because they are two things.
        """
        self._require_input(input_name)
        if low is not None and high is not None and float(low) > float(high):
            raise PanelError(
                f"field({input_name!r}) was given low {low} above high "
                f"{high}.")
        c = _Control("field", input_name)
        c.label = str(label or input_name)
        # Stored in the same slot the other controls use for their own
        # number format; what differs is how the field spells it (g, not f).
        c.decimals = max(1, int(digits))
        c.low = None if low is None else float(low)
        c.high = None if high is None else float(high)
        if value is None:
            c.start = self._input_value_now(input_name)
            c.writes_on_open = False
        else:
            c.start = float(value)
            c.writes_on_open = True
            self._pending_writes[input_name] = float(value)
        self._controls.append(c)
        return self

    @contextlib.contextmanager
    def group(self, title: str = "", *, color: str = ""):
        """Put the controls made inside this block in one titled panel.

            with ui.group("Machine", color=panel.GROUP_LAVENDER):
                ui.switch("enable")
                ui.switch("home")

        Grouping is not decoration: it is what tells the operator which
        switches belong to the same decision. *color* takes any Qt colour
        name; the three the courseware uses are module constants.
        """
        begin = _Control("group_begin")
        begin.label = str(title)
        begin.color = str(color)
        self._controls.append(begin)
        try:
            yield self
        finally:
            self._controls.append(_Control("group_end"))

    def number(self, *probe_names: str, decimals: int = 3,
               labels: Optional[Sequence[str]] = None) -> "Panel":
        """A live numeric readout of one or more probes.

        *labels* renames the displays without renaming the probes, one
        label per name in the order given. A probe is called what the
        design calls it, which is not always what the panel should say:
        a display over ``cal_max`` reads better, and matches the
        courseware, as "Max Value".
        """
        names = list(probe_names)
        if labels is not None:
            labels = [str(t) for t in labels]
            if len(labels) != len(names):
                raise PanelError(
                    f"number() was given {len(names)} probe(s) and "
                    f"{len(labels)} label(s); there must be one label per "
                    f"probe, in the same order.")
        for i, name in enumerate(names):
            self._require_probe(name)
            c = _Control("number", name)
            c.decimals = int(decimals)
            c.label = labels[i] if labels is not None else name
            self._controls.append(c)
        return self

    def plot(self, *probe_names: str, label: str = "") -> "Panel":
        """A rolling curve per probe, on one set of axes.

        Every probe named here must exist on the board. Several plots are
        allowed; they share the one read per tick.
        """
        for name in probe_names:
            self._require_probe(name)
        c = _Control("plot")
        c.names = [str(n) for n in probe_names]
        c.label = str(label or ", ".join(c.names))
        self._controls.append(c)
        return self

    def button(self, text: str, action: Callable[[], None]) -> "Panel":
        """A button that runs your own function when pressed.

        The function runs on the panel's thread, so keep it short: a
        write, a state change, a print. Anything that blocks stops the
        panel refreshing, and a panel that has stopped refreshing looks
        exactly like a board that has stopped answering.
        """
        c = _Control("button")
        c.label = str(text)
        c.callback = action
        self._controls.append(c)
        return self

    def every_tick(self, action: Callable[[Dict[str, float]], None]) -> "Panel":
        """Run *action* with the newest probe values on every refresh.

        This is where a decision goes: read the values, decide, and write
        with :meth:`set`. It is the panel's equivalent of the loop in a
        plain interaction script, minus the sleeping and the timing.

        Every refresh, not every batch: on a refresh where no new batch
        arrived, *action* still runs, with the values of the last one.
        It does not run before the first batch, because there is nothing
        to decide on yet.
        """
        self._on_tick = action
        return self

    # -- driving it from your own code ---------------------------------
    def set(self, input_name: str, value: float) -> None:
        """Write an input from your code, as a control would.

        Queued and sent with the tick's other writes, so a rule that
        moves two inputs together moves them together on the board.
        """
        self._require_input(input_name)
        self._pending_writes[str(input_name)] = float(value)

    def input_value(self, input_name: str) -> float:
        """The value this panel last put on *input_name*.

        NOT ``design.input_values``, which is a snapshot taken when the
        design was described and never moves again: code that asked it
        what a control had been set to read the attach-time value on
        every tick, forever, and any rule written on top of it silently
        never fired.

        Answers, in order: a value moved this tick and not yet sent, then
        the last value this panel sent, then what the board reported when
        the panel attached. Reading an input this panel has never touched
        is therefore still honest rather than zero.
        """
        self._require_input(input_name)
        name = str(input_name)
        if name in self._pending_writes:
            return float(self._pending_writes[name])
        if name in self._written:
            return float(self._written[name])
        return self._input_value_now(name)

    @property
    def values(self) -> Dict[str, float]:
        """The newest probe values the panel read, keyed by name."""
        return dict(self._last_values)

    def describe(self) -> str:
        """What the board is offering, straight from the board."""
        return self.design.describe()

    # -- running it -----------------------------------------------------
    def run(self) -> None:
        """Show the window and run until it is closed or interrupted.

        Blocks. The design is started on the way in and stopped on the
        way out, whichever way the exit happens: a closed window, a
        Ctrl+C, an exception out of your own function, or a board that
        stops answering. If any of those leaves the board streaming, the
        NEXT run of anything is the thing that suffers, which is why the
        stop is on the way out of a ``finally`` and why nothing inside
        this panel is allowed to end the process on its own.
        """
        QtCore, QtGui, QtWidgets = _require_gui()

        # A PANEL MAY BE RUN MORE THAN ONCE. The closing latch is per
        # run, not per panel: left set from a previous run it would let
        # start() put the board back into streaming and then refuse to
        # stop it, which is the worst of both.
        self._closing = False

        app = QtWidgets.QApplication.instance()
        # STANDING RULE: never let the QApplication be garbage collected.
        # A constructor whose result is dropped takes the process down
        # with no traceback and no exit message.
        owns_app = app is None
        if owns_app:
            app = QtWidgets.QApplication(sys.argv or ["papaya-panel"])

        window = self._build(QtCore, QtGui, QtWidgets)
        self.design.start()
        self._started = True
        self._t0 = time.monotonic()

        timer = QtCore.QTimer()
        timer.timeout.connect(lambda: self._tick(QtCore))
        timer.start(self.refresh_ms)

        # ITS OWN EVENT LOOP, not the application's.
        #
        # ``QApplication.exec()`` returns -1 at once when a loop is
        # already running on this thread, which happens whenever a panel
        # is opened from a program that already has a window of its own.
        # The panel then started the board, saw the call return
        # immediately, stopped it again and left a dead window on
        # screen. Worse, quitting on the way out quit the HOST's loop and
        # took its window with it. A loop of this panel's own nests
        # correctly and quits only itself.
        self._loop = QtCore.QEventLoop()
        window.show()
        try:
            self._loop.exec()
        except KeyboardInterrupt:
            pass
        finally:
            timer.stop()
            self.close()
            self._loop = None
            # The window goes before the application does: destroying a
            # QApplication while a top-level widget is still alive is the
            # classic exit crash.
            window.deleteLater()
            window = None
        del app

    def _leave(self) -> None:
        """Stop the design and end this panel's loop, from anywhere."""
        self.close()
        loop = self._loop
        if loop is not None:
            try:
                loop.quit()
            except Exception:                              # noqa: BLE001
                pass

    def close(self) -> None:
        """Stop the design and hand the board back. Safe to call twice."""
        if self._closing:
            return
        self._closing = True
        try:
            if self._started:
                self.design.stop()
        except Exception as exc:                           # noqa: BLE001
            # A stop that raises must not stop the release below, and it
            # must not be silent: this is the message that explains why
            # the next run finds a busy board.
            print(f"[panel] the board did not confirm the stop: {exc}. If "
                  f"the next program cannot reach it, unplug it and plug "
                  f"it back in.", flush=True)
        finally:
            self._started = False
            if self._owns_design:
                # Attached by this panel, so released by it. A panel
                # handed a design it did not open leaves that caller's
                # link alone.
                try:
                    self.design.close()
                except Exception:                          # noqa: BLE001
                    pass

    def __enter__(self) -> "Panel":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    # -- internals ------------------------------------------------------
    def _require_input(self, name: str) -> None:
        if str(name) not in self.design.input_names:
            offered = ", ".join(self.design.input_names) or "(none)"
            raise PanelError(
                f"this design has no remote input named {name!r}. It "
                f"offers: {offered}. Remote inputs are the INPUT blocks "
                f"you ticked as remotely writable in the diagram.")

    def _require_probe(self, name: str) -> None:
        if str(name) not in self.design.probe_names:
            offered = ", ".join(self.design.probe_names) or "(none)"
            raise PanelError(
                f"this design has no probe named {name!r}. It offers: "
                f"{offered}.")

    def _input_value_now(self, name: str) -> float:
        """What the board says this input holds, or 0.0 if it cannot say."""
        try:
            idx = self.design.input_names.index(name)
            return float(self.design.input_values[idx])
        except (ValueError, IndexError, TypeError):
            return 0.0

    def _nearest_state(self, name: str, states: Sequence[float]) -> float:
        """The state the board is closest to being in.

        A two-state control cannot park "between", so it parks on the
        state nearest what the board holds. Nearest rather than exact
        because an input the design left at 0.9999 is on, and a control
        that refused to admit it would show the wrong state.
        """
        value = self._input_value_now(name)
        return min(states, key=lambda s: abs(value - float(s)))

    def _current_input_value(self, name: str, low: float, high: float) -> float:
        try:
            idx = self.design.input_names.index(name)
            value = float(self.design.input_values[idx])
        except (ValueError, IndexError, TypeError):
            value = 0.0
        return min(max(value, min(low, high)), max(low, high))

    def _titled_for_the_link(self) -> str:
        """The window title, saying so when the board is simulated.

        Never raises and never blocks: a title is not worth a failure,
        so a link that cannot be asked simply gives the plain title.
        """
        try:
            from papaya.usb_transport import board_is_simulated
            if board_is_simulated():
                return f"{self.title}  -  simulated board, no hardware"
        except Exception:
            pass
        return str(self.title)

    def _build(self, QtCore, QtGui, QtWidgets):
        panel = self

        class _PanelWindow(QtWidgets.QWidget):
            """A window that ends its own panel when it is closed.

            CLOSING, NOT DESTRUCTION. This used to hang off the
            ``destroyed`` signal, which is wrong twice over. It does not
            fire when a window is closed, only when Qt finally deletes
            the object, so closing the window did not stop the design at
            all; and when it did fire, it fired late. Running the same
            panel a second time collected the FIRST window during the
            SECOND run, and its handler then closed the panel that was
            still going: every refresh returned early and the program
            hung with the board streaming.
            """

            def closeEvent(self, event):                   # noqa: N802
                panel._leave()
                super().closeEvent(event)

        window = _PanelWindow()
        # SAY IT IN THE TITLE BAR WHEN THERE IS NO BOARD.
        #
        # A panel driving a simulated board looks exactly like a panel
        # driving the bench: same controls, same plots, same numbers
        # moving. The link says which it is and the console line saying
        # so scrolls away in a second, so the one place the answer stays
        # put is the window's own name.
        window.setWindowTitle(self._titled_for_the_link())
        # The controls and plots live on a content widget inside a scroll
        # area, not directly on the window. Without this the sum of every
        # row's height becomes the window's smallest size, so a tall panel
        # cannot be shrunk and opens taller than the screen with its lowest
        # plots off the bottom. In the scroll area a short window shows a
        # scrollbar instead of clipping, and a tall one stretches the plots.
        content = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(content)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)

        header = QtWidgets.QLabel(
            f"{len(self.design.probe_names)} probe(s), "
            f"{len(self.design.input_names)} writable input(s), "
            f"{self.design.fs:g} Hz on the board")
        outer.addWidget(header)

        # A stack, because a group holds controls: everything made
        # between group() opening and closing goes inside its frame.
        stack = [outer]
        for c in self._controls:
            target = stack[-1]
            if c.kind == "group_begin":
                box = QtWidgets.QGroupBox(str(c.label))
                if c.color:
                    box.setStyleSheet(
                        "QGroupBox { background-color: %s; border: 1px solid "
                        "#b9b9c8; border-radius: 5px; margin-top: 9px; "
                        "padding: 10px 8px 8px 8px; }"
                        "QGroupBox::title { subcontrol-origin: margin; "
                        "left: 9px; padding: 0 4px; }" % c.color)
                inner = QtWidgets.QVBoxLayout(box)
                inner.setSpacing(8)
                target.addWidget(box)
                stack.append(inner)
                continue
            if c.kind == "group_end":
                if len(stack) > 1:
                    stack.pop()
                continue
            if c.kind == "slider":
                target.addLayout(self._build_slider(c, QtCore, QtWidgets))
            elif c.kind in ("switch", "rocker"):
                target.addLayout(
                    self._build_two_state(c, QtCore, QtGui, QtWidgets))
            elif c.kind == "choice":
                target.addWidget(self._build_choice(c, QtWidgets))
            elif c.kind == "field":
                target.addLayout(self._build_field(c, QtCore, QtWidgets))
            elif c.kind == "number":
                target.addLayout(self._build_number(c, QtWidgets))
            elif c.kind == "button":
                target.addWidget(self._build_button(c, QtWidgets))
            elif c.kind in ("plot", "number_group"):
                # number_group is what a plot becomes when the curve
                # package is missing; a second run has to build it too.
                widget = self._build_plot(c, QtGui, QtWidgets)
                if widget is not None:
                    target.addWidget(widget, 1)

        outer.addStretch(0)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(content)
        shell = QtWidgets.QVBoxLayout(window)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.addWidget(scroll)

        # Never narrower than the column of controls needs, so the horizontal
        # bar (kept off above) is never asked for and nothing is clipped
        # sideways. The vertical bar's width is part of that floor.
        bar_w = scroll.verticalScrollBar().sizeHint().width()
        window.setMinimumWidth(content.minimumSizeHint().width() + bar_w)
        window.setMinimumHeight(min(240, content.minimumSizeHint().height()))

        # Open large enough to show the content but never past the screen's
        # own work area, so every panel arrives fully on screen whatever its
        # height. A rich panel opens near full height; a small one at its
        # natural size. Below this the scroll area takes over, so nothing is
        # ever lost.
        screen = window.screen() or QtWidgets.QApplication.primaryScreen()
        hint = content.sizeHint()
        want_w = max(hint.width() + bar_w, 560)
        want_h = hint.height() + 24
        avail = screen.availableGeometry() if screen is not None else None
        # Only clamp against a real screen; an offscreen/headless platform can
        # report a tiny or empty work area, and clamping to that would open the
        # panel uselessly small.
        if avail is not None and avail.width() > 400 and avail.height() > 300:
            want_w = min(want_w, int(avail.width() * 0.9))
            want_h = min(want_h, int(avail.height() * 0.9))
        window.resize(max(want_w, 400), max(want_h, 240))
        return window

    def _build_slider(self, c, QtCore, QtWidgets):
        row = QtWidgets.QHBoxLayout()
        caption = QtWidgets.QLabel(str(c.label))
        caption.setMinimumWidth(110)
        row.addWidget(caption)

        # An integer slider over a float range: the toolkit's sliders are integers,
        # so the range is divided into 1000 steps. Named rather than
        # hidden, because it is the resolution the user actually gets.
        steps = 1000
        slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        slider.setRange(0, steps)
        readout = QtWidgets.QLabel("")
        readout.setMinimumWidth(80)

        span = (c.high - c.low) or 1.0

        def to_value(pos: int) -> float:
            return c.low + (float(pos) / steps) * span

        # True only while this code is placing the control, so putting it
        # where the board already is does not count as the user moving
        # it. Without this the panel wrote on open, rounded to the
        # nearest of its thousand steps.
        parking = {"now": True}

        def on_move(pos: int) -> None:
            try:
                value = to_value(pos)
                readout.setText(f"{value:+.{c.decimals}f}")
                if not parking["now"]:
                    self._pending_writes[c.name] = value
            except BaseException:                          # noqa: BLE001
                # A Qt callback again: nothing may escape, or the process
                # ends here with the board still streaming.
                print("[panel] the slider could not be moved:", flush=True)
                traceback.print_exc()

        slider.valueChanged.connect(on_move)
        start = float(getattr(c, "start", c.low))
        if start != start:                                 # NaN
            print(f"[panel] the board reported no usable value for "
                  f"{c.name!r}, so its control starts at {c.low:g}.",
                  flush=True)
            start = c.low
        slider.setValue(int(round((start - c.low) / span * steps)))
        on_move(slider.value())
        parking["now"] = False

        row.addWidget(slider, 1)
        row.addWidget(readout)
        c.widget = slider

        spacing = float(c.options[0][1]) if c.options else 0.0
        if spacing <= 0:
            return row

        # A NUMBERED scale, not the toolkit's bare tick marks: it draws
        # ticks but writes no numbers beside them, and the numbers are the
        # reason the scale is there.
        slider.setTickPosition(
            QtWidgets.QSlider.TickPosition.TicksBelow)
        slider.setTickInterval(max(1, int(round(spacing / span * steps))))

        column = QtWidgets.QVBoxLayout()
        column.setSpacing(1)
        column.addLayout(row)
        scale = QtWidgets.QHBoxLayout()
        scale.setContentsMargins(0, 0, 0, 0)
        scale.addSpacing(caption.minimumWidth() + 6)
        first = c.low - (c.low % spacing) + (spacing if c.low % spacing else 0)
        marks = []
        mark = first
        while mark <= c.high + 1e-9 and len(marks) < 64:
            marks.append(mark)
            mark += spacing
        for i, mark in enumerate(marks):
            text = QtWidgets.QLabel(f"{mark:g}")
            text.setStyleSheet("color: #55607a; font-size: 10px;")
            text.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            scale.addWidget(text, 1)
            if i < len(marks) - 1:
                scale.addStretch(0)
        scale.addSpacing(readout.minimumWidth() + 6)
        column.addLayout(scale)
        return column

    def _build_two_state(self, c, QtCore, QtGui, QtWidgets):
        """A switch or a rocker: the title above, the words either side."""
        kit = _widget_kit(QtCore, QtGui, QtWidgets)
        horizontal = c.kind == "switch"
        column = QtWidgets.QVBoxLayout()
        column.setSpacing(4)

        caption = QtWidgets.QLabel(str(c.label))
        caption.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        column.addWidget(caption)

        button = kit["TwoState"](horizontal=horizontal)
        off = QtWidgets.QLabel(str(c.off_label))
        on = QtWidgets.QLabel(str(c.on_label))

        if horizontal:
            row = QtWidgets.QHBoxLayout()
            row.setSpacing(8)
            row.addStretch(1)
            row.addWidget(off)
            row.addWidget(button)
            row.addWidget(on)
            row.addStretch(1)
            column.addLayout(row)
        else:
            # A rocker is read top to bottom: thrown up is the on state.
            for widget, align in ((on, "top"), (button, "mid"), (off, "bot")):
                holder = QtWidgets.QHBoxLayout()
                holder.addStretch(1)
                holder.addWidget(widget)
                holder.addStretch(1)
                column.addLayout(holder)

        # Which word is the state it is IN. The knob says it too, but the
        # knob is small, so the live word is emphasised as well. Nothing
        # else about the picture changes.
        def show_state(checked: bool) -> None:
            on.setStyleSheet("font-weight: 600;" if checked else "")
            off.setStyleSheet("" if checked else "font-weight: 600;")

        parking = {"now": True}

        def toggled(checked: bool) -> None:
            try:
                show_state(bool(checked))
                if not parking["now"]:
                    self._pending_writes[c.name] = (
                        c.on_value if checked else c.off_value)
            except BaseException:                          # noqa: BLE001
                # A Qt callback: nothing may escape, or the process ends
                # with the board still streaming.
                print(f"[panel] the {c.label!r} switch could not be "
                      f"thrown:", flush=True)
                traceback.print_exc()

        button.toggled.connect(toggled)
        button.setChecked(float(c.start) == float(c.on_value))
        show_state(button.isChecked())
        parking["now"] = False
        c.widget = button
        return column

    def _build_choice(self, c, QtWidgets):
        """A radio group: the title above, one button per named state."""
        outer = QtWidgets.QGroupBox(str(c.label))
        layout = QtWidgets.QVBoxLayout(outer)
        layout.setSpacing(4)

        inner_parent = layout
        if c.group_name:
            frame = QtWidgets.QGroupBox(str(c.group_name))
            inner_parent = QtWidgets.QVBoxLayout(frame)
            inner_parent.setSpacing(4)
            layout.addWidget(frame)

        parking = {"now": True}
        buttons = []
        for text, value in c.options:
            radio = QtWidgets.QRadioButton(str(text))

            def chosen(checked, _value=value):
                try:
                    if checked and not parking["now"]:
                        self._pending_writes[c.name] = float(_value)
                except BaseException:                      # noqa: BLE001
                    print(f"[panel] the {c.label!r} choice could not be "
                          f"made:", flush=True)
                    traceback.print_exc()

            radio.toggled.connect(chosen)
            inner_parent.addWidget(radio)
            buttons.append((radio, float(value)))

        for radio, value in buttons:
            if value == float(c.start):
                radio.setChecked(True)
                break
        else:
            if buttons:
                buttons[0][0].setChecked(True)
        parking["now"] = False
        c.widget = outer
        c.curves = [r for r, _v in buttons]
        return outer

    def _build_field(self, c, QtCore, QtWidgets):
        """A typed number, committed with Enter or by leaving the box."""
        row = QtWidgets.QHBoxLayout()
        caption = QtWidgets.QLabel(str(c.label))
        caption.setMinimumWidth(110)
        row.addWidget(caption)

        edit = QtWidgets.QLineEdit()
        edit.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        edit.setStyleSheet(
            "QLineEdit { background: #ffffff; border: 1px solid #9b9b9b; "
            "border-radius: 3px; padding: 3px 6px; }")
        edit.setText(f"{float(c.start):.{c.decimals}g}")
        note = QtWidgets.QLabel("")
        note.setStyleSheet("color: #a33;")

        # WHAT THE BOX ALREADY SAYS, so that neither of the two signals
        # below can write when nothing was typed. Qt emits BOTH
        # returnPressed and editingFinished for one press of Enter, and
        # editingFinished again whenever focus merely leaves the box. With
        # both wired straight to the commit, one press wrote twice, and the
        # second write was the ROUNDED text this function puts back, so a
        # gain the board held to more digits than the box shows was quietly
        # replaced by the shorter number. Clicking into a field and out of
        # it wrote that same rounding, with the user having typed nothing.
        # A panel writes when the user changes something, and not otherwise.
        settled = {"text": edit.text()}

        def commit() -> None:
            try:
                text = edit.text().strip()
                if text == settled["text"].strip():
                    return                                 # nothing was typed
                try:
                    value = float(text)
                except ValueError:
                    note.setText(f"{text!r} is not a number")
                    return
                # NaN and infinity parse cleanly and then pass every
                # comparison below, because a comparison with NaN is
                # false: "nan" typed into a bounded field went to the
                # board as a value no design can use.
                if value != value or value in (float("inf"), float("-inf")):
                    note.setText(f"{text!r} is not a usable number")
                    return
                if c.low is not None and value < c.low:
                    note.setText(f"below {c.low:g}")
                    return
                if c.high is not None and value > c.high:
                    note.setText(f"above {c.high:g}")
                    return
                note.setText("")
                edit.setText(f"{value:.{c.decimals}g}")
                settled["text"] = edit.text()
                self._pending_writes[c.name] = value
            except BaseException:                          # noqa: BLE001
                print(f"[panel] the {c.label!r} field could not be read:",
                      flush=True)
                traceback.print_exc()

        # Both, on purpose: Enter commits, and so does leaving the box
        # after a change. The guard above is what keeps that from being
        # two writes, or a write with no edit behind it.
        edit.returnPressed.connect(commit)
        edit.editingFinished.connect(commit)
        row.addWidget(edit, 1)
        row.addWidget(note)
        c.widget = edit
        return row

    def _build_number(self, c, QtWidgets):
        row = QtWidgets.QHBoxLayout()
        caption = QtWidgets.QLabel(str(c.label))
        caption.setMinimumWidth(110)
        value = QtWidgets.QLabel("waiting")
        row.addWidget(caption)
        row.addWidget(value, 1)
        c.widget = value
        return row

    def _build_button(self, c, QtWidgets):
        button = QtWidgets.QPushButton(str(c.label))

        def pressed(_checked=False):
            action = c.callback
            if action is None:
                return
            try:
                action()
            except KeyboardInterrupt:
                # Ctrl+C can land inside a slot as easily as inside a
                # refresh, and the rule is the same as for _tick: it is
                # a BaseException, nothing may escape a Qt slot, and the
                # panel ends itself so the design is stopped on the way
                # out rather than left streaming.
                print("\n[panel] stopping.", flush=True)
                self._leave()
            except BaseException:                          # noqa: BLE001
                # A button that raises must not take the panel with it:
                # the board is streaming and the stop is on the way out.
                # The whole traceback, for the same reason _tick prints
                # one: a bare message has no file and no line to fix.
                print(f"[panel] the {c.label!r} button raised:", flush=True)
                traceback.print_exc()

        button.clicked.connect(pressed)
        c.widget = button
        return button

    def _build_plot(self, c, QtGui, QtWidgets):
        # A FRESH LIST. run() may be called again on the same panel, and
        # it builds a new window; the curves of the old one were appended
        # to and never cleared, so the paint zipped the DEAD curves (the
        # first N) with the names and the second run died on its first
        # refresh reaching into a window Qt had already deleted.
        c.curves = []
        c.widget = None
        try:
            import pyqtgraph as pg
        except Exception:                                  # noqa: BLE001
            # Not fatal, and not silent either. The panel is still worth
            # having without curves, so it says what is missing and
            # carries on with the numbers.
            print("[panel] pyqtgraph is not installed, so "
                  f"plot({', '.join(c.names)}) is shown as numbers "
                  "instead. Add pyqtgraph with Packages in the Source "
                  "Editor to get curves.", flush=True)
            c.kind = "number_group"
            c.curves = []
            box = QtWidgets.QGroupBox(str(c.label))
            inner = QtWidgets.QVBoxLayout(box)
            c.curves = []
            for name in c.names:
                label = QtWidgets.QLabel(f"{name}: waiting")
                inner.addWidget(label)
                c.curves.append(label)
            return box

        widget = pg.PlotWidget(title=str(c.label))
        # LIGHT PAPER, not the curve package's default black. The plot is
        # one widget among the switches and fields on a light window, and
        # a black rectangle there does not read as an empty graph, it
        # reads as a display that failed to come up. Everything drawn on
        # the paper is re-inked to match: title, axes, tick numbers and
        # the legend all default to white, which is invisible here.
        widget.setBackground(PLOT_PAPER)
        # A plot needs real height or its title and axis eat all of it and
        # the curve area collapses to nothing. This floor keeps a readable
        # trace at any window size; the stretch factor added in _build lets
        # it grow to fill a tall window.
        widget.setMinimumHeight(160)
        widget.setMinimumWidth(260)
        widget.showGrid(x=True, y=True, alpha=PLOT_GRID_ALPHA)
        plot_item = widget.getPlotItem()
        plot_item.setTitle(str(c.label), color=PLOT_INK, size="10pt")
        for side in ("left", "bottom"):
            axis = plot_item.getAxis(side)
            axis.setPen(pg.mkPen(PLOT_INK))
            axis.setTextPen(pg.mkPen(PLOT_INK))
        widget.setLabel("bottom", "seconds", color=PLOT_INK)
        # A legend on light paper needs its own light backing: the curves
        # run under it, and dark text over a curve is not readable.
        widget.addLegend(labelTextColor=PLOT_INK,
                         brush=pg.mkBrush(255, 255, 255, 200),
                         pen=pg.mkPen("#c8ccd8"))
        for i, name in enumerate(c.names):
            colour = PLOT_CURVE_COLORS[i % len(PLOT_CURVE_COLORS)]
            curve = widget.plot(
                pen=pg.mkPen(colour, width=PLOT_CURVE_WIDTH), name=name)
            c.curves.append(curve)
            self._series.setdefault(name, [])
        c.widget = widget
        return widget

    def _tick(self, QtCore) -> None:
        """One refresh: write what moved, read what the board has, draw.

        NOTHING IS ALLOWED OUT OF HERE, and that is not tidiness.

        This runs as a Qt callback. An exception escaping one of those
        does not unwind: the toolkit ends the process on the spot, which
        skips ``run()``'s finally, skips the stop, and skips the
        transport's own last-resort cleanup. Measured before this was
        written: a read that raised produced an exit code, an empty
        console and a board still streaming, with no traceback anywhere.
        A board left streaming is what makes the NEXT program fail.

        Ctrl+C arrives here too, for the same reason: while the window is
        up, this callback is the only Python that runs, so the interrupt
        is raised inside it. It is a BaseException, so a bare
        ``except Exception`` would have missed it, and so would
        ``SystemExit`` from a rule that decides it is finished.
        """
        if self._closing:
            return
        try:
            self._flush_writes()
            # A SHORT READ, not a whole refresh period. This blocks the
            # window while it waits, and the board sends a batch every
            # few tens of milliseconds, so a poll that waited a full
            # period would leave the controls feeling heavy for no gain:
            # the next tick is along in a moment either way.
            values = self.design.read(timeout_ms=self._read_timeout_ms)
            if values:
                self._last_values = values
                self._record(values)
                self._paint(values)
            # The rule runs on EVERY refresh once a first batch has
            # arrived, with the newest values known, and not only on the
            # refreshes that brought a fresh batch. A rule that counts
            # refreshes to give something up, or that acts on time, was
            # frozen whenever the board went quiet, which is exactly when
            # such a rule is needed.
            if self._on_tick is not None and self._last_values:
                self._on_tick(dict(self._last_values))
        except KeyboardInterrupt:
            print("\n[panel] stopping.", flush=True)
            self._leave()
        except RemoteDesignError as exc:
            print(f"[panel] the board stopped answering: {exc}", flush=True)
            self._leave()
        except BaseException:                              # noqa: BLE001
            # The whole traceback, because "name 'x' is not defined" with
            # no file and no line is not enough to fix a script by.
            print("[panel] stopping, because something in this refresh "
                  "raised:", flush=True)
            traceback.print_exc()
            self._leave()

    def _flush_writes(self) -> None:
        if not self._pending_writes:
            return
        batch, self._pending_writes = self._pending_writes, {}
        try:
            self.design.write_many(batch)
            self._written.update(batch)
        except RemoteDesignError as exc:
            print(f"[panel] a write was refused: {exc}", flush=True)

    def _record(self, values: Dict[str, float]) -> None:
        self._times.append(time.monotonic() - self._t0)
        if len(self._times) > self.history:
            del self._times[: len(self._times) - self.history]
        for name, value in values.items():
            series = self._series.get(name)
            if series is None:
                continue
            series.append(float(value))
            if len(series) > self.history:
                del series[: len(series) - self.history]

    def _paint(self, values: Dict[str, float]) -> None:
        for c in self._controls:
            if c.kind == "number" and c.widget is not None:
                value = values.get(c.name)
                if value is not None:
                    c.widget.setText(f"{value:+.{c.decimals}f}")
            elif c.kind == "number_group":
                for label, name in zip(c.curves, c.names):
                    value = values.get(name)
                    if value is not None:
                        label.setText(f"{name}: {value:+.{c.decimals}f}")
            elif c.kind == "plot":
                for curve, name in zip(c.curves, c.names):
                    series = self._series.get(name) or []
                    n = min(len(series), len(self._times))
                    if n >= 2:
                        curve.setData(self._times[-n:], series[-n:])
