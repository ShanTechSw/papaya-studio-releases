var searchData=
[
  ['zcr_0',['zcr',['../classzcr.html',1,'']]],
  ['zscorenorm_1',['zScoreNorm',['../classz_score_norm.html',1,'']]]
];
