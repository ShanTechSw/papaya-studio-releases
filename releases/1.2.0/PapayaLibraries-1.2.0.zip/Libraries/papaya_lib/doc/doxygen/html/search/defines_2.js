var searchData=
[
  ['spi_5fhas_5ftransaction_0',['SPI_HAS_TRANSACTION',['../host__arduino__compat_2include_2_s_p_i_8h.html#a54ccd466ea250550206f8766bb874e77',1,'SPI_HAS_TRANSACTION:&#160;SPI.h'],['../stm32cubeide__hal_2include_2_s_p_i_8h.html#a54ccd466ea250550206f8766bb874e77',1,'SPI_HAS_TRANSACTION:&#160;SPI.h']]],
  ['ss_5ffactory_5fbegin_1',['SS_FACTORY_BEGIN',['../_p_a_p_a_y_a_8cpp.html#ae369bb7148dfa4d4e647117850020539',1,'PAPAYA.cpp']]],
  ['ss_5ffactory_5fend_2',['SS_FACTORY_END',['../_p_a_p_a_y_a_8cpp.html#aaf4276735c691ab7cad1c8b8c2514006',1,'PAPAYA.cpp']]]
];
