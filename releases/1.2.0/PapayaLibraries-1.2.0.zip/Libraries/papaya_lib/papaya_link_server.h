/**
 * @file    papaya_link_server.h
 * @brief   Carrying the relay engine over a socket.
 *
 * The engine is pure and a socket is not, so they are separate files.
 * This one owns the socket and nothing else: it reads bytes, hands whole
 * frames to the engine, and writes back whatever the engine emits.
 *
 * One client at a time
 * --------------------
 * A second PAPAYA Studio attaching to a board that is already being
 * driven would interleave two command streams onto one sequence counter,
 * which is the same loss of step the board's own arbitration exists to
 * prevent. So a second connection is **refused with a reason** rather
 * than dropped: a client that is told why can say so, and a client whose
 * socket simply closes reports a network fault for a policy decision.
 *
 * Losing a client mid-command
 * ---------------------------
 * The engine's flush rule is what makes a disconnect survivable, but only
 * if something tells it. A socket that dies is not an event the engine
 * can see, so this file makes it one: **any** exit from the serve loop
 * runs the same flush a clean goodbye would, and the board is left able
 * to answer its next command instead of waiting forever for the rest of
 * the last one.
 *
 * The loop has two things to wait for
 * -----------------------------------
 * A frame from the client, and the next telemetry poll. So the read's
 * timeout is whichever comes first rather than a fixed figure: a loop
 * that always waited half a second would deliver a 20 ms batch stream in
 * half-second lumps, and one that always waited 20 ms would wake
 * constantly on an idle link with nothing subscribed.
 *
 * Portability
 * -----------
 * Berkeley sockets, which is what every target here speaks: a Linux host
 * natively, and an ESP32's network stack through the same API. Windows is
 * supported because the desktop tests that prove this file run there.
 * Nothing above the two `#ifdef`s in the implementation is
 * platform-specific.
 */
#pragma once

#include <stdint.h>

#include "papaya_link_gateway.h"

namespace papaya {
namespace link {

/** Default port a generated gateway listens on. Registered nowhere;
 *  simply out of the way of common services. */
static const uint16_t kDefaultPort = 8272u;

/** How long a read waits before the loop looks at its stop flag, when
 *  there is no telemetry schedule asking for sooner. */
static const uint32_t kIdlePollMs = 500u;

/** Asked between reads. Returning true ends the serve loop cleanly, which
 *  still flushes: see the note in the file header. */
typedef bool (*ShouldStopFn)(void *context);

/** Milliseconds since some fixed point, supplied by the host because a
 *  gateway's clock is the host's. May wrap; the engine expects it to. */
typedef uint32_t (*MillisFn)(void);

/**
 * A FrameSink that writes to a stream socket.
 *
 * Sends the pieces where they lie, accumulating the checksum across them,
 * so a telemetry batch is never copied to be sent. On a host whose whole
 * memory is measured in tens of kilobytes that is the difference between
 * carrying a batch and not.
 *
 * It is created ONCE and pointed at each client in turn, because the
 * engine takes its sink at construction and one engine serves every
 * client the gateway will ever have. Building a new engine per connection
 * would throw away the counters that are the whole diagnosis of a link
 * nobody can see, and would do it exactly when a client keeps
 * reconnecting -- which is when those counters matter most.
 */
class SocketFrameSink : public FrameSink
{
public:
  SocketFrameSink(void) : socket_(-1), alive_(false) {}

  /** Point at a client. Clears the failed flag: the next client's socket
   *  is not the last one's. */
  void attach(intptr_t socketHandle)
  {
    socket_ = socketHandle;
    alive_ = true;
  }

  /** Let go. A send after this fails rather than writing to a handle the
   *  operating system has since given to something else. */
  void detach(void)
  {
    socket_ = -1;
    alive_ = false;
  }

  bool send(uint8_t type, uint16_t seq,
            const uint8_t *first, uint32_t firstLength,
            const uint8_t *second, uint32_t secondLength,
            const uint8_t *third, uint32_t thirdLength);

  /** False once a write has failed. The loop stops rather than going on
   *  talking to a socket that has gone. */
  bool alive(void) const { return alive_; }

private:
  bool writeAll(const uint8_t *data, uint32_t length);

  intptr_t socket_;
  bool alive_;
};

/**
 * Relay for one already-accepted client until it goes away.
 *
 * Returns on a clean goodbye, a closed socket, or @p shouldStop. In every
 * one of those cases the engine is told, because a half-sent command that
 * nobody finishes leaves the board's receive state machine waiting
 * forever.
 *
 * @param socketHandle an accepted stream socket, as an int on POSIX and
 *        as a SOCKET on Windows; both fit here.
 * @param sink         the sink the engine was built with. Attached to
 *                     this client on entry and detached on exit.
 * @param frameBuffer  caller-owned, at least kRelayFrameBufferSize.
 * @param listener     the listening socket, or -1. When given, a SECOND
 *                     client arriving mid-session is accepted, told why
 *                     it cannot have the board, and closed. That is the
 *                     specified behaviour and it is not the same as a
 *                     backlog: a client left queued believes it is
 *                     connecting, and one whose socket simply closes
 *                     reports a network fault for a policy decision.
 */
void serveConnection(intptr_t socketHandle, Gateway &gateway,
                     SocketFrameSink &sink, uint8_t *frameBuffer,
                     uint32_t frameBufferSize, MillisFn millis,
                     ShouldStopFn shouldStop = 0, void *stopContext = 0,
                     intptr_t listener = -1);

/**
 * Which interfaces a gateway answers on.
 *
 * A real gateway has to be reachable from the network it is on, so
 * kAllInterfaces is the default and the only useful setting for one.
 *
 * kLoopbackOnly exists for tests and for bringing a gateway up on a
 * developer's own machine. It is not a lesser default, it is a different
 * job: a program that binds every interface is offering a board-relay
 * port to the whole network, which on Windows also raises the firewall's
 * "allow this app" prompt, and neither is a reasonable thing for a test
 * run to do to somebody's machine.
 */
enum BindScope
{
  kAllInterfaces = 0,
  kLoopbackOnly = 1
};

/**
 * Listen, accept one client at a time, relay, repeat.
 *
 * A blocking loop, meant to be the body of a task of its own. It returns
 * only when @p shouldStop says so or the listening socket fails.
 *
 * @param port  the TCP port to listen on.
 * @param scope which interfaces to answer on. See BindScope.
 * @return false when the socket could not be opened at all, which is a
 *         configuration fault rather than a runtime one and worth telling
 *         the operator about differently.
 */
bool serveForever(uint16_t port, Gateway &gateway, SocketFrameSink &sink,
                  uint8_t *frameBuffer, uint32_t frameBufferSize,
                  MillisFn millis, ShouldStopFn shouldStop = 0,
                  void *stopContext = 0, BindScope scope = kAllInterfaces);

/** Once per process, before any of the above. A no-op where the network
 *  stack needs no starting; on Windows it starts Winsock. */
bool networkStartup(void);

/** The counterpart, for a host that ever stops. */
void networkShutdown(void);

/** Connections turned away because one was already live. A rising count
 *  usually means a second PAPAYA Studio, which is worth surfacing. */
uint32_t rejectedConnections(void);

}  /* namespace link */
}  /* namespace papaya */
