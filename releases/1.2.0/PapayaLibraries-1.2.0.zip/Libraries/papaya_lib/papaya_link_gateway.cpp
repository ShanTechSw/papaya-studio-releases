/**
 * @file    papaya_link_gateway.cpp
 * @brief   The relay engine. See papaya_link_gateway.h.
 *
 * A port of a design already proven against a fake board in the Studio's
 * own language. What is ported is the RULES, not the reasoning: every
 * decision below has its justification in the header, and the tests that
 * hold it in place are the same scenarios, run against this code.
 *
 * Two things are genuinely different here and neither is a translation:
 *
 * - **The clock is a millisecond counter that wraps**, roughly every 49
 *   days. Every comparison against it is written as a signed difference
 *   of unsigned values, which is correct across the wrap; a plain
 *   `now < due` is not, and the failure would be a gateway that stops
 *   streaming seven weeks after it was switched on.
 * - **The scratch buffer is the real bound on what this host can carry.**
 *   A subscription asking for a batch larger than it fits is refused with
 *   a reason rather than truncated, because half a batch drawn as a whole
 *   one is a waveform that is wrong in a way nobody can see.
 */
#include "papaya_link_gateway.h"

#include <string.h>

namespace papaya {
namespace link {

namespace {

/* Offsets inside a command header, and the two sub-function values that
 * must never reach the wire. The only opcode knowledge in this file, and
 * it is here because both would damage the link rather than merely fail.
 *
 * THE FUNCTION ID IS PART OF THE TEST, and leaving it out was a real
 * defect rather than a tidiness point. A sub-function number means
 * nothing on its own: the board reads it together with the function id
 * at offset 7, and the same number means different commands under
 * different functions. Sub-function 4 under MANAGE is the flow-credit
 * opcode this refuses; sub-function 4 under CREATE is "make a hardware
 * input", which is how every analog input in every design is built.
 *
 * Testing the sub-function alone therefore ate the creation of any
 * hardware input, so a design containing one could never be uploaded
 * over this link: the board never saw the command, answered nothing, and
 * the Studio reported "the design did not go through over Wi-Fi" after
 * two full command timeouts. Designs without a hardware input were
 * unaffected, which is what made it look like a link fault rather than
 * an opcode one. */
const uint16_t kFuncOffset = 0x07u;
const uint16_t kSubfuncOffset = 0x08u;
const uint8_t kFuncManage = 0x02u;
const uint16_t kOpcodeFlowCredit = 0x0004u;
const uint16_t kOpcodeSetLiveRate = 0x201Au;

/* The read/write field, where the board's protocol puts a bare opcode. */
const uint16_t kReadWriteOffset = 0x02u;
const uint8_t kCmdReadVectorProbe = 0x02u;

/* The board's status frame. */
const uint16_t kStatusSize = 7u;

/** How many EXTRA batches one late poll may fetch to catch up.
 *
 * The board publishes into a ring and keeps four batches available,
 * serving the oldest uncollected one on every read. So a poll that ran
 * one interval late can still fetch the batch it missed, and the bound
 * is what the ring holds: asking for more than the board kept only
 * re-reads the newest one, which the host then discards as a duplicate,
 * and an unbounded burst after a long stall would starve the inbound
 * command path this same loop serves.
 *
 * Three, because this poll is already fetching the fourth. */
const uint32_t kRingCatchUpMax = 3u;

/* Byte 2 of a status frame is the design status; 0 is success. */
bool statusIsOk(const uint8_t *status, uint16_t length)
{
  return (length >= 3u) && (status[2] == 0u);
}

uint16_t readU16(const uint8_t *data)
{
  return (uint16_t)((uint16_t)data[0] | ((uint16_t)data[1] << 8));
}

/**
 * True when @p now has reached @p deadline, correctly across the wrap.
 *
 * A millisecond counter wraps at 2^32, roughly every 49 days. Written as
 * `now >= deadline` this would go false for the 49 days after a wrap, and
 * a gateway would simply stop streaming with nothing to explain it. The
 * signed difference of two unsigned values is the standard way round it
 * and is correct for any interval under about 24 days, which is far
 * longer than any poll.
 */
bool reached(uint32_t now, uint32_t deadline)
{
  return (int32_t)(now - deadline) >= 0;
}

}  /* namespace */

Gateway::Gateway(BoardPort &board, FrameSink &sink, uint8_t *scratch,
                 uint32_t scratchSize, TelemetryStage *stage)
  : board_(board), sink_(sink), scratch_(scratch), scratchSize_(scratchSize),
    stage_(stage),
    pending_(false), pendingShape_(0u), pendingTotalBody_(0u),
    pendingReceived_(0u), pendingExpectedData_(0u), pendingNextIndex_(1u),
    subscribed_(false), batchSeq_(0u), nextDueMs_(0u),
    scheduleStarted_(false), flushedCommands_(0u), refusedCommands_(0u),
    droppedBatches_(0u)
{
  subscription_.probeCount = 0u;
  subscription_.samplesPerBatch = 0u;
  subscription_.vectorCount = 0u;
  subscription_.intervalMs = 0u;
  subscription_.scalarBytes = 0u;
  subscription_.vectorBytes = 0u;
}

/* ==================================================================== */
/* Entry point                                                          */
/* ==================================================================== */

void Gateway::handle(const Frame &frame)
{
  switch (frame.type)
  {
    case kCmd:
      onCommand(frame);
      return;

    case kCmdChunk:
      onChunk(frame);
      return;

    case kReset:
      /* Anything half-sent is moot once the board reboots, and the flush
       * would be talking to a board that is about to disappear. */
      pending_ = false;
      result(frame.seq,
             board_.resetBoard() ? (uint8_t)kOutcomeAnswered
                                 : (uint8_t)kOutcomeRefused,
             0, 0u, 0, 0u);
      return;

    case kSubscribe:
      onSubscribe(frame);
      return;

    case kUnsubscribe:
      subscribed_ = false;
      scheduleStarted_ = false;
      result(frame.seq, (uint8_t)kOutcomeAnswered, 0, 0u, 0, 0u);
      return;

    case kPing:
      sink_.send((uint8_t)kPong, frame.seq, frame.payload,
                 frame.payloadLength, 0, 0u, 0, 0u);
      return;

    case kBye:
      flushPending();
      /* The subscriber is gone. Polling a board on behalf of nobody
       * spends the wire the next client will want. */
      subscribed_ = false;
      scheduleStarted_ = false;
      /* AND PUT THE BOARD BACK. Unsubscribing stops this end asking;
       * it does not stop the board sampling, and a board left sampling
       * is what the next client has to fight. See BoardPort::quiesce. */
      board_.quiesce();
      return;

    default:
      /* Unknown-but-intact frames are the far end's business, not ours.
       * A newer peer is entitled to send one, and ignoring it is how a
       * protocol stays extensible. */
      return;
  }
}

/* ==================================================================== */
/* Commands                                                             */
/* ==================================================================== */

void Gateway::onCommand(const Frame &frame)
{
  /* A command arriving while another is half-sent means the far end gave
   * up on the first. Finish it before starting anything, or the board is
   * left mid-receive and the new command's header is read as body. */
  flushPending();

  Command command;
  if (!decodeCommand(frame.payload, frame.payloadLength, command))
  {
    refuse(frame.seq, "the command payload could not be read");
    return;
  }

  const char *why = refusalReason(command.header, command.headerLength);
  if (why != 0)
  {
    refuse(frame.seq, why);
    return;
  }

  /* The shapes that put an OPCODE on the wire rather than a header. A
   * shape added to samplingShape() but left out of this list does not
   * fail there: it falls through to the header path below and the board
   * is handed eighteen bytes where it expected one. */
  if ((command.shape == (uint8_t)kShapeProbeRead)
      || (command.shape == (uint8_t)kShapeInputWrite)
      || (command.shape == (uint8_t)kShapeOpcodeOnly))
  {
    samplingShape(frame.seq, command.shape, command.header,
                  command.headerLength, command.firstChunk,
                  command.firstChunkLength, command.expectedData);
    return;
  }

  if (command.expectedData > (uint32_t)(scratchSize_ - kStatusSize))
  {
    /* Refused before a byte reaches the wire. Reading a payload this host
     * cannot hold would either overrun the buffer or leave the unread
     * remainder to be taken for the NEXT command's response, and the link
     * is desynchronised from there on.
     *
     * THE STATUS SHARES THE SCRATCH, so the bound has to leave room for
     * it. This check used to say `> scratchSize_` while the read that
     * completes the command says `<= scratchSize_ - statusLength`. Any
     * size in the seven bytes between them passed here, failed there,
     * and the command was answered with a clean status and NO DATA --
     * having never clocked the payload the board had already armed.
     * Under-clocking an armed transmit leaves the board mid-response, so
     * the NEXT chip-select lands on its state machine's default arm and
     * the session is wedged.
     *
     * Not hypothetical: a trace download asks for exactly 4096 bytes,
     * and one of the shipped gateway profiles has a scratch of exactly
     * 4096. Refusing at entry is the recoverable direction: the host is
     * told, and the wire is untouched. */
    refuse(frame.seq, "this gateway cannot hold a reply that large");
    return;
  }

  board_.beginCommand(command.header, command.headerLength);
  if (command.firstChunkLength > 0u)
  {
    board_.sendBodyChunk(command.firstChunk, command.firstChunkLength);
  }

  pending_ = true;
  pendingShape_ = command.shape;
  pendingTotalBody_ = command.totalBodyLength;
  pendingReceived_ = command.firstChunkLength;
  pendingExpectedData_ = command.expectedData;
  pendingNextIndex_ = 1u;

  if (pendingReceived_ < pendingTotalBody_)
  {
    /* More chunks to come. Nothing is buffered here: each one goes
     * straight to the wire as it arrives. */
    return;
  }
  finish(frame.seq);
}

void Gateway::onChunk(const Frame &frame)
{
  if (!pending_)
  {
    /* No command to attach it to. Nothing has been half-sent, so there is
     * nothing to flush; just say so. */
    refuse(frame.seq, "a body chunk with no command");
    return;
  }

  uint16_t index = 0u;
  const uint8_t *chunk = 0;
  uint32_t chunkLength = 0u;
  if (!decodeCommandChunk(frame.payload, frame.payloadLength, index, chunk,
                          chunkLength))
  {
    flushPending();
    refuse(frame.seq, "the chunk payload could not be read");
    return;
  }

  if (index != pendingNextIndex_)
  {
    /* Out of order. Forwarding it would produce a body whose checksum
     * fails somewhere far from the cause, so flush the command out
     * instead and let the far end retry it whole. */
    flushPending();
    refuse(frame.seq, "a body chunk arrived out of order");
    return;
  }

  const uint32_t outstanding = pendingTotalBody_ - pendingReceived_;
  if (chunkLength > outstanding)
  {
    flushPending();
    refuse(frame.seq, "a body chunk overruns the declared body");
    return;
  }

  board_.sendBodyChunk(chunk, chunkLength);
  pendingReceived_ += chunkLength;
  pendingNextIndex_++;

  if (pendingReceived_ < pendingTotalBody_) { return; }
  finish(frame.seq);
}

void Gateway::finish(uint16_t seq)
{
  const uint8_t shape = pendingShape_;
  const uint32_t expectedData = pendingExpectedData_;
  pending_ = false;

  if (shape == (uint8_t)kShapeFireAndForget)
  {
    /* No poll: the board is rebooting and will not answer. Waiting would
     * spend the deadline and then report a failure for a command that did
     * exactly what it was asked. */
    result(seq, (uint8_t)kOutcomeAnswered, 0, 0u, 0, 0u);
    return;
  }

  const uint16_t statusLength = board_.awaitStatus(scratch_, kStatusSize);
  if (statusLength == 0u)
  {
    result(seq, (uint8_t)kOutcomeNoAnswer, 0, 0u, 0, 0u);
    return;
  }

  uint32_t dataLength = 0u;
  if ((shape == (uint8_t)kShapeConfigWithData)
      && statusIsOk(scratch_, statusLength)
      && (expectedData > 0u)
      && (statusLength < scratchSize_)
      && (expectedData <= scratchSize_ - statusLength))
  {
    /* Only after a good status. Reading a payload nobody queued consumes
     * the NEXT command's response, and the link is desynchronised from
     * there on. */
    dataLength = board_.readDataPayload(&scratch_[statusLength],
                                        expectedData);
  }

  result(seq, (uint8_t)kOutcomeAnswered, scratch_, statusLength,
         &scratch_[statusLength], dataLength);
}

void Gateway::samplingShape(uint16_t seq, uint8_t shape,
                            const uint8_t *header, uint16_t headerLength,
                            const uint8_t *payload, uint32_t payloadLength,
                            uint32_t expectedData)
{
  if (shape == (uint8_t)kShapeOpcodeOnly)
  {
    /* The opcode sits in the header's read/write field, exactly where
     * kShapeProbeRead reads its own from. Nothing else about the header
     * reaches the wire. */
    const uint8_t opcode = (headerLength > kReadWriteOffset)
                         ? header[kReadWriteOffset] : 0u;
    const bool sent = board_.sendOpcode(opcode);
    result(seq, sent ? (uint8_t)kOutcomeAnswered : (uint8_t)kOutcomeNoAnswer,
           0, 0u, 0, 0u);
    return;
  }

  if (shape == (uint8_t)kShapeProbeRead)
  {
    uint32_t length = expectedData;
    if ((length == 0u) && (headerLength >= 5u))
    {
      /* Fallback, when the far end did not state one. */
      length = readU16(&header[3]);
    }
    if (length == 0u)
    {
      refuse(seq, "a probe read with no byte count would return nothing");
      return;
    }
    if (length > scratchSize_)
    {
      refuse(seq, "this gateway cannot hold a probe read that large");
      return;
    }

    /* The opcode sits in the header's read/write field, which is where
     * the board's own protocol puts it. Reading byte zero instead would
     * find the sequence number's low half. */
    const bool vector = (headerLength > kReadWriteOffset)
                     && (header[kReadWriteOffset] == kCmdReadVectorProbe);

    const uint32_t got = board_.readProbes(scratch_, length, vector);
    if (got == 0u)
    {
      result(seq, (uint8_t)kOutcomeNoAnswer, 0, 0u, 0, 0u);
      return;
    }
    result(seq, (uint8_t)kOutcomeAnswered, 0, 0u, scratch_, got);
    return;
  }

  const bool ok = board_.writeInputs(payload, payloadLength);
  result(seq, ok ? (uint8_t)kOutcomeAnswered : (uint8_t)kOutcomeNoAnswer,
         0, 0u, 0, 0u);
}

/* ==================================================================== */
/* Telemetry                                                            */
/* ==================================================================== */

void Gateway::onSubscribe(const Frame &frame)
{
  Subscription wanted;
  if (!decodeSubscribe(frame.payload, frame.payloadLength, wanted))
  {
    refuse(frame.seq, "the subscription could not be read");
    return;
  }

  /* The buffer a batch is read into is the real bound on what this host
   * can carry, and a batch that does not fit is refused rather than
   * truncated: half a batch drawn as a whole one is a waveform that is
   * wrong in a way nobody can see. The reason travels, so the far end
   * can say what to do about it instead of reporting a dead link.
   *
   * WHICH buffer that is depends on whether a stage was supplied, which
   * is why this asks rather than naming the scratch. Testing the scratch
   * with a smaller stage fitted would accept a batch no buffer can hold,
   * and the failure would be silent: the subscription succeeds and the
   * stream never starts. */
  const uint32_t largest = (wanted.scalarBytes > wanted.vectorBytes)
                         ? wanted.scalarBytes : wanted.vectorBytes;
  if (largest > telemetryCapacity())
  {
    refuse(frame.seq,
           "this gateway cannot hold a batch that large. Reduce the "
           "sampling rate, the batch size, or the number of probes");
    return;
  }

  /* A second subscription replaces the first rather than joining it. Two
   * schedules on one wire interleave probe reads between each other's
   * request and payload, and a payload does not say which request it
   * belongs to. */
  subscription_ = wanted;
  subscribed_ = true;
  scheduleStarted_ = false;
  result(frame.seq, (uint8_t)kOutcomeAnswered, 0, 0u, 0, 0u);
}

void Gateway::announce(void)
{
  /* THE SMALLER OF TWO THINGS, and using only the first was a defect.
   *
   * telemetryCapacity() is the buffer a batch is read into, which is
   * what a subscription is refused against. Announcing that alone told
   * every gateway in the family to size batches by its MEMORY, and two
   * of them cannot deliver what their memory holds: the ST IoT nodes'
   * radio takes 1200 bytes per write and the Arduino R4's staging is
   * 192, so an 8 KB batch becomes seven writes on a transport that
   * charges several command round trips per write. That is the mistake
   * this protocol exists to avoid, made from the other end.
   *
   * So the transport also gets a say. Where it states a comfortable
   * frame size, the announcement is clamped to it; where it states
   * nothing, the buffer stands. The host applies its own floor of 1200
   * on top, so a small announcement can only ever leave today's
   * behaviour in place and never make a working session worse. */
  uint32_t budget = telemetryCapacity();
  const uint32_t comfortable = sink_.comfortableFrameBytes();
  if ((comfortable > 0u) && (comfortable < budget)) { budget = comfortable; }

  uint8_t payload[4];
  const uint32_t length = encodeWelcome(payload, sizeof(payload), budget);
  if (length == 0u) { return; }
  sink_.send((uint8_t)kWelcome, 0u, payload, length, 0, 0u, 0, 0u);
}

uint32_t Gateway::telemetryCapacity(void) const
{
  /* With a stage the scratch carries command results only, so the
   * stage's buffer is the bound. Without one the scratch is both. */
  return (stage_ != 0) ? stage_->slotBytes() : scratchSize_;
}

uint32_t Gateway::telemetryDueIn(uint32_t nowMs) const
{
  if (!subscribed_) { return 0xFFFFFFFFu; }
  if (!scheduleStarted_) { return 0u; }
  if (reached(nowMs, nextDueMs_)) { return 0u; }
  return nextDueMs_ - nowMs;
}

void Gateway::pollTelemetry(uint32_t nowMs)
{
  if (!subscribed_) { return; }

  if (!scheduleStarted_)
  {
    nextDueMs_ = nowMs;                          /* the first is due at once */
    scheduleStarted_ = true;
  }
  if (!reached(nowMs, nextDueMs_)) { return; }

  /* Advance the schedule past every slot that has gone by, and the batch
   * number with it. A slot that produced nothing still spends its number,
   * which is what puts the gap in the sequence: the board's own
   * monitoring carries no sequence, no checksum and no gap marker, so a
   * host handed a late batch under the next consecutive number cannot
   * tell it is looking at a hole.
   *
   * Computed rather than looped: a host that was busy for an hour is a
   * legitimate arrival and must not spin here. */
  const uint32_t behind = nowMs - nextDueMs_;    /* correct across the wrap */
  const uint32_t interval = subscription_.intervalMs;
  const uint32_t slots = 1u + (behind / interval);
  nextDueMs_ += slots * interval;

  /* CATCH UP BY READING, NOT BY RENUMBERING.
   *
   * The board does not overwrite the batch it has just published: it
   * keeps a ring of them and serves the OLDEST uncollected one on every
   * read, retiring it when the transfer completes. So when this loop
   * runs late, the batches it missed are still there to be fetched.
   *
   * They used to be deleted instead. Spending a slot number for each one
   * told the host they were lost, and the host believed it, because the
   * gap in the numbering is exactly what a real loss looks like. The
   * producer buffered and the consumer threw the buffer away.
   *
   * So a late poll now fetches what it missed, bounded by the ring's own
   * depth: reading further back than the board keeps would only return
   * the same batch twice, and reading without a bound would let one long
   * stall turn into an unbounded burst that starves the inbound path.
   * A deficit the ring cannot cover is still a real loss and is still
   * counted below. */
  /* WHAT THE NUMBER WAS BEFORE THIS POLL TOUCHED IT.
   *
   * Every exit below restores the one rule that matters: this poll spends
   * exactly `slots` numbers, one per slot it owed, whether it managed to
   * send them or not. Stating it from here rather than deriving it from
   * the arithmetic is deliberate. Derived, it was right for a scalar poll
   * and short by one for a vector-only subscription, because the vector
   * branch retires a batch from `owed` without ever advancing the number,
   * and that lost one batch per late poll with no gap to show for it. */
  const uint32_t seqAtEntry = batchSeq_;

  uint32_t extra = slots - 1u;
  if (extra > kRingCatchUpMax) { extra = kRingCatchUpMax; }
  /* Behind by more than the ring can hold is a real loss and is counted
   * as one straight away; the rest this poll intends to fetch. */
  droppedBatches_ += (slots - 1u) - extra;
  batchSeq_ += slots - extra;

  /* Batches this poll owes, decremented as each one is delivered, so
   * whatever is left at the end is what genuinely did not arrive. */
  uint32_t owed = extra + 1u;

  if (pending_)
  {
    /* A command's body is part-way onto the wire. A probe read here is
     * one more framed exchange in the middle of it, and the board would
     * take the opcode for body. Skip the batch; the sequence gap says so,
     * and dropping beats delivering stale samples as fresh.
     *
     * ALL of the slots this poll owed are lost here, not one. It used to
     * charge a single batch and spend `slots - extra` numbers, so the
     * count and the gap agreed with each other and both under-reported a
     * late poll. */
    droppedBatches_ += extra + 1u;
    batchSeq_ = seqAtEntry + slots;
    return;
  }

  /* Microseconds, because that is what the format carries and what places
   * a batch in time. A millisecond clock is what a gateway has. */
  const uint64_t stamp = (uint64_t)nowMs * 1000u;

  if (subscription_.scalarBytes > 0u)
  {
    /* One read per batch this poll owes: the one that is due, plus the
     * ones a late loop missed and the board still holds. Each carries
     * its own sequence number so the host sees a contiguous run rather
     * than a hole followed by a jump. */
    for (uint32_t i = 0u; i <= extra; i++)
    {
      /* WHERE THIS BATCH IS READ. Without a stage it is the scratch, and
       * the send below must finish with it before the next read may
       * start: that serialisation IS the slot time. With one, each batch
       * gets a buffer of its own and the send can still be running when
       * the next read begins. See TelemetryStage. */
      uint8_t *slot = scratch_;
      if (stage_ != 0)
      {
        slot = stage_->claim(subscription_.scalarBytes);
        if (slot == 0)
        {
          /* Every buffer is still going out, so the sender is the
           * bottleneck and reading another batch could only overwrite
           * one nobody has sent. Stop, and let the count below charge
           * for what this poll owed: a deeper stage cannot fix a link
           * that is slower than the board. */
          break;
        }
      }

      const uint32_t got = board_.readProbes(slot,
                                             subscription_.scalarBytes,
                                             false);
      if (got == 0u)
      {
        if (stage_ != 0) { stage_->discard(slot); }
        /* The board had nothing to give. Reachable at last: the read
         * reports an idle wire instead of returning its byte count come
         * what may, so this arm is no longer dead code.
         *
         * Not counted here. Whatever this poll owed and did not fetch is
         * accounted once, below, so a partial catch-up is counted once
         * per missing batch and never twice for the same one. */
        break;
      }

      /* The payload's own header goes out ahead of the samples rather
       * than being joined to them: the samples are already in the scratch
       * and joining would need a second buffer the same size. */
      uint8_t head[16];
      const uint32_t headLength = encodeTelemetry(
          head, sizeof(head), batchSeq_, stamp, subscription_.probeCount,
          subscription_.samplesPerBatch, 0, 0u);
      if (headLength == 0u)
      {
        if (stage_ != 0) { stage_->discard(slot); }
        break;
      }
      if (stage_ != 0)
      {
        /* Ownership passes: the stage returns the buffer to its own free
         * list once the bytes have gone, and this loop must not touch
         * them again. */
        stage_->publish((uint8_t)kTelemetry, head, headLength, slot, got);
      }
      else
      {
        sink_.send((uint8_t)kTelemetry, 0u, head, headLength, slot, got,
                   0, 0u);
      }
      owed--;
      if (i < extra)
      {
        batchSeq_++;
      }
    }
  }

  if (subscription_.vectorBytes > 0u)
  {
    /* The same buffer question as the scalar read above, and it must be
     * asked separately: a stage that is full of scalar batches has no
     * room for a vector snapshot either, and reading one into the
     * scratch while the stage sends from its own buffers would be a
     * batch drawn from memory the sender is not looking at. */
    uint8_t *slot = scratch_;
    if (stage_ != 0)
    {
      slot = stage_->claim(subscription_.vectorBytes);
    }
    const uint32_t got = (slot != 0)
        ? board_.readProbes(slot, subscription_.vectorBytes, true)
        : 0u;
    if (got > 0u)
    {
      if ((subscription_.scalarBytes == 0u) && (owed > 0u)) { owed--; }
      uint8_t head[16];
      const uint32_t headLength = encodeTelemetry(
          head, sizeof(head), batchSeq_, stamp, subscription_.vectorCount,
          1u, 0, 0u);
      if (headLength > 0u)
      {
        if (stage_ != 0)
        {
          stage_->publish((uint8_t)kVectorTelemetry, head, headLength,
                          slot, got);
        }
        else
        {
          sink_.send((uint8_t)kVectorTelemetry, 0u, head, headLength, slot,
                     got, 0, 0u);
        }
      }
      else if (stage_ != 0)
      {
        stage_->discard(slot);
      }
    }
    else if ((stage_ != 0) && (slot != 0))
    {
      stage_->discard(slot);
    }
  }

  /* SPEND ONE NUMBER PER SLOT THIS POLL OWED, or the far end cannot see
   * what is missing.
   *
   * A late poll pre-advances the sequence by `slots - extra` above and
   * then advances it once more per batch it actually delivers, so a poll
   * that delivers all of them spends exactly `slots` numbers and the
   * host sees a gap of exactly what was lost. A poll that STOPS EARLY
   * -- the ring had no free buffer, or the board had nothing -- spends
   * fewer, and the numbers it never spent are the ones it owed. Without
   * this line those batches are lost with no gap behind them: the next
   * batch arrives under a consecutive number and the host, whose only
   * evidence of loss is the numbering, is told nothing happened.
   *
   * MEASURED, 2026-08-26, and this is how it was found. A stalled writer
   * with a 16-deep ring: the gateway's own counter said 145 batches were
   * never sent and the host's sequence arithmetic said 72. Both were
   * right about what they measured. The gateway was right about the
   * loss. At a 4-deep ring the two agreed exactly, because the ring
   * emptied before any poll ran late and this path was never taken,
   * which is why a deeper ring is what exposed it.
   *
   * Assigned rather than added, so it holds however the loops above
   * exited: a full delivery lands on the same value it always did, and
   * every early exit lands there too. */
  batchSeq_ = seqAtEntry + slots;

  /* THE ONE PLACE A MISSED BATCH IS COUNTED. The board having nothing is
   * ordinary between batches; the slots are still spent, so the gap
   * stands and the far end is never told a batch arrived that did not.
   * Counting here rather than in the loop is what stops a poll that
   * fetched two of four being charged for the same two twice. */
  droppedBatches_ += owed;
}

/* ==================================================================== */
/* The rules                                                            */
/* ==================================================================== */

const char *Gateway::refusalReason(const uint8_t *header,
                                   uint16_t length) const
{
  if ((header == 0) || (length < kSubfuncOffset + 2u)) { return 0; }

  /* Both refusals below name MANAGE sub-functions. A header under any
   * other function that happens to carry the same number is a different
   * command entirely and must pass through untouched. */
  if (header[kFuncOffset] != kFuncManage) { return 0; }

  const uint16_t opcode = readU16(&header[kSubfuncOffset]);

  if (opcode == kOpcodeSetLiveRate)
  {
    return "the live-rate opcode is rejected by the board unconditionally "
           "AND latches the failure, so it breaks the next command as well "
           "as itself";
  }
  if (opcode == kOpcodeFlowCredit)
  {
    return "the flow-credit opcode reads from the USB endpoint in "
           "firmware, so on this wire it is meaningless";
  }
  return 0;
}

void Gateway::flushPending(void)
{
  if (!pending_) { return; }

  const uint8_t shape = pendingShape_;
  const uint32_t outstanding = pendingTotalBody_ - pendingReceived_;
  pending_ = false;
  if (outstanding == 0u) { return; }

  /* Complete a half-sent command with filler. The board has no
   * inter-frame timeout: a body that stops arriving leaves its receive
   * state machine waiting forever. Sending the rest as zeros lets it
   * finish, fail the body checksum, and answer an error, which is
   * recoverable where a stalled state machine is not. */
  flushedCommands_++;

  uint8_t filler[64];
  memset(filler, 0, sizeof(filler));
  uint32_t remaining = outstanding;
  while (remaining > 0u)
  {
    const uint32_t size = (remaining < sizeof(filler)) ? remaining
                                                       : sizeof(filler);
    board_.sendBodyChunk(filler, size);
    remaining -= size;
  }

  if (shape != (uint8_t)kShapeFireAndForget)
  {
    /* Consume whatever the board answers, so the reply to this dead
     * command is not read as the reply to the next live one. */
    board_.awaitStatus(scratch_, kStatusSize);
  }
}

void Gateway::refuse(uint16_t seq, const char *reason)
{
  refusedCommands_++;
  uint32_t length = 0u;
  while ((reason != 0) && (reason[length] != '\0')) { length++; }
  /* The reason first, then the refusal. A client that is told why can say
   * so; one that only sees a refusal reports a mystery. */
  sink_.send((uint8_t)kEvent, seq, (const uint8_t *)reason, length,
             0, 0u, 0, 0u);
  result(seq, (uint8_t)kOutcomeRefused, 0, 0u, 0, 0u);
}

void Gateway::result(uint16_t seq, uint8_t outcome, const uint8_t *status,
                     uint16_t statusLength, const uint8_t *data,
                     uint32_t dataLength)
{
  /* The result header is eight bytes; the status and data are already in
   * the scratch buffer and are handed to the sink beside it rather than
   * copied into a third place. */
  uint8_t head[8];
  const uint32_t headLength = encodeCommandResultHeader(
      head, sizeof(head), outcome, statusLength, dataLength);
  if (headLength == 0u) { return; }

  sink_.send((uint8_t)kCmdResult, seq, head, headLength, status,
             statusLength, data, dataLength);
}

}  /* namespace link */
}  /* namespace papaya */
