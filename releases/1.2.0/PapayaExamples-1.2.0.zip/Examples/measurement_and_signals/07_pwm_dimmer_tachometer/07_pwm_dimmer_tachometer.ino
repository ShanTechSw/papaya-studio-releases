/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      PWM out          nothing to play: its model is a probe named PWM_out_duty
 *                       that records the duty command the design sends, 0.5 until
 *                       the duty input cell is changed
 *      PWM capture      a pulse width in seconds: a 0.5 Hz triangle between 0.1 ms
 *                       and 0.9 ms, the width a dimmer turned up and down would
 *                       produce at the 1 kHz PWM frequency
 *      Period capture   a constant 0.001 s, the period of that same 1 kHz PWM, so
 *                       duty_measured = pulse / period sweeps between 0.1 and 0.9
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe pulse_width;
probe duty_measured;

input duty;
input duty_min;
input duty_max;
input period_hi;
input period_lo;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  duty = input("duty", 0.5f);
  duty_min = input("duty_min", 0.0f);
  duty_max = input("duty_max", 1.0f);
  period_hi = input("period_hi", 1000000000.0f);
  period_lo = input("period_lo", 1e-06f);
  pwmIn PWM_capture = pwmIn(FI1_PULSE, 1.0);
  pwmIn Period_capture = pwmIn(FI2_PERIOD, 1.0);
  sat Clamp_0__1 = sat();
  pwmOut PWM_out = pwmOut(FO1, 1000.0, 0.0, 1.0);
  sat never_zero = sat();
  inverse _1___period = inverse();
  node duty___pulse___period = node("[1.0 1.0]", "[1.0]", Mul);
  pulse_width = probe("pulse_width");
  duty_measured = probe("duty_measured");

  /* Connect Blocks */
  duty > Clamp_0__1.in(2);
  duty_min > Clamp_0__1.in(1);
  duty_max > Clamp_0__1.in(0);
  period_hi > never_zero.in(0);
  period_lo > never_zero.in(1);
  PWM_capture > duty___pulse___period.in(0);
  PWM_capture > pulse_width;
  Period_capture > never_zero.in(2);
  Clamp_0__1 > PWM_out;
  never_zero > _1___period;
  _1___period > duty___pulse___period.in(1);
  duty___pulse___period > duty_measured;

  /* Enable Remote Input Control */
  duty.enableRemote();
  duty_min.enableRemote();
  duty_max.enableRemote();
  period_hi.enableRemote();
  period_lo.enableRemote();

  /* PWM Input channel source and pin swap */
  papaya0.setFreqInCh2Source(0, 0);
  papaya0.setFreqInCh2Source(1, 0);

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    pulse_width.show();
    duty_measured.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}