var classhrv_time =
[
    [ "hrvTime", "classhrv_time.html#a1ac5805f793e9845fe6134027940ce61", null ]
];