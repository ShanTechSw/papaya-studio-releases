var struct_p_p___l_m_s_config =
[
    [ "delta", "struct_p_p___l_m_s_config.html#a2141f6ab22059af26cabd3697267041e", null ],
    [ "mu", "struct_p_p___l_m_s_config.html#a94fa2dc178340b5371fe58d9f89e0065", null ],
    [ "N", "struct_p_p___l_m_s_config.html#a7420e28b48d482c801c255dd5dc52825", null ],
    [ "normalize", "struct_p_p___l_m_s_config.html#ad0f525e7cf6030a04af1edfe29983f0c", null ]
];