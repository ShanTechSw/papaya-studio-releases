/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe id_current;
probe vq_command;
probe rotor_speed;
probe phase_voltage_a;
probe phase_voltage_b;

input id_ref;
input speed_ref;
input v_dc_hi;
input v_dc_lo;
input v_dc_hi_q;
input v_dc_lo_q;

/* Global Array Declarations */
float SIM__d_axis_winding_numerator[] = {1.0f};
float SIM__d_axis_winding_denominator[] = {0.002f, 0.5f};
float SIM__q_axis_winding_numerator[] = {1.0f};
float SIM__q_axis_winding_denominator[] = {0.002f, 0.5f};
float SIM__rotor_mechanics_numerator[] = {1.0f};
float SIM__rotor_mechanics_denominator[] = {0.02f, 0.05f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  id_ref = input("id_ref_A", 0.0f);
  speed_ref = input("speed_ref", 120.0f);
  v_dc_hi = input("v_dc_hi", 24.0f);
  v_dc_lo = input("v_dc_lo", -24.0f);
  v_dc_hi_q = input("v_dc_hi_q", 24.0f);
  v_dc_lo_q = input("v_dc_lo_q", -24.0f);
  signalSource SIM__rotor_angle = signalSource::sawtooth(50.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 6.283f);
  node d_axis_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid d_axis_PI = pid(800.0, 12.0, 0.0, 0.001);
  sat Vd_limit = sat();
  expander fan_vd = expander(2);
  tf SIM__d_axis_winding = tf(SIM__d_axis_winding_numerator, 1, SIM__d_axis_winding_denominator, 2);
  node speed_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid speed_PI = pid(8.0, 0.4, 0.0, 0.005);
  expander fan_2_2 = expander(1);
  node q_axis_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid q_axis_PI = pid(800.0, 12.0, 0.0, 0.001);
  sat Vq_limit = sat();
  expander fan_vq = expander(2);
  tf SIM__q_axis_winding = tf(SIM__q_axis_winding_numerator, 1, SIM__q_axis_winding_denominator, 2);
  expander fan_iq = expander(2);
  gain torque_constant = gain(0.1);
  tf SIM__rotor_mechanics = tf(SIM__rotor_mechanics_numerator, 1, SIM__rotor_mechanics_denominator, 2);
  expander fan_2 = expander(1);
  invPark inverse_Park = invPark();
  invClarke inverse_Clarke = invClarke();
  id_current = probe("id_current_A");
  vq_command = probe("vq_command_V");
  rotor_speed = probe("rotor_speed");
  phase_voltage_a = probe("phase_voltage_a");
  phase_voltage_b = probe("phase_voltage_b");

  /* Connect Blocks */
  id_ref > d_axis_error.in(0);
  speed_ref > speed_error.in(0);
  v_dc_hi > Vd_limit.in(0);
  v_dc_lo > Vd_limit.in(1);
  v_dc_hi_q > Vq_limit.in(0);
  v_dc_lo_q > Vq_limit.in(1);
  SIM__rotor_angle > fan_2;
  d_axis_error > d_axis_PI;
  d_axis_PI > Vd_limit.in(2);
  Vd_limit > fan_vd;
  fan_vd.out(0) > SIM__d_axis_winding;
  fan_vd.out(1) > inverse_Park.in(0);
  SIM__d_axis_winding > d_axis_error.in(1);
  SIM__d_axis_winding > id_current;
  speed_error > speed_PI;
  speed_PI > fan_2_2;
  fan_2_2 > q_axis_error.in(0);
  q_axis_error > q_axis_PI;
  q_axis_PI > Vq_limit.in(2);
  Vq_limit > fan_vq;
  Vq_limit > vq_command;
  fan_vq.out(0) > SIM__q_axis_winding;
  fan_vq.out(1) > inverse_Park.in(1);
  SIM__q_axis_winding > fan_iq;
  fan_iq.out(0) > q_axis_error.in(1);
  fan_iq.out(1) > torque_constant;
  torque_constant > SIM__rotor_mechanics;
  SIM__rotor_mechanics > speed_error.in(1);
  SIM__rotor_mechanics > rotor_speed;
  fan_2 > inverse_Park.in(2);
  inverse_Park.out(0) > inverse_Clarke.in(0);
  inverse_Park.out(1) > inverse_Clarke.in(1);
  inverse_Clarke.out(0) > phase_voltage_a;
  inverse_Clarke.out(1) > phase_voltage_b;

  /* Enable Remote Input Control */
  id_ref.enableRemote();
  speed_ref.enableRemote();
  v_dc_hi.enableRemote();
  v_dc_lo.enableRemote();
  v_dc_hi_q.enableRemote();
  v_dc_lo_q.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    id_current.show();
    vq_command.show();
    rotor_speed.show();
    phase_voltage_a.show();
    phase_voltage_b.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}