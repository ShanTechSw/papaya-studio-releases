var struct_p_p___a_d_r_c_config =
[
    [ "b0", "struct_p_p___a_d_r_c_config.html#a270d2b27e8d161df4d086add8dbb81ce", null ],
    [ "omega_c", "struct_p_p___a_d_r_c_config.html#a8fe0ac3ea2c6879c520f90ae0a1d6bc7", null ],
    [ "omega_o", "struct_p_p___a_d_r_c_config.html#a750898d19886938ae2d07cbd320182a5", null ],
    [ "order", "struct_p_p___a_d_r_c_config.html#a718ac8669b6e207b6e33e387fcf0615a", null ]
];