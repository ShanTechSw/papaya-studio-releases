/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe load_torque_0;
probe load_torque_1;
probe battery_soc_0;
probe battery_soc_1;
probe battery_soh_0;
probe battery_soh_1;
probe Battery_Soh_Ekf_tap;
probe acim_ekf_out0;
probe acim_ekf_out1;
probe Acim_Ekf_tap;
probe Acim_Ekf_tap_2;
probe Acim_Ekf_tap_3;
probe pmsm_ekf_out0;
probe pmsm_ekf_out1;
probe Pmsm_Ekf_tap;
probe Pmsm_Ekf_tap_2;

input const_;
input const__2;
input const__3;
input const__4;
input const__5;
input const__6;
input const__7;
input const__8;
input const__9;

/* Global Struct Declarations */
// TODO: populate fields of Load_Torque_Ekf_config before deploying.
//       See PAPAYA.h for the PP_LoadTorque_EKF struct layout.
PP_LoadTorque_EKF Load_Torque_Ekf_config = {};

// TODO: populate fields of Battery_Soc_Ekf_config before deploying.
//       See PAPAYA.h for the PP_BatterySOC_EKF struct layout.
PP_BatterySOC_EKF Battery_Soc_Ekf_config = {};

// Configuration for Battery_Soh_Ekf
static float Battery_Soh_Ekf_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Battery_Soh_Ekf_R_data[1] = {0.01f};
static float Battery_Soh_Ekf_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_BatterySOH_EKF Battery_Soh_Ekf_config = {
  .R1 = 0.01f,
  .C1 = 1000.0f,
  .ocv_coef = { 3.0f, 0.5f, 0.1f, 0.01f },
  .Q_data = Battery_Soh_Ekf_Q_data,
  .R_data = Battery_Soh_Ekf_R_data,
  .x_init = Battery_Soh_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Acim_Ekf
static float Acim_Ekf_Q_data[25] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Acim_Ekf_R_data[4] = {0.1f, 0.0f, 0.0f, 0.1f};
static float Acim_Ekf_x_init[5] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_ACIM_EKF Acim_Ekf_config = {
  .Rs = 1.5f,
  .Rr = 1.2f,
  .Ls = 0.17f,
  .Lr = 0.17f,
  .Lm = 0.16f,
  .P_pairs = 2.0f,
  .Q_data = Acim_Ekf_Q_data,
  .R_data = Acim_Ekf_R_data,
  .x_init = Acim_Ekf_x_init,
  .P_init = 1.0f
};

// TODO: populate fields of Pmsm_Ekf_config before deploying.
//       See PAPAYA.h for the PP_PMSM_EKF struct layout.
PP_PMSM_EKF Pmsm_Ekf_config = {};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(10.0f, 0.0f);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  const__3 = input("const", 0.0f);
  const__4 = input("const", 0.0f);
  const__5 = input("const", 0.0f);
  const__6 = input("const", 0.0f);
  const__7 = input("const", 0.0f);
  const__8 = input("const", 0.0f);
  const__9 = input("const", 0.0f);
  expander shared_measurement = expander(5);
  loadTorqueEKF Load_Torque_Ekf = loadTorqueEKF(&Load_Torque_Ekf_config);
  batterySOC_EKF Battery_Soc_Ekf = batterySOC_EKF(&Battery_Soc_Ekf_config);
  batterySOH_EKF Battery_Soh_Ekf = batterySOH_EKF(&Battery_Soh_Ekf_config);
  acimEKF Acim_Ekf = acimEKF(&Acim_Ekf_config);
  pmsmEKF Pmsm_Ekf = pmsmEKF(&Pmsm_Ekf_config);
  load_torque_0 = probe("load_torque_0");
  load_torque_1 = probe("load_torque_1");
  battery_soc_0 = probe("battery_soc_0");
  battery_soc_1 = probe("battery_soc_1");
  battery_soh_0 = probe("battery_soh_0");
  battery_soh_1 = probe("battery_soh_1");
  Battery_Soh_Ekf_tap = probe("Battery Soh_2");
  acim_ekf_out0 = probe("acim_ekf_out0");
  acim_ekf_out1 = probe("acim_ekf_out1");
  Acim_Ekf_tap = probe("Acim Ekf_o2");
  Acim_Ekf_tap_2 = probe("Acim Ekf_o3");
  Acim_Ekf_tap_3 = probe("Acim Ekf_o4");
  pmsm_ekf_out0 = probe("pmsm_ekf_out0");
  pmsm_ekf_out1 = probe("pmsm_ekf_out1");
  Pmsm_Ekf_tap = probe("Pmsm Ekf_o2");
  Pmsm_Ekf_tap_2 = probe("Pmsm Ekf_o3");

  /* Connect Blocks */
  Source > shared_measurement;
  const_ > Load_Torque_Ekf.in(1);
  const__2 > Battery_Soc_Ekf.in(1);
  const__3 > Battery_Soh_Ekf.in(1);
  const__4 > Acim_Ekf.in(1);
  const__5 > Acim_Ekf.in(2);
  const__6 > Acim_Ekf.in(3);
  const__7 > Pmsm_Ekf.in(1);
  const__8 > Pmsm_Ekf.in(2);
  const__9 > Pmsm_Ekf.in(3);
  shared_measurement.out(0) > Load_Torque_Ekf.in(0);
  shared_measurement.out(1) > Battery_Soc_Ekf.in(0);
  shared_measurement.out(2) > Battery_Soh_Ekf.in(0);
  shared_measurement.out(3) > Acim_Ekf.in(0);
  shared_measurement.out(4) > Pmsm_Ekf.in(0);
  Load_Torque_Ekf.out(0) > load_torque_0;
  Load_Torque_Ekf.out(1) > load_torque_1;
  Battery_Soc_Ekf.out(0) > battery_soc_0;
  Battery_Soc_Ekf.out(1) > battery_soc_1;
  Battery_Soh_Ekf.out(0) > battery_soh_0;
  Battery_Soh_Ekf.out(1) > battery_soh_1;
  Battery_Soh_Ekf.out(2) > Battery_Soh_Ekf_tap;
  Acim_Ekf.out(0) > acim_ekf_out0;
  Acim_Ekf.out(1) > acim_ekf_out1;
  Acim_Ekf.out(2) > Acim_Ekf_tap;
  Acim_Ekf.out(3) > Acim_Ekf_tap_2;
  Acim_Ekf.out(4) > Acim_Ekf_tap_3;
  Pmsm_Ekf.out(0) > pmsm_ekf_out0;
  Pmsm_Ekf.out(1) > pmsm_ekf_out1;
  Pmsm_Ekf.out(2) > Pmsm_Ekf_tap;
  Pmsm_Ekf.out(3) > Pmsm_Ekf_tap_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    load_torque_0.show();
    load_torque_1.show();
    battery_soc_0.show();
    battery_soc_1.show();
    battery_soh_0.show();
    battery_soh_1.show();
    Battery_Soh_Ekf_tap.show();
    acim_ekf_out0.show();
    acim_ekf_out1.show();
    Acim_Ekf_tap.show();
    Acim_Ekf_tap_2.show();
    Acim_Ekf_tap_3.show();
    pmsm_ekf_out0.show();
    pmsm_ekf_out1.show();
    Pmsm_Ekf_tap.show();
    Pmsm_Ekf_tap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}