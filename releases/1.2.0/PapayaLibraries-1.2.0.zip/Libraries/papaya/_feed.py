"""Shared core for every list Papaya Studio fetches over the network.

One version comparator, one address check, one way of opening a URL. Both
update checks and the Package Manager import from here rather than each
carrying their own, because two comparators answering one question is how
a direction arrow and an offer end up disagreeing on screen.

WHY THE COMPARATOR IS STRICT
----------------------------
The old one never failed. Anything it could not read became zero, so a
version string that did not parse produced a confident answer instead of
an error. Measured on the shipped code before this module existed:

    parse of "v2.0.0"   ->  major zeroed, so a v-prefixed list said the
                            user was up to date on every release
    parse of "banana"   ->  (0, 0, 0), so garbage said up to date
    parse of "1.2"      ->  silently became 1.2.0

The failure mode is the bad one: not an error a person can act on, but a
calm "you already have the latest version". So the parser here returns
``None`` for anything it cannot read, and the callers turn that into a
reported problem rather than a reassurance.

A NOTE ON PRE-RELEASE ORDER, WHICH IS NOT A BUG
-----------------------------------------------
``1.0.0-rc10`` sorts BELOW ``1.0.0-rc2``, and that is correct. The
specification says an identifier containing letters is compared as text,
so "rc10" and "rc2" are compared character by character and "1" comes
before "2". Only identifiers made purely of digits are compared as
numbers. The spelling that behaves the way people expect is the dotted
one, ``1.0.0-rc.10``, where "10" and "2" are separate numeric identifiers.
Both are implemented here, and both are tested, so nobody has to
rediscover this from a release that looked like it went backwards. Use the
dotted form when naming releases.

TRUST
-----
Nothing in this module decides whether a list is genuine. It checks that
an address is one we are willing to open and that a version is one we can
read. Whether the content is authentic is a separate question, answered by
the signature check that the release-signing work adds.
"""
from __future__ import annotations

import re
import ssl
import urllib.error
import urllib.parse
import urllib.request

#: Anything longer than this is not a version, it is an attack on the
#: parser or a mistake, and either way it is not worth the regex time.
_MAX_VERSION_CHARS = 256

#: MAJOR.MINOR.PATCH, optionally -prerelease, optionally +build.
_VERSION_RE = re.compile(
    r"\A(?P<major>0|[1-9]\d*)"
    r"\.(?P<minor>0|[1-9]\d*)"
    r"\.(?P<patch>0|[1-9]\d*)"
    r"(?:-(?P<pre>[0-9A-Za-z.-]+))?"
    r"(?:\+(?P<build>[0-9A-Za-z.-]+))?\Z")

_NUMERIC_RE = re.compile(r"\A(?:0|[1-9]\d*)\Z")


class FeedProblem(Exception):
    """A list could not be fetched or read. Carries a reason code."""

    def __init__(self, reason: str, detail: str = ""):
        super().__init__(detail or reason)
        self.reason = reason
        self.detail = detail


#: Reason codes. Kept separate from their wording so the wording can be
#: written for the person reading it without moving the logic.
REASON_ADDRESS = "address"        # the address is not one we will open
REASON_OFFLINE = "offline"        # nothing answered
REASON_CLOCK = "clock"            # the certificate is not valid *yet* or any more
REASON_TLS = "tls"                # some other secure-connection failure
REASON_HTTP = "http"              # answered, but with an error
REASON_TOO_BIG = "too_big"        # more data than a list should ever be
REASON_UNREADABLE = "unreadable"  # answered, but it is not a list we understand


def parse_version(text: object) -> tuple | None:
    """A sortable key for *text*, or ``None`` when it is not a version.

    ``None`` is the whole point. A comparator that cannot fail turns a
    typo in a published list into a silent "you are up to date".
    """
    if not isinstance(text, str):
        return None
    raw = text.strip()
    if not raw or len(raw) > _MAX_VERSION_CHARS:
        return None
    match = _VERSION_RE.match(raw)
    if match is None:
        return None

    core = (int(match.group("major")),
            int(match.group("minor")),
            int(match.group("patch")))
    pre = match.group("pre")
    if pre is None:
        # A release outranks every one of its own pre-releases.
        return (core, 1, ())

    identifiers: list[tuple] = []
    for part in pre.split("."):
        if part == "":
            return None                       # "1.0.0-" or "1.0.0-a..b"
        if _NUMERIC_RE.match(part):
            # Numeric identifiers rank below alphanumeric ones, so the
            # leading 0 puts them first.
            identifiers.append((0, int(part), ""))
        else:
            identifiers.append((1, 0, part))
    return (core, 0, tuple(identifiers))


def compare(left: object, right: object) -> int | None:
    """-1, 0 or 1, or ``None`` when either side is unreadable."""
    a = parse_version(left)
    b = parse_version(right)
    if a is None or b is None:
        return None
    return (a > b) - (a < b)


def is_newer(candidate: object, current: object) -> bool:
    """True only when *candidate* is readable, and newer than *current*.

    Deliberately False rather than raising when either side is
    unreadable, so a caller that only wants a yes or no keeps working.
    A caller that must tell "older" apart from "unreadable" should use
    :func:`compare`, which says so.
    """
    return compare(candidate, current) == 1


def safe_http_url(text: object) -> str | None:
    """The address, if it is one we are willing to open. Else ``None``.

    Applied to the resolved list address AND to every address read out of
    a list, before any of them reaches a network call or the desktop's
    "open this" handler. That second path is why this is not theoretical:
    opening a link on Windows hands the string to the shell, so a value
    taken from a downloaded list already reaches the operating system.

    Plain http is refused along with everything else. There is no address
    this product needs to open that cannot be https.
    """
    if not isinstance(text, str):
        return None
    raw = text.strip()
    if not raw or len(raw) > 2048 or any(c in raw for c in "\r\n\t"):
        return None
    try:
        parts = urllib.parse.urlsplit(raw)
    except ValueError:
        return None
    if parts.scheme != "https":
        return None
    if not parts.hostname:
        return None
    # Credentials in the address are a phishing shape and are never
    # something a published list needs.
    if parts.username or parts.password:
        return None
    return raw


def tls_context() -> ssl.SSLContext:
    """A context that verifies, explicitly rather than by default.

    Stated rather than inherited so that a change of default, or a frozen
    build that lost its trust store, is a visible decision rather than a
    silent downgrade to no verification at all.

    On Windows the trust store is the operating system's and is queried
    live. On Linux a frozen application inherits the build host's
    directory, which is a real risk for a portable bundle and is recorded
    as an open decision in the plan rather than papered over here.
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED
    return ctx


def _classify(exc: BaseException) -> tuple[str, str]:
    """Turn a network failure into a reason code and a short detail."""
    text = str(exc)
    if isinstance(exc, ssl.SSLCertVerificationError):
        # A machine whose clock is wrong reports a certificate that is not
        # valid yet, or expired. Telling that person to check their
        # internet connection sends them the wrong way entirely, and a
        # dead clock battery on a bench machine is common enough to be
        # worth its own answer.
        lowered = text.lower()
        if "not yet valid" in lowered or "has expired" in lowered \
                or "certificate is not valid" in lowered:
            return REASON_CLOCK, text
        return REASON_TLS, text
    if isinstance(exc, ssl.SSLError):
        return REASON_TLS, text
    if isinstance(exc, urllib.error.HTTPError):
        return REASON_HTTP, f"{exc.code}"
    if isinstance(exc, urllib.error.URLError):
        inner = getattr(exc, "reason", None)
        if isinstance(inner, ssl.SSLError):
            return _classify(inner)
        return REASON_OFFLINE, str(inner or text)
    return REASON_OFFLINE, text


def fetch(url: object, *, timeout: float = 6.0, user_agent: str,
          max_bytes: int = 262144) -> bytes:
    """Fetch a list. Raises :class:`FeedProblem` with a reason code.

    THE REQUEST CARRIES NOTHING ABOUT THIS MACHINE. No version, no board
    identity, no unique id, no query string: one constant name so the
    server can see that a Papaya Studio asked, and nothing else. The whole
    list is fetched and the comparison happens here.

    That is a deliberate property and not an accident of the current
    implementation, because the obvious next step is to filter server-side
    by part number, and a list request that names the board turns an
    update check into a beacon that reports every board and how often it
    is switched on. A test asserts this.
    """
    safe = safe_http_url(url)
    if safe is None:
        raise FeedProblem(REASON_ADDRESS, str(url)[:120])

    request = urllib.request.Request(safe, headers={"User-Agent": user_agent})
    try:
        with urllib.request.urlopen(                      # noqa: S310
                request, timeout=timeout, context=tls_context()) as response:
            # One byte more than the cap, so a list that is exactly at the
            # limit is not silently truncated and reported as unreadable.
            raw = response.read(max_bytes + 1)
    except FeedProblem:
        raise
    except Exception as exc:                              # noqa: BLE001
        reason, detail = _classify(exc)
        raise FeedProblem(reason, detail) from exc

    if len(raw) > max_bytes:
        raise FeedProblem(REASON_TOO_BIG, f"{len(raw)} bytes or more")
    return raw


# ===========================================================================
# Signed containers
#
# A published list is ONE file: a 68-byte header followed by the list's
# exact bytes. Not a list plus a separate signature file, and the reason is
# operational rather than cryptographic. Two files cannot be renamed
# atomically together, so every publish would leave a window where the two
# disagree, and a mismatch looks exactly like an attack. Anyone who
# publishes a few releases learns to click past that warning, which
# destroys the one message that has to be believed. One file, one rename,
# and "the signature is missing" stops being a state that can happen.
#
# The signed message is CONTEXT || 0x00 || key_id || body:
#
#   * CONTEXT keeps a signed package index from being served as an update
#     list.
#   * The NUL makes that separation hold for contexts that do not exist
#     yet. Without it "PP-FEED-v1" is a byte-prefix of a future
#     "PP-FEED-v10", and a prefix relationship between two contexts can be
#     turned into a collision by choosing the body.
#   * The key id is INSIDE the signed message, so flipping it cannot steer
#     anything. Unauthenticated metadata sitting next to a signature is
#     where the next weakness grows, and covering it costs nothing today
#     and cannot be added later without breaking the format.
# ===========================================================================

#: 4-byte key id, then a 64-byte signature.
CONTAINER_HEADER_LEN = 68

REASON_NOT_SIGNED = "not_signed"      # too short, or a reserved key id
REASON_KEY_UNKNOWN = "key_unknown"    # signed by a key this build never knew
REASON_KEY_RETIRED = "key_retired"    # signed by a key this install retired
REASON_SIG_BAD = "sig_bad"            # the signature does not match
REASON_NO_KEYS = "no_keys"            # this build has no keys at all
REASON_STALE = "stale"                # older than a list already seen

#: "Could not be confirmed genuine", as distinct from "could not be
#: reached". Grouped here rather than at each caller because the
#: distinction is the whole point of telling a user anything: sending
#: somebody to check their network cable because a signature did not
#: verify wastes their time and hides the real event.
SIGNATURE_REASONS = frozenset({
    REASON_NOT_SIGNED, REASON_KEY_UNKNOWN, REASON_KEY_RETIRED,
    REASON_SIG_BAD, REASON_NO_KEYS, REASON_STALE,
})

#: The list never arrived. These are the ones where looking at the network
#: is genuinely the right advice.
NETWORK_REASONS = frozenset({
    REASON_ADDRESS, REASON_OFFLINE, REASON_CLOCK, REASON_TLS, REASON_HTTP,
})


def signed_message(context: bytes, key_id_bytes: bytes, body: bytes) -> bytes:
    """The exact bytes a signature covers. Used by signer and verifier."""
    return context + b"\x00" + key_id_bytes + body


def stored_floor(name: str) -> int:
    """A floor this installation has already reached, or 0.

    A missing or damaged value falls back to zero rather than refusing:
    the guarantee comes from the value baked in at build time, and this
    is the improvement on top of it, not the thing being relied on.

    Lives here rather than in one caller because every signed list this
    product fetches needs the same two floors, and two copies of a rule
    about when a channel locks itself is two chances to drift.
    """
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        value = QSettings("Shanon Technologies", "Papaya Studio").value(
            name, 0, type=int)
        return max(0, int(value))
    except Exception:
        return 0


def raise_floor(name: str, value: object) -> None:
    """Move a floor up. Never down, and never before acceptance."""
    try:
        candidate = int(value)
    except (TypeError, ValueError):
        return
    if candidate <= stored_floor(name):
        return
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        settings = QSettings("Shanon Technologies", "Papaya Studio")
        settings.setValue(name, candidate)
        settings.sync()
    except Exception:
        pass


def verify_container(raw: bytes, context: bytes, *,
                     key_floor: int = 0) -> tuple[int, bytes]:
    """Return ``(key_id, body)`` for a container, or raise ``FeedProblem``.

    Nothing after the signature check touches a byte that has not been
    proven to come from a key we trust. Nothing before it is allowed to
    make a decision.

    *key_floor* is the lowest key id this installation still accepts. It
    only ever rises, and only after a list has been fully accepted, so a
    forged list cannot brick the channel by planting a high floor.
    """
    from . import _release_keys as keys

    if not keys.keys_are_provisioned():
        raise FeedProblem(REASON_NO_KEYS, "no publishing keys in this build")

    if not isinstance(raw, (bytes, bytearray)):
        raise FeedProblem(REASON_NOT_SIGNED, "not bytes")
    raw = bytes(raw)
    if len(raw) <= CONTAINER_HEADER_LEN:
        raise FeedProblem(REASON_NOT_SIGNED, f"{len(raw)} bytes")

    key_id_bytes = raw[0:4]
    key_id = int.from_bytes(key_id_bytes, "big")
    if key_id in keys.KEY_ID_RESERVED:
        raise FeedProblem(REASON_NOT_SIGNED, f"reserved key id {key_id}")
    if key_id < key_floor:
        raise FeedProblem(REASON_KEY_RETIRED,
                          f"key {key_id} below floor {key_floor}")

    public = keys.public_key_for(key_id)
    if public is None:
        raise FeedProblem(REASON_KEY_UNKNOWN, f"key {key_id}")

    signature = raw[4:CONTAINER_HEADER_LEN]
    body = raw[CONTAINER_HEADER_LEN:]
    from . import ed25519
    if not ed25519.verify(public, signed_message(context, key_id_bytes, body),
                          signature):
        raise FeedProblem(REASON_SIG_BAD, f"key {key_id}")
    return key_id, body


def open_signed_feed(raw: bytes, context: bytes, *,
                     key_floor: int = 0, serial_floor: int = 0) -> dict:
    """Verify, parse and range-check a published list. Returns the document.

    Steps 7 onward of the check. Nothing here runs until the signature has
    already been proven, so every value below is one a trusted key put
    there. The order still matters: a field that is missing or out of
    range is a refusal, never a value quietly treated as zero.

    Returns the parsed document with two extra keys the caller needs and
    cannot re-derive safely: ``__key_id__`` and ``__serial__``. The caller
    raises its stored floors from those ONLY after it has accepted the
    list, so a forged one can never brick the channel by planting a floor.
    """
    import json
    from . import _feed_schema as schema

    key_id, body = verify_container(raw, context, key_floor=key_floor)

    if len(body) > schema.MAX_FEED_BYTES:
        raise FeedProblem(REASON_TOO_BIG, f"{len(body)} bytes")
    try:
        document = json.loads(body.decode("utf-8"))
    except Exception as exc:                              # noqa: BLE001
        raise FeedProblem(REASON_UNREADABLE, f"not readable: {exc}") from exc
    if not isinstance(document, dict):
        raise FeedProblem(REASON_UNREADABLE, "not a list document")

    serial = schema.parse_serial(document.get(schema.FIELD_SERIAL))
    if serial is None:
        # Refused, never waved through. A signed list with no readable
        # counter is tooling output nobody checked, and accepting it would
        # switch the replay protection off in silence.
        raise FeedProblem(REASON_UNREADABLE,
                          f"{schema.FIELD_SERIAL} is missing or out of range")

    min_key_id = document.get(schema.FIELD_MIN_KEY_ID)
    if isinstance(min_key_id, bool) or not isinstance(min_key_id, int):
        raise FeedProblem(REASON_UNREADABLE,
                          f"{schema.FIELD_MIN_KEY_ID} is missing")
    if not 1 <= min_key_id <= key_id:
        # A list demanding a floor above the key that signed it is
        # self-inconsistent: it would retire itself.
        raise FeedProblem(REASON_UNREADABLE,
                          f"{schema.FIELD_MIN_KEY_ID} {min_key_id} is not "
                          f"usable with signing key {key_id}")

    if serial < serial_floor:
        raise FeedProblem(REASON_STALE, f"{serial} below {serial_floor}")

    document["__key_id__"] = key_id
    document["__serial__"] = serial
    return document


def feed_is_stale(document: dict, *, today=None) -> bool:
    """True when the list has not changed for a long time.

    The one thing a replay floor cannot see. Somebody who can serve
    today's genuine list forever keeps a user from ever learning that a
    fix exists, and the floor is happy because nothing went backwards.

    A note, never a refusal. Refusing on age at a small company would take
    the product down during any quiet quarter, and the field is in the
    format from the first release, so the policy can tighten later without
    a format change.
    """
    import datetime as _dt
    from . import _feed_schema as schema

    text = document.get(schema.FIELD_PUBLISHED)
    if not isinstance(text, str):
        return False
    try:
        when = _dt.date.fromisoformat(text.strip()[:10])
    except ValueError:
        return False
    now = today or _dt.date.today()
    return (now - when).days > schema.STALE_AFTER_DAYS
