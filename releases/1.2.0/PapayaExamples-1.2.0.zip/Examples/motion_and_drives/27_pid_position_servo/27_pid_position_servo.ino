/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe position_counts;
probe motor_current_tap;

input setpoint_counts;
input duty_min;
input duty_max;
input rate_limiter_up;
input rate_limiter_dn;

/* Global Struct Declarations */
// Configuration for DC_motor
PP_motorBlockCfg DC_motor_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  2,
  {MotorPosition, MotorCurrent, NoMotorOutput}
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  setpoint_counts = input("setpoint_counts", 90.0f);
  duty_min = input("duty_min", -1.0f);
  duty_max = input("duty_max", 1.0f);
  rate_limiter_up = input("rate_limiter_up", 5.0f);
  rate_limiter_dn = input("rate_limiter_dn", 5.0f);
  node Error = node("[1.0 -1.0]", "[1.0]", Sum);
  pidAw PID = pidAw(0.2f, 0.8f, 0.04f, 0.01f, -1f, 1f, 0f, 2, 0);
  sat Duty_clamp = sat();
  rateLimiter Rate_limiter = rateLimiter();
  motor DC_motor = motor(&DC_motor_config);
  position_counts = probe("position_counts");
  motor_current_tap = probe("motor_current");

  /* Connect Blocks */
  setpoint_counts > Error.in(0);
  duty_min > Duty_clamp.in(1);
  duty_max > Duty_clamp.in(0);
  rate_limiter_up > Rate_limiter.in(1);
  rate_limiter_dn > Rate_limiter.in(2);
  Error > PID;
  PID > Duty_clamp.in(2);
  Duty_clamp > Rate_limiter.in(0);
  Rate_limiter > DC_motor;
  DC_motor.out(0) > Error.in(1);
  DC_motor.out(0) > position_counts;
  DC_motor.out(1) > motor_current_tap;

  /* Enable Remote Input Control */
  setpoint_counts.enableRemote();
  duty_min.enableRemote();
  duty_max.enableRemote();
  rate_limiter_up.enableRemote();
  rate_limiter_dn.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    position_counts.show();
    motor_current_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}