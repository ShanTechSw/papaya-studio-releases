var classeeg_bandpower =
[
    [ "eegBandpower", "classeeg_bandpower.html#a4f1b39735dc32df9ee19ce61488ccb65", null ]
];