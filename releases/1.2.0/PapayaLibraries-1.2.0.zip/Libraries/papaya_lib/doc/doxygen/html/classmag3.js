var classmag3 =
[
    [ "mag3", "classmag3.html#a4122bdefff28c63a603b422f8afb11bf", null ]
];