"""Stray flux: an electrical fault found from outside the cabinet.

Run this beside example 93.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  broken bar      the bar ratio: how much the leakage field is modulated at
                  twice the slip frequency, as a fraction of the supply
                  line. Modulation at 2sf is what a broken or cracked rotor
                  bar does and nothing else does it.

  eccentricity    the eccentricity ratio: modulation at the ROTOR rate
                  instead, which is what an air gap that is not concentric
                  produces.

  is the motor
  even running    the supply line itself. Both ratios divide by it, so a
                  motor that is switched off makes both of them meaningless
                  rather than zero, and this script refuses to report them
                  when the line is not there.

  and the point   the accelerometer is read at the same moment. Neither of
                  these faults moves it, which is why they are missed by
                  vibration programmes.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 45.0
DECIDE_EVERY = 0.5

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "broken rotor bar", "eccentricity")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "flux"
FEATURES = ("e_supply", "e_beat", "e_ecc", "env_rms", "bar_ratio",
            "ecc_ratio", "a_rms", "state")

SUPPLY_PRESENT = 1.0        # uT: below this the motor is not energised
BAR_ALERT = 0.010           # bar ratio
BAR_ALARM = 0.025
ECC_ALERT = 0.008           # eccentricity ratio
ECC_ALARM = 0.015
ACCEL_BASELINE = 0.0145     # g, the accelerometer on a healthy machine

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def classify(row):
    supply = row["e_supply"]
    reasons = [
        f"supply line {supply:.3f} uT, envelope level {row['env_rms']:.3f} "
        f"uT",
        f"slip beat {row['e_beat']:.5f} uT, rotor-line ripple "
        f"{row['e_ecc']:.5f} uT",
        f"ratios: bar {row['bar_ratio']:.4f}, eccentricity "
        f"{row['ecc_ratio']:.4f}",
    ]

    # Nothing below means anything if the machine is not running.
    if supply < SUPPLY_PRESENT:
        return ("not energised",
                "no supply line in the field: the motor is off, or the "
                "sensor is nowhere near it",
                reasons + ["both ratios divide by that line, so both are "
                           "meaningless rather than zero"])

    accel_level = row["a_rms"] / max(ACCEL_BASELINE, 1e-12)
    reasons.append(
        f"the accelerometer reads {row['a_rms']:.4f} g, {accel_level:.2f}x "
        f"its healthy value")

    bar, ecc = row["bar_ratio"], row["ecc_ratio"]
    if bar >= BAR_ALARM:
        return ("broken rotor bar",
                "a broken or cracked rotor bar, and it is not marginal",
                reasons + ["twice the slip frequency depends on load: this "
                           "reading is only as good as the load the motor "
                           "was under"])
    if ecc >= ECC_ALARM:
        return ("eccentricity",
                "an eccentric air gap: a bent shaft, worn bearings, or a "
                "stator that is not concentric with the rotor", reasons)
    if bar >= BAR_ALERT:
        return ("broken rotor bar",
                "an early rotor-bar signature, worth trending rather than "
                "acting on", reasons)
    if ecc >= ECC_ALERT:
        return ("eccentricity", "an early eccentricity signature", reasons)
    return ("healthy",
            "the field is a clean supply line with nothing modulating it",
            reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 93_stray_flux_electrical_faults.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA stray-flux electrical fault monitor")
    print("=" * 72)
    print("Every motor leaks a field, and that field carries the same "
          "fault information\nthe stator current does, with no clamp meter "
          "and nothing opened.")
    print(f"\nThe motor counts as energised above {SUPPLY_PRESENT:.1f} uT "
          f"of supply line.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
