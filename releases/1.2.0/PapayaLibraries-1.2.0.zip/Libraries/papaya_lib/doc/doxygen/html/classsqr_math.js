var classsqr_math =
[
    [ "sqrMath", "classsqr_math.html#af743f9235b628dbd37a2ef2598eae22d", null ]
];