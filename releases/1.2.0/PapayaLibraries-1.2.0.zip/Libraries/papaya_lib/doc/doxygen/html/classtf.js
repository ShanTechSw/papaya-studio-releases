var classtf =
[
    [ "tf", "classtf.html#ad04353caa1e843a518a5ff0be2f74bbb", null ],
    [ "tf", "classtf.html#a140f6d71253ecd154f08029573140a31", null ],
    [ "tf", "classtf.html#aa1e6d044416432636c434d67d7c7904b", null ],
    [ "getContextSlot", "classtf.html#ac13f8cb21c1c7ce97839dad1a41a355c", null ],
    [ "getId", "classtf.html#a3cccb2e5524ab1d618f80a789d007025", null ],
    [ "operator>", "classtf.html#ae52f3d7ab261eafc8ed0d2010e2007eb", null ],
    [ "operator>", "classtf.html#ada9fb54e4962938b6f62b5745ac7b8e9", null ],
    [ "operator>", "classtf.html#a52497c99616d5775dbf27eaf8631ec94", null ],
    [ "operator>", "classtf.html#ad7b3b5fd2577f759cff52ff8ec46173c", null ],
    [ "operator>>", "classtf.html#ae8f0ffcaff5ef6851dcafb82b54e5131", null ],
    [ "setContextSlot", "classtf.html#aad4cec5411462ec305b14369e2e32ec4", null ],
    [ "setId", "classtf.html#a65c4592053c81845f52a4c0012398a6b", null ],
    [ "contextSlot", "classtf.html#a33af4e46a6b3312106c72efc22d731af", null ],
    [ "currentSysId", "classtf.html#a0d9b2c0722e5cca65a595e2d0b4eea3d", null ],
    [ "dataLines", "classtf.html#a4c85e8036b6ac73b36f846ab287493e5", null ],
    [ "dataRaw", "classtf.html#a444f48b3a52b719245a648d46c1e6f09", null ],
    [ "id", "classtf.html#a26d0afb9d748dcaf56c0f8975c7b9613", null ]
];