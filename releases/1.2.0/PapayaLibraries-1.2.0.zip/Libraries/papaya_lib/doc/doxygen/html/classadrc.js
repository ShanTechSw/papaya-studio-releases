var classadrc =
[
    [ "adrc", "classadrc.html#afa0a2d672565fb5afd05f49d0b8f8e87", null ]
];