"""USB transport backend for the papaya Python library.

When activated, every command built by the library is sent to the
PAPAYA board over USB and the real response code is returned.

Usage in generated scripts::

    from papaya import *
    from papaya.usb_transport import connect_usb

    connect_usb()  # opens USB, hooks CTX

    papaya0 = PAPAYA(0)
    papaya0.startDesign(1000, PP_C2dAlgo.Tustin)
    # ^^^ actually sent to the board; response printed
"""

from __future__ import annotations

import os
import socket
import struct
import sys
import time
from typing import NamedTuple, Optional

from .constants import (
    PP_CMD_CRC_SIZE,
    PP_CMD_HEADER_SIZE,
    PP_CMD_READ,
    PP_CMD_READ_VECT_PROBE,
    PP_CMD_RESPONSE_ID,
    PP_CMD_SWITCH_BACK_TO_CFG,
    PP_CMD_WRITE,
    PP_CHUNK_MAX_SIZE,
    PP_RESPONSE_POLL_INTERVAL_MS,
    PP_RESPONSE_REQ_SIZE,
    PP_RESPONSE_SIZE,
    PP_RESPONSE_TIMEOUT_MS,
)
from .enums import PP_ComStatus, PP_DesignStatus

# Re-use the CRC from context (import the class, call static method)
from .context import CTX, PapayaContext
from ._no_console import no_window


# ── USB constants ──────────────────────────────────────────────────────────
VENDOR_ID = 0x270F
PRODUCT_ID = 0x15B3
EP_OUT = 0x01
EP_IN = 0x81

#: Smallest buffer a bulk-IN read may ask for.  An IN transfer already waiting
#: on the endpoint that is LARGER than the read buffer is an overflow, not a
#: short read, so the buffer has to be able to hold one whole packet.  A
#: full-speed board packs 64 bytes per packet and a high-speed one 512; 1024 is
#: a multiple of both, so a read of this size cannot overflow whatever the
#: board negotiates.  Same figure, same reason, as BRIDGE_READ_GRANULARITY.
READ_GRANULARITY = 1024

#: The device-access rule's filename, and the two places it legitimately
#: lives. Named here so the diagnostic below and the packaging that places
#: the file cannot drift apart; the file itself is
#: ``drivers/linux/70-papaya.rules`` in the source tree.
#:
#: The 70 prefix is not cosmetic: udev evaluates rules files once in lexical
#: order, and the ``uaccess`` tag is only acted on by systemd's
#: ``73-seat-late.rules``, so a rule numbered above 73 sets a tag nothing
#: ever reads. The rule file's own header explains it at length.
UDEV_RULES_NAME = "70-papaya.rules"
#: Where a user installs it by hand (and where the AppImage's copy must go).
UDEV_RULES_TARGET = f"/etc/udev/rules.d/{UDEV_RULES_NAME}"
#: Where the .deb puts it. A packaged install has no file at
#: UDEV_RULES_TARGET, so a diagnostic naming only that path tells a .deb
#: user their rule is missing on a machine where it is correctly installed.
UDEV_RULES_PACKAGED = f"/usr/lib/udev/rules.d/{UDEV_RULES_NAME}"


def permission_hint(err: Exception | None = None) -> list[str]:
    """Advice lines for a USB open that failed, chosen by platform.

    The same libusb error code means different things on different
    systems, and the wrong advice costs the user real time. On Windows,
    access denied on a device that enumerated almost always means another
    handle is already holding it. On Linux it almost always means the
    device node belongs to root because the udev rule is not installed,
    and telling that user to replug the board sends them round a loop that
    cannot terminate.
    """
    if sys.platform.startswith("linux"):
        denied = getattr(err, "errno", None) == 13 or "access" in str(err).lower()
        if denied:
            return [
                "Hint: the board is connected but this user is not allowed to open it.",
                f"      The package installs a device rule at {UDEV_RULES_PACKAGED}.",
                f"      If you installed by hand, put it at {UDEV_RULES_TARGET}.",
                "      Then reload the rules:",
                "          sudo udevadm control --reload-rules && sudo udevadm trigger",
                "      Replugging the board also applies it.",
            ]
        return [
            "Hint: unplug the board for 3 s then plug it back in, and make sure",
            "      no other PAPAYA Studio or Python session is holding the device.",
            "      If this repeats, check that the device rule is installed at",
            f"      {UDEV_RULES_PACKAGED} or {UDEV_RULES_TARGET}.",
        ]
    denied = getattr(err, "errno", None) in (13, 16) or "access" in str(err).lower()
    if denied:
        # Lead with what it almost always is. A board that enumerated and
        # then refused to open is being held by something else; saying
        # "unplug it" first sends people round driver reinstalls and
        # running as administrator, none of which can help. Misread here
        # once as the BOARD being wedged, because a reset appears to cure
        # it: re-enumerating invalidates the stale handle.
        return [
            "Hint: the board is plugged in, but another program already has it open.",
            "      Only one program can use a board at a time. Close PAPAYA Studio,",
            "      or the panel or script that attached to it, and try again.",
            "      A script releases the board when it calls close() on the design,",
            "      or when it exits.",
            "      If nothing else is running, unplug the board for 3 s and replug it:",
            "      a session that crashed can leave the handle claimed until then.",
        ]
    return [
        "Hint: unplug the board for 3 s then plug it back in,",
        "      and make sure PAPAYA Studio (or another Python",
        "      session) is not holding the device.",
    ]


def _crc32(data: bytes, length: int) -> int:
    return PapayaContext.calculate_crc(data, length)


class ProbeBatch(NamedTuple):
    """One auto-push batch of scalar-probe data, with its provenance.

    ``values`` is the compact ``n_probes * 4`` byte buffer holding the
    newest sample of each probe, what ``probe.getVal()`` ends up reading.
    ``seq`` is the transport-level sequence number of the packet the batch
    came from, or ``None`` on a transport that does not carry one.
    ``samples_per_probe`` is how many samples the board packed per probe,
    detected from the packet length.  ``skipped`` is how many older
    batches were discarded to reach this one (only a draining read sets
    it).
    """

    values: bytes
    seq: Optional[int]
    samples_per_probe: int
    skipped: int = 0

    def with_skipped(self, skipped: int) -> "ProbeBatch":
        return self._replace(skipped=int(skipped))


#: Consecutive short reads before the batch-size latch re-learns. A batch
#: depth changed at runtime shrinks every frame from then on, and without a
#: way back the latch would reject all of them for ever.
_PROBE_BATCH_RELEARN_AFTER = 50

class PapayaUSBTransport:
    """Lightweight USB transport that plugs into PapayaContext.

    Talks to the board with PyUSB. An application that already holds a
    faster native link to the same board may install it on this transport
    before :meth:`connect` is called, and every command then travels over
    that link instead; this module never goes looking for one, so a
    standalone program always gets the PyUSB path.
    """

    #: Whether THIS process may close the device and open it again.
    #:
    #: True here: the transport owns a libusb handle and can reopen it
    #: whenever it likes. False on a lent link, where the device belongs
    #: to another process and the way back in is a one-shot token that
    #: has already been spent. Anything that would disconnect and
    #: reconnect has to ask first; on a lent link that sequence does not
    #: recover the session, it ENDS it.
    reopenable_by_this_process: bool = True

    #: True once the board has ANSWERED StartSampling with DesignOk on
    #: this link, and false again after a stop or a reset. It is what
    #: :meth:`quiesce` trusts instead of reading the endpoint, because a
    #: board whose auto-push has stalled reads exactly like an idle one.
    #:
    #: A CLASS attribute on purpose: instances built without ``__init__``
    #: (test doubles do this) then inherit a truthful False rather than
    #: raising, and only a link that really started sampling ever sets an
    #: instance value over the top of it.
    _sampling_started: bool = False

    def note_sampling_started(self) -> None:
        """Record that the board accepted StartSampling on this link."""
        self._sampling_started = True

    def note_sampling_stopped(self) -> None:
        """Record that the board is no longer in data exchange."""
        self._sampling_started = False

    # The probe-batch size latch (see poll_probe_batch). On the CLASS, not
    # only in the constructor: the Studio bridge client subclasses this
    # transport and deliberately does not run this constructor, and when
    # the latch lived only here every probe read through the bridge
    # raised AttributeError on its first batch. Found by driving the
    # product's own Run button on 2026-09-07; a direct-USB harness could
    # not see it because it never goes through the bridge.
    _probe_batch_bytes = 0
    _probe_batch_short_run = 0

    def __init__(self) -> None:
        self._dev = None
        self._connected = False

        # How long a whole scalar probe batch is, learned from the wire. A
        # read that comes back short would otherwise be taken for a smaller
        # batch and mis-sliced; see poll_probe_batch.
        self._probe_batch_bytes = 0
        self._probe_batch_short_run = 0

        # The optional native fast path, and it stays None unless something
        # installs one. This library never imports an accelerator: when the
        # application around it already holds a faster link to the board it
        # assigns that link here before connect() is called, and the send /
        # poll methods below route through it. A generated program run on
        # its own has nobody to do that, so it uses PyUSB throughout, which
        # is the supported standalone path and not a degraded one.
        #
        # The one behavioural difference is the extra data-response payload
        # some commands send after their status word. Only the PyUSB path
        # can read it, so listAudioSlots(), getAudioSlotInfo() and
        # downloadAudioSlot() return data on that path and return None when
        # a native fast path is active. supports_data_response() reports
        # which path is live, and PAPAYA_FORCE_PYUSB=1 keeps this transport
        # on PyUSB whatever was installed.
        self._engine = None
        # When True (default) this transport owns its libusb handle:
        # ``disconnect()`` releases + disposes it.  When False the
        # handle was injected by another owner, and ``disconnect()``
        # only clears the internal reference, leaving the real handle
        # alive for that owner.  Papaya Studio injects its handle this
        # way when it launches a program, so the program and Studio
        # share one link instead of both trying to claim the board.
        self._owns_handle = True

    @property
    def is_connected(self) -> bool:
        return self._connected and self._dev is not None

    def connect(self) -> bool:
        # Kill switch, honoured before anything is opened.
        #
        # A test suite runs generated programs, and a generated program's
        # first act is to claim the board, in a SUBPROCESS, where an
        # in-process pytest fixture cannot reach it. One such test ran the
        # generated main.py, which connected, deployed a design, called
        # startSampling() and exited without stopping it. That leaves the
        # board auto-pushing into an endpoint nobody drains, which no
        # host-side path recovers: only a physical replug does.
        #
        # An environment variable is the one mechanism that crosses a
        # process boundary by inheritance, so the guard lives here rather
        # than in the caller.
        if os.environ.get("PAPAYA_REFUSE_HARDWARE", "").strip():
            print("USB: refused. PAPAYA_REFUSE_HARDWARE is set "
                  "(a test run must not open a real board)")
            return False

        # The Studio bridge selector, honoured before anything is opened:
        # the same crosses-the-process-boundary mechanism as the kill
        # switch above. When PAPAYA_HOST_BRIDGE is set, PAPAYA Studio
        # launched this process, KEPT the USB device open, and serves
        # this program's board bytes over loopback TCP (see
        # :class:`PapayaStudioBridgeTransport` below; the C++ twin is
        # papaya_lib/ports/pc_usb/PapayaStudioBridge). A direct libusb
        # claim from such a process is exactly the second-claim
        # collision documented in :func:`connect_usb` (it can wedge the
        # board until a physical replug), so it is refused LOUDLY here,
        # never fallen into silently. ``connect_usb()`` selects the
        # bridge transport before this class is ever reached; landing on
        # this raise means some caller built the direct transport by
        # hand inside a bridged process.
        if os.environ.get("PAPAYA_HOST_BRIDGE", "").strip():
            raise RuntimeError(
                "PAPAYA studio-bridge transport: PAPAYA_HOST_BRIDGE is "
                "set, so PAPAYA Studio holds this board's USB device open "
                "and this process must talk to it through the Studio "
                "bridge. Refusing to claim the device directly: use "
                "papaya.usb_transport.connect_usb(), which selects the "
                "bridge transport.")

        # PAPAYA_FORCE_PYUSB=1 discards any installed native fast path for
        # the rest of the session. It is checked here rather than at
        # construction because a fast path is installed BETWEEN construction
        # and this call. Set it when the program needs the extra
        # data-response payload of listAudioSlots(), getAudioSlotInfo() or
        # downloadAudioSlot(), which only the PyUSB path can read.
        if self._engine is not None and os.environ.get(
                "PAPAYA_FORCE_PYUSB", "").strip():
            self._engine = None

        # Prefer the native fast path when one is installed.
        if self._engine is not None:
            if self._engine.connect(VENDOR_ID, PRODUCT_ID):
                self._connected = True
                try:
                    self._engine.negotiate_v2()
                except Exception:
                    pass
                print(f"USB: Connected via the native fast path "
                      f"(V{self._engine.protocol_version()})")
                return True
            self._engine = None  # fall back to PyUSB

        try:
            import usb.core
            import usb.util
        except ImportError:
            print("ERROR: pyusb is required.  pip install pyusb")
            return False

        # Hand pyusb the libusb we ship rather than letting it search.
        # On Linux the search cannot see inside our own bundle at all; see
        # papaya/_libusb_backend.py for why. Returns None when nothing is
        # bundled, which means "pyusb, decide for yourself" and leaves a
        # machine with a working system libusb exactly as it was.
        from ._libusb_backend import get_backend
        backend = get_backend()

        dev = usb.core.find(idVendor=VENDOR_ID, idProduct=PRODUCT_ID, backend=backend)
        if dev is None:
            print("ERROR: PAPAYA board not found.  Check USB connection.")
            return False

        # set_configuration is idempotent on a freshly-plugged device,
        # but on Windows WinUSB it raises [Errno 13] Access denied when
        # another handle (or a prior leaked handle from a crashed run)
        # already holds the device in that configuration. Treat that
        # error as "already configured" and continue, but re-raise
        # anything else (e.g. truly missing permissions).
        try:
            dev.set_configuration()
        except usb.core.USBError as e:
            try:
                active = dev.get_active_configuration()
            except Exception:
                active = None
            if active is None:
                print(f"ERROR: USB set_configuration failed: {e}")
                for line in permission_hint(e):
                    print(line)
                return False
            # Device already configured: harmless, keep going.

        try:
            usb.util.claim_interface(dev, 0)
        except usb.core.USBError as e:
            # Same story for claim_interface: a prior run that crashed
            # mid-session can leave Windows thinking the interface is
            # still claimed. Retry once after releasing any stale claim.
            try:
                usb.util.release_interface(dev, 0)
            except Exception:
                pass
            try:
                usb.util.claim_interface(dev, 0)
            except usb.core.USBError as e2:
                print(f"ERROR: USB claim_interface failed: {e2}")
                for line in permission_hint(e2):
                    print(line)
                return False

        self._dev = dev
        self._connected = True

        print(f"USB: Connected to PAPAYA board (VID=0x{VENDOR_ID:04X} PID=0x{PRODUCT_ID:04X})")
        return True

    def disconnect(self) -> None:
        # Stop the board BEFORE letting go of the handle.  Releasing a
        # libusb handle does not stop a sampling design: the board keeps
        # auto-pushing into an endpoint nobody reads, and from that point
        # on nothing short of a power-cycle brings it back (see
        # :meth:`quiesce`).  Best-effort and never fatal: a disconnect
        # must always complete.
        try:
            self.quiesce()
        except Exception:
            pass
        if self._engine is not None and self._engine.is_connected():
            self._engine.disconnect()
        if self._dev is not None:
            # When ``_owns_handle`` is False the libusb device was
            # injected by another component: Papaya Studio lends its own
            # open handle to a debugged program so the program can send
            # frames over the shared link without opening a second one.
            # Releasing or disposing that shared handle would invalidate
            # it for the lender: the visible symptom is that Studio
            # stops receiving anything after the program resets its
            # transport state.  Skip the libusb teardown in that case
            # and just clear our own reference; the lender releases the
            # handle on its own schedule.
            if getattr(self, "_owns_handle", True):
                try:
                    import usb.util
                    usb.util.release_interface(self._dev, 0)
                except Exception:
                    pass
                try:
                    import usb.util
                    usb.util.dispose_resources(self._dev)
                except Exception:
                    pass
            self._dev = None
        self._connected = False
        print("USB: Disconnected")

    # ── low-level I/O ──────────────────────────────────────────────────
    def _write(self, data: bytes, timeout_ms: int = 2000) -> bool:
        import usb.core
        try:
            self._dev.write(EP_OUT, data, timeout=timeout_ms)
            return True
        except usb.core.USBError as e:
            print(f"USB write error: {e}")
            return False

    def _read_stream_frame(self, size: int, timeout_ms: int) -> Optional[bytes]:
        """One board-initiated auto-push frame, opcode byte included.

        A SEAM, not a synonym for :meth:`_read`. On a direct link the two
        are the same thing: whatever arrives next on the endpoint. Over
        the Studio's bridge they are emphatically not, because the Studio
        is reading that endpoint too, and a request for "the next bytes"
        cannot say whether the caller wants its command's answer or the
        board's next batch. Auto-push reads come through here so the
        other end can serve them from this client's own copy of the
        stream, and command responses keep using ``_read``, which stays
        the synchronous round-trip it has always been.
        """
        return self._read(size, timeout_ms)

    def _read(self, size: int, timeout_ms: int) -> Optional[bytes]:
        import usb.core
        try:
            data = self._dev.read(EP_IN, size, timeout=timeout_ms)
            return bytes(data)
        except usb.core.USBTimeoutError:
            return None
        except usb.core.USBError as e:
            print(f"USB read error: {e}")
            return None

    def _read_exact(self, size: int, timeout_ms: int) -> Optional[bytes]:
        if size <= 0:
            return b""
        deadline = time.monotonic() + max(timeout_ms, 1) / 1000.0
        buf = bytearray()
        while len(buf) < size and time.monotonic() < deadline:
            remaining_ms = max(1, int((deadline - time.monotonic()) * 1000))
            chunk = self._read(size - len(buf), remaining_ms)
            if chunk is not None:
                buf.extend(chunk)
        return bytes(buf[:size]) if len(buf) >= size else None

    def drain_in(self, timeout_ms: int = 30) -> int:
        """Discard any stale bytes sitting on the bulk-IN endpoint.

        A data-response command (DownloadAudioSlot, DownloadTrace, ...) can
        leave a framing tail on the endpoint after the caller has read its
        fixed-size payload.  Issued back-to-back, the next command's 7-byte
        status read would then pick up that tail, fail to parse it as a
        status frame, and time out.  Call this immediately before sending
        such a command.  Returns the number of stale bytes drained.
        """
        if self._dev is None:
            return 0
        drained = 0
        for _ in range(16):
            leftover = self._read(4096, timeout_ms)
            if not leftover:
                break
            drained += len(leftover)
        return drained

    # ── frame send + response poll ─────────────────────────────────────
    def send_frame(self, header: bytes, body: bytes, seq: int, *, vect: bool = False,
                   expect_response: bool = True) -> Optional[int]:
        """Send header + chunked body, optionally poll for response.

        Returns the status byte (PP_DesignStatus) or None on timeout.
        When ``expect_response`` is False (e.g. for ``mcuReset`` where
        the MCU reboots before it can answer), the function sends the
        frame and returns 0 without polling, avoiding the spurious
        ``USB write error`` and ``NO RESPONSE (timeout)`` log noise.
        """
        # Use the native fast path when one is installed and live: it polls
        # at 2 ms where the PyUSB path waits 20 ms between polls.
        if self._engine is not None and self._engine.is_connected():
            if not expect_response:
                # A fast path has no fire-and-forget call, so use the normal
                # one and swallow its timeout or error silently.
                try:
                    self._engine.send_frame_v1(header, body)
                except Exception:
                    pass
                return 0
            status = self._engine.send_frame_v1(header, body)
            return status if status >= 0 else None

        # PyUSB fallback path.
        #
        # No fixed sleeps between header / body / polling: we rely on
        # libusb's natural flow control (bulk transfers serialise per
        # endpoint) and on the 1000 ms response timeout below to detect
        # a stuck firmware.  This keeps command latency at the USB
        # round-trip time instead of the ~90 ms that was previously
        # baked in (20 + 20 + 50 ms of sleeps per command).
        #
        # 1. Send header (18 bytes)
        if not self._write(header):
            return 0 if not expect_response else None

        # 2. Send body in chunks (no inter-chunk sleep)
        for off in range(0, len(body), PP_CHUNK_MAX_SIZE):
            chunk = body[off: off + PP_CHUNK_MAX_SIZE]
            if not self._write(chunk):
                return 0 if not expect_response else None

        if not expect_response:
            return 0

        # 3. Build and poll with response request.  The firmware may
        #    silently drop the first request if it is still processing
        #    the command (see ``poll_response_v1_locked`` in the C++
        #    engine). We retry within the 1000 ms total budget.
        req = bytearray(PP_RESPONSE_REQ_SIZE)
        struct.pack_into("<H", req, 0, seq & 0xFFFF)
        req[2] = PP_CMD_READ_VECT_PROBE if vect else PP_CMD_READ
        struct.pack_into("<H", req, 3, PP_CMD_RESPONSE_ID)
        req_crc = _crc32(bytes(req), PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE)
        struct.pack_into("<I", req, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE, req_crc)

        deadline = time.monotonic() + PP_RESPONSE_TIMEOUT_MS / 1000.0
        while time.monotonic() < deadline:
            if not self._write(bytes(req)):
                return None

            for _ in range(20):
                raw = self._read(READ_GRANULARITY, 200)
                if raw is None:
                    break
                if len(raw) == PP_RESPONSE_SIZE:
                    resp_seq = struct.unpack_from("<H", raw, 0)[0]
                    resp_crc = struct.unpack_from("<I", raw, 3)[0]
                    calc_crc = _crc32(raw, PP_RESPONSE_SIZE - PP_CMD_CRC_SIZE)
                    if resp_seq == (seq & 0xFFFF) and resp_crc == calc_crc:
                        return raw[2]  # status byte

            # Brief CPU yield between retries (not a fixed delay for the
            # transfer itself; the 1000 ms deadline above bounds the
            # overall command).
            time.sleep(0.002)

        return None  # timeout

    def supports_data_response(self) -> bool:
        """Whether :meth:`read_data_response` can actually return a payload.

        False on a native fast path (it owns its own response framing and
        exposes no extra-payload read call).  Callers that emit
        a data-response-producing opcode MUST check this first: sending such
        an opcode when the payload cannot be read leaves the firmware's
        queued bytes unread in the IN pipe and desyncs the next command.
        """
        if self._engine is not None and self._engine.is_connected():
            return False
        return self._dev is not None

    def read_data_response(self, size: int, timeout_ms: int = 2000,
                           *, exact: bool = True) -> Optional[bytes]:
        """Read a data-response payload the board sends after a status.

        Some commands (``GetBootCfg``, ``MeasureCycleTime``,
        ``GetDesignInstrumentation``, ...) send a fixed-size data payload
        IN ADDITION to the standard 7-byte status response.  The status is
        returned by :meth:`send_frame`; the payload is read through this
        method as the additional bulk-IN bytes the board queued behind it.

        Call IMMEDIATELY after :meth:`send_frame` returns a successful
        status, and only when ``CTX.usb_transport`` is the lightweight
        ``PapayaUSBTransport``; the transport Papaya Studio supplies does
        its own payload read.

        Returns the raw payload bytes on success or ``None`` on
        timeout / engine-not-available.

        ``exact`` (default True) waits for the full *size*, which is right
        when the payload's length is known from the command's contract.
        Pass False for the commands whose payload is variable-length:
        *size* is then an upper bound and whatever arrived is returned.
        """
        # A native fast path handles its own response framing internally
        # and exposes no "extra payload" read call, so a caller on that
        # path cannot read data responses through this transport.
        # Returning None gives it a clear "not available here" signal
        # rather than blocking on a phantom read.
        if self._engine is not None and self._engine.is_connected():
            return None
        if self._dev is None:
            return None
        if exact:
            return self._read_exact(int(size), int(timeout_ms))
        # Variable-length payload (GetDesignInfo, GetDebugLog): the
        # response carries no length, so *size* is only an upper bound and
        # waiting for exactly that many bytes would always time out.
        #
        # Note this is the OPPOSITE of the C++ host, where a libusb bulk
        # read of more than was sent simply returns early on the short
        # packet. Here the read is assembled in Python, so "ask for more
        # than exists" has to be a deliberate mode rather than a
        # harmless over-request.
        return self._read(int(size), int(timeout_ms))

    # ── recovery helpers ───────────────────────────────────────────────
    def force_to_cfg_mode(self, drain_timeout_ms: int = 300) -> bool:
        """Ensure the board is in config mode and its IN endpoint is drained.

        A board left mid-sampling can be wedged: an auto-push IN transfer
        the host stopped consuming stalls the device-side USB stack so it
        no longer services the OUT endpoint.  A ``PP_CMD_SWITCH_BACK_TO_CFG``
        opcode sent blind would then never be received.

        So the IN endpoint is drained FIRST -- completing the stalled IN
        transfer lets the device resume servicing OUT -- and only then is
        SwitchToCfg sent.  The drain/send is repeated so the opcode lands
        even if a fresh auto-push frame re-armed the IN endpoint in between,
        and a final drain clears the residual auto-push frames produced
        before the firmware stopped sampling.

        Safe to call on a freshly-connected transport regardless of the
        board's prior state.
        """
        if not self._connected:
            return False
        if self._dev is None:
            return True

        import time as _time

        def _drain() -> None:
            deadline = _time.monotonic() + drain_timeout_ms / 1000.0
            empty = 0
            while _time.monotonic() < deadline:
                raw = self._read(4096, 20)
                if not raw:
                    empty += 1
                    if empty >= 2:
                        break
                else:
                    empty = 0

        for _ in range(2):
            _drain()                                       # unblock device USB RX
            self._write(bytes([PP_CMD_SWITCH_BACK_TO_CFG]))
            _time.sleep(0.02)
        _drain()                                           # clear residual auto-push

        # Verify rather than assume.  This used to `return True`
        # unconditionally, so a board that ignored SwitchToCfg reported a
        # successful recovery and the caller moved on believing the link
        # was clean.  Bench-observed: with a sampling design left running,
        # this sequence drains 8 KB, returns True, and the board is still
        # auto-pushing immediately afterwards.
        return not self.is_streaming()

    def is_streaming(self, samples: int = 8, timeout_ms: int = 20) -> bool:
        """True if the board is auto-pushing with no command outstanding.

        A quiet board answers a read with nothing.  A board still running
        a sampling design answers every single read, because it is
        emitting probe batches continuously, which is also what buries
        command responses and makes the link look dead.
        """
        if self._dev is None or not self._connected:
            return False
        hits = 0
        for _ in range(max(1, samples)):
            try:
                if self._read(4096, timeout_ms):
                    hits += 1
            except Exception:
                break
        # Require a clear majority so one late in-flight frame from a
        # just-stopped design isn't read as "still streaming".
        return hits > (max(1, samples) // 2)

    def quiesce(self, attempts: int = 3) -> bool:
        """Best-effort: leave the board not-streaming before we let go.

        Called from :meth:`disconnect`.  Without it, dropping the libusb
        handle while a sampling design is running leaves the board
        auto-pushing into an endpoint nobody drains: from then on every
        command response is buried under the stream, ``GetBoardInfo``
        times out forever, and the link looks dead while the device still
        enumerates fine.  Bench-verified that once a board reaches that
        state **no host-side path recovers it**: SwitchToCfg,
        StopSampling, endpoint drain, ``mcuReset``, ``bus_reset_recover``
        and even a raw ``libusb_reset_device`` with full re-enumeration
        all leave it streaming.  Only a physical power-cycle clears it.

        Prevention is therefore the only cure, and this is where it goes.
        Returns True if the board is quiet when we hand the handle back.
        """
        if not self._connected or self._dev is None:
            return True
        # THE READS CANNOT TELL "IDLE" FROM "WEDGED", SO DO NOT ASK THEM
        # WHEN WE ALREADY KNOW.
        #
        # ``is_streaming`` decides by reading the IN endpoint and seeing
        # whether anything comes back. That distinguishes a quiet board
        # from a healthy streaming one, but NOT from the state this
        # method exists to prevent: once an unconsumed auto-push has
        # stalled the device-side USB stack the reads return nothing, so
        # a board mid-wedge reads as "quiet". The short-circuit then
        # skipped the stop and handed the board back still sampling.
        # Measured: run any example, then any other, and the second dies
        # on its first command with UnknownComError.
        #
        # ``_sampling_started`` is not a guess. It is set only when the
        # board ANSWERED StartSampling with DesignOk, so when it is true
        # the board is sampling whatever the endpoint says, and the stop
        # is sent unconditionally. When it is false nothing on this link
        # ever entered data exchange, the reads are trustworthy, and the
        # cheap path is kept: an idle board still sees no stop traffic.
        if not self._sampling_started:
            try:
                if not self.is_streaming():
                    return True
            except Exception:
                return True
        for _ in range(max(1, attempts)):
            try:
                if self.force_to_cfg_mode():
                    return True
            except Exception:
                break
        print("USB: WARNING. Board is still streaming after quiesce; "
              "a power-cycle will be required before it accepts commands "
              "again.")
        return False

    def bus_reset_recover(self) -> bool:
        """Hard-recover the board with a USB bus reset, then reconnect.

        A SwitchToCfg opcode is not always honoured after a sampling
        design on the V1 PyUSB path -- the board's comm state machine can
        be left in data-exchange mode.  A USB bus reset makes the device
        re-enumerate, and the board treats losing the USB connection as an
        unconditional "stop sampling", resetting its comm state machine
        back to configuration mode.

        Works on both transport paths:

        * **PyUSB path** -- ``self._dev.reset()`` directly fires
          libusb_reset_device(), the device re-enumerates, and we
          re-claim it.

        * **native fast path** -- it owns its own libusb handle and
          exposes no reset call, so the fast path is briefly dropped, a
          temporary PyUSB handle is opened JUST to fire ``dev.reset()``
          (which the board sees as a disconnect, clearing its claimed
          configuration interface, its sequence counter and its comm
          state cleanly), and PyUSB is then closed and the fast path
          reopened. This is the host-side workaround for the wedge that
          a handoff between the two paths can otherwise leave behind.

        The libusb handle is invalidated by the reset, so we re-find
        and re-claim the device afterwards.  Returns True on success.
        """
        import time as _time

        # If the engine is currently the active path, fully tear it
        # down BEFORE the reset.  Empirically, leaving the engine's
        # libusb context alive across libusb_reset_device leaves the
        # Windows WinUSB driver in a state where neither the engine
        # nor a subsequent PyUSB handle can claim the device cleanly.
        # Dropping the engine here (and reconnecting via PyUSB after
        # the reset) is the path that's been bench-verified to give
        # 10/10 DesignOk responses after Arduino's stopSampling.
        if self._engine is not None and self._engine.is_connected():
            try:
                self._engine.disconnect()
            except Exception:
                pass
        self._engine = None       # force PyUSB for the rest of session
        # Whatever the board was doing, it is not doing it after a reset.
        self._sampling_started = False

        # DROP OUR OWN HANDLE FIRST. This used to happen AFTER the reset
        # below, and that ordering is why recovery never worked on
        # Windows: libusb_reset_device refuses while a second handle is
        # open on the same device, so ``tmp.reset()`` returned
        # "[Errno 13] Access denied", the board stayed in data-exchange
        # mode, and the recovery reported that a power-cycle was
        # required. Nothing was wrong with the board -- this end was
        # holding the device open with one hand and asking to reset it
        # with the other. The handle is invalidated by the reset anyway,
        # so there is nothing to keep it open for.
        if self._dev is not None:
            try:
                import usb.util as _util
                _util.dispose_resources(self._dev)
            except Exception:
                pass
        self._dev = None
        self._connected = False

        # WinUSB takes ~1-2 s to release the driver bind after the
        # engine's libusb_close.  Without this wait the PyUSB handle
        # opened below attaches to lingering driver state and bulk
        # transfers post-reset never get acknowledged.
        _time.sleep(2.0)

        # Fire libusb_reset_device via a one-shot PyUSB handle.
        # The board sees the disconnect and unconditionally clears its
        # comm state: the claimed configuration interface, the sequence
        # counter and the data-exchange flag (measured on hardware: a
        # sequence counter of 262145 came back as 0).
        try:
            import usb.core
            import usb.util
            from ._libusb_backend import get_backend
            backend = get_backend()
            tmp = usb.core.find(idVendor=VENDOR_ID,
                                idProduct=PRODUCT_ID, backend=backend)
            if tmp is None:
                print("  [bus_reset_recover] PyUSB find returned None")
            else:
                try:
                    tmp.reset()
                    print("  [bus_reset_recover] dev.reset() fired -- "
                          "the board cleared its comm state")
                except Exception as exc:
                    print(f"  [bus_reset_recover] dev.reset() raised: "
                          f"{type(exc).__name__}: {exc}")
                try:
                    usb.util.dispose_resources(tmp)
                except Exception:
                    pass
        except ImportError:
            print("  [bus_reset_recover] pyusb not available -- skipping "
                  "real USB bus reset")

        # Our handle was already dropped above, before the reset, which
        # is what makes the reset legal in the first place.

        # Generous re-enumeration window.  On Windows the device-side USB stack
        # device may take 2-3 s to fully come back after a bus reset,
        # especially when WinUSB needs to rebind.
        _time.sleep(2.5)

        # Reconnect via PyUSB (self._engine is None, so connect()
        # falls through to the PyUSB path).
        for attempt in range(5):
            if self.connect():
                # Settle window before the caller fires real frames.
                _time.sleep(1.0)
                # Verify the reset actually cleared the board's state.
                # The docstring above asserts that re-enumeration makes
                # the board stop sampling.  Bench
                # testing shows that does NOT hold for a board left
                # running a sampling design: dev.reset() succeeds, the
                # device re-enumerates, and it is still auto-pushing
                # afterwards.  Returning True there sent callers on to a
                # board that could not answer a single command.
                try:
                    if self.is_streaming():
                        print("  [bus_reset_recover] board is STILL streaming "
                              "after re-enumeration: firmware state was not "
                              "cleared; a power-cycle is required.")
                        return False
                except Exception:
                    pass
                return True
            _time.sleep(0.6)
        return False

    # ── live (sampling-mode) data exchange ─────────────────────────────
    def forget_probe_batch_size(self) -> None:
        """Re-learn the batch size, for a design of a different shape."""
        self._probe_batch_bytes = 0
        self._probe_batch_short_run = 0

    def poll_probe_batch(self, n_probes: int, timeout_ms: int = 250,
                         max_samples_per_probe: int = 1024) -> Optional["ProbeBatch"]:
        """Receive one board-initiated auto-push of scalar probes.

        During sampling the board packs ``S`` successive samples of each
        of ``n_probes`` probes into a single bulk packet:

            [opcode (1)] [probe0_s0 ... probe0_s{S-1}  probe1_s0 ... ...]

        This routine reads the full packet, auto-detects ``S`` from the
        length, and returns a :class:`ProbeBatch` carrying both the
        compact "newest sample per probe" buffer and the batch's sequence
        number.

        The sequence number is the only thing on the wire that says
        *when* the batch was produced.  Discarding it, which the previous
        ``poll_probes`` did, makes a stale read indistinguishable from a
        fresh one, so a script looping slower than the batch cadence reads
        progressively older data with nothing to notice it by.  Everything
        the staleness accounting in :mod:`papaya.device` reports is
        derived from this number.

        Returns ``None`` on timeout, wrong opcode, or malformed packet.
        """
        if not self._connected or n_probes <= 0:
            return None

        max_bytes = 1 + n_probes * max_samples_per_probe * 4

        payload: Optional[bytes] = None
        seq: Optional[int] = None
        if self._engine is not None and self._engine.is_connected():
            try:
                result = self._engine.poll_packet(timeout_ms)
            except Exception:
                return None
            if result is None:
                return None
            opcode, pkt_seq, data = result
            if opcode != PP_CMD_READ:
                return None
            payload = bytes(data)
            try:
                seq = int(pkt_seq)
            except (TypeError, ValueError):
                seq = None
        else:
            raw = self._read_stream_frame(max_bytes, timeout_ms)
            if raw is None or len(raw) < 2 or raw[0] != PP_CMD_READ:
                return None
            payload = bytes(raw[1:])

        total = len(payload)
        if total < n_probes * 4:
            return None
        bytes_per_probe = total // n_probes
        if bytes_per_probe < 4 or bytes_per_probe * n_probes != total:
            return None

        # A SHORT READ IS NOT A SMALL BATCH.
        #
        # The geometry above is inferred from the length, and the length is
        # only trustworthy when the whole transfer arrived. It often does not:
        # a batch of nine probes is 4609 bytes on the wire, and a read with a
        # short timeout comes back part way through it. Measured on the bench
        # at a 10 ms timeout, 41 whole frames arrived alongside truncations at
        # 3136, 3264, 3584, 3648, 3776, 3968, 4288, 4480 and 4544 bytes.
        #
        # Most truncations do not divide by n_probes*4 and are already
        # rejected above. The ones that do are worse than a dropped sample:
        # the stride comes out short, so every probe is read from the wrong
        # offset and the caller gets numbers like 3e8 for an angle in degrees,
        # with nothing to say they are wrong. A panel showed exactly that.
        #
        # A truncated frame is never LONGER than a whole one, so the longest
        # payload seen is the batch size, and anything shorter is torn. The
        # latch re-learns after a run of rejections so that changing the batch
        # depth at runtime cannot wedge it shut.
        if total > self._probe_batch_bytes:
            self._probe_batch_bytes = total
            self._probe_batch_short_run = 0
        elif total < self._probe_batch_bytes:
            self._probe_batch_short_run += 1
            if self._probe_batch_short_run < _PROBE_BATCH_RELEARN_AFTER:
                return None
            self._probe_batch_bytes = total
            self._probe_batch_short_run = 0
        else:
            self._probe_batch_short_run = 0

        samples_per_probe = bytes_per_probe // 4

        # Extract the last (= most recent) sample of every probe.
        last_off = (samples_per_probe - 1) * 4
        out = bytearray(n_probes * 4)
        for p in range(n_probes):
            src = p * bytes_per_probe + last_off
            out[p * 4 : p * 4 + 4] = payload[src : src + 4]
        return ProbeBatch(values=bytes(out), seq=seq,
                          samples_per_probe=samples_per_probe)

    def poll_probes(self, n_probes: int, timeout_ms: int = 250,
                    max_samples_per_probe: int = 1024) -> Optional[bytes]:
        """Newest sample per probe from one auto-push packet, or ``None``.

        Thin wrapper over :meth:`poll_probe_batch` kept for callers that
        only want the bytes.  Prefer ``poll_probe_batch`` when the age of
        the data matters.
        """
        batch = self.poll_probe_batch(n_probes, timeout_ms,
                                      max_samples_per_probe)
        return None if batch is None else batch.values

    def poll_probe_batch_latest(
            self, n_probes: int, timeout_ms: int = 250,
            max_samples_per_probe: int = 1024) -> Optional["ProbeBatch"]:
        """Drain the queued auto-push packets and return the newest one.

        The bulk-IN endpoint is a FIFO the board fills at its own cadence.
        A consumer that polls it more slowly than the board fills it reads
        the *oldest* queued batch every time, so its view of the plant
        falls further behind on every iteration while every individual
        read still succeeds.  This drains what has piled up, keeps the
        last batch, and reports how many it had to skip to get there.

        ``skipped`` on the returned batch is therefore a direct measure of
        how far behind the caller was: 0 means the caller is keeping up.

        The drain uses a 1 ms per-packet timeout rather than 0: a zero
        timeout means "block forever" to libusb, which would hang here.

        Caveat worth stating rather than discovering: the drain consumes
        whatever is queued, so on a design that also pushes vector-probe
        data a queued vector batch can be swallowed.  A script that reads
        both should use the non-draining call; one that closes a loop on
        scalars wants the newest scalars more than it wants an old
        spectrum.
        """
        batch = self.poll_probe_batch(n_probes, timeout_ms,
                                      max_samples_per_probe)
        if batch is None:
            return None
        skipped = 0
        while True:
            nxt = self.poll_probe_batch(n_probes, 1, max_samples_per_probe)
            if nxt is None:
                break
            batch = nxt
            skipped += 1
        return batch.with_skipped(skipped)

    def poll_vector_probes(self, expected_bytes: int, timeout_ms: int = 250) -> Optional[bytes]:
        """Receive one board-initiated auto-push of vector-probe bytes.

        Mirrors :meth:`poll_probes` for the vector-probe auto-push packet
        (opcode ``PP_CMD_READ_VECT_PROBE``): ``[opcode (1)] [payload
        bytes]``. ``expected_bytes`` is the total byte count across every
        vector probe currently linked (``VectorProbe.VectorProbeBytes`` on
        the Python side): the caller already knows this because it built
        the design locally before calling ``startSampling()``.

        Returns the raw payload (``expected_bytes`` long) on success, or
        ``None`` on timeout, wrong opcode, or a short packet.
        """
        if not self._connected or expected_bytes <= 0:
            return None

        max_bytes = 1 + expected_bytes

        payload: Optional[bytes] = None
        if self._engine is not None and self._engine.is_connected():
            try:
                result = self._engine.poll_packet(timeout_ms)
            except Exception:
                return None
            if result is None:
                return None
            opcode, _seq, data = result
            if opcode != PP_CMD_READ_VECT_PROBE:
                return None
            payload = bytes(data)
        else:
            raw = self._read_stream_frame(max_bytes, timeout_ms)
            if raw is None or len(raw) < 2 or raw[0] != PP_CMD_READ_VECT_PROBE:
                return None
            payload = bytes(raw[1:])

        if len(payload) < expected_bytes:
            return None
        return payload[:expected_bytes]

    def send_inputs(self, payload: bytes) -> bool:
        """Push a raw remote-input float32 payload to the board.

        Wire format: [PP_CMD_WRITE (0x00)] + payload. Payload must be
        exactly (n_remote_inputs * 4) bytes in registration order.
        """
        if not self._connected:
            return False

        if self._engine is not None and self._engine.is_connected():
            try:
                import numpy as np
                arr = np.frombuffer(bytes(payload), dtype=np.float32)
                return bool(self._engine.send_inputs(arr))
            except Exception:
                return False

        # PyUSB fallback: two writes (opcode, then payload).
        if not self._write(bytes([PP_CMD_WRITE])):
            return False
        if not payload:
            return True
        return self._write(bytes(payload))


# ── The Studio board bridge (wire protocol v1) ─────────────────────────
#
# When PAPAYA Studio launches a papaya-importing program while it is
# itself attached to the board, the program must NOT claim the USB
# device: the Studio already holds it, and a second exclusive libusb
# claim resets the device out from under the first, which can wedge the
# board until a physical replug. The Studio therefore keeps the device
# open, starts a small loopback TCP server
# inside Papaya Studio, and sets two environment
# variables ON THE CHILD PROCESS ONLY, the one mechanism that crosses
# a process boundary by inheritance, the PAPAYA_REFUSE_HARDWARE
# precedent above:
#
#     PAPAYA_HOST_BRIDGE=127.0.0.1:<port>
#     PAPAYA_HOST_BRIDGE_TOKEN=<hex>
#
# The constants below MUST stay in lockstep with the C++ client
# (papaya_lib/ports/pc_usb/include/PapayaStudioBridge.h) and with the
# Studio-side server; all three are checked against each other so they
# cannot drift apart.
#
# Message framing (both directions), ALL integers little-endian:
#
#     u8 op | u8 status | u32 len | payload[len]
#
# Requests set status=0. In a response, status==0 means OK; any
# non-zero status is a hard failure and the payload is a UTF-8 reason
# string. The response's op byte echoes the request's op. A READ that
# times out is NOT an error: the response is status=0, len=0.
BRIDGE_PROTO_VER = 1
BRIDGE_OP_HELLO = 0x01
BRIDGE_OP_WRITE = 0x02
BRIDGE_OP_READ = 0x03
#: Ask for the next auto-push frame from this client's own copy of
#: the board's stream. Distinct from READ because the Studio is
#: reading the same endpoint for its Monitor, and "the next
#: bytes" cannot say whether the caller wants its command's
#: answer or the board's next batch.
BRIDGE_OP_STREAM = 0x06
#: Sent as the probe width in a STREAM request to mean "hand me
#: the frame whole". A program knows how many probes it
#: deployed but not how many samples the board packs into a
#: batch, so it cannot state a width, and a guessed one would
#: cut the tail off every batch.
_STREAM_WHOLE_FRAME = 0xFFFF
BRIDGE_OP_SEQ = 0x04
BRIDGE_OP_BYE = 0x05
BRIDGE_MAX_PAYLOAD = 65536
BRIDGE_MAX_WRITE = 65535

#: A bit in the HELLO reply's flags byte: the board on the other end of
#: this relay is SIMULATED, not hardware. Set by the simulated-board host
#: PAPAYA Studio starts when a run is pointed at this computer instead of
#: the bench. It is the only end that knows, which is why it is on the
#: wire rather than in an environment variable a user could set wrongly.
#: Two things read it: the message this client prints, so a simulated
#: result is never mistaken for a measured one, and the
#: PAPAYA_REFUSE_HARDWARE kill switch, which has nothing to refuse here.
BRIDGE_FLAG_SIMULATED = 0x01

#: Every request runs under a socket deadline of its own timeout budget
#: plus this fixed grace, so a hung Studio can never freeze the program
#: forever. Same value as the C++ client's PAPAYA_BRIDGE_SOCKET_GRACE_MS.
BRIDGE_SOCKET_GRACE_MS = 2000

#: Client-side policy, not a wire rule: the server passes a READ's
#: timeout_ms to the USB layer uncapped, and a huge value would hold the
#: link's RX lock for the whole duration, so no single READ ever asks
#: for more than this, and a longer caller timeout becomes a sequence of
#: short polls against one deadline (PAPAYA_BRIDGE_MAX_POLL_MS).
BRIDGE_MAX_POLL_MS = 1000

#: Client-side policy, not a wire rule: the server relays request_bytes
#: straight into a USB read of exactly that size, and a waiting IN
#: transfer LARGER than the read buffer is an overflow the server can at
#: best report as a hard failure. So reads request in multiples of this,
#: the same 1024-byte wire granularity the C++ transports prove
#: (PAPAYA_BRIDGE_READ_GRANULARITY): no bulk packet can overrun a
#: 1024-multiple buffer at any bus speed. The unread tail is kept in a
#: FIFO and served to later reads first.
BRIDGE_READ_GRANULARITY = 1024

#: ``u8 op | u8 status | u32 len``, all little-endian, both directions.
_BRIDGE_HEADER = struct.Struct("<BBI")


def _bridge_request_from_env() -> Optional[tuple]:
    """The Studio's bridge selector on THIS process, or ``None``.

    Returns ``(endpoint, token)`` when ``PAPAYA_HOST_BRIDGE`` is set.
    The token may come back empty: the transport refuses it loudly
    rather than this helper guessing; the Studio always sets both.
    Absent, nothing changes anywhere: the direct transport claims the
    device itself exactly as it always has.
    """
    endpoint = os.environ.get("PAPAYA_HOST_BRIDGE", "").strip()
    if not endpoint:
        return None
    return endpoint, os.environ.get("PAPAYA_HOST_BRIDGE_TOKEN", "").strip()


def _parse_bridge_endpoint(endpoint: str) -> int:
    """Port from ``127.0.0.1:<port>``, the ONLY accepted form.

    The bridge never connects anywhere else, so nothing is resolved and
    no other address form is accepted (the C++ client applies the same
    rule). Raises ``RuntimeError`` naming the reason.
    """
    text = str(endpoint or "")
    host, sep, port_text = text.rpartition(":")
    if not sep or host != "127.0.0.1":
        raise RuntimeError(
            "PAPAYA studio-bridge transport: bad PAPAYA_HOST_BRIDGE "
            "value: the bridge only ever connects to 127.0.0.1:<port>; "
            f"got \"{text}\".")
    if (not port_text or len(port_text) > 5
            or any(c not in "0123456789" for c in port_text)):
        raise RuntimeError(
            "PAPAYA studio-bridge transport: bad PAPAYA_HOST_BRIDGE "
            f"value: invalid port in \"{text}\".")
    port = int(port_text)
    if not 1 <= port <= 65535:
        raise RuntimeError(
            "PAPAYA studio-bridge transport: bad PAPAYA_HOST_BRIDGE "
            f"value: port out of range in \"{text}\".")
    return port


class _BridgeAttached:
    """Sentinel installed as ``_dev`` while a bridge session is live.

    The parent class treats ``self._dev is None`` as "no device", in
    the ``is_connected`` property and in every guard sitting above the
    raw ``_write``/``_read`` pair (``drain_in``, ``read_data_response``,
    ``force_to_cfg_mode``, ``quiesce``, ...), and those semantics are
    exactly what the bridge transport wants unchanged. This object is
    never a libusb handle and nothing may call into it: every inherited
    method that would touch a real handle (``connect``, ``disconnect``,
    ``_write``, ``_read``, ``bus_reset_recover``) is overridden by
    :class:`PapayaStudioBridgeTransport`.
    """

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return "<papaya Studio-bridge session (no USB handle)>"


_BRIDGE_ATTACHED = _BridgeAttached()


class PapayaStudioBridgeTransport(PapayaUSBTransport):
    """Board transport that talks to PAPAYA Studio over loopback TCP.

    Selected by :func:`connect_usb` when the two ``PAPAYA_HOST_BRIDGE``
    variables are present in the environment. Mirrors the C++ client
    (``PapayaStudioBridge.cpp``) op for op and byte for byte; everything
    ABOVE the raw ``_write``/``_read`` pair (``send_frame``,
    ``read_data_response``, ``drain_in``, the probe polls) is inherited
    unchanged from :class:`PapayaUSBTransport`, so the command layer
    cannot drift between the direct and the bridged path.

    Failure policy, same as the C++ client: a bridge that is requested
    but cannot be reached, or that refuses the HELLO, raises
    ``RuntimeError`` naming the reason; it NEVER falls back to opening
    the USB device. A silent fallback would re-create the exact
    two-claims collision the bridge exists to remove.

    One deliberate divergence from the C++ client, documented at
    :meth:`_bridge_request`: an IN-PROTOCOL failure (a reply carrying a
    non-zero status) maps onto the same per-call surface the direct
    transport has (``_write`` → False, ``_read`` → None, a printed
    reason) instead of ending the session, because the Python command
    layer above is built on per-call failures and retries and must keep
    behaving identically on both paths. Out-of-protocol failures still
    fail the session closed with no auto-reconnect, exactly like C++.
    """

    def __init__(self, endpoint: str, token: str,
                 board_index: int = 0) -> None:
        # Deliberately NOT calling super().__init__(): a bridged process
        # must never hold any USB machinery at all, because the point of
        # the bridge is that PAPAYA Studio owns the device and this
        # process talks to it over loopback TCP. The parent fields the
        # inherited methods read are set here instead.
        self._dev = None            # _BRIDGE_ATTACHED while attached
        self._connected = False
        self._engine = None         # never; see the note above
        self._owns_handle = False   # there is no handle to own
        self._endpoint = str(endpoint or "").strip()
        self._token = str(token or "").strip()
        self._board_index = int(board_index) & 0xFF
        self._sock: Optional[socket.socket] = None
        #: Unread tail of the last IN transfer (a transfer longer than
        #: the caller's request), served FIRST to later reads.
        self._rx_fifo = bytearray()
        #: True only while the HELLO reply is outstanding: a silent
        #: close in that window is the server's reserved signal for a
        #: bad/spent token or a duplicate connection.
        self._handshaking = False

    # ── session lifecycle ──────────────────────────────────────────────
    def connect(self) -> bool:
        # THE KILL SWITCH, AND WHY IT IS ASKED BEFORE THE SOCKET.
        #
        # Bridged bytes normally end at a real board, so the switch
        # refuses here exactly as it does on the direct path. It must
        # refuse BEFORE connecting, not after reading the server's HELLO
        # flag: a real bridge server re-anchors the board's command
        # counter as part of accepting a client, so merely connecting
        # would have touched the hardware the switch exists to protect.
        #
        # The one relay that has no hardware behind it says so on the
        # child's environment, set by the Studio beside the two variables
        # that point here. It is checked again against the server's own
        # HELLO flag below, so a variable set by hand cannot talk this
        # client past a real board.
        claims_simulated = bool(os.environ.get(
            "PAPAYA_HOST_BRIDGE_SIMULATED", "").strip())
        if not claims_simulated and os.environ.get(
                "PAPAYA_REFUSE_HARDWARE", "").strip():
            print("USB: refused. PAPAYA_REFUSE_HARDWARE is set "
                  "(a test run must not open a real board)")
            return False
        if self._connected and self._sock is not None:
            return True

        port = _parse_bridge_endpoint(self._endpoint)
        if not self._token:
            raise RuntimeError(
                "PAPAYA studio-bridge transport: PAPAYA_HOST_BRIDGE is "
                "set but PAPAYA_HOST_BRIDGE_TOKEN is empty: the Studio "
                "always sets both. Refusing to connect without a token.")
        if len(self._token) > 255:
            raise RuntimeError(
                "PAPAYA studio-bridge transport: the bridge token is "
                "longer than 255 bytes, which the HELLO frame cannot "
                "carry.")

        try:
            sock = socket.create_connection(
                ("127.0.0.1", port),
                timeout=BRIDGE_SOCKET_GRACE_MS / 1000.0)
        except OSError as exc:
            raise RuntimeError(
                "PAPAYA studio-bridge transport: could not reach the "
                f"PAPAYA Studio bridge at 127.0.0.1:{port} ({exc}). Is "
                "the Studio still running? This program will not fall "
                "back to claiming the USB device directly: the Studio "
                "holds it.") from exc
        try:
            # Strictly synchronous request -> response with small
            # messages; without this every request sits out Nagle's
            # delay.
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        self._sock = sock
        del self._rx_fifo[:]

        # HELLO: u8 proto_ver | u8 board_index | u8 token_len | token[].
        # The token is sent verbatim (opaque ASCII, not hex-decoded).
        hello = (bytes([BRIDGE_PROTO_VER, self._board_index,
                        len(self._token)])
                 + self._token.encode("ascii"))
        self._handshaking = True
        try:
            status, payload = self._bridge_request(BRIDGE_OP_HELLO,
                                                   hello, 0)
        finally:
            self._handshaking = False
        if status != 0:
            reason = (payload.decode("utf-8", "replace")
                      or "(no reason given)")
            self._fail_closed(
                f"the Studio bridge refused HELLO (status {status}): "
                f"{reason}")
        if len(payload) != 3:
            self._fail_closed(
                f"protocol error: the HELLO reply carried {len(payload)} "
                "payload bytes, expected 3 (u16 link_seq | u8 flags).")
        link_seq, flags = struct.unpack("<HB", payload)
        simulated = bool(flags & BRIDGE_FLAG_SIMULATED)
        if claims_simulated and not simulated:
            # The environment said this relay had no hardware behind it
            # and the server says otherwise. The server is the end that
            # knows, and being wrong in this direction means a run that
            # believes it is on the desk driving the rig.
            self._fail_closed(
                "this program was told it was connecting to a simulated "
                "PAPAYA board, and the link reports a real one. Refusing "
                "to start: unset PAPAYA_HOST_BRIDGE_SIMULATED, or launch "
                "the program from PAPAYA Studio.")

        if link_seq != 0:
            # The v1 sequence rule, same as the C++ client: the Studio
            # re-anchors the board's command counter to ZERO at attach
            # and stays silent while this program runs, and this
            # library's own counter starts at zero: any other answer
            # means every command would come back refused
            # (BadRequest). Refuse loudly now instead of failing
            # confusingly later.
            self._fail_closed(
                "the Studio bridge reports the board's command counter "
                f"at {link_seq}, not 0. The board was not re-anchored "
                "for this run, so every command this program sent would "
                "be refused (BadRequest). Refusing to start: "
                "reconnect the board in PAPAYA Studio and launch again.")

        self._connected = True
        self._dev = _BRIDGE_ATTACHED
        self.is_simulated = simulated
        if simulated:
            # SAY WHICH BOARD THIS IS. A program that prints "connected"
            # and then reports numbers is trusted to be reporting the
            # rig, and a run pointed at the desk that says the same thing
            # is how a simulated result gets written into a lab book.
            print("USB: Connected to a SIMULATED PAPAYA board provided by "
                  f"PAPAYA Studio (127.0.0.1:{port}). No hardware is in "
                  f"this loop.")
        else:
            print("USB: Connected to PAPAYA board through the Studio bridge "
                  f"(127.0.0.1:{port})")
        return True

    def disconnect(self) -> None:
        """Best-effort BYE + socket close, never a USB teardown.

        The parent's disconnect quiesces the board before releasing the
        libusb handle; here the STUDIO owns the handle, and its server
        runs the detach cleanup (re-anchor + quiesce) the moment this
        session ends, so the client's only job is to end it cleanly,
        exactly like the C++ client's ``close()``.
        """
        sock = self._sock
        if sock is not None and self._connected:
            try:
                sock.settimeout(BRIDGE_SOCKET_GRACE_MS / 1000.0)
                sock.sendall(_BRIDGE_HEADER.pack(BRIDGE_OP_BYE, 0, 0))
                header = self._recv_exact(_BRIDGE_HEADER.size)
                if header is not None:
                    _op, _status, length = _BRIDGE_HEADER.unpack(header)
                    if 0 < length <= BRIDGE_MAX_PAYLOAD:
                        self._recv_exact(length)
            except (OSError, RuntimeError):
                pass
        self._sock = None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        self._connected = False
        self._dev = None
        del self._rx_fifo[:]
        print("USB: Disconnected (Studio bridge)")

    def bus_reset_recover(self) -> bool:
        """Refused: a bridged program must never touch the USB bus.

        The direct implementation opens a PyUSB handle just to fire
        ``libusb_reset_device``. From a bridged process, that is exactly
        the second claim this transport exists to prevent, and the reset
        would tear the device out from under the Studio. Callers fall
        through to their ``mcuReset`` path, whose bytes ARE relayed like
        any others.
        """
        print("USB: bus reset refused. This program is attached to the "
              "PAPAYA Studio bridge and must never touch the USB bus; "
              "the Studio owns the device.")
        return False

    #: The way back in is a ONE-SHOT token, and it has been spent. A
    #: disconnect here does not pause the session, it ends it: the next
    #: HELLO is refused with "the access token was wrong or already
    #: spent" and the program dies holding no link at all.
    reopenable_by_this_process: bool = False

    def quiesce(self, attempts: int = 3) -> bool:
        """Refused: the Studio decides when ITS board stops sampling.

        The direct implementation stops a sampling design on the way out,
        because a program that owns the device and simply ends leaves the
        board auto-pushing into an endpoint nobody drains, and the next
        program then finds a board that answers nothing.

        None of that applies here. The Studio holds the device and keeps
        draining it, so this program ending cannot wedge anything, and
        the design is deliberately LEFT sampling: pressing Open Monitor
        after a script attaches to the acquisition the script started,
        which is a documented workflow and the whole point of running the
        program from the editor. Stopping it here would relay SwitchToCfg
        over the bridge and end the Studio's own acquisition.
        """
        return True

    # ── wire plumbing ──────────────────────────────────────────────────
    def _fail_closed(self, reason: str) -> None:
        """End the session on a hard failure and raise, C++-style.

        Close the raw socket (no BYE: the link is broken or out of
        protocol) and stay closed. There is no auto-reconnect: every
        later call lands in the "not connected" error, so a half-dead
        session can never limp along.
        """
        sock, self._sock = self._sock, None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        self._connected = False
        self._dev = None
        del self._rx_fifo[:]
        raise RuntimeError(f"PAPAYA studio-bridge transport: {reason}")

    def _recv_exact(self, n: int) -> Optional[bytes]:
        """Exactly *n* bytes off the socket, or ``None`` on a clean EOF.

        ``socket.timeout`` / ``OSError`` propagate to the caller; only
        an orderly close by the peer is a ``None``.
        """
        buf = bytearray()
        while len(buf) < n:
            chunk = self._sock.recv(n - len(buf))
            if not chunk:
                return None
            buf.extend(chunk)
        return bytes(buf)

    def _bridge_request(self, op: int, payload: bytes,
                        timeout_hint_ms: int) -> tuple:
        """One strictly synchronous request → response exchange.

        Returns ``(status, payload)``. A reply with a non-zero status is
        RETURNED to the caller: the wire is still synchronised (the
        whole reply was consumed), and the caller maps it onto the same
        per-call surface the direct transport has. This is the one
        deliberate divergence from the C++ client (which ends its
        session on any non-zero status); see the class docstring for
        why. Everything that cannot be resynchronised (socket death, a
        silent close, a mismatched reply op, an over-cap length, a
        blown deadline) fails the session closed and raises.
        """
        sock = self._sock
        if sock is None:
            raise RuntimeError(
                "PAPAYA studio-bridge transport: not connected to the "
                "Studio bridge (the connection was never made, or a hard "
                "failure closed it; there is no auto-reconnect).")
        payload = bytes(payload)
        if len(payload) > BRIDGE_MAX_PAYLOAD:
            self._fail_closed(
                f"internal error: a request payload of {len(payload)} "
                f"bytes exceeds the protocol cap of {BRIDGE_MAX_PAYLOAD}.")
        # Per-request socket deadline: the op's own timeout budget plus
        # a fixed grace, so a hung Studio cannot freeze this program
        # forever.
        deadline_ms = max(int(timeout_hint_ms), 0) + BRIDGE_SOCKET_GRACE_MS
        sock.settimeout(deadline_ms / 1000.0)
        try:
            sock.sendall(_BRIDGE_HEADER.pack(op, 0, len(payload))
                         + payload)
            header = self._recv_exact(_BRIDGE_HEADER.size)
            if header is None:
                # A silent close while the HELLO reply is outstanding is
                # the server's reserved signal for exactly two
                # conditions; every other refusal arrives as a status=1
                # reply with a reason.
                if self._handshaking:
                    self._fail_closed(
                        "the Studio bridge closed the connection without "
                        "answering HELLO: the access token was wrong or "
                        "already spent, or another program is already "
                        "attached to the bridge. Relaunch from the "
                        "Studio to get a fresh token.")
                self._fail_closed(
                    "the Studio bridge closed the connection: the "
                    "Studio was closed or its bridge server stopped.")
            reply_op, status, length = _BRIDGE_HEADER.unpack(header)
            if reply_op != op:
                self._fail_closed(
                    f"protocol error: sent op 0x{op:02X} but the reply "
                    f"is for op 0x{reply_op:02X}; the strictly "
                    "synchronous link is out of step.")
            if length > BRIDGE_MAX_PAYLOAD:
                self._fail_closed(
                    f"protocol error: the reply claims a {length}-byte "
                    f"payload, above the {BRIDGE_MAX_PAYLOAD}-byte cap.")
            body = self._recv_exact(length) if length else b""
            if body is None:
                self._fail_closed(
                    "the Studio bridge closed the connection mid-reply.")
        except socket.timeout:
            self._fail_closed(
                "timed out waiting for the Studio bridge to answer "
                "(socket deadline reached); the Studio appears hung.")
        except OSError as exc:
            self._fail_closed(
                f"socket I/O with the Studio bridge failed: {exc}")
        return int(status), bytes(body)

    # ── low-level I/O: the exact surface of the direct transport ─────
    def _write(self, data: bytes, timeout_ms: int = 2000) -> bool:
        data = bytes(data)
        if not data:
            # The frame protocol never legitimately produces an empty
            # write (WRITE carries 1..65535 bytes); the direct path
            # would push a zero-length packet the board ignores.
            return True
        if not self._connected or self._sock is None:
            print("USB write error: the Studio bridge session is closed")
            return False
        if len(data) > BRIDGE_MAX_WRITE:
            print(f"USB write error: a {len(data)}-byte write exceeds "
                  f"the bridge protocol's {BRIDGE_MAX_WRITE}-byte WRITE "
                  "cap")
            return False
        # A transmit starts a new command exchange, so any unread tail
        # of a previous IN transfer belongs to a dead exchange, so discard
        # it. Same rule as the C++ client; bytes still queued on the
        # Studio side are untouched.
        del self._rx_fifo[:]
        try:
            status, payload = self._bridge_request(BRIDGE_OP_WRITE, data,
                                                   int(timeout_ms))
        except RuntimeError as exc:
            print(f"USB write error: {exc}")
            return False
        if status != 0:
            # The server acknowledges a WRITE only once the whole OUT
            # transfer completed, so a non-zero status IS a hard board
            # failure, with the reason attached.
            reason = (payload.decode("utf-8", "replace")
                      or "(no reason given)")
            print(f"USB write error: {reason}")
            return False
        return True

    def _read_stream_frame(self, size: int,
                           timeout_ms: int) -> Optional[bytes]:
        """One auto-push frame, from this client's copy of the stream.

        Never a wire read. The Studio owns the endpoint while a client is
        attached and publishes every frame it takes to all subscribers,
        so asking here costs its Monitor nothing. Before this existed the
        two of them split the stream: measured on the board, the Monitor
        lost 12 per cent of its batches to a script reading the same
        probes.

        A timeout returns None, the same answer a quiet endpoint gives on
        a direct link, so every caller above is unchanged.
        """
        if not self._connected or self._sock is None:
            return None
        try:
            status, payload = self._bridge_request(
                BRIDGE_OP_STREAM,
                struct.pack("<IHH", max(0, int(timeout_ms)),
                            _STREAM_WHOLE_FRAME, _STREAM_WHOLE_FRAME),
                int(timeout_ms) + 2000)
        except (OSError, RuntimeError):
            # A dead session, not a quiet board. Narrow on purpose: a
            # blanket except here swallowed a TypeError from a wrong
            # keyword and turned "the call is misspelt" into "the board
            # is not streaming", which reads on the bench as a hardware
            # fault and cost a bench session to find.
            return None
        if status != 0 or not payload:
            return None
        return bytes(payload)

    def _read(self, size: int, timeout_ms: int) -> Optional[bytes]:
        size = int(size)
        if size <= 0:
            return b""
        # The unread tail of the last IN transfer is served FIRST;
        # otherwise consecutive reads would hand out the byte stream in
        # the wrong order (same FIFO rule as the C++ client).
        if self._rx_fifo:
            take = bytes(self._rx_fifo[:size])
            del self._rx_fifo[:size]
            return take
        if not self._connected or self._sock is None:
            print("USB read error: the Studio bridge session is closed")
            return None
        deadline = time.monotonic() + max(int(timeout_ms), 1) / 1000.0
        while True:
            remaining_ms = int((deadline - time.monotonic()) * 1000.0)
            if remaining_ms < 1:
                return None       # timeout, the direct path's None
            # One READ = exactly one whole IN transfer from the server,
            # and no single READ may hold the server's RX lock for long:
            # a long caller budget becomes several short polls
            # against the one deadline above.
            poll_ms = min(remaining_ms, BRIDGE_MAX_POLL_MS)
            # Round the request up to the wire granularity so the
            # server's USB read buffer can never be smaller than the
            # transfer that answers it (a larger waiting transfer is a
            # server-side overflow). The u16 field caps the request at
            # the top end, exactly like the C++ client.
            granules = (-(-size // BRIDGE_READ_GRANULARITY)
                        * BRIDGE_READ_GRANULARITY)
            request_bytes = min(granules, 65535)
            try:
                status, payload = self._bridge_request(
                    BRIDGE_OP_READ,
                    struct.pack("<HI", request_bytes, poll_ms),
                    poll_ms)
            except RuntimeError as exc:
                print(f"USB read error: {exc}")
                return None
            if status != 0:
                # A named hard failure (libusb OVERFLOW, pipe error,
                # handle gone), the same print-and-None the direct
                # transport produces for a non-timeout USBError.
                reason = (payload.decode("utf-8", "replace")
                          or "(no reason given)")
                print(f"USB read error: {reason}")
                return None
            if not payload:
                continue          # READ timeout is not an error; poll on
            if len(payload) > size:
                # The transfer was longer than the caller asked for:
                # the tail is kept for the next read, preserving the
                # transfer boundary end to end.
                self._rx_fifo.extend(payload[size:])
                return bytes(payload[:size])
            return bytes(payload)


# ── Windows driver auto-fix ────────────────────────────────────────────

def _try_fix_winusb_driver() -> bool:
    """Attempt to remove the cached wrong USB driver so Windows re-reads
    the MS OS 2.0 descriptors on next plug-in and auto-installs WinUSB.

    Returns True if the fix was applied (user must re-plug the board).
    """
    if sys.platform != "win32":
        return False
    try:
        import subprocess
        # Find the device instance ID
        result = subprocess.run(
            ["powershell", "-Command",
             "Get-PnpDevice | Where-Object { $_.InstanceId -like '*VID_270F*PID_15B3*' }"
             " | Select-Object -ExpandProperty InstanceId"],
            capture_output=True, text=True, timeout=10, **no_window())
        instance_id = (result.stdout or "").strip()
        if not instance_id:
            return False

        # Remove the device entry (needs admin, will show UAC prompt)
        subprocess.run(
            ["powershell", "-Command",
             f'Start-Process pnputil -Verb RunAs -Wait '
             f'-ArgumentList "/remove-device", "{instance_id}", "/subtree"'],
            timeout=30, **no_window())
        return True
    except Exception:
        return False


# ── global transport instance ──────────────────────────────────────────
_transport: Optional[PapayaUSBTransport] = None


def _get_status_name(code: int) -> str:
    try:
        return PP_DesignStatus(code).name
    except (ValueError, KeyError):
        return f"Unknown({code})"


def connect_usb() -> bool:
    """Connect to the PAPAYA board and hook USB transport into CTX.

    After calling this, every ``PAPAYA`` library call (``startDesign``,
    block constructors, ``stopDesign``, ``startSampling``, …) will be
    sent to the board over USB.  The response code is printed after
    each command.

    Returns True on success.
    """
    global _transport

    if _transport is not None and _transport.is_connected:
        print("USB: Already connected")
        return True

    # Someone else already hooked a live transport into CTX: honour it and
    # do NOT open a second one.
    #
    # This is what lets PAPAYA Studio debug a generated program in its own
    # process. The Studio holds the board open; the program's first act is
    # this call, and opening a second libusb handle makes the SECOND claim
    # reset the device out from under the first. The observed result is
    # "set_configuration failed: [Errno 13] Access denied", then the
    # Studio's own link dying with "[Errno 32] Pipe error" / "Board not
    # found", and a board that needs replugging.
    #
    # Checked on CTX rather than on ``_transport`` because the Studio
    # installs an adapter over its own arbitrated connection, which this
    # module never created.


    # Someone else already hooked a live transport into CTX: honour it and
    # do NOT open a second one.
    #
    # This is what lets PAPAYA Studio debug a generated program in its own
    # process. The Studio holds the board open; the program's first act is
    # this call, and opening a second libusb handle makes the SECOND claim
    # reset the device out from under the first. The observed result is
    # "set_configuration failed: [Errno 13] Access denied", then the
    # Studio's own link dying with "[Errno 32] Pipe error" / "Board not
    # found", and a board that needs replugging.
    #
    # Checked on CTX rather than on ``_transport`` because the Studio
    # installs an adapter over its own arbitrated connection, which this
    # module never created.
    existing = getattr(CTX, "usb_transport", None)
    if existing is not None and getattr(existing, "is_connected", False):
        print("USB: Using the link this process already has open")
        return True

    # The Studio bridge selector, checked BEFORE any transport is
    # built. When PAPAYA Studio launched this process it KEPT the USB
    # device open and serves this program's board bytes over loopback
    # TCP; claiming libusb here would be the second-claim collision
    # documented above, one process boundary out. The bridge transport
    # NEVER falls back to the device: if the bridge cannot be reached or
    # refuses, its connect() raises with the named reason (the same
    # policy as the C++ client): silently proceeding to the direct
    # claim would re-create the exact wedge the bridge removes.
    bridge = _bridge_request_from_env()
    if bridge is not None:
        transport = PapayaStudioBridgeTransport(bridge[0], bridge[1])
        if not transport.connect():
            # False only for the PAPAYA_REFUSE_HARDWARE kill switch;
            # every bridge failure raises out of connect() instead.
            return False
        _transport = transport
        CTX.usb_transport = _transport
        CTX.current_design_status = PP_DesignStatus.DesignOk
        CTX.current_com_status = PP_ComStatus.ComOk
        return True

    _transport = PapayaUSBTransport()
    if not _transport.connect():
        _transport = None
        return False

    # Hook into CTX so handle_cmd() sends frames over USB
    CTX.usb_transport = _transport
    # Reset error states for a clean session
    CTX.current_design_status = PP_DesignStatus.DesignOk
    CTX.current_com_status = PP_ComStatus.ComOk
    _arm_exit_quiesce()
    return True


#: Set once the interpreter-exit guard below has been registered.
_exit_quiesce_armed = False


def _arm_exit_quiesce() -> None:
    """Guarantee the board is left quiet when this process ends.

    A PROGRAM THAT SIMPLY ENDS MUST NOT WEDGE THE BOARD.
    ``PapayaUSBTransport.quiesce`` already knows how to stop a sampling
    design, and :meth:`PapayaUSBTransport.disconnect` already calls it,
    but a program is under no obligation to disconnect: a design is
    started and left running on purpose so a monitor can watch it, and
    the lifecycle belongs to the caller. That is a reasonable contract
    and it had one hole in it. Dropping the libusb handle at interpreter
    exit while the design is still sampling leaves the board auto-pushing
    into an endpoint nobody drains, and from then on every command
    response is buried under the stream. The next program to run gets a
    board that enumerates perfectly and answers nothing.

    Measured: run any example, then run any other, and the second one
    fails in ``setMonitoringInterface`` with UnknownComError. Every
    host-side recovery is then out of reach, as ``quiesce``'s own notes
    record, so the only fix is not to arrive there.

    This does not take the lifecycle away from the caller. An explicit
    ``disconnect_usb()`` still runs first and this becomes a no-op; it is
    the floor under a program that never gets round to one, including a
    program that dies of an exception. It cannot help a process that is
    killed outright, which is what the hardware reset line is for.
    """
    global _exit_quiesce_armed
    if _exit_quiesce_armed:
        return
    import atexit

    def _on_exit() -> None:
        transport = _transport
        if transport is None:
            return
        try:
            if not transport.is_connected:
                return
        except Exception:
            return
        try:
            transport.quiesce()
        except Exception:
            # Nothing useful to do at interpreter exit, and raising here
            # would replace the program's own exit status with noise.
            pass

    atexit.register(_on_exit)
    _exit_quiesce_armed = True


def board_is_simulated() -> bool:
    """Is the board this program is talking to a simulated one?

    True only while a link is open AND the end that answers it says it
    has no hardware behind it. False when nothing is connected, and
    false for a real board, so a program can print or display the answer
    without first checking whether it is connected.

    It is worth displaying. A window headed the same way for both is how
    a result taken on the desk gets written down as a result taken on
    the bench; :meth:`papaya.panel.Panel.show` puts it in the title bar
    for exactly that reason.
    """
    transport = _transport
    if transport is None or not getattr(transport, "is_connected", False):
        return False
    return bool(getattr(transport, "is_simulated", False))


def disconnect_usb() -> None:
    """Disconnect USB and unhook transport from CTX.

    A transport this module never opened is left alone: the generated
    program calls this on its way out, and when it is running inside PAPAYA
    Studio the link belongs to the Studio. Tearing it down would close the
    board on the application hosting the debug session, the same damage
    the second-claim guard in :func:`connect_usb` exists to prevent, just
    at the other end of the run.
    """
    global _transport
    if _transport is None:
        return
    CTX.usb_transport = None
    _transport.disconnect()
    _transport = None
