"""
In-app update check for Papaya Studio.

Polls a small JSON "release feed" and reports whether a newer build is
available on the user's channel. Pure standard library (``urllib`` +
``json``), no extra dependency. Qt-free apart from an optional lazy
``QSettings`` read of the feed-URL / opt-out override, so it stays
unit-testable headless.

The feed (``latest.json``) is a JSON object keyed by channel::

    {
      "stable": {
        "version":     "1.1.0",
        "url":         "https://.../PapayaStudio-Setup-1.1.0.exe",
        "sha256":      "<hex>",
        "notes_url":   "https://.../changelog",
        "min_version": "1.0.0",
        "downloads": {
          "windows_exe":    {"url": "...", "sha256": "..."},
          "linux_appimage": {"url": "...", "sha256": "..."},
          "linux_deb":      {"url": "...", "sha256": "..."}
        }
      },
      "beta": { ... }
    }

``downloads`` is what makes the feed usable by more than one platform, and
everything about it is designed so that neither half of the change has to
land at the same time as the other:

* An entry with only the flat ``url`` still works. That was the whole feed
  for the first year, it is what any already-installed copy is reading
  right now, and a user does not update their Studio in order to be told
  about updates.
* An entry with ``downloads`` but no matching key for this machine falls
  back to the flat ``url``, then reports nothing rather than offering a
  download that cannot run here. Handing a Linux user a ``.exe`` is worse
  than saying nothing: it looks like the product does not know what it is.

Studio downloads nothing automatically. :func:`check_status` only
*reports*; the user clicks through to the download. Host ``latest.json``
anywhere reachable over HTTPS (your website or a public releases repo);
point Studio at it with the ``PAPAYA_UPDATE_FEED`` env var or the
QSettings key ``updates/feed_url``.
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.request

from . import _feed
from . import _feed_schema
from . import _release_keys

#: Where the two floors are remembered between runs. They only ever rise.
_KEY_FLOOR_SETTING = "updates/min_key_id"
_SERIAL_FLOOR_SETTING = "updates/min_serial"

#: Not a failure. The list verified; it simply has not changed in a long
#: time, which is the one thing the replay floor cannot notice.
_STALE_NOTE = "stale_note"


# The floors themselves live in _feed, because the Package Manager needs
# exactly the same two and a second copy of a rule about when a channel
# locks itself is a second chance for the two to drift apart. Kept under
# these names so every existing caller and test still finds them here.
_stored_floor = _feed.stored_floor
_raise_floor = _feed.raise_floor
from dataclasses import dataclass
from pathlib import Path

# Placeholder feed URL. Replace with the real address, or override per
# machine via the PAPAYA_UPDATE_FEED env var / QSettings updates/feed_url.
DEFAULT_FEED_URL = "https://shanon-technologies.com/papaya-studio/updates/latest.json"

_USER_AGENT = "PapayaStudio-UpdateCheck"

# check_status() outcomes.
STATUS_UPDATE = "update"     # a newer build is available
STATUS_CURRENT = "current"   # already on the latest build
STATUS_ERROR = "error"       # feed unreachable / unparseable


#: Feed keys for the shapes a Papaya Studio install can take. The name
#: identifies the ARTIFACT the user would download, not merely the OS,
#: because on Linux the two formats are replaced in completely different
#: ways and telling somebody to install a .deb when they are running an
#: AppImage is as wrong as offering either to a Windows user.
FLAVOUR_WINDOWS = "windows_exe"
FLAVOUR_APPIMAGE = "linux_appimage"
FLAVOUR_DEB = "linux_deb"
FLAVOUR_UNKNOWN = "unknown"

#: Where a system package installs a self-contained application. Nothing
#: else puts one there, so an application running from below this path came
#: from the package rather than from an archive the user unpacked.
_SYSTEM_INSTALL_PREFIX = "/opt/"


def install_flavour() -> str:
    """How this copy of Studio was installed, as a feed key.

    Detection, in order:

    * ``APPIMAGE`` in the environment is set by the AppImage runtime and
      holds the path of the image itself. Nothing else sets it.
    * An application living under ``/opt`` came from the system package,
      which is the only thing that installs there.
    * Otherwise the platform decides, and a Linux build that is neither of
      the above (a tarball, a development tree) is reported as unknown
      rather than guessed at, because the advice differs per format and a
      wrong guess is worse than none.
    """
    if sys.platform == "win32":
        return FLAVOUR_WINDOWS
    if not sys.platform.startswith("linux"):
        return FLAVOUR_UNKNOWN

    if (os.environ.get("APPIMAGE") or "").strip():
        return FLAVOUR_APPIMAGE
    if not getattr(sys, "frozen", False):
        return FLAVOUR_UNKNOWN

    # Both the literal path and the resolved one. The resolved form follows
    # a symlink into the real install directory, which is what identifies a
    # packaged install when the user launched it through /usr/bin; the
    # literal form is what to trust when resolution rewrites the path,
    # which it does on any host whose idea of an absolute path differs.
    candidates = [str(sys.executable)]
    try:
        candidates.append(str(Path(sys.executable).resolve()))
    except OSError:
        pass
    if any(c.replace("\\", "/").startswith(_SYSTEM_INSTALL_PREFIX)
           for c in candidates):
        return FLAVOUR_DEB
    return FLAVOUR_UNKNOWN


@dataclass(frozen=True)
class UpdateInfo:
    """A newer release advertised by the feed."""
    version: str
    url: str
    channel: str
    sha256: str = ""
    notes_url: str = ""
    #: Which artifact ``url`` points at. Empty when the feed offered only
    #: the flat url and did not say what it was, which is every feed
    #: published before the field existed.
    flavour: str = ""


def _semver_key(v: str) -> tuple:
    """Sortable key for a version string.

    Kept as a name because callers and tests use it. The work is done by
    the shared parser now, which REFUSES what it cannot read instead of
    turning it into zero. Raises ValueError on an unreadable version, so
    that a caller which ignores the possibility fails loudly rather than
    comparing garbage against a real release and calling it older.
    """
    key = _feed.parse_version(v)
    if key is None:
        raise ValueError(f"not a version: {v!r}")
    return key


def is_newer(candidate: str, current: str) -> bool:
    """True if *candidate* is a strictly newer version than *current*.

    False when either side cannot be read. Callers that must tell "older"
    apart from "unreadable" use ``_feed.compare``, which returns None for
    the second case; ``check_status`` below does exactly that, because
    reporting an unreadable version as "you are up to date" was the whole
    defect.
    """
    return _feed.is_newer(candidate, current)


def feed_url() -> str:
    """Resolve the release-feed URL: env -> QSettings -> default."""
    env = (os.environ.get("PAPAYA_UPDATE_FEED") or "").strip()
    if env:
        return env
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        v = QSettings("Shanon Technologies", "Papaya Studio").value(
            "updates/feed_url", "", type=str)
        if v:
            return str(v)
    except Exception:
        pass
    return DEFAULT_FEED_URL


def check_enabled() -> bool:
    """Whether the automatic startup update check is on (default True)."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        return bool(QSettings("Shanon Technologies", "Papaya Studio").value(
            "updates/check_enabled", True, type=bool))
    except Exception:
        return True


def set_check_enabled(enabled: bool) -> None:
    """Persist the startup-update-check opt-in/out."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
        s = QSettings("Shanon Technologies", "Papaya Studio")
        s.setValue("updates/check_enabled", bool(enabled))
        s.sync()
    except Exception:
        pass


#: Why the last check failed, as a reason code from ``_feed``, or "".
#: Module state rather than a return value on purpose: ``check_status``
#: keeps its exact three-value contract, which every existing caller and
#: test depends on, and a dialog that wants to be more specific can ask.
_LAST_PROBLEM: tuple[str, str] = ("", "")


def _remember_problem(reason: str, detail: str) -> None:
    global _LAST_PROBLEM
    _LAST_PROBLEM = (reason, detail)


def last_problem() -> tuple[str, str]:
    """``(reason, detail)`` for the most recent check. Empty if it worked."""
    return _LAST_PROBLEM


def check_status(channel: str, current_version: str, *,
                  timeout: float = 6.0) -> tuple[str, UpdateInfo | None]:
    """Poll the feed. Returns ``(status, info)``:

    * ``(STATUS_UPDATE, UpdateInfo)``: a newer build is available.
    * ``(STATUS_CURRENT, None)``:      already up to date.
    * ``(STATUS_ERROR, None)``:        feed unreachable / unparseable.

    Never raises.
    """
    url = feed_url()
    try:
        raw = _feed.fetch(url, timeout=timeout, user_agent=_USER_AGENT)
        # Signed, and fail-closed. A build with no publishing keys refuses
        # every list rather than reading one it cannot check, which is the
        # correct state for a build that cannot verify anything.
        feed = _feed.open_signed_feed(
            raw, _release_keys.CONTEXT_FEED,
            key_floor=_stored_floor(_KEY_FLOOR_SETTING),
            serial_floor=_stored_floor(_SERIAL_FLOOR_SETTING))
    except _feed.FeedProblem as problem:
        # The reason is kept on the module so the dialog can say something
        # more useful than "check your internet connection" when the real
        # answer is that this machine's clock is wrong. The return shape
        # is unchanged, because every existing caller depends on it.
        _remember_problem(problem.reason, problem.detail)
        return (STATUS_ERROR, None)
    except Exception:
        _remember_problem(_feed.REASON_UNREADABLE, "")
        return (STATUS_ERROR, None)
    _remember_problem("", "")
    # Raised ONLY now, after the list has been fully accepted. A forged
    # list must never be able to plant a high floor and lock the channel.
    _raise_floor(_SERIAL_FLOOR_SETTING, feed.get("__serial__", 0))
    _raise_floor(_KEY_FLOOR_SETTING,
                 feed.get(_feed_schema.FIELD_MIN_KEY_ID, 0))
    if _feed.feed_is_stale(feed):
        _remember_problem(_STALE_NOTE, "")

    # A beta user still wants to hear about stable releases: fall back
    # from the requested channel to "stable".
    entry = feed.get(channel)
    if not isinstance(entry, dict):
        entry = feed.get("stable")
    if not isinstance(entry, dict):
        return (STATUS_ERROR, None)

    version = str(entry.get("version", "")).strip()
    if not version:
        return (STATUS_ERROR, None)

    download, sha, flavour = _pick_download(entry)
    if not download:
        # The feed knows about a release but has nothing this machine can
        # install. Reported as an error rather than as "up to date",
        # because the user is NOT up to date and telling them so would be
        # a lie; the dialog is silent on error, so nothing is claimed.
        return (STATUS_ERROR, None)

    # An unreadable version on either side is an ERROR, never "current".
    # Reporting a version we could not parse as "you are up to date" is
    # the exact defect this module was rewritten to remove: a leading "v"
    # used to zero the major number, so a v-prefixed feed reassured every
    # user on every release.
    order = _feed.compare(version, current_version)
    if order is None:
        _remember_problem(_feed.REASON_UNREADABLE,
                          f"version {version!r}")
        return (STATUS_ERROR, None)
    if order != 1:
        return (STATUS_CURRENT, None)

    # Both addresses are checked here, before either can reach a network
    # call or the desktop's open handler. notes_url in particular is
    # handed straight to the browser by the "What's Changed" button, and
    # on Windows that goes through the shell.
    safe_download = _feed.safe_http_url(download)
    if safe_download is None:
        _remember_problem(_feed.REASON_ADDRESS, "download address")
        return (STATUS_ERROR, None)
    safe_notes = _feed.safe_http_url(entry.get("notes_url", "")) or ""

    return (STATUS_UPDATE, UpdateInfo(
        version=version,
        url=safe_download,
        channel=channel,
        sha256=sha,
        notes_url=safe_notes,
        flavour=flavour,
    ))


def _pick_download(entry: dict) -> tuple[str, str, str]:
    """Choose the artifact for this machine. Returns (url, sha256, flavour).

    An empty url means the feed has nothing installable here, which is a
    real answer and not a failure: it is what a Linux machine gets from a
    feed that only ever knew about the Windows installer.
    """
    downloads = entry.get("downloads")
    flavour = install_flavour()

    if isinstance(downloads, dict):
        item = downloads.get(flavour)
        if isinstance(item, dict):
            url = str(item.get("url", "")).strip()
            if url:
                return (url, str(item.get("sha256", "")).strip(), flavour)
        # A feed that names its platforms but not ours is telling us so.
        # Falling through to the flat url here would hand a Linux user the
        # Windows installer of a feed that clearly knew better.
        if flavour != FLAVOUR_UNKNOWN:
            return ("", "", flavour)

    # No downloads block at all: the original single-artifact schema, and
    # the only thing every already-installed copy understands. Trust it on
    # Windows, where it has always been correct.
    flat = str(entry.get("url", "")).strip()
    if flat and flavour in (FLAVOUR_WINDOWS, FLAVOUR_UNKNOWN):
        return (flat, str(entry.get("sha256", "")).strip(), "")
    return ("", "", flavour)


def check_for_update(channel: str, current_version: str, *,
                      timeout: float = 6.0) -> UpdateInfo | None:
    """Convenience wrapper: the :class:`UpdateInfo` when newer, else None."""
    return check_status(channel, current_version, timeout=timeout)[1]


# ===========================================================================
# What to tell the user
#
# Qt-free and pure, so every outcome can be tested headless. The dialog it
# feeds builds a message box and calls exec(), which is a nested event loop
# the suite's dialog fixture cannot reach, and that is why the whole
# update-available path had no test before this existed.
# ===========================================================================

@dataclass(frozen=True)
class Outcome:
    """One thing to show the user, decided without touching Qt."""
    kind: str            # "update" | "current" | "problem"
    title: str
    text: str
    detail: str = ""
    #: True when the list verified but has not changed in a long time.
    stale_note: bool = False


#: Everything that means "the list did not verify". They deliberately
#: share ONE message. Distinct wording per reason would hand an attacker a
#: user-visible branch to steer by flipping a byte, and none of the
#: differences is something the reader could act on differently.
_VERIFICATION_REASONS = frozenset({
    _feed.REASON_SIG_BAD,
    _feed.REASON_NOT_SIGNED,
    _feed.REASON_KEY_UNKNOWN,
    _feed.REASON_KEY_RETIRED,
    _feed.REASON_NO_KEYS,
    _feed.REASON_STALE,
})

#: Reasons that mean this installation can no longer be updated in place,
#: as opposed to something that might work tomorrow.
_TERMINAL_REASONS = frozenset({
    _feed.REASON_KEY_UNKNOWN,
    _feed.REASON_KEY_RETIRED,
})


def describe(status: str, info=None, current_version: str = "",
             *, problem: tuple[str, str] | None = None,
             seen_before: bool = False) -> Outcome:
    """Turn a check result into the words for it.

    *seen_before* says this same terminal problem already happened in an
    earlier session. Only then is the reinstall remedy offered: telling
    somebody to reinstall the first time a request fails would be wrong
    far more often than right.
    """
    reason, _detail = problem or ("", "")

    if status == STATUS_UPDATE and info is not None:
        return Outcome(
            "update",
            "Update available",
            f"PAPAYA Studio {info.version} is available. "
            f"You are running {current_version}.",
            "Your settings, projects, libraries and examples are kept.")

    if status == STATUS_CURRENT:
        return Outcome(
            "current",
            "No updates",
            f"PAPAYA Studio {current_version} is the latest version.",
            stale_note=(reason == _STALE_NOTE))

    if reason == _feed.REASON_CLOCK:
        # The wrong advice here costs real time. A machine whose clock is
        # far out cannot check any secure address, and being told to check
        # the network sends that person looking in the wrong place.
        return Outcome(
            "problem",
            "Check the date and time",
            "The update list could not be checked because this computer's "
            "date and time look wrong.",
            "Set the clock, then try again. A computer whose clock is far "
            "out cannot make a secure connection to anything.")

    if reason in _VERIFICATION_REASONS:
        text = ("The update list could not be confirmed as genuine, so "
                "nothing was downloaded and nothing was changed.")
        detail = ("This is usually temporary, and normally means the list "
                  "is being updated right now. Try again later.")
        if seen_before and reason in _TERMINAL_REASONS:
            detail = ("This installation can no longer confirm updates. "
                      "Download PAPAYA Studio again from the Shanon "
                      "Technologies website to continue receiving them. "
                      "Your settings, projects, libraries and examples "
                      "are kept.")
        return Outcome("problem", "Update list not confirmed", text, detail)

    if reason == _feed.REASON_ADDRESS:
        return Outcome(
            "problem",
            "Update address refused",
            "The address configured for the update list is not one PAPAYA "
            "Studio will open.",
            "An update list has to be served over a secure connection. "
            "Clear the update address in Preferences to go back to the "
            "standard one.")

    if reason == _feed.REASON_TOO_BIG:
        return Outcome(
            "problem",
            "Update list not confirmed",
            "The update list is far larger than it should be, so it was "
            "not read.",
            "Try again later. If it keeps happening, report it.")

    return Outcome(
        "problem",
        "Could not check for updates",
        "PAPAYA Studio could not reach the update list.",
        "Check your internet connection and try again later. You can turn "
        "the automatic check off in Preferences.")
