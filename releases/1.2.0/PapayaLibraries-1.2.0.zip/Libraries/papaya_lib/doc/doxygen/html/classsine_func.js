var classsine_func =
[
    [ "sineFunc", "classsine_func.html#a30455cce4f8fe291c249a0b56990c8fe", null ]
];