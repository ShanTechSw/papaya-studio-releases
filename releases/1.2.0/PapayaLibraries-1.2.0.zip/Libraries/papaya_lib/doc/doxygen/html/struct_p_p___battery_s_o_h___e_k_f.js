var struct_p_p___battery_s_o_h___e_k_f =
[
    [ "C1", "struct_p_p___battery_s_o_h___e_k_f.html#a71dd3ce004bb10f65dc941343507b39e", null ],
    [ "ocv_coef", "struct_p_p___battery_s_o_h___e_k_f.html#a5fe55edad16fdd7b967141228868179d", null ],
    [ "P_init", "struct_p_p___battery_s_o_h___e_k_f.html#a275bd7d2ebf772388e71be59db744c41", null ],
    [ "Q_data", "struct_p_p___battery_s_o_h___e_k_f.html#a0fb3d8ecab412bf3f0b99e9a09b29e0f", null ],
    [ "R1", "struct_p_p___battery_s_o_h___e_k_f.html#aace4552972dc2b9e12858304e92a2eec", null ],
    [ "R_data", "struct_p_p___battery_s_o_h___e_k_f.html#a95c0eed9e8cd5a6887d2101aa4e54797", null ],
    [ "x_init", "struct_p_p___battery_s_o_h___e_k_f.html#aa0cadbbeb49e394dfa7a755fc23f32a0", null ]
];