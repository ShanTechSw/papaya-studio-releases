var classvariance =
[
    [ "variance", "classvariance.html#abead17d176d2fdb93a328718cb7d9a08", null ]
];