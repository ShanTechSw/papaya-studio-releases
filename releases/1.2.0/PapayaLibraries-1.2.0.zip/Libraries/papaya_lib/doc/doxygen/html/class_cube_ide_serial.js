var class_cube_ide_serial =
[
    [ "begin", "class_cube_ide_serial.html#ac774d64278327450034db2b782ea7d57", null ],
    [ "print", "class_cube_ide_serial.html#a034c2b3d1673a5db578959a1b95bb72a", null ],
    [ "print", "class_cube_ide_serial.html#a17bac2fa0f4a0e710da63340d4f82a22", null ],
    [ "print", "class_cube_ide_serial.html#a5ac44806f6c7d29236ecd9e0585e09d5", null ],
    [ "println", "class_cube_ide_serial.html#acc1adc2258a229402abccbd9cc8c00e3", null ],
    [ "println", "class_cube_ide_serial.html#a9b994a3b7750e03fc36a3e4baaab82bf", null ]
];