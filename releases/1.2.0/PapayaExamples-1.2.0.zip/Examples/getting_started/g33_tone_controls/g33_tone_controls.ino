/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:40:01
 *  Fs (Hz)      : 8000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe low_shelf;
probe high_shelf;
probe band;
probe peak_eq;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(8000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::chirpLinear(20.0f, 3500.0f, 4.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  expander fan_4 = expander(4);
  paramEQLow Low_shelf = paramEQLow(100.0, 2, 6.0);
  ParamEQHigh High_shelf = ParamEQHigh(100.0, 2, 6.0);
  ParamEQBand Band = ParamEQBand(100.0, 200.0, 2, 6.0);
  ParamEQPeak Peak = ParamEQPeak(100.0, 6.0);
  low_shelf = probe("low_shelf");
  high_shelf = probe("high_shelf");
  band = probe("band");
  peak_eq = probe("peak_eq");

  /* Connect Blocks */
  Source > fan_4;
  fan_4.out(0) > Low_shelf;
  fan_4.out(1) > High_shelf;
  fan_4.out(2) > Band;
  fan_4.out(3) > Peak;
  Low_shelf > low_shelf;
  High_shelf > high_shelf;
  Band > band;
  Peak > peak_eq;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    low_shelf.show();
    high_shelf.show();
    band.show();
    peak_eq.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}