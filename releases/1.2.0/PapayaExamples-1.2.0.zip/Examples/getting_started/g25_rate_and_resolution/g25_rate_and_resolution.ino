/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe rate_limited;
probe quantized;

input Slew_p1;
input Slew_p2;
input Steps_p1;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::square(1.0f, 0.0f);
  Slew_p1 = input("Slew_p1", 4.0f);
  Slew_p2 = input("Slew_p2", -4.0f);
  Steps_p1 = input("Steps_p1", 0.25f);
  expander fan_2 = expander(2);
  rateLimiter Slew = rateLimiter();
  quantizer Steps = quantizer();
  rate_limited = probe("rate_limited");
  quantized = probe("quantized");

  /* Connect Blocks */
  Source > fan_2;
  Slew_p1 > Slew.in(1);
  Slew_p2 > Slew.in(2);
  Steps_p1 > Steps.in(1);
  fan_2.out(0) > Slew.in(0);
  fan_2.out(1) > Steps.in(0);
  Slew > rate_limited;
  Steps > quantized;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    rate_limited.show();
    quantized.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}