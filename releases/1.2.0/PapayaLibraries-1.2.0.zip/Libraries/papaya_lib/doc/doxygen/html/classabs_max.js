var classabs_max =
[
    [ "absMax", "classabs_max.html#a8bc96e86469a4a13cce2d7e0549d6d25", null ]
];