/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 500.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe rpy;
probe pitch;
probe yaw;
probe att_err;
probe unused_signals;

input quat_norm_conj;
input roll_sp;
input pitch_sp;
input yaw_sp;
input conj_mode;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(500.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  quat_norm_conj = input("quat_norm_conj", 0.0f);
  roll_sp = input("roll_sp", 0.0f);
  pitch_sp = input("pitch_sp", 0.0f);
  yaw_sp = input("yaw_sp", 0.0f);
  conj_mode = input("conj_mode", 1.0f);
  imu IMU_9_DOF = imu(IMU_ACC, 1.0);
  imu Gyro = imu(IMU_GYR, 0.017453293);
  imu Magnetometer = imu(IMU_MAG, 1.0);
  quatFromEuler Euler_to_Quat = quatFromEuler();
  expander fan_11 = expander(4);
  expander fan_11_2 = expander(4);
  expander fan_11_3 = expander(4);
  expander fan_mag0 = expander(3);
  expander fan_mag1 = expander(3);
  expander fan_mag2 = expander(3);
  imuBiasEst IMU_bias_est = imuBiasEst(64, 0.001, 0.01);
  quatNormConj Conjugate_reference = quatNormConj();
  expander fan_gyro0 = expander(4);
  expander fan_gyro1 = expander(4);
  expander fan_gyro2 = expander(4);
  madgwickAhrs Madgwick = madgwickAhrs(0.1);
  mahonyAhrs Mahony = mahonyAhrs(1.0, 0.1);
  complementaryAhrs Complementary = complementaryAhrs(0.98);
  expander fan_2 = expander(2);
  expander fan_madg0 = expander(3);
  expander fan_madg1 = expander(3);
  expander fan_madg2 = expander(3);
  expander fan_mah0 = expander(2);
  expander fan_mah1 = expander(2);
  expander fan_mah2 = expander(2);
  quatToEuler Quat_to_Euler = quatToEuler();
  quatNormConj Quat_norm_conj = quatNormConj();
  quatMult Quat_multiply = quatMult();
  expander fan_norm0 = expander(2);
  expander fan_norm1 = expander(2);
  expander fan_norm2 = expander(2);
  quatToRotmat Quat_to_Rotmat = quatToRotmat();
  merger unused_bus = merger(42);
  rpy = probe("roll");
  pitch = probe("pitch");
  yaw = probe("yaw");
  att_err = probe("attitude_error");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  quat_norm_conj > Quat_norm_conj.in(4);
  roll_sp > Euler_to_Quat.in(0);
  pitch_sp > Euler_to_Quat.in(1);
  yaw_sp > Euler_to_Quat.in(2);
  conj_mode > Conjugate_reference.in(4);
  IMU_9_DOF.out(0) > fan_11;
  IMU_9_DOF.out(1) > fan_11_2;
  IMU_9_DOF.out(2) > fan_11_3;
  Gyro.out(0) > IMU_bias_est.in(3);
  Gyro.out(1) > IMU_bias_est.in(4);
  Gyro.out(2) > IMU_bias_est.in(5);
  Magnetometer.out(0) > fan_mag0;
  Magnetometer.out(1) > fan_mag1;
  Magnetometer.out(2) > fan_mag2;
  Euler_to_Quat.out(0) > Conjugate_reference.in(0);
  Euler_to_Quat.out(1) > Conjugate_reference.in(1);
  Euler_to_Quat.out(2) > Conjugate_reference.in(2);
  Euler_to_Quat.out(3) > Conjugate_reference.in(3);
  fan_11.out(3) > IMU_bias_est.in(0);
  fan_11.out(0) > Madgwick.in(0);
  fan_11.out(1) > Mahony.in(0);
  fan_11.out(2) > Complementary.in(0);
  fan_11_2.out(3) > IMU_bias_est.in(1);
  fan_11_2.out(0) > Madgwick.in(1);
  fan_11_2.out(1) > Mahony.in(1);
  fan_11_2.out(2) > Complementary.in(1);
  fan_11_3.out(3) > IMU_bias_est.in(2);
  fan_11_3.out(0) > Madgwick.in(2);
  fan_11_3.out(1) > Mahony.in(2);
  fan_11_3.out(2) > Complementary.in(2);
  fan_mag0.out(0) > Madgwick.in(6);
  fan_mag0.out(1) > Mahony.in(6);
  fan_mag0.out(2) > Complementary.in(6);
  fan_mag1.out(0) > Madgwick.in(7);
  fan_mag1.out(1) > Mahony.in(7);
  fan_mag1.out(2) > Complementary.in(7);
  fan_mag2.out(0) > Madgwick.in(8);
  fan_mag2.out(1) > Mahony.in(8);
  fan_mag2.out(2) > Complementary.in(8);
  IMU_bias_est.out(3) > fan_gyro0;
  IMU_bias_est.out(4) > fan_gyro1;
  IMU_bias_est.out(5) > fan_gyro2;
  IMU_bias_est.out(0) > unused_bus.in(0);
  IMU_bias_est.out(1) > unused_bus.in(1);
  IMU_bias_est.out(2) > unused_bus.in(2);
  IMU_bias_est.out(6) > unused_bus.in(6);
  IMU_bias_est.out(7) > unused_bus.in(7);
  IMU_bias_est.out(8) > unused_bus.in(8);
  IMU_bias_est.out(9) > unused_bus.in(9);
  IMU_bias_est.out(10) > unused_bus.in(10);
  IMU_bias_est.out(11) > unused_bus.in(11);
  Conjugate_reference.out(0) > Quat_multiply.in(0);
  Conjugate_reference.out(1) > Quat_multiply.in(1);
  Conjugate_reference.out(2) > Quat_multiply.in(2);
  Conjugate_reference.out(3) > Quat_multiply.in(3);
  fan_gyro0.out(0) > Madgwick.in(3);
  fan_gyro0.out(1) > Mahony.in(3);
  fan_gyro0.out(2) > Complementary.in(3);
  fan_gyro0.out(3) > unused_bus.in(3);
  fan_gyro1.out(0) > Madgwick.in(4);
  fan_gyro1.out(1) > Mahony.in(4);
  fan_gyro1.out(2) > Complementary.in(4);
  fan_gyro1.out(3) > unused_bus.in(4);
  fan_gyro2.out(0) > Madgwick.in(5);
  fan_gyro2.out(1) > Mahony.in(5);
  fan_gyro2.out(2) > Complementary.in(5);
  fan_gyro2.out(3) > unused_bus.in(5);
  Madgwick.out(0) > fan_2;
  Madgwick.out(1) > fan_madg0;
  Madgwick.out(2) > fan_madg1;
  Madgwick.out(3) > fan_madg2;
  Mahony.out(1) > fan_mah0;
  Mahony.out(2) > fan_mah1;
  Mahony.out(3) > fan_mah2;
  Mahony.out(0) > Quat_norm_conj.in(0);
  Mahony.out(4) > unused_bus.in(18);
  Mahony.out(5) > unused_bus.in(19);
  Mahony.out(6) > unused_bus.in(20);
  Complementary.out(0) > unused_bus.in(21);
  Complementary.out(1) > unused_bus.in(22);
  Complementary.out(2) > unused_bus.in(23);
  Complementary.out(3) > unused_bus.in(24);
  fan_2.out(0) > Quat_to_Euler.in(0);
  fan_2.out(1) > Quat_multiply.in(4);
  fan_madg0.out(0) > Quat_to_Euler.in(1);
  fan_madg0.out(1) > Quat_multiply.in(5);
  fan_madg0.out(2) > unused_bus.in(12);
  fan_madg1.out(0) > Quat_to_Euler.in(2);
  fan_madg1.out(1) > Quat_multiply.in(6);
  fan_madg1.out(2) > unused_bus.in(13);
  fan_madg2.out(0) > Quat_to_Euler.in(3);
  fan_madg2.out(1) > Quat_multiply.in(7);
  fan_madg2.out(2) > unused_bus.in(14);
  fan_mah0.out(0) > Quat_norm_conj.in(1);
  fan_mah0.out(1) > unused_bus.in(15);
  fan_mah1.out(0) > Quat_norm_conj.in(2);
  fan_mah1.out(1) > unused_bus.in(16);
  fan_mah2.out(0) > Quat_norm_conj.in(3);
  fan_mah2.out(1) > unused_bus.in(17);
  Quat_to_Euler.out(1) > unused_bus.in(25);
  Quat_to_Euler.out(2) > unused_bus.in(26);
  Quat_to_Euler.out(0) > rpy;
  Quat_to_Euler.out(1) > pitch;
  Quat_to_Euler.out(2) > yaw;
  Quat_norm_conj.out(1) > fan_norm0;
  Quat_norm_conj.out(2) > fan_norm1;
  Quat_norm_conj.out(3) > fan_norm2;
  Quat_norm_conj.out(0) > Quat_to_Rotmat.in(0);
  Quat_multiply.out(1) > unused_bus.in(39);
  Quat_multiply.out(2) > unused_bus.in(40);
  Quat_multiply.out(3) > unused_bus.in(41);
  Quat_multiply.out(0) > att_err;
  fan_norm0.out(0) > Quat_to_Rotmat.in(1);
  fan_norm0.out(1) > unused_bus.in(27);
  fan_norm1.out(0) > Quat_to_Rotmat.in(2);
  fan_norm1.out(1) > unused_bus.in(28);
  fan_norm2.out(0) > Quat_to_Rotmat.in(3);
  fan_norm2.out(1) > unused_bus.in(29);
  Quat_to_Rotmat.out(0) > unused_bus.in(30);
  Quat_to_Rotmat.out(1) > unused_bus.in(31);
  Quat_to_Rotmat.out(2) > unused_bus.in(32);
  Quat_to_Rotmat.out(3) > unused_bus.in(33);
  Quat_to_Rotmat.out(4) > unused_bus.in(34);
  Quat_to_Rotmat.out(5) > unused_bus.in(35);
  Quat_to_Rotmat.out(6) > unused_bus.in(36);
  Quat_to_Rotmat.out(7) > unused_bus.in(37);
  Quat_to_Rotmat.out(8) > unused_bus.in(38);
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  quat_norm_conj.enableRemote();
  roll_sp.enableRemote();
  pitch_sp.enableRemote();
  yaw_sp.enableRemote();
  conj_mode.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    rpy.show();
    pitch.show();
    yaw.show();
    att_err.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}