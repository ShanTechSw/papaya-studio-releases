/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:24:43
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Sensor   a 1 V measurement at 0.4 Hz buried under mains pickup, in volts:
 *               0.5 V of hum at 50.4 Hz, 0.15 V of its second harmonic at 100.8 Hz,
 *               and 0.02 V of broadband noise. The hum sits 0.4 Hz off the fixed
 *               notch's centre, as real mains drift does, so the fixed 50 Hz notch
 *               leaves a visible residual while the adaptive notch pulls
 *               tracked_freq_Hz to 50.4 and all but removes the hum
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe single;
probe comb;
probe psub;
probe clean;
probe trk;

/* Global Struct Declarations */
// Configuration for Adaptive_notch
PP_AdaptiveNotchConfig Adaptive_notch_config = {
  .init_freq = 50.0f,
  .Q_factor = 10.0f,
  .mu = 0.01f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  analogIn Sensor = analogIn(AIN1, 1.0, 0.0);
  expander fan_4 = expander(4);
  notch Notch_50Hz = notch(50.0, 30.0);
  notch Notch_100Hz = notch(100.0, 30.0);
  peak Peak_50Hz = peak(50.0, 30.0);
  adaptiveNotch Adaptive_notch = adaptiveNotch(&Adaptive_notch_config);
  single = probe("single_notch");
  comb = probe("second_harmonic");
  psub = probe("extracted_hum");
  clean = probe("clean");
  trk = probe("tracked_freq_Hz");

  /* Connect Blocks */
  Sensor > fan_4;
  fan_4.out(0) > Notch_50Hz;
  fan_4.out(1) > Notch_100Hz;
  fan_4.out(2) > Peak_50Hz;
  fan_4.out(3) > Adaptive_notch;
  Notch_50Hz > single;
  Notch_100Hz > comb;
  Peak_50Hz > psub;
  Adaptive_notch.out(0) > clean;
  Adaptive_notch.out(1) > trk;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    single.show();
    comb.show();
    psub.show();
    clean.show();
    trk.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}