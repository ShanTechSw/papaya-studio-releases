/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe echo_cancelled;
probe filter_output;
probe double_talk;
probe residual_power_2;

input dtd_rail_hi;
input double_talk_det;

/* Global Struct Declarations */
// Configuration for NLMS_echo_canceller
PP_LMSConfig NLMS_echo_canceller_config = {
  .mu = 0.05f,
  .N = 64,
  .normalize = 1,
  .delta = 0.001f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  dtd_rail_hi = input("rail_hi", 1.0f);
  double_talk_det = input("double_talk_det", 0.0f);
  signalSource SIM__far_end_speech = signalSource::multisine(100.0f, 50.0f, 6, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.8f);
  signalSource SIM__near_end_speech = signalSource::multisine(400.0f, 130.0f, 5, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::RepeatN, /*n_periods=*/ 25, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  expander fan_3 = expander(3);
  fir SIM__echo_path = fir(65, 2000.0, hann, passLow);
  envFollower far_end_envelope = envFollower(0.005, 0.05);
  node microphone_signal = node("[1.0 1.0]", "[1.0]", Sum);
  gain dtd_threshold = gain(1.35);
  expander fan_mic = expander(2);
  lms NLMS_echo_canceller = lms(&NLMS_echo_canceller_config);
  envFollower microphone_envelope = envFollower(0.005, 0.05);
  comp double_talk_detect = comp();
  power residual_power = power(255);
  echo_cancelled = probe("echo_cancelled");
  filter_output = probe("estimated_echo");
  double_talk = probe("double_talk_fla");
  residual_power_2 = probe("residual_power");

  /* Connect Blocks */
  dtd_rail_hi > double_talk_detect.in(0);
  double_talk_det > double_talk_detect.in(1);
  SIM__far_end_speech > fan_3;
  SIM__near_end_speech > microphone_signal.in(1);
  fan_3.out(0) > SIM__echo_path;
  fan_3.out(2) > far_end_envelope;
  fan_3.out(1) > NLMS_echo_canceller.in(1);
  SIM__echo_path > microphone_signal.in(0);
  far_end_envelope > dtd_threshold;
  microphone_signal > fan_mic;
  dtd_threshold > double_talk_detect.in(3);
  fan_mic.out(0) > NLMS_echo_canceller.in(0);
  fan_mic.out(1) > microphone_envelope;
  NLMS_echo_canceller.out(1) > residual_power;
  NLMS_echo_canceller.out(1) > echo_cancelled;
  NLMS_echo_canceller.out(0) > filter_output;
  microphone_envelope > double_talk_detect.in(2);
  double_talk_detect > double_talk;
  residual_power > residual_power_2;

  /* Enable Remote Input Control */
  dtd_rail_hi.enableRemote();
  double_talk_det.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    echo_cancelled.show();
    filter_output.show();
    double_talk.show();
    residual_power_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}