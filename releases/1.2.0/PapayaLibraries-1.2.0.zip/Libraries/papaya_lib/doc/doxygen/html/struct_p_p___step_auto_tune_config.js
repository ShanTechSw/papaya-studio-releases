var struct_p_p___step_auto_tune_config =
[
    [ "id_method", "struct_p_p___step_auto_tune_config.html#a79f31673385c2cc1e3675cec57bc2c64", null ],
    [ "settle_pct", "struct_p_p___step_auto_tune_config.html#ae0ab1ac7695065e22e19574b52b97538", null ],
    [ "step_size", "struct_p_p___step_auto_tune_config.html#a8c03f008dc996256ca41a65cd4aa2347", null ],
    [ "tuning_rule", "struct_p_p___step_auto_tune_config.html#ad6c61647c405726b69d3d490e36db874", null ]
];