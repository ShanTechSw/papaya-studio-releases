"""HMAC-SHA256 challenge-response authentication for PAPAYA boards.

Why this exists
---------------
``GetBoardInfo`` alone is trivially spoofable: any USB device that
enumerates with the PAPAYA VID/PID and answers the opcode with a
recognised part number passes an identity check made on that answer
alone.  Papaya Studio would then treat the device as genuine and open
every board operation to it.

A pre-shared-key HMAC challenge raises the bar: a counterfeit board
would need to obtain the 32-byte secret before it could compute valid
responses.  That's the same bar consumer-grade peripherals use (Apple
MFi, printer cartridges, …).

Protocol
--------
1. Host generates a fresh 32-byte cryptographically-random nonce.
2. Host sends ``PP_SubFuncId.Authenticate`` (0x2022) with the nonce
   as the body's TYPE_Uint8Array param.
3. Firmware receives the nonce, computes::

       expected = HMAC_SHA256(PSK, nonce || mcu_unique_id_96bit)

   and writes the 32-byte HMAC back as the command's response payload.
4. Host reads the 32-byte response, recomputes the HMAC with the
   same PSK and the unique_id it received from GetBoardInfo, and
   compares them in constant time.

The nonce is freshly random per attempt so a captured exchange cannot
be replayed against another board (each board's UID is also unique,
giving per-board response uniqueness even for the same nonce).

Where the key comes from
------------------------
This module contains **no key material**.  The effective key is resolved
at import time, first hit wins:

1. ``PAPAYA_AUTH_PSK_HEX`` in the environment, an explicit override for
   a bench setup or a firmware developer running a custom key.
2. ``PAPAYA_AUTH_PSK_FILE`` in the environment, naming a file that holds
   that same material.  For a key too long to want in a shell history.
3. ``papaya._auth_key``, a generated module written by the release
   build from a secret that lives on the build machine and is never
   committed.  Present in shipped Papaya Studio builds.
4. The per-user key file, :func:`default_secrets_file` -- on Windows
   ``%USERPROFILE%\\.papaya\\secrets\\auth_psk.hex``, elsewhere
   ``~/.config/papaya-studio/secrets/auth_psk.hex``.  This is the file a
   board's firmware is provisioned from, so a checkout that has no
   generated key module still agrees with a board that has been given a
   real one.  Without this step the two sides are provisioned from two
   different places, and a provisioned board fails verification against
   its own machine's source tree with nothing pointing at the key.
5. A **public development key**, published below.  This is the
   zero-configuration path for a freshly cloned tree; it provides no
   protection whatsoever and :data:`PSK_IS_PROVISIONED` is False.  A
   released build never carries this key: the build refuses to produce
   one unless a real key has been provisioned.

Steps 1 and 2 are explicit instructions and beat a generated key module.
Step 4 does not: a copy of the library distributed with the key redacted
stays redacted whatever happens to be lying in the user's home
directory.

Whatever the source, the effective HMAC key is ``SHA-256(material)``.
The board does the same, so the two sides only have to agree on the
material.  :data:`PSK_FINGERPRINT` identifies the key without revealing
it and is safe to print; the key itself must never be logged.

The Python library distributed to users ships with the key **redacted**
(``PSK_HEX = None``, ``PSK_REDACTED = True``): board authentication is
performed by Papaya Studio, so user projects never need the secret.  In
that configuration :func:`expected_hmac` and :func:`verify_response`
raise :class:`AuthKeyUnavailable` rather than returning a wrong answer.

What this does and does not protect against
-------------------------------------------
It stops a device that merely mimics ``GetBoardInfo``.  It does **not**
survive an adversary who reads the key out of a shipped artifact or a
board.  A symmetric secret the host must hold in order to check a
response is, by construction, recoverable from whatever ships to the
host.  Treat it the way MFi and printer-cartridge authentication are
treated: it deters casual cloning and gives a clear signal when a device
is not genuine.  It is not tamper-proof.
"""
from __future__ import annotations

import hmac
import hashlib
import os
import re
import secrets
import sys
import warnings
from pathlib import Path
from typing import Optional


# ──────────────────────────────────────────────────────────────────────
# Public development key
# ──────────────────────────────────────────────────────────────────────
# NOT a secret.  Published deliberately, and mirrored byte-for-byte in
# papaya_lib/papaya_auth_reference.c, so a fresh checkout and a
# development firmware authenticate each other with nothing configured.
# A release build that would ship this key is refused.
#
# It MUST stay byte-identical to the key every board already in the field
# was flashed with.  A previous revision derived this from fresh material
# ("PAPAYA-PUBLIC-DEVELOPMENT-KEY-DO-NOT-SHIP"), on the assumption that the
# firmware would be rebuilt alongside the host, but boards are flashed
# once and keep their key.  Changing it silently broke the handshake for
# every existing board: host and board computed different HMACs, the board
# rejected the response, and the failure surfaced only as "connection
# failed" with nothing pointing at the key.
#
# The security boundary is NOT this constant; it is
# ``assert_auth_psk_not_default``, which refuses to build a release unless
# a real key has been provisioned.  Rotating this value buys nothing and
# strands hardware, so do not change it without a firmware migration plan.
#
# Both sides hash this material through SHA-256 before HMAC use, so the
# effective key is sha256(_DEV_PSK_MATERIAL), matching the original
# implementation exactly.
_DEV_PSK_MATERIAL: bytes = b"Papaya-Version-1.0-SharedSecret!"

# Minimum material length accepted from an override, in bytes.
_MIN_MATERIAL_BYTES = 16


class AuthKeyUnavailable(RuntimeError):
    """Raised when a board response cannot be checked because this copy
    of the library was distributed without the verification key."""


def _material_from_hex(text: str) -> Optional[bytes]:
    try:
        data = bytes.fromhex(text)
    except ValueError:
        return None
    return data if len(data) >= _MIN_MATERIAL_BYTES else None


#: Environment variable naming a file that holds the key material.
_FILE_ENV = "PAPAYA_AUTH_PSK_FILE"


def default_secrets_file() -> Path:
    """The per-user key file, deliberately outside any checkout.

    Windows : ``%USERPROFILE%\\.papaya\\secrets\\auth_psk.hex``
    else    : ``~/.config/papaya-studio/secrets/auth_psk.hex``

    NOT under ``%APPDATA%``: a Store-installed Python redirects that path
    into a package-private cache, so a key written there is invisible to
    every other interpreter on the same machine.  The user profile root
    is not redirected.

    Being outside the checkout is the point, not a detail.  A key sitting
    inside the package directory is a key a generated user project can
    copy out with the rest of the package; one in the home directory
    cannot be picked up that way.
    """
    if sys.platform == "win32":
        base = os.environ.get("USERPROFILE")
        root = Path(base) if base else Path.home()
        return root / ".papaya" / "secrets" / "auth_psk.hex"
    xdg = os.environ.get("XDG_CONFIG_HOME")
    root = Path(xdg) if xdg else (Path.home() / ".config")
    return root / "papaya-studio" / "secrets" / "auth_psk.hex"


def _material_from_file(path: Path) -> Optional[bytes]:
    """Key material held in *path*, or None.

    Tolerates a byte-order mark, ``#`` comment lines, blank lines,
    internal whitespace and an optional ``0x`` prefix, because the file is
    written for a person to read: the shipped one carries a fingerprint
    comment above the key.  Never raises -- an unreadable or malformed
    file means "no key here", and resolution carries on to the next step.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, ValueError, UnicodeDecodeError):
        return None
    for raw in text.lstrip("﻿").splitlines():
        line = re.sub(r"\s+", "", raw.split("#", 1)[0])
        if not line:
            continue
        if line[:2].lower() == "0x":
            line = line[2:]
        return _material_from_hex(line)
    return None


def _resolve_psk() -> tuple[Optional[bytes], str]:
    """Return ``(key_or_None, source)``.

    ``None`` means the key was deliberately withheld from this copy of the
    library, not that resolution failed.
    """
    env = os.environ.get("PAPAYA_AUTH_PSK_HEX", "").strip()
    if env:
        material = _material_from_hex(env)
        if material is not None:
            return hashlib.sha256(material).digest(), "environment"

    named = os.environ.get(_FILE_ENV, "").strip()
    if named:
        material = _material_from_file(Path(named))
        if material is not None:
            return hashlib.sha256(material).digest(), "environment-file"

    try:
        from . import _auth_key as _key_mod  # type: ignore[attr-defined]
    except Exception:
        _key_mod = None  # type: ignore[assignment]

    if _key_mod is not None:
        if getattr(_key_mod, "PSK_REDACTED", False):
            return None, "redacted"
        provisioned = getattr(_key_mod, "PSK_HEX", None)
        if isinstance(provisioned, str) and provisioned:
            material = _material_from_hex(provisioned)
            if material is not None:
                return hashlib.sha256(material).digest(), "provisioned"

    # The file a board's firmware was provisioned from. Reached only when
    # no key module was generated into this copy, i.e. a checkout -- which
    # is exactly the case that used to fall through to the development key
    # and then fail against a board holding a real one.
    material = _material_from_file(default_secrets_file())
    if material is not None:
        return hashlib.sha256(material).digest(), "secrets-file"

    return hashlib.sha256(_DEV_PSK_MATERIAL).digest(), "development"


PSK, PSK_SOURCE = _resolve_psk()

#: True only when a build-provisioned or explicitly overridden key is in
#: use.  False means the public development key is active.
PSK_IS_PROVISIONED: bool = PSK_SOURCE in (
    "environment", "environment-file", "provisioned", "secrets-file")

#: Non-reversible identifier for the active key: safe to print, log and
#: paste into a bug report.  Empty when no key is available.  Two hosts
#: showing the same fingerprint hold the same key.
PSK_FINGERPRINT: str = (
    hashlib.sha256(b"papaya-auth-psk-fingerprint-v1|" + PSK).hexdigest()[:16]
    if PSK is not None else ""
)


class PapayaDevelopmentKeyWarning(UserWarning):
    """Emitted once when the public development key is in use."""


if PSK_SOURCE == "development":
    warnings.warn(
        "Papaya board authentication is using the PUBLIC development key: "
        "board identity checks pass for any device that knows it, and the "
        "anti-clone challenge provides no protection. This is expected in a "
        "development checkout, and a released build never uses this key.",
        PapayaDevelopmentKeyWarning,
        stacklevel=2,
    )


def psk_status() -> dict[str, object]:
    """Machine-readable summary of the active key, with no key material."""
    return {
        "source": PSK_SOURCE,
        "provisioned": PSK_IS_PROVISIONED,
        "available": PSK is not None,
        "fingerprint": PSK_FINGERPRINT,
    }


# ──────────────────────────────────────────────────────────────────────
# Wire constants
# ──────────────────────────────────────────────────────────────────────
NONCE_LEN: int = 32
HMAC_LEN: int = 32
UID_LEN: int = 12   # STM32 96-bit unique device ID, little-endian


def fresh_nonce() -> bytes:
    """Return ``NONCE_LEN`` bytes of cryptographically secure randomness."""
    return secrets.token_bytes(NONCE_LEN)


def expected_hmac(nonce: bytes, unique_id: bytes,
                  psk: Optional[bytes] = None) -> bytes:
    """Compute HMAC-SHA256(PSK, nonce || unique_id).

    Both inputs are passed verbatim; the firmware must concatenate
    them in the same order.  Lengths are validated so a malformed
    GetBoardInfo response (e.g. truncated UID) cannot accidentally
    pass authentication.

    Raises :class:`AuthKeyUnavailable` when no ``psk`` is given and this
    copy of the library was distributed without one.
    """
    if len(nonce) != NONCE_LEN:
        raise ValueError(
            f"nonce must be {NONCE_LEN} bytes (got {len(nonce)})"
        )
    if len(unique_id) != UID_LEN:
        raise ValueError(
            f"unique_id must be {UID_LEN} bytes (got {len(unique_id)})"
        )
    key = psk if psk is not None else PSK
    if key is None:
        raise AuthKeyUnavailable(
            "This copy of the Papaya library was distributed without the "
            "board verification key, so it cannot check a board's response. "
            "PAPAYA Studio performs the check when it connects. To verify "
            "from your own code, supply the key via the psk= argument or "
            "the PAPAYA_AUTH_PSK_HEX environment variable."
        )
    return hmac.new(key, nonce + unique_id, hashlib.sha256).digest()


def verify_response(nonce: bytes, unique_id: bytes, response: bytes,
                    psk: Optional[bytes] = None) -> bool:
    """Constant-time compare ``response`` against the expected HMAC.

    ``hmac.compare_digest`` resists timing side-channels, which matters
    here even though the threat model is mostly about the secret
    rather than the comparison itself, because using ``==`` on bytes
    is a code-smell that future readers might "fix" by switching to
    something that leaks per-byte timing.

    A malformed input is a plain ``False``.  A *missing key* is not: it
    raises :class:`AuthKeyUnavailable`, because silently reporting a
    genuine board as counterfeit is worse than an explicit error.
    """
    if len(response) != HMAC_LEN:
        return False
    try:
        expected = expected_hmac(nonce, unique_id, psk=psk)
    except ValueError:
        return False
    return hmac.compare_digest(expected, response)
