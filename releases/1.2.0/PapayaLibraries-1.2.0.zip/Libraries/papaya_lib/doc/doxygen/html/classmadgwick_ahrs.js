var classmadgwick_ahrs =
[
    [ "madgwickAhrs", "classmadgwick_ahrs.html#aa4757d4124f4c2dc2fb60881f0cfe507", null ]
];