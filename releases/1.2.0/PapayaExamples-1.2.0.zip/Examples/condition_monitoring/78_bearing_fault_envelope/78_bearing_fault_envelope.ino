/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe skew___kurtosis_tap;
probe Hjorth_params_tap;
probe Hjorth_params_tap_2;
probe bearing_health;
probe fault_classifier_tap;
probe fault_envelope;
VectorProbe envelope_spectr;
probe envelope_spectrum_tap;

input const_;

/* Global Array Declarations */
uint16_t fault_classifier_feat_idx[] = {0, 65535, 65535};
float fault_classifier_thresh[] = {0.5f, 0.0f, 0.0f};
uint16_t fault_classifier_left[] = {1, 65535, 65535};
uint16_t fault_classifier_right[] = {2, 65535, 65535};
float fault_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__resonance_carrier = signalSource::sine(5000.0f, 0.0f);
  signalSource SIM__1x_shaft = signalSource::sine(30.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  const_ = input("const", 0.0f);
  signalSource SIM__defect_rate = signalSource::sine(140.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 1.0f);
  node SIM__defect_modulation = node("[1.0 1.0]", "[1.0]", Mul);
  noise SIM__broadband_noise = noise(-0.5, 0.5, uniform);
  node vibration_signal = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  expander fan_5 = expander(5);
  butterBq resonance_band_pass = butterBq(4, 3500.0, 6500.0, passBand);
  rootMeanSquare vibration_RMS = rootMeanSquare(255);
  crestFactor crest_factor = crestFactor(64);
  skewKurt skew___kurtosis = skewKurt(0);
  hjorth Hjorth_params = hjorth(128);
  absVal full_wave_rectify = absVal();
  decisionTree fault_classifier = decisionTree(4, 2, 3, fault_classifier_feat_idx, fault_classifier_thresh, fault_classifier_left, fault_classifier_right, fault_classifier_leaf_val);
  butter envelope_LPF = butter(4, 500.0, passLow);
  fft envelope_FFT = fft(1024);
  fftMagResolver envelope_spectrum = fftMagResolver(envelope_FFT);
  skew___kurtosis_tap = probe("skew / kurtos_1");
  Hjorth_params_tap = probe("Hjorth params_1");
  Hjorth_params_tap_2 = probe("Hjorth params_2");
  bearing_health = probe("bearing_health");
  fault_classifier_tap = probe("fault classif_1");
  fault_envelope = probe("fault_envelope");
  envelope_spectr = VectorProbe("envelope_spectr");
  envelope_spectrum_tap = probe("envelope spec_0");

  /* Connect Blocks */
  SIM__resonance_carrier > SIM__defect_modulation.in(0);
  SIM__1x_shaft > vibration_signal.in(1);
  const_ > SIM__broadband_noise;
  SIM__defect_rate > SIM__defect_modulation.in(1);
  SIM__defect_modulation > vibration_signal.in(0);
  SIM__broadband_noise > vibration_signal.in(2);
  vibration_signal > fan_5;
  fan_5.out(0) > resonance_band_pass;
  fan_5.out(1) > vibration_RMS;
  fan_5.out(2) > crest_factor;
  fan_5.out(3) > skew___kurtosis;
  fan_5.out(4) > Hjorth_params;
  resonance_band_pass > full_wave_rectify;
  vibration_RMS > fault_classifier.in(0);
  crest_factor > fault_classifier.in(1);
  skew___kurtosis.out(0) > fault_classifier.in(2);
  skew___kurtosis.out(1) > skew___kurtosis_tap;
  Hjorth_params.out(0) > fault_classifier.in(3);
  Hjorth_params.out(1) > Hjorth_params_tap;
  Hjorth_params.out(2) > Hjorth_params_tap_2;
  full_wave_rectify > envelope_LPF;
  fault_classifier.out(0) > bearing_health;
  fault_classifier.out(1) > fault_classifier_tap;
  envelope_LPF > envelope_FFT;
  envelope_LPF > fault_envelope;
  envelope_FFT > envelope_spectrum;
  envelope_spectrum >> envelope_spectr;
  envelope_spectrum > envelope_spectrum_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    skew___kurtosis_tap.show();
    Hjorth_params_tap.show();
    Hjorth_params_tap_2.show();
    bearing_health.show();
    fault_classifier_tap.show();
    fault_envelope.show();
    envelope_spectr.show();
    envelope_spectrum_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}