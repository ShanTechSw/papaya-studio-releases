var classtraj_trapezoid =
[
    [ "trajTrapezoid", "classtraj_trapezoid.html#af84712979d3f7ebd6464f24982767b4b", null ]
];