var struct_p_p___gain_schedule_p_i_d_config =
[
    [ "Kd_table", "struct_p_p___gain_schedule_p_i_d_config.html#a36cac7df9183424cdfa561bfd3bec76c", null ],
    [ "Ki_table", "struct_p_p___gain_schedule_p_i_d_config.html#adb5e2c4f6d5afeb59ab9f8cbad5222e7", null ],
    [ "Kp_table", "struct_p_p___gain_schedule_p_i_d_config.html#a7db5b9b7bee98de93dac1c5662a193a1", null ],
    [ "num_points", "struct_p_p___gain_schedule_p_i_d_config.html#a8db5bdb0c00e1b2af4c932bb9d3c7c0d", null ],
    [ "out_max", "struct_p_p___gain_schedule_p_i_d_config.html#a523f57446cfc438b749fdd74932272b9", null ],
    [ "out_min", "struct_p_p___gain_schedule_p_i_d_config.html#a5c99db9d42fcd682fbb7ba0f1b15adfa", null ],
    [ "schedule_points", "struct_p_p___gain_schedule_p_i_d_config.html#a122d621c63382441a06c3c553c902fb9", null ],
    [ "Tau", "struct_p_p___gain_schedule_p_i_d_config.html#a9ae8e91d93bac81d80583e99a83511a2", null ]
];