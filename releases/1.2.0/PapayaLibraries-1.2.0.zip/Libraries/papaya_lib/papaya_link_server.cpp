/**
 * @file    papaya_link_server.cpp
 * @brief   See papaya_link_server.h.
 */
#include "papaya_link_server.h"

#include <string.h>

#if defined(_WIN32)
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
typedef int SocketLength;
#  define PP_CLOSE_SOCKET closesocket
#  define PP_INVALID_SOCKET INVALID_SOCKET
#else
#  include <arpa/inet.h>
#  include <errno.h>
#  include <netinet/in.h>
#  include <netinet/tcp.h>
#  include <sys/socket.h>
#  include <fcntl.h>
#  include <sys/time.h>
#  include <time.h>
#  include <unistd.h>
typedef socklen_t SocketLength;
#  define PP_CLOSE_SOCKET close
#  define PP_INVALID_SOCKET (-1)
#endif

namespace papaya {
namespace link {

namespace {

uint32_t g_rejected = 0u;

/** Floor under the computed read timeout. A poll that is already overdue
 *  would otherwise ask for a zero-timeout read every pass, which is a
 *  busy loop on the socket rather than a fast one. */
const uint32_t kMinTimeoutMs = 1u;

void setReadTimeout(intptr_t handle, uint32_t ms)
{
#if defined(_WIN32)
  DWORD value = (DWORD)ms;
  setsockopt((SOCKET)handle, SOL_SOCKET, SO_RCVTIMEO,
             (const char *)&value, sizeof(value));
#else
  struct timeval tv;
  tv.tv_sec = (time_t)(ms / 1000u);
  tv.tv_usec = (suseconds_t)((ms % 1000u) * 1000u);
  setsockopt((int)handle, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
#endif
}

/**
 * The listening socket is non-blocking, always.
 *
 * A receive timeout does not govern accept() on every platform, and two
 * different things need to accept without blocking: the wait for a first
 * client, which must still notice a stop request; and the check for a
 * SECOND client during a session, which must not stall the first one's
 * sample stream even for a moment.
 */
void setNonBlocking(intptr_t handle)
{
#if defined(_WIN32)
  u_long mode = 1u;
  ioctlsocket((SOCKET)handle, FIONBIO, &mode);
#else
  const int flags = fcntl((int)handle, F_GETFL, 0);
  if (flags >= 0) { fcntl((int)handle, F_SETFL, flags | O_NONBLOCK); }
#endif
}

/**
 * An accepted client socket is put back into blocking mode, explicitly.
 *
 * It does not merely tidy up. On Windows an accepted socket INHERITS the
 * listening socket's blocking mode, and the listener here is
 * non-blocking; on other stacks it does not. Left inherited, every read
 * on the session returns "would block" at once, SO_RCVTIMEO governs
 * nothing, and the serve loop spins at full speed burning a core while
 * appearing to work perfectly -- the stream is fast, the commands are
 * answered, and the only symptom is a gateway that runs hot and flattens
 * a battery.
 *
 * It was found by a mutation that should have slowed the stream down and
 * did not: the spin was hiding it.
 */
void setBlocking(intptr_t handle)
{
#if defined(_WIN32)
  u_long mode = 0u;
  ioctlsocket((SOCKET)handle, FIONBIO, &mode);
#else
  const int flags = fcntl((int)handle, F_GETFL, 0);
  if (flags >= 0) { fcntl((int)handle, F_SETFL, flags & ~O_NONBLOCK); }
#endif
}

/** A short wait between accept attempts on an idle listener, so waiting
 *  for a first client is not a spin. */
void sleepBriefly(void)
{
#if defined(_WIN32)
  Sleep(10);
#else
  struct timespec ts;
  ts.tv_sec = 0;
  ts.tv_nsec = 10L * 1000L * 1000L;
  nanosleep(&ts, 0);
#endif
}

void disableNagle(intptr_t handle)
{
  /* Nagle would hold a small reply waiting for company, which on a
   * request-response link is latency added to every single command. */
  int one = 1;
#if defined(_WIN32)
  setsockopt((SOCKET)handle, IPPROTO_TCP, TCP_NODELAY,
             (const char *)&one, sizeof(one));
#else
  setsockopt((int)handle, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
#endif
}

/** True when a failed read was merely a timeout, which is not an error
 *  and must not end the session: it is how the loop gets a chance to poll
 *  telemetry and to look at its stop flag. */
bool readTimedOut(void)
{
#if defined(_WIN32)
  const int code = WSAGetLastError();
  return (code == WSAETIMEDOUT) || (code == WSAEWOULDBLOCK);
#else
  return (errno == EAGAIN) || (errno == EWOULDBLOCK) || (errno == EINTR);
#endif
}

int receiveSome(intptr_t handle, uint8_t *buffer, uint32_t capacity)
{
#if defined(_WIN32)
  return recv((SOCKET)handle, (char *)buffer, (int)capacity, 0);
#else
  return (int)recv((int)handle, buffer, (size_t)capacity, 0);
#endif
}

int sendSome(intptr_t handle, const uint8_t *data, uint32_t length)
{
#if defined(_WIN32)
  return send((SOCKET)handle, (const char *)data, (int)length, 0);
#else
  return (int)send((int)handle, data, (size_t)length, MSG_NOSIGNAL);
#endif
}

/** The read buffer. One board chunk plus a frame's overhead is the
 *  largest thing a relay is ever sent, so a bigger one would only make
 *  the copy longer. */
const uint32_t kReadChunk = 512u;

/** What a second client is told before its socket closes. */
const char kBusyMessage[] =
    "This gateway is already relaying for another PAPAYA Studio. Only one "
    "at a time can drive a board: two command streams on one sequence "
    "counter is the loss of step the board's own arbitration exists to "
    "prevent. Disconnect the other one, then try again.";

/**
 * Turn away a client that arrived while one was being served.
 *
 * REFUSED WITH A REASON, not queued and not dropped. A client left
 * waiting in a backlog believes it is connecting; a client whose socket
 * simply closes reports a network fault for what is a policy decision.
 * Only a client that is told can say so.
 */
void refuseSecondClient(intptr_t listener)
{
  struct sockaddr_in peer;
  SocketLength peerLength = (SocketLength)sizeof(peer);
#if defined(_WIN32)
  SOCKET extra = accept((SOCKET)listener, (struct sockaddr *)&peer,
                        &peerLength);
#else
  int extra = accept((int)listener, (struct sockaddr *)&peer, &peerLength);
#endif
  if (extra == PP_INVALID_SOCKET) { return; }

  g_rejected++;

  uint8_t frame[kFrameOverhead + sizeof(kBusyMessage)];
  const uint32_t length =
      encodeFrame(frame, sizeof(frame), (uint8_t)kEvent, 0u,
                  (const uint8_t *)kBusyMessage,
                  (uint32_t)(sizeof(kBusyMessage) - 1u));
  if (length > 0u)
  {
    uint32_t sent = 0u;
    while (sent < length)
    {
      const int n = sendSome((intptr_t)extra, &frame[sent], length - sent);
      if (n <= 0) { break; }
      sent += (uint32_t)n;
    }
  }
  PP_CLOSE_SOCKET(extra);
}

}  /* namespace */

uint32_t rejectedConnections(void)
{
  return g_rejected;
}

bool networkStartup(void)
{
#if defined(_WIN32)
  WSADATA data;
  return WSAStartup(MAKEWORD(2, 2), &data) == 0;
#else
  return true;
#endif
}

void networkShutdown(void)
{
#if defined(_WIN32)
  WSACleanup();
#endif
}

/* ==================================================================== */
/* The sink                                                             */
/* ==================================================================== */

bool SocketFrameSink::writeAll(const uint8_t *data, uint32_t length)
{
  uint32_t sent = 0u;
  while (sent < length)
  {
    const int n = sendSome(socket_, &data[sent], length - sent);
    if (n <= 0)
    {
      alive_ = false;
      return false;
    }
    sent += (uint32_t)n;
  }
  return true;
}

bool SocketFrameSink::send(uint8_t type, uint16_t seq,
                           const uint8_t *first, uint32_t firstLength,
                           const uint8_t *second, uint32_t secondLength,
                           const uint8_t *third, uint32_t thirdLength)
{
  if (!alive_) { return false; }

  const uint32_t total = firstLength + secondLength + thirdLength;
  uint8_t head[kHeaderSize];
  if (encodeFrameHeader(head, sizeof(head), type, seq, total) == 0u)
  {
    return false;
  }

  /* The checksum is accumulated across the pieces where they lie. Joining
   * them into one buffer would need a second buffer as large as the
   * largest batch this host carries, on the hosts least able to spare
   * one. */
  uint32_t crc = crc32Update(crc32Begin(), head, kHeaderSize);
  if (!writeAll(head, kHeaderSize)) { return false; }

  const uint8_t *parts[3] = { first, second, third };
  const uint32_t lengths[3] = { firstLength, secondLength, thirdLength };
  for (uint32_t i = 0u; i < 3u; i++)
  {
    if ((parts[i] == 0) || (lengths[i] == 0u)) { continue; }
    crc = crc32Update(crc, parts[i], lengths[i]);
    if (!writeAll(parts[i], lengths[i])) { return false; }
  }

  uint8_t tail[kChecksumSize];
  encodeFrameChecksum(tail, sizeof(tail), crc32Finish(crc));
  return writeAll(tail, kChecksumSize);
}

/* ==================================================================== */
/* One client                                                           */
/* ==================================================================== */

void serveConnection(intptr_t socketHandle, Gateway &gateway,
                     SocketFrameSink &sink, uint8_t *frameBuffer,
                     uint32_t frameBufferSize, MillisFn millis,
                     ShouldStopFn shouldStop, void *stopContext,
                     intptr_t listener)
{
  FrameDecoder decoder(frameBuffer, frameBufferSize);
  uint8_t scratch[kReadChunk];
  bool goodbye = false;

  sink.attach(socketHandle);
  /* Before anything reads: see setBlocking(). An inherited non-blocking
   * flag turns the loop below into a spin that still works. */
  setBlocking(socketHandle);
  disableNagle(socketHandle);

  /* Say what this gateway can carry, before the client asks for
   * anything. The same announcement the microcontroller gateways make,
   * from the same engine, so a host sizes its batches the same way
   * whichever kind of gateway is in front of it. A gateway that stayed
   * silent here would be quietly limited to the conservative default
   * that exists for a radio it does not have. */
  gateway.announce();

  while (!goodbye)
  {
    if ((shouldStop != 0) && shouldStop(stopContext)) { break; }

    /* Wait for whichever comes first, a frame or a batch. */
    const uint32_t now = millis();
    uint32_t due = gateway.telemetryDueIn(now);
    if (due > kIdlePollMs) { due = kIdlePollMs; }
    if (due < kMinTimeoutMs) { due = kMinTimeoutMs; }
    setReadTimeout(socketHandle, due);

    const int got = receiveSome(socketHandle, scratch, sizeof(scratch));
    if (got == 0) { break; }                       /* clean close */
    if (got < 0)
    {
      if (!readTimedOut()) { break; }              /* peer vanished */
      /* Nothing to read is not nothing to do: a batch may be due. */
    }
    else
    {
      uint32_t offset = 0u;
      while (offset < (uint32_t)got)
      {
        uint32_t used = 0u;
        Frame frame;
        if (decoder.consume(&scratch[offset], (uint32_t)got - offset, used,
                            frame))
        {
          gateway.handle(frame);
          if (frame.type == kBye) { goodbye = true; break; }
        }
        if (used == 0u) { break; }                 /* cannot happen; do not spin */
        offset += used;
      }
    }

    /* After the frames, not before: a subscription that arrived in this
     * same read should take effect on this pass rather than waiting a
     * whole timeout for the next one. */
    gateway.pollTelemetry(millis());

    /* And a second Studio, if one turned up, is told why rather than
     * left waiting in a backlog believing it is connecting. */
    if (listener >= 0) { refuseSecondClient(listener); }
  }

  /* The engine cannot see a socket die. Tell it, every time, on every
   * exit from this loop -- a half-sent command that nobody finishes
   * leaves the board's receive state machine waiting forever.
   *
   * Before the detach, deliberately: the flush this provokes may want to
   * say something, and a sink already let go of would swallow it. */
  Frame bye;
  bye.type = (uint8_t)kBye;
  bye.version = kProtocolVersion;
  bye.seq = 0u;
  bye.payload = 0;
  bye.payloadLength = 0u;
  gateway.handle(bye);

  sink.detach();
}

/* ==================================================================== */
/* Many clients, one at a time                                          */
/* ==================================================================== */

bool serveForever(uint16_t port, Gateway &gateway, SocketFrameSink &sink,
                  uint8_t *frameBuffer, uint32_t frameBufferSize,
                  MillisFn millis, ShouldStopFn shouldStop,
                  void *stopContext, BindScope scope)
{
#if defined(_WIN32)
  SOCKET listener = socket(AF_INET, SOCK_STREAM, 0);
#else
  int listener = socket(AF_INET, SOCK_STREAM, 0);
#endif
  if (listener == PP_INVALID_SOCKET) { return false; }

  int one = 1;
#if defined(_WIN32)
  setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, (const char *)&one,
             sizeof(one));
#else
  setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
#endif

  struct sockaddr_in address;
  memset(&address, 0, sizeof(address));
  address.sin_family = AF_INET;
  /* A gateway must be reachable from its network, so every interface is
   * the default. Binding loopback only is for tests and bring-up: a
   * program that offers a board-relay port to the whole network is not
   * something a test run should do to somebody's machine, and on Windows
   * it also raises the firewall's "allow this app" prompt. */
  address.sin_addr.s_addr = htonl((scope == kLoopbackOnly) ? INADDR_LOOPBACK
                                                           : INADDR_ANY);
  address.sin_port = htons(port);

  if (bind(listener, (struct sockaddr *)&address, sizeof(address)) != 0)
  {
    PP_CLOSE_SOCKET(listener);
    return false;
  }
  /* A short backlog, so a second client is picked up and TOLD promptly
   * rather than sitting in a queue believing it is connected. The
   * telling happens inside serveConnection, on the same pass that polls
   * telemetry. */
  if (listen(listener, 2) != 0)
  {
    PP_CLOSE_SOCKET(listener);
    return false;
  }

  setNonBlocking((intptr_t)listener);

  while ((shouldStop == 0) || !shouldStop(stopContext))
  {
    struct sockaddr_in peer;
    SocketLength peerLength = (SocketLength)sizeof(peer);
#if defined(_WIN32)
    SOCKET client = accept(listener, (struct sockaddr *)&peer, &peerLength);
#else
    int client = accept(listener, (struct sockaddr *)&peer, &peerLength);
#endif
    if (client == PP_INVALID_SOCKET)
    {
      sleepBriefly();
      continue;
    }

    /* One at a time, and the one being served holds the loop. A second
     * client arriving meanwhile is TOLD why, from inside that loop; it is
     * never interleaved with this one, because two command streams on one
     * sequence counter is the loss of step the board's own arbitration
     * exists to prevent. */
    serveConnection((intptr_t)client, gateway, sink, frameBuffer,
                    frameBufferSize, millis, shouldStop, stopContext,
                    (intptr_t)listener);
    PP_CLOSE_SOCKET(client);
  }

  PP_CLOSE_SOCKET(listener);
  return true;
}

}  /* namespace link */
}  /* namespace papaya */
