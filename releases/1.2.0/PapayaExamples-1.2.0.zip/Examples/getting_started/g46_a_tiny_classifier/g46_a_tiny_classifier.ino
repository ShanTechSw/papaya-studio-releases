/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe class_0;
probe class_1;
probe component_0;
probe component_1;

input feature_a;
input feature_b;
input pad_2;
input pad_3;

/* Global Array Declarations */
uint16_t Classify_feat_idx[] = {0, 65535, 65535};
float Classify_thresh[] = {0.5f, 0.0f, 0.0f};
uint16_t Classify_left[] = {1, 65535, 65535};
uint16_t Classify_right[] = {2, 65535, 65535};
float Classify_leaf_val[] = {0.0f, 0.0f, 1.0f};
float Project_W[] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f};
float Project_mu[] = {0.0f, 0.0f, 0.0f, 0.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  feature_a = input("feature_a", 0.0f);
  feature_b = input("feature_b", 0.0f);
  pad_2 = input("pad_2", 0.0f);
  pad_3 = input("pad_3", 0.0f);
  expander split_0 = expander(2);
  expander split_1 = expander(2);
  expander split_2 = expander(2);
  expander split_3 = expander(2);
  decisionTree Classify = decisionTree(4, 2, 3, Classify_feat_idx, Classify_thresh, Classify_left, Classify_right, Classify_leaf_val);
  pcaProject Project = pcaProject(4, 2, Project_W, Project_mu);
  class_0 = probe("class_0");
  class_1 = probe("class_1");
  component_0 = probe("component_0");
  component_1 = probe("component_1");

  /* Connect Blocks */
  feature_a > split_0;
  feature_b > split_1;
  pad_2 > split_2;
  pad_3 > split_3;
  split_0.out(0) > Classify.in(0);
  split_0.out(1) > Project.in(0);
  split_1.out(0) > Classify.in(1);
  split_1.out(1) > Project.in(1);
  split_2.out(0) > Classify.in(2);
  split_2.out(1) > Project.in(2);
  split_3.out(0) > Classify.in(3);
  split_3.out(1) > Project.in(3);
  Classify.out(0) > class_0;
  Classify.out(1) > class_1;
  Project.out(0) > component_0;
  Project.out(1) > component_1;

  /* Enable Remote Input Control */
  feature_a.enableRemote();
  feature_b.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    class_0.show();
    class_1.show();
    component_0.show();
    component_1.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}