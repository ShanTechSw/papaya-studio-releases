/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 00:23:27
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe anc_error;

/* Global Struct Declarations */
// Configuration for Adaptive_ANC
PP_LMSConfig Adaptive_ANC_config = {
  .mu = 0.01f,
  .N = 32,
  .normalize = 0,
  .delta = 0.001f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  microphone Feed_fwd_mic = microphone(MIC_L);
  microphone Error_mic = microphone(MIC_R);
  signalSource Program_audio__tone_ = signalSource::sine(440.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  lms Adaptive_ANC = lms(&Adaptive_ANC_config);
  negate Anti_phase = negate();
  node Music___anti_noise = node("[1.0 1.0]", "[1.0]", Sum);
  limiter Limiter = limiter(0.001, 0.1, -1.0);
  speaker Driver = speaker(SPEAKER1);
  anc_error = probe("residual_noise");

  /* Connect Blocks */
  Feed_fwd_mic > Adaptive_ANC.in(1);
  Error_mic > Adaptive_ANC.in(0);
  Program_audio__tone_ > Music___anti_noise.in(1);
  Adaptive_ANC.out(0) > Anti_phase;
  Adaptive_ANC.out(1) > anc_error;
  Anti_phase > Music___anti_noise.in(0);
  Music___anti_noise > Limiter;
  Limiter > Driver;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    anc_error.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}