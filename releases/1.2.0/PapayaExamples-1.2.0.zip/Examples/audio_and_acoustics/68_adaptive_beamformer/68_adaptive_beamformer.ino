/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe beamformed_out;
probe sidelobe_canceller_tap;
probe output_power_2;

/* Global Struct Declarations */
// Configuration for sidelobe_canceller
PP_LMSConfig sidelobe_canceller_config = {
  .mu = 0.01f,
  .N = 32,
  .normalize = 0,
  .delta = 0.001f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__target_wavefront = signalSource::multisine(100.0f, 50.0f, 5, MultisinePhase::Schroeder, 44257);
  signalSource SIM__interferer = signalSource::sine(1200.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.8f);
  expander fan_2 = expander(2);
  expander fan_2_2 = expander(2);
  node mic_1 = node("[1.0 1.0]", "[1.0]", Sum);
  fracDelay mic_2_propagation = fracDelay(7);
  fracDelay interferer_delay = fracDelay(3);
  fracDelay steering_delay = fracDelay(7);
  expander fan_2_3 = expander(2);
  node mic_2 = node("[1.0 1.0]", "[1.0]", Sum);
  node delay_and_sum = node("[0.5 0.5]", "[1.0]", Sum);
  lms sidelobe_canceller = lms(&sidelobe_canceller_config);
  power output_power = power(255);
  beamformed_out = probe("beamformed_outp");
  sidelobe_canceller_tap = probe("sidelobe canc_0");
  output_power_2 = probe("output_power");

  /* Connect Blocks */
  SIM__target_wavefront > fan_2;
  SIM__interferer > fan_2_2;
  fan_2.out(0) > mic_1.in(0);
  fan_2.out(1) > mic_2_propagation;
  fan_2_2.out(0) > mic_1.in(1);
  fan_2_2.out(1) > interferer_delay;
  mic_1 > steering_delay;
  mic_2_propagation > mic_2.in(0);
  interferer_delay > fan_2_3;
  steering_delay > delay_and_sum.in(0);
  fan_2_3.out(0) > mic_2.in(1);
  fan_2_3.out(1) > sidelobe_canceller.in(1);
  mic_2 > delay_and_sum.in(1);
  delay_and_sum > sidelobe_canceller.in(0);
  sidelobe_canceller.out(1) > output_power;
  sidelobe_canceller.out(1) > beamformed_out;
  sidelobe_canceller.out(0) > sidelobe_canceller_tap;
  output_power > output_power_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    beamformed_out.show();
    sidelobe_canceller_tap.show();
    output_power_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}