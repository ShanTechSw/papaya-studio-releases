/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe str_pid_kp;
probe str_pid_ki;
probe str_pid_kd;
probe str_pid_measure;
probe gs_kp;
probe gs_ki;
probe gs_kd;
probe gs_measured;
probe mrac_pid_kp;
probe mrac_pid_ki;
probe mrac_pid_kd;
probe mrac_pid_measur;

input schedule_variable;

/* Global Struct Declarations */
// Configuration for Str_Pid
PP_STR_PID_Config Str_Pid_config = {
  .lambda = 0.98f,
  .P_init = 100.0f,
  .Tau = 0.01f,
  .desired_cl_bw = 10.0f
};

// Configuration for Gain_Schedule_Pid
static float Gain_Schedule_Pid_schedule_points[3] = {0.0f, 50.0f, 100.0f};
static float Gain_Schedule_Pid_Kp_table[3] = {1.0f, 2.0f, 3.0f};
static float Gain_Schedule_Pid_Ki_table[3] = {0.1f, 0.2f, 0.3f};
static float Gain_Schedule_Pid_Kd_table[3] = {0.01f, 0.02f, 0.03f};
PP_GainSchedulePIDConfig Gain_Schedule_Pid_config = {
  .schedule_points = Gain_Schedule_Pid_schedule_points,
  .Kp_table = Gain_Schedule_Pid_Kp_table,
  .Ki_table = Gain_Schedule_Pid_Ki_table,
  .Kd_table = Gain_Schedule_Pid_Kd_table,
  .Tau = 0.01f,
  .out_min = -100.0f,
  .out_max = 100.0f,
  .num_points = 3
};

// Configuration for Mrac_Pid
PP_MRAC_PID_Config Mrac_Pid_config = {
  .Am = 0.99f,
  .Bm = 0.01f,
  .gamma_p = 1.0f,
  .gamma_i = 0.5f,
  .gamma_d = 0.1f,
  .Tau = 0.01f
};


/* Global Array Declarations */
float STR_PID_plant_numerator[] = {1.0f};
float STR_PID_plant_denominator[] = {0.2f, 1.0f};
float gs_plant_numerator[] = {1.0f};
float gs_plant_denominator[] = {0.2f, 1.0f};
float MRAC_PID_plant_numerator[] = {1.0f};
float MRAC_PID_plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::square(0.3f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  schedule_variable = input("schedule_variable", 0.5f);
  expander fan_3 = expander(3);
  strPID Str_Pid = strPID(&Str_Pid_config);
  tf STR_PID_plant = tf(STR_PID_plant_numerator, 1, STR_PID_plant_denominator, 2);
  expander STR_PID_fb = expander(2);
  expander MRAC_PID_ref = expander(1);
  gainSchedulePID Gain_Schedule_Pid = gainSchedulePID(&Gain_Schedule_Pid_config);
  tf gs_plant = tf(gs_plant_numerator, 1, gs_plant_denominator, 2);
  expander gs_fb = expander(2);
  node gs_error = node("[1.0 -1.0]", "[1.0]", Sum);
  mracPID Mrac_Pid = mracPID(&Mrac_Pid_config);
  tf MRAC_PID_plant = tf(MRAC_PID_plant_numerator, 1, MRAC_PID_plant_denominator, 2);
  expander MRAC_PID_fb = expander(2);
  str_pid_kp = probe("str_pid_kp");
  str_pid_ki = probe("str_pid_ki");
  str_pid_kd = probe("str_pid_kd");
  str_pid_measure = probe("str_pid_measure");
  gs_kp = probe("gs_kp");
  gs_ki = probe("gs_ki");
  gs_kd = probe("gs_kd");
  gs_measured = probe("gs_measured");
  mrac_pid_kp = probe("mrac_pid_kp");
  mrac_pid_ki = probe("mrac_pid_ki");
  mrac_pid_kd = probe("mrac_pid_kd");
  mrac_pid_measur = probe("mrac_pid_measur");

  /* Connect Blocks */
  Source > fan_3;
  schedule_variable > Gain_Schedule_Pid.in(1);
  fan_3.out(0) > Str_Pid.in(0);
  fan_3.out(1) > MRAC_PID_ref;
  fan_3.out(2) > gs_error.in(0);
  Str_Pid.out(0) > STR_PID_plant;
  Str_Pid.out(1) > str_pid_kp;
  Str_Pid.out(2) > str_pid_ki;
  Str_Pid.out(3) > str_pid_kd;
  STR_PID_plant > STR_PID_fb;
  STR_PID_fb.out(0) > Str_Pid.in(1);
  STR_PID_fb.out(1) > str_pid_measure;
  MRAC_PID_ref > Mrac_Pid.in(0);
  Gain_Schedule_Pid.out(0) > gs_plant;
  Gain_Schedule_Pid.out(1) > gs_kp;
  Gain_Schedule_Pid.out(2) > gs_ki;
  Gain_Schedule_Pid.out(3) > gs_kd;
  gs_plant > gs_fb;
  gs_fb.out(0) > gs_error.in(1);
  gs_fb.out(1) > gs_measured;
  gs_error > Gain_Schedule_Pid.in(0);
  Mrac_Pid.out(0) > MRAC_PID_plant;
  Mrac_Pid.out(1) > mrac_pid_kp;
  Mrac_Pid.out(2) > mrac_pid_ki;
  Mrac_Pid.out(3) > mrac_pid_kd;
  MRAC_PID_plant > MRAC_PID_fb;
  MRAC_PID_fb.out(0) > Mrac_Pid.in(1);
  MRAC_PID_fb.out(1) > mrac_pid_measur;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    str_pid_kp.show();
    str_pid_ki.show();
    str_pid_kd.show();
    str_pid_measure.show();
    gs_kp.show();
    gs_ki.show();
    gs_kd.show();
    gs_measured.show();
    mrac_pid_kp.show();
    mrac_pid_ki.show();
    mrac_pid_kd.show();
    mrac_pid_measur.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}