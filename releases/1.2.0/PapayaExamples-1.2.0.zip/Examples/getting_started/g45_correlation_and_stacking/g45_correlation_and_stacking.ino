/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe normalised;
VectorProbe autocorrelation;
VectorProbe feature_vector;
probe stack_updated;

input Normalise_p1;
input feature_0;
input feature_1;
input feature_2;
input feature_3;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(20.0f, 0.0f);
  Normalise_p1 = input("Normalise_p1", 0.0f);
  feature_0 = input("feature_0", 0.1f);
  feature_1 = input("feature_1", 0.2f);
  feature_2 = input("feature_2", 0.30000000000000004f);
  feature_3 = input("feature_3", 0.4f);
  expander fan_2 = expander(2);
  zScoreNorm Normalise = zScoreNorm(256, 1e-09);
  autocorrLags Autocorrelation = autocorrLags(256, 64, 32);
  featureStack Feature_vector = featureStack(4);
  normalised = probe("normalised");
  autocorrelation = VectorProbe("autocorrelation");
  feature_vector = VectorProbe("feature_vector");
  stack_updated = probe("stack_updated");

  /* Connect Blocks */
  Source > fan_2;
  Normalise_p1 > Normalise.in(1);
  feature_0 > Feature_vector.in(0);
  feature_1 > Feature_vector.in(1);
  feature_2 > Feature_vector.in(2);
  feature_3 > Feature_vector.in(3);
  fan_2.out(0) > Normalise.in(0);
  fan_2.out(1) > Autocorrelation;
  Normalise > normalised;
  Autocorrelation >> autocorrelation;
  Feature_vector >> feature_vector;
  Feature_vector > stack_updated;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    normalised.show();
    autocorrelation.show();
    feature_vector.show();
    stack_updated.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}