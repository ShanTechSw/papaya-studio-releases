var _papaya_stm32_cube_ide_config_8h =
[
    [ "papayaStm32BindLogicalPin", "_papaya_stm32_cube_ide_config_8h.html#a57576fcc27f90e0d93b2490570d36f82", null ],
    [ "papayaStm32BindSpiHandle", "_papaya_stm32_cube_ide_config_8h.html#a8ae62b09b8d28bd193d4c608bd1be396", null ],
    [ "papayaStm32GetSpiHandle", "_papaya_stm32_cube_ide_config_8h.html#a36918cb162b9df4b9c62a8d8a5f8d5a9", null ],
    [ "papayaStm32TryGetLogicalPin", "_papaya_stm32_cube_ide_config_8h.html#acef0df75e71d7ac13d83d06fc4370aa2", null ]
];