/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:24:40
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Voltage                    a 0.5 Hz triangle between -9 V and +9 V, most of
 *                                 the input's -10 V to +10 V span, so the voltage
 *                                 readout sweeps slowly through both signs
 *      Temp sensor (10 mV/degC)   a room temperature in degrees Celsius: 25 degC
 *                                 with a slow 1.5 degC drift and 0.3 degC of sensor
 *                                 noise. The block's out_scale of 100 already turns
 *                                 this sensor's 10 mV/degC into degrees, so the
 *                                 model plays degrees directly and temp_C settles
 *                                 near 25
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe voltage_V;
probe temp_C;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  analogIn Voltage = analogIn(AIN1, 1.0, 0.0);
  analogIn Temp_sensor__10_mV_degC_ = analogIn(AIN2, 100.0, 0.0);
  movingAverage Smooth = movingAverage(64);
  mean Display_avg = mean(200);
  voltage_V = probe("voltage_V");
  temp_C = probe("temp_C");

  /* Connect Blocks */
  Voltage > voltage_V;
  Temp_sensor__10_mV_degC_ > Smooth;
  Smooth > Display_avg;
  Display_avg > temp_C;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    voltage_V.show();
    temp_C.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}