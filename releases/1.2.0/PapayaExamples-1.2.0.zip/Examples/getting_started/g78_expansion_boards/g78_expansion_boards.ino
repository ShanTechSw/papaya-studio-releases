/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 00:55:26
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe external_x;
probe external_y;
probe external_z;
probe module_0;
probe module_1;
probe module_2;
probe module_3;
probe module_4;
probe module_5;
probe module_6;
probe module_7;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  extSensor External_Sensor = extSensor(I2C1, LIS3DH, 1.0);
  extSensor Io_Module = extSensor(SPI2, MCP3008, 1.0);
  external_x = probe("external_x");
  external_y = probe("external_y");
  external_z = probe("external_z");
  module_0 = probe("module_0");
  module_1 = probe("module_1");
  module_2 = probe("module_2");
  module_3 = probe("module_3");
  module_4 = probe("module_4");
  module_5 = probe("module_5");
  module_6 = probe("module_6");
  module_7 = probe("module_7");

  /* Connect Blocks */
  External_Sensor.out(0) > external_x;
  External_Sensor.out(1) > external_y;
  External_Sensor.out(2) > external_z;
  Io_Module.out(0) > module_0;
  Io_Module.out(1) > module_1;
  Io_Module.out(2) > module_2;
  Io_Module.out(3) > module_3;
  Io_Module.out(4) > module_4;
  Io_Module.out(5) > module_5;
  Io_Module.out(6) > module_6;
  Io_Module.out(7) > module_7;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    external_x.show();
    external_y.show();
    external_z.show();
    module_0.show();
    module_1.show();
    module_2.show();
    module_3.show();
    module_4.show();
    module_5.show();
    module_6.show();
    module_7.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}