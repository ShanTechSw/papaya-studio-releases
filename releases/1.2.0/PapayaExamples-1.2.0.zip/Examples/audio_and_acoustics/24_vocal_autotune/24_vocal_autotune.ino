/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe Envelope_tap;

input semitone_step;
input pitch_hi;
input pitch_lo;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  semitone_step = input("semitone_step", 1.0f);
  pitch_hi = input("pitch_hi", 500.0f);
  pitch_lo = input("pitch_lo", 80.0f);
  microphone Voice_in = microphone(MIC_L);
  expander fan_3 = expander(3);
  pitchDetect Pitch_detect = pitchDetect(80.0, 500.0);
  envFollower Envelope = envFollower(0.005, 0.05);
  fracDelay Slap_back_echo = fracDelay(8192);
  speaker Echo_voice = speaker(SPEAKER2);
  sat Pitch_floor = sat();
  logFunc ln_pitch_ = logFunc();
  gain Hz_to_semitone = gain(17.312340490667562);
  quantizer Snap_to_scale = quantizer();
  gain semitone_to_ln_Hz_ = gain(0.05776226504666211);
  expFunc pitch_reconstruct = expFunc();
  gain Hz_to_rad_per_s = gain(6.283185);
  integrator Phase_accumulator = integrator();
  sineFunc Resynth_tone = sineFunc();
  node Voice_VCA = node("[1.0 1.0]", "[1.0]", Mul);
  speaker Lead_voice = speaker(SPEAKER1);
  Envelope_tap = probe("Envelope_o0");

  /* Connect Blocks */
  semitone_step > Snap_to_scale.in(1);
  pitch_hi > Pitch_floor.in(0);
  pitch_lo > Pitch_floor.in(1);
  Voice_in > fan_3;
  fan_3.out(0) > Pitch_detect;
  fan_3.out(1) > Envelope;
  fan_3.out(2) > Slap_back_echo;
  Pitch_detect > Pitch_floor.in(2);
  Envelope > Voice_VCA.in(1);
  Envelope > Envelope_tap;
  Slap_back_echo > Echo_voice;
  Pitch_floor > ln_pitch_;
  ln_pitch_ > Hz_to_semitone;
  Hz_to_semitone > Snap_to_scale.in(0);
  Snap_to_scale > semitone_to_ln_Hz_;
  semitone_to_ln_Hz_ > pitch_reconstruct;
  pitch_reconstruct > Hz_to_rad_per_s;
  Hz_to_rad_per_s > Phase_accumulator;
  Phase_accumulator > Resynth_tone;
  Resynth_tone > Voice_VCA.in(0);
  Voice_VCA > Lead_voice;

  /* Enable Remote Input Control */
  semitone_step.enableRemote();
  pitch_hi.enableRemote();
  pitch_lo.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    Envelope_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}