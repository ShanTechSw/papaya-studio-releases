var dir_01538ad46ba247002bef53366126b333 =
[
    [ "host_arduino_compat", "dir_695b88d4823c2e28ea12e37dfec64c26.html", "dir_695b88d4823c2e28ea12e37dfec64c26" ],
    [ "linux_spidev", "dir_e855715d1e2745efd7132286dd691850.html", "dir_e855715d1e2745efd7132286dd691850" ],
    [ "pc_usb", "dir_f8fc63b6aa9436f8a8d10ebb0126baf3.html", "dir_f8fc63b6aa9436f8a8d10ebb0126baf3" ],
    [ "posix_serial", "dir_786727adecdcf9ef8b21fe7ddc1cc950.html", "dir_786727adecdcf9ef8b21fe7ddc1cc950" ],
    [ "stm32cubeide_hal", "dir_ee77e45f865b21b28a134c54aa202e57.html", "dir_ee77e45f865b21b28a134c54aa202e57" ],
    [ "usb_bridge", "dir_d22b04f39f18cdd537ccf310a05f0366.html", "dir_d22b04f39f18cdd537ccf310a05f0366" ],
    [ "windows_serial", "dir_aeeb11f69d581ba6c9487659ab78b8de.html", "dir_aeeb11f69d581ba6c9487659ab78b8de" ]
];