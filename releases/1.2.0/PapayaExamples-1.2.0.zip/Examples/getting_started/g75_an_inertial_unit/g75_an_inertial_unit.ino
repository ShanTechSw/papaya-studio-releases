/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe gyro_x;
probe gyro_y;
probe gyro_z;
probe accel_x;
probe accel_y;
probe accel_z;
probe accel_magnitude;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  imu Accelerometer = imu(IMU_ACC, 1.0);
  imu Gyroscope = imu(IMU_GYR, 1.0);
  expander axis_0 = expander(2);
  expander axis_1 = expander(2);
  expander axis_2 = expander(2);
  mag3 Magnitude = mag3();
  gyro_x = probe("gyro_x");
  gyro_y = probe("gyro_y");
  gyro_z = probe("gyro_z");
  accel_x = probe("accel_x");
  accel_y = probe("accel_y");
  accel_z = probe("accel_z");
  accel_magnitude = probe("accel_magnitude");

  /* Connect Blocks */
  Accelerometer.out(0) > axis_0;
  Accelerometer.out(1) > axis_1;
  Accelerometer.out(2) > axis_2;
  Gyroscope.out(0) > gyro_x;
  Gyroscope.out(1) > gyro_y;
  Gyroscope.out(2) > gyro_z;
  axis_0.out(0) > Magnitude.in(0);
  axis_0.out(1) > accel_x;
  axis_1.out(0) > Magnitude.in(1);
  axis_1.out(1) > accel_y;
  axis_2.out(0) > Magnitude.in(2);
  axis_2.out(1) > accel_z;
  Magnitude > accel_magnitude;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    gyro_x.show();
    gyro_y.show();
    gyro_z.show();
    accel_x.show();
    accel_y.show();
    accel_z.show();
    accel_magnitude.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}