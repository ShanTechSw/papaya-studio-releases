/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe beam_angle;
probe ball_position;
probe beam_rate_2;
probe ball_velocity_2;

input ball_target;
input angle_slew_up;
input angle_slew_dn;
input torque_min;
input torque_max;

/* Global Struct Declarations */
// Configuration for SIM__ball_on_beam
static float SIM__ball_on_beam_A_data[4] = {1.0f, 0.001f, 0.0f, 1.0f};
static float SIM__ball_on_beam_B_data[2] = {3.50357142857e-06f, 0.00700714285714f};
static float SIM__ball_on_beam_C_data[2] = {1.0f, 0.0f};
static float SIM__ball_on_beam_D_data[1] = {0.0f};
static float SIM__ball_on_beam_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__ball_on_beam_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__ball_on_beam_A_data,
  .B_data = SIM__ball_on_beam_B_data,
  .C_data = SIM__ball_on_beam_C_data,
  .D_data = SIM__ball_on_beam_D_data,
  .x_init = SIM__ball_on_beam_x_init
};


/* Global Array Declarations */
float SIM__beam_motor_numerator[] = {1.0f};
float SIM__beam_motor_denominator[] = {1.0f, 4.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ball_target = input("ball_target_m", 0.3f);
  angle_slew_up = input("angle_slew_up", 1.0f);
  angle_slew_dn = input("angle_slew_dn", 1.0f);
  torque_min = input("torque_min", -1.0f);
  torque_max = input("torque_max", 1.0f);
  node position_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid outer_ball_PID = pid(0.05, 1.4, 0.9, 0.02);
  rateLimiter angle_slew_limit = rateLimiter();
  node angle_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid inner_beam_PID = pid(1.0, 6.0, 0.4, 0.01);
  sat torque_clamp = sat();
  tf SIM__beam_motor = tf(SIM__beam_motor_numerator, 1, SIM__beam_motor_denominator, 2);
  expander fan_3 = expander(3);
  stateSpace SIM__ball_on_beam = stateSpace(&SIM__ball_on_beam_config);
  expander fan_2 = expander(2);
  derivative beam_rate = derivative(0.01);
  derivative ball_velocity = derivative(0.02);
  beam_angle = probe("beam_angle_rad");
  ball_position = probe("ball_position_m");
  beam_rate_2 = probe("beam_rate");
  ball_velocity_2 = probe("ball_velocity");

  /* Connect Blocks */
  ball_target > position_error.in(0);
  angle_slew_up > angle_slew_limit.in(1);
  angle_slew_dn > angle_slew_limit.in(2);
  torque_min > torque_clamp.in(1);
  torque_max > torque_clamp.in(0);
  position_error > outer_ball_PID;
  outer_ball_PID > angle_slew_limit.in(0);
  angle_slew_limit > angle_error.in(0);
  angle_error > inner_beam_PID;
  inner_beam_PID > torque_clamp.in(2);
  torque_clamp > SIM__beam_motor;
  SIM__beam_motor > fan_3;
  SIM__beam_motor > beam_angle;
  fan_3.out(1) > angle_error.in(1);
  fan_3.out(0) > SIM__ball_on_beam;
  fan_3.out(2) > beam_rate;
  SIM__ball_on_beam > fan_2;
  SIM__ball_on_beam > ball_position;
  fan_2.out(0) > position_error.in(1);
  fan_2.out(1) > ball_velocity;
  beam_rate > beam_rate_2;
  ball_velocity > ball_velocity_2;

  /* Enable Remote Input Control */
  ball_target.enableRemote();
  angle_slew_up.enableRemote();
  angle_slew_dn.enableRemote();
  torque_min.enableRemote();
  torque_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    beam_angle.show();
    ball_position.show();
    beam_rate_2.show();
    ball_velocity_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}