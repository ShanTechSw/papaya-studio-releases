var searchData=
[
  ['haar_0',['HAAR',['../_p_a_p_a_y_a_8h.html#a99b8fcaf681aae86978400075136e314a1ea930ade0a3b1a7a2ba438b98cf148b',1,'PAPAYA.h']]],
  ['hamming_1',['hamming',['../_p_a_p_a_y_a_8h.html#aef9b3e5d8856ec7b479ff82df4e4a58daa8c48128fde24ff9b040ac87c913b8bf',1,'PAPAYA.h']]],
  ['hann_2',['hann',['../_p_a_p_a_y_a_8h.html#aef9b3e5d8856ec7b479ff82df4e4a58da0ab3c44d2556b803538a23128766cf06',1,'PAPAYA.h']]],
  ['hdc1080_3',['HDC1080',['../_p_a_p_a_y_a_8h.html#a253724c4643f2cd0861f4299a3ded381ab545790297adff815816f39417380f51',1,'PAPAYA.h']]],
  ['hts221_4',['HTS221',['../_p_a_p_a_y_a_8h.html#a253724c4643f2cd0861f4299a3ded381ab1277fe371cfa7dcb50c6befb21834c8',1,'PAPAYA.h']]]
];
