/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe coulomb_count;
probe state_of_charge;
probe state_of_health;
probe SoC___SoH_EKF_tap;
probe balance_active;
probe core_temperature;
probe thermal_EKF_tap;

input bal_rail_hi;
input bal_thr;
input balance_trigger_2;

/* Global Struct Declarations */
// Configuration for SoC___SoH_EKF
static float SoC___SoH_EKF_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float SoC___SoH_EKF_R_data[1] = {0.01f};
static float SoC___SoH_EKF_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_BatterySOH_EKF SoC___SoH_EKF_config = {
  .R1 = 0.01f,
  .C1 = 1000.0f,
  .ocv_coef = { 3.0f, 0.5f, 0.1f, 0.01f },
  .Q_data = SoC___SoH_EKF_Q_data,
  .R_data = SoC___SoH_EKF_R_data,
  .x_init = SoC___SoH_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for thermal_EKF
static float thermal_EKF_Q_data[4] = {0.01f, 0.0f, 0.0f, 0.01f};
static float thermal_EKF_R_data[1] = {0.1f};
static float thermal_EKF_x_init[2] = {0.0f, 0.0f};
PP_Thermal_EKF thermal_EKF_config = {
  .R_th = 1.0f,
  .C_core = 10.0f,
  .C_surf = 5.0f,
  .R_conv = 2.0f,
  .T_amb = 25.0f,
  .Q_data = thermal_EKF_Q_data,
  .R_data = thermal_EKF_R_data,
  .x_init = thermal_EKF_x_init,
  .P_init = 1.0f
};


/* Global Array Declarations */
float SIM__cell_RC_model_numerator[] = {1.0f};
float SIM__cell_RC_model_denominator[] = {20.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  bal_rail_hi = input("rail_hi", 1.0f);
  bal_thr = input("imbalance_thr", 0.05f);
  balance_trigger_2 = input("balance_trigger", 0.0f);
  signalSource SIM__load_current = signalSource::multisine(100.0f, 50.0f, 4, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 3.0f);
  signalSource SIM__open_circuit_V = signalSource::ramp(-0.001f, 0.0f, -1000000000.0f, 1000000000.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.0f, /*offset=*/ 3.6f);
  signalSource SIM__weak_cell_V = signalSource::sine(0.1f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.05f, /*offset=*/ 3.6f);
  signalSource SIM__pack_temperature = signalSource::sine(0.05f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 4.0f, /*offset=*/ 30.0f);
  expander fan_4 = expander(4);
  expander fan_2 = expander(2);
  tf SIM__cell_RC_model = tf(SIM__cell_RC_model_numerator, 1, SIM__cell_RC_model_denominator, 2);
  integrator coulomb_counter = integrator();
  node cell_imbalance = node("[1.0 -1.0]", "[1.0]", Sum);
  sqrMath I_squared = sqrMath();
  node terminal_voltage = node("[1.0 1.0]", "[1.0]", Sum);
  gain ohmic_loss = gain(0.05);
  absVal imbalance_magnitude = absVal();
  batterySOH_EKF SoC___SoH_EKF = batterySOH_EKF(&SoC___SoH_EKF_config);
  comp balance_trigger = comp();
  thermalEKF thermal_EKF = thermalEKF(&thermal_EKF_config);
  coulomb_count = probe("coulomb_count");
  state_of_charge = probe("state_of_charge");
  state_of_health = probe("state_of_health");
  SoC___SoH_EKF_tap = probe("SoC / SoH EKF_2");
  balance_active = probe("balance_active");
  core_temperature = probe("core_temperatur");
  thermal_EKF_tap = probe("thermal EKF_o1");

  /* Connect Blocks */
  bal_rail_hi > balance_trigger.in(0);
  bal_thr > balance_trigger.in(3);
  balance_trigger_2 > balance_trigger.in(1);
  SIM__load_current > fan_4;
  SIM__open_circuit_V > fan_2;
  SIM__weak_cell_V > cell_imbalance.in(1);
  SIM__pack_temperature > thermal_EKF.in(1);
  fan_4.out(0) > SIM__cell_RC_model;
  fan_4.out(1) > coulomb_counter;
  fan_4.out(3) > I_squared;
  fan_4.out(2) > SoC___SoH_EKF.in(1);
  fan_2.out(1) > cell_imbalance.in(0);
  fan_2.out(0) > terminal_voltage.in(1);
  SIM__cell_RC_model > terminal_voltage.in(0);
  coulomb_counter > coulomb_count;
  cell_imbalance > imbalance_magnitude;
  I_squared > ohmic_loss;
  terminal_voltage > SoC___SoH_EKF.in(0);
  ohmic_loss > thermal_EKF.in(0);
  imbalance_magnitude > balance_trigger.in(2);
  SoC___SoH_EKF.out(0) > state_of_charge;
  SoC___SoH_EKF.out(1) > state_of_health;
  SoC___SoH_EKF.out(2) > SoC___SoH_EKF_tap;
  balance_trigger > balance_active;
  thermal_EKF.out(0) > core_temperature;
  thermal_EKF.out(1) > thermal_EKF_tap;

  /* Enable Remote Input Control */
  bal_rail_hi.enableRemote();
  bal_thr.enableRemote();
  balance_trigger_2.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    coulomb_count.show();
    state_of_charge.show();
    state_of_health.show();
    SoC___SoH_EKF_tap.show();
    balance_active.show();
    core_temperature.show();
    thermal_EKF_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}