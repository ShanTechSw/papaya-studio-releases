"""Gear mesh: the board measures the sidebands, this script reads the tooth.

Run this beside example 90.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  wear            the sideband energy ratio: how much energy sits in the
                  lines either side of the mesh, as a fraction of the mesh
                  line itself. It is the standard gear indicator and it
                  moves while the mesh line does not.

  a crack         crest factor and kurtosis on a high-passed copy. A
                  cracked tooth deflects under load and lets go, once per
                  revolution, which is an impact. Sidebands see that only
                  indirectly; an impulsiveness measure sees it directly.

  and the trap    the mesh line itself is reported and deliberately NOT
                  used for a decision. Watching it is the commonest way to
                  miss a gear fault, and printing it beside the ratio is
                  the fastest way to see why.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "worn tooth", "cracked tooth")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "gear"
FEATURES = ("e_gmf", "e_lo1", "e_hi1", "e_lo2", "e_hi2",
            "sb_sum", "sb_ratio", "crest", "kurtosis",
            "state")

SIDEBAND_WORN = 0.30        # sideband energy over mesh energy
SIDEBAND_BAD = 0.90
CREST_IMPACT = 2.5          # on the high-passed copy
KURTOSIS_IMPACT = 0.0       # crossing zero is the line worth watching

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def classify(row):
    ratio = row["sb_ratio"]
    crest, kurt = row["crest"], row["kurtosis"]
    reasons = [
        f"mesh line {row['e_gmf']:.4f} g, sidebands together "
        f"{row['sb_sum']:.4f} g, ratio {ratio:.3f}",
        f"first sidebands {row['e_lo1']:.4f} and {row['e_hi1']:.4f} g, "
        f"second {row['e_lo2']:.4f} and {row['e_hi2']:.4f} g",
        f"on the high-passed copy: crest {crest:.2f}, excess kurtosis "
        f"{kurt:+.2f}",
    ]

    impacting = crest >= CREST_IMPACT and kurt >= KURTOSIS_IMPACT
    if impacting and ratio >= SIDEBAND_WORN:
        reasons.append(
            "impacts AND sidebands together: the tooth is not merely worn, "
            "it is deflecting and letting go once per revolution")
        return ("cracked tooth",
                "a cracked or chipped tooth, and it will not get better",
                reasons)
    if ratio >= SIDEBAND_BAD:
        reasons.append("sidebands carry more energy than the mesh line "
                       "itself")
        return ("worn tooth", "advanced tooth wear", reasons)
    if ratio >= SIDEBAND_WORN:
        reasons.append(
            f"the mesh line has hardly moved and the sidebands have. That "
            f"is the whole point: a mesh line of {row['e_gmf']:.4f} g says "
            f"nothing on its own")
        return ("worn tooth", "one tooth is not meshing like the others",
                reasons)
    if impacting:
        reasons.append(
            "impacts without sidebands: something is hitting once a "
            "revolution that is not a tooth. A loose key, a coupling, or "
            "debris")
        return ("cracked tooth", "impacts, but not from the mesh", reasons)
    return ("healthy", "the mesh is clean", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 90_gear_mesh_sidebands.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA gear mesh and sideband monitor")
    print("=" * 72)
    print("Thresholds: sideband ratio {:.2f} for wear and {:.2f} for "
          "serious wear,".format(SIDEBAND_WORN, SIDEBAND_BAD))
    print("crest {:.1f} or excess kurtosis {:+.1f} for an impact."
          .format(CREST_IMPACT, KURTOSIS_IMPACT))
    print("The mesh line is printed for comparison and is never used for a "
          "decision.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
