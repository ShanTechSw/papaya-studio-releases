"""
Runtime loader for the Papaya asset blob.

Generated during packaging. Do not edit by hand: it is overwritten.
"""

from __future__ import annotations

import hashlib
import json
import os
import struct
import sys
import zlib
from pathlib import Path

_MAGIC = b"PAPAYAASSETS\x00\x01\x00\x00"
_HEADER_FORMAT = "<16s16sQ"
_HEADER_SIZE = struct.calcsize(_HEADER_FORMAT)
if len(_MAGIC) != 16:                                   # pragma: no cover
    raise RuntimeError("asset blob magic must be exactly 16 bytes")


def _resolve_blob_path() -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    cand = base / "papaya_assets.bin"
    if cand.exists():
        return cand
    return base / "release" / ".assets_dist" / "papaya_assets.bin"


def _resolve_key() -> bytes:
    env = os.environ.get("PAPAYA_ASSET_KEY")
    if env:
        return bytes.fromhex(env)
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    for cand in (base / "release" / ".asset_key",
                 Path(__file__).resolve().parent.parent / "release" / ".asset_key"):
        if cand.exists():
            return bytes.fromhex(cand.read_text().strip())
    raise RuntimeError("Asset key not found")


def _decrypt(key, nonce, aad, ciphertext):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        return AESGCM(key).decrypt(nonce, ciphertext, aad)
    except ImportError:
        out = bytearray()
        counter = 0
        while len(out) < len(ciphertext):
            out.extend(hashlib.sha256(key + nonce + counter.to_bytes(8, "little")).digest())
            counter += 1
        ks = bytes(out[:len(ciphertext)])
        return zlib.decompress(bytes(c ^ k for c, k in zip(ciphertext, ks)))


class _BlobIndex:
    def __init__(self):
        self._blob_path = _resolve_blob_path()
        self._key = _resolve_key()
        self._entries: dict = {}
        self._nonce = b""
        self._body_offset = 0
        self._loaded = False

    def _ensure_loaded(self):
        if self._loaded:
            return
        if not self._blob_path.exists():
            raise FileNotFoundError(f"Asset blob not found: {self._blob_path}")
        with self._blob_path.open("rb") as f:
            header = f.read(_HEADER_SIZE)
            magic, nonce, idx_len = struct.unpack(_HEADER_FORMAT, header)
            if magic != _MAGIC:
                raise ValueError("Asset blob magic mismatch")
            idx_cipher = f.read(idx_len)
            self._body_offset = _HEADER_SIZE + idx_len
            self._nonce = nonce
        aad = _MAGIC + nonce
        idx_json = _decrypt(self._key, nonce, aad, idx_cipher)
        for e in json.loads(idx_json.decode("utf-8")):
            self._entries[e["rel_path"]] = e
        self._loaded = True

    def open(self, rel_path: str) -> bytes:
        self._ensure_loaded()
        rel = rel_path.replace("\\", "/")
        e = self._entries.get(rel)
        if e is None:
            raise KeyError(f"Asset not in blob: {rel_path}")
        with self._blob_path.open("rb") as f:
            f.seek(self._body_offset + e["offset"])
            cipher = f.read(e["size"])
        # Each entry carries its own nonce. The fallback to the header nonce
        # is for a blob written before per-entry nonces existed; the loader
        # and the blob are regenerated together, so it should never be taken.
        entry_nonce = bytes.fromhex(e["nonce"]) if e.get("nonce") else self._nonce
        plain = _decrypt(self._key, entry_nonce, _MAGIC + entry_nonce, cipher)
        if hashlib.sha256(plain).hexdigest() != e["sha256"]:
            raise ValueError(f"Asset hash mismatch for {rel_path}")
        return plain


_INDEX = _BlobIndex()


def open_asset(rel_path: str) -> bytes:
    return _INDEX.open(rel_path)
