/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Thermal EKF in                      the surface temperature in degC of the
 *                                          device the filter models, dissipating
 *                                          the 5 W set by heater_power_W: 35 degC
 *                                          (ambient 25 plus 5 W through the 2 K/W
 *                                          convection path) with a slow 1 degC sway
 *                                          and 0.3 degC of sensor noise
 *      Baro altitude (m)                   a barometric altitude in metres: 50 m
 *                                          with a slow 2 m sway at 0.2 Hz and 0.7 m
 *                                          of barometric noise
 *      Vertical accel (m/s^2, g removed)   the acceleration that same 2 m sway
 *                                          really has, 3.2 m/s^2 peak, plus a
 *                                          deliberate +0.3 m/s^2 accelerometer bias
 *                                          for the filter's bias_est output to
 *                                          find, and 0.05 m/s^2 of noise
 *      Sine-tracking EKF in                a 1.5 V sine at 48 Hz with 0.05 V of
 *                                          noise: close enough to the filter's 50
 *                                          Hz starting guess to lock, far enough
 *                                          that amp_est, freq_est and phase_est
 *                                          visibly measure the signal instead of
 *                                          repeating their initial values
 *      Grid-sync EKF in                    a mains voltage in volts: 325 V peak at
 *                                          49.8 Hz with 0.5 V of noise, slightly
 *                                          off the 50 Hz nominal so
 *                                          grid_omega_rad_s visibly converges to
 *                                          312.9 rad/s rather than parroting 314.2
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe core_temp;
probe Thermal_EKF_tap;
probe altitude;
probe Baro_altitude_EKF_tap;
probe Baro_altitude_EKF_tap_2;
probe amplitude;
probe Sine_tracking_EKF_tap;
probe Sine_tracking_EKF_tap_2;
probe grid_phase_rad;
probe grid_omega_rad;
probe Grid_sync_EKF_tap;

input heater_power_W;

/* Global Struct Declarations */
// Configuration for Thermal_EKF
static float Thermal_EKF_Q_data[4] = {0.01f, 0.0f, 0.0f, 0.01f};
static float Thermal_EKF_R_data[1] = {0.1f};
static float Thermal_EKF_x_init[2] = {0.0f, 0.0f};
PP_Thermal_EKF Thermal_EKF_config = {
  .R_th = 1.0f,
  .C_core = 10.0f,
  .C_surf = 5.0f,
  .R_conv = 2.0f,
  .T_amb = 25.0f,
  .Q_data = Thermal_EKF_Q_data,
  .R_data = Thermal_EKF_R_data,
  .x_init = Thermal_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for Baro_altitude_EKF
static float Baro_altitude_EKF_Q_data[9] = {0.01f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Baro_altitude_EKF_R_data[1] = {0.5f};
static float Baro_altitude_EKF_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_BaroAlt_EKF Baro_altitude_EKF_config = {
  .Q_data = Baro_altitude_EKF_Q_data,
  .R_data = Baro_altitude_EKF_R_data,
  .x_init = Baro_altitude_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for Sine_tracking_EKF
static float Sine_tracking_EKF_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Sine_tracking_EKF_R_data[1] = {0.1f};
static float Sine_tracking_EKF_x_init[3] = {1.0f, 314.159265359f, 0.0f};
PP_SinTrack_EKF Sine_tracking_EKF_config = {
  .Q_data = Sine_tracking_EKF_Q_data,
  .R_data = Sine_tracking_EKF_R_data,
  .x_init = Sine_tracking_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for Grid_sync_EKF
static float Grid_sync_EKF_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Grid_sync_EKF_R_data[1] = {0.1f};
static float Grid_sync_EKF_x_init[3] = {0.0f, 314.159265359f, 325.0f};
PP_GridSync_EKF Grid_sync_EKF_config = {
  .nom_freq = 50.0f,
  .nom_amplitude = 325.0f,
  .Q_data = Grid_sync_EKF_Q_data,
  .R_data = Grid_sync_EKF_R_data,
  .x_init = Grid_sync_EKF_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  heater_power_W = input("heater_power_W", 5.0f);
  analogIn Thermal_EKF_in = analogIn(AIN1, 5.0, 50.0);
  analogIn Baro_altitude__m_ = analogIn(AIN2, 5.0, 50.0);
  analogIn Vertical_accel__m_s_2__g_removed_ = analogIn(AIN5, 1.0, 0.0);
  analogIn Sine_tracking_EKF_in = analogIn(AIN3, 1.0, 0.0);
  analogIn Grid_sync_EKF_in = analogIn(AIN4, 1.0, 0.0);
  thermalEKF Thermal_EKF = thermalEKF(&Thermal_EKF_config);
  baroAltEKF Baro_altitude_EKF = baroAltEKF(&Baro_altitude_EKF_config);
  sinTrackEKF Sine_tracking_EKF = sinTrackEKF(&Sine_tracking_EKF_config);
  gridSyncEKF Grid_sync_EKF = gridSyncEKF(&Grid_sync_EKF_config);
  core_temp = probe("core_temp");
  Thermal_EKF_tap = probe("Thermal EKF_o1");
  altitude = probe("altitude");
  Baro_altitude_EKF_tap = probe("Baro altitude_1");
  Baro_altitude_EKF_tap_2 = probe("Baro altitude_2");
  amplitude = probe("amplitude");
  Sine_tracking_EKF_tap = probe("Sine-tracking_1");
  Sine_tracking_EKF_tap_2 = probe("Sine-tracking_2");
  grid_phase_rad = probe("grid_phase_rad");
  grid_omega_rad = probe("grid_omega_rad");
  Grid_sync_EKF_tap = probe("grid_amp_peak_v");

  /* Connect Blocks */
  heater_power_W > Thermal_EKF.in(0);
  Thermal_EKF_in > Thermal_EKF.in(1);
  Baro_altitude__m_ > Baro_altitude_EKF.in(0);
  Vertical_accel__m_s_2__g_removed_ > Baro_altitude_EKF.in(1);
  Sine_tracking_EKF_in > Sine_tracking_EKF;
  Grid_sync_EKF_in > Grid_sync_EKF;
  Thermal_EKF.out(0) > core_temp;
  Thermal_EKF.out(1) > Thermal_EKF_tap;
  Baro_altitude_EKF.out(0) > altitude;
  Baro_altitude_EKF.out(1) > Baro_altitude_EKF_tap;
  Baro_altitude_EKF.out(2) > Baro_altitude_EKF_tap_2;
  Sine_tracking_EKF.out(0) > amplitude;
  Sine_tracking_EKF.out(1) > Sine_tracking_EKF_tap;
  Sine_tracking_EKF.out(2) > Sine_tracking_EKF_tap_2;
  Grid_sync_EKF.out(0) > grid_phase_rad;
  Grid_sync_EKF.out(1) > grid_omega_rad;
  Grid_sync_EKF.out(2) > Grid_sync_EKF_tap;

  /* Enable Remote Input Control */
  heater_power_W.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    core_temp.show();
    Thermal_EKF_tap.show();
    altitude.show();
    Baro_altitude_EKF_tap.show();
    Baro_altitude_EKF_tap_2.show();
    amplitude.show();
    Sine_tracking_EKF_tap.show();
    Sine_tracking_EKF_tap_2.show();
    grid_phase_rad.show();
    grid_omega_rad.show();
    Grid_sync_EKF_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}