/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe compressed_puls;
probe range_peak;
probe detection;

input decl_rail_hi;
input const_;
input detection_decla;

/* Global Array Declarations */
const float matched_filter_coefficients[] = {
  -0.00500266897f, -3.53615439e-05f, 0.00500204408f, 0.000141428508f, -0.00499779558f, -0.000318041917f, 0.00498393382f, 0.000564584016f, -0.004951515f, -0.000879451967f,
  0.0048887482f, 0.00125933157f, -0.0047812346f, -0.00169829261f, 0.00461241754f, 0.00218674889f, -0.00436433547f, -0.00271035804f, 0.00401877273f, 0.00324897867f,
  -0.00355889275f, -0.00377585449f, 0.00297140547f, 0.00425725033f, -0.00224926016f, -0.0046528162f, 0.00139475903f, 0.00491698632f, -0.000422854641f, -0.00500171246f,
  -0.000635771423f, 0.00486075951f, 0.00173243329f, -0.0044556325f, -0.002799723f, 0.00376293812f, 0.00375321275f, -0.00278260437f, -0.00449642395f, 0.00154591214f,
  0.00492969579f, -0.000121789854f, -0.00496310597f, -0.00138060313f, 0.00453281112f, 0.00281517027f, -0.00361910765f, -0.00400998054f, 0.00226328728f, 0.0047872632f,
  -0.000579221514f, -0.00499179366f, -0.00124506651f, 0.00452488296f, 0.00296033102f, -0.00337847176f, -0.0042863874f, 0.001661283f, 0.0049593208f, 0.000392505496f,
  -0.00479038855f, -0.00244098527f, 0.00372580877f, 0.00408388141f, -0.00189173099f, -0.00494169865f, -0.000393484734f, 0.00475294825f, 0.00265480858f, -0.00346729205f,
  -0.004349856f, 0.00130490575f, 0.0050025301f, 0.00124792039f, -0.00435276398f, -0.00352629608f, 0.00247776629f, 0.00485418149f, 0.000165973722f, -0.00475782835f,
  -0.00281922884f, 0.00316149999f, 0.00462224649f, -0.000486437747f, -0.00490170185f, -0.00241350026f, 0.00345239304f, 0.00449943377f, -0.000696129961f, -0.00492476793f,
  -0.00238332949f, 0.00341309429f, 0.00455986014f, -0.000466881673f, -0.00485866116f, -0.00273343431f, 0.0030342548f, 0.0047686368f, 0.000205237501f, -0.00462187068f,
  -0.00340230717f, 0.00223960362f, 0.00497672357f, 0.00130490575f, -0.00403276768f, -0.00422600372f, 0.000936443258f, 0.00491109642f, 0.00272108225f, -0.00286047035f,
  -0.00488411698f, -0.000875583793f, 0.00420218361f, 0.00413982398f, -0.000951877182f, -0.00488560044f, -0.00294129425f, 0.00251606888f, 0.00497342773f, 0.00154591214f,
  -0.00369417979f, -0.00460515882f, -0.000158119661f, 0.00446453072f, 0.00394384237f, -0.00108746532f, -0.00487325269f, -0.003140137f, 0.00212203377f, 0.00500171246f,
  0.00231394734f, -0.00292777033f, -0.00494123909f, -0.00154964845f, 0.00352001982f, 0.00477687868f, 0.000899750928f, -0.00393111804f, -0.00457905144f, -0.000392505496f,
  0.00419791452f, 0.00440080511f, 4.02727698e-05f, -0.00435324806f, -0.00427826262f, 0.000153210673f, 0.00442073407f, 0.0042323001f, -0.000187570223f, -0.00441196703f,
  -0.00427009561f, 6.28638359e-05f, 0.0043253884f, 0.00438577058f, 0.000220939604f, -0.00414643026f, -0.00455986014f, -0.000662068701f, 0.00384898757f, 0.00475782835f,
  0.0012526759f, -0.0033987049f, -0.00492835234f, -0.00197236898f, 0.00275888664f, 0.00500267523f, 0.00278015498f, -0.00189991206f, -0.00489693483f, -0.00360619755f,
  0.000812651959f, 0.00451984325f, 0.0043459693f, 0.000474704984f, -0.00378807111f, -0.00486075951f, -0.00187899315f, 0.00265064456f, 0.00498955191f, 0.00324897867f,
  -0.00112099685f, -0.00457707129f, -0.00436529539f, -0.000689320287f, 0.00352001982f, 0.00496372009f, 0.0025474151f, -0.00182698637f, -0.00479038855f, -0.00410420325f,
  -0.000322943194f, 0.00368953975f, 0.00494722546f, 0.00254995082f, -0.00170845199f, -0.00471222287f, -0.00430651408f, -0.000817497699f, 0.00324225126f, 0.00500267678f,
  0.00325569593f, -0.00074764533f, -0.0042233733f, -0.00479963049f, -0.00211669514f, 0.00198319597f, 0.00474522921f, 0.00435324806f, 0.00109992597f, -0.00286047035f,
  -0.0049569671f, -0.00386462766f, -0.000315101003f, 0.00342170267f, 0.00500261651f, 0.00347012328f, -0.000195422649f, -0.00372908447f, -0.00499080066f, -0.00324897867f,
  0.000422854641f, 0.00383199211f, 0.00498410334f, 0.00323701183f, -0.000368019734f, -0.00374996372f, -0.00499716936f, -0.00343600773f, 3.04502839e-05f, 0.00346729205f,
  0.00499669894f, 0.00381425344f, 0.000588977062f, -0.00293732002f, -0.00490170185f, -0.00429799263f, -0.00147192753f, 0.00209798688f, 0.00458771162f, 0.00475782835f,
  0.00255417504f, -0.000902649539f, -0.00390362684f, -0.00499968992f, -0.00369020304f, -0.000630899574f, 0.00271283442f, 0.00477687868f, 0.00462524656f, 0.00235824551f,
  -0.000967301711f, -0.00384459171f, -0.00500204408f, -0.00395529708f, -0.00119171586f, 0.0020729871f, 0.00443898976f, 0.00492056895f, 0.00334427973f, 0.000392505496f,
  -0.00270622863f, -0.00469482649f, -0.0047932104f, -0.00299112537f, -2.45567336e-05f, 0.00293732002f, 0.00475752472f, 0.00476266149f, 0.00297930205f, 9.82210173e-05f,
  -0.0028046053f, -0.0046741457f, -0.00485536691f, -0.00331127575f, -0.000612381042f, 0.00228515989f, 0.00438340578f, 0.00498367811f, 0.00390976241f, 0.00154591214f,
  -0.00131154239f, -0.00372908447f, -0.00494093177f, -0.00458496538f, -0.002799723f, -0.000161064981f, 0.00251182269f, 0.00441381783f, 0.00499335244f, 0.00410420325f,
  0.0020308827f, -0.000611406144f, -0.00306539968f, -0.0046499234f, -0.00494486752f, -0.00389439528f, -0.00180593601f, 0.00074764533f, 0.00309017953f, 0.00462187068f,
  0.00496903184f, 0.00406793441f, 0.00216640704f, -0.000251356084f, -0.00259292189f, -0.00430401275f, -0.00499707681f, -0.00453322664f, -0.00304205864f, -0.000879451967f,
  0.00146253676f, 0.00347012328f, 0.00471976084f, 0.00496372009f, 0.0041731666f, 0.00253302938f, 0.000393484734f, -0.00180868381f, -0.00364073702f, -0.00475782835f,
  -0.00496432943f, -0.00424274185f, -0.00274740464f, -0.000767064351f, 0.00133427772f, 0.00318579779f, 0.00447467855f, 0.00499635818f, 0.0046828417f, 0.00360619755f,
  0.00195881984f, 1.57163468e-05f, -0.00191353398f, -0.00353464729f, -0.00461241754f, -0.00500228179f, -0.00466604591f, -0.00367090996f, -0.0021734875f, -0.000392505496f,
  0.00142491769f, 0.00303815818f, 0.00424430247f, 0.00490189812f, 0.00494486752f, 0.00438577058f, 0.00330906626f, 0.00185621175f, 0.000205237501f, -0.00145220041f,
  -0.00293334296f, -0.00408388141f, -0.00479264751f, -0.00500033013f, -0.00470191097f, -0.00394323796f, -0.00281273383f, -0.00142962493f, 6.97391445e-05f, 0.00154591214f,
  0.00286932811f, 0.00393111804f, 0.00465100955f, 0.00498192918f, 0.00491128341f, 0.00445920004f, 0.00367424486f, 0.00262727893f, 0.00140418958f, 9.82210173e-05f,
  -0.00119743901f, -0.00239627369f, -0.0034238518f, -0.00422179309f, -0.00475018258f, -0.00498846367f, -0.00493494792f, -0.00460515882f, -0.00402927733f, -0.00324897867f,
  -0.00231394734f, -0.00127833464f, -0.000197385681f, 0.000875583793f, 0.00189173099f, 0.00280867092f, 0.00359187011f, 0.00421545762f, 0.00466249457f, 0.00492476793f,
  0.00500219066f, 0.00490189812f, 0.00463713264f, 0.00422600372f, 0.00369020304f, 0.0030537424f, 0.00234176967f, 0.00157950435f, 0.000791321458f, 0.0f
};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  decl_rail_hi = input("rail_hi", 1.0f);
  detection_decla = input("detection_decla", 0.0f);
  signalSource SIM__TX_chirp = signalSource::chirpLinear(500.0f, 5000.0f, 0.02f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  const_ = input("const", 0.0f);
  noise SIM__receiver_noise = noise(0.0, 0.1, gaussian);
  expander fan_3 = expander(3);
  delayop SIM__target_1_echo = delayop(120);
  delayop SIM__target_2_echo = delayop(320);
  gain target_1_RCS = gain(0.6);
  gain target_2_RCS = gain(0.35);
  node received_echo = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  node echo___noise = node("[1.0 1.0]", "[1.0]", Sum);
  CustFir matched_filter = CustFir(const_cast<float*>(matched_filter_coefficients), 400);
  absVal envelope_detector = absVal();
  expander fan_3_2 = expander(3);
  maxObserver range_peak_hold = maxObserver(65);
  mean CFAR_noise_level = mean(255);
  gain CFAR_scale = gain(15.0);
  comp detection_declare = comp();
  compressed_puls = probe("compressed_puls");
  range_peak = probe("range_peak");
  detection = probe("detection_flag");

  /* Connect Blocks */
  decl_rail_hi > detection_declare.in(0);
  detection_decla > detection_declare.in(1);
  SIM__TX_chirp > fan_3;
  const_ > SIM__receiver_noise;
  SIM__receiver_noise > echo___noise.in(1);
  fan_3.out(0) > SIM__target_1_echo;
  fan_3.out(1) > SIM__target_2_echo;
  fan_3.out(2) > received_echo.in(2);
  SIM__target_1_echo > target_1_RCS;
  SIM__target_2_echo > target_2_RCS;
  target_1_RCS > received_echo.in(0);
  target_2_RCS > received_echo.in(1);
  received_echo > echo___noise.in(0);
  echo___noise > matched_filter;
  matched_filter > envelope_detector;
  envelope_detector > fan_3_2;
  envelope_detector > compressed_puls;
  fan_3_2.out(0) > range_peak_hold;
  fan_3_2.out(1) > CFAR_noise_level;
  fan_3_2.out(2) > detection_declare.in(2);
  range_peak_hold > range_peak;
  CFAR_noise_level > CFAR_scale;
  CFAR_scale > detection_declare.in(3);
  detection_declare > detection;

  /* Enable Remote Input Control */
  decl_rail_hi.enableRemote();
  detection_decla.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    compressed_puls.show();
    range_peak.show();
    detection.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}