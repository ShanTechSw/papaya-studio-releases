var classcheby1_bq =
[
    [ "cheby1Bq", "classcheby1_bq.html#a2ab26bd505daddafd27d9ef9e83ed977", null ],
    [ "cheby1Bq", "classcheby1_bq.html#aac4d3a7ebf6561a57b14b6730a4ad4b3", null ]
];