r"""
Resolve where the Papaya user libraries are installed.

The libraries are shipped and updated *independently* of the Papaya
Studio code generator, the same way STM32CubeMX keeps its tool and its
firmware-package "Repository folder" separate. Studio reads C++/Python
library files from this location and copies them into the projects it
generates, so the libraries can be re-downloaded and replaced without
reinstalling Studio.

Folder layout
-------------
The resolved *libraries root* is a directory that contains::

    <root>/
        .papaya_libraries        marker file (written by the installer)
        VERSION                  libraries version (one semver line)
        papaya_lib/              C++ device library (PAPAYA.h/.cpp, ports/)
        papaya/                  Python host library package

In a development checkout the root is simply the Studio repository
itself, which already has ``papaya_lib/`` and ``papaya/`` side by side.
On a customer machine the installer populates the user-chosen folder
with the same two subdirectories.

Resolution order (first hit wins)
---------------------------------
  1. Env var ``PAPAYA_LIBRARIES_PATH``
     (ad-hoc overrides during testing / CI).
  2. QSettings  "Shanon Technologies / Papaya Studio"  key ``libraries/path``
     (set by the user via Preferences -> Libraries).
  3. The installer handoff, which is whatever channel the platform's
     installer can write and this process can read:

       * Windows: the registry under HKLM (or HKCU for per-user
         installs), ``SOFTWARE\Shanon Technologies\Papaya Studio\LibrariesPath``.
       * Linux and macOS: an ``install.conf`` key/value file, system
         location first and then per-user, listed in
         :func:`_install_conf_paths`.

     Both carry the same key names, because they are one contract with
     two spellings: the location the user chose during installation.
  4. Libraries bundled inside the application, if it is a frozen build
     carrying them. This is how the Linux packages ship: an AppImage has
     no install step that could copy a tree into the user's home, so the
     libraries travel inside the image. Ranked below the three above so
     that a user who wants their own copy still gets it.
  5. Default per-user location: ``<home>/Papaya Studio/Libraries``
     (matches the STM32CubeMX repository convention).
  6. Dev fallback: the Studio repository root (it already contains the
     ``papaya_lib/`` and ``papaya/`` directories). Lets a freshly cloned
     dev tree run without configuring anything.

``get_libraries_root()`` always returns a Path (never raises). Callers
that are about to *read* library files should first check
:func:`libraries_ok`. A fresh install may have created the root but not
yet populated it, and the user may have pointed Studio at a stale folder.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from . import _app_paths


# Subdirectories of the libraries root.
CPP_LIB_SUBDIR = "papaya_lib"
PYTHON_LIB_SUBDIR = "papaya"

# Files that mark / describe a populated libraries root.
MARKER_FILE = ".papaya_libraries"
VERSION_FILE = "VERSION"

# Sentinel files used to decide whether a subdirectory is actually a
# populated library rather than an empty placeholder.
_CPP_SENTINEL = "PAPAYA.h"
_PYTHON_SENTINEL = "__init__.py"

_DEFAULT_REL_USER = Path("Papaya Studio") / "Libraries"

# Registry sub-key written by the Inno installer. Same publisher/app
# folder structure the rest of the app uses (cf. QSettings names).
_REG_SUBKEY = r"SOFTWARE\Shanon Technologies\Papaya Studio"
_REG_VALUE = "LibrariesPath"

# The POSIX counterpart of that registry key. Written by the Linux and
# macOS installers; same value names, so the two channels stay legibly
# one contract.
_INSTALL_CONF_NAME = "install.conf"


def _from_env() -> Path | None:
    raw = (os.environ.get("PAPAYA_LIBRARIES_PATH") or "").strip()
    if raw:
        return Path(os.path.expandvars(os.path.expanduser(raw)))
    return None


def _from_qsettings() -> Path | None:
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
    except ImportError:
        return None
    s = QSettings("Shanon Technologies", "Papaya Studio")
    raw = s.value("libraries/path", "", type=str)
    if raw:
        return Path(raw)
    return None


def _from_registry() -> Path | None:
    if os.name != "nt":
        return None
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        return None
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(hive, _REG_SUBKEY, 0,
                                 winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                val, _ = winreg.QueryValueEx(k, _REG_VALUE)
                if val:
                    return Path(val)
        except OSError:
            continue
    return None


def _install_conf_paths() -> list[Path]:
    """Ordered ``install.conf`` candidates for the current platform.

    System-wide location first, then per-user, mirroring the HKLM-then-HKCU
    order the Windows branch has always used: a machine-wide install wins
    over a per-user one.

    Returns an empty list on Windows, where the registry is the channel.
    """
    plat = _app_paths._platform()
    if plat == "win32":
        return []
    if plat == "darwin":
        support = "Library/Application Support/Papaya Studio"
        return [
            Path("/Library/Application Support/Papaya Studio") / _INSTALL_CONF_NAME,
            _app_paths._home() / support / _INSTALL_CONF_NAME,
        ]
    raw = (os.environ.get("XDG_CONFIG_HOME") or "").strip()
    user_cfg = (Path(raw) if raw and os.path.isabs(raw)
                else _app_paths._home() / ".config")
    return [
        Path("/etc/papaya-studio") / _INSTALL_CONF_NAME,
        user_cfg / "papaya-studio" / _INSTALL_CONF_NAME,
    ]


def _read_install_conf(path: Path) -> dict[str, str]:
    """Parse one ``install.conf``. Never raises; a bad file reads as empty.

    Deliberately tolerant: this file is written by an installer and may be
    hand-edited afterwards by a user relocating their libraries. A stray
    blank line or comment must not cost them the whole mapping, and a
    missing file is the normal case in a development tree.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return {}
    out: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        val = val.strip().strip('"').strip("'")
        if val:
            out[key.strip()] = val
    return out


def _from_install_conf(value_name: str) -> Path | None:
    """Read one value out of the first ``install.conf`` that supplies it.

    A file that exists but omits this key does not stop the search: a
    system-wide install that set only ``LibrariesPath`` must not shadow a
    per-user file that also knows ``ExamplesPath``.
    """
    for candidate in _install_conf_paths():
        val = _read_install_conf(candidate).get(value_name)
        if val:
            return Path(os.path.expandvars(os.path.expanduser(val)))
    return None


def _from_installer() -> Path | None:
    """The installer-written libraries location, whatever the channel."""
    if _app_paths._platform() == "win32":
        return _from_registry()
    return _from_install_conf(_REG_VALUE)


def _bundle_dirs() -> list[Path]:
    """Directories that may hold libraries shipped inside the application.

    Only meaningful in an installed build. There the executable sits one
    level above the directory the bundled data is unpacked into, and which
    of the two a given data directory lands in depends on how it was
    packaged, so both are checked rather than guessed at.
    """
    if not getattr(sys, "frozen", False):
        return []
    out: list[Path] = []
    try:
        out.append(Path(sys.executable).resolve().parent)
    except OSError:
        pass
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        out.append(Path(meipass))
        out.append(Path(meipass).parent)
    # Deduplicate, preserving order.
    seen: set[str] = set()
    unique: list[Path] = []
    for p in out:
        key = str(p)
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _from_bundle() -> Path | None:
    """Libraries shipped inside the application itself.

    This is how the Linux packages carry them. An AppImage has no install
    step that could copy a libraries tree into the user's home and no
    registry-equivalent to record where it went, so the libraries travel
    inside the image and are found here.

    Ranked below the user's own settings on purpose: the decoupling that
    lets somebody update the libraries without reinstalling Studio is the
    point of this whole module, and it survives because
    ``PAPAYA_LIBRARIES_PATH``, Preferences and the installer handoff all
    still outrank the bundled copy.

    A candidate is accepted only if it is actually populated. An empty
    ``Libraries`` directory left by a packaging mistake must fall through
    to the next resolver rather than become the answer.
    """
    for base in _bundle_dirs():
        cand = base / "Libraries"
        if (cand / CPP_LIB_SUBDIR / _CPP_SENTINEL).is_file():
            return cand
    return None


def _default_user_path() -> Path:
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    return home / _DEFAULT_REL_USER


def _dev_fallback() -> Path | None:
    """In-tree dev fallback: the Studio repository root.

    ``papaya/_libraries_path.py`` -> ``papaya/`` -> repo root, which in a
    development checkout already contains both the ``papaya_lib/`` and
    ``papaya/`` directories.
    """
    repo_root = Path(__file__).resolve().parent.parent
    if (repo_root / CPP_LIB_SUBDIR).is_dir() and (repo_root / PYTHON_LIB_SUBDIR).is_dir():
        return repo_root
    return None


def get_libraries_root() -> Path:
    """Return the configured (or best-guess) Papaya libraries root.

    The root is the directory that contains the ``papaya_lib/`` and
    ``papaya/`` subdirectories. Never raises; callers should validate
    with :func:`libraries_ok` before reading.
    """
    for resolver in (_from_env, _from_qsettings, _from_installer, _from_bundle):
        p = resolver()
        if p is not None:
            return p
    # No explicit configuration. Prefer the default per-user location IF
    # it exists on disk; otherwise fall back to the in-repo dev location.
    # On a customer machine the installer always populates the default
    # location, so the dev branch is only hit for a misconfigured install
    # (and then libraries_ok() reports the problem to the user).
    default = _default_user_path()
    if default.is_dir():
        return default
    dev = _dev_fallback()
    if dev is not None:
        return dev
    return default  # last resort: let callers fail with a clear missing-dir


def get_cpp_library_path() -> Path:
    """Return the C++ device-library directory (``<root>/papaya_lib``)."""
    return get_libraries_root() / CPP_LIB_SUBDIR


def get_python_library_path() -> Path:
    """Return the Python host-library package dir (``<root>/papaya``)."""
    return get_libraries_root() / PYTHON_LIB_SUBDIR


def cpp_library_ok(root: Path | None = None) -> bool:
    """True when the C++ library subdir exists and looks populated."""
    base = (root if root is not None else get_libraries_root())
    return (base / CPP_LIB_SUBDIR / _CPP_SENTINEL).is_file()


def python_library_ok(root: Path | None = None) -> bool:
    """True when the Python library subdir exists and looks populated."""
    base = (root if root is not None else get_libraries_root())
    return (base / PYTHON_LIB_SUBDIR / _PYTHON_SENTINEL).is_file()


def libraries_ok() -> bool:
    """True when both the C++ and Python libraries resolve and exist."""
    root = get_libraries_root()
    return cpp_library_ok(root) and python_library_ok(root)


def missing_components() -> list[str]:
    """Return a human-readable list of whatever is missing.

    Empty list means the libraries are fully present. Used to build a
    precise error message for the user.
    """
    root = get_libraries_root()
    missing: list[str] = []
    if not root.is_dir():
        return [f"libraries folder does not exist: {root}"]
    if not cpp_library_ok(root):
        missing.append(f"C++ library missing ({CPP_LIB_SUBDIR}/{_CPP_SENTINEL})")
    if not python_library_ok(root):
        missing.append(f"Python library missing ({PYTHON_LIB_SUBDIR}/{_PYTHON_SENTINEL})")
    return missing


def libraries_version() -> str | None:
    """Return the version string from the root ``VERSION`` file, or None.

    The release pipeline writes this file so the installed libraries
    carry the version of the Studio release they shipped with. A dev
    checkout has no ``VERSION`` file and returns None.
    """
    vf = get_libraries_root() / VERSION_FILE
    try:
        text = vf.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    # First non-comment, non-empty line.
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            return line
    return None


def studio_version() -> str | None:
    """Return the running Papaya Studio version, or None if unavailable."""
    try:
        from papaya._version import __version__
        return __version__
    except Exception:
        return None


def version_mismatch() -> str | None:
    """Return a warning message when the libraries and Studio disagree.

    Returns None (i.e. nothing to warn about) when:
      * the libraries carry no ``VERSION`` stamp (a development tree), or
      * the libraries version equals the running Studio version, or
      * either version cannot be determined.

    The release pipeline stamps matching versions into both, so a real
    mismatch means the user updated one without the other.
    """
    lib_v = libraries_version()
    if lib_v is None:
        return None
    studio_v = studio_version()
    if studio_v is None or lib_v == studio_v:
        return None
    return (
        f"The installed Papaya libraries are version {lib_v}, but Papaya "
        f"Studio is version {studio_v}. Update the Papaya Libraries "
        f"package so the two match. Projects generated against "
        f"mismatched libraries may fail to build."
    )


def set_libraries_path(path: Path | str) -> None:
    """Persist a user-chosen libraries root via QSettings.

    Does NOT write the registry; that's the installer's job. Studio's
    in-app Preferences -> Libraries page calls this when the user picks a
    new location after first install.
    """
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
    except ImportError:
        return
    s = QSettings("Shanon Technologies", "Papaya Studio")
    s.setValue("libraries/path", str(path))
    s.sync()


def clear_libraries_path() -> None:
    """Drop the QSettings override so resolution falls back to registry /
    default / dev again. Used by the Preferences "Reset" button."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
    except ImportError:
        return
    s = QSettings("Shanon Technologies", "Papaya Studio")
    s.remove("libraries/path")
    s.sync()


def configured_libraries_path() -> Path | None:
    """Return the explicit user override (QSettings), or None.

    Distinct from :func:`get_libraries_root`, which always returns a
    usable path by falling through to the default / dev location. This
    returns only the value the user (or installer-handoff to Preferences)
    explicitly set, so the Preferences page can show an empty field when
    Studio is running on the default / dev resolution.
    """
    return _from_qsettings()


# ---------------------------------------------------------------------------
# Examples (sample designs)
# ---------------------------------------------------------------------------
#
# The example designs ship as their own package, PapayaExamples-<v>.zip.
# The code generator never reads them, but
# Studio resolves the folder so the Package Manager can report/update it
# and the first-run / Open-Example flows can find it.

_EXAMPLES_DEFAULT_REL_USER = Path("Papaya Studio") / "Examples"
_EXAMPLES_REG_VALUE = "ExamplesPath"
EXAMPLES_MARKER_FILE = ".papaya_examples"


def _examples_from_env() -> Path | None:
    raw = (os.environ.get("PAPAYA_EXAMPLES_PATH") or "").strip()
    if raw:
        return Path(os.path.expandvars(os.path.expanduser(raw)))
    return None


def _examples_from_qsettings() -> Path | None:
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
    except ImportError:
        return None
    raw = QSettings("Shanon Technologies", "Papaya Studio").value(
        "examples/path", "", type=str)
    return Path(raw) if raw else None


def _examples_from_registry() -> Path | None:
    if os.name != "nt":
        return None
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        return None
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(hive, _REG_SUBKEY, 0,
                                 winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                val, _ = winreg.QueryValueEx(k, _EXAMPLES_REG_VALUE)
                if val:
                    return Path(val)
        except OSError:
            continue
    return None


def _examples_from_installer() -> Path | None:
    """The installer-written examples location, whatever the channel."""
    if _app_paths._platform() == "win32":
        return _examples_from_registry()
    return _from_install_conf(_EXAMPLES_REG_VALUE)


def _examples_from_bundle() -> Path | None:
    """Examples shipped inside the application. See :func:`_from_bundle`."""
    for base in _bundle_dirs():
        cand = base / "Examples"
        if cand.is_dir() and any(cand.rglob("*.pap")):
            return cand
    return None


def _examples_dev_fallback() -> Path | None:
    cand = Path(__file__).resolve().parent.parent / "examples"
    return cand if cand.is_dir() else None


def get_examples_root() -> Path:
    """Return the configured (or best-guess) Papaya examples folder."""
    for resolver in (_examples_from_env, _examples_from_qsettings,
                     _examples_from_installer, _examples_from_bundle):
        p = resolver()
        if p is not None:
            return p
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    default = home / _EXAMPLES_DEFAULT_REL_USER
    if default.is_dir():
        return default
    dev = _examples_dev_fallback()
    return dev if dev is not None else default


def examples_ok() -> bool:
    """True when the examples folder exists and holds at least one design."""
    root = get_examples_root()
    return root.is_dir() and any(root.rglob("*.pap"))


def examples_version() -> str | None:
    """Return the version from the examples-folder VERSION file, or None."""
    try:
        text = (get_examples_root() / VERSION_FILE).read_text(encoding="utf-8")
    except OSError:
        return None
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            return line
    return None


def set_examples_path(path: Path | str) -> None:
    """Persist a user-chosen examples folder via QSettings."""
    try:
        from PyQt6.QtCore import QSettings  # type: ignore[import]
    except ImportError:
        return
    s = QSettings("Shanon Technologies", "Papaya Studio")
    s.setValue("examples/path", str(path))
    s.sync()


def libraries_origin() -> str:
    """Human-readable description of which resolution path produced the
    current value. Used by the Preferences page + About dialog so the
    user knows where Studio is reading libraries from."""
    if _from_env() is not None:
        return f"environment variable PAPAYA_LIBRARIES_PATH={os.environ.get('PAPAYA_LIBRARIES_PATH')!r}"
    if _from_qsettings() is not None:
        return "user setting (Preferences -> Libraries)"
    if _from_installer() is not None:
        if _app_paths._platform() == "win32":
            return "installer-written registry value"
        for candidate in _install_conf_paths():
            if _read_install_conf(candidate).get(_REG_VALUE):
                return f"installer-written {candidate}"
        return "installer-written install.conf"
    if _from_bundle() is not None:
        return "libraries bundled inside the application"
    if _default_user_path().is_dir():
        return "default per-user location (Papaya Studio/Libraries)"
    if _dev_fallback() is not None:
        return "dev fallback (Studio repository tree)"
    return "unresolved (no path configured)"


if __name__ == "__main__":
    root = get_libraries_root()
    print(f"Resolved libraries root : {root}")
    print(f"Source                  : {libraries_origin()}")
    print(f"C++ library             : {get_cpp_library_path()}")
    print(f"Python library          : {get_python_library_path()}")
    print(f"Version                 : {libraries_version() or '(none, dev tree)'}")
    miss = missing_components()
    if miss:
        print("MISSING:")
        for m in miss:
            print(f"  - {m}")
    print(f"libraries_ok()          : {libraries_ok()}")
    sys.exit(0 if libraries_ok() else 1)
