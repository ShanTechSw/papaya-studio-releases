"""Carrying the relay engine over a socket.

The engine is pure and the transport is not, so they are separate files.
This one owns the socket and nothing else: it reads bytes, hands whole
frames to the engine, and writes back whatever the engine returns.

One client at a time
--------------------
A second Studio attaching to a board that is already being driven would
interleave two command streams onto one sequence counter, which is the
same desync the board's own arbitration exists to prevent. So a second
connection is **refused with a reason** rather than dropped: a client that
is told why can say so, and a client whose socket simply closes reports a
network fault for a policy decision.

Losing a client mid-command
---------------------------
The engine's flush rule is what makes a disconnect survivable, but only if
someone tells it. A socket that dies is not an event the engine can see,
so this file makes it one: any exit from the serve loop runs the same
flush a clean goodbye would, and the board is left able to answer its next
command instead of waiting forever for the rest of the last one.

The loop has two things to wait for
-----------------------------------
A frame from the client, and the next telemetry poll. So the read's
timeout is whichever of the two comes first rather than a fixed figure: a
loop that always waited half a second would deliver a 20 ms batch stream
in half-second lumps, and one that always waited 20 ms would wake up
constantly on an idle link with nothing subscribed.
"""
from __future__ import annotations

import socket
import threading
import time
from typing import Callable, List, Optional, Tuple

from .gateway import Gateway
from .protocol import (
    FrameDecoder, LinkFrame, MessageType, UnsupportedVersion, encode,
)

#: Enough to keep a telemetry batch moving without a syscall per sample.
_READ_SIZE = 8192

#: How long a blocking read waits before letting the loop check whether it
#: has been asked to stop.
_POLL_TIMEOUT_S = 0.5

#: Floor under the computed read timeout. A poll that is already overdue
#: would otherwise ask for a zero-timeout read every pass, which is a
#: busy loop on the socket rather than a fast one.
_MIN_TIMEOUT_S = 0.001


def serve_connection(sock: socket.socket, gateway: Gateway,
                     should_stop: Optional[Callable[[], bool]] = None) -> None:
    """Relay for one client until it goes away.

    Returns on a clean goodbye, a closed socket, or ``should_stop``. In
    every one of those cases the engine is told, because a half-sent
    command that nobody finishes leaves the board's receive state machine
    waiting forever.
    """
    decoder = FrameDecoder()
    try:
        while not (should_stop and should_stop()):
            sock.settimeout(_read_timeout(gateway, time.monotonic()))
            try:
                chunk = sock.recv(_READ_SIZE)
            except socket.timeout:
                # Nothing to read is not nothing to do: a batch may be due.
                chunk = None
            except OSError:
                return                       # peer vanished; finally flushes
            if chunk == b"":
                return                       # clean close

            if chunk:
                try:
                    frames = decoder.feed(chunk)
                except UnsupportedVersion as exc:
                    _send(sock, LinkFrame(type=MessageType.EVENT,
                                          payload=str(exc).encode("utf-8")))
                    return

                for frame in frames:
                    for reply in gateway.handle(frame):
                        if not _send(sock, reply):
                            return
                    if frame.type is MessageType.BYE:
                        return

            # After the frames, not before: a SUBSCRIBE that arrived in
            # this same read should take effect on this pass rather than
            # waiting a whole timeout for the next one.
            for batch in gateway.poll_telemetry(time.monotonic()):
                if not _send(sock, batch):
                    return
    finally:
        # The engine cannot see a socket die. Tell it, every time.
        gateway.handle(LinkFrame(type=MessageType.BYE))


def _read_timeout(gateway: Gateway, now: float) -> float:
    """How long the loop may block, given what it is waiting for."""
    due = gateway.telemetry_due_in(now)
    if due is None:
        return _POLL_TIMEOUT_S
    return max(_MIN_TIMEOUT_S, min(due, _POLL_TIMEOUT_S))


def _send(sock: socket.socket, frame: LinkFrame) -> bool:
    try:
        sock.sendall(encode(frame))
        return True
    except OSError:
        return False


class LinkServer:
    """Accepts clients for one board, one at a time."""

    def __init__(self, gateway: Gateway, host: str = "0.0.0.0",
                 port: int = 0) -> None:
        self._gateway = gateway
        self._host = host
        self._port = port
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        #: Connections turned away because one was already live. A rising
        #: count usually means a second Studio, which is worth surfacing.
        self.rejected = 0

    @property
    def address(self) -> Optional[Tuple[str, int]]:
        return self._sock.getsockname() if self._sock else None

    def start(self) -> Tuple[str, int]:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((self._host, self._port))
        # Backlog of one, so a second client is refused promptly rather
        # than sitting in a queue believing it is connected.
        sock.listen(1)
        sock.settimeout(_POLL_TIMEOUT_S)
        self._sock = sock

        self._thread = threading.Thread(target=self._accept_loop, daemon=True,
                                        name="papaya-link-server")
        self._thread.start()
        return sock.getsockname()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            self._thread = None
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None

    def _accept_loop(self) -> None:
        while not self._stop.is_set():
            try:
                client, _ = self._sock.accept()
            except (socket.timeout, OSError):
                continue

            # Nagle would hold a small reply waiting for company, which on
            # a request-response link is latency added to every command.
            try:
                client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass

            try:
                serve_connection(client, self._gateway,
                                 should_stop=self._stop.is_set)
            finally:
                try:
                    client.close()
                except OSError:
                    pass


__all__ = ["LinkServer", "serve_connection"]
