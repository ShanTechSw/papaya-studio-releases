var host__arduino__compat_2src_2_s_p_i_8cpp =
[
    [ "SPI", "host__arduino__compat_2src_2_s_p_i_8cpp.html#a56953eb3affc2a9f56e1680bbc537bf7", null ]
];