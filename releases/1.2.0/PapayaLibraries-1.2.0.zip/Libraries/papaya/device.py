from __future__ import annotations

from typing import Optional, Callable, Sequence

import struct
import warnings

from .context import CTX
from .constants import (
    PP_CMD_READ,
    PP_CMD_READ_VECT_PROBE,
    PP_CMD_SWITCH_BACK_TO_CFG,
    PP_CMD_WRITE,
    PP_REAL_SIZE,
    PP_FIXED_SIZE,
    PP_PARAM_INFO_SIZE,
    PP_MAX_INPUTS_NUMBER,
    PP_MAX_PROBES_NUMBER,
    PP_MAX_VECTOR_PROBES_BYTES,
    PP_MAX_VECTOR_PROBES_NUMBER,
    PP_UINT8_SIZE,
    PP_UINT16_SIZE,
    PP_UINT32_SIZE,
    PP_EEP_APP_LABEL_MAX_SIZE,
    PP_VECTOR_PROBE_REQUEST_DELAY_MS,
)
from .enums import (
    PP_C2dAlgo,
    PP_ComStatus,
    PP_DesignStatus,
    PP_FuncId,
    PP_FuncParamId,
    PP_MonInterface,
    PP_MonitorMode,
    PP_SubFuncId,
)
from .auth import NONCE_LEN, fresh_nonce
from .blocks import input, probe, VectorProbe  # noqa: F811


class ProbeRead(int):
    """Outcome of a live scalar-probe read, with the age of the data.

    Subclasses ``int`` so it is a drop-in for the plain ``True``/``False``
    these reads used to return: ``if papaya0.readProbesLive():`` and
    ``== True`` both keep working.  What it adds is the answer to the
    question the boolean could not be asked (*how old is what I just
    read*) because the batches the board pushes queue up on the link and
    a read hands back the oldest of them.

    ``age_batches``
        How many newer batches were discarded to reach this one.  Only a
        draining read (:meth:`PAPAYA.readProbesLatest`) can be non-zero;
        it is how far behind the caller had fallen.
    ``dropped``
        Batches the link lost since the previous read, from the gap in
        the sequence numbers.  Not the same as ``age_batches``: those
        were skipped deliberately, these went missing.
    ``seq``
        The batch's sequence number, or ``None`` on a transport that does
        not carry one.
    ``values``
        The newest sample of every registered probe, in probe order.
    """

    # No ``__slots__``: a variable-length built-in like ``int`` cannot
    # carry one, and the attributes are set in ``__new__``.

    def __new__(cls, ok: bool, *, seq=None, age_batches: int = 0,
                dropped: int = 0, values=None):
        self = super().__new__(cls, 1 if ok else 0)
        self.seq = seq
        self.age_batches = int(age_batches)
        self.dropped = int(dropped)
        self.values = list(values) if values is not None else []
        return self

    def __repr__(self) -> str:  # pragma: no cover - diagnostics only
        if not self:
            return "ProbeRead(failed)"
        return (f"ProbeRead(ok, seq={self.seq}, "
                f"age_batches={self.age_batches}, dropped={self.dropped}, "
                f"values={self.values!r})")


def _note_sampling(started: bool) -> None:
    """Tell the active link whether the board is in data exchange.

    Best-effort and silent: a transport that does not carry the notion
    (SPI, or an application's own adapter) simply does not have the
    methods, and a command must never fail because of bookkeeping.
    """
    transport = getattr(CTX, "usb_transport", None)
    if transport is None:
        return
    method = getattr(transport,
                     "note_sampling_started" if started
                     else "note_sampling_stopped", None)
    if callable(method):
        try:
            method()
        except Exception:                                      # noqa: BLE001
            pass


def _clear_a_diagnostic_refusal(verbose: bool = False) -> None:
    """Forget a refusal that belongs to an optional reading.

    The context refuses to send while a previous command's error is
    still standing, which is right: it stops a script piling commands on
    a board that has already objected. It is wrong for a reading the
    script never asked for and does not depend on, because the refusal
    then kills work that would have succeeded.
    """
    try:
        if CTX.current_design_status != PP_DesignStatus.DesignOk:
            if verbose:
                print(f"[Design Instrumentation] clearing the refusal it "
                      f"left behind ({CTX.current_design_status.name}); it "
                      f"has no bearing on the design.")
            CTX.current_design_status = PP_DesignStatus.DesignOk
        if CTX.current_com_status != PP_ComStatus.ComOk:
            CTX.current_com_status = PP_ComStatus.ComOk
    except Exception:                                      # noqa: BLE001
        pass


class PAPAYA:
    """
    Python PAPAYA host model aligned with the Arduino C++ reference library.

    Configuration commands use the standard header/body + response-request flow.
    Sampling-mode exchanges use the same raw opcodes as the reference SPI host.

    **USB-only**: when the caller has already hooked a USB transport into
    ``CTX`` (via ``connect_usb()``) before constructing this instance, the
    constructor automatically performs the MCU hard-reset + reconnect
    dance that used to be inlined in every generated Python script,
    mirroring the SPI path where the physical reset pin is toggled during
    hardware initialisation.  On SPI (or no transport yet), this is a
    no-op and the caller is responsible for driving the reset pin.
    """

    def __init__(self, Id: int = 0, cs_pin: Optional[int] = None) -> None:
        self.Id = int(Id)
        self.cs = cs_pin
        # Sequence number of the last live batch this instance consumed.
        # ``None`` until the first read, so the first read cannot report a
        # phantom drop from an unrelated starting value.
        self._last_probe_seq: Optional[int] = None
        # Hook for tests / advanced callers who want to skip the
        # auto-hard-reset.  Pass ``CTX.usb_auto_hard_reset = False``
        # before constructing PAPAYA to opt out.
        self.begin(self.Id)
        if CTX.usb_transport is not None and getattr(CTX, "usb_auto_hard_reset", True):
            self._hard_reset_usb()

    # ------------------------------------------------------------------
    # USB hard-reset (USB transport only; SPI ignored)
    # ------------------------------------------------------------------
    def _hard_reset_usb(self) -> None:
        """Drain pending auto-push traffic, fire a USB-level reset
        (the board treats losing the USB connection as an unconditional
        "stop sampling and clear the comm state"), then reconnect.
        Falls back to ``mcuReset`` + re-enumerate if
        the active transport doesn't expose a bus-reset path
        (e.g., the C++ engine path).

        Mirrors the C++ ``PapayaUSB::connect()`` contract so the caller
        gets a clean config-mode board after ``PAPAYA(0)`` returns,
        without having to paste a 13-line reset boilerplate block into
        every generated script.

        Why we prefer ``bus_reset_recover`` over plain ``mcuReset``:
        a software ``mcuReset`` reboots the board's processor but does
        not always tear the USB connection down, so the board's claimed
        configuration interface and its sequence counter can survive the
        reboot.  That residue makes the next ``DesignInit`` come back
        with design status 8, BadRequest, because the counters no longer
        agree.  A real USB-bus reset forces the device to re-enumerate,
        which the board always sees, guaranteeing a clean cfg-mode
        start.

        Not called on SPI (``CTX.usb_transport is None``) -- on that
        path the hardware reset pin is toggled by the physical init
        sequence.
        """
        transport = CTX.usb_transport
        if transport is None:
            return

        import time
        # Local import avoids a circular dependency at module load time
        # (usb_transport.py imports CTX from .context, which is also
        # imported by this module).
        from .usb_transport import connect_usb, disconnect_usb

        # Prefer USB-bus reset (the board sees the disconnect) over
        # plain mcuReset (software-only reboot that can leave USB state).
        # When bus_reset_recover is available we skip force_to_cfg_mode
        # -- the bus reset clears state more thoroughly anyway, and the
        # extra SwitchToCfg bytes can perturb the link timing right
        # before the reset.
        if hasattr(transport, "bus_reset_recover"):
            print("Triggering USB bus reset (the board treats the "
                  "disconnect as stop-sampling and clears all "
                  "cfg-mode state)...")
            try:
                if transport.bus_reset_recover():
                    print("Reconnected, loading design...")
                    return
            except Exception as exc:  # noqa: BLE001
                print(f"  bus_reset_recover raised {type(exc).__name__}: {exc}")
                # Fall through to mcuReset fallback.

        # A LENT LINK OWNS ITS RESET, so ask for it rather than
        # reinventing a weaker one.
        #
        # When the studio lends its arbitrated connection (the Source
        # Editor does this so a debugged program never opens a second
        # handle), that connection's own reset restarts the board by
        # whatever means the route offers AND re-anchors its command
        # counter, which is not an extra but the other half of the
        # operation: a board that has restarted begins numbering at zero
        # and this end does not find out by being told.
        #
        # The bare ``mcuReset`` below does only the first half. Over a
        # cable that survives, because the byte stream carries
        # reset-class commands past the board's sequence check. Over the
        # board's other wire there is no such bypass and a mismatched
        # frame is dropped SILENTLY, so the very next command vanished
        # and the session looked dead on arrival. Measured over a
        # gateway on 2026-08-24: the board really had rebooted -- read
        # back over its debug port it was at sequence zero, idle, not
        # sampling -- while this end still counted from three.
        resetter = getattr(transport, "reset_board", None)
        if callable(resetter):
            try:
                if resetter():
                    # Both ends are counting from zero again, so the
                    # library's own counter has to say so too: it is a
                    # third counter answering to the same board.
                    CTX.reset_command_sequence(clear_transaction_log=False)
                    print("Board reset through the studio's link; "
                          "loading design...")
                    return
                print("  the link's reset reported failure; "
                      "falling back to a command reset")
            except Exception as exc:  # noqa: BLE001
                print(f"  the link's reset raised "
                      f"{type(exc).__name__}: {exc}; falling back")

        # A LENT LINK MUST NOT BE TORN DOWN TO RESET THE BOARD.
        #
        # Everything below ends in ``mcuReset()`` then ``disconnect_usb()``
        # then ``connect_usb()``, which is right when this process owns the
        # device: it can always open it again. Over the Studio's bridge it
        # cannot. The way back in is a ONE-SHOT token that this session has
        # already spent, so the reconnect is refused with "the access token
        # was wrong or already spent" and the program is left with no link
        # at all -- having just rebooted the board out from under the
        # application that lent it.
        #
        # Measured by running an example over a real bridge: bus reset
        # refused (correct), no reset_board on this transport, then the
        # fallback fired and the very next connect_usb() raised. That is
        # what the Source Editor's Execute did to every example that
        # reaches the board.
        #
        # There is nothing to do here instead, and nothing is needed: the
        # Studio resets the board itself before lending the link, which is
        # the "[Reset] Board resetting..." step in its console.
        if not getattr(transport, "reopenable_by_this_process", True):
            print("Board reset left to the application that owns the link; "
                  "this program is using a borrowed connection.")
            return

        print("Forcing board to config mode and draining USB...")
        try:
            if hasattr(transport, "force_to_cfg_mode"):
                transport.force_to_cfg_mode()
        except Exception:
            # Best-effort -- if the drain fails we still try the reset below.
            pass

        # Fallback path -- transport doesn't expose bus_reset_recover
        # (e.g., the C++ engine path) or it returned False.
        print("Triggering hard reset (MCU reboot, fallback path)...")
        # ``mcuReset`` reboots the MCU; the host loses the USB link.  We
        # use this class's own helper so the command formatting is kept
        # in one place.
        self.mcuReset()

        disconnect_usb()
        # Wait 2 s for the MCU to fully reboot before sending the next
        # command with sequence number 0.  This is the only fixed delay
        # anywhere in the USB session -- all the remaining commands
        # (block construction, linking, start/stop design/sampling ...)
        # rely on libusb's native 1000 ms response timeout rather than
        # paying any fixed settle.
        time.sleep(2.0)
        deadline = time.monotonic() + 10.0
        while not connect_usb():
            if time.monotonic() >= deadline:
                raise SystemExit(
                    "Failed to reconnect to PAPAYA board after hard reset (10 s timeout)"
                )
            time.sleep(0.2)
        print("Reconnected, loading design...")

    # ------------------------------------------------------------------
    # Compatibility methods
    # ------------------------------------------------------------------
    def begin(self, Id: int) -> None:
        self.Id = int(Id)

    def end(self) -> None:
        return

    # ------------------------------------------------------------------
    # Design / sampling control (produces DLP config frames)
    # ------------------------------------------------------------------
    def startDesign(self, SamplingFreq: float, Algo: PP_C2dAlgo) -> None:
        CTX.reset_command_sequence(clear_transaction_log=False)
        # A Dataset block works out its own playback rate from this and its
        # recording's length, so neither has to be passed to its constructor.
        CTX.sampling_freq_hz = float(SamplingFreq)

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + 1)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 2, PP_SubFuncId.DesignInit, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(SamplingFreq))
        CTX.prepare_param(cmd, 1, 1, PP_FuncParamId.TYPE_Uint8, int(Algo) & 0xFF)

        CTX.handle_cmd(cmd, serial_size)

    def stopDesign(self) -> None:
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.StopDesign, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def startSampling(self) -> None:
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.StartSampling, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)
        # Enter the data-exchange phase only if the board accepted it,
        # the same rule as the C++ library's startSampling() and as the
        # Studio bridge tracer, which flips its own _data_exchange only
        # on a DesignOk StartSampling response.  The flag is the phase
        # guard of BOTH sequence recoveries (the idle re-anchor in
        # PapayaContext._reanchor_after_config_idle and the one-shot
        # BadRequest retry in _retry_once_after_badrequest), so latching
        # it on a REFUSED StartSampling (the most-reported failure on
        # this link) disarmed both for the rest of the run.
        if (CTX.current_com_status == PP_ComStatus.ComOk
                and CTX.current_design_status == PP_DesignStatus.DesignOk):
            CTX.data_exchange_started = True
            # Tell the link as well as the context. The link is what has
            # to leave the board quiet when this process ends, and it
            # cannot learn this by reading the endpoint: a board whose
            # auto-push has stalled reads exactly like an idle one.
            _note_sampling(True)
        else:
            # SAY SO. This used to return normally on a StartSampling the
            # board never answered, so the generated program went on to
            # print "Board is now sampling", and the failure surfaced
            # much later as "readProbesLatest() requires sampling mode"
            # from whichever read happened to come first. Three
            # statements about one event, two of them untrue, and none of
            # them naming the command that actually failed.
            #
            # Raising here is the same rule the next command would apply
            # anyway: handle_cmd refuses to send while the status is bad.
            # This just refuses at the command that went wrong.
            raise RuntimeError(
                "The board did not start sampling: StartSampling came back "
                f"com={CTX.current_com_status.name}, "
                f"design={CTX.current_design_status.name}. Nothing is "
                "streaming, so no probe can be read. Reset the board and "
                "deploy the design again.")
        # A new session restarts the board's batch numbering, so carrying
        # the previous session's last sequence number over would report a
        # spurious drop on the first read of this one.
        self._last_probe_seq = None

    def getDesignInstrumentation(self, verbose: bool = True) -> Optional[dict]:
        """Measure the design's on-chip CPU + application-memory footprint.

        Issue AFTER all create/link/manage frames are sent but BEFORE
        ``startSampling()``.  The board builds and then tears down its
        own copy of the design, measures how much of its 110 KB fast
        application-memory pool the design's blocks claimed, and times
        five passes of the design's execution with a cycle-accurate
        counter, so the caller never has to interrupt a running design
        to read these numbers.

        Returns the parsed dict on success (USB transport), ``None``
        otherwise.  When ``verbose`` is true, prints a single-line
        summary so scripted-deploy users see the same numbers Papaya
        Studio shows in its monitor-mode dialog.

        Routing
        -------
        * **Studio context**: when Papaya Studio lends its own USB
          handle to the program (so Studio and the program share one
          link), the transport it supplies already knows how to frame and
          decode this command, and we call straight into it.
        * **Standalone generated script**: the active transport is
          ``papaya.usb_transport.PapayaUSBTransport``.  We emit the
          command through ``CTX.handle_cmd`` (which uses send_frame to
          get the 7-byte status) and then read the 32-byte payload
          directly via ``transport.read_data_response``.
        * **No USB transport / SPI**: skipped (the opcode is
          USB-routed only); returns ``None`` without raising so the
          generated script keeps moving toward ``startSampling()``.
        """
        transport = CTX.usb_transport
        if transport is None:
            return None

        info: Optional[dict] = None

        # Path 1: the transport Studio supplies, which decodes for us.
        #
        # WHICHEVER PATH RUNS, ONLY ONE OF THEM SENDS. They are two ways
        # of asking the same question, not a first attempt and a retry,
        # and the board counts every command it is asked. When path one
        # sent the command and then failed to read its answer, path two
        # asked again: the board had already answered, refused the
        # repeat with a state error, and that refusal is sticky, so the
        # program died three commands later with "Cannot send command:
        # DesignStatus=BadRequest".
        #
        # Recorded from a user's session: the first ask succeeded at
        # link sequence 20, its 32-byte read timed out after three
        # seconds, the second ask went out at 21 and was refused, and a
        # DIAGNOSTIC READING took the whole run down with it.
        asked_already = False
        if hasattr(transport, "send_get_design_instrumentation"):
            asked_already = True
            try:
                info = transport.send_get_design_instrumentation()
            except Exception as exc:
                if verbose:
                    print(f"[Design Instrumentation] rich-transport call failed: {exc}")
                info = None
            if info is None:
                # The refusal it may have left behind goes with it: this
                # is a reading, and the design's own commands must not
                # inherit its failure.
                _clear_a_diagnostic_refusal(verbose)
                if verbose:
                    print("[Design Instrumentation] the board was asked and "
                          "did not answer in time; carrying on without it.")
                return None

        # Path 2: standalone PapayaUSBTransport. Emit via CTX and read
        # the 32-byte payload directly off the bulk-IN endpoint.
        #
        # CRITICAL: only send the command if this transport can actually
        # read the board's separate data-response payload. The C++ USB
        # engine path cannot (read_data_response returns None there). If we
        # sent the command anyway, the board's queued 32-byte payload
        # would sit unread in the IN pipe and desync the *next* command's
        # response read, observed as a downstream StartSampling
        # "NO RESPONSE". So skip without sending.
        _can_read = True
        _probe = getattr(transport, "supports_data_response", None)
        if callable(_probe):
            try:
                _can_read = bool(_probe())
            except Exception:
                _can_read = True
        if info is None and not _can_read:
            if verbose:
                print("[Design Instrumentation] skipped: transport cannot "
                      "read data-response payloads")
            return None

        if info is None and hasattr(transport, "read_data_response"):
            try:
                cmd = CTX.prepare_cmd_header(
                    PP_FIXED_SIZE, PP_FuncId.Manageblock, 0,
                    PP_SubFuncId.GetDesignInstrumentation, 0xFFFF,
                )
                CTX.handle_cmd(cmd, PP_FIXED_SIZE)
                if CTX.current_design_status == PP_DesignStatus.DesignOk:
                    raw = transport.read_data_response(32, timeout_ms=3000)
                    if raw is not None and len(raw) >= 32:
                        (cpu_cycle_us, period_us,
                         app_mem_used, app_mem_free, app_mem_total, app_mem_high_watermark,
                         _r1, _r2,
                         cpu_load_pct_x100) = struct.unpack_from('<IIIIIIHHH', raw, 0)
                        app_mem_used_pct = raw[30]
                        cpu_load_pct = cpu_load_pct_x100 / 100.0
                        app_mem_used_pct_float = (
                            (app_mem_used * 100.0 / app_mem_total) if app_mem_total > 0 else 0.0
                        )
                        info = {
                            "cpu_cycle_us":             int(cpu_cycle_us),
                            "period_us":                int(period_us),
                            "cpu_load_pct_x100":        int(cpu_load_pct_x100),
                            "cpu_load_pct":             float(cpu_load_pct),
                            "app_mem_used_bytes":       int(app_mem_used),
                            "app_mem_free_bytes":       int(app_mem_free),
                            "app_mem_total_bytes":      int(app_mem_total),
                            "app_mem_high_watermark":   int(app_mem_high_watermark),
                            "app_mem_used_pct":         int(app_mem_used_pct),
                            "app_mem_used_pct_float":   float(app_mem_used_pct_float),
                        }
            except Exception as exc:
                if verbose:
                    print(f"[Design Instrumentation] standalone-transport call failed: {exc}")
                info = None

        if info is None:
            # A READING NOBODY ASKED FOR MUST NOT END THE RUN.
            #
            # This is a diagnostic: the docstring above promises the
            # script keeps moving toward startSampling whatever it
            # returns. But a refusal here leaves the context's design
            # status set, and the context refuses to send ANYTHING while
            # a previous error is still standing. So a failed CPU-load
            # reading surfaced three commands later as "Cannot send
            # command: DesignStatus=BadRequest" and the program exited
            # saying the board would not build the design, which was
            # neither true nor anything the user could act on.
            #
            # Clearing it is not hiding an error: the command that failed
            # was ours, its failure has been reported here, and no state
            # the caller depends on was changed by it.
            _clear_a_diagnostic_refusal(verbose)
            if verbose:
                print("[Design Instrumentation] not available on this "
                      "transport (skipping)")
            return None

        if verbose:
            mem_total_kb = info["app_mem_total_bytes"] / 1024.0
            mem_used_kb = info["app_mem_used_bytes"] / 1024.0
            cpu_pct = info["cpu_load_pct"]
            mem_pct = info["app_mem_used_pct_float"]
            print(
                f"[Design Instrumentation] "
                f"CPU {cpu_pct:5.1f}% "
                f"(cycle {info['cpu_cycle_us']} us / period {info['period_us']} us)   "
                f"App memory {mem_pct:5.1f}% "
                f"({mem_used_kb:,.1f} / {mem_total_kb:,.1f} KB)"
            )
        return info

    def stopSampling(self) -> None:
        if CTX.data_exchange_started:
            self.switchToCfg()
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.StopSampling, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)
        _note_sampling(False)

    def setMonitoringInterface(self, interf: PP_MonInterface) -> None:
        """Select the board's monitoring transport (USB or SPI).

        The samples-per-probe count is fixed on the board at 128 and is
        no longer host-tunable.
        The dialog's design-settings UI used to expose this value but
        only as a read-only display; the second ``samples_per_probe``
        argument has been removed from the API.
        """
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + 1)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.SetMonInterface, 0xFFFF)
        CTX.prepare_param(cmd, 0, 1, PP_FuncParamId.TYPE_Uint8, int(interf) & 0xFF)
        CTX.handle_cmd(cmd, serial_size)

    def setMonitoringBatchDepth(self, depth: int) -> None:
        """Ask the board to gather ``depth`` samples per probe between
        SPI probe reads (1..128).

        Only meaningful when the monitoring interface is SPI; the board
        refuses it over USB, while sampling is active, and in a capture
        mode other than Live. Send it AFTER ``setMonitoringInterface``
        and BEFORE ``startSampling``: setting the interface resets the
        depth, so the order is part of the contract and every session
        negotiates afresh.

        Acceptance changes what a probe read returns: an 8-byte header
        (u32 batch sequence, u16 valid samples, u16 depth echo) followed
        by ``probes * depth`` float32 samples, probe-major, so a read
        must clock ``8 + probes * depth * 4`` bytes. Without acceptance
        the read keeps today's bare one-sample-per-probe payload. A
        board flashed before this command existed answers with a
        bad-request status and keeps working, which is exactly how a
        host discovers whether the board can batch.
        """
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.SetMonBatchDepth, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(depth) & 0xFFFF)
        CTX.handle_cmd(cmd, serial_size)

    # ------------------------------------------------------------------
    # FreqIn comparator-mode + pin-swap (Session 1)
    # ------------------------------------------------------------------
    def setFreqInCh2Source(self, channel: int, source: int) -> None:
        """Drive the per-channel CH2-source mux on a PAPAYA VL FreqIn input.

        ``channel`` is 0..4 (FreqIn 1..5). ``source`` is 0 for the external
        CN pin (default) or 1 for the on-board comparator output.
        When source==1, the matching analog-output channel must drive
        AN_OUT_<channel+1> to the desired threshold voltage.
        """
        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + 1)
            + (PP_PARAM_INFO_SIZE + 1)
        )
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Manageblock, 2,
            PP_SubFuncId.SetFreqInCh2Source, 0xFFFF,
        )
        CTX.prepare_param(cmd, 0, 1, PP_FuncParamId.TYPE_Uint8,
                          int(channel) & 0xFF)
        CTX.prepare_param(cmd, 1, 1, PP_FuncParamId.TYPE_Uint8,
                          int(source) & 0xFF)
        CTX.handle_cmd(cmd, serial_size)

    def setFreqInSwapPins(self, channel: int) -> None:
        """Exchange the two pins of the given FreqIn channel (0..4).

        Only meaningful for Delay-mode designs whose first rising edge
        arrives on the timer's CH2 input rather than CH1. Must be called
        AFTER the corresponding ``pwmIn(...)`` create.
        """
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + 1)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Manageblock, 1,
            PP_SubFuncId.SetFreqInSwapPins, 0xFFFF,
        )
        CTX.prepare_param(cmd, 0, 1, PP_FuncParamId.TYPE_Uint8,
                          int(channel) & 0xFF)
        CTX.handle_cmd(cmd, serial_size)

    # ------------------------------------------------------------------
    # DWT live tuning (runtime block-param updates over the Manageblock path)
    #
    # These overwrite a live DWT child block's stored knobs; the board
    # re-reads them each frame.  The header BlockId names the TARGET
    # block: the board finds it by id and checks that it really is the
    # matching kind of DWT child, so an id that points somewhere else is
    # safely rejected.  Both frames are ordinary Manageblock config frames
    # (same header/body/response handshake as setMonInterface), NOT the raw
    # sampling-mode opcodes.
    # ------------------------------------------------------------------
    def setDwtSubbandGainsLive(self, block_id: int, gains: Sequence[float]) -> bool:
        """Push new per-subband LINEAR gains to a live dwt_subband_gain block.

        ``gains`` carries one linear multiplier per subband, in the board's
        subband order (``[0]``=approx, ``[1..J]``=detail), length = the
        target block's NumSubbands (= linked DWT levels+1).
        Modelled on the array-carrying create builders (CustFir /
        dwt_subband_gain), so it uses ``use_global_command=False`` to emit
        from a fresh command struct.  Returns True when the send left the
        transport in a good state.
        """
        gains_list = [float(g) for g in gains]
        arr_size = len(gains_list) * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + arr_size)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Manageblock, 1,
            PP_SubFuncId.SetDwtSubbandGains, int(block_id) & 0xFFFF,
            use_global_command=False,
        )
        CTX.prepare_param(cmd, 0, arr_size, PP_FuncParamId.TYPE_RealArray, gains_list)
        CTX.handle_cmd(cmd, serial_size)
        return (CTX.current_com_status == PP_ComStatus.ComOk
                and CTX.current_design_status == PP_DesignStatus.DesignOk)

    def setDwtDenoiseScaleLive(self, block_id: int, scale: float) -> bool:
        """Push a new threshold scale to a live dwt_denoise block.

        ``scale`` is the linear threshold multiplier applied to the
        block's per-subband denoise thresholds.  Returns True when the
        send left the transport in a good state.
        """
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Manageblock, 1,
            PP_SubFuncId.SetDwtDenoiseScale, int(block_id) & 0xFFFF,
        )
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(scale))
        CTX.handle_cmd(cmd, serial_size)
        return (CTX.current_com_status == PP_ComStatus.ComOk
                and CTX.current_design_status == PP_DesignStatus.DesignOk)

    def signalSourceManualTrigger(self, block_id: int) -> bool:
        """Software-fire a live TrigEdge/TrigGate signalSource (no wired trigger).

        Sends the runtime Manageblock ``SignalSourceManualTrigger`` (204 =
        0x00CC) to
        ``block_id`` (the block's on-board wire id). Re-arms the source: it
        restarts its timeline and emits its burst / opens its gate as if a
        hardware trigger edge had arrived. A no-op on the board for a
        non-signal-source id or a non-triggered mode (firmware type-guards on
        CoreFuncId). Returns True when the send left the transport in a good
        state.
        """
        serial_size = PP_FIXED_SIZE
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Manageblock, 0,
            PP_SubFuncId.SignalSourceManualTrigger, int(block_id) & 0xFFFF,
        )
        CTX.handle_cmd(cmd, serial_size)
        return (CTX.current_com_status == PP_ComStatus.ComOk
                and CTX.current_design_status == PP_DesignStatus.DesignOk)

    # ------------------------------------------------------------------
    # Data exchange commands
    #
    # SPI (host-driven / poll):
    #   The master sends a 1-byte opcode (PP_CMD_READ or
    #   PP_CMD_READ_VECT_PROBE) as a separate CS-framed transaction,
    #   then reads the response in a second CS-framed transaction.
    #
    # USB (board-driven / auto-push):
    #   The board autonomously pushes probe and vector-probe data
    #   prefixed with a 1-byte opcode tag.  The host only listens.
    #
    # Inputs (PP_CMD_WRITE) are always host-initiated for both
    # transports: the host sends the opcode + float payload.
    # ------------------------------------------------------------------
    def getDesignInfo(self) -> None:
        """Query monitoring metadata (buffer size, probe/input names).

        The board responds with the standard 7-byte status followed by a
        text payload describing the design.  Over USB that payload is
        read as a separate data response.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.GetDesignInfo, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def readProbes(self) -> None:
        """Request scalar probe data using the raw PP_CMD_READ opcode.

        Mirrors C++ SPI framing: TX opcode in one CS-framed transaction,
        then RX probe floats in a second CS-framed transaction.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("readProbes() requires sampling/data-exchange mode to be active.")
        nbytes = probe.currentProbeIdx * PP_REAL_SIZE if probe.currentProbeIdx > 0 else 0
        CTX.record_sampling_transaction(
            "Sampling.ReadProbes",
            bytes([PP_CMD_READ]),
            frame_name="PP_CMD_READ (opcode)",
            rx_data=bytes(nbytes) if nbytes > 0 else None,
            rx_frame_name="ProbesBuffer",
            notes=[f"Expects {nbytes} byte(s) back ({probe.currentProbeIdx} probe(s) x 4 bytes)."] if nbytes > 0 else [],
        )

    def readVectProbes(self) -> None:
        """Request vector probe data using the raw PP_CMD_READ_VECT_PROBE opcode.

        Mirrors C++ SPI framing: TX opcode, wait PP_VECTOR_PROBE_REQUEST_DELAY_MS (2 ms),
        then RX vector probe bytes in a second CS-framed transaction.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("readVectProbes() requires sampling/data-exchange mode to be active.")
        nbytes = VectorProbe.VectorProbeBytes if VectorProbe.currentVectorProbeIdx > 0 else 0
        CTX.record_sampling_transaction(
            "Sampling.ReadVectProbes",
            bytes([PP_CMD_READ_VECT_PROBE]),
            frame_name="PP_CMD_READ_VECT_PROBE (opcode)",
            rx_data=bytes(nbytes) if nbytes > 0 else None,
            rx_frame_name="VectorProbesBuffer",
            inter_frame_delay_ms=PP_VECTOR_PROBE_REQUEST_DELAY_MS,
            notes=[f"Expects {nbytes} vector-probe byte(s) after {PP_VECTOR_PROBE_REQUEST_DELAY_MS} ms delay."] if nbytes > 0 else [],
        )

    def writeInputs(self) -> None:
        """Send queued input values using the raw PP_CMD_WRITE opcode.

        Mirrors C++ SPI framing: two separate CS-framed transactions,
        one for the opcode byte, one for the float payload.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("writeInputs() requires sampling/data-exchange mode to be active.")
        if 0 < input.currentInputIdx <= PP_MAX_INPUTS_NUMBER:
            nbytes = input.currentInputIdx * PP_REAL_SIZE
            payload = bytes(CTX.inputs_buffer[:nbytes])
            CTX.record_sampling_transaction(
                "Sampling.WriteInputs",
                bytes([PP_CMD_WRITE]),
                frame_name="PP_CMD_WRITE (opcode)",
                rx_data=payload,
                rx_frame_name="InputsBuffer payload",
                notes=[f"Payload size: {nbytes} byte(s) for {input.currentInputIdx} remote input(s)."],
            )

    # ------------------------------------------------------------------
    # Live (sampling-mode) developer API over USB
    #
    # These helpers talk directly to the USB transport without going
    # through the design-time transaction log. Use them from a user
    # script after startSampling() to poll probes and push inputs.
    # ------------------------------------------------------------------
    def readProbesLive(self, timeout_ms: int = 250) -> "ProbeRead":
        """Receive one board-pushed batch and refresh CTX.probes_buffer.

        After the call, ``probe_obj.getVal()`` returns the sample this
        read brought back for every registered scalar probe.

        **This reads the oldest batch that is waiting, not the newest.**
        The board pushes batches at its own cadence; they queue up, and a
        script whose loop is slower than that cadence falls further behind
        on every iteration while every individual read still succeeds.
        The return value now says so: it is truthy exactly as before, so
        ``if papaya0.readProbesLive():`` is unchanged, but it also carries
        ``.age_batches`` (how many newer batches were already waiting
        behind this one), ``.dropped`` (batches the link lost since the
        last read) and ``.seq``.  Use :meth:`readProbesLatest` when only
        the most recent value is of any use (closing a loop in a script,
        for instance, where acting on stale data is a stability hazard).
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("readProbesLive() requires sampling mode.")
        return self._read_probes(timeout_ms, drain=False)

    def readProbesLatest(self, timeout_ms: int = 250) -> "ProbeRead":
        """Discard the queued backlog and refresh from the newest batch.

        Same effect on ``probe_obj.getVal()`` as :meth:`readProbesLive`,
        but the batches that had piled up behind the newest one are
        dropped rather than handed out one per call.  ``.age_batches`` on
        the result is how many were skipped, which is a direct measure of
        how far behind the caller had fallen: zero means it is keeping up.

        This is the read to use in any loop that acts on what it reads.
        It never runs outside sampling mode, so it cannot swallow a
        pending configuration response.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("readProbesLatest() requires sampling mode.")
        return self._read_probes(timeout_ms, drain=True)

    def _read_probes(self, timeout_ms: int, *, drain: bool) -> "ProbeRead":
        """Shared body of the two live scalar reads.

        Keeps the staleness accounting in one place so the draining and
        non-draining reads cannot report it differently.
        """
        transport = CTX.usb_transport
        if transport is None or not getattr(transport, "is_connected", False):
            return ProbeRead(False)
        n = probe.currentProbeIdx
        if n <= 0:
            return ProbeRead(False)

        # The board packs several samples of each probe into every pushed
        # batch; the transport auto-detects the packing and hands back the
        # most recent sample of each, plus the batch's sequence number.
        getter = (getattr(transport, "poll_probe_batch_latest", None) if drain
                  else getattr(transport, "poll_probe_batch", None))
        if getter is None:
            # A transport that predates batch metadata (or a test double
            # that only implements the byte-level call) still works: it
            # just cannot say how old its data is.
            payload = transport.poll_probes(n, timeout_ms)
            if payload is None or len(payload) < n * PP_REAL_SIZE:
                return ProbeRead(False)
            CTX.probes_buffer[: n * PP_REAL_SIZE] = payload[: n * PP_REAL_SIZE]
            return ProbeRead(True, values=self._probe_values(n))

        batch = getter(n, timeout_ms)
        if batch is None or len(batch.values) < n * PP_REAL_SIZE:
            return ProbeRead(False)
        CTX.probes_buffer[: n * PP_REAL_SIZE] = batch.values[: n * PP_REAL_SIZE]

        seq = batch.seq
        dropped = 0
        if seq is not None:
            last = self._last_probe_seq
            if last is not None:
                # A sequence number is a 32-bit counter; the gap is taken
                # modulo that so a wrap reports 0 lost batches rather than
                # four billion.
                gap = (int(seq) - int(last)) & 0xFFFFFFFF
                # ``gap`` counts batches consumed; the ones this read
                # skipped on purpose are not losses.
                dropped = max(0, gap - 1 - int(batch.skipped))
            self._last_probe_seq = int(seq)

        return ProbeRead(True, seq=seq, age_batches=int(batch.skipped),
                         dropped=dropped, values=self._probe_values(n))

    @staticmethod
    def _probe_values(n: int) -> list:
        """Decode the host probe buffer into ``n`` floats."""
        raw = bytes(CTX.probes_buffer[: n * PP_REAL_SIZE])
        return list(struct.unpack_from(f"<{n}f", raw, 0))

    def readProbeLive(self, probe_obj: probe, timeout_ms: int = 250) -> Optional[float]:
        """Convenience: fetch the latest sample for a single probe."""
        if not self.readProbesLive(timeout_ms=timeout_ms):
            return None
        return probe_obj.getVal()

    def readVectProbesLive(self, timeout_ms: int = 250) -> bool:
        """Receive one USB auto-push packet and refresh CTX.vector_probes_buffer.

        Mirrors :meth:`readProbesLive` for vector-probe outputs (FFT/DWT/
        RLS/... blocks linked to a ``VectorProbe``). After a successful
        call, every linked ``vector_probe_obj.getSamples(n)`` returns the
        latest live sample block. Returns True on a successful read,
        False on timeout / wrong opcode / no transport / nothing linked.

        Requires the transport to implement ``poll_vector_probes`` (the
        lightweight :class:`~papaya.usb_transport.PapayaUSBTransport`
        does); on a transport that doesn't, this returns False rather
        than raising, so a script that only reads scalar probes is
        unaffected.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("readVectProbesLive() requires sampling mode.")
        transport = CTX.usb_transport
        if transport is None or not getattr(transport, "is_connected", False):
            return False
        n = VectorProbe.VectorProbeBytes
        if n <= 0:
            return False
        poll = getattr(transport, "poll_vector_probes", None)
        if poll is None:
            return False
        payload = poll(n, timeout_ms)
        if payload is None or len(payload) < n:
            return False
        CTX.vector_probes_buffer[:n] = payload[:n]
        return True

    def readVectProbeLive(self, vector_probe_obj: VectorProbe, num_samples: int,
                          timeout_ms: int = 250) -> Optional[bytes]:
        """Convenience: fetch the latest raw sample block for one vector probe.

        Returns ``num_samples * 4`` raw bytes (little-endian float32) on
        success, or ``None`` on a failed read. ``num_samples`` is usually
        ``vector_probe_obj.dataLines * vector_probe_obj.dataRaw`` (set on
        the object when it was linked).
        """
        if not self.readVectProbesLive(timeout_ms=timeout_ms):
            return None
        return vector_probe_obj.getSamples(num_samples)

    def writeInputsLive(self) -> bool:
        """Send the current CTX.inputs_buffer to the board over USB now.

        Call after one or more ``input_obj.addToQueue(value)`` updates to
        push the new remote-input values to the running design.
        """
        if not CTX.data_exchange_started:
            raise RuntimeError("writeInputsLive() requires sampling mode.")
        transport = CTX.usb_transport
        if transport is None or not getattr(transport, "is_connected", False):
            return False
        n = input.currentInputIdx
        if n <= 0:
            return True
        payload = bytes(CTX.inputs_buffer[: n * PP_REAL_SIZE])
        return bool(transport.send_inputs(payload))

    def setInput(self, input_obj: input, value: float) -> bool:
        """Convenience: queue a new remote-input value and push it over USB."""
        input_obj.addToQueue(float(value))
        return self.writeInputsLive()

    def setInputsLive(self, pairs) -> bool:
        """Queue multiple remote inputs and push them in one USB write.

        ``pairs`` is either a list of ``(input_obj, value)`` tuples or a
        dict ``{input_obj: value}``. All queued values are packed into
        the inputs buffer then pushed in a single PP_CMD_WRITE transfer.
        """
        if isinstance(pairs, dict):
            items = pairs.items()
        else:
            items = pairs
        for inp_obj, value in items:
            if not isinstance(inp_obj, input):
                raise TypeError("setInputsLive expects input objects as keys")
            inp_obj.addToQueue(float(value))
        return self.writeInputsLive()

    def switchToCfg(self) -> None:
        """End data exchange and return to configuration mode."""
        if CTX.data_exchange_started:
            CTX.record_sampling_transaction(
                "Sampling.SwitchToCfg",
                bytes([PP_CMD_SWITCH_BACK_TO_CFG]),
                frame_name="PP_CMD_SWITCH_BACK_TO_CFG",
            )
            # RECORDING IS NOT SENDING. The call above appends to the
            # transaction log and, when auto_print is on, renders the
            # frame; it does not touch the transport. On a lent link the
            # mode change has to actually happen, and it cannot be a bare
            # byte on every route: the board's other wire is one
            # transaction per chip-select and a chip-select in
            # configuration mode must carry a full header, so a lone byte
            # there leaves the board mid-receive rather than changing its
            # mode. The link exposes the shape that works on both routes
            # -- the opcode travels in the header's read/write field and
            # costs no payload bytes -- and mirrors the firmware's
            # counter zeroing only when the switch actually took.
            #
            # Measured over a gateway on 2026-08-24: without this the
            # board never left data exchange, the StopSampling that
            # follows timed out, and every later command timed out with
            # it. A standalone transport has nothing better to reach for
            # and keeps today's behaviour.
            switcher = getattr(CTX.usb_transport, "switch_to_cfg_and_reanchor",
                               None)
            if callable(switcher):
                try:
                    switcher()
                except Exception as exc:  # noqa: BLE001
                    print(f"[USB] the link refused the mode change "
                          f"({type(exc).__name__}: {exc})")
            CTX.data_exchange_started = False
            # The link tracks this too, because it is the link that has to
            # leave the board quiet at the end of the process.
            _note_sampling(False)
            # The board zeroes its sequence counter when it returns from
            # data exchange to configuration on this opcode: BOTH sides
            # reset in lockstep.  The C++ reference library resets here
            # too (PAPAYA.cpp stopSampling).  This
            # Python side did not, so the very next cfg frame (the
            # StopSampling that stopSampling() sends right after) went
            # out with the stale pre-sampling counter and bounced with
            # BadRequest; only a full startDesign rebuild recovered.
            CTX.sequence_number = 0

    # ------------------------------------------------------------------
    # EEPROM application storage commands
    # ------------------------------------------------------------------
    def enableStorage(self, label: str) -> None:
        """Begin recording commands with a label (max 128 chars).

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        label_bytes = label.encode("utf-8")[:PP_EEP_APP_LABEL_MAX_SIZE]
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + len(label_bytes) + 1
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.EnableStorage, 0xFFFF)
        CTX.prepare_param(cmd, 0, len(label_bytes) + 1, PP_FuncParamId.TYPE_String, label)
        CTX.handle_cmd(cmd, serial_size)

    def commitToEeprom(self) -> None:
        """Commit the active recording to the EEPROM directory.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.CommitToEeprom, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def loadApp(self, app_id: int, auto_start: bool = False) -> None:
        """Load and replay a stored application by ID.

        Args:
          app_id     : EEPROM directory id of the app to load.
          auto_start : When ``True``, firmware synthesises ``StartSampling``
                       at the end of replay so the design is actively
                       running by the time this call returns.  Default
                       ``False`` mirrors the original 1-arg behaviour:
                       the design is replayed but stays idle until the
                       caller issues ``startSampling()``.

        Wire shape: 1 or 2 params (uint16 AppId, optional uint8 AutoStart).
        AutoStart defaults to 0 when omitted, so the 2-param form is
        wire-compatible with older firmware that always treated the
        trailing byte as 0.

        Allowed over both USB and SPI: this is the SPI master's primary
        mechanism for switching between stored apps.
        """
        if auto_start:
            serial_size = (
                PP_FIXED_SIZE
                + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 2, PP_SubFuncId.LoadApp, 0xFFFF)
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, app_id)
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  1)
        else:
            serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.LoadApp, 0xFFFF)
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, app_id)
        CTX.handle_cmd(cmd, serial_size)

    def dumpApp(self, app_id: int) -> None:
        """Request stored app data from the board.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.DumpApp, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, app_id)
        CTX.handle_cmd(cmd, serial_size)

    def uploadApp(self, app_id: int, data: bytes) -> None:
        """Upload modified application data to the board.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE + PP_PARAM_INFO_SIZE + len(data)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 2, PP_SubFuncId.UploadApp, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, app_id)
        CTX.prepare_param(cmd, 1, len(data), PP_FuncParamId.TYPE_Uint8Array, data)
        CTX.handle_cmd(cmd, serial_size)

    def listApps(self) -> None:
        """Request the stored application directory from the board."""
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.ListApps, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def deleteApp(self, app_id: int) -> None:
        """Delete a stored application by ID.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.DeleteApp, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, app_id)
        CTX.handle_cmd(cmd, serial_size)

    def syncEeprom(self) -> None:
        """Write the board's in-memory mirror back to non-volatile storage.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.SyncEeprom, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def abortStorage(self) -> None:
        """Discard the in-progress recording without committing.

        Lets the host recover from a half-finished save without resorting
        to softReset() / mcuReset() (which would also tear down any live
        design).  No-op when no recording is active.  Mirrors the C++
        master library's ``papaya.abortStorage()``.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.AbortStorage, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def eraseAll(self) -> None:
        """Wipe the entire EEPROM directory + all stored applications.

        Stops the running design first (firmware does this implicitly)
        and resets the boot config to ``no auto-load``.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.EraseAll, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    # ------------------------------------------------------------------
    # Audio recording slot management (RECORDER / REPLAY storage layer)
    #
    # Wire opcodes 0x2034..0x203B.
    # The board's 8 MB on-board flash holds a single recording slot;
    # recorded audio is little-endian float32 mono, one sample per
    # design tick.
    #
    # Each method routes the same two ways as getDesignInstrumentation():
    #   * Studio context  -> the decoding transport Studio supplies.
    #   * Standalone      -> CTX cfg-frame + transport.read_data_response.
    # ------------------------------------------------------------------
    AUDIO_FMT_F32_MONO = 0
    # A Uint8Array param's length is a 12-bit wire field, so a single
    # segment is capped at 4095 bytes; 4092 is the largest whole-sample
    # (float32) segment. One UploadAudioSlotChunk command packs many
    # segments (firmware reassembles them) -> one USB round-trip per
    # command instead of per 4 KB, so an 8 MB clip is ~146 round-trips.
    _AUDIO_UPLOAD_SEG_BYTES = 4092
    _AUDIO_UPLOAD_CHUNK_BYTES = 14 * 4092   # 57288 B/command (< 64 KB buffer)

    def _audio_read_response(self, size: int, timeout_ms: int = 5000):
        """Read a data-response payload off the bulk-IN endpoint (standalone)."""
        transport = CTX.usb_transport
        if transport is None or not hasattr(transport, "read_data_response"):
            return None
        if CTX.current_design_status != PP_DesignStatus.DesignOk:
            return None
        return transport.read_data_response(size, timeout_ms=timeout_ms)

    @staticmethod
    def _audio_parse_slot_record(raw: bytes, base: int) -> dict:
        # Record byte 1 is a state code: 0 = empty, 1 = occupied,
        # 2 = recording/flushing in progress.
        slot_id = raw[base]
        state   = raw[base + 1]
        fmt = struct.unpack_from("<H", raw, base + 2)[0]
        rate, length, crc, ts = struct.unpack_from("<IIII", raw, base + 4)
        return {
            "slot_id": int(slot_id),
            "state": int(state),
            "occupied": state == 1,
            "busy": state == 2,
            "format": int(fmt),
            "sample_rate_hz": int(rate),
            "length_samples": int(length),
            "crc32": int(crc),
            "timestamp": int(ts),
        }

    def listAudioSlots(self) -> Optional[list]:
        """List every audio recording slot (one dict per slot)."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_list_audio_slots"):
            return transport.send_list_audio_slots()
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0,
                                     PP_SubFuncId.ListAudioSlots, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)
        raw = self._audio_read_response(1 + 20)
        if raw is None or len(raw) < 1:
            return None
        count = raw[0]
        slots = []
        for i in range(count):
            base = 1 + i * 20
            if len(raw) < base + 20:
                return None
            slots.append(self._audio_parse_slot_record(raw, base))
        return slots

    def getAudioSlotInfo(self, slot_id: int = 0) -> Optional[dict]:
        """Return detail for one audio slot, or None on failure."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_get_audio_slot_info"):
            return transport.send_get_audio_slot_info(slot_id)
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1,
                                     PP_SubFuncId.GetAudioSlotInfo, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(slot_id))
        CTX.handle_cmd(cmd, serial_size)
        raw = self._audio_read_response(20)
        if raw is None or len(raw) < 20:
            return None
        # Byte 0 state: 0 = empty, 1 = occupied, 2 = recording/flushing.
        state = raw[0]
        fmt = struct.unpack_from("<H", raw, 2)[0]
        rate, length, crc, ts = struct.unpack_from("<IIII", raw, 4)
        return {
            "state": int(state),
            "occupied": state == 1,
            "busy": state == 2,
            "slot_id": int(raw[1]),
            "format": int(fmt),
            "sample_rate_hz": int(rate),
            "length_samples": int(length),
            "crc32": int(crc),
            "timestamp": int(ts),
        }

    def eraseAudioSlot(self, slot_id: int = 0) -> bool:
        """Erase one audio slot (clears its header so it reads back empty)."""
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_erase_audio_slot"):
            return transport.send_erase_audio_slot(slot_id)
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1,
                                     PP_SubFuncId.EraseAudioSlot, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(slot_id))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    def eraseAllAudioSlots(self) -> bool:
        """Erase every audio slot."""
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_erase_all_audio_slots"):
            return transport.send_erase_all_audio_slots()
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0,
                                     PP_SubFuncId.EraseAllAudioSlots, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    def downloadAudioSlot(self, slot_id: int, offset: int,
                          length: int) -> Optional[bytes]:
        """Download one payload chunk (raw float32 bytes) from an audio slot."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_download_audio_slot"):
            return transport.send_download_audio_slot(slot_id, offset, length)
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 3,
                                     PP_SubFuncId.DownloadAudioSlot, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(offset))
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(length))
        CTX.handle_cmd(cmd, serial_size)
        return self._audio_read_response(length)

    def uploadAudioSlotStart(self, slot_id: int, fmt: int,
                             sample_rate_hz: int, length_samples: int) -> bool:
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_audio_slot_start"):
            return transport.send_upload_audio_slot_start(
                slot_id, fmt, sample_rate_hz, length_samples)
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 4,
                                     PP_SubFuncId.UploadAudioSlotStart, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(fmt))
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(sample_rate_hz))
        CTX.prepare_param(cmd, 3, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(length_samples))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    def uploadAudioSlotChunk(self, slot_id: int, offset: int,
                             data: bytes) -> bool:
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_audio_slot_chunk"):
            return transport.send_upload_audio_slot_chunk(slot_id, offset, data)
        # Split into <=4095-byte wire segments (12-bit param length field)
        # and pack them all into ONE command -> a single USB round-trip.
        seg = self._AUDIO_UPLOAD_SEG_BYTES
        segments = [data[i:i + seg] for i in range(0, len(data), seg)]
        if not segments:
            return True
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        for s in segments:
            serial_size += PP_PARAM_INFO_SIZE + len(s)
        nparams = 2 + len(segments)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, nparams,
                                     PP_SubFuncId.UploadAudioSlotChunk, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(offset))
        for i, s in enumerate(segments):
            CTX.prepare_param(cmd, 2 + i, len(s),
                              PP_FuncParamId.TYPE_Uint8Array, bytes(s))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    def uploadAudioSlotCommit(self, slot_id: int, crc32: int,
                              timestamp_unix: int = 0) -> bool:
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_audio_slot_commit"):
            return transport.send_upload_audio_slot_commit(
                slot_id, crc32, timestamp_unix)
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 3,
                                     PP_SubFuncId.UploadAudioSlotCommit, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(crc32) & 0xFFFFFFFF)
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(timestamp_unix) & 0xFFFFFFFF)
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    def uploadAudioSlot(self, slot_id: int, samples: bytes,
                        sample_rate_hz: int, timestamp_unix: int = 0,
                        fmt: Optional[int] = None) -> bool:
        """High-level upload: Start -> chunked Chunk -> Commit.

        ``samples`` is the raw float32 little-endian PCM payload.
        """
        import zlib
        if fmt is None:
            fmt = self.AUDIO_FMT_F32_MONO
        length_samples = len(samples) // 4
        if length_samples == 0:
            return False
        if not self.uploadAudioSlotStart(slot_id, fmt, sample_rate_hz, length_samples):
            return False
        offset = 0
        step = self._AUDIO_UPLOAD_CHUNK_BYTES
        while offset < len(samples):
            chunk = samples[offset:offset + step]
            if not self.uploadAudioSlotChunk(slot_id, offset, chunk):
                return False
            offset += len(chunk)
        crc = zlib.crc32(samples) & 0xFFFFFFFF
        return self.uploadAudioSlotCommit(slot_id, crc, timestamp_unix)

    def downloadAudioSlotAll(self, slot_id: int,
                             length_samples: int) -> Optional[bytes]:
        """High-level download: pull a slot's whole float32 payload."""
        total = length_samples * 4
        out = bytearray()
        offset = 0
        step = 32768   # well under the board's 64 KB transfer buffer
        while offset < total:
            want = min(step, total - offset)
            chunk = self.downloadAudioSlot(slot_id, offset, want)
            if chunk is None or len(chunk) < want:
                return None
            out.extend(chunk)
            offset += want
        return bytes(out)

    # ------------------------------------------------------------------
    # Dataset storage slots: wire opcodes 0x2040..0x2046.
    # 8 fixed 512 KB slots in the 4-8 MB region of the board's on-board
    # flash; each stores little-endian float32 mono samples behind a
    # 128-byte header.
    #
    # A slot is STORAGE. Nothing plays one. A Signal Source that plays a
    # recording carries the samples itself, in the one command that creates
    # the block (``signalSource.dataset(samples)``), and the board iterates
    # them from its fast heap. These calls are here for a program that wants
    # to manage that flash region directly.
    #
    # Routes the same two ways as the audio-slot methods: a rich Studio
    # transport helper if present, else the standalone CTX cfg-frame path.
    # ------------------------------------------------------------------
    DATASET_FMT_F32_MONO = 0
    DATASET_SLOT_COUNT = 8
    DATASET_MAX_SAMPLES = 114688          # per-slot flash capacity (458752 B / 4)
    _DATASET_UPLOAD_SEG_BYTES = 4092      # 12-bit wire length cap, whole float32
    _DATASET_UPLOAD_CHUNK_BYTES = 14 * 4092   # 57288 B/command (< 64 KB buffer)
    # list/info record size. The record carried a char name[64] and does not
    # any more: a recording is played by a block, and a block has an id.
    _DATASET_RECORD_BYTES = 20

    @staticmethod
    def _dataset_parse_record(raw: bytes, base: int, id_first: bool) -> dict:
        # List layout   (id_first=True):  {u8 slot_id, u8 occupied, ...}
        # Info layout   (id_first=False): {u8 occupied, u8 slot_id, ...}
        # then u16 format, u32 sample_rate_hz, u32 length_samples, u32 crc32,
        # u32 timestamp. 20 bytes, no name.
        if id_first:
            slot_id, occupied = raw[base], raw[base + 1]
        else:
            occupied, slot_id = raw[base], raw[base + 1]
        fmt = struct.unpack_from("<H", raw, base + 2)[0]
        rate, length, crc, ts = struct.unpack_from("<IIII", raw, base + 4)
        return {
            "slot_id": int(slot_id),
            "occupied": occupied == 1,
            "format": int(fmt),
            "sample_rate_hz": int(rate),
            "length_samples": int(length),
            "crc32": int(crc),
            "timestamp": int(ts),
        }

    @staticmethod
    def _dataset_to_bytes(samples) -> bytes:
        """Coerce a float sequence (or raw float32 bytes) to LE float32 bytes."""
        if isinstance(samples, (bytes, bytearray)):
            return bytes(samples)
        return b"".join(struct.pack("<f", float(x)) for x in samples)

    def listDatasets(self) -> Optional[list]:
        """List every dataset slot (one dict per slot)."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_list_datasets"):
            return transport.send_list_datasets()
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0,
                                     PP_SubFuncId.ListDatasets, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)
        raw = self._audio_read_response(
            1 + self.DATASET_SLOT_COUNT * self._DATASET_RECORD_BYTES)
        if raw is None or len(raw) < 1:
            return None
        count = raw[0]
        slots = []
        for i in range(count):
            base = 1 + i * self._DATASET_RECORD_BYTES
            if len(raw) < base + self._DATASET_RECORD_BYTES:
                return None
            slots.append(self._dataset_parse_record(raw, base, id_first=True))
        return slots

    def getDatasetInfo(self, slot_id: int = 0) -> Optional[dict]:
        """Return detail for one dataset slot, or None on failure."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_get_dataset_info"):
            return transport.send_get_dataset_info(slot_id)
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1,
                                     PP_SubFuncId.GetDatasetInfo, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(slot_id))
        CTX.handle_cmd(cmd, serial_size)
        raw = self._audio_read_response(self._DATASET_RECORD_BYTES)
        if raw is None or len(raw) < self._DATASET_RECORD_BYTES:
            return None
        return self._dataset_parse_record(raw, 0, id_first=False)

    def eraseDataset(self, slot_id: int = 0) -> bool:
        """Erase one dataset slot (clears its header so it reads back empty)."""
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_erase_dataset"):
            return transport.send_erase_dataset(slot_id)
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1,
                                     PP_SubFuncId.EraseDataset, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(slot_id))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    # The four upload calls below are static: they build frames out of CTX
    # and touch nothing on the instance. That is what lets
    # signalSource.dataset() put a recording on the board itself, without
    # constructing a PAPAYA to do it -- and constructing one is not a
    # neutral act, because PAPAYA(0) hard-resets the board over USB.
    # ``papaya0.uploadDataset(...)`` still reads and works the same.
    @staticmethod
    def uploadDatasetStart(slot_id: int, fmt: int, sample_rate_hz: int,
                           length_samples: int) -> bool:
        """Open an upload session on ``slot_id``. Four parameters, no name."""
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_dataset_start"):
            return transport.send_upload_dataset_start(
                slot_id, fmt, sample_rate_hz, length_samples)
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 4,
                                     PP_SubFuncId.UploadDatasetStart, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(fmt))
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(sample_rate_hz))
        CTX.prepare_param(cmd, 3, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(length_samples))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    @staticmethod
    def uploadDatasetChunk(slot_id: int, offset: int, data: bytes) -> bool:
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_dataset_chunk"):
            return transport.send_upload_dataset_chunk(slot_id, offset, data)
        seg = PAPAYA._DATASET_UPLOAD_SEG_BYTES
        segments = [data[i:i + seg] for i in range(0, len(data), seg)]
        if not segments:
            return True
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        for s in segments:
            serial_size += PP_PARAM_INFO_SIZE + len(s)
        nparams = 2 + len(segments)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, nparams,
                                     PP_SubFuncId.UploadDatasetChunk, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(offset))
        for i, s in enumerate(segments):
            CTX.prepare_param(cmd, 2 + i, len(s),
                              PP_FuncParamId.TYPE_Uint8Array, bytes(s))
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    @staticmethod
    def uploadDatasetCommit(slot_id: int, crc32: int,
                            timestamp_unix: int = 0) -> bool:
        transport = CTX.usb_transport
        if transport is None:
            return False
        if hasattr(transport, "send_upload_dataset_commit"):
            return transport.send_upload_dataset_commit(
                slot_id, crc32, timestamp_unix)
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 3,
                                     PP_SubFuncId.UploadDatasetCommit, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(crc32) & 0xFFFFFFFF)
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(timestamp_unix) & 0xFFFFFFFF)
        CTX.handle_cmd(cmd, serial_size)
        return CTX.current_design_status == PP_DesignStatus.DesignOk

    @staticmethod
    def uploadDataset(slot_id: int, samples,
                      *, sample_rate_hz: Optional[int] = None,
                      timestamp_unix: int = 0,
                      fmt: Optional[int] = None) -> bool:
        """Put a recording in flash slot ``slot_id``. Start, chunks, Commit.

        Most programs never call this: ``signalSource.dataset(samples)``
        creates a block and puts its recording on the board in one call, and
        that is the form to reach for. This is the slot itself, for a program
        that manages flash directly.

        ``samples`` may be raw LE float32 bytes OR a sequence of floats. The
        CRC-32 is zlib over the exact payload bytes, which is exactly what
        the board recomputes and checks the committed slot against. Rejects
        a payload longer than one slot's flash capacity
        (DATASET_MAX_SAMPLES).

        The rate stamped into the slot header is the design's sampling
        frequency, taken from ``startDesign``. It is not an argument because
        it is not a separate fact: the samples are fed to the graph one per
        tick, so the rate they are played at IS the rate the design runs at.
        ``sample_rate_hz`` overrides it for the one case that differs, a
        recording uploaded for something other than the running design.

        No name is sent, and there is nowhere for one to go: the slot header
        has no name field and the Start frame carries four parameters. A
        recording reaches the board because a block plays it, and that block
        is identified by an id the library assigns. A second name for the
        same thing is one more thing to keep in step, and nothing reads it.
        """
        import zlib
        if fmt is None:
            fmt = PAPAYA.DATASET_FMT_F32_MONO
        if sample_rate_hz is None:
            sample_rate_hz = int(round(float(CTX.sampling_freq_hz or 0.0)))
        if int(sample_rate_hz) <= 0:
            raise ValueError(
                "the design has no sampling frequency yet, so a recording "
                "cannot be stamped with one. Call startDesign() before "
                "uploading, or pass sample_rate_hz= explicitly.")
        if not (0 <= int(slot_id) < PAPAYA.DATASET_SLOT_COUNT):
            return False
        payload = PAPAYA._dataset_to_bytes(samples)
        length_samples = len(payload) // 4
        if length_samples == 0 or length_samples > PAPAYA.DATASET_MAX_SAMPLES:
            return False
        if not PAPAYA.uploadDatasetStart(slot_id, fmt, sample_rate_hz,
                                         length_samples):
            return False
        offset = 0
        step = PAPAYA._DATASET_UPLOAD_CHUNK_BYTES
        while offset < len(payload):
            chunk = payload[offset:offset + step]
            if not PAPAYA.uploadDatasetChunk(slot_id, offset, chunk):
                return False
            offset += len(chunk)
        crc = zlib.crc32(payload) & 0xFFFFFFFF
        if not PAPAYA.uploadDatasetCommit(slot_id, crc, timestamp_unix):
            return False
        # What the slot now holds. A Dataset block plays it once over its
        # natural duration, which is Fs / N traversals a second, so this is
        # half of what signalSource.dataset() needs to derive its own rate.
        CTX.dataset_slot_samples[int(slot_id)] = int(length_samples)
        return True

    def downloadDataset(self, slot_id: int, offset: int,
                        length: int) -> Optional[bytes]:
        """Download one payload chunk (raw float32 bytes) from a dataset slot."""
        transport = CTX.usb_transport
        if transport is None:
            return None
        if hasattr(transport, "send_download_dataset"):
            return transport.send_download_dataset(slot_id, offset, length)
        if hasattr(transport, "drain_in"):
            transport.drain_in()
        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 3,
                                     PP_SubFuncId.DownloadDataset, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  int(slot_id))
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(offset))
        CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(length))
        CTX.handle_cmd(cmd, serial_size)
        return self._audio_read_response(length)

    def downloadDatasetAll(self, slot_id: int,
                           length_samples: int) -> Optional[bytes]:
        """High-level download: pull a dataset slot's whole float32 payload."""
        total = length_samples * 4
        out = bytearray()
        offset = 0
        step = 32768
        while offset < total:
            want = min(step, total - offset)
            chunk = self.downloadDataset(slot_id, offset, want)
            if chunk is None or len(chunk) < want:
                return None
            out.extend(chunk)
            offset += want
        return bytes(out)

    def setBootApp(self, boot_id: int, auto_load: bool = True) -> None:
        """Persist which stored app the firmware auto-loads on power-up.

        Args:
          boot_id   : stored-app directory id of the app to auto-load.
                      Pass ``0xFFFF``, the "no boot app" sentinel, to
                      clear and boot to idle.
          auto_load : ``True`` tells the board to replay the app and start
                      sampling on the next reset.  ``False`` stores the id
                      but skips the auto-load (handy for "set then test
                      manually before locking it in").

        Wire shape: 2 params (uint16 BootAppId, uint8 AutoLoad).
        Follow up with ``syncEeprom()`` if persistence is required: this
        command updates the board's in-memory mirror, and ``syncEeprom``
        is what flushes it to the non-volatile store.

        USB-only: over SPI the board answers design status 8, BadRequest.
        """
        serial_size = (
            PP_FIXED_SIZE
            + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
            + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        )
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 2, PP_SubFuncId.SetBootApp, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(boot_id) & 0xFFFF)
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE,  PP_FuncParamId.TYPE_Uint8,  1 if auto_load else 0)
        CTX.handle_cmd(cmd, serial_size)

    def getBootCfg(self) -> None:
        """Request the persisted boot config from the board.

        The board replies with a 3-byte data response: little-endian
        uint16 BootAppId followed by a uint8 AutoLoad flag.  Decoding is
        left to the transport wrapper (the C++ master's ``getBootCfg``
        overload does it); this method just sends the request.
        Read-only, so SPI masters are allowed.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.GetBootCfg, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    # ------------------------------------------------------------------
    # Offline monitoring (USB-only)
    # ------------------------------------------------------------------
    def SetMonitorMode(self, mode: PP_MonitorMode) -> None:
        """Select live/offline monitoring mode (firmware ``SetMonitorMode``).

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.SetMonitorMode, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(mode) & 0xFF)
        CTX.handle_cmd(cmd, serial_size)

    def SetTraceSize(self, total_samples: int) -> None:
        """Configure the offline trace depth in full-rate samples.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.SetTraceSize, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(total_samples) & 0xFFFFFFFF)
        CTX.handle_cmd(cmd, serial_size)

    def SetLiveRate(self, hz: int) -> None:
        """DEPRECATED: the board always rejects this.

        The firmware's ``SetLiveRate`` case is marked deprecated and
        returns ``BadParam`` unconditionally: samples-per-probe is fixed
        on the board at 128 samples per probe, and the host API that
        used to drive this was removed. Calling it cannot succeed.

        Worse than merely useless: **the board latches a failure** and
        reports it on every subsequent response until something on its
        after-failure whitelist (``startDesign`` / DesignInit) clears it.
        So a call here does not fail in isolation; it breaks whatever
        the caller does next.

        Kept only so existing code does not break on import, and it warns
        rather than failing silently. It is deliberately NOT mirrored in
        the C++ library; the previous claim that it existed there "for
        wire-level parity" is no longer true.
        """
        warnings.warn(
            "SetLiveRate is deprecated: the board rejects it unconditionally "
            "(samples-per-probe is fixed in firmware) and the resulting "
            "failure latches, breaking the next command. Remove the call.",
            DeprecationWarning,
            stacklevel=2,
        )
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.SetLiveRate, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(hz) & 0xFFFFFFFF)
        CTX.handle_cmd(cmd, serial_size)

    def GetCaptureStatus(self) -> None:
        """Query offline capture progress.

        The board replies with a 9-byte data response: u32 captured,
        u32 total, u8 complete.  Decoding the data payload is the transport
        layer's job; this method emits the command frame only.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.GetCaptureStatus, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def DownloadTrace(self, offset: int, length: int) -> None:
        """Download a chunk of the offline trace at ``offset`` / ``length`` bytes.

        The board replies with the standard 7-byte status followed by
        ``length`` bytes of raw trace data, and the transport streams that
        payload.  This method emits the command frame only; read the
        payload with the transport's own data-response read.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
            + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        )
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 2, PP_SubFuncId.DownloadTrace, 0xFFFF)
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(offset) & 0xFFFFFFFF)
        CTX.prepare_param(cmd, 1, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(length) & 0xFFFFFFFF)
        CTX.handle_cmd(cmd, serial_size)

    # ------------------------------------------------------------------
    # Board identity + authentication + descriptor queries (USB-only)
    # ------------------------------------------------------------------
    def GetBoardInfo(self) -> None:
        """Request the board's identity (part number + 96-bit MCU UID).

        The board replies with a 14-byte data response: u16 part number
        followed by the 12 bytes (3 x u32) of its unique device id.  This
        method emits the command frame only; decoding is the transport
        layer's job.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.GetBoardInfo, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def DescribeVectProbes(self) -> None:
        """Request the vector-probe descriptor table.

        The board replies with a 4-byte header (count, proto_version=2,
        max_probes, reserved) followed by ``count`` x 24-byte records
        ``{u16 index, u16 lines, u16 rows, u16 bytes, char label[16]}``.
        Parsing the payload is the transport layer's job.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.DescribeVectProbes, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def Authenticate(self, nonce: Optional[bytes] = None) -> bytes:
        """Run the HMAC-SHA256 challenge-response (firmware ``Authenticate``).

        Builds the wire frame with a 32-byte ``nonce`` as a TYPE_Uint8Array
        param and emits it.  If ``nonce`` is None a cryptographically random
        nonce is generated via :func:`papaya.auth.fresh_nonce`.  Returns the
        nonce so the caller can verify the board's 32-byte HMAC response
        with :func:`papaya.auth.verify_response`; reading the response off
        the wire is the transport layer's job.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        if nonce is None:
            nonce = fresh_nonce()
        nonce = bytes(nonce)
        if len(nonce) != NONCE_LEN:
            raise ValueError(f"Authenticate nonce must be {NONCE_LEN} bytes (got {len(nonce)})")
        serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + NONCE_LEN
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Manageblock, 1, PP_SubFuncId.Authenticate, 0xFFFF)
        CTX.prepare_param(cmd, 0, NONCE_LEN, PP_FuncParamId.TYPE_Uint8Array, nonce)
        CTX.handle_cmd(cmd, serial_size)
        return nonce

    # ------------------------------------------------------------------
    # Debug log ring buffer (USB-only)
    # ------------------------------------------------------------------
    def GetDebugLog(self) -> None:
        """Snapshot the board's 16 KB debug ring buffer.

        The board replies with the standard 7-byte status followed by the
        log contents (oldest-first, ASCII text) up to the ring size.  The
        transport layer streams the payload until a short read.

        Do NOT call while the board is in data-exchange (sampling) mode:
        while sampling, the board routes inbound bytes through its
        data-exchange path, which does not understand this response, and
        the comm state is corrupted.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.GetDebugLog, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def ClearDebugLog(self) -> None:
        """Reset the board's debug ring buffer to empty.

        Reachable from an SPI master too: the board restricts only the
        app-storage *mutations* to the USB interface, and this is not
        one of them.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.ClearDebugLog, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def softReset(self) -> None:
        """Perform a soft reset of the design.

        Stops any running sampling, frees all dynamically allocated
        blocks and the current design, then returns to the idle
        configuration state, ready for a brand-new design.
        Unlike mcuReset() the MCU itself is NOT reset, so the
        SPI / USB connection stays alive.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.SoftReset, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def mcuReset(self) -> None:
        """Perform a destructive MCU reset.

        The board resets its core, clears all RAM, de-initializes all
        peripherals, and reboots from flash.  The USB connection will
        be lost; the host must reconnect after the reset completes.

        Because the MCU reboots before it can acknowledge the frame,
        this is a fire-and-forget command: the host sends the bytes and
        does not poll for a response. This suppresses the spurious
        ``USB write error`` and ``NO RESPONSE (timeout)`` log noise that
        would otherwise appear after every hard reset.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.McuReset, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE, expect_response=False)
        # A rebooted board is not sampling, so the link must stop
        # believing it is: otherwise the end-of-process stop would be
        # sent to a board that has already forgotten the design.
        _note_sampling(False)

    def enterBootloader(self) -> None:
        """Reboot the board into its firmware-update mode.

        The board restarts and stays in update mode so the firmware
        updater can upload a new firmware package, rather than running the
        application.  In update mode it re-enumerates with USB product id
        0x15B4 ("PAPAYA VL Bootloader") rather than the application's
        0x15B3. Studio's regular Connect path filters on 0x15B3 only and
        is therefore deliberately blind to a board in update mode; only
        the firmware updater looks for both product ids.

        Fire-and-forget for the same reason as ``mcuReset``.
        """
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.EnterBootloader, 0xFFFF)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE, expect_response=False)

    # ------------------------------------------------------------------
    # Status / handlers (global in C++ -> global in CTX)
    # ------------------------------------------------------------------
    def setComErrorHandler(self, handler: Optional[Callable[[], None]]) -> None:
        CTX.com_error_handler = handler

    def setDesignErrorHandler(self, handler: Optional[Callable[[], None]]) -> None:
        CTX.design_error_handler = handler

    def GetcurrentDesignStatus(self) -> PP_DesignStatus:
        return CTX.current_design_status

    def GetcurrentComStatus(self) -> PP_ComStatus:
        return CTX.current_com_status

    def getSequenceNumber(self) -> int:
        return CTX.sequence_number
