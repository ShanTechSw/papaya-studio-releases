var classdwt =
[
    [ "dwt", "classdwt.html#a6a52b778af4c0fa206e03362b3940989", null ],
    [ "~dwt", "classdwt.html#a03a31ee38972a54a6b2b68334a3f4a3b", null ],
    [ "getDecompositionLevels", "classdwt.html#acab69bd164047b05f5ac1e8611922c3d", null ],
    [ "getNbSamples", "classdwt.html#af9ebaa139375b66071c58959e274c31e", null ],
    [ "getSamplingRate", "classdwt.html#a2a4693f762d2555dc55c7c1da9a4f496", null ],
    [ "getWaveletType", "classdwt.html#ab547a997bc50bb52d41c13d5910025f9", null ],
    [ "operator>", "classdwt.html#ad525da9364225581594535f4d5badd79", null ],
    [ "operator>", "classdwt.html#a2d037bc3b9472eabb39eb161eb7be1dc", null ],
    [ "operator>", "classdwt.html#ae2b1d75990fb15822746b6f01493e2b0", null ],
    [ "operator>", "classdwt.html#a5c7b301765eca664e41de6bd173e037c", null ],
    [ "decompositionLevels", "classdwt.html#a944763292ee23bdc75f3dbc9ccaeffe3", null ],
    [ "nbSamples", "classdwt.html#ae9bbf2a1f617c256441bddc7e7e02d00", null ],
    [ "samplingRate", "classdwt.html#a660882e69cb479728566b978bf75e138", null ],
    [ "waveletType", "classdwt.html#a2fae60252dc2fbd428a419b73bbc40fb", null ]
];