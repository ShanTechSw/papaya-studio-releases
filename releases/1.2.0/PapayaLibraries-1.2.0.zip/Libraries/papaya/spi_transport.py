"""Reach a PAPAYA board over SPI, for a host that is wired to one.

Why this exists
---------------
This package could only ever reach a board over USB.  That was fine while
the only Python host was a PC with a cable, and it stopped being fine the
moment a Raspberry Pi could sit beside a board and relay it to Studio over
the network: the C++ library has had a Linux SPI port for some time, and
the Python side had nothing at all.

What it is
----------
The same bargain :class:`PapayaStudioBridgeTransport` already strikes.  It
subclasses the USB transport and overrides exactly four methods --
``connect``, ``disconnect``, ``_write`` and ``_read``.  Everything above
those is inherited unchanged: the framing, the response poll, the data
response read, the probe batch decode.  That is deliberate and it is the
whole reason to do it this way.  A second transport that re-implemented
the command layer would get a second chance to disagree with the board,
and the two would drift the first time either was fixed alone.

The transport difference, stated once
-------------------------------------
USB is a byte stream with transfer boundaries: a write is a transfer, a
read is a transfer, and the host does not decide where a frame begins.
**SPI has no boundaries of its own.**  The master frames every exchange by
driving chip-select, so on this transport a ``_write`` is one chip-select
pulse and a ``_read`` is one chip-select pulse.  That mapping is what lets
the inherited command layer work untouched.

Timing
------
The board arms one transfer per chip-select edge, inside the interrupt
handler for that edge, so it needs a guard period before data arrives.
The library's measured floor is above 100 microseconds and its shipped
default is 200; 50 was tried and corrupted command headers.  The same
number is used here, and it is a constructor argument rather than a
constant so a host that has measured its own wiring can say so, but the
default is the one the board is known to tolerate.

The clock is not the constraint.  8 MHz is the library default and 40 MHz
has been verified on real wiring; the guard period dominates either way.

Availability
------------
``spidev`` is a Linux-only package and is imported lazily, so importing
:mod:`papaya` on Windows or macOS costs nothing and fails only if someone
actually asks for an SPI transport there.
"""
from __future__ import annotations

import time
from typing import Optional

from .usb_transport import PapayaUSBTransport

#: Guard period around every chip-select edge, microseconds.  See the
#: module docstring: this is the board's DMA arming window, not a
#: politeness delay, and lowering it corrupts headers rather than merely
#: slowing things down.
DEFAULT_CS_GUARD_US = 200

#: Library default.  Not the limiting factor; the guard period is.
DEFAULT_CLOCK_HZ = 8_000_000

#: Reset line timing, matching the C++ library's own constants.
RESET_ASSERT_MS = 100
BOOT_SETTLE_MS = 3000


class PapayaSpiUnavailable(RuntimeError):
    """Raised when SPI cannot be used on this host, with the reason."""


class PapayaSpiTransport(PapayaUSBTransport):
    """A board on the local SPI bus, framed by chip-select.

    :param bus: spidev bus number.
    :param device: spidev chip-select index.
    :param clock_hz: SCLK rate.  Raising it barely moves throughput,
        because the per-pulse guard dominates.
    :param cs_guard_us: guard period around each chip-select edge.  Lower
        it only against a measurement on your own wiring.
    :param reset_gpio: optional BCM pin number of the board's reset line.
        When given, :meth:`reset_board` can recover a wedged board without
        anyone visiting it, which is the one thing a USB host cannot do.
    """

    def __init__(
        self,
        bus: int = 0,
        device: int = 0,
        *,
        clock_hz: int = DEFAULT_CLOCK_HZ,
        cs_guard_us: int = DEFAULT_CS_GUARD_US,
        reset_gpio: Optional[int] = None,
    ) -> None:
        super().__init__()
        self._bus = int(bus)
        self._device = int(device)
        self._clock_hz = int(clock_hz)
        self._cs_guard_us = int(cs_guard_us)
        self._reset_gpio = reset_gpio
        self._spi = None
        self._gpio = None
        # The inherited command layer checks ``_dev is not None`` in a
        # dozen places to mean "the link is up".  Point it at the spidev
        # handle so every one of those guards keeps working, exactly as
        # the bridge transport points it at its own sentinel.
        self._dev = None

    # -- lifecycle ----------------------------------------------------

    def connect(self) -> bool:
        """Open the bus.  False on failure, never an exception."""
        if self._spi is not None:
            return True
        try:
            import spidev                       # noqa: PLC0415  (Linux only)
        except ImportError as exc:
            raise PapayaSpiUnavailable(
                "spidev is not available. It ships for Linux only, so an SPI "
                "transport cannot be opened on this host. Use the USB "
                "transport, or run this on the machine wired to the board."
            ) from exc

        try:
            spi = spidev.SpiDev()
            spi.open(self._bus, self._device)
            spi.max_speed_hz = self._clock_hz
            spi.mode = 0                        # CPOL 0, CPHA 0
            spi.bits_per_word = 8
            # The board is framed by our chip-select timing, not by the
            # controller's automatic one: spidev would drop CS between
            # words, which is shorter than the board's arming window.
            spi.cshigh = False
        except Exception as exc:                # noqa: BLE001
            raise PapayaSpiUnavailable(
                f"could not open SPI bus {self._bus}.{self._device}: {exc}"
            ) from exc

        self._spi = spi
        self._dev = spi
        return True

    def disconnect(self) -> None:
        """Release the bus.  Safe to call when already released."""
        spi, self._spi, self._dev = self._spi, None, None
        if spi is not None:
            try:
                spi.close()
            except Exception:                   # noqa: BLE001
                pass

    # -- the four methods that differ ---------------------------------

    def _guard(self) -> None:
        if self._cs_guard_us > 0:
            time.sleep(self._cs_guard_us / 1_000_000.0)

    def _write(self, data: bytes, timeout_ms: int = 2000) -> bool:
        """One chip-select pulse carrying ``data``.

        ``timeout_ms`` is accepted for signature compatibility and is not
        used: an SPI transfer is synchronous and either completes or
        raises. There is nothing here to wait on, which is also why an SPI
        host never sees the timeout class of failure a USB host does.
        """
        if self._spi is None:
            return False
        payload = bytes(data)
        if not payload:
            return True
        try:
            self._guard()
            self._spi.writebytes2(payload)
            self._guard()
            return True
        except Exception as exc:                # noqa: BLE001
            print(f"SPI write error: {exc}")
            return False

    def _read(self, size: int, timeout_ms: int) -> Optional[bytes]:
        """One chip-select pulse clocking ``size`` bytes in.

        Returns ``None`` on failure.  It never returns ``None`` for "not
        yet": the master creates the exchange, so there is no idle case to
        distinguish, and the inherited poll loops treat a short answer the
        same way they always did.
        """
        if self._spi is None or size <= 0:
            return None
        try:
            self._guard()
            data = self._spi.readbytes(int(size))
            self._guard()
            return bytes(data)
        except Exception as exc:                # noqa: BLE001
            print(f"SPI read error: {exc}")
            return None

    # -- the capability a cable does not have -------------------------

    def reset_board(self) -> bool:
        """Drive the board's reset line, if this host owns it.

        A USB host can only ask the board to reset, over a protocol, which
        is no help when the board has stopped listening.  A wired host owns
        the line.  That is what turns the one unrecoverable failure state
        into something a remote operator can clear.

        Returns False when no reset pin was configured, so a caller can
        tell "not wired" from "tried and failed".
        """
        if self._reset_gpio is None:
            return False
        try:
            import RPi.GPIO as GPIO             # noqa: PLC0415,N814
        except ImportError:
            return False

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self._reset_gpio, GPIO.OUT)
        GPIO.output(self._reset_gpio, GPIO.LOW)          # assert
        time.sleep(RESET_ASSERT_MS / 1000.0)
        GPIO.output(self._reset_gpio, GPIO.HIGH)         # release
        time.sleep(BOOT_SETTLE_MS / 1000.0)              # let it boot
        return True

    # -- identity -----------------------------------------------------

    def describe(self) -> str:
        return f"SPI {self._bus}.{self._device}"


__all__ = [
    "PapayaSpiTransport",
    "PapayaSpiUnavailable",
    "DEFAULT_CS_GUARD_US",
    "DEFAULT_CLOCK_HZ",
]
