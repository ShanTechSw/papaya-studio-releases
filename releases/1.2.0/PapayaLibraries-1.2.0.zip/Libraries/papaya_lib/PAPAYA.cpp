#include "PAPAYA.h"

#include <cstring>  /* memcpy: the STM32 HAL port does not transitively pull
                       this in the way the Arduino core does. */
#include <cstdlib>  /* atof, for parsing the board's design description.
                       Explicit for the same reason: it happens to arrive
                       transitively on this host and must not be relied on
                       to do so on a bare-metal target. */

/* Util Data ########################################################################################################### */
namespace
{
/* PP_MAX_BOARD_CONTEXTS is defined in PAPAYA.h; a generated project
 * sets it in papaya_target_config.h beside the library. */
static constexpr uint8_t PP_INVALID_CONTEXT_SLOT = 0xFFu;
static constexpr uint16_t PP_VECTOR_PROBE_REQUEST_DELAY_MS = 2u;

/* Sink for the part of a vector-probe frame the buffer cannot hold.
 * Small on purpose: it is a stack frame inside getVectorProbes() on a
 * target chosen for having little RAM, and the only thing it has to do
 * is take bytes off the link so the next read starts on a frame
 * boundary. */
static constexpr uint16_t PP_VECT_PROBE_DRAIN_BYTES = 32u;

/* How long this host may stay command-silent in the CONFIG phase before
 * it must assume the board's config-session idle watchdog fired and the
 * session was released.  The board drops a half-sent configuration after
 * 3000 ms of command silence, so a configuration burst must never stall
 * longer than that; this host mirrors the same bound so it can resync
 * instead of sending into a session that no longer exists.  Overridable
 * with -D if you run a board whose watchdog has been retuned.
 * Deliberately private to this .cpp: it mirrors a board-side bound, it
 * is not host API surface. */
#ifndef PP_HOST_CFG_IDLE_RESYNC_MS
#define PP_HOST_CFG_IDLE_RESYNC_MS 3000u
#endif

struct PapayaSpiTransport 
{
  SPIClass* spi = &SPI;  // default to global SPI
  SPISettings settings = SPISettings(8000000, MSBFIRST, SPI_MODE0);
  uint8_t csPin = PP_CS_PIN;
  uint16_t csDelayUs = PP_DEFAULT_CS_DELAY_US;
  bool callSpiBegin = true;
  PP_TransportTxBytesFn txBytes = nullptr;
  PP_TransportRxBytesFn rxBytes = nullptr;
  PP_TransportHooks hooks = {};
};

static PapayaSpiTransport g_transport;
struct PapayaRuntimeContext
{
  bool initialized = false;
  uint8_t boardId = 0u;
  PapayaSpiTransport transport;
  uint16_t currentSysId = PP_SYS_ID_BASE;
  uint16_t currentNodeId = PP_NODE_ID_BASE;
  uint16_t currentMacroId = PP_MACRO_ID_BASE;
  uint16_t currentInputId = PP_INPUT_ID_BASE;
  uint16_t currentProbeId = PP_PROBE_ID_BASE;
  uint16_t currentVectorProbeId = PP_VECTOR_PROBE_ID_BASE;
  uint8_t currentInputIdx = 0u;
  uint8_t currentProbeIdx = 0u;
  uint8_t currentVectorProbeIdx = 0u;
  uint32_t vectorProbeBytes = 0u;
  uint16_t sequenceNumber = 0u;
  bool dataExchangeStarted = false;
  /* Host-side idle clock for the firmware's config-session watchdog:
   * transportMillis() of this context's last transmitted command frame,
   * and whether one was ever sent (0 ms is a valid stamp, so a separate
   * flag).  ResetRuntimeContext clears both via the default ctor. */
  uint32_t lastCommandTouchMs = 0u;
  bool haveCommandTouch = false;
  PP_DesignStatus designStatus = PP_DesignStatus::DesignOk;
  PP_ComStatus comStatus = PP_ComStatus::ComOk;
  PP_ErrorHandlerType comErrorHandler = NULL;
  PP_ErrorHandlerType designErrorHandler = NULL;
  uint8_t serialData[PP_CMD_BODY_MAX_SIZE] = {0u};
  uint8_t response[PP_RESPONSE_SIZE] = {0u};
  PP_CommandInfo command = {};
  uint8_t inputsBuffer[PP_MAX_INPUTS_NUMBER * PP_REAL_SIZE] = {0u};
  uint8_t probesBuffer[PP_MAX_PROBES_NUMBER * PP_REAL_SIZE] = {0u};
#if PP_MAX_BOARD_CONTEXTS > 1u
  /* Per-context snapshot of the vector-probe buffer. On a single-context
   * build the global VectorProbesBuffer is the sole storage, so this
   * ~72 KB duplicate is omitted entirely. */
  uint8_t vectorProbesBuffer[PP_MAX_VECTOR_PROBES_NUMBER * PP_MAX_VECTOR_PROBES_BYTES] = {0u};
#endif
};

static PapayaRuntimeContext g_contexts[PP_MAX_BOARD_CONTEXTS];
static bool g_contextsReady = false;
static uint8_t g_activeContextSlot = PP_INVALID_CONTEXT_SLOT;
static uint16_t SequenceNumber = 0u;
static bool DataExchangeStarted = false;
/* Active-context twins of PapayaRuntimeContext.lastCommandTouchMs /
 * .haveCommandTouch, swapped by Save/LoadRuntimeContext like every
 * other per-context static above. */
static uint32_t LastCommandTouchMs = 0u;
static bool HaveCommandTouch = false;
static PP_DesignStatus currentDesignStatus = PP_DesignStatus::DesignOk;
static PP_ComStatus currentComStatus = PP_ComStatus::ComOk;
static PP_ErrorHandlerType ComErrorHandler = NULL;
static PP_ErrorHandlerType DesignErrorHandler = NULL;
static uint8_t SerialData[PP_CMD_BODY_MAX_SIZE] = {0u};
static uint8_t Response[PP_RESPONSE_SIZE] = {0u};
static PP_CommandInfo Command = {};
static uint8_t InputsBuffer[PP_MAX_INPUTS_NUMBER * PP_REAL_SIZE] = {0u};
static uint8_t ProbesBuffer[PP_MAX_PROBES_NUMBER * PP_REAL_SIZE] = {0u};
static uint8_t VectorProbesBuffer[PP_MAX_VECTOR_PROBES_NUMBER * PP_MAX_VECTOR_PROBES_BYTES] = {0u};

static void EnsureRuntimeContextsReady();
static void ResetRuntimeContext(PapayaRuntimeContext &ctx, uint8_t boardId);
static bool IsValidContextSlot(uint8_t slot);
static uint8_t GetContextSlotForBoardId(int boardId);
static uint8_t GetActiveContextSlot();
static void SaveActiveRuntimeContext();
static void LoadRuntimeContext(uint8_t slot);
static void SelectBoardLines(uint8_t boardId);
static void ActivateContext(uint8_t slot);
static void BindObjectToActiveContext(uint8_t &slot);
static bool EnsureSameContext(uint8_t lhsSlot, uint8_t rhsSlot);
static void SetDesignError(PP_DesignStatus status);
static bool TryGetCStringPayloadSize(const char *text, uint16_t &payloadSize);
static void transportBegin();
static void transportEnd();
static void transportBeginTransaction();
static void transportEndTransaction();
static void transportTransmitBytes(uint8_t *buffer, uint16_t size);
static void transportReceiveBytes(uint8_t *buffer, uint16_t size);
static void transportPinMode(int pin, int mode);
static void transportDigitalWrite(int pin, int value);
static void transportSelectBoard(uint8_t boardId);
static void transportSetReset(bool asserted);
static void transportDelayMilliseconds(unsigned long delayMs);
static void transportDelayMicroseconds(unsigned int delayUs);
static unsigned long transportMillis();
static bool transportUsesDirectByteCallbacks();

static inline void csSelect() 
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_activeContextSlot != PP_INVALID_CONTEXT_SLOT)
  {
    transportSelectBoard(g_contexts[g_activeContextSlot].boardId);
  }

  if (g_transport.hooks.chipSelect != nullptr)
  {
    g_transport.hooks.chipSelect(g_transport.hooks.context, g_transport.csPin, true, g_transport.csDelayUs);
    return;
  }

  transportDigitalWrite(g_transport.csPin, LOW);
  if (g_transport.csDelayUs)
  {
    transportDelayMicroseconds(g_transport.csDelayUs);
  }
}

static inline void csDeselect() 
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_transport.hooks.chipSelect != nullptr)
  {
    g_transport.hooks.chipSelect(g_transport.hooks.context, g_transport.csPin, false, g_transport.csDelayUs);
    return;
  }

  if (g_transport.csDelayUs)
  {
    transportDelayMicroseconds(g_transport.csDelayUs);
  }

  transportDigitalWrite(g_transport.csPin, HIGH);

  /* Give the slave a real CS-high gap before the next frame starts. */
  if (g_transport.csDelayUs)
  {
    transportDelayMicroseconds(g_transport.csDelayUs);
  }
}

static inline void spiBeginTransaction() 
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_transport.hooks.beginTransaction != nullptr)
  {
    g_transport.hooks.beginTransaction(g_transport.hooks.context, &g_transport.settings);
    return;
  }

#if defined(SPI_HAS_TRANSACTION)
  if (g_transport.spi) g_transport.spi->beginTransaction(g_transport.settings);
#endif
}

static inline void spiEndTransaction() 
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_transport.hooks.endTransaction != nullptr)
  {
    g_transport.hooks.endTransaction(g_transport.hooks.context);
    return;
  }

#if defined(SPI_HAS_TRANSACTION)
  if (g_transport.spi) g_transport.spi->endTransaction();
#endif
}

/* ---- Link framing -------------------------------------------------
 *
 * SPI needs a chip-select assertion and a bus transaction around every
 * frame.  A direct-byte transport -- native USB, bound through
 * PP_TransportTxBytesFn / PP_TransportRxBytesFn, see
 * transportUsesDirectByteCallbacks() below -- frames its own packets
 * and has neither a CS line nor a bus to arbitrate.
 *
 * These two exist so that fact is visible where the frame is sent
 * instead of hidden inside four SPI-named functions that quietly
 * return.  Stepping a native-USB build used to walk through
 * spiBeginTransaction / csSelect / csDeselect / spiEndTransaction on
 * the way to every single transmit, which reads exactly like traffic
 * going out over SPI; here the transport is asked once, in front, and
 * a USB build steps straight from the frame boundary to the byte move.
 *
 * Behaviour is unchanged for SPI and for the hook-based ports: the same
 * four calls run, in the same order, at the same points -- each one
 * re-checks the same condition on entry, so the guard added here is
 * only ever a duplicate of one they already make.
 */
static inline void linkFrameBegin()
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  spiBeginTransaction();
  csSelect();
}

static inline void linkFrameEnd()
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  csDeselect();
  spiEndTransaction();
}

static void transportBegin()
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_transport.callSpiBegin == false)
  {
    return;
  }

  if (g_transport.hooks.begin != nullptr)
  {
    g_transport.hooks.begin(g_transport.hooks.context);
    return;
  }

  if (g_transport.spi != nullptr)
  {
    g_transport.spi->begin();
  }
}

static void transportEnd()
{
  if (transportUsesDirectByteCallbacks())
  {
    return;
  }

  if (g_transport.hooks.end != nullptr)
  {
    g_transport.hooks.end(g_transport.hooks.context);
  }
}

static bool transportUsesDirectByteCallbacks()
{
  return (g_transport.txBytes != nullptr) || (g_transport.rxBytes != nullptr);
}

static void transportTransmitBytes(uint8_t *buffer, uint16_t size)
{
  if ((buffer == NULL) || (size == 0u))
  {
    return;
  }

  if (g_transport.txBytes != nullptr)
  {
    g_transport.txBytes(buffer, size);
    return;
  }

  if (g_transport.hooks.transferByte != nullptr)
  {
    for (uint16_t index = 0u; index < size; ++index)
    {
      (void)g_transport.hooks.transferByte(g_transport.hooks.context, buffer[index]);
    }
    return;
  }

  if (g_transport.hooks.transferBuffer != nullptr)
  {
    static constexpr uint16_t PP_TRANSFER_CHUNK_SIZE = 32u;
    uint8_t scratch[PP_TRANSFER_CHUNK_SIZE];
    uint16_t offset = 0u;

    while (offset < size)
    {
      uint16_t chunkSize = (uint16_t)(size - offset);
      if (chunkSize > PP_TRANSFER_CHUNK_SIZE)
      {
        chunkSize = PP_TRANSFER_CHUNK_SIZE;
      }

      memcpy(scratch, &buffer[offset], chunkSize);
      g_transport.hooks.transferBuffer(g_transport.hooks.context, scratch, chunkSize);
      offset = (uint16_t)(offset + chunkSize);
    }
    return;
  }

  if (g_transport.spi != nullptr)
  {
    for (uint16_t index = 0u; index < size; ++index)
    {
      (void)g_transport.spi->transfer(buffer[index]);
    }
  }
}

static void transportReceiveBytes(uint8_t *buffer, uint16_t size)
{
  if ((buffer == NULL) || (size == 0u))
  {
    return;
  }

  if (g_transport.rxBytes != nullptr)
  {
    g_transport.rxBytes(buffer, size);
    return;
  }

  if (g_transport.hooks.transferByte != nullptr)
  {
    for (uint16_t index = 0u; index < size; ++index)
    {
      buffer[index] = g_transport.hooks.transferByte(g_transport.hooks.context, 0u);
    }
    return;
  }

  if (g_transport.hooks.transferBuffer != nullptr)
  {
    static constexpr uint16_t PP_TRANSFER_CHUNK_SIZE = 32u;
    uint8_t scratch[PP_TRANSFER_CHUNK_SIZE];
    uint16_t offset = 0u;

    while (offset < size)
    {
      uint16_t chunkSize = (uint16_t)(size - offset);
      if (chunkSize > PP_TRANSFER_CHUNK_SIZE)
      {
        chunkSize = PP_TRANSFER_CHUNK_SIZE;
      }

      memset(scratch, 0u, chunkSize);
      g_transport.hooks.transferBuffer(g_transport.hooks.context, scratch, chunkSize);
      memcpy(&buffer[offset], scratch, chunkSize);
      offset = (uint16_t)(offset + chunkSize);
    }
    return;
  }

  if (g_transport.spi != nullptr)
  {
    /* ONE block transfer, not one call per byte.
     *
     * This is the read a gateway does to collect a probe batch, and at
     * depth 128 it is 520 bytes. Byte at a time that was 520 separate
     * SPIClass::transfer() calls, each one a full-duplex exchange that
     * ends by spinning on the busy flag, so the per-call overhead was
     * paid 520 times and it dominated the transfer completely.
     *
     * Two things it cost, and both were measured on the bench:
     *
     * The board REFUSES any batch that completes while this read is in
     * flight and destroys it, advancing its batch sequence number as it
     * does so the loss is visible to the host rather than silent. The
     * width of this read is therefore directly a share of the lost
     * batches: about a third of them over 1100 seconds of streaming.
     * Narrowing the read narrows that window.
     *
     * And the gateway collects and sends from one thread, so every
     * millisecond spent here is a millisecond not available to the next
     * batch's deadline.
     *
     * The block overload is not new and not unproven: the response-request
     * read a few hundred lines below has always used it on this same
     * object. In-place is how it works -- what is sent is what the buffer
     * holds -- so the buffer is zeroed first, which is exactly what the
     * per-byte loop was sending. */
    memset(buffer, 0, size);
    g_transport.spi->transfer(buffer, size);
  }
}

static void transportPinMode(int pin, int mode)
{
  if (g_transport.hooks.pinMode != nullptr)
  {
    g_transport.hooks.pinMode(g_transport.hooks.context, pin, mode);
    return;
  }

  pinMode(pin, mode);
}

static void transportDigitalWrite(int pin, int value)
{
  if (g_transport.hooks.digitalWrite != nullptr)
  {
    g_transport.hooks.digitalWrite(g_transport.hooks.context, pin, value);
    return;
  }

  digitalWrite(pin, value);
}

static void transportSelectBoard(uint8_t boardId)
{
  if (g_transport.hooks.selectBoard != nullptr)
  {
    g_transport.hooks.selectBoard(g_transport.hooks.context, boardId);
    return;
  }

  int selectedId = ~((int)boardId);
  transportDigitalWrite(PP_ID_PIN_2, (selectedId & 0b01) ? HIGH : LOW);
  transportDigitalWrite(PP_ID_PIN_1, (selectedId & 0b10) ? HIGH : LOW);
}

static void transportSetReset(bool asserted)
{
  if (g_transport.hooks.setReset != nullptr)
  {
    g_transport.hooks.setReset(g_transport.hooks.context, asserted);
    return;
  }

  transportDigitalWrite(PP_RESET_PIN, asserted ? HIGH : LOW);
}

static void transportDelayMilliseconds(unsigned long delayMs)
{
  if (g_transport.hooks.delayMs != nullptr)
  {
    g_transport.hooks.delayMs(g_transport.hooks.context, delayMs);
    return;
  }

  delay(delayMs);
}

static void transportDelayMicroseconds(unsigned int delayUs)
{
  if (g_transport.hooks.delayUs != nullptr)
  {
    g_transport.hooks.delayUs(g_transport.hooks.context, delayUs);
    return;
  }

  delayMicroseconds(delayUs);
}

static unsigned long transportMillis()
{
  if (g_transport.hooks.millis != nullptr)
  {
    return g_transport.hooks.millis(g_transport.hooks.context);
  }

  return millis();
}

static void ResetRuntimeContext(PapayaRuntimeContext &ctx, uint8_t boardId)
{
  ctx = PapayaRuntimeContext();
  ctx.initialized = true;
  ctx.boardId = boardId;
}

static void EnsureRuntimeContextsReady()
{
  if (g_contextsReady == false)
  {
    for (uint8_t slot = 0u; slot < PP_MAX_BOARD_CONTEXTS; ++slot)
    {
      ResetRuntimeContext(g_contexts[slot], slot);
    }

    g_contextsReady = true;
  }
}

static bool IsValidContextSlot(uint8_t slot)
{
  return slot < PP_MAX_BOARD_CONTEXTS;
}

static uint8_t GetContextSlotForBoardId(int boardId)
{
  /* Valid PAPAYA board ids are 0..3 (selected by the 2 ID lines). */
  if ((boardId < 0) || (boardId > 3))
  {
    return PP_INVALID_CONTEXT_SLOT;
  }

  /* Single-context build (RAM-constrained target): every board id
   * collapses onto the sole slot 0. The real id still drives the
   * ID-select lines through g_contexts[slot].boardId. */
  if (PP_MAX_BOARD_CONTEXTS == 1u)
  {
    return 0u;
  }

  if (boardId >= (int)PP_MAX_BOARD_CONTEXTS)
  {
    return PP_INVALID_CONTEXT_SLOT;
  }

  return (uint8_t)boardId;
}

static uint8_t GetActiveContextSlot()
{
  return g_activeContextSlot;
}

static void SaveActiveRuntimeContext()
{
  if (IsValidContextSlot(g_activeContextSlot))
  {
    PapayaRuntimeContext &ctx = g_contexts[g_activeContextSlot];

    ctx.transport = g_transport;
    ctx.currentSysId = tf::currentSysId;
    ctx.currentNodeId = node::currentNodeId;
    ctx.currentMacroId = macro::currentMacroId;
    ctx.currentInputId = input::currentInputId;
    ctx.currentProbeId = probe::currentProbeId;
    ctx.currentVectorProbeId = VectorProbe::currentVectorProbeId;
    ctx.currentInputIdx = input::currentInputIdx;
    ctx.currentProbeIdx = probe::currentProbeIdx;
    ctx.currentVectorProbeIdx = VectorProbe::currentVectorProbeIdx;
    ctx.vectorProbeBytes = VectorProbe::VectorProbeBytes;
    ctx.sequenceNumber = SequenceNumber;
    ctx.dataExchangeStarted = DataExchangeStarted;
    ctx.lastCommandTouchMs = LastCommandTouchMs;
    ctx.haveCommandTouch = HaveCommandTouch;
    ctx.designStatus = currentDesignStatus;
    ctx.comStatus = currentComStatus;
    ctx.comErrorHandler = ComErrorHandler;
    ctx.designErrorHandler = DesignErrorHandler;
    memcpy(ctx.serialData, SerialData, sizeof(SerialData));
    memcpy(ctx.response, Response, sizeof(Response));
    ctx.command = Command;
    memcpy(ctx.inputsBuffer, InputsBuffer, sizeof(InputsBuffer));
    memcpy(ctx.probesBuffer, ProbesBuffer, sizeof(ProbesBuffer));
#if PP_MAX_BOARD_CONTEXTS > 1u
    memcpy(ctx.vectorProbesBuffer, VectorProbesBuffer, sizeof(VectorProbesBuffer));
#endif
  }
}

static void LoadRuntimeContext(uint8_t slot)
{
  PapayaRuntimeContext &ctx = g_contexts[slot];

  g_transport = ctx.transport;
  tf::currentSysId = ctx.currentSysId;
  node::currentNodeId = ctx.currentNodeId;
  macro::currentMacroId = ctx.currentMacroId;
  input::currentInputId = ctx.currentInputId;
  probe::currentProbeId = ctx.currentProbeId;
  VectorProbe::currentVectorProbeId = ctx.currentVectorProbeId;
  input::currentInputIdx = ctx.currentInputIdx;
  probe::currentProbeIdx = ctx.currentProbeIdx;
  VectorProbe::currentVectorProbeIdx = ctx.currentVectorProbeIdx;
  VectorProbe::VectorProbeBytes = ctx.vectorProbeBytes;
  SequenceNumber = ctx.sequenceNumber;
  DataExchangeStarted = ctx.dataExchangeStarted;
  LastCommandTouchMs = ctx.lastCommandTouchMs;
  HaveCommandTouch = ctx.haveCommandTouch;
  currentDesignStatus = ctx.designStatus;
  currentComStatus = ctx.comStatus;
  ComErrorHandler = ctx.comErrorHandler;
  DesignErrorHandler = ctx.designErrorHandler;
  memcpy(SerialData, ctx.serialData, sizeof(SerialData));
  memcpy(Response, ctx.response, sizeof(Response));
  Command = ctx.command;
  memcpy(InputsBuffer, ctx.inputsBuffer, sizeof(InputsBuffer));
  memcpy(ProbesBuffer, ctx.probesBuffer, sizeof(ProbesBuffer));
#if PP_MAX_BOARD_CONTEXTS > 1u
  memcpy(VectorProbesBuffer, ctx.vectorProbesBuffer, sizeof(VectorProbesBuffer));
#endif
}

static void SelectBoardLines(uint8_t boardId)
{
  transportSelectBoard(boardId);
}

static void ActivateContext(uint8_t slot)
{
  if (IsValidContextSlot(slot) == false)
  {
    return;
  }

  EnsureRuntimeContextsReady();

  if (g_activeContextSlot != slot)
  {
    SaveActiveRuntimeContext();
    LoadRuntimeContext(slot);
    g_activeContextSlot = slot;
  }

  SelectBoardLines(g_contexts[slot].boardId);
}

static void BindObjectToActiveContext(uint8_t &slot)
{
  slot = GetActiveContextSlot();
  if (IsValidContextSlot(slot))
  {
    ActivateContext(slot);
  }
}

static bool EnsureSameContext(uint8_t lhsSlot, uint8_t rhsSlot)
{
  if ((lhsSlot == rhsSlot) && IsValidContextSlot(lhsSlot))
  {
    ActivateContext(lhsSlot);
    return true;
  }

  if (IsValidContextSlot(lhsSlot))
  {
    ActivateContext(lhsSlot);
    currentDesignStatus = PP_DesignStatus::BadConnection;
    if (DesignErrorHandler != NULL)
    {
      DesignErrorHandler();
    }
  }

  return false;
}

static void SetDesignError(PP_DesignStatus status)
{
  currentDesignStatus = status;
  if (DesignErrorHandler != NULL)
  {
    DesignErrorHandler();
  }
}

static bool TryGetCStringPayloadSize(const char *text, uint16_t &payloadSize)
{
  if (text == nullptr)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return false;
  }

  size_t rawSize = strlen(text) + 1u;
  if (rawSize > PP_PARAM_DESC_MAX_SIZE)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return false;
  }

  payloadSize = (uint16_t)rawSize;
  return true;
}
} // namespace

uint16_t tf::currentSysId = PP_SYS_ID_BASE;
uint16_t node::currentNodeId = PP_NODE_ID_BASE;
uint16_t macro::currentMacroId = PP_MACRO_ID_BASE;
uint16_t input::currentInputId = PP_INPUT_ID_BASE;
uint16_t probe::currentProbeId = PP_PROBE_ID_BASE;
uint16_t VectorProbe::currentVectorProbeId = PP_VECTOR_PROBE_ID_BASE;
uint8_t input::currentInputIdx = 0u;
uint8_t probe::currentProbeIdx = 0u;
uint8_t VectorProbe::currentVectorProbeIdx = 0u;
uint32_t VectorProbe::VectorProbeBytes = 0u;

/* Util Functions ###################################################################################################### */
static void SendCommand(uint8_t *Cmd, uint16_t Size);
static void GetResponse(uint8_t *Cmd, uint8_t *Response);
static bool GetDataResponse(uint8_t *Buffer, uint16_t Size);
static bool SendManageQuery(PP_SubFuncId SubFuncId, uint16_t blockId);
static bool SendManageU32(PP_SubFuncId SubFuncId, uint32_t value,
                          uint16_t paramSize, PP_FuncParamId paramType);
static void CalculateAndsetCrc(uint8_t *Data, uint16_t DataLength);
static uint32_t CalculateCrc(uint8_t *Data, uint16_t DataLength);
static uint32_t CrcUpdateByte(uint32_t crc, uint8_t byte);
static uint32_t ComputeBodyCrc(PP_CommandInfo *Command);
static void SerializeResponseRequest(uint8_t *SerialData, PP_CommandInfo *Command);
static void SerializeCommandBody(uint8_t *Buffer, PP_CommandInfo *Command, uint8_t chunkIdx, uint16_t chunkSize);
static void SerializeHeader(uint8_t *SerialData, PP_CommandInfo *Command);
static void HandleCmd(PP_CommandInfo *Command, uint16_t SerialDataSize);
static void HandleCmdVect(PP_CommandInfo *Command, uint16_t SerialDataSize);
static void PrepareCmdHeader(PP_CommandInfo *Command,
                             uint16_t SerialDataSize,
                             PP_FuncId FuncId,
                             uint8_t NbrOfParams,
                             PP_SubFuncId SubFuncId,
                             uint16_t blockId);
static void PrepareParam(PP_CommandInfo *Command,
                         uint8_t ParamIndex,
                         uint16_t SizeOfParam,
                         PP_FuncParamId FuncParamId,
                         PP_FuncParam *FuncParam);
static void Linkblock2block(uint16_t SrcId, uint8_t OutIdx, uint16_t DstId, uint8_t InIdx, PP_SubFuncId SubFuncId);
static void SerializeResponseRequestVect(uint8_t *SerialData, PP_CommandInfo *Command);
static bool TryDecodeResponseFrame(const uint8_t *WireData, uint8_t *Response);
static void WriteUint16LE(uint8_t *Data, uint16_t Value);
static void WriteUint32LE(uint8_t *Data, uint32_t Value);
static uint16_t ReadUint16LE(const uint8_t *Data);
static uint32_t ReadUint32LE(const uint8_t *Data);

static void WriteUint16LE(uint8_t *Data, uint16_t Value)
{
  if (Data != NULL)
  {
    Data[0u] = (uint8_t)(Value & 0x00FFu);
    Data[1u] = (uint8_t)((Value >> 8u) & 0x00FFu);
  }
}

static void WriteUint32LE(uint8_t *Data, uint32_t Value)
{
  if (Data != NULL)
  {
    Data[0u] = (uint8_t)(Value & 0x000000FFu);
    Data[1u] = (uint8_t)((Value >> 8u) & 0x000000FFu);
    Data[2u] = (uint8_t)((Value >> 16u) & 0x000000FFu);
    Data[3u] = (uint8_t)((Value >> 24u) & 0x000000FFu);
  }
}

static uint16_t ReadUint16LE(const uint8_t *Data)
{
  uint16_t Value = 0u;

  if (Data != NULL)
  {
    Value = (uint16_t)((uint16_t)Data[0u] |
                       ((uint16_t)Data[1u] << 8u));
  }

  return Value;
}

static uint32_t ReadUint32LE(const uint8_t *Data)
{
  uint32_t Value = 0u;

  if (Data != NULL)
  {
    Value = (uint32_t)Data[0u] |
            ((uint32_t)Data[1u] << 8u) |
            ((uint32_t)Data[2u] << 16u) |
            ((uint32_t)Data[3u] << 24u);
  }

  return Value;
}

static void SerializeResponseRequestVect(uint8_t *SerialData, PP_CommandInfo *Command)
{
  if ((SerialData != NULL) && (Command != NULL))
  {
    WriteUint16LE(&SerialData[PP_CMD_SEQ_NUMBER_IDX], Command->TransactionInfo.SeqNbr);
    SerialData[PP_CMD_READ_WRITE_IDX] = PP_CMD_READ_VECT_PROBE;
    WriteUint16LE(&SerialData[PP_CMD_SIZEL_IDX], PP_CMD_RESPONSE_ID);
    CalculateAndsetCrc(SerialData, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE);
  }
}

static void SendCommand(uint8_t *Cmd, uint16_t Size)
{
  if (Cmd != NULL)
  {
    linkFrameBegin();
    transportTransmitBytes(Cmd, Size);
    linkFrameEnd();

    /* FLOOR idle stamp only.  The authoritative stamp for the idle
     * test lives at exchange END (TryDecodeResponseFrame): the
     * firmware also stamps the response-request polls that follow
     * this TX, so a TX-time stamp alone would make the client
     * OVER-measure idle and re-anchor into a session the firmware
     * still holds.  This floor matters only for an exchange that
     * never sees a response: that latches a com error and HandleCmd
     * refuses to transmit afterwards, so it cannot drive a spurious
     * zero onto a live wire. */
    LastCommandTouchMs = (uint32_t)transportMillis();
    HaveCommandTouch = true;
  }
}

/**
 * @brief Read the data payload some commands send AFTER the 7-byte status.
 *
 * A handful of opcodes (GetBoardInfo, GetDesignInfo, GetDebugLog,
 * DownloadTrace, the dataset/audio slot readers, ...) answer with the
 * normal status response and then a separate payload, which the board
 * queues behind that status.
 *
 * Both transports carry it, by different mechanics:
 *  - over USB the board transmits the payload immediately after the
 *    status, so it is simply the next bytes on the IN endpoint;
 *  - over SPI it parks in a @c DataResponsePending state and is sent on
 *    the NEXT chip-select assertion, which is exactly what the CS
 *    framing below performs.
 *
 * Call ONLY after the command's own response arrived with a good status.
 * Reading when nothing is pending desynchronises the link: the bytes
 * meant for the next command's response get consumed here instead.
 *
 * @param Buffer Destination, at least @p Size bytes.
 * @param Size   Exact payload length, known from the command's contract.
 * @return true when the read was attempted, false on a bad argument.
 */
static bool GetDataResponse(uint8_t *Buffer, uint16_t Size)
{
  if ((Buffer == NULL) || (0u == Size))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }

  /* NEVER read a data response while sampling.
   *
   * During sampling the board is pushing probe batches on the same
   * bulk-IN pipe, and a multi-byte data response contends with them.
   * The firmware says so beside its own slot commands ("multi-byte data
   * responses contend with the live monitor push on the bulk-IN pipe;
   * both can wedge the board (observed in the field: a ListDatasets sent
   * mid-monitoring froze streaming and the board)").
   *
   * This was not theoretical: polling getCaptureStatus once per 100 ms
   * during a capture wedged a real board so hard that SwitchToCfg,
   * softReset and even McuReset could not bring it back: it needed a
   * physical replug. Refusing here makes the whole class of mistake
   * unreachable, which is worth more than documenting it, because the
   * natural way to write a capture loop is to poll.
   *
   * Call these in config mode: stopSampling() first, then query.
   *
   * Note what this deliberately does NOT do: set currentDesignStatus.
   * HandleCmd refuses to transmit while that is anything other than
   * DesignOk, so a refusal recorded there would poison every LATER
   * command too: the caller stops sampling, asks again in config mode
   * as instructed, and that call fails as well, with no way to tell why.
   * Returning false is the whole signal; the caller's own state is left
   * exactly as it was. */
  if (true == DataExchangeStarted)
  {
    return false;
  }

  linkFrameBegin();
  if (g_transport.csDelayUs == 0)
  {
    transportDelayMicroseconds(10);
  }

  transportReceiveBytes(Buffer, Size);

  if (g_transport.csDelayUs == 0)
  {
    transportDelayMicroseconds(10);
  }
  linkFrameEnd();

  /* Over SPI this read's chip-select fed the board's idle clock again
   * (the board restarts its config-idle countdown on EVERY chip-select
   * it sees during the configuration phase), so the exchange-end stamp
   * taken at the status decode is no longer the board's latest touch.
   * Re-stamp after the payload read to keep client-idle <= board-idle
   * for data-carrying commands too.  Over USB this read is pure IN
   * traffic that does not restart the board's countdown, so this can
   * only widen the safe (miss-a-release) side. */
  LastCommandTouchMs = (uint32_t)transportMillis();
  HaveCommandTouch = true;

  return true;
}

static void GetResponse(uint8_t *Cmd, uint8_t *Response)
{
  if ((Cmd != NULL) && (Response != NULL))
  {
    uint8_t ResponseRequest[PP_RESPONSE_REQ_SIZE];
    unsigned long startTime = transportMillis();

    while ((transportMillis() - startTime) < PP_RESPONSE_TIMEOUT_MS)
    {
      /* Re-copy the request each iteration because full-duplex SPI
         overwrites the buffer with the received response bytes. */
      memcpy(&ResponseRequest[0u], Cmd, PP_RESPONSE_REQ_SIZE);

      /* Each poll frame both requests the response and samples any
         response already queued by the slave (full-duplex SPI). */
      linkFrameBegin();

      if (transportUsesDirectByteCallbacks())
      {
        /* Transport callbacks handle their own CS framing.
           Use txBytes to send and rxBytes to receive in ONE logical
           transaction.  The transport platform must implement this
           as a single full-duplex SPI transfer. */
        transportTransmitBytes(&ResponseRequest[0u], PP_RESPONSE_REQ_SIZE);
        transportReceiveBytes(&ResponseRequest[0u], PP_RESPONSE_REQ_SIZE);
      }
      else if (g_transport.hooks.transferBuffer != nullptr)
      {
        g_transport.hooks.transferBuffer(g_transport.hooks.context,
                                         &ResponseRequest[0u],
                                         PP_RESPONSE_REQ_SIZE);
      }
      else if (g_transport.hooks.transferByte != nullptr)
      {
        for (uint16_t index = 0u; index < PP_RESPONSE_REQ_SIZE; ++index)
        {
          ResponseRequest[index] =
              g_transport.hooks.transferByte(g_transport.hooks.context,
                                             ResponseRequest[index]);
        }
      }
      else if (g_transport.spi != nullptr)
      {
        /* Default Arduino SPI: full-duplex transfer overwrites the
           request buffer with the received slave response. */
        g_transport.spi->transfer(&ResponseRequest[0u], PP_RESPONSE_REQ_SIZE);
      }

      linkFrameEnd();

      if (TryDecodeResponseFrame(&ResponseRequest[0u], Response))
      {
        return;
      }

      transportDelayMilliseconds(PP_RESPONSE_POLL_INTERVAL_MS);
    }

    currentComStatus = UnknownComError;
  }
  else
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
  }
}

static bool TryDecodeResponseFrame(const uint8_t *WireData, uint8_t *Response)
{
  if ((WireData != NULL) && (Response != NULL))
  {
    memcpy(&Response[0u], WireData, PP_RESPONSE_SIZE);

    if ((SequenceNumber == ReadUint16LE(&Response[PP_RES_SEQ_NUMBER_IDX])) &&
        (CalculateCrc(&Response[0u], PP_RESPONSE_SIZE - PP_CMD_CRC_SIZE) ==
         ReadUint32LE(&Response[PP_RES_CRC_IDX])))
    {
      currentComStatus = ComOk;
      currentDesignStatus = static_cast<PP_DesignStatus>(Response[PP_RES_RESCODE_IDX]);

      /* AUTHORITATIVE idle stamp: the exchange END.  The board feeds
       * its own idle clock on every accepted RX, including the
       * response-request polls this response answers, over both USB and
       * SPI, so its last stamp for this exchange is the last poll it
       * RECEIVED, which is earlier than this decode.  Stamping here
       * keeps client-measured idle <= board-measured idle, the
       * direction PrepareCmdHeader's re-anchor needs to be safe.
       * Deliberately fires for every decoded response, error rescodes
       * included: the board restarted its countdown on that RX too. */
      LastCommandTouchMs = (uint32_t)transportMillis();
      HaveCommandTouch = true;
      return true;
    }
  }

  return false;
}

static uint32_t CalculateCrc(uint8_t *Data, uint16_t DataLength)
{
  uint32_t Crc = 0xFFFFFFFFu;

  for (uint16_t ByteIndex = 0u; ByteIndex < DataLength; ByteIndex++)
  {
    Crc ^= (uint32_t)Data[ByteIndex];

    for (uint8_t BitIndex = 0u; BitIndex < 8u; BitIndex++)
    {
      if ((Crc & 0x00000001u) != 0u)
      {
        Crc = (Crc >> 1u) ^ 0xEDB88320u;
      }
      else
      {
        Crc >>= 1u;
      }
    }
  }

  return Crc ^ 0xFFFFFFFFu;
}

static void CalculateAndsetCrc(uint8_t *Data, uint16_t DataLength)
{
  uint32_t Crc = 0u;
  Crc = CalculateCrc(Data, DataLength);
  WriteUint32LE(&Data[DataLength], Crc);
}

static uint32_t CrcUpdateByte(uint32_t crc, uint8_t byte)
{
  crc ^= (uint32_t)byte;
  for (uint8_t i = 0u; i < 8u; i++)
  {
    crc = ((crc & 1u) != 0u) ? ((crc >> 1u) ^ 0xEDB88320u) : (crc >> 1u);
  }
  return crc;
}

static uint32_t ComputeBodyCrc(PP_CommandInfo *Command)
{
  uint32_t crc = 0xFFFFFFFFu;

  if (Command != NULL)
  {
    for (uint16_t index = 0u; index < Command->FuncInfo.NbrOfParams; index++)
    {
      PP_FuncParamId id = Command->FuncInfo.FuncParamIds[index];
      uint16_t size = Command->FuncInfo.FuncParamSizes[index];
      uint16_t desc = (uint16_t)((((uint16_t)id & PP_PARAM_DESC_MAX_ID) << PP_PARAM_DESC_ID_SHIFT) |
                                 (size & PP_PARAM_DESC_SIZE_MASK));

      crc = CrcUpdateByte(crc, (uint8_t)(desc & 0x00FFu));
      crc = CrcUpdateByte(crc, (uint8_t)((desc >> 8u) & 0x00FFu));

      const uint8_t *dataPtr;
      if ((id == TYPE_String) || (id == TYPE_RealArray) || (id == TYPE_Uint32Array) ||
          (id == TYPE_Uint16Array) || (id == TYPE_Uint8Array))
      {
        void *tmp;
        memcpy(&tmp, (const void *)&Command->FuncInfo.FuncParams[index], sizeof(tmp));
        dataPtr = (const uint8_t *)tmp;
      }
      else
      {
        dataPtr = (const uint8_t *)&Command->FuncInfo.FuncParams[index];
      }

      for (uint16_t b = 0u; b < size; b++)
      {
        crc = CrcUpdateByte(crc, dataPtr[b]);
      }
    }
  }

  return crc ^ 0xFFFFFFFFu;
}

static void SerializeResponseRequest(uint8_t *SerialData, PP_CommandInfo *Command)
{
  if ((SerialData != NULL) && (Command != NULL))
  {
    WriteUint16LE(&SerialData[PP_CMD_SEQ_NUMBER_IDX], Command->TransactionInfo.SeqNbr);
    SerialData[PP_CMD_READ_WRITE_IDX] = PP_CMD_READ;
    WriteUint16LE(&SerialData[PP_CMD_SIZEL_IDX], PP_CMD_RESPONSE_ID);
    CalculateAndsetCrc(SerialData, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE);
  }
}

static void SerializeCommandBody(uint8_t *Buffer, PP_CommandInfo *Command, uint8_t chunkIdx, uint16_t chunkSize)
{
  if ((Buffer != NULL) && (Command != NULL))
  {
    uint32_t bodyCrc = ComputeBodyCrc(Command);
    uint32_t streamPos = 0u;
    uint16_t bufIdx = 0u;
    uint32_t chunkStart = (uint32_t)chunkIdx * PP_CMD_CHUNK_SIZE;

    for (uint16_t index = 0u; index < Command->FuncInfo.NbrOfParams; index++)
    {
      PP_FuncParamId id = Command->FuncInfo.FuncParamIds[index];
      uint16_t size = Command->FuncInfo.FuncParamSizes[index];
      uint16_t desc = (uint16_t)((((uint16_t)id & PP_PARAM_DESC_MAX_ID) << PP_PARAM_DESC_ID_SHIFT) |
                                 (size & PP_PARAM_DESC_SIZE_MASK));
      uint8_t desc_bytes[2u] = {(uint8_t)(desc & 0x00FFu), (uint8_t)((desc >> 8u) & 0x00FFu)};

      /* Descriptor (2 bytes, LE) */
      for (uint8_t b = 0u; b < 2u; b++, streamPos++)
      {
        if ((streamPos >= chunkStart) && (bufIdx < chunkSize))
        {
          Buffer[bufIdx++] = desc_bytes[b];
        }
      }

      /* Param data */
      const uint8_t *dataPtr;
      if ((id == TYPE_String) || (id == TYPE_RealArray) || (id == TYPE_Uint32Array) ||
          (id == TYPE_Uint16Array) || (id == TYPE_Uint8Array))
      {
        void *tmp;
        memcpy(&tmp, (const void *)&Command->FuncInfo.FuncParams[index], sizeof(tmp));
        dataPtr = (const uint8_t *)tmp;
      }
      else
      {
        dataPtr = (const uint8_t *)&Command->FuncInfo.FuncParams[index];
      }

      for (uint16_t b = 0u; b < size; b++, streamPos++)
      {
        if ((streamPos >= chunkStart) && (bufIdx < chunkSize))
        {
          Buffer[bufIdx++] = dataPtr[b];
        }
      }
    }

    /* CRC (4 bytes, LE) appended at end of body stream */
    uint8_t crc_bytes[4u] = {
      (uint8_t)(bodyCrc & 0x000000FFu),
      (uint8_t)((bodyCrc >> 8u) & 0x000000FFu),
      (uint8_t)((bodyCrc >> 16u) & 0x000000FFu),
      (uint8_t)((bodyCrc >> 24u) & 0x000000FFu)
    };
    for (uint8_t b = 0u; b < 4u; b++, streamPos++)
    {
      if ((streamPos >= chunkStart) && (bufIdx < chunkSize))
      {
        Buffer[bufIdx++] = crc_bytes[b];
      }
    }
  }
}

static void SerializeHeader(uint8_t *SerialData, PP_CommandInfo *Command)
{
  if ((SerialData != NULL) && (Command != NULL))
  {
    WriteUint16LE(&SerialData[PP_CMD_SEQ_NUMBER_IDX], Command->TransactionInfo.SeqNbr);
    SerialData[PP_CMD_READ_WRITE_IDX] = PP_CMD_WRITE;
    WriteUint16LE(&SerialData[PP_CMD_SIZEL_IDX], Command->FuncInfo.DataSize);
    WriteUint16LE(&SerialData[PP_CMD_blockIDL_IDX], Command->FuncInfo.blockId);
    SerialData[PP_CMD_FUNC_ID_IDX] = (uint8_t)(Command->FuncInfo.FuncId);
    WriteUint16LE(&SerialData[PP_CMD_SUB_FUNC_IDL_IDX], (uint16_t)Command->FuncInfo.SubFuncId);
    SerialData[PP_CMD_NBR_OF_PARAMS_IDX] = Command->FuncInfo.NbrOfParams;
    SerialData[PP_CMD_NBR_OF_CHUNKS_IDX] = Command->FuncInfo.NbrOfChunks;
    WriteUint16LE(&SerialData[PP_CMD_LAST_CHUNK_SIZEL_IDX], Command->FuncInfo.LastChunkSize);
    CalculateAndsetCrc(SerialData, PP_CMD_HEADER_SIZE - PP_CMD_CRC_SIZE);
  }
}

static void HandleCmd(PP_CommandInfo *Command, uint16_t SerialDataSize)
{
  if (SerialDataSize <= PP_CMD_BODY_HARD_MAX_SIZE)
  {
    if ((PP_ComStatus::ComOk == currentComStatus) &&
        (PP_DesignStatus::DesignOk == currentDesignStatus))
    {
      /* Compute chunk metadata */
      uint8_t nbrOfChunks;
      uint16_t lastChunkSize;

      if (SerialDataSize <= PP_CMD_CHUNK_SIZE)
      {
        nbrOfChunks = 1u;
        lastChunkSize = SerialDataSize;
      }
      else
      {
        nbrOfChunks = (uint8_t)((SerialDataSize + PP_CMD_CHUNK_SIZE - 1u) / PP_CMD_CHUNK_SIZE);
        lastChunkSize = SerialDataSize - (uint16_t)(nbrOfChunks - 1u) * PP_CMD_CHUNK_SIZE;
      }

      Command->FuncInfo.NbrOfChunks = nbrOfChunks;
      Command->FuncInfo.LastChunkSize = lastChunkSize;

      /* Send a Write Request Command With the Header */
      SerializeHeader(&SerialData[0u], Command);
      SendCommand(&SerialData[0u], PP_CMD_HEADER_SIZE);

      /* Serialize and send each body chunk directly from the command structure */
      for (uint8_t i = 0u; i < nbrOfChunks; i++)
      {
        uint16_t sz = (i == (nbrOfChunks - 1u)) ? lastChunkSize : PP_CMD_CHUNK_SIZE;
        SerializeCommandBody(&SerialData[0u], Command, i, sz);
        SendCommand(&SerialData[0u], sz);
      }

      /* Poll for the response until it becomes available or times out */
      SerializeResponseRequest(&SerialData[0u], Command);
      GetResponse(SerialData, Response);

      /* One-shot BadRequest recovery, the complement of the time-based
       * idle re-anchor in PrepareCmdHeader, closing the two windows that
       * rule is structurally blind to:
       *
       *  1. The skew band.  The board's idle clock restarts on the last
       *     inbound packet it ACCEPTED, which is EARLIER than this
       *     client's exchange-end stamp, so board-idle >= host-idle
       *     always.  In the band between the two the board released the
       *     configuration session and zeroed its sequence counter while
       *     the host measured under 3000 ms and kept its own.
       *  2. A mid-exchange pause.  A debugger break between the command
       *     TX and the response read (a breakpoint inside
       *     papayaDesignInit() does exactly this) runs the board's clock
       *     the whole time, yet on resume the exchange completes and the
       *     host's exchange-end gap reads ~0, invisible to ANY
       *     host-side idle measurement by construction.
       *
       * Both windows end the same way: the next command carries a stale
       * sequence number, the board refuses it, and the reply carries
       * design status 8, PP_DesignStatus::BadRequest.  Retrying that
       * command ONCE, re-stamped with sequence 0, is deterministic
       * because the board's counter is provably exactly 0 by the time
       * that reply is decoded:
       *  - the rejected packet's own arrival re-claimed the released
       *    configuration session and ZEROED the board's counter;
       *  - a refusal response does not advance the board's counter, so
       *    it is still 0 afterwards.
       * So a retry stamped 0 either succeeds (it was a desync) or fails
       * identically (the command was genuinely bad), with no counter
       * movement either way.  A second BadRequest therefore IS a real
       * error: it falls through to the unchanged handling below and
       * latches currentDesignStatus exactly as before: one straight-line
       * retry, never a loop, no budget that can compound.
       *
       * Config phase only: once data exchange is running the board's
       * config-idle watchdog stops running, the session is legitimately
       * held, and a BadRequest means something else: surface it
       * untouched. */
      if ((false == DataExchangeStarted) &&
          (PP_ComStatus::ComOk == currentComStatus) &&
          (PP_DesignStatus::BadRequest == currentDesignStatus))
      {
        SequenceNumber = 0u;
        Command->TransactionInfo.SeqNbr = SequenceNumber;
        /* Clear the latch for the retry's own transmission only; a
         * second BadRequest re-latches it in the block below. */
        currentDesignStatus = PP_DesignStatus::DesignOk;

        SerializeHeader(&SerialData[0u], Command);
        SendCommand(&SerialData[0u], PP_CMD_HEADER_SIZE);

        for (uint8_t i = 0u; i < nbrOfChunks; i++)
        {
          uint16_t sz = (i == (nbrOfChunks - 1u)) ? lastChunkSize : PP_CMD_CHUNK_SIZE;
          SerializeCommandBody(&SerialData[0u], Command, i, sz);
          SendCommand(&SerialData[0u], sz);
        }

        SerializeResponseRequest(&SerialData[0u], Command);
        GetResponse(SerialData, Response);
      }

      bool com_error = false;
      bool design_error = false;

      if (currentComStatus != PP_ComStatus::ComOk)
      {
        com_error = true;
      }

      if (currentDesignStatus != PP_DesignStatus::DesignOk)
      {
        design_error = true;
      }

      if ((true == com_error) && (ComErrorHandler != NULL))
      {
        ComErrorHandler();
      }

      if ((true == design_error) && (DesignErrorHandler != NULL))
      {
        DesignErrorHandler();
      }

      /* The board advances its own sequence counter after ANY response
       * it transmits, including one carrying a design failure status.
       * Advancing only on full success left the host one behind after
       * the first failed command, so even the small set of commands the
       * board still accepts after a failure (StopSampling,
       * GetDesignInfo, ...) became unreachable.  Advance whenever a
       * response arrived; only a com error (no response) keeps the
       * counter, since the board may never have processed the frame. */
      if (false == com_error)
      {
        SequenceNumber++;
      }
    }
  }
  else
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
  }
}

static void HandleCmdVect(PP_CommandInfo *Command, uint16_t SerialDataSize)
{
  if (SerialDataSize <= PP_CMD_BODY_HARD_MAX_SIZE)
  {
    if ((PP_ComStatus::ComOk == currentComStatus) &&
        (PP_DesignStatus::DesignOk == currentDesignStatus))
    {
      /* Compute chunk metadata */
      uint8_t nbrOfChunks;
      uint16_t lastChunkSize;

      if (SerialDataSize <= PP_CMD_CHUNK_SIZE)
      {
        nbrOfChunks = 1u;
        lastChunkSize = SerialDataSize;
      }
      else
      {
        nbrOfChunks = (uint8_t)((SerialDataSize + PP_CMD_CHUNK_SIZE - 1u) / PP_CMD_CHUNK_SIZE);
        lastChunkSize = SerialDataSize - (uint16_t)(nbrOfChunks - 1u) * PP_CMD_CHUNK_SIZE;
      }

      Command->FuncInfo.NbrOfChunks = nbrOfChunks;
      Command->FuncInfo.LastChunkSize = lastChunkSize;

      /* Send a Write Request Command With the Header */
      SerializeHeader(&SerialData[0u], Command);
      SendCommand(&SerialData[0u], PP_CMD_HEADER_SIZE);

      /* Serialize and send each body chunk directly from the command structure */
      for (uint8_t i = 0u; i < nbrOfChunks; i++)
      {
        uint16_t sz = (i == (nbrOfChunks - 1u)) ? lastChunkSize : PP_CMD_CHUNK_SIZE;
        SerializeCommandBody(&SerialData[0u], Command, i, sz);
        SendCommand(&SerialData[0u], sz);
      }

      /* Poll for the response until it becomes available or times out */
      SerializeResponseRequestVect(&SerialData[0u], Command);
      GetResponse(SerialData, Response);

      /* One-shot BadRequest recovery: same rule, same reasoning and
       * same phase guard as HandleCmd (see the full comment there).
       * Vector-probe creation is a config-phase command and hits the
       * same config-idle watchdog windows. */
      if ((false == DataExchangeStarted) &&
          (PP_ComStatus::ComOk == currentComStatus) &&
          (PP_DesignStatus::BadRequest == currentDesignStatus))
      {
        SequenceNumber = 0u;
        Command->TransactionInfo.SeqNbr = SequenceNumber;
        currentDesignStatus = PP_DesignStatus::DesignOk;

        SerializeHeader(&SerialData[0u], Command);
        SendCommand(&SerialData[0u], PP_CMD_HEADER_SIZE);

        for (uint8_t i = 0u; i < nbrOfChunks; i++)
        {
          uint16_t sz = (i == (nbrOfChunks - 1u)) ? lastChunkSize : PP_CMD_CHUNK_SIZE;
          SerializeCommandBody(&SerialData[0u], Command, i, sz);
          SendCommand(&SerialData[0u], sz);
        }

        SerializeResponseRequestVect(&SerialData[0u], Command);
        GetResponse(SerialData, Response);
      }

      bool com_error = false;
      bool design_error = false;

      if (currentComStatus != PP_ComStatus::ComOk)
      {
        com_error = true;
      }

      if (currentDesignStatus != PP_DesignStatus::DesignOk)
      {
        design_error = true;
      }

      if ((true == com_error) && (ComErrorHandler != NULL))
      {
        ComErrorHandler();
      }

      if ((true == design_error) && (DesignErrorHandler != NULL))
      {
        DesignErrorHandler();
      }

      /* The board advances its own sequence counter after ANY response
       * it transmits, including one carrying a design failure status.
       * Advancing only on full success left the host one behind after
       * the first failed command, so even the small set of commands the
       * board still accepts after a failure (StopSampling,
       * GetDesignInfo, ...) became unreachable.  Advance whenever a
       * response arrived; only a com error (no response) keeps the
       * counter, since the board may never have processed the frame. */
      if (false == com_error)
      {
        SequenceNumber++;
      }
    }
  }
  else
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
  }
}

static void PrepareCmdHeader(PP_CommandInfo *Command,
                             uint16_t SerialDataSize,
                             PP_FuncId FuncId,
                             uint8_t NbrOfParams,
                             PP_SubFuncId SubFuncId,
                             uint16_t blockId)
{
  if (Command != NULL)
  {
    /* Self-re-anchor after config-phase idle.
     *
     * The board force-releases its configuration session after 3000 ms
     * of command silence, and the next packet that re-claims it ZEROES
     * the board's sequence counter, over USB and over SPI alike.  A
     * stale non-zero frame sent after that is refused, and the refusal
     * ECHOES this client's own sequence number with design status 8,
     * BadRequest, so the reply decodes here as a VALID response,
     * latches currentDesignStatus = BadRequest, and HandleCmd then
     * refuses to transmit anything further.  The user sees
     * "design status = 8" with a board that is alive and waiting.
     *
     * Why zero is the correct anchor: the board restarts its idle
     * countdown on EVERY packet it accepts, including the final
     * response-request poll of an exchange, so its last restart lands
     * BEFORE the client's exchange-end stamp (taken at response decode
     * in TryDecodeResponseFrame, re-taken after a data-payload read in
     * GetDataResponse).  Client-measured idle is therefore <=
     * board-measured idle, and a client-measured gap above the same
     * 3000 ms bound GUARANTEES the board released the session and will
     * zero its counter when this very frame re-claims it.
     *
     * Residual error direction, stated so nobody re-derives it: the
     * client UNDER-measures idle, so around the exact 3.000 s edge it
     * may occasionally MISS a genuine release, which merely reproduces
     * the pre-fix behaviour (one BadRequest, recoverable); it can
     * NEVER fabricate a spurious re-anchor, which would inject seq 0
     * into a healthy session the board still holds and break something
     * that was working.  The TX-time stamp in SendCommand is only a
     * floor for exchanges that never saw a response; those latch a com
     * error and HandleCmd refuses to transmit afterwards, so the floor
     * cannot push a spurious zero onto a live wire.
     *
     * Scope: config phase only.  The board's config-idle watchdog stops
     * running once data exchange is started, so a started exchange must
     * NEVER re-anchor: the session is then legitimately held and the
     * counter still live.
     *
     * Unsigned u32 subtraction: correct across the millisecond
     * counter's wrap (never compare with `+` here). */
    if ((false == DataExchangeStarted) && (true == HaveCommandTouch))
    {
      uint32_t hostIdleMs = (uint32_t)transportMillis() - LastCommandTouchMs;

      if (hostIdleMs > PP_HOST_CFG_IDLE_RESYNC_MS)
      {
        SequenceNumber = 0u;
      }
    }

    Command->TransactionInfo.SeqNbr = SequenceNumber;
    Command->FuncInfo.DataSize = SerialDataSize;
    Command->FuncInfo.blockId = blockId;
    Command->FuncInfo.FuncId = FuncId;
    Command->FuncInfo.SubFuncId = SubFuncId;
    Command->FuncInfo.NbrOfParams = NbrOfParams;
  }
}

static void PrepareParam(PP_CommandInfo *Command,
                         uint8_t ParamIndex,
                         uint16_t SizeOfParam,
                         PP_FuncParamId FuncParamId,
                         PP_FuncParam *FuncParam)
{
  if ((Command != NULL) && (FuncParam != NULL))
  {
    /* The wire descriptor packs id (4 bits) + size (12 bits) into a u16.
     * Sizes >PP_PARAM_DESC_MAX_SIZE (4095) get silently truncated by
     * `size & PP_PARAM_DESC_SIZE_MASK` → firmware reads garbage from
     * the body. Latch a design error instead of shipping a corrupt
     * frame; callers that hit this should be split across multiple
     * params or use a chunked transfer. */
    if (SizeOfParam > PP_PARAM_DESC_MAX_SIZE)
    {
      SetDesignError(PP_DesignStatus::BadParam);
      return;
    }
    Command->FuncInfo.FuncParamIds[ParamIndex] = FuncParamId;
    Command->FuncInfo.FuncParamSizes[ParamIndex] = SizeOfParam;
    memcpy((void *)&Command->FuncInfo.FuncParams[ParamIndex], (const void *)FuncParam, sizeof(PP_FuncParam));
  }
}

static void Linkblock2block(uint16_t SrcId, uint8_t OutIdx, uint16_t DstId, uint8_t InIdx, PP_SubFuncId SubFuncId)
{
  uint8_t NbrOfParams;
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_blockID_SIZE);
  switch (SubFuncId)
  {
  case LinkSys2Sys:
  case LinkSys2Probe:
  case LinkSys2VectorProbe:
  case LinkIn2Sys:
  {
    NbrOfParams = 2u;

    /* Prepare Param_1 */
    FuncParam.ParamblockId(SrcId);
    PrepareParam(&Command, 0u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_2 */
    FuncParam.ParamblockId(DstId);
    PrepareParam(&Command, 1u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);
  }
  break;
  case LinkSys2Node:
  case LinkSys2Macro:
  case LinkIn2Node:
  case LinkIn2Macro:
  {
    NbrOfParams = 3u;
    SerialDataSize += PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* Prepare Param_1 */
    FuncParam.ParamblockId(SrcId);
    PrepareParam(&Command, 0u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_2 */
    FuncParam.ParamblockId(DstId);
    PrepareParam(&Command, 1u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_3 */
    FuncParam.ParamUint8 = InIdx;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  }
  break;
  case LinkNode2Sys:
  case LinkNode2Probe:
  case LinkNode2VectorProbe:
  case LinkMacro2Sys:
  case LinkMacro2Probe:
  {
    NbrOfParams = 3u;
    SerialDataSize += PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* Prepare Param_1 */
    FuncParam.ParamblockId(SrcId);
    PrepareParam(&Command, 0u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_2 */
    FuncParam.ParamUint8 = OutIdx;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* Prepare Param_3 */
    FuncParam.ParamblockId(DstId);
    PrepareParam(&Command, 2u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);
  }
  break;
  case LinkNode2Node:
  case LinkNode2Macro:
  case LinkMacro2Node:
  case LinkMacro2Macro:
  {
    NbrOfParams = 4u;
    SerialDataSize += 2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

    /* Prepare Param_1 */
    FuncParam.ParamblockId(SrcId);
    PrepareParam(&Command, 0u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_2 */
    FuncParam.ParamUint8 = OutIdx;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* Prepare Param_3 */
    FuncParam.ParamblockId(DstId);
    PrepareParam(&Command, 2u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

    /* Prepare Param_4 */
    FuncParam.ParamUint8 = InIdx;
    PrepareParam(&Command, 3u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  }
  break;
  default:
  {
  }
  break;
  }

  PrepareCmdHeader(&Command, SerialDataSize, Linkblock, NbrOfParams, SubFuncId, 0xFFFF);

  /* Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

static bool isPwmPeriod(PP_HwId id)
{
  return (id >= FI1_PERIOD && id <= FI5_PERIOD);
}

static bool isPwmPulse(PP_HwId id)
{
  return (id >= FI1_PULSE && id <= FI5_PULSE);
}

static bool isPwmDelay(PP_HwId id)
{
  return (id >= FI1_DELAY && id <= FI5_DELAY);
}

static uint8_t outputsPerHwInput(PP_HwId id)
{
  if (isPwmPeriod(id))
    return 1u; /* period only */
  if (isPwmPulse(id) || isPwmDelay(id))
    return 2u; /* period + pulse/delay */
  if (id == IMU_ACC || id == IMU_GYR || id == IMU_MAG)
    return 3u; /* Ax,Ay,Az etc. */
  return 1u;   /* analog in, mic, etc. */
}

/* Generic Functions ##################################################################################################### */
PAPAYA::PAPAYA()
{
  cs = PP_CS_PIN;
}

PAPAYA::PAPAYA(SPIClass& spi, uint8_t csPin)
{
  _spi = &spi;
  cs = csPin;
}

PAPAYA::PAPAYA(uint8_t boardId, PP_TransportTxBytesFn txFunction, PP_TransportRxBytesFn rxFunction)
{
  cs = PP_CS_PIN;
  (void)begin(boardId, txFunction, rxFunction);
}

PAPAYA::PAPAYA(const PP_TransportHooks &hooks)
{
  cs = PP_CS_PIN;
  setTransportHooks(hooks);
}

PAPAYA::PAPAYA(const PP_TransportHooks &hooks, uint8_t csPin)
{
  cs = csPin;
  setTransportHooks(hooks);
}

PAPAYA::PAPAYA(int Id)
{
  // Legacy behavior: constructor performs full initialization.
  (void)begin(Id);
}

PAPAYA::PAPAYA(int Id, SPIClass& spi, uint8_t csPin)
{
  // Legacy-compatible behavior, but on a user-provided SPI bus.
  (void)begin(Id, spi, csPin, _spiSettings, /*callSpiBegin=*/true, /*csDelayUs=*/PP_DEFAULT_CS_DELAY_US);
}

PAPAYA::PAPAYA(int Id, const PP_TransportHooks &hooks)
{
  (void)begin(Id, hooks, PP_CS_PIN, _spiSettings, /*callTransportBegin=*/true, /*csDelayUs=*/PP_DEFAULT_CS_DELAY_US);
}

PAPAYA::PAPAYA(int Id, const PP_TransportHooks &hooks, uint8_t csPin)
{
  (void)begin(Id, hooks, csPin, _spiSettings, /*callTransportBegin=*/true, /*csDelayUs=*/PP_DEFAULT_CS_DELAY_US);
}

bool PAPAYA::begin(int Id)
{
  return begin(Id, SPI, PP_CS_PIN, SPISettings(8000000, MSBFIRST, SPI_MODE0), true, PP_DEFAULT_CS_DELAY_US);
}

bool PAPAYA::begin(uint8_t boardId, PP_TransportTxBytesFn txFunction, PP_TransportRxBytesFn rxFunction)
{
  uint8_t slot = GetContextSlotForBoardId(boardId);

  if (IsValidContextSlot(slot) == false)
  {
    return false;
  }

  EnsureRuntimeContextsReady();
  SaveActiveRuntimeContext();
  ResetRuntimeContext(g_contexts[slot], slot);

  _boardId = boardId;
  _contextSlot = slot;
  _transportTx = txFunction;
  _transportRx = rxFunction;
  _transportHooks = {};
  _spi = nullptr;
  _callSpiBegin = false;
  _csDelayUs = 0u;
  cs = PP_CS_PIN;

  g_contexts[slot].boardId = (uint8_t)_boardId;
  g_contexts[slot].transport.spi = nullptr;
  g_contexts[slot].transport.settings = _spiSettings;
  g_contexts[slot].transport.csPin = static_cast<uint8_t>(cs);
  g_contexts[slot].transport.csDelayUs = _csDelayUs;
  g_contexts[slot].transport.callSpiBegin = false;
  g_contexts[slot].transport.txBytes = _transportTx;
  g_contexts[slot].transport.rxBytes = _transportRx;
  g_contexts[slot].transport.hooks = {};
  /* Invalidate the active slot so ActivateContext performs a full
   * LoadRuntimeContext: a repeat begin() on the same board must reset
   * host session state (SequenceNumber, id counters, status latches).
   * ActivateContext otherwise skips the load when the slot is unchanged. */
  g_activeContextSlot = PP_INVALID_CONTEXT_SLOT;
  ActivateContext(slot);
  SaveActiveRuntimeContext();
  return true;
}

bool PAPAYA::begin(int Id, SPIClass& spi, uint8_t csPin, const SPISettings& settings,
                   bool callSpiBegin, uint16_t csDelayUs)
{
  return setUpTransport(Id, spi, csPin, settings, callSpiBegin, csDelayUs, true);
}

bool PAPAYA::attach(int Id)
{
  return attach(Id, SPI, PP_CS_PIN, SPISettings(8000000, MSBFIRST, SPI_MODE0),
                true, PP_DEFAULT_CS_DELAY_US);
}

bool PAPAYA::attach(int Id, SPIClass& spi, uint8_t csPin, const SPISettings& settings,
                    bool callSpiBegin, uint16_t csDelayUs)
{
  return setUpTransport(Id, spi, csPin, settings, callSpiBegin, csDelayUs, false);
}

bool PAPAYA::setUpTransport(int Id, SPIClass& spi, uint8_t csPin,
                            const SPISettings& settings, bool callSpiBegin,
                            uint16_t csDelayUs, bool driveReset)
{
  uint8_t slot = GetContextSlotForBoardId(Id);

  if (IsValidContextSlot(slot) == false)
  {
    return false;
  }

  EnsureRuntimeContextsReady();
  SaveActiveRuntimeContext();
  ResetRuntimeContext(g_contexts[slot], slot);

  // Store local instance configuration
  _boardId = Id;
  _contextSlot = slot;
  _spi = &spi;
  _transportTx = nullptr;
  _transportRx = nullptr;
  _transportHooks = {};
  _spiSettings = settings;
  _callSpiBegin = callSpiBegin;
  _csDelayUs = csDelayUs;
  cs = csPin;

  g_contexts[slot].boardId = (uint8_t)_boardId;
  g_contexts[slot].transport.spi = _spi;
  g_contexts[slot].transport.settings = _spiSettings;
  g_contexts[slot].transport.csPin = static_cast<uint8_t>(cs);
  g_contexts[slot].transport.csDelayUs = _csDelayUs;
  g_contexts[slot].transport.callSpiBegin = _callSpiBegin;
  g_contexts[slot].transport.txBytes = _transportTx;
  g_contexts[slot].transport.rxBytes = _transportRx;
  g_contexts[slot].transport.hooks = _transportHooks;
  /* Full context (re)load: see note in begin(boardId,tx,rx). */
  g_activeContextSlot = PP_INVALID_CONTEXT_SLOT;
  ActivateContext(slot);

  /* THE RESET LINE IS WRITTEN BEFORE THE PIN BECOMES AN OUTPUT.
   *
   * Reset is asserted HIGH on this wire, and a pin made an output before
   * its level is chosen drives whatever its output register happened to
   * hold. On the attach path that is the difference between adopting a
   * running board and restarting the very design the caller was trying
   * to preserve, and it would happen in a few microseconds, before any
   * code could see it. Choosing the level first costs nothing on the
   * begin path, which asserts reset a line later anyway. */
  transportSetReset(false);
  transportPinMode(PP_RESET_PIN, OUTPUT);
  transportPinMode(PP_ID_PIN_1, OUTPUT);
  transportPinMode(PP_ID_PIN_2, OUTPUT);
  transportPinMode(g_transport.csPin, OUTPUT);

  // Select Device ID (keeps your original "~Id" convention)
  SelectBoardLines(g_contexts[slot].boardId);

  if (driveReset)
  {
    // Keep Device in Reset Mode
    transportSetReset(true);

    // Init SPI Interface
    csDeselect();
    transportBegin();
    transportDelayMilliseconds(PP_RESET_ASSERT_MS);

    // Release Reset
    transportSetReset(false);
    transportDelayMilliseconds(PP_BOOT_SETTLE_MS);
  }
  else
  {
    /* attach(): the board is already up and must stay up. The transport
     * still has to be brought into service, but nothing here touches
     * the reset line and there is no boot to wait out. */
    csDeselect();
    transportBegin();
  }

  SaveActiveRuntimeContext();
  return true;
}

bool PAPAYA::begin(int Id, const PP_TransportHooks &hooks, const SPISettings &settings,
                   bool callTransportBegin, uint16_t csDelayUs)
{
  return begin(Id, hooks, PP_CS_PIN, settings, callTransportBegin, csDelayUs);
}

bool PAPAYA::begin(int Id, const PP_TransportHooks &hooks, uint8_t csPin, const SPISettings &settings,
                   bool callTransportBegin, uint16_t csDelayUs)
{
  uint8_t slot = GetContextSlotForBoardId(Id);

  if (IsValidContextSlot(slot) == false)
  {
    return false;
  }

  EnsureRuntimeContextsReady();
  SaveActiveRuntimeContext();
  ResetRuntimeContext(g_contexts[slot], slot);

  _boardId = Id;
  _contextSlot = slot;
  _transportTx = nullptr;
  _transportRx = nullptr;
  _transportHooks = hooks;
  if (_spi == nullptr)
  {
    _spi = &SPI;
  }
  _spiSettings = settings;
  _callSpiBegin = callTransportBegin;
  _csDelayUs = csDelayUs;
  cs = csPin;

  g_contexts[slot].boardId = (uint8_t)_boardId;
  g_contexts[slot].transport.spi = _spi;
  g_contexts[slot].transport.settings = _spiSettings;
  g_contexts[slot].transport.csPin = static_cast<uint8_t>(cs);
  g_contexts[slot].transport.csDelayUs = _csDelayUs;
  g_contexts[slot].transport.callSpiBegin = _callSpiBegin;
  g_contexts[slot].transport.txBytes = _transportTx;
  g_contexts[slot].transport.rxBytes = _transportRx;
  g_contexts[slot].transport.hooks = _transportHooks;
  /* Full context (re)load: see note in begin(boardId,tx,rx). */
  g_activeContextSlot = PP_INVALID_CONTEXT_SLOT;
  ActivateContext(slot);

  transportPinMode(PP_RESET_PIN, OUTPUT);
  transportPinMode(PP_ID_PIN_1, OUTPUT);
  transportPinMode(PP_ID_PIN_2, OUTPUT);
  transportPinMode(g_transport.csPin, OUTPUT);

  SelectBoardLines(g_contexts[slot].boardId);
  transportSetReset(true);
  csDeselect();
  transportBegin();
  transportDelayMilliseconds(PP_RESET_ASSERT_MS);
  transportSetReset(false);
  transportDelayMilliseconds(PP_BOOT_SETTLE_MS);
  SaveActiveRuntimeContext();
  return true;
}

void PAPAYA::end()
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);

  // We do not call spi->end() because many sketches share the SPI bus.
  // Just deselect and reset state.
  csDeselect();
  transportEnd();
}

void PAPAYA::setSPISettings(const SPISettings& settings)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
    g_transport.settings = settings;
    g_contexts[this->_contextSlot].transport.settings = settings;
  }

  _spiSettings = settings;
}

void PAPAYA::setTransportHooks(const PP_TransportHooks &hooks)
{
  _transportTx = nullptr;
  _transportRx = nullptr;
  _transportHooks = hooks;

  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
    g_transport.txBytes = nullptr;
    g_transport.rxBytes = nullptr;
    g_transport.hooks = _transportHooks;
    g_contexts[this->_contextSlot].transport.txBytes = nullptr;
    g_contexts[this->_contextSlot].transport.rxBytes = nullptr;
    g_contexts[this->_contextSlot].transport.hooks = _transportHooks;
  }
}

void PAPAYA::setCsDelayMicroseconds(uint16_t csDelayUs)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
    g_transport.csDelayUs = csDelayUs;
    g_contexts[this->_contextSlot].transport.csDelayUs = csDelayUs;
  }

  _csDelayUs = csDelayUs;
}

PP_DesignStatus PAPAYA::GetcurrentDesignStatus()
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
  }

  return currentDesignStatus;
}

PP_ComStatus PAPAYA::GetcurrentComStatus(void)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
  }

  return currentComStatus;
}

void PAPAYA::setComErrorHandler(PP_ErrorHandlerType UserHandler)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
  }

  ComErrorHandler = UserHandler;
}

void PAPAYA::setDesignErrorHandler(PP_ErrorHandlerType UserHandler)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
  }

  DesignErrorHandler = UserHandler;
}

/* --------------------------------------------------------------------
 * What a Dataset block needs to work out its own playback rate.
 *
 * A recording plays once over its natural duration, which means
 * traversing its N samples in N ticks of the design clock: Fs / N. Both
 * numbers are already known here - Fs from startDesign, N from the
 * upload - so signalSource::dataset() does not ask the caller for a
 * frequency the way the generated-waveform factories do.
 * -------------------------------------------------------------------- */
static float g_designSamplingFreq = 0.0f;
static uint32_t g_datasetSlotSamples[PP_DATASET_SLOT_COUNT] = {0u};
/* Flash slots this design has handed out, in creation order.
 * signalSource::dataset(samples, count) takes the next one and puts the
 * recording there itself, which is why a slot is not something the caller
 * passes: it is bookkeeping between the library and the board, and two
 * Dataset blocks must simply not collide. Reset by startDesign(), so
 * re-running a program reuses 0, 1, 2 and overwrites what it wrote last
 * time rather than walking up the flash until it runs out. */
static uint8_t g_datasetSlotsTaken = 0u;

float PapayaDesignSamplingFreq(void) { return g_designSamplingFreq; }

uint32_t PapayaDatasetSlotSamples(uint16_t slot)
{
  return (slot < PP_DATASET_SLOT_COUNT) ? g_datasetSlotSamples[slot] : 0u;
}

float PapayaDatasetPlaybackFreq(uint32_t nSamples, float fs)
{
  /* Fs / N of the WHOLE recording, never a clamped N. A recording plays
   * once over its own duration, so traversing N samples takes N ticks.
   *
   * This clamped at the flash slot's capacity, which described a recording
   * that had been cut, and nothing cuts one: what fits is a question
   * validation answers by refusing. Clamping a longer recording would have
   * played it N/cap times too fast, silently. The Python twin,
   * papaya.signal_source.dataset_playback_freq, dropped the same clamp, and
   * these two are the same function or they are a bug. */
  if ((nSamples == 0u) || (fs <= 0.0f)) { return 0.0f; }
  return fs / (float)nSamples;
}

void PapayaNoteDatasetSlot(uint16_t slot, uint32_t nSamples)
{
  if (slot < PP_DATASET_SLOT_COUNT) { g_datasetSlotSamples[slot] = nSamples; }
}

void PAPAYA::startDesign(float SamplingFreq, PP_C2dAlgo Algo)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  PP_FuncParam FuncParam;

  /* Half of what a Dataset block needs; the other half is the slot's
   * length, noted by uploadDataset(). */
  g_designSamplingFreq = SamplingFreq;
  /* A new design hands out slots from 0 again. */
  g_datasetSlotsTaken = 0u;

  ActivateContext(this->_contextSlot);

  /* DesignInit starts a fresh design on the firmware side. Reset host
   * counters so a re-deployed sketch (or a second design in the same
   * sketch) does not keep stale IDs / probe indices / VectorProbeBytes
   * from a prior design; otherwise IDs collide and the host-side
   * byte-offset map drifts past CachedVectProbesBytes.
   *
   * NOTE on probe/VectorProbe object re-use: instance idx members live
   * on the object (sentinel-default 0xFFu for idempotency). If a host
   * sketch re-runs startDesign() while keeping the SAME probe / vector-
   * probe / input objects from a previous design, addToQueue() will
   * no-op (idx already assigned) and the new design will have no
   * probes routed. The typical Arduino setup() pattern recreates
   * objects on every fresh upload so this is not a concern there; for
   * runtime re-deploys, recreate the probe objects too. */
  tf::currentSysId                  = PP_SYS_ID_BASE;
  node::currentNodeId               = PP_NODE_ID_BASE;
  macro::currentMacroId             = PP_MACRO_ID_BASE;
  input::currentInputId             = PP_INPUT_ID_BASE;
  probe::currentProbeId             = PP_PROBE_ID_BASE;
  VectorProbe::currentVectorProbeId = PP_VECTOR_PROBE_ID_BASE;
  input::currentInputIdx            = 0u;
  probe::currentProbeIdx            = 0u;
  VectorProbe::currentVectorProbeIdx = 0u;
  VectorProbe::VectorProbeBytes     = 0u;
  /* Clear any latched failure from a previous design so this DesignInit
   * (and subsequent Createblock/Linkblock calls) are not short-circuited
   * by the addToQueue / operator>> gate added in the failure-isolation
   * path. */
  currentDesignStatus               = PP_DesignStatus::DesignOk;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                            PP_PARAM_INFO_SIZE + PP_C2D_ALGO_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u, DesignInit, 0xFFFF);

  FuncParam.ParamReal = SamplingFreq;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamC2dAlgo(Algo);
  PrepareParam(&Command, 1u, PP_C2D_ALGO_SIZE, PP_C2D_ALGO_TYPE, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::stopDesign(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, StopDesign, 0xFFFF);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::startSampling(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, StartSampling, 0xFFFF);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);

  /* Enter the data-exchange phase ONLY if the board actually accepted
   * the switch.  Latching unconditionally was harmless while nothing
   * read the flag; it is not harmless now, because DataExchangeStarted
   * is the phase guard of BOTH sequence recoveries and of the raw
   * switch-back frame:
   *
   *   - PrepareCmdHeader's idle re-anchor  (`false == DataExchangeStarted
   *     && true == HaveCommandTouch`)
   *   - HandleCmd's / HandleCmdVect's one-shot BadRequest retry
   *     (`false == DataExchangeStarted && ComOk && BadRequest`)
   *   - stopSampling()'s raw 1-byte PP_CMD_SWITCH_BACK_TO_CFG
   *
   * A refused StartSampling (the most-reported failure on this link)
   * left the host believing data exchange was running while the board
   * was still in configuration.  Both recoveries then stayed disarmed
   * for the rest of the process (the board's config-idle watchdog only
   * stops running during a REAL exchange), and stopSampling() pushed a
   * bare 1-byte switch-back into a board in config mode, where it is
   * read as the first byte of an 18-byte command header.
   *
   * Papaya Studio applies the same rule when it tracks the phase of a
   * link it is bridging: data exchange counts as started only after a
   * StartSampling that answered DesignOk.  Studio and this client
   * therefore agree about the phase instead of disagreeing. */
  if ((PP_ComStatus::ComOk == currentComStatus) &&
      (PP_DesignStatus::DesignOk == currentDesignStatus))
  {
    DataExchangeStarted = true;
  }
}

void PAPAYA::stopSampling(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  if (true == DataExchangeStarted)
  {
    /* Request Switch Back To CFG Mode */
    linkFrameBegin();
    uint8_t command = PP_CMD_SWITCH_BACK_TO_CFG;
    transportTransmitBytes(&command, 1u);
    linkFrameEnd();
    DataExchangeStarted = false;

    /* The firmware zeroes its command sequence counter when the next
     * command re-claims the configuration interface after
     * PP_CMD_SWITCH_BACK_TO_CFG releases it.  Reset the host counter in
     * lockstep so the StopSampling command below (and every command of
     * the next session) passes the firmware seq check.  Without this only
     * the first sample session works: the second onward fail the seq
     * check, the design never resumes, and probes read NaN. */
    SequenceNumber = 0u;
  }

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, StopSampling, 0xFFFF);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::setMonitoringInterface(PP_MonInterface InterfaceId)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_MON_INTERFACE_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, SetMonInterface, 0xFFFF);

  /* 2. Prepare Param_1 */
  FuncParam.ParamMonInterface(InterfaceId);
  PrepareParam(&Command, 0u, PP_MON_INTERFACE_SIZE, PP_MON_INTERFACE_TYPE, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::setInputs(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  if ((input::currentInputIdx > 0u) && (input::currentInputIdx <= PP_MAX_INPUTS_NUMBER))
  {
    /* Request Write */
    linkFrameBegin();
    uint8_t command = PP_CMD_WRITE;
    transportTransmitBytes(&command, 1u);
    linkFrameEnd();

    /* Send Inputs */
    linkFrameBegin();
    transportTransmitBytes(&InputsBuffer[0u], input::currentInputIdx * PP_REAL_SIZE);
    linkFrameEnd();
  }
}

void PAPAYA::getProbes(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  if ((probe::currentProbeIdx > 0u) && (probe::currentProbeIdx <= PP_MAX_PROBES_NUMBER))
  {
    /* Request Read */
    linkFrameBegin();
    if (g_transport.csDelayUs == 0) transportDelayMicroseconds(10);
    uint8_t command = PP_CMD_READ;
    transportTransmitBytes(&command, 1u);
    if (g_transport.csDelayUs == 0) transportDelayMicroseconds(10);
    linkFrameEnd();

    /* Get Probes */
    linkFrameBegin();
    if (g_transport.csDelayUs == 0) transportDelayMicroseconds(10);
    transportReceiveBytes(&ProbesBuffer[0u], probe::currentProbeIdx * PP_REAL_SIZE);
    if (g_transport.csDelayUs == 0) transportDelayMicroseconds(10);
    linkFrameEnd();
  }
}

void PAPAYA::getVectorProbes(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t n_vec = VectorProbe::currentVectorProbeIdx; // number of active vector probes
  uint32_t bytes = VectorProbe::VectorProbeBytes;

  if (n_vec > 0u && n_vec <= PP_MAX_VECTOR_PROBES_NUMBER && bytes > 0u)
  {
    /* Request Read */
    linkFrameBegin();
    uint8_t command = PP_CMD_READ_VECT_PROBE;
    transportTransmitBytes(&command, 1u);
    linkFrameEnd();

    if (PP_VECTOR_PROBE_REQUEST_DELAY_MS > 0u)
    {
      transportDelayMilliseconds(PP_VECTOR_PROBE_REQUEST_DELAY_MS);
    }

    /* Get Probes, in chunks, for two reasons.
     *
     * transportReceiveBytes takes a uint16_t count, and on a host build
     * 9 probes x 8192 B/probe is 73 728 B — more than one call can
     * express, so a single call would clip the size to its low 16 bits.
     *
     * And the buffer is not always big enough to hold the frame. On a
     * microcontroller it deliberately is not: PP_MAX_VECTOR_PROBES_BYTES
     * is one 400-byte chunk per probe there, because the whole-frame
     * buffer is 72 KB of static RAM that no Arduino has. The board still
     * sends the whole frame, and every byte of it MUST come off the
     * link, or the next read starts mid-frame and everything after it is
     * garbage. So: store what fits, then drain the rest through a small
     * sink. What a caller reads back is the leading
     * PP_MAX_VECTOR_PROBES_BYTES of each probe.
     *
     * This also closes an overflow that was reachable on any target: the
     * previous loop wrote `bytes` into the buffer without ever comparing
     * it to the buffer's size. */
    linkFrameBegin();
    const uint32_t capacity = (uint32_t)sizeof(VectorProbesBuffer);
    uint32_t remaining = bytes;
    uint32_t offset    = 0u;

    while ((remaining > 0u) && (offset < capacity))
    {
      const uint32_t room = capacity - offset;
      uint32_t want = (remaining < room) ? remaining : room;
      if (want > 0xFFFFu)
      {
        want = 0xFFFFu;
      }
      const uint16_t chunk = (uint16_t)want;
      transportReceiveBytes(&VectorProbesBuffer[offset], chunk);
      offset    += chunk;
      remaining -= chunk;
    }

    if (remaining > 0u)
    {
      uint8_t sink[PP_VECT_PROBE_DRAIN_BYTES];
      while (remaining > 0u)
      {
        const uint16_t chunk = (remaining < (uint32_t)sizeof(sink))
                                   ? (uint16_t)remaining
                                   : (uint16_t)sizeof(sink);
        transportReceiveBytes(&sink[0u], chunk);
        remaining -= chunk;
      }
    }
    linkFrameEnd();
  }
}


/* ---- Gateway relay API -------------------------------------------
 *
 * Running commands somebody else composed.  See the declarations in
 * PAPAYA.h for why this exists; what follows is the part that is easy to
 * get wrong.
 *
 * THE SEQUENCE NUMBER IS NOT OURS.
 *
 * TryDecodeResponseFrame validates an arriving status frame against the
 * module-global SequenceNumber, because normally this library composed
 * the command and therefore owns the count.  A relay did not: the far end
 * numbered the header, and the board will answer with that number.  If we
 * poll with our own idea of the count, every response fails the compare,
 * GetResponse burns its whole deadline, and the caller is told the link is
 * broken for a command the board executed perfectly.
 *
 * So each relayed command ADOPTS the number out of the header it was
 * handed.  That keeps this library's validator agreeing with whoever is
 * actually driving, which on a relayed link is the only correct answer.
 */

/** @brief Copy the far end's sequence number out of a formed header. */
static void AdoptRelayedSequence(const uint8_t *Header)
{
  if (Header != NULL)
  {
    SequenceNumber = ReadUint16LE(&Header[PP_CMD_SEQ_NUMBER_IDX]);
  }
}

/**
 * @brief Put a formed header and body on the wire, chunked.
 *
 * Copies through a scratch buffer rather than sending the caller's memory
 * directly: on a default Arduino SPI transport the transfer is
 * full-duplex and overwrites the buffer it is given with what the slave
 * clocked back.  Sending the caller's header in place would corrupt it,
 * and a caller that reuses its buffer for a retry would then send
 * nonsense.
 */
static void SendRelayedCommand(const uint8_t *Header, const uint8_t *Body,
                               uint16_t BodyLength)
{
  uint8_t scratch[PP_CMD_CHUNK_SIZE];

  memcpy(&scratch[0u], Header, PP_CMD_HEADER_SIZE);
  SendCommand(&scratch[0u], PP_CMD_HEADER_SIZE);

  uint16_t sent = 0u;
  while (sent < BodyLength)
  {
    const uint16_t remaining = (uint16_t)(BodyLength - sent);
    const uint16_t chunk = (remaining > PP_CMD_CHUNK_SIZE)
                             ? (uint16_t)PP_CMD_CHUNK_SIZE
                             : remaining;
    memcpy(&scratch[0u], &Body[sent], chunk);
    SendCommand(&scratch[0u], chunk);
    sent = (uint16_t)(sent + chunk);
  }
}

/** @brief Build the 9-byte poll frame for an already-sent command. */
static void BuildRelayedResponseRequest(uint8_t *SerialData)
{
  WriteUint16LE(&SerialData[PP_CMD_SEQ_NUMBER_IDX], SequenceNumber);
  SerialData[PP_CMD_READ_WRITE_IDX] = PP_CMD_READ;
  WriteUint16LE(&SerialData[PP_CMD_SIZEL_IDX], PP_CMD_RESPONSE_ID);
  CalculateAndsetCrc(SerialData, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE);
}

/** @brief Shared argument check for every relay entry point. */
static bool RelayArgumentsUsable(const uint8_t *Header, const uint8_t *Body,
                                 uint16_t BodyLength)
{
  if (Header == NULL)
  {
    return false;
  }
  /* A body length with no body, or a body with no length, means the
   * caller and this library disagree about the frame.  Refuse rather
   * than send half of one: the board has no inter-frame timeout and a
   * part-sent command leaves its state machine waiting forever. */
  if ((BodyLength > 0u) && (Body == NULL))
  {
    return false;
  }
  return true;
}

bool PAPAYA::relayCommand(const uint8_t *header, const uint8_t *body,
                          uint16_t bodyLength, uint8_t *response)
{
  if ((response == NULL) || !RelayArgumentsUsable(header, body, bodyLength))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  AdoptRelayedSequence(header);
  SendRelayedCommand(header, body, bodyLength);

  uint8_t request[PP_RESPONSE_REQ_SIZE];
  BuildRelayedResponseRequest(&request[0u]);
  GetResponse(&request[0u], response);

  /* An error STATUS is still an answer, and the far end is the one
   * entitled to judge it: it knows what it asked for. Only a failure to
   * converse at all is this function's to report. */
  return (currentComStatus == PP_ComStatus::ComOk);
}

void PAPAYA::relayBeginCommand(const uint8_t *header)
{
  if (header == NULL)
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }
  ActivateContext(this->_contextSlot);

  /* The far end's number, not ours. It composed the command, so the poll
   * built later has to carry the number the board will answer with. */
  AdoptRelayedSequence(header);

  /* Copied through scratch for the same reason SendRelayedCommand does
   * it: a default SPI transport is full duplex and overwrites the buffer
   * it is given with whatever the slave clocked back, so sending the
   * caller's header in place would corrupt it. */
  uint8_t scratch[PP_CMD_HEADER_SIZE];
  memcpy(&scratch[0u], header, PP_CMD_HEADER_SIZE);
  SendCommand(&scratch[0u], PP_CMD_HEADER_SIZE);
}

bool PAPAYA::relaySendBodyChunk(const uint8_t *chunk, uint16_t length)
{
  if ((chunk == NULL) || (length == 0u) || (length > PP_CMD_CHUNK_SIZE))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  uint8_t scratch[PP_CMD_CHUNK_SIZE];
  memcpy(&scratch[0u], chunk, length);
  SendCommand(&scratch[0u], length);
  return true;
}

bool PAPAYA::relayAwaitResponse(uint8_t *response)
{
  if (response == NULL)
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  uint8_t request[PP_RESPONSE_REQ_SIZE];
  BuildRelayedResponseRequest(&request[0u]);
  GetResponse(&request[0u], response);

  return (currentComStatus == PP_ComStatus::ComOk);
}

bool PAPAYA::relayReadDataPayload(uint8_t *data, uint16_t dataLength)
{
  if ((data == NULL) || (0u == dataLength))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  /* Deliberately NOT gated on the status here, unlike
   * relayCommandWithData: the caller of these three steps holds the
   * status itself and has already had to decide what it says. Gating
   * twice would mean this function silently disagreeing with a caller
   * that had good reason. The obligation is stated on the declaration. */
  return GetDataResponse(data, dataLength);
}

bool PAPAYA::relayCommandWithData(const uint8_t *header, const uint8_t *body,
                                  uint16_t bodyLength, uint8_t *response,
                                  uint8_t *data, uint16_t dataLength)
{
  if (!relayCommand(header, body, bodyLength, response))
  {
    return false;
  }
  if ((data == NULL) || (0u == dataLength))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  /* Only when the command itself succeeded: reading a payload the board
   * never queued consumes the NEXT command's response instead, and the
   * link is desynchronised from that point on. */
  if (currentDesignStatus != PP_DesignStatus::DesignOk)
  {
    return false;
  }
  return GetDataResponse(data, dataLength);
}

void PAPAYA::relayCommandNoResponse(const uint8_t *header, const uint8_t *body,
                                    uint16_t bodyLength)
{
  if (!RelayArgumentsUsable(header, body, bodyLength))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }
  ActivateContext(this->_contextSlot);

  AdoptRelayedSequence(header);
  SendRelayedCommand(header, body, bodyLength);
  /* No poll: the board is rebooting and will not answer.  Waiting would
   * spend the full response deadline and then report a comms failure for
   * a command that did exactly what it was told. */
}

/** True when a read returned nothing but the quiet wire.
 *
 * A PROBE READ HAD NO WAY TO FAIL, and that is worse than it sounds.
 * This returned its byte count unconditionally, so the gateway's
 * "the board had nothing" branch was unreachable, its dropped-batch
 * counter could never move, and whatever the bus floated to was wrapped
 * in a correct link CRC and forwarded as a genuine batch. The CRC then
 * certified it all the way to the chart.
 *
 * Reachable in ordinary use: while the board is held in reset, during
 * its boot after the gateway restarts itself to re-arm its radio, or
 * with the address switch set to a board that is not there. In every one
 * of those the master clocks a quiet wire and reads 0xFF on every clock.
 *
 * ENTIRELY 0xFF, not a threshold. Every sample would be 0xFFFFFFFF,
 * which is a quiet NaN, so a batch of them carries nothing any design
 * could have produced; a single byte that is not 0xFF means real data,
 * and a partial read is a different fault that must not be swallowed by
 * this one.
 */
static bool AllIdleLine(const uint8_t *buffer, uint16_t byteCount)
{
  for (uint16_t i = 0u; i < byteCount; i++)
  {
    if (buffer[i] != 0xFFu)
    {
      return false;
    }
  }
  return byteCount > 0u;
}

uint16_t PAPAYA::relayReadProbes(uint8_t *buffer, uint16_t byteCount)
{
  if ((buffer == NULL) || (0u == byteCount) ||
      (IsValidContextSlot(this->_contextSlot) == false))
  {
    return 0u;
  }
  ActivateContext(this->_contextSlot);

  /* Two chip-select pulses: the opcode, then the payload.  Identical to
   * getProbes(), except the size comes from the caller instead of from
   * probe objects this program never built. */
  linkFrameBegin();
  uint8_t command = PP_CMD_READ;
  transportTransmitBytes(&command, 1u);
  linkFrameEnd();

  linkFrameBegin();
  transportReceiveBytes(buffer, byteCount);
  linkFrameEnd();

  return AllIdleLine(buffer, byteCount) ? 0u : byteCount;
}

uint16_t PAPAYA::relayReadVectorProbes(uint8_t *buffer, uint16_t byteCount)
{
  if ((buffer == NULL) || (0u == byteCount) ||
      (IsValidContextSlot(this->_contextSlot) == false))
  {
    return 0u;
  }
  ActivateContext(this->_contextSlot);

  linkFrameBegin();
  uint8_t command = PP_CMD_READ_VECT_PROBE;
  transportTransmitBytes(&command, 1u);
  linkFrameEnd();

  /* The board needs a moment between the request and the payload; the
   * same wait getVectorProbes() takes. */
  transportDelayMilliseconds(PP_VECTOR_PROBE_REQUEST_DELAY_MS);

  linkFrameBegin();
  transportReceiveBytes(buffer, byteCount);
  linkFrameEnd();

  return AllIdleLine(buffer, byteCount) ? 0u : byteCount;
}

bool PAPAYA::relaySendOpcode(uint8_t opcode)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  /* One pulse, one byte. The same write a cable makes for the same
   * opcode, which is the point: the board cannot tell the difference and
   * must not have to. */
  linkFrameBegin();
  transportTransmitBytes(&opcode, 1u);
  linkFrameEnd();
  /* The transport does not report a byte back, exactly as it does not
   * for the opcode that opens an input write. Nothing on this wire
   * acknowledges a lone opcode, so there is nothing truer to return. */
  return true;
}


bool PAPAYA::relayWriteInputs(const uint8_t *values, uint16_t byteCount)
{
  if ((values == NULL) || (0u == byteCount) ||
      (IsValidContextSlot(this->_contextSlot) == false))
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  linkFrameBegin();
  uint8_t command = PP_CMD_WRITE;
  transportTransmitBytes(&command, 1u);
  linkFrameEnd();

  /* One exchange for every slot.  Splitting them leaves the firmware
   * waiting for floats and mis-parsing the next frame's opening bytes as
   * input data, which is why the values travel whole. */
  linkFrameBegin();
  {
    uint8_t scratch[PP_CMD_CHUNK_SIZE];
    uint16_t sent = 0u;
    while (sent < byteCount)
    {
      const uint16_t remaining = (uint16_t)(byteCount - sent);
      const uint16_t chunk = (remaining > PP_CMD_CHUNK_SIZE)
                               ? (uint16_t)PP_CMD_CHUNK_SIZE
                               : remaining;
      memcpy(&scratch[0u], &values[sent], chunk);
      transportTransmitBytes(&scratch[0u], chunk);
      sent = (uint16_t)(sent + chunk);
    }
  }
  linkFrameEnd();

  return true;
}

bool PAPAYA::resetBoard(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  /* Refuse only when there is genuinely no line to drive.
   *
   * The test used to be "no setReset hook", and that refused on the one
   * transport where this works best. transportSetReset() falls back to
   * the library's own reset line when no hook is supplied, and begin()
   * has always relied on exactly that fallback: it asserts reset, brings
   * up SPI, releases reset and waits out the boot, which is how a
   * stacked board comes up at all. So a gateway that had just booted a
   * board successfully was told it could not reset one.
   *
   * What genuinely cannot drive a line is the direct byte-callback
   * transport: it hands whole buffers to a host that framed them itself
   * and owns no GPIO here, so unless it supplies the hook there is
   * nothing to assert. That, and only that, is "this host cannot", which
   * a caller still needs to tell apart from "this host tried and
   * failed". */
  if (transportUsesDirectByteCallbacks() &&
      (g_transport.hooks.setReset == nullptr))
  {
    return false;
  }

  transportSetReset(true);
  csDeselect();
  transportDelayMilliseconds(PP_RESET_ASSERT_MS);
  transportSetReset(false);
  transportDelayMilliseconds(PP_BOOT_SETTLE_MS);

  /* The board came up fresh, so its command numbering restarted at zero
   * and ours has to say the same thing or the next command is refused. */
  SequenceNumber = 0u;
  currentComStatus = PP_ComStatus::ComOk;
  currentDesignStatus = PP_DesignStatus::DesignOk;
  return true;
}


/* ---- Live (sampling-mode) developer API --------------------------
 *
 * These helpers bypass the DLP / transaction-log path used by the
 * code-generator flow. They talk raw opcodes to the board so a host
 * MCU can poll probes and push inputs after startSampling() has been
 * issued. They assume a USB transport has been bound via a direct
 * byte callback (PP_TransportTxBytesFn / PP_TransportRxBytesFn); the
 * rxBytes callback is responsible for honouring its own timeout.
 * ------------------------------------------------------------------*/
bool PAPAYA::readProbesLive(uint32_t timeoutUs)
{
  (void)timeoutUs; // honoured by the transport rxBytes callback itself
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }

  ActivateContext(this->_contextSlot);

  uint8_t n = probe::currentProbeIdx;
  if ((n == 0u) || (n > PP_MAX_PROBES_NUMBER))
  {
    return false;
  }

  /* USB auto-push frame: [opcode][payload]. Read the opcode byte
   * first, then the expected probe payload only if the opcode matches
   * PP_CMD_READ. If another opcode (vector probe, stale, ...) arrives
   * we discard the frame without touching ProbesBuffer.            */
  uint8_t opcode = 0u;
  transportReceiveBytes(&opcode, 1u);
  if (opcode != PP_CMD_READ)
  {
    return false;
  }

  uint16_t payloadSize = (uint16_t)(n * PP_REAL_SIZE);
  transportReceiveBytes(&ProbesBuffer[0u], payloadSize);
  return true;
}

bool PAPAYA::writeInputsLive(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }

  ActivateContext(this->_contextSlot);

  uint8_t n = input::currentInputIdx;
  if ((n == 0u) || (n > PP_MAX_INPUTS_NUMBER))
  {
    return false;
  }

  uint8_t opcode = PP_CMD_WRITE;
  transportTransmitBytes(&opcode, 1u);
  transportTransmitBytes(&InputsBuffer[0u], (uint16_t)(n * PP_REAL_SIZE));
  return true;
}

bool PAPAYA::setInputLive(input &inp, float value)
{
  inp.addToQueue(value);
  return this->writeInputsLive();
}


/* ------------------------------------------------------------------
 * Slot storage (audio + dataset)
 *
 * The two families use the SAME command shapes for the parts that carry
 * bulk data (a chunk is {slot, offset, bytes}, a commit is
 * {slot, crc, timestamp}, a download is {slot, offset, length}), so
 * those are written once and shared. Only what genuinely differs (the
 * record layout, and the dataset's optional name on Start) is written
 * twice.
 * ------------------------------------------------------------------ */

/** Send a {u8 slot, u32 offset, u8[] data} upload chunk. */
static bool SendSlotChunk(PP_SubFuncId SubFuncId, uint8_t slotId,
                          uint32_t offset, const uint8_t *data, uint16_t size)
{
  if ((data == NULL) || (size == 0u))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }

  /* The payload travels as SEVERAL params, not one.
   *
   * A wire descriptor packs the parameter length into 12 bits, so one
   * param carries at most PP_PARAM_DESC_MAX_SIZE bytes and PrepareParam
   * refuses anything longer by latching BadParam. This sent a whole
   * 57288-byte chunk as a single param: the Start was accepted, the very
   * first chunk was refused before it left the host, and the program
   * reported only that the design could not be built.
   *
   * Segmented the way the Python library segments it
   * (_DATASET_UPLOAD_SEG_BYTES), so a chunk becomes the same sequence of
   * params from either host and the firmware sees one contract. */
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t seg = (uint16_t)PAPAYA_DATASET_SEG_BYTES;
  const uint8_t nsegs = (uint8_t)(((uint32_t)size + seg - 1u) / seg);
  const uint8_t nparams = (uint8_t)(2u + nsegs);

  if (nparams > PP_FUNC_PARAM_MAX_NBR)
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }

  uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                 + (uint16_t)(nsegs * PP_PARAM_INFO_SIZE)
                 + size);

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, nparams, SubFuncId, 0xFFFFu);
  FuncParam.ParamUint8 = slotId;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  FuncParam.ParamUint32 = offset;
  PrepareParam(&Command, 1u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  for (uint8_t i = 0u; i < nsegs; i++)
  {
    const uint32_t at = (uint32_t)i * (uint32_t)seg;
    const uint16_t take = ((uint32_t)size - at > (uint32_t)seg)
                              ? seg
                              : (uint16_t)((uint32_t)size - at);
    FuncParam.ParamUint8Array = (uint8_t *)&data[at];
    PrepareParam(&Command, (uint8_t)(2u + i), take, TYPE_Uint8Array, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

/** Send a {u8 slot, u32 a, u32 b} frame: commit, or a download request. */
static bool SendSlotU8U32U32(PP_SubFuncId SubFuncId, uint8_t slotId,
                             uint32_t a, uint32_t b)
{
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                 + 2u * (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE));

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 3u, SubFuncId, 0xFFFFu);
  FuncParam.ParamUint8 = slotId;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  FuncParam.ParamUint32 = a;
  PrepareParam(&Command, 1u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  FuncParam.ParamUint32 = b;
  PrepareParam(&Command, 2u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

/** Request a payload chunk, then read the payload it promised. */
static bool DownloadSlotChunk(PP_SubFuncId SubFuncId, uint8_t slotId,
                              uint32_t offset, uint16_t length, uint8_t *buffer)
{
  if ((buffer == NULL) || (length == 0u))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  /* No payload follows a refusal: reading one would consume the next
   * command's response and desynchronise the link. */
  if (false == SendSlotU8U32U32(SubFuncId, slotId, offset, (uint32_t)length))
  {
    return false;
  }
  return GetDataResponse(buffer, length);
}

/* ------------------------------------------------------------------
 * Audio recording slots
 * ------------------------------------------------------------------ */

/**
 * @brief Decode one 20-byte audio slot record.
 *
 * Like the dataset records, the list and info responses carry the same
 * fields but SWAP the first two bytes: list leads with the slot id,
 * info with the state. Getting that wrong is not loud: it silently
 * reports a written slot as empty (state 1 read as slot id, slot id 0
 * read as state Empty), which is exactly what a round-trip against the
 * board showed before this flag existed.
 *
 * The occupancy byte is a STATE, not a boolean: 2 means mid-capture.
 */
static void DecodeAudioRecord(const uint8_t *raw, bool idFirst,
                              PP_AudioSlotInfo &info)
{
  if (idFirst)
  {
    info.slotId = raw[0u];
    info.state  = (PP_AudioSlotState)raw[1u];
  }
  else
  {
    info.state  = (PP_AudioSlotState)raw[0u];
    info.slotId = raw[1u];
  }
  info.format        = ReadUint16LE(&raw[2u]);
  info.sampleRateHz  = ReadUint32LE(&raw[4u]);
  info.lengthSamples = ReadUint32LE(&raw[8u]);
  info.crc32         = ReadUint32LE(&raw[12u]);
  info.timestamp     = ReadUint32LE(&raw[16u]);
}

bool PAPAYA::listAudioSlots(PP_AudioSlotInfo *out, uint8_t capacity, uint8_t *count)
{
  if (count != nullptr) { *count = 0u; }
  if ((out == NULL) || (capacity == 0u))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(ListAudioSlots, 0xFFFFu)) { return false; }

  uint8_t payload[1u + (PP_AUDIO_SLOT_COUNT * PP_AUDIO_RECORD_WIRE_SIZE)];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  uint8_t reported = payload[0u];
  if (reported > PP_AUDIO_SLOT_COUNT) { reported = PP_AUDIO_SLOT_COUNT; }
  const uint8_t emit = (reported < capacity) ? reported : capacity;
  for (uint8_t i = 0u; i < emit; i++)
  {
    DecodeAudioRecord(&payload[1u + (i * PP_AUDIO_RECORD_WIRE_SIZE)], true, out[i]);
  }
  if (count != nullptr) { *count = emit; }
  return true;
}

bool PAPAYA::getAudioSlotInfo(uint8_t slotId, PP_AudioSlotInfo &info)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageU32(GetAudioSlotInfo, (uint32_t)slotId,
                             PP_UINT8_SIZE, TYPE_Uint8))
  {
    return false;
  }
  uint8_t payload[PP_AUDIO_RECORD_WIRE_SIZE];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }
  DecodeAudioRecord(&payload[0u], false, info);
  return true;
}

bool PAPAYA::eraseAudioSlot(uint8_t slotId)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageU32(EraseAudioSlot, (uint32_t)slotId, PP_UINT8_SIZE, TYPE_Uint8);
}

bool PAPAYA::eraseAllAudioSlots(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageQuery(EraseAllAudioSlots, 0xFFFFu);
}

bool PAPAYA::uploadAudioSlotStart(uint8_t slotId, uint16_t format,
                                  uint32_t sampleRateHz, uint32_t lengthSamples)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                 + 2u * (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE));

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 4u,
                   UploadAudioSlotStart, 0xFFFFu);
  FuncParam.ParamUint8 = slotId;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  FuncParam.ParamUint16 = format;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamUint32 = sampleRateHz;
  PrepareParam(&Command, 2u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  FuncParam.ParamUint32 = lengthSamples;
  PrepareParam(&Command, 3u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

bool PAPAYA::uploadAudioSlotChunk(uint8_t slotId, uint32_t offset,
                                  const uint8_t *data, uint16_t size)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendSlotChunk(UploadAudioSlotChunk, slotId, offset, data, size);
}

bool PAPAYA::uploadAudioSlotCommit(uint8_t slotId, uint32_t crc32,
                                   uint32_t timestampUnix)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendSlotU8U32U32(UploadAudioSlotCommit, slotId, crc32, timestampUnix);
}

bool PAPAYA::downloadAudioSlot(uint8_t slotId, uint32_t offset, uint16_t length,
                               uint8_t *buffer)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return DownloadSlotChunk(DownloadAudioSlot, slotId, offset, length, buffer);
}

/* ------------------------------------------------------------------
 * Dataset FLASH slots
 * ------------------------------------------------------------------ */

/**
 * @brief Decode one 84-byte slot record.
 *
 * The list and info responses carry the SAME fields but swap the first
 * two bytes: list leads with the slot id, info with the occupied flag.
 * That is a firmware quirk, not a choice; @p idFirst selects which.
 */
static void DecodeDatasetRecord(const uint8_t *raw, bool idFirst,
                                PP_DatasetInfo &info)
{
  if (idFirst)
  {
    info.slotId = raw[0u];
    info.occupied = (raw[1u] == 1u);
  }
  else
  {
    info.occupied = (raw[0u] == 1u);
    info.slotId = raw[1u];
  }
  info.format        = ReadUint16LE(&raw[2u]);
  info.sampleRateHz  = ReadUint32LE(&raw[4u]);
  info.lengthSamples = ReadUint32LE(&raw[8u]);
  info.crc32         = ReadUint32LE(&raw[12u]);
  info.timestamp     = ReadUint32LE(&raw[16u]);
}

bool PAPAYA::listDatasets(PP_DatasetInfo *out, uint8_t capacity, uint8_t *count)
{
  if (count != nullptr) { *count = 0u; }
  if ((out == NULL) || (capacity == 0u))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(ListDatasets, 0xFFFFu))
  {
    return false;
  }

  /* One count byte then a record per slot. The whole maximum is read
   * even when fewer slots come back: a short read would strand the
   * remainder in the pipe and break the next command. */
  static uint8_t payload[1u + (PP_DATASET_SLOT_COUNT * PP_DATASET_RECORD_WIRE_SIZE)];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  uint8_t reported = payload[0u];
  if (reported > PP_DATASET_SLOT_COUNT) { reported = PP_DATASET_SLOT_COUNT; }
  const uint8_t emit = (reported < capacity) ? reported : capacity;

  for (uint8_t i = 0u; i < emit; i++)
  {
    DecodeDatasetRecord(&payload[1u + (i * PP_DATASET_RECORD_WIRE_SIZE)],
                        true, out[i]);
  }
  if (count != nullptr) { *count = emit; }
  return true;
}

bool PAPAYA::getDatasetInfo(uint8_t slotId, PP_DatasetInfo &info)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageU32(GetDatasetInfo, (uint32_t)slotId,
                             PP_UINT8_SIZE, TYPE_Uint8))
  {
    return false;
  }

  uint8_t payload[PP_DATASET_RECORD_WIRE_SIZE];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }
  DecodeDatasetRecord(&payload[0u], false, info);
  return true;
}

bool PAPAYA::eraseDataset(uint8_t slotId)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageU32(EraseDataset, (uint32_t)slotId, PP_UINT8_SIZE, TYPE_Uint8);
}

/* The three dataset sends, on whichever context is already active.
 *
 * Split out so signalSource::dataset() can put a recording on the board
 * itself. It is a STATIC factory: it has no PAPAYA to call, and building one
 * to get it is not an option, because constructing PAPAYA hard-resets the
 * board over USB. The context it needs is the one already active, which is
 * necessarily the board whose design is being built, because that is what
 * just created every other block in it.
 *
 * The PAPAYA methods below activate their own context and then call these,
 * so the two routes cannot drift into producing different frames. */
static bool SendDatasetStart(uint8_t slotId, uint16_t format,
                             uint32_t sampleRateHz, uint32_t lengthSamples)
{
  /* Four parameters, and there is no fifth. The frame carried an optional
   * name and does not any more: a slot header has no name field. */
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE
                 + PP_PARAM_INFO_SIZE + PP_UINT32_SIZE);

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock,
                   4u, UploadDatasetStart, 0xFFFFu);

  FuncParam.ParamUint8 = slotId;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  FuncParam.ParamUint16 = format;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamUint32 = sampleRateHz;
  PrepareParam(&Command, 2u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  FuncParam.ParamUint32 = lengthSamples;
  PrepareParam(&Command, 3u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

bool PAPAYA::uploadDatasetStart(uint8_t slotId, uint16_t format,
                                uint32_t sampleRateHz, uint32_t lengthSamples)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendDatasetStart(slotId, format, sampleRateHz, lengthSamples);
}

bool PAPAYA::uploadDatasetChunk(uint8_t slotId, uint32_t offset,
                                const uint8_t *data, uint16_t size)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendSlotChunk(UploadDatasetChunk, slotId, offset, data, size);
}

bool PAPAYA::uploadDatasetCommit(uint8_t slotId, uint32_t crc32,
                                 uint32_t timestampUnix)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendSlotU8U32U32(UploadDatasetCommit, slotId, crc32, timestampUnix);
}

/* CRC-32, zlib polynomial 0xEDB88320 reflected, computed a byte at a time.
 * The board checks the committed slot against this exact value, and
 * Python's zlib.crc32 produces it too, so all three agree on whether a
 * slot holds what the host meant to send. A table would be faster and
 * would cost 1 KB of program memory on a target that may have little to
 * spare; this runs once per upload. */
static uint32_t PapayaDatasetCrc32(const uint8_t *data, uint32_t len)
{
  uint32_t crc = 0xFFFFFFFFu;
  for (uint32_t i = 0u; i < len; i++)
  {
    crc ^= (uint32_t)data[i];
    for (uint8_t bit = 0u; bit < 8u; bit++)
    {
      crc = (crc >> 1) ^ (0xEDB88320u & (uint32_t)(-(int32_t)(crc & 1u)));
    }
  }
  return crc ^ 0xFFFFFFFFu;
}

/* Start, chunks and Commit on the active context. Both the PAPAYA method
 * and signalSource::dataset() go through here, so one recording reaches the
 * board by exactly one sequence of frames however it was asked for. */
static bool SendDatasetToActiveContext(uint8_t slotId, const float *samples,
                                       uint32_t count, uint32_t sampleRateHz)
{
  if ((samples == nullptr) || (count == 0u)) { return false; }
  if (sampleRateHz == 0u)
  {
    sampleRateHz = (uint32_t)(PapayaDesignSamplingFreq() + 0.5f);
  }
  if (sampleRateHz == 0u)
  {
    /* startDesign() has not run, so there is no rate to stamp. */
    SetDesignError(PP_DesignStatus::BadParam);
    return false;
  }
  if (count > PAPAYA_DATASET_MAX_SAMPLES) { return false; }

  const uint8_t *bytes = reinterpret_cast<const uint8_t *>(samples);
  const uint32_t total = count * 4u;

  /* No name, and nowhere for one to go: the slot header has no name field.
   * A recording is on the board because a block plays it, and that block
   * has an id. */
  if (SendDatasetStart(slotId, 0u /* float32 mono */, sampleRateHz,
                       count) == false)
  {
    return false;
  }

  uint32_t offset = 0u;
  while (offset < total)
  {
    uint32_t remaining = total - offset;
    uint16_t size = (remaining > PAPAYA_DATASET_CHUNK_BYTES)
                        ? (uint16_t)PAPAYA_DATASET_CHUNK_BYTES
                        : (uint16_t)remaining;
    if (SendSlotChunk(UploadDatasetChunk, slotId, offset,
                      &bytes[offset], size) == false)
    {
      return false;
    }
    offset += size;
  }

  if (SendSlotU8U32U32(UploadDatasetCommit, slotId,
                       PapayaDatasetCrc32(bytes, total), 0u) == false)
  {
    return false;
  }
  PapayaNoteDatasetSlot(slotId, count);
  return true;
}

bool PAPAYA::uploadDataset(uint8_t slotId, const float *samples, uint32_t count,
                           uint32_t sampleRateHz)
{
  if ((samples == nullptr) || (count == 0u)) { return false; }
  /* The design's sampling frequency, unless the caller named another. See
   * the declaration for why this is not something to pass in. */
  if (sampleRateHz == 0u)
  {
    sampleRateHz = (uint32_t)(PapayaDesignSamplingFreq() + 0.5f);
  }
  if (sampleRateHz == 0u)
  {
    /* startDesign() has not run, so there is no rate to stamp. */
    SetDesignError(PP_DesignStatus::BadParam);
    return false;
  }
  /* One slot's payload. Refusing here beats a Commit the board rejects
   * after every byte has already been sent over the wire. */
  if (count > PAPAYA_DATASET_MAX_SAMPLES) { return false; }

  const uint8_t *bytes = reinterpret_cast<const uint8_t *>(samples);
  const uint32_t total = count * 4u;

  if (uploadDatasetStart(slotId, 0u /* float32 mono */, sampleRateHz,
                         count) == false)
  {
    return false;
  }

  /* Chunked to stay inside the board's command buffer, the same step the
   * Python library uses so both produce the same sequence of frames. */
  uint32_t offset = 0u;
  while (offset < total)
  {
    uint32_t remaining = total - offset;
    uint16_t size = (remaining > PAPAYA_DATASET_CHUNK_BYTES)
                        ? (uint16_t)PAPAYA_DATASET_CHUNK_BYTES
                        : (uint16_t)remaining;
    if (uploadDatasetChunk(slotId, offset, &bytes[offset], size) == false)
    {
      return false;
    }
    offset += size;
  }

  if (uploadDatasetCommit(slotId, PapayaDatasetCrc32(bytes, total), 0u) == false)
  {
    return false;
  }
  /* What the slot now holds, so a Dataset block built from it can work out
   * its own playback rate without being told. */
  PapayaNoteDatasetSlot(slotId, count);
  return true;
}

bool PAPAYA::downloadDataset(uint8_t slotId, uint32_t offset, uint16_t length,
                             uint8_t *buffer)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return DownloadSlotChunk(DownloadDataset, slotId, offset, length, buffer);
}

/* ------------------------------------------------------------------
 * Live probe reads (push model)
 * ------------------------------------------------------------------ */

/** Registered by PAPAYA::setPacketReader; null until a port supplies one. */
static PP_TransportRxPacketFn g_packetReader = nullptr;

/** Scratch for one pushed packet: opcode + samples for every probe.
 *  Sized by PAPAYA_PUSH_PROBE_BUFFER_BYTES so an SPI-only port can
 *  reclaim the ~8 KB it will never use. */
static uint8_t g_packetBuffer[PAPAYA_PUSH_PROBE_BUFFER_BYTES];

void PAPAYA::setPacketReader(PP_TransportRxPacketFn reader)
{
  g_packetReader = reader;
}

/**
 * @brief Decode one pushed batch into the probe buffer.
 *
 * Wire shape, matching the Python transport:
 *
 *   [PP_CMD_READ] [p0_s0 .. p0_s{S-1}] [p1_s0 .. p1_s{S-1}] ...
 *
 * S is not transmitted: it is derived from the packet length, which is
 * why a packet reader must never hand back a partial transfer. Only the
 * NEWEST sample of each probe (the last of its group) is kept, because
 * that is what probe::getVal() reports.
 *
 * @return samples-per-probe on success, 0 if the packet was not a
 *         well-formed probe batch (wrong opcode, short, or not a whole
 *         number of samples per probe).
 */
static uint16_t DecodeProbeBatch(const uint8_t *packet, uint16_t length,
                                 uint16_t probeCount)
{
  if ((packet == NULL) || (probeCount == 0u) || (length < 2u))
  {
    return 0u;
  }
  if (PP_CMD_READ != packet[0u])
  {
    return 0u;
  }

  const uint16_t payload = (uint16_t)(length - 1u);
  const uint16_t bytesPerProbe = (uint16_t)(payload / probeCount);
  if ((bytesPerProbe < PP_REAL_SIZE) ||
      ((uint16_t)(bytesPerProbe * probeCount) != payload) ||
      (0u != (bytesPerProbe % PP_REAL_SIZE)))
  {
    return 0u;
  }

  const uint16_t samplesPerProbe = (uint16_t)(bytesPerProbe / PP_REAL_SIZE);

  for (uint16_t probeIdx = 0u; probeIdx < probeCount; probeIdx++)
  {
    /* Last sample of this probe's group is the newest one. */
    const uint16_t offset =
        (uint16_t)(1u + (probeIdx * bytesPerProbe) +
                   ((samplesPerProbe - 1u) * PP_REAL_SIZE));
    memcpy(&ProbesBuffer[probeIdx * PP_REAL_SIZE], &packet[offset], PP_REAL_SIZE);
  }

  return samplesPerProbe;
}

/**
 * @brief Shared body of the two live reads.
 * @param drain When true, keep reading until the queue is empty and use
 *              the last batch; otherwise take the first one.
 */
static bool ReadProbeBatch(bool drain, PP_ProbeRead *result, uint32_t timeoutMs)
{
  if (result != NULL)
  {
    result->ok = false;
    result->samplesPerProbe = 0u;
    result->ageBatches = 0u;
  }

  if (g_packetReader == nullptr)
  {
    /* No push transport here (SPI). Saying so beats silently returning
     * whatever getProbes() last left in the buffer. */
    currentDesignStatus = PP_DesignStatus::BadRequest;
    return false;
  }
  if (sizeof(g_packetBuffer) < 2u)
  {
    /* Built with PAPAYA_PUSH_PROBE_BUFFER_BYTES reclaimed — the MCU
     * profile's default, because the push model is USB-only and a
     * microcontroller reaches the board over SPI. A caller that has
     * nonetheless registered a packet reader is told no, rather than
     * being handed a one-byte read that could never decode. Raise the
     * macro in papaya_target_config.h to enable this path. */
    currentDesignStatus = PP_DesignStatus::BadRequest;
    return false;
  }
  if (false == DataExchangeStarted)
  {
    currentDesignStatus = PP_DesignStatus::BadRequest;
    return false;
  }

  const uint16_t probeCount = probe::currentProbeIdx;
  if ((probeCount == 0u) || (probeCount > PP_MAX_PROBES_NUMBER))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }

  uint16_t samples = 0u;
  uint16_t skipped = 0u;
  const unsigned long deadline = transportMillis() + timeoutMs;

  for (;;)
  {
    /* Only the FIRST read waits: once a batch is in hand, a drain must
     * not sit out the whole timeout again just to prove the queue is
     * empty. */
    const uint32_t wait = (samples == 0u) ? timeoutMs : 0u;
    const uint16_t length =
        g_packetReader(&g_packetBuffer[0u], (uint16_t)sizeof(g_packetBuffer), wait);
    if (0u == length)
    {
      break;
    }

    const uint16_t decoded =
        DecodeProbeBatch(&g_packetBuffer[0u], length, probeCount);
    if (0u == decoded)
    {
      /* Not a probe batch: a stray, or a vector payload on the same
       * pipe. Skip it rather than decoding garbage into the probe
       * values, but DO NOT retry forever: a board pushing a steady
       * stream this decoder rejects would otherwise spin here with the
       * caller's timeout never consulted, which hangs the program
       * outright rather than failing. */
      if (transportMillis() >= deadline)
      {
        break;
      }
      continue;
    }

    if (samples != 0u)
    {
      skipped++;
    }
    samples = decoded;

    if (false == drain)
    {
      break;
    }
  }

  if (0u == samples)
  {
    return false;
  }

  if (result != NULL)
  {
    result->ok = true;
    result->samplesPerProbe = samples;
    result->ageBatches = skipped;
  }
  return true;
}

bool PAPAYA::readProbesLive(PP_ProbeRead *result, uint32_t timeoutMs)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return ReadProbeBatch(false, result, timeoutMs);
}

bool PAPAYA::readProbesLatest(PP_ProbeRead *result, uint32_t timeoutMs)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return ReadProbeBatch(true, result, timeoutMs);
}

/* No readVectProbesLive(): the board does not auto-push vector data
 * under the framing this transport uses. Vectors are auto-pushed only
 * under the newer V2 monitor framing, whose frame is
 * [opcode][seq][len][payload][crc32] rather than the [opcode][payload]
 * shape the scalar batches arrive in. Measured: a design with one
 * 512-byte vector probe produced no payload at all.
 *
 * Vector data under this framing is READ, not pushed: getVectorProbes()
 * requests it and is the correct call. Shipping a live variant that can
 * only ever return false would be exactly the "looks supported, silently
 * returns nothing" defect this library keeps removing. */

bool PAPAYA::describeVectProbes(PP_VectorProbeDesc *out, uint8_t capacity,
                                uint8_t *count)
{
  if (count != nullptr) { *count = 0u; }
  if ((out == NULL) || (capacity == 0u))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(DescribeVectProbes, 0xFFFFu))
  {
    return false;
  }

  /* 4-byte header then one 24-byte descriptor per probe. The whole
   * maximum is read even when fewer come back: a short read would
   * strand the remainder and break the next command. */
  uint8_t payload[4u + (PP_MAX_VECTOR_PROBES_NUMBER *
                        PP_VECTOR_PROBE_DESC_WIRE_SIZE)];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  uint8_t reported = payload[0u];
  /* payload[1] is the protocol version and payload[2] the board's
   * maximum; neither is surfaced, but a count beyond our own ceiling is
   * clamped rather than trusted. */
  if (reported > PP_MAX_VECTOR_PROBES_NUMBER)
  {
    reported = (uint8_t)PP_MAX_VECTOR_PROBES_NUMBER;
  }
  const uint8_t emit = (reported < capacity) ? reported : capacity;

  for (uint8_t i = 0u; i < emit; i++)
  {
    const uint8_t *rec = &payload[4u + (i * PP_VECTOR_PROBE_DESC_WIRE_SIZE)];
    out[i].index = ReadUint16LE(&rec[0u]);
    out[i].lines = ReadUint16LE(&rec[2u]);
    out[i].rows  = ReadUint16LE(&rec[4u]);
    out[i].bytes = ReadUint16LE(&rec[6u]);
    memcpy(&out[i].label[0u], &rec[8u], PP_VECTOR_PROBE_LABEL_MAX);
    out[i].label[PP_VECTOR_PROBE_LABEL_MAX - 1u] = '\0';
  }
  if (count != nullptr) { *count = emit; }
  return true;
}

/* ------------------------------------------------------------------
 * Board / design queries
 *
 * Shape shared by all of them: send a status-only Manageblock command,
 * check it succeeded, then read the payload the firmware queued behind
 * the response. The payload is read ONLY on success: reading when the
 * board rejected the command would consume the next command's response
 * instead and desynchronise the link.
 * ------------------------------------------------------------------ */

/**
 * @brief Send a parameterless Manageblock command and report success.
 *
 * @param SubFuncId Which management command.
 * @param blockId   Target block, or 0xFFFF for "the design".
 */
static bool SendManageQuery(PP_SubFuncId SubFuncId, uint16_t blockId)
{
  PP_CommandInfo Command;
  const uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, SubFuncId, blockId);
  HandleCmd(&Command, SerialDataSize);

  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

bool PAPAYA::getBoardInfo(PP_BoardInfo &info)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(GetBoardInfo, 0xFFFFu))
  {
    return false;
  }

  uint8_t payload[PP_BOARD_INFO_WIRE_SIZE];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  info.partNumber = ReadUint16LE(&payload[0u]);
  memcpy(&info.uniqueId[0u], &payload[2u], PP_BOARD_UNIQUE_ID_SIZE);
  return true;
}

bool PAPAYA::getDesignInstrumentation(PP_DesignInstrumentation &info)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(GetDesignInstrumentation, 0xFFFFu))
  {
    return false;
  }

  uint8_t payload[PP_DESIGN_INSTRUMENTATION_WIRE_SIZE];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  /* Offsets are the firmware's documented little-endian layout; bytes
   * 24..27 and 31 are reserved and deliberately not surfaced. */
  info.cpuCycleUs          = ReadUint32LE(&payload[0u]);
  info.periodUs            = ReadUint32LE(&payload[4u]);
  info.appMemUsedBytes     = ReadUint32LE(&payload[8u]);
  info.appMemFreeBytes     = ReadUint32LE(&payload[12u]);
  info.appMemTotalBytes    = ReadUint32LE(&payload[16u]);
  info.appMemHighWatermark = ReadUint32LE(&payload[20u]);
  info.cpuLoadPctX100      = ReadUint16LE(&payload[28u]);
  info.appMemUsedPct       = payload[30u];
  return true;
}

bool PAPAYA::getDesignInfo(char *buffer, uint16_t capacity)
{
  /* Must be able to take the board's whole maximum. Reading less than
   * was sent strands the remainder in the pipe, where the NEXT command
   * reads it as its own response, after which every command fails and
   * the board looks dead. Measured on hardware, not theorised. */
  if ((buffer == NULL) || (capacity < (PP_DESIGN_INFO_MAX_SIZE + 1u)))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  buffer[0u] = '\0';

  if (false == SendManageQuery(GetDesignInfo, 0xFFFFu))
  {
    return false;
  }

  /* Asking for more than the board sent is harmless (the transfer ends
   * on its own short packet), so the maximum is always requested. */
  if (false == GetDataResponse((uint8_t *)buffer, (uint16_t)PP_DESIGN_INFO_MAX_SIZE))
  {
    return false;
  }
  buffer[PP_DESIGN_INFO_MAX_SIZE] = '\0';
  return true;
}

/* ------------------------------------------------------------------
 * Offline capture (trace) and diagnostics
 * ------------------------------------------------------------------ */

/**
 * @brief Send a Manageblock command carrying one unsigned parameter.
 */
static bool SendManageU32(PP_SubFuncId SubFuncId, uint32_t value,
                          uint16_t paramSize, PP_FuncParamId paramType)
{
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + paramSize);

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, SubFuncId, 0xFFFFu);

  if (PP_UINT8_SIZE == paramSize)
  {
    FuncParam.ParamUint8 = (uint8_t)value;
  }
  else
  {
    FuncParam.ParamUint32 = value;
  }
  PrepareParam(&Command, 0u, paramSize, paramType, &FuncParam);

  HandleCmd(&Command, SerialDataSize);

  return (PP_ComStatus::ComOk == currentComStatus) &&
         (PP_DesignStatus::DesignOk == currentDesignStatus);
}

bool PAPAYA::setMonitorMode(PP_MonitorMode mode)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageU32(SetMonitorMode, (uint32_t)mode, PP_UINT8_SIZE, TYPE_Uint8);
}

bool PAPAYA::setTraceSize(uint32_t totalSamples)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageU32(SetTraceSize, totalSamples, PP_UINT32_SIZE, TYPE_Uint32);
}

/* No setLiveRate(): the firmware's SetLiveRate case is marked DEPRECATED
 * and returns BadParam unconditionally: samples-per-probe is fixed on
 * the board. Python still exposes one; mirroring it here would have
 * added a call that can only fail, and because the board LATCHES a
 * failure it would also break whatever was issued next. Confirmed
 * against hardware. */

bool PAPAYA::getCaptureStatus(PP_CaptureStatus &status)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  if (false == SendManageQuery(GetCaptureStatus, 0xFFFFu))
  {
    return false;
  }

  uint8_t payload[PP_CAPTURE_STATUS_WIRE_SIZE];
  if (false == GetDataResponse(&payload[0u], (uint16_t)sizeof(payload)))
  {
    return false;
  }

  status.capturedSamples  = ReadUint32LE(&payload[0u]);
  status.requestedSamples = ReadUint32LE(&payload[4u]);
  status.complete         = payload[8u];
  return true;
}

bool PAPAYA::downloadTrace(uint32_t offset, uint16_t length, uint8_t *buffer)
{
  if ((buffer == NULL) || (0u == length))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize =
      (uint16_t)(PP_FIXED_SIZE + 2u * (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE));

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u, DownloadTrace, 0xFFFFu);

  FuncParam.ParamUint32 = offset;
  PrepareParam(&Command, 0u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  FuncParam.ParamUint32 = (uint32_t)length;
  PrepareParam(&Command, 1u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  HandleCmd(&Command, SerialDataSize);

  /* The board refuses a range that runs past the end of the recorded
   * trace, so a bad status here means "no payload is coming"; reading
   * one anyway would consume the next command's response. */
  if ((PP_ComStatus::ComOk != currentComStatus) ||
      (PP_DesignStatus::DesignOk != currentDesignStatus))
  {
    return false;
  }

  return GetDataResponse(buffer, length);
}

bool PAPAYA::getDebugLog(char *buffer, uint32_t capacity)
{
  /* Same rule as getDesignInfo, at the log's much larger scale: the
   * board sends up to 16 KB and a short read wedges the link. This is
   * the exact failure the firmware itself warns about beside its
   * GetDebugLog case: "every command AFTER a successful GetDebugLog
   * stops getting a response ... the board appears dead". Measured
   * here before it was understood. */
  if ((buffer == NULL) || (capacity < (PP_DEBUG_LOG_MAX_SIZE + 1u)))
  {
    currentDesignStatus = PP_DesignStatus::BadParam;
    return false;
  }
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);

  buffer[0u] = '\0';

  if (false == SendManageQuery(GetDebugLog, 0xFFFFu))
  {
    return false;
  }

  /* Taken in chunks only because GetDataResponse counts bytes in a
   * uint16_t; every chunk is still consumed, so the pipe ends empty. */
  uint32_t done = 0u;
  while (done < PP_DEBUG_LOG_MAX_SIZE)
  {
    const uint32_t remaining = PP_DEBUG_LOG_MAX_SIZE - done;
    const uint16_t chunk =
        (remaining > 0x8000u) ? (uint16_t)0x8000u : (uint16_t)remaining;
    if (false == GetDataResponse((uint8_t *)&buffer[done], chunk))
    {
      return false;
    }
    done += chunk;
  }
  buffer[PP_DEBUG_LOG_MAX_SIZE] = '\0';
  return true;
}

bool PAPAYA::clearDebugLog(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false) { return false; }
  ActivateContext(this->_contextSlot);
  return SendManageQuery(ClearDebugLog, 0xFFFFu);
}

/* ------------------------------------------------------------------
 * Describing the loaded design (what interaction code attaches to)
 * ------------------------------------------------------------------ */

/**
 * @brief Copy one comma-separated group into a fixed name table.
 *
 * @param cursor  Points just past the opening brace; advanced past the
 *                closing one.
 * @param names   Destination table, or NULL to parse values instead.
 * @param values  Destination floats, or NULL to parse names.
 * @return how many entries were taken.
 */
static uint8_t ParseDesignGroup(const char *&cursor,
                                char (*names)[PP_REMOTE_NAME_MAX],
                                float *values)
{
  uint8_t count = 0u;
  char field[PP_REMOTE_NAME_MAX];
  uint8_t used = 0u;

  while ((*cursor != '\0') && (*cursor != '}'))
  {
    const char ch = *cursor++;
    if (ch == ',')
    {
      field[used] = '\0';
      if ((used > 0u) && (count < PP_REMOTE_MAX_NAMES))
      {
        if (names != NULL) { memcpy(names[count], field, used + 1u); }
        if (values != NULL) { values[count] = (float)atof(field); }
        count++;
      }
      used = 0u;
      continue;
    }
    if (used < (PP_REMOTE_NAME_MAX - 1u)) { field[used++] = ch; }
  }
  field[used] = '\0';
  if ((used > 0u) && (count < PP_REMOTE_MAX_NAMES))
  {
    if (names != NULL) { memcpy(names[count], field, used + 1u); }
    if (values != NULL) { values[count] = (float)atof(field); }
    count++;
  }
  if (*cursor == '}') { cursor++; }
  return count;
}

/** Advance to just past the next '{'. Returns false if there is none. */
static bool SeekDesignGroup(const char *&cursor)
{
  while ((*cursor != '\0') && (*cursor != '{')) { cursor++; }
  if (*cursor != '{') { return false; }
  cursor++;
  return true;
}

bool PAPAYA::describeDesign(PP_RemoteDesign &design)
{
  memset(&design, 0, sizeof(design));

  /* The firmware's buffer, not the caller's: a short read of a
   * variable-length payload strands the remainder in the pipe. */
  static char info[PP_DESIGN_INFO_MAX_SIZE + 1u];
  if (false == this->getDesignInfo(&info[0u], (uint16_t)sizeof(info)))
  {
    return false;
  }

  /* Wire shape of the design-info text the board returns:
   *   {Fs,samplesPerProbe},{input names},{input values},{probe names} */
  const char *cursor = &info[0u];

  if (false == SeekDesignGroup(cursor)) { return false; }
  char header[PP_REMOTE_NAME_MAX];
  float headerValues[2] = {0.0f, 0.0f};
  (void)header;
  const uint8_t nHeader = ParseDesignGroup(cursor, NULL, &headerValues[0u]);
  if (nHeader == 0u) { return false; }
  design.sampleRateHz = headerValues[0u];
  design.samplesPerProbe = (uint16_t)headerValues[1u];

  if (false == SeekDesignGroup(cursor)) { return false; }
  design.inputCount = ParseDesignGroup(cursor, design.inputNames, NULL);

  if (false == SeekDesignGroup(cursor)) { return false; }
  (void)ParseDesignGroup(cursor, NULL, design.inputValues);

  if (false == SeekDesignGroup(cursor)) { return false; }
  design.probeCount = ParseDesignGroup(cursor, design.probeNames, NULL);

  /* Teach the library how wide the running design is.
   *
   * This is what makes interaction code work without containing the
   * diagram. The live reads size their request from
   * probe::currentProbeIdx, which normally grows as the script CREATES
   * probe objects, so a program that did not build the design had zero
   * and could read nothing. Discovery supplies the same counts from the
   * board instead, which is the whole point: attach, ask, work. */
  if (design.probeCount > 0u)
  {
    probe::currentProbeIdx = design.probeCount;
  }
  if (design.inputCount > 0u)
  {
    input::currentInputIdx = design.inputCount;
  }

  return true;
}

float probe::valueAt(uint8_t index)
{
  if (index >= (uint8_t)PP_MAX_PROBES_NUMBER)
  {
    return 0.0f;
  }
  if (probe::currentProbeIdx <= index)
  {
    probe::currentProbeIdx = (uint8_t)(index + 1u);
  }
  float value = 0.0f;
  memcpy((void *)&value, (const void *)&ProbesBuffer[index * PP_REAL_SIZE],
         PP_REAL_SIZE);
  return value;
}

void input::setValueAt(uint8_t index, float value)
{
  if (index >= (uint8_t)PP_MAX_INPUTS_NUMBER)
  {
    return;
  }
  if (input::currentInputIdx <= index)
  {
    input::currentInputIdx = (uint8_t)(index + 1u);
  }
  memcpy((void *)&InputsBuffer[index * PP_REAL_SIZE], (const void *)&value,
         PP_REAL_SIZE);
}

static int FindRemoteName(const char (*table)[PP_REMOTE_NAME_MAX],
                          uint8_t count, const char *name)
{
  if (name == NULL) { return -1; }
  for (uint8_t i = 0u; i < count; i++)
  {
    if (0 == strcmp(table[i], name)) { return (int)i; }
  }
  return -1;
}

int PAPAYA::remoteInputIndex(const PP_RemoteDesign &design, const char *name)
{
  return FindRemoteName(design.inputNames, design.inputCount, name);
}

int PAPAYA::remoteProbeIndex(const PP_RemoteDesign &design, const char *name)
{
  return FindRemoteName(design.probeNames, design.probeCount, name);
}

bool PAPAYA::signalSourceManualTrigger(uint16_t blockId)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return false;
  }
  ActivateContext(this->_contextSlot);

  /* Status-only: no data response to read. */
  return SendManageQuery(SignalSourceManualTrigger, blockId);
}

uint16_t PAPAYA::getSequenceNumber(void)
{
  if (IsValidContextSlot(this->_contextSlot))
  {
    ActivateContext(this->_contextSlot);
  }

  return SequenceNumber;
}

/* ---- EEPROM App Storage manage methods ---- */

void PAPAYA::enableStorage(const char* label)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t labelLen = 0u;
  while (label[labelLen] != '\0' && labelLen < PP_EEP_APP_LABEL_MAX_SIZE) labelLen++;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + labelLen;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, EnableStorage, 0xFFFF);

  FuncParam.ParamString = (char*)label;
  PrepareParam(&Command, 0u, labelLen, TYPE_String, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::commitToEeprom(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, CommitToEeprom, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::loadApp(uint16_t appId)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, LoadApp, 0xFFFF);

  FuncParam.ParamUint16 = appId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::loadApp(uint16_t appId, bool autoStart)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u, LoadApp, 0xFFFF);

  FuncParam.ParamUint16 = appId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  FuncParam.ParamUint8 = autoStart ? 1u : 0u;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::dumpApp(uint16_t appId)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, DumpApp, 0xFFFF);

  FuncParam.ParamUint16 = appId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::uploadApp(uint16_t appId, const uint8_t* data, uint16_t length)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                            PP_PARAM_INFO_SIZE + length;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u, UploadApp, 0xFFFF);

  FuncParam.ParamUint16 = appId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  FuncParam.ParamUint8Array = (uint8_t*)data;
  PrepareParam(&Command, 1u, length, TYPE_Uint8Array, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::abortStorage(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, AbortStorage, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::eraseAll(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, EraseAll, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::setBootApp(uint16_t bootId, bool autoLoad)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u, SetBootApp, 0xFFFF);

  FuncParam.ParamUint16 = bootId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  FuncParam.ParamUint8 = autoLoad ? 1u : 0u;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::getBootCfg(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, GetBootCfg, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::deleteApp(uint16_t appId)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, DeleteApp, 0xFFFF);

  FuncParam.ParamUint16 = appId;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::listApps(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, ListApps, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::syncEeprom(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, SyncEeprom, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::mcuReset(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, McuReset, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::softReset(void)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  uint16_t SerialDataSize = PP_FIXED_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 0u, SoftReset, 0xFFFF);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::setFreqInCh2Source(uint8_t channel, uint8_t source)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 2u,
                   SetFreqInCh2Source, 0xFFFF);

  FuncParam.ParamUint8 = channel;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  FuncParam.ParamUint8 = source;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

void PAPAYA::setFreqInSwapPins(uint8_t channel)
{
  if (IsValidContextSlot(this->_contextSlot) == false)
  {
    return;
  }

  ActivateContext(this->_contextSlot);
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u,
                   SetFreqInSwapPins, 0xFFFF);

  FuncParam.ParamUint8 = channel;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

PP_SubFuncId getButterSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewButterLow;
  }
  break;
  case passHigh:
  {
    retval = NewButterHigh;
  }
  break;
  case passBand:
  {
    retval = NewButterBand;
  }
  break;
  case stopBand:
  {
    retval = NewButterStop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getButterBqSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewBiquadButterLow;
  }
  break;
  case passHigh:
  {
    retval = NewBiquadButterHigh;
  }
  break;
  case passBand:
  {
    retval = NewBiquadButterBand;
  }
  break;
  case stopBand:
  {
    retval = NewBiquadButterStop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getCheby1SubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewChebyshev1Low;
  }
  break;
  case passHigh:
  {
    retval = NewChebyshev1High;
  }
  break;
  case passBand:
  {
    retval = NewChebyshev1Band;
  }
  break;
  case stopBand:
  {
    retval = NewChebyshev1Stop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getCheby1BqSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewBiquadCheby1Low;
  }
  break;
  case passHigh:
  {
    retval = NewBiquadCheby1High;
  }
  break;
  case passBand:
  {
    retval = NewBiquadCheby1Band;
  }
  break;
  case stopBand:
  {
    retval = NewBiquadCheby1Stop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getCheby2SubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewChebyshev2Low;
  }
  break;
  case passHigh:
  {
    retval = NewChebyshev2High;
  }
  break;
  case passBand:
  {
    retval = NewChebyshev2Band;
  }
  break;
  case stopBand:
  {
    retval = NewChebyshev2Stop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getCheby2BqSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewBiquadCheby2Low;
  }
  break;
  case passHigh:
  {
    retval = NewBiquadCheby2High;
  }
  break;
  case passBand:
  {
    retval = NewBiquadCheby2Band;
  }
  break;
  case stopBand:
  {
    retval = NewBiquadCheby2Stop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getEllipSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewEllipLow;
  }
  break;
  case passHigh:
  {
    retval = NewEllipHigh;
  }
  break;
  case passBand:
  {
    retval = NewEllipBand;
  }
  break;
  case stopBand:
  {
    retval = NewEllipStop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}

PP_SubFuncId getEllipBqSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewBiquadEllipLow;
  }
  break;
  case passHigh:
  {
    retval = NewBiquadEllipHigh;
  }
  break;
  case passBand:
  {
    retval = NewBiquadEllipBand;
  }
  break;
  case stopBand:
  {
    retval = NewBiquadEllipStop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}
PP_SubFuncId getFirSubFuncId(PP_FilterType ftype)
{
  PP_SubFuncId retval = NoSubFuncId;

  switch (ftype)
  {
  case passLow:
  {
    retval = NewFirLow;
  }
  break;
  case passHigh:
  {
    retval = NewFirHigh;
  }
  break;
  case passBand:
  {
    retval = NewFirBand;
  }
  break;
  case stopBand:
  {
    retval = NewFirStop;
  }
  break;
  default:
  {
  }
  break;
  };

  return retval;
}
/* System Class ########################################################################################################## */
tf::tf()
{
  BindObjectToActiveContext(this->contextSlot);
};

uint16_t tf::getId()
{
  return this->id;
}

void tf::setId(uint16_t id)
{
  this->id = id;
}

uint8_t tf::getContextSlot() const
{
  return this->contextSlot;
}

void tf::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

void tf::operator>(tf Dst) // Sys2Sys
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), 0xFF, LinkSys2Sys);
}

void tf::operator>(probe &Dst) // Sys2Probe
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), 0xFF, LinkSys2Probe);
  Dst.addToQueue();
}

void tf::operator>(node Dst) // Sys2Node
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), Dst.getActiveInIdx(), LinkSys2Node);
}

void tf::operator>(macro Dst) // Sys2Macro
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), Dst.getActiveInIdx(), LinkSys2Macro);
}

void tf::operator>>(VectorProbe& Dst) // Sys2VectorProbe
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), 0xFF, LinkSys2VectorProbe);

  /* Only commit host-side bookkeeping if the firmware accepted the
   * link. Otherwise VectorProbeBytes drifts past CachedVectProbesBytes
   * and every subsequent getVectorProbes() reads misaligned data. */
  if (currentDesignStatus != PP_DesignStatus::DesignOk)
  {
    return;
  }

  /* Stage data-shape; addToQueue() owns the buffer-offset assignment
   * and VectorProbeBytes accumulation, and is idempotent against a
   * probe being linked from more than one source. */
  Dst.dataLines = this->dataLines;
  Dst.dataRaw   = this->dataRaw;
  Dst.addToQueue();
}

tf::tf(const char *numerator, const char *denominator)
{
  BindObjectToActiveContext(this->contextSlot);
  PP_FuncParam FuncParam;
  uint16_t param1_size;
  uint16_t param2_size;

  if ((TryGetCStringPayloadSize(numerator, param1_size) == false) ||
      (TryGetCStringPayloadSize(denominator, param2_size) == false))
  {
    return;
  }

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + param1_size +
                            PP_PARAM_INFO_SIZE + param2_size;

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentSysId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewSys, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamString = numerator;
  PrepareParam(&Command, 0u, param1_size, TYPE_String, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamString = denominator;
  PrepareParam(&Command, 1u, param2_size, TYPE_String, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

tf::tf(float *numerator, uint8_t numSize, float *denominator, uint8_t denomSize)
{
  BindObjectToActiveContext(this->contextSlot);
  PP_FuncParam FuncParam;
  uint8_t param1_size = numSize * PP_REAL_SIZE;
  uint8_t param3_size = denomSize * PP_REAL_SIZE;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + param1_size +
                            PP_PARAM_INFO_SIZE + param3_size +
                            2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentSysId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewSysLightC, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamRealArray = numerator;
  PrepareParam(&Command, 0u, param1_size, TYPE_RealArray, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = numSize;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamRealArray = denominator;
  PrepareParam(&Command, 2u, param3_size, TYPE_RealArray, &FuncParam);

  /* 5. Prepare Param_4 */
  FuncParam.ParamUint8 = denomSize;
  PrepareParam(&Command, 3u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 6. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

tfd::tfd(float *numerator, float *denominator, uint8_t sysord)
{
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  // An order-N filter has N+1 coefficients (b0..bN, a0..aN). The board
  // reserves (sysord+1) floats per coefficient array and its IIR routine
  // reads indices 0..sysord inclusive. Sending only sysord*PP_REAL_SIZE
  // bytes leaves the last coefficient uninitialised on the board and
  // silently degrades the filter (e.g. an order-2 stable Butterworth
  // turns into an order-1 unstable response on the board).
  uint8_t param1_size = (sysord + 1u) * PP_REAL_SIZE;
  uint8_t param2_size = (sysord + 1u) * PP_REAL_SIZE;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + param1_size +
                            PP_PARAM_INFO_SIZE + param2_size +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewSysLightD, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamRealArray = numerator;
  PrepareParam(&Command, 0u, param1_size, TYPE_RealArray, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamRealArray = denominator;
  PrepareParam(&Command, 1u, param2_size, TYPE_RealArray, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamUint8 = sysord;

  PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

amOscillator::amOscillator(PP_WaveForm waveform, float freq, float phaseshift)
{
  /* Firmware reads exactly 2 floats (frequency, phase shift).  The shape
   * (NewSine / NewTriangle / NewSquare / NewSawtooth) is encoded in the
   * subfunc id.  Declaring NbrOfParams=3 would size the payload for a
   * third PrepareParam slot that's never set, leaving an uninitialised
   * descriptor + 4 garbage bytes in the wire frame. */
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)waveform, this->getId());

  /* 2. Prepare Param_1 (frequency) */
  FuncParam.ParamReal = freq;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 (phase shift) */
  FuncParam.ParamReal = phaseshift;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}


/* ============================================================
 *  signalSource: unified waveform engine
 * ============================================================
 * Wire layout (positional, matches papaya.signal_source):
 *     pos 0: shape       (u16, WaveShape)
 *     pos 1: mode        (u16, WaveMode)
 *     pos 2: trig_pol    (u16, WaveTrigPol)
 *     pos 3: n_periods   (u32, 0 = perpetual)
 *     pos 4: amplitude   (f32)
 *     pos 5: offset      (f32)
 *     pos 6+:            shape-specific (in _SHAPE_PARAM_LAYOUT order)
 *
 * The implementation below builds exactly the wire format the board's
 * waveform decoder expects.
 */

namespace pp_wave_detail {

/* Tiny TLV-like accumulator. We don't truly use TLV (every param's
 * type is implied by its position), but this helper centralises the
 * PrepareParam pattern so each factory below is just a list of
 * (type, size, value) appends. */
struct Builder {
  uint16_t serial_size;
  uint8_t  n_params;
  PP_FuncParam fp;

  Builder() : serial_size(PP_FIXED_SIZE), n_params(0) {}

  uint16_t add_u16(uint16_t v) { fp.ParamUint16 = v; return _push(TYPE_Uint16, PP_UINT16_SIZE, &fp); }
  uint16_t add_u8 (uint8_t  v) { fp.ParamUint8  = v; return _push(TYPE_Uint8,  PP_UINT8_SIZE,  &fp); }
  uint16_t add_u32(uint32_t v) { fp.ParamUint32 = v; return _push(TYPE_Uint32, PP_UINT32_SIZE, &fp); }
  uint16_t add_f32(float    v) { fp.ParamReal   = v; return _push(TYPE_Real,   PP_REAL_SIZE,   &fp); }

  void add_header(WaveShape shape, WaveMode mode, WaveTrigPol pol,
                  uint32_t n_periods, float amplitude, float offset) {
    add_u16((uint16_t)shape);
    add_u16((uint16_t)mode);
    add_u16((uint16_t)pol);
    add_u32(n_periods);
    add_f32(amplitude);
    add_f32(offset);
  }

private:
  /* Reserves space + remembers the descriptor; the actual write happens
   * after HandleCmd has the full SerialDataSize. We re-walk in commit(). */
  struct Entry { PP_FuncParamId t; uint16_t sz; PP_FuncParam fp; };
  Entry _entries[24];

  uint16_t _push(PP_FuncParamId t, uint16_t sz, const PP_FuncParam *fpv) {
    if (n_params >= 24) return 0; /* defensive cap */
    _entries[n_params].t  = t;
    _entries[n_params].sz = sz;
    _entries[n_params].fp = *fpv;
    n_params++;
    serial_size += PP_PARAM_INFO_SIZE + sz;
    return n_params;
  }

public:
  void commit(uint16_t blockId) {
    PrepareCmdHeader(&Command, serial_size, Createblock, n_params,
                     NewSignalSource, blockId);
    for (uint8_t i = 0; i < n_params; ++i) {
      PrepareParam(&Command, i, _entries[i].sz, _entries[i].t, &_entries[i].fp);
    }
    HandleCmd(&Command, serial_size);
  }
};

} // namespace pp_wave_detail


signalSource::signalSource(WaveShape shape, float amplitude, float offset,
                            WaveMode mode, uint32_t n_periods, WaveTrigPol pol,
                            bool emitFrame)
{
  /* Bare ctor: header only (no shape-specific params). emitFrame=true
   * sends the header-only create frame (correct for DC). The static
   * factories pass emitFrame=false: they allocate the id here, then emit
   * a single frame with header + shape params: sending it from the ctor
   * too would create the block twice on the firmware (NbrOfParams
   * mismatch -> BadParam). */
  this->setId(currentSysId++);
  if (emitFrame)
  {
    pp_wave_detail::Builder b;
    b.add_header(shape, mode, pol, n_periods, amplitude, offset);
    b.commit(this->getId());
  }
}

#define SS_FACTORY_BEGIN(shape_enum) \
  signalSource s(shape_enum, amplitude, offset, mode, n_periods, trig_pol, /*emitFrame=*/false); \
  pp_wave_detail::Builder b; \
  b.add_header(shape_enum, mode, trig_pol, n_periods, amplitude, offset);

#define SS_FACTORY_END  b.commit(s.getId()); return s;

signalSource signalSource::sine(float freq, float phase, WaveMode mode,
                                 uint32_t n_periods, WaveTrigPol trig_pol,
                                 float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Sine)
  b.add_f32(freq); b.add_f32(phase);
  SS_FACTORY_END
}

signalSource signalSource::square(float freq, float phase, WaveMode mode,
                                   uint32_t n_periods, WaveTrigPol trig_pol,
                                   float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Square)
  b.add_f32(freq); b.add_f32(phase);
  SS_FACTORY_END
}

signalSource signalSource::triangle(float freq, float phase, float symmetry,
                                     WaveMode mode, uint32_t n_periods,
                                     WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Triangle)
  b.add_f32(freq); b.add_f32(phase); b.add_f32(symmetry);
  SS_FACTORY_END
}

signalSource signalSource::sawtooth(float freq, float phase, uint8_t direction,
                                     WaveMode mode, uint32_t n_periods,
                                     WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Sawtooth)
  b.add_f32(freq); b.add_f32(phase); b.add_u8(direction);
  SS_FACTORY_END
}

signalSource signalSource::pulse(float freq, float duty, float phase,
                                  WaveMode mode, uint32_t n_periods,
                                  WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Pulse)
  b.add_f32(freq); b.add_f32(phase); b.add_f32(duty);
  SS_FACTORY_END
}

signalSource signalSource::sinc(float freq, uint16_t n_lobes, float phase,
                                 WaveMode mode, uint32_t n_periods,
                                 WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Sinc)
  b.add_f32(freq); b.add_f32(phase); b.add_u16(n_lobes);
  SS_FACTORY_END
}

signalSource signalSource::gauspuls(float freq, float bw_fraction, float prf,
                                     WaveMode mode, uint32_t n_periods,
                                     WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Gauspuls)
  b.add_f32(freq); b.add_f32(bw_fraction); b.add_f32(prf);
  SS_FACTORY_END
}

signalSource signalSource::dc(float value) {
  return signalSource(WaveShape::DC, /*amplitude*/1.0f, /*offset*/value,
                       WaveMode::Perpetual, 0, WaveTrigPol::Rising);
}

signalSource signalSource::arbitrary(const float * samples, uint16_t n_samples,
                                      float freq, float phase, WaveMode mode,
                                      uint32_t n_periods, WaveTrigPol trig_pol,
                                      float amplitude, float offset) {
  /* Wire layout for Arbitrary (matches papaya/signal_source.py
   *   _SHAPE_PARAM_LAYOUT[Arbitrary] = ("freq", "phase", "n_samples", "samples")):
   *
   *   pos 0..5: common header (shape/mode/trig_pol/n_periods/amplitude/offset)
   *   pos 6: freq      (Real)
   *   pos 7: phase     (Real)
   *   pos 8: n_samples (Uint16)
   *   pos 9..: samples (RealArray, one param per PAPAYA_ARB_SAMPLES_PER_PARAM)
   *
   * One Real-array param is capped at PP_PARAM_DESC_MAX_SIZE (= 4095 B) by
   * the protocol's 12-bit size field, i.e. at most 1023 float samples. That
   * was a limit of one PARAMETER, never of the LUT: frame chunking already
   * lets a command body span as many frames as it needs. A longer table is
   * therefore split across consecutive params, exactly as
   * UploadDatasetChunk splits a dataset payload, and the board pulls the
   * pieces back together into one arbitrary table.
   *
   * The whole table is capped at PAPAYA_ARB_MAX_SAMPLES, which is how many
   * params a signal source has left out of PP_FUNC_PARAM_MAX_NBR after the
   * nine it already spends. Reject a longer one here so a bad call cannot
   * silently truncate. Mirrors split_real_array + PP_WAVE_ARB_MAX_SAMPLES
   * in papaya/signal_source.py; the two hosts must agree or a design built
   * in one language stops matching the same design built in the other.
   */
  signalSource s(WaveShape::Arbitrary, amplitude, offset, mode, n_periods, trig_pol);

  if (samples == nullptr || n_samples == 0u) {
    /* Nothing to upload: emit a header-only frame so the firmware can at
     * least allocate the state, then return. Tests cover the n_samples>0
     * path; this branch is defensive. */
    return s;
  }

  if ((uint32_t)n_samples > (uint32_t)PAPAYA_ARB_MAX_SAMPLES) {
    SetDesignError(PP_DesignStatus::BadParam);
    return s;
  }

  /* freq = 0 means "play it once over its own duration". A recording has
   * only that one speed, so a caller playing one does not have a rate to
   * give; the library works it out from the sampling frequency
   * startDesign() recorded and the length of the table. Mirrors the
   * Python library's signalSource.arbitrary(samples) with no freq. */
  if (freq <= 0.0f) {
    freq = PapayaDatasetPlaybackFreq((uint32_t)n_samples,
                                     PapayaDesignSamplingFreq());
    if (freq <= 0.0f) {
      SetDesignError(PP_DesignStatus::BadParam);
      return s;
    }
  }

  uint32_t arr_bytes = (uint32_t)n_samples * sizeof(float);
  /* One param per PAPAYA_ARB_SAMPLES_PER_PARAM samples; the last carries
   * the remainder. Always >= 1 here, since n_samples > 0. */
  uint16_t n_chunks = (uint16_t)(((uint32_t)n_samples + PAPAYA_ARB_SAMPLES_PER_PARAM - 1u)
                                 / PAPAYA_ARB_SAMPLES_PER_PARAM);
  /* Total serial size: header (PP_FIXED_SIZE) + 6 header params + 3 scalar
   * shape params + one descriptor per LUT param + the samples themselves.
   * At the cap that is 45012 sample bytes plus 70, well under the 65535 a
   * u16 BodySize can express. */
  uint16_t serial_size = (uint16_t)((uint32_t)PP_FIXED_SIZE
      + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) * 3u      /* shape + mode + trig_pol */
      + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)           /* n_periods */
      + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) * 2u        /* amplitude + offset */
      + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) * 2u        /* freq + phase */
      + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)           /* n_samples */
      + (uint32_t)PP_PARAM_INFO_SIZE * n_chunks         /* one per LUT param */
      + arr_bytes);                                     /* samples LUT */

  /* Issue every param explicitly so we control the exact wire layout. */
  PrepareCmdHeader(&Command, serial_size, Createblock,
                   /*NbrOfParams*/ (uint8_t)(9u + n_chunks),
                   NewSignalSource, s.getId());

  PP_FuncParam fp;
  fp.ParamUint16 = (uint16_t)WaveShape::Arbitrary;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &fp);
  fp.ParamUint16 = (uint16_t)mode;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &fp);
  fp.ParamUint16 = (uint16_t)trig_pol;
  PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16, &fp);
  fp.ParamUint32 = n_periods;
  PrepareParam(&Command, 3u, PP_UINT32_SIZE, TYPE_Uint32, &fp);
  fp.ParamReal = amplitude;
  PrepareParam(&Command, 4u, PP_REAL_SIZE, TYPE_Real, &fp);
  fp.ParamReal = offset;
  PrepareParam(&Command, 5u, PP_REAL_SIZE, TYPE_Real, &fp);
  fp.ParamReal = freq;
  PrepareParam(&Command, 6u, PP_REAL_SIZE, TYPE_Real, &fp);
  fp.ParamReal = phase;
  PrepareParam(&Command, 7u, PP_REAL_SIZE, TYPE_Real, &fp);
  fp.ParamUint16 = n_samples;
  PrepareParam(&Command, 8u, PP_UINT16_SIZE, TYPE_Uint16, &fp);
  /* The TYPE_RealArray payloads point into the raw float buffer the user
   * passed. PrepareParam memcpy's the bytes into the command payload during
   * the synchronous HandleCmd below, so `samples` only needs to live until
   * this function returns. */
  for (uint16_t chunk = 0u; chunk < n_chunks; chunk++) {
    uint32_t first = (uint32_t)chunk * PAPAYA_ARB_SAMPLES_PER_PARAM;
    uint32_t count = (uint32_t)n_samples - first;
    if (count > PAPAYA_ARB_SAMPLES_PER_PARAM) {
      count = PAPAYA_ARB_SAMPLES_PER_PARAM;
    }
    fp.ParamRealArray = const_cast<float*>(samples + first);
    PrepareParam(&Command, (uint8_t)(9u + chunk),
                 (uint16_t)(count * sizeof(float)), TYPE_RealArray, &fp);
  }

  HandleCmd(&Command, serial_size);
  return s;
}

signalSource signalSource::chirpLinear(float f0, float f1, float t_sweep, float phase,
                                        WaveMode mode, uint32_t n_periods,
                                        WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::LinearChirp)
  b.add_f32(f0); b.add_f32(f1); b.add_f32(t_sweep); b.add_f32(phase);
  SS_FACTORY_END
}

signalSource signalSource::chirpLog(float f0, float f1, float t_sweep, float phase,
                                     WaveMode mode, uint32_t n_periods,
                                     WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::LogChirp)
  b.add_f32(f0); b.add_f32(f1); b.add_f32(t_sweep); b.add_f32(phase);
  SS_FACTORY_END
}

signalSource signalSource::multisine(float f0, float df, uint16_t n_lines,
                                      MultisinePhase phase_scheme, uint32_t lfsr_seed,
                                      WaveMode mode, uint32_t n_periods,
                                      WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Multisine)
  b.add_f32(f0); b.add_f32(df); b.add_u16(n_lines);
  b.add_u8((uint8_t)phase_scheme); b.add_u32(lfsr_seed);
  SS_FACTORY_END
}

signalSource signalSource::prbs(uint8_t bits, uint32_t clock_div, uint32_t lfsr_seed,
                                 WaveMode mode, uint32_t n_periods,
                                 WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::PRBS)
  b.add_u8(bits); b.add_u32(clock_div); b.add_u32(lfsr_seed);
  SS_FACTORY_END
}

signalSource signalSource::step(float t_step, float value_before, float value_after,
                                 WaveMode mode, uint32_t n_periods,
                                 WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Step)
  b.add_f32(t_step); b.add_f32(value_before); b.add_f32(value_after);
  SS_FACTORY_END
}

signalSource signalSource::ramp(float slope, float t_start, float sat_low, float sat_high,
                                 WaveMode mode, uint32_t n_periods,
                                 WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Ramp)
  b.add_f32(slope); b.add_f32(t_start); b.add_f32(sat_low); b.add_f32(sat_high);
  SS_FACTORY_END
}

signalSource signalSource::impulse(float t_impulse, WaveMode mode, uint32_t n_periods,
                                    WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::Impulse)
  b.add_f32(t_impulse);
  SS_FACTORY_END
}

signalSource signalSource::pulseTrain(float freq, float duty, uint16_t n_pulses, float prf,
                                       float phase, WaveMode mode, uint32_t n_periods,
                                       WaveTrigPol trig_pol, float amplitude, float offset) {
  SS_FACTORY_BEGIN(WaveShape::PulseTrain)
  /* Wire order MUST match papaya/signal_source.py _SHAPE_PARAM_LAYOUT[PulseTrain]
   * = (freq, phase, duty, n_pulses[u16], prf[f32]), which is the order the
   * board decodes: param 9 is n_pulses as Uint16, param 10 is prf as Real.
   * The last two params were previously emitted swapped in BOTH order and
   * type here, so the Arduino/C++ path produced a garbage PulseTrain while
   * the USB/Python path was correct. */
  b.add_f32(freq); b.add_f32(phase); b.add_f32(duty); b.add_u16(n_pulses); b.add_f32(prf);
  SS_FACTORY_END
}

signalSource signalSource::dataset(const float * samples, uint32_t n_samples,
                                    WaveMode mode, uint32_t n_periods,
                                    WaveTrigPol trig_pol, float amplitude, float offset,
                                    float phase) {
  /* ONE command. A recording IS an Arbitrary lookup table: it travels inside
   * the block's own create command, the board copies it into its fast
   * working memory, and the block iterates it there. Nothing is uploaded
   * first, so there is no slot to name and no step to forget.
   *
   * The rate is left at 0, which means "work it out": a recording plays once
   * over its own duration, Fs / N. See the declaration. */
  if (n_samples > PAPAYA_ARB_MAX_SAMPLES) {
    /* More than the board's fast heap gives one table. */
    SetDesignError(PP_DesignStatus::BadParam);
    return signalSource(WaveShape::Arbitrary, amplitude, offset, mode,
                        n_periods, trig_pol, /*emitFrame=*/false);
  }
  return arbitrary(samples, (uint16_t)n_samples, /*freq=*/0.0f, phase, mode,
                   n_periods, trig_pol, amplitude, offset);
}

#undef SS_FACTORY_BEGIN
#undef SS_FACTORY_END


pid::pid(float ki, float kp, float kd, float tau)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, (PP_SubFuncId)NewPid, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = ki;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = kp;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamReal = kd;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 5. Prepare Param_4 */
  FuncParam.ParamReal = tau;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 6. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

livePid::livePid()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewTunePID, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

livePi::livePi()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewTunePI, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

livePd::livePd()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewTunePD, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

live2Pid::live2Pid()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewTune2PID, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

pidAw::pidAw(float ki, float kp, float kd, float tau,
             float u_min, float u_max, float Tt,
             uint8_t mode, uint8_t report)
{
  PP_FuncParam FuncParam;
  /* 7 reals then 2 uint8. The parameter order (Ki, Kp, Kd, Tau, UMin,
   * UMax, Tt, Mode, Report) is a wire contract with the board: do not
   * reorder. */
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            7u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 9u, (PP_SubFuncId)NewPidAw, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = ki;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = kp;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamReal = kd;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 5. Prepare Param_4 */
  FuncParam.ParamReal = tau;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 6. Prepare Param_5 */
  FuncParam.ParamReal = u_min;
  PrepareParam(&Command, 4u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 7. Prepare Param_6 */
  FuncParam.ParamReal = u_max;
  PrepareParam(&Command, 5u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 8. Prepare Param_7 */
  FuncParam.ParamReal = Tt;
  PrepareParam(&Command, 6u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 9. Prepare Param_8 */
  FuncParam.ParamUint8 = mode;
  PrepareParam(&Command, 7u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 10. Prepare Param_9 */
  FuncParam.ParamUint8 = report;
  PrepareParam(&Command, 8u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 11. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

livePidAw::livePidAw(uint8_t mode, uint8_t report)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)NewTunePIDAw, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = mode;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = report;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

livePiAw::livePiAw(uint8_t mode, uint8_t report)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)NewTunePIAw, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = mode;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = report;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

live2PidAw::live2PidAw(uint8_t mode, uint8_t report)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)NewTune2PIDAw, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = mode;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = report;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

mag2::mag2()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewMag2, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

mag3::mag3()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewMag3, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

/* ----------------------------------------------------------------------------
 *  Infrastructure block
 *  quatMult: Hamilton product (multiplication) of two quaternions.
 *  Inputs (8): q1w,q1x,q1y,q1z, q2w,q2x,q2y,q2z.  Outputs (4): qw,qx,qy,qz.
 * ----------------------------------------------------------------------------
 */
quatMult::quatMult()
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE ;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewQuatMult, this->getId());

  /* 6. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

quatFromEuler::quatFromEuler()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewQuatFromEuler, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

quatToEuler::quatToEuler()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewQuatToEuler, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

quatToRotmat::quatToRotmat()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewQuatToRotmat, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

quatNormConj::quatNormConj()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, (PP_SubFuncId)NewQuatNormConj, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

/* ----------------------------------------------------------------------------
 *  Infrastructure block
 *  windowFramer: sliding-window framer with hop H.
 *  Two uint16 params (N, H).
 * ----------------------------------------------------------------------------
 */
windowFramer::windowFramer(uint16_t N, uint16_t H)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u,
                   (PP_SubFuncId)NewWindowFramer, this->getId());

  /* 2. Prepare Param_0 (N) */
  FuncParam.ParamUint16 = N;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Prepare Param_1 (H) */
  FuncParam.ParamUint16 = H;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

/* ----------------------------------------------------------------------------
 *  Infrastructure block
 *  stftFramer: windowed sliding-window framer.
 *  Three uint16 params (N, H, WindowType).
 * ----------------------------------------------------------------------------
 */
stftFramer::stftFramer(uint16_t N, uint16_t H, uint16_t WindowType)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u,
                   (PP_SubFuncId)NewStftFramer, this->getId());

  FuncParam.ParamUint16 = N;          PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamUint16 = H;          PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamUint16 = WindowType; PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

/* ----------------------------------------------------------------------------
 *  Infrastructure blocks (4 blocks: zScoreNorm,
 *  innovationChi2, imuBiasEst, featureStack). All take a mix of uint16 and
 *  float parameters; constructor pattern mirrors signalSource / pid.
 * ----------------------------------------------------------------------------
 */
zScoreNorm::zScoreNorm(uint16_t TrainWindowN, float Epsilon)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u,
                   (PP_SubFuncId)NewZScoreNorm, this->getId());
  FuncParam.ParamUint16 = TrainWindowN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamReal   = Epsilon;      PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

innovationChi2::innovationChi2(uint16_t NMeas, float Threshold)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u,
                   (PP_SubFuncId)NewInnovationChi2, this->getId());
  FuncParam.ParamUint16 = NMeas;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamReal   = Threshold; PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

imuBiasEst::imuBiasEst(uint16_t VarWindow, float RestThreshold, float Alpha)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            2u * ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u,
                   (PP_SubFuncId)NewImuBiasEst, this->getId());
  FuncParam.ParamUint16 = VarWindow;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamReal   = RestThreshold; PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  FuncParam.ParamReal   = Alpha;         PrepareParam(&Command, 2u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

featureStack::featureStack(uint16_t K)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,
                   (PP_SubFuncId)NewFeatureStack, this->getId());
  FuncParam.ParamUint16 = K; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

/* Flight, fusion and control blocks.
 * The sample period comes from the design's global Fs, which the board
 * reads at run time; there is no Ts parameter on the wire. */
madgwickAhrs::madgwickAhrs(float Beta)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,
                   (PP_SubFuncId)NewMadgwickAhrs, this->getId());
  FuncParam.ParamReal = Beta; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

mahonyAhrs::mahonyAhrs(float Kp, float Ki)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE + 2u * ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u,
                   (PP_SubFuncId)NewMahonyAhrs, this->getId());
  FuncParam.ParamReal = Kp; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  FuncParam.ParamReal = Ki; PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

complementaryAhrs::complementaryAhrs(float Alpha)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,
                   (PP_SubFuncId)NewComplementaryAhrs, this->getId());
  FuncParam.ParamReal = Alpha; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

mixerMultirotor::mixerMultirotor(uint8_t FrameType, float PwmMin, float PwmMax)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            2u * ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u,
                   (PP_SubFuncId)NewMixerMultirotor, this->getId());
  FuncParam.ParamUint16 = (uint16_t)FrameType; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamReal   = PwmMin;              PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  FuncParam.ParamReal   = PwmMax;              PrepareParam(&Command, 2u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

/* Motion and control blocks. Sample period taken from the design's global Fs. */
trajScurve::trajScurve()
{
  uint16_t SerialDataSize = PP_FIXED_SIZE;
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 0u, (PP_SubFuncId)NewTrajScurve, this->getId());
  HandleCmd(&Command, SerialDataSize);
}

trajTrapezoid::trajTrapezoid()
{
  uint16_t SerialDataSize = PP_FIXED_SIZE;
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 0u, (PP_SubFuncId)NewTrajTrapezoid, this->getId());
  HandleCmd(&Command, SerialDataSize);
}

frictionStribeck::frictionStribeck(float Fc, float Fs, float vs, float Bv)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE + 4u * ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, (PP_SubFuncId)NewFrictionStribeck, this->getId());
  FuncParam.ParamReal = Fc; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  FuncParam.ParamReal = Fs; PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  FuncParam.ParamReal = vs; PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  FuncParam.ParamReal = Bv; PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

inputShaper::inputShaper(uint8_t Mode, float Wn, float Zeta)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            2u * ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, (PP_SubFuncId)NewInputShaper, this->getId());
  FuncParam.ParamUint16 = (uint16_t)Mode; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
  FuncParam.ParamReal   = Wn;             PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  FuncParam.ParamReal   = Zeta;           PrepareParam(&Command, 2u, PP_REAL_SIZE,   TYPE_Real,   &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

/* Biomedical blocks */
hjorth::hjorth(uint16_t WindowN)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewHjorth, this->getId());
  P.ParamUint16 = WindowN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
emgEnvelope::emgEnvelope(float CutoffHz)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewEmgEnvelope, this->getId());
  P.ParamReal = CutoffHz; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &P);
  HandleCmd(&Command, S);
}
emgHudgins::emgHudgins(uint16_t WindowN, float ZcThreshold)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 2u, (PP_SubFuncId)NewEmgHudgins, this->getId());
  P.ParamUint16 = WindowN;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  P.ParamReal   = ZcThreshold; PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &P);
  HandleCmd(&Command, S);
}
ecgBlRemove::ecgBlRemove(uint16_t WindowW)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewEcgBlRemove, this->getId());
  P.ParamUint16 = WindowW; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
hrvTime::hrvTime(uint16_t RingN)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewHrvTime, this->getId());
  P.ParamUint16 = RingN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
/* Dependent block: consumes the magnitude spectrum of an fftMagResolver.
 * The board derives the band edges from the global Fs and the FFT length. */
eegBandpower::eegBandpower(fftMagResolver fftMagInstance)
{
  this->setContextSlot(fftMagInstance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewEegBandpower, this->getId());
  P.ParamUint16 = fftMagInstance.getId(); PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}

/* AI and feature-extraction blocks */
skewKurt::skewKurt(uint16_t WindowN)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewSkewKurt, this->getId());
  P.ParamUint16 = WindowN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
percentile::percentile(float Quantile)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewPercentile, this->getId());
  P.ParamReal = Quantile; PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &P);
  HandleCmd(&Command, S);
}
peakToPeak::peakToPeak(uint16_t WindowN)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewPeakToPeak, this->getId());
  P.ParamUint16 = WindowN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
crestFactor::crestFactor(uint16_t WindowN)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewCrestFactor, this->getId());
  P.ParamUint16 = WindowN; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
zcr::zcr(uint16_t WindowN, float ZcThreshold)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) + ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 2u, (PP_SubFuncId)NewZcr, this->getId());
  P.ParamUint16 = WindowN;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  P.ParamReal   = ZcThreshold; PrepareParam(&Command, 1u, PP_REAL_SIZE,   TYPE_Real,   &P);
  HandleCmd(&Command, S);
}
/* Dependent block: consumes the magnitude spectrum of an fftMagResolver. */
spectralFeatures::spectralFeatures(fftMagResolver fftMagInstance)
{
  this->setContextSlot(fftMagInstance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewSpectralFeatures, this->getId());
  P.ParamUint16 = fftMagInstance.getId(); PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
cepstrum::cepstrum(fftMagResolver fftMagInstance)
{
  this->setContextSlot(fftMagInstance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 1u, (PP_SubFuncId)NewCepstrum, this->getId());
  P.ParamUint16 = fftMagInstance.getId(); PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
autocorrLags::autocorrLags(uint16_t N, uint16_t L, uint16_t D)
{
  PP_FuncParam P;
  uint16_t S = PP_FIXED_SIZE + 3u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE );
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, S, Createblock, 3u, (PP_SubFuncId)NewAutocorrLags, this->getId());
  P.ParamUint16 = N; PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  P.ParamUint16 = L; PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  P.ParamUint16 = D; PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16, &P);
  HandleCmd(&Command, S);
}
pcaProject::pcaProject(uint16_t K, uint16_t P_dim, float* W, float* mu)
{
  PP_FuncParam Pp;
  const uint32_t w_len  = (uint32_t)P_dim * (uint32_t)K;
  const uint32_t mu_len = (uint32_t)K;
  uint16_t S = PP_FIXED_SIZE + 2u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE )
                             + ( PP_PARAM_INFO_SIZE + (uint16_t)(w_len  * PP_REAL_SIZE) )
                             + ( PP_PARAM_INFO_SIZE + (uint16_t)(mu_len * PP_REAL_SIZE) );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 4u, (PP_SubFuncId)NewPcaProject, this->getId());
  Pp.ParamUint16    = K;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &Pp);
  Pp.ParamUint16    = P_dim; PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &Pp);
  Pp.ParamRealArray = W;     PrepareParam(&Command, 2u, (uint16_t)(w_len  * PP_REAL_SIZE), TYPE_RealArray, &Pp);
  Pp.ParamRealArray = mu;    PrepareParam(&Command, 3u, (uint16_t)(mu_len * PP_REAL_SIZE), TYPE_RealArray, &Pp);
  HandleCmd(&Command, S);
}
decisionTree::decisionTree(uint16_t K, uint16_t C, uint16_t NNodes,
                           uint16_t* FeatIdx, float* Thresh,
                           uint16_t* Left, uint16_t* Right, float* LeafVal)
{
  PP_FuncParam Pp;
  /* feat_idx/left/right are uint16 arrays (2 B/elem): the board copies
   * them as uint16_t[NNodes].  Send them as genuine
   * TYPE_Uint16Array with a NNodes*2 byte size -- previously they were cast to
   * (float*) and sent as TYPE_RealArray with a NNodes*4 size, which read
   * NNodes*2 bytes past the end of the caller's uint16 buffers (host-side
   * over-read) and produced a wire frame that disagreed with the Python lib.
   * thresh/leaf_val stay float32 arrays. */
  uint16_t S = PP_FIXED_SIZE + 3u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE )
                             + 2u * ( PP_PARAM_INFO_SIZE + (uint16_t)(NNodes * PP_REAL_SIZE) )
                             + 3u * ( PP_PARAM_INFO_SIZE + (uint16_t)(NNodes * sizeof(uint16_t)) );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, S, Createblock, 8u, (PP_SubFuncId)NewDecisionTree, this->getId());
  Pp.ParamUint16      = K;        PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &Pp);
  Pp.ParamUint16      = C;        PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &Pp);
  Pp.ParamUint16      = NNodes;   PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16, &Pp);
  Pp.ParamUint16Array = FeatIdx;  PrepareParam(&Command, 3u, (uint16_t)(NNodes * sizeof(uint16_t)), TYPE_Uint16Array, &Pp);
  Pp.ParamRealArray   = Thresh;   PrepareParam(&Command, 4u, (uint16_t)(NNodes * PP_REAL_SIZE), TYPE_RealArray, &Pp);
  Pp.ParamUint16Array = Left;     PrepareParam(&Command, 5u, (uint16_t)(NNodes * sizeof(uint16_t)), TYPE_Uint16Array, &Pp);
  Pp.ParamUint16Array = Right;    PrepareParam(&Command, 6u, (uint16_t)(NNodes * sizeof(uint16_t)), TYPE_Uint16Array, &Pp);
  Pp.ParamRealArray   = LeafVal;  PrepareParam(&Command, 7u, (uint16_t)(NNodes * PP_REAL_SIZE), TYPE_RealArray, &Pp);
  HandleCmd(&Command, S);
}

lqrServo::lqrServo(uint16_t n, uint16_t m, uint16_t p, float* K, float UMax)
{
  /* LQR servo node.
   *   Wire ABI:    n (u16), m (u16), p (u16), K (float[m*(n+p)]), UMax (float)
   *   Block ports: n+p inputs (x_0..x_{n-1}, e_0..e_{p-1}), m outputs.
   *   The user wires an external Sum node "[1 -1]" to compute e = r-y and
   *   feeds it into the integrator inputs.
   *   The sample period comes from the design's global Fs, which the board
   *   reads at run time; there is no Ts parameter on the wire. */
  PP_FuncParam FuncParam;
  const uint32_t k_len = (uint32_t)m * (uint32_t)(n + p);
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * ( PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ) +
                            ( PP_PARAM_INFO_SIZE + (uint16_t)( k_len * PP_REAL_SIZE ) ) +
                            ( PP_PARAM_INFO_SIZE + PP_REAL_SIZE );
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u,
                   (PP_SubFuncId)NewLqrServo, this->getId());
  FuncParam.ParamUint16    = n;     PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16,    &FuncParam);
  FuncParam.ParamUint16    = m;     PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16,    &FuncParam);
  FuncParam.ParamUint16    = p;     PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16,    &FuncParam);
  FuncParam.ParamRealArray = K;     PrepareParam(&Command, 3u, (uint16_t)( k_len * PP_REAL_SIZE ),
                                                  TYPE_RealArray, &FuncParam);
  FuncParam.ParamReal      = UMax;  PrepareParam(&Command, 4u, PP_REAL_SIZE,   TYPE_Real,      &FuncParam);
  HandleCmd(&Command, SerialDataSize);
}

delayop::delayop(uint16_t NbrOfSamples)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewDelayOp, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = NbrOfSamples;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

movingAverage::movingAverage(uint16_t NbrOfSamples)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewMovingAverage, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = NbrOfSamples;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}
absMax::absMax(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewAbsMax, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

absMin::absMin(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewAbsMin, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

entropy::entropy(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewEntropy, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

mean::mean(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewMean, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

maximum::maximum(uint32_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewMaximum, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint32 = Length;
  PrepareParam(&Command, 0u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

minimum::minimum(uint32_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewMinimum, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint32 = Length;
  PrepareParam(&Command, 0u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);
  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

power::power(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewPower, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

rootMeanSquare::rootMeanSquare(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewRootMeanSquare, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

standardDeviation::standardDeviation(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewStandardDeviation, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

variance ::variance(uint8_t Length)
{ 
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u,(PP_SubFuncId)NewVariance, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = Length;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

/* Node Class ############################################################################################################ */
/* ===================================================================================== */
/* ====================================== node.cpp ===================================== */
/* ===================================================================================== */

node::node()
{
  BindObjectToActiveContext(this->contextSlot);
  /* Default port selection: first input and first output */
  this->activeInIdx  = 0u;
  this->activeOutIdx = 0u;
}

node::node(const char *InCoef, const char *OutCoef, PP_NodeType Type)
{
  BindObjectToActiveContext(this->contextSlot);
  /* Default port selection: first input and first output */
  this->activeInIdx  = 0u;
  this->activeOutIdx = 0u;

  PP_FuncParam FuncParam;
  uint16_t param1_size;
  uint16_t param2_size;

  if ((TryGetCStringPayloadSize(InCoef, param1_size) == false) ||
      (TryGetCStringPayloadSize(OutCoef, param2_size) == false))
  {
    return;
  }

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + param1_size +
                            PP_PARAM_INFO_SIZE + param2_size +
                            PP_PARAM_INFO_SIZE + PP_NODE_TYPE_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentNodeId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewNode, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamString = InCoef;
  PrepareParam(&Command, 0u, param1_size, TYPE_String, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamString = OutCoef;
  PrepareParam(&Command, 1u, param2_size, TYPE_String, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamNodeType(Type);
  PrepareParam(&Command, 2u, PP_NODE_TYPE_SIZE, PP_NODE_TYPE_TYPE, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

node::node
(
  const float *inCoef, 
  uint8_t inSize,
  const float *outCoef, 
  uint8_t outSize,
  PP_NodeType Type
)
{
  BindObjectToActiveContext(this->contextSlot);
  /* Default port selection: first input and first output */
  this->activeInIdx  = 0u;
  this->activeOutIdx = 0u;

  PP_FuncParam FuncParam;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            /* Param 0: InCoef array */
                            PP_PARAM_INFO_SIZE + (uint16_t)(inSize * PP_REAL_SIZE) +
                            /* Param 1: InSize */
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                            /* Param 2: OutCoef array */
                            PP_PARAM_INFO_SIZE + (uint16_t)(outSize * PP_REAL_SIZE) +
                            /* Param 3: OutSize */
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                            /* Param 4: Type */
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentNodeId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewFlexNode, this->id);

  /* 2. Prepare Param_0 (InCoef) */
  FuncParam.ParamRealArray = (float*)inCoef;
  PrepareParam(&Command, 0u, (uint16_t)(inSize * PP_REAL_SIZE), TYPE_RealArray, &FuncParam);

  /* 3. Prepare Param_1 (InSize) */
  FuncParam.ParamUint8 = inSize;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Prepare Param_2 (OutCoef) */
  FuncParam.ParamRealArray = (float*)outCoef;
  PrepareParam(&Command, 2u, (uint16_t)(outSize * PP_REAL_SIZE), TYPE_RealArray, &FuncParam);

  /* 5. Prepare Param_3 (OutSize) */
  FuncParam.ParamUint8 = outSize;
  PrepareParam(&Command, 3u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 6. Prepare Param_4 (Type) */
  FuncParam.ParamUint8 = (uint8_t)Type;
  PrepareParam(&Command, 4u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 7. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

node node::in(uint8_t InIdx)
{
  /* Return a CONFIGURED COPY rather than mutating ``*this``.  The original
   * block retains its default port indices, so a later bare
   * ``src > node`` (no explicit ``.in(N)`` / ``.out(N)``) reliably uses
   * port 0 instead of the index a previous ``.in(N)`` left sticky on
   * the original.  This mirrors the consume-on-link reset the Python lib
   * applies to macros and avoids the cross-copy plumbing that would
   * otherwise be needed in every ``operator>`` overload to reach the
   * original instance. */
  node tmp = *this;
  tmp.activeInIdx = InIdx;
  return tmp;
}

node node::out(uint8_t OutIdx)
{
  node tmp = *this;
  tmp.activeOutIdx = OutIdx;
  return tmp;
}

uint16_t node::getId()
{
  return this->id;
}

void node::setId(uint16_t id)
{
  this->id = id;
}

uint8_t node::getContextSlot() const
{
  return this->contextSlot;
}

void node::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

uint8_t node::getActiveInIdx()
{
  return this->activeInIdx;
}

uint8_t node::getActiveOutIdx()
{
  return this->activeOutIdx;
}

void node::operator>(tf Dst) // Node2Sys
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), 0xFF, LinkNode2Sys);
}

void node::operator>(probe &Dst) // Node2Probe
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), 0xFF, LinkNode2Probe);
  Dst.addToQueue();
}

void node::operator>(node Dst) // Node2Node
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), Dst.getActiveInIdx(), LinkNode2Node);
}

void node::operator>(macro Dst) // Node2Macro
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), Dst.getActiveInIdx(), LinkNode2Macro);
}

void node::operator>>(VectorProbe &Dst) // Node2VectorProbe
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), 0xFF, LinkNode2VectorProbe);

  /* Only commit host-side bookkeeping if the firmware accepted the
   * link. Otherwise VectorProbeBytes drifts past CachedVectProbesBytes
   * and every subsequent getVectorProbes() reads misaligned data. */
  if (currentDesignStatus != PP_DesignStatus::DesignOk)
  {
    return;
  }

  /* Stage data-shape; addToQueue() owns the buffer-offset assignment
   * and VectorProbeBytes accumulation, and is idempotent against a
   * probe being linked from more than one source. */
  Dst.dataLines = this->dataLines;
  Dst.dataRaw   = this->dataRaw;
  Dst.addToQueue();
}

schmidt::schmidt()
{
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewSchmidt,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

comp::comp()
{
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewComp,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

sat::sat()
{
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewSat,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

deadZone::deadZone()
{
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewDeadZone,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

backlashDeadBand::backlashDeadBand()
{
  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewBacklashDeadBand,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

merger::merger(uint8_t nbrOfInputs) 
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewMerger, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = nbrOfInputs;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

sign::sign(void)
{
    /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
  PrepareCmdHeader(&Command,
                   PP_FIXED_SIZE,
                   Createblock,
                   0,
                   NewSign,
                   this->getId());

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

gain::gain(float gainValue)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  this->out(0);
  PrepareCmdHeader(&Command,
                   SerialDataSize,
                   Createblock,
                   1u,
                   NewGain,
                   this->getId());

  /* 2. Prepare Param_0 (gainValue) */
  FuncParam.ParamReal = gainValue;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

/* ======================== Math / DSP systems ======================== */

sqrMath::sqrMath(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewSqrMath, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

sqrtBlock::sqrtBlock(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewSqrt, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

sineFunc::sineFunc(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewSineFunc, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

cosineFunc::cosineFunc(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewCosineFunc, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

absVal::absVal(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewAbsVal, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

atan2Block::atan2Block(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewAtan2, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

logFunc::logFunc(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewLogFunc, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

expFunc::expFunc(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewExpFunc, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

negate::negate(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewNegate, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

inverse::inverse(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewInverse, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}


/* ======================== Control blocks ======================== */

switchBlock::switchBlock(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewSwitch, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

quantizer::quantizer(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewQuantizer, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

integratorIC::integratorIC(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewIntegratorIC, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

modulo::modulo(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewModulo, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

integrator::integrator(void)
{
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewIntegrator, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

derivative::derivative(float Tau)
{
  this->setId(currentSysId++);
  PP_FuncParam FuncParam;
  FuncParam.ParamReal = Tau;
  uint16_t serial_size = PP_FIXED_SIZE + PP_PARAM_INFO_SIZE + PP_REAL_SIZE;
  PrepareCmdHeader(&Command, serial_size, Createblock, 1, NewDerivative, this->getId());
  PrepareParam(&Command, 0, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  HandleCmd(&Command, serial_size);
}

rateLimiter::rateLimiter(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewRateLimiter, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

sampleHold::sampleHold(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewSampleHold, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}


/* ======================== Motor control transforms ======================== */

clarke::clarke(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewClarke, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

invClarke::invClarke(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewInvClarke, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

park::park(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewPark, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

invPark::invPark(void)
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewInvPark, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}


/* ======================== Classical compensators ======================== */

leadLag::leadLag(float K, float z, float p)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, (PP_SubFuncId)NewLeadLag, this->getId());

  FuncParam.ParamReal = K;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = z;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = p;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

washout::washout(float a)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewWashout, this->getId());

  FuncParam.ParamReal = a;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

expander::expander(uint8_t nbrOfOutputs)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewExpander, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = nbrOfOutputs;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

analogIn::analogIn(PP_HwId id, float outScale, float offset)
{
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewHwInput, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  FuncParam.ParamReal = outScale;  /* CfgConst1 */
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = offset;    /* CfgConst2 */
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

analogIn::analogIn(PP_anInCfg* config, uint8_t items)
{
  if (!config || items == 0u) return;

  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  items * ((PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE));

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(items * 3u), NewHwInput, this->getId());

  uint8_t p = 0u;
  for (uint8_t i = 0u; i < items; ++i) 
  {
    FuncParam.ParamHwRoutineId(config[i].id);
    PrepareParam(&Command, p++, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

    FuncParam.ParamReal = config[i].outScale; /* CfgConst1 */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config[i].offset;   /* CfgConst2 */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}


pwmIn::pwmIn(PP_HwId id, float outScale)
{
  PP_FuncParam FuncParam;
  const uint8_t outs = outputsPerHwInput(id);
  const float   cfg2 = 0.0f;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  outs * ((PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                          (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                          (PP_PARAM_INFO_SIZE + PP_REAL_SIZE));

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(outs * 3u), NewHwInput, this->getId());

  uint8_t p = 0u;
  for (uint8_t k = 0u; k < outs; ++k) 
  {
    FuncParam.ParamHwRoutineId(id);
    PrepareParam(&Command, p++, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

    FuncParam.ParamReal = outScale;  /* CfgConst1 */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = cfg2;      /* CfgConst2 */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}

pwmIn::pwmIn(PP_pwmInCfg* config, uint8_t items)
{
  if (!config || items == 0u) return;

  PP_FuncParam FuncParam;
  uint8_t totalOuts = 0u;
  for (uint8_t i = 0u; i < items; ++i) totalOuts += outputsPerHwInput(config[i].id);

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  totalOuts * ((PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                               (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                               (PP_PARAM_INFO_SIZE + PP_REAL_SIZE));

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(totalOuts * 3u), NewHwInput, this->getId());

  uint8_t p = 0u;
  for (uint8_t i = 0u; i < items; ++i) 
  {
    const uint8_t outs = outputsPerHwInput(config[i].id);
    for (uint8_t k = 0u; k < outs; ++k) 
    {
      FuncParam.ParamHwRoutineId(config[i].id);
      PrepareParam(&Command, p++, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

      FuncParam.ParamReal = config[i].outScale; /* CfgConst1 */
      PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

      FuncParam.ParamReal = 0.0f;               /* CfgConst2 */
      PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);
    }
  }

  HandleCmd(&Command, SerialDataSize);
}

pwmOut::pwmOut(PP_HwId id, float frequency, float dutyLowerLimit, float dutyUpperLimit)
{
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewHwOutput, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  FuncParam.ParamReal = frequency;        /* CfgConst1 */
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = dutyLowerLimit;   /* LowerLimit */
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = dutyUpperLimit;   /* UpperLimit */
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

pwmOut::pwmOut(PP_pwmOutCfg* config, uint8_t items)
{
  if (!config || items == 0u) return;

  if (items > 8u) items = 8u; /* PWM out HW supports up to 8 inputs */

  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  items * ((PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE));

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(items * 4u), NewHwOutput, this->getId());

  uint8_t p = 0u;
  for (uint8_t i = 0u; i < items; ++i)
  {
    FuncParam.ParamHwRoutineId(config[i].id);
    PrepareParam(&Command, p++, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

    FuncParam.ParamReal = config[i].frequency;       /* CfgConst1 */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config[i].dutyLowerLimit;  /* Lower */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config[i].dutyUpperLimit;  /* Upper */
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}

imu::imu(PP_HwId id, float outScale)
{
  PP_FuncParam FuncParam;

  PP_SubFuncId subFunc;
  switch (id)
  {
    case IMU_ACC: subFunc = NewAccelerometer; break;
    case IMU_GYR: subFunc = NewGyroscope;     break;
    case IMU_MAG: subFunc = NewMagnetometer;  break;
    default:      return;
  }

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, subFunc, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  FuncParam.ParamReal = outScale;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

static bool isMotorOutputValid(PP_MotorOutput output)
{
  return (output == MotorVelocity) ||
         (output == MotorPosition) ||
         (output == MotorCurrent);
}

static void CreateMotorNode(node *self,
                            PP_HwId id,
                            const PP_motorCfg *config,
                            const PP_MotorOutput *outputs,
                            uint8_t outputCount)
{
  if ((self == nullptr) || (config == nullptr) || (outputs == nullptr))
    return;

  if ((id != MOTOR1) && (id != MOTOR2))
    return;

  if ((outputCount == 0u) || (outputCount > 3u))
    return;

  for (uint8_t i = 0u; i < outputCount; ++i)
  {
    if (!isMotorOutputValid(outputs[i]))
      return;

    for (uint8_t j = 0u; j < i; ++j)
    {
      if (outputs[j] == outputs[i])
        return;
    }
  }

  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (8u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)) +
                                  (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE) +
                                  (outputCount * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE));

  self->setId(node::currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(10u + outputCount), NewMotor, self->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  FuncParam.ParamReal = config->pwm_hz;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->cur_min_mA;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->cur_max_mA;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->vel_conv;
  PrepareParam(&Command, 4u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->pos_conv;
  PrepareParam(&Command, 5u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->vel_tau;
  PrepareParam(&Command, 6u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->dutyLowerLimit;
  PrepareParam(&Command, 7u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->dutyUpperLimit;
  PrepareParam(&Command, 8u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamUint8 = outputCount;
  PrepareParam(&Command, 9u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  for (uint8_t i = 0u; i < outputCount; ++i)
  {
    FuncParam.ParamUint8 = (uint8_t)outputs[i];
    PrepareParam(&Command, (uint8_t)(10u + i), PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}

motor::motor(PP_HwId id, const PP_motorCfg *config, const PP_MotorOutput *outputs, uint8_t outputCount)
{
  CreateMotorNode(this, id, config, outputs, outputCount);
}

motor::motor(const PP_motorBlockCfg *config)
{
  if (config == nullptr)
    return;

  CreateMotorNode(this, config->id, &config->config, &config->outputs[0], config->outputCount);
}

/* ======================= Encoder ======================= */

static bool isEncoderOutputValid(PP_EncoderOutput output)
{
  return (output == EncoderVelocity) ||
         (output == EncoderPosition);
}

static void CreateEncoderNode(node *self,
                              PP_HwId id,
                              const PP_encoderCfg *config,
                              const PP_EncoderOutput *outputs,
                              uint8_t outputCount)
{
  if ((self == nullptr) || (config == nullptr) || (outputs == nullptr))
    return;

  if ((id != ENC1) && (id != ENC2))
    return;

  if ((outputCount == 0u) || (outputCount > 2u))
    return;

  for (uint8_t i = 0u; i < outputCount; ++i)
  {
    if (!isEncoderOutputValid(outputs[i]))
      return;

    for (uint8_t j = 0u; j < i; ++j)
    {
      if (outputs[j] == outputs[i])
        return;
    }
  }

  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)) +
                                  (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE) +
                                  (outputCount * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE));

  self->setId(node::currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(5u + outputCount), NewEncoder, self->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  FuncParam.ParamReal = config->vel_conv;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->pos_conv;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = config->vel_tau;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamUint8 = outputCount;
  PrepareParam(&Command, 4u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  for (uint8_t i = 0u; i < outputCount; ++i)
  {
    FuncParam.ParamUint8 = (uint8_t)outputs[i];
    PrepareParam(&Command, (uint8_t)(5u + i), PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}

encoder::encoder(PP_HwId id, const PP_encoderCfg *config, const PP_EncoderOutput *outputs, uint8_t outputCount)
{
  CreateEncoderNode(this, id, config, outputs, outputCount);
}

encoder::encoder(const PP_encoderBlockCfg *config)
{
  if (config == nullptr)
    return;

  CreateEncoderNode(this, config->id, &config->config, &config->outputs[0], config->outputCount);
}

/* ======================= Analog Output ======================= */

analogOut::analogOut(PP_HwId id, float lowerLimit, float upperLimit)
{
  /* The board's hardware-output configuration accepts NbrOfParams in
   * {1 (speaker), 4 (id + freq + lower + upper), or 4*N for
   * multi-channel}. AnalogOut has no meaningful frequency on the wire
   * (it is a voltage output, not a PWM output) but the slot is required
   * for parser uniformity; emit 0.0f, which the board stores and then
   * ignores for an analog output. */
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                  (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewHwOutput, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  /* Slot 1: dummy frequency (DAC has no PWM frequency) */
  FuncParam.ParamReal = 0.0f;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = lowerLimit;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = upperLimit;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

analogOut::analogOut(PP_anOutCfg* config, uint8_t items)
{
  if (!config || items == 0u) return;

  if (items > 5u) items = 5u; /* AN_OUT HW supports up to 5 outputs */

  /* Each channel emits 4 params (id + freq + lower + upper); see the
   * comment in the single-channel ctor above for the freq slot rationale. */
  PP_FuncParam FuncParam;
  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  items * ((PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                                           (PP_PARAM_INFO_SIZE + PP_REAL_SIZE));

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, (uint8_t)(items * 4u), NewHwOutput, this->getId());

  uint8_t p = 0u;
  for (uint8_t i = 0u; i < items; ++i)
  {
    FuncParam.ParamHwRoutineId(config[i].id);
    PrepareParam(&Command, p++, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

    /* Slot +1: dummy frequency */
    FuncParam.ParamReal = 0.0f;
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config[i].lowerLimit;
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config[i].upperLimit;
    PrepareParam(&Command, p++, PP_REAL_SIZE, TYPE_Real, &FuncParam);
  }

  HandleCmd(&Command, SerialDataSize);
}

/* ============== analogOut predefined-waveform factories ==============
 * Build the 36-byte AO_WaveCfg frame (mirrors papaya/signal_source.py
 * ao_predef_frame) and emit it as a 3-param NewHwOutput command:
 *   (hwId:HwRoutineId, mode:Uint16=PredefinedWaveform, blob:Uint8Array[36]).
 * The board synthesises one cycle and loops it. */
namespace pp_ao_detail {

static const uint16_t AO_CFG_PREDEF_LEN = 36u;
static const uint32_t AO_MAX_SAMPLES    = 2048u;
static const uint32_t AO_DEFAULT_LUT    = 1024u;
static const uint32_t AO_MIN_LUT        = 8u;
static const float    AO_DAC_FS_MAX     = 1000000.0f;

/* (dac_fs, lut_len) for one seamless cycle of natural period `period` (s). */
inline void cadence_periodic(float period, float* dac_fs, uint16_t* lut_len)
{
  if (period <= 0.0f) { period = 1.0f; }
  uint32_t L = AO_DEFAULT_LUT;
  if ((float)L / period > AO_DAC_FS_MAX) { L = (uint32_t)(AO_DAC_FS_MAX * period); }
  if (L < AO_MIN_LUT)     { L = AO_MIN_LUT; }
  if (L > AO_MAX_SAMPLES) { L = AO_MAX_SAMPLES; }
  *lut_len = (uint16_t)L;
  *dac_fs  = (float)L / period;
}

/* 36-byte predefined-waveform frame builder. */
struct Frame {
  uint8_t buf[AO_CFG_PREDEF_LEN];
  void header(uint16_t shape, float dac_fs, uint16_t lut_len,
              float amp, float off) {
    for (uint16_t i = 0u; i < AO_CFG_PREDEF_LEN; ++i) { buf[i] = 0u; }
    memcpy(buf + 0,  &shape,   2);
    memcpy(buf + 2,  &dac_fs,  4);
    memcpy(buf + 6,  &lut_len, 2);
    memcpy(buf + 8,  &amp,     4);
    memcpy(buf + 12, &off,     4);
  }
  void pf (uint8_t off, float    v) { memcpy(buf + 16 + off, &v, 4); }
  void pu8(uint8_t off, uint8_t  v) { buf[16 + off] = v; }
  void pu16(uint8_t off, uint16_t v){ memcpy(buf + 16 + off, &v, 2); }
  void pu32(uint8_t off, uint32_t v){ memcpy(buf + 16 + off, &v, 4); }
};

} // namespace pp_ao_detail

/* Construct the analogOut and emit the predefined-waveform command. */
#define AO_EMIT(ID, FRAME)                                                     \
  analogOut ao;                                                                \
  ao.setId(currentNodeId++);                                                   \
  do {                                                                         \
    PP_FuncParam fp;                                                           \
    const uint16_t sz = PP_FIXED_SIZE                                          \
        + (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE)                         \
        + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)                                \
        + (PP_PARAM_INFO_SIZE + pp_ao_detail::AO_CFG_PREDEF_LEN);              \
    PrepareCmdHeader(&Command, sz, Createblock, 3u, NewHwOutput, ao.getId());   \
    fp.ParamHwRoutineId(ID);                                                   \
    PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &fp); \
    fp.ParamUint16 = 1u; /* PP_AnOutMode::PredefinedWaveform */                 \
    PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &fp);               \
    fp.ParamUint8Array = (uint8_t*)(FRAME).buf;                                 \
    PrepareParam(&Command, 2u, pp_ao_detail::AO_CFG_PREDEF_LEN, TYPE_Uint8Array, &fp); \
    HandleCmd(&Command, sz);                                                    \
  } while (0);                                                                  \
  return ao;

analogOut analogOut::sine(PP_HwId id, float freq, float phase,
                          float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Sine, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase);
  AO_EMIT(id, fr)
}

analogOut analogOut::square(PP_HwId id, float freq, float phase,
                            float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Square, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase);
  AO_EMIT(id, fr)
}

analogOut analogOut::triangle(PP_HwId id, float freq, float phase,
                              float symmetry, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Triangle, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase); fr.pf(8, symmetry);
  AO_EMIT(id, fr)
}

analogOut analogOut::sawtooth(PP_HwId id, float freq, float phase,
                              uint8_t direction, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Sawtooth, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase); fr.pu8(8, direction);
  AO_EMIT(id, fr)
}

analogOut analogOut::pulse(PP_HwId id, float freq, float phase,
                           float duty, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Pulse, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase); fr.pf(8, duty);
  AO_EMIT(id, fr)
}

analogOut analogOut::sinc(PP_HwId id, float freq, float phase,
                          uint16_t n_lobes, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / freq, &fs, &L);
  fr.header((uint16_t)WaveShape::Sinc, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase); fr.pu16(8, n_lobes);
  AO_EMIT(id, fr)
}

analogOut analogOut::gauspuls(PP_HwId id, float freq, float bw_fraction,
                              float prf, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / prf, &fs, &L);
  fr.header((uint16_t)WaveShape::Gauspuls, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, bw_fraction); fr.pf(8, prf);
  AO_EMIT(id, fr)
}

analogOut analogOut::dc(PP_HwId id, float value) {
  pp_ao_detail::Frame fr;
  fr.header((uint16_t)WaveShape::DC, 1000.0f, 1u, 1.0f, value);
  AO_EMIT(id, fr)
}

analogOut analogOut::chirpLinear(PP_HwId id, float f0, float f1, float t_sweep,
                                 float phase, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(t_sweep, &fs, &L);
  fr.header((uint16_t)WaveShape::LinearChirp, fs, L, amplitude, offset);
  fr.pf(0, f0); fr.pf(4, f1); fr.pf(8, t_sweep); fr.pf(12, phase);
  AO_EMIT(id, fr)
}

analogOut analogOut::chirpLog(PP_HwId id, float f0, float f1, float t_sweep,
                              float phase, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(t_sweep, &fs, &L);
  fr.header((uint16_t)WaveShape::LogChirp, fs, L, amplitude, offset);
  fr.pf(0, f0); fr.pf(4, f1); fr.pf(8, t_sweep); fr.pf(12, phase);
  AO_EMIT(id, fr)
}

analogOut analogOut::multisine(PP_HwId id, float f0, float df, uint16_t n_lines,
                               MultisinePhase phase_scheme, uint32_t lfsr_seed,
                               float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f / df, &fs, &L);
  fr.header((uint16_t)WaveShape::Multisine, fs, L, amplitude, offset);
  fr.pf(0, f0); fr.pf(4, df); fr.pu16(8, n_lines);
  fr.pu8(10, (uint8_t)phase_scheme); fr.pu32(12, lfsr_seed);
  AO_EMIT(id, fr)
}

analogOut analogOut::prbs(PP_HwId id, uint8_t bits, uint32_t clock_div,
                          uint32_t lfsr_seed, float amplitude, float offset) {
  pp_ao_detail::Frame fr;
  uint32_t chips = (((uint32_t)1u << bits) - 1u) * clock_div;
  if (chips > pp_ao_detail::AO_MAX_SAMPLES) { chips = pp_ao_detail::AO_MAX_SAMPLES; }
  if (chips < pp_ao_detail::AO_MIN_LUT)     { chips = pp_ao_detail::AO_MIN_LUT; }
  fr.header((uint16_t)WaveShape::PRBS, (float)chips * 100.0f,
            (uint16_t)chips, amplitude, offset);
  fr.pu8(0, bits); fr.pu32(4, clock_div); fr.pu32(8, lfsr_seed);
  AO_EMIT(id, fr)
}

analogOut analogOut::step(PP_HwId id, float t_step, float value_before,
                          float value_after, float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  float win = 2.0f * (t_step > 1e-3f ? t_step : 1e-3f);
  pp_ao_detail::cadence_periodic(win, &fs, &L);
  fr.header((uint16_t)WaveShape::Step, fs, L, amplitude, offset);
  fr.pf(0, t_step); fr.pf(4, value_before); fr.pf(8, value_after);
  AO_EMIT(id, fr)
}

analogOut analogOut::ramp(PP_HwId id, float slope, float t_start,
                          float sat_low, float sat_high,
                          float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  pp_ao_detail::cadence_periodic(1.0f, &fs, &L);
  fr.header((uint16_t)WaveShape::Ramp, fs, L, amplitude, offset);
  fr.pf(0, slope); fr.pf(4, t_start); fr.pf(8, sat_low); fr.pf(12, sat_high);
  AO_EMIT(id, fr)
}

analogOut analogOut::impulse(PP_HwId id, float t_impulse,
                             float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  float win = 2.0f * (t_impulse > 1e-3f ? t_impulse : 1e-3f);
  pp_ao_detail::cadence_periodic(win, &fs, &L);
  fr.header((uint16_t)WaveShape::Impulse, fs, L, amplitude, offset);
  fr.pf(0, t_impulse);
  AO_EMIT(id, fr)
}

analogOut analogOut::pulseTrain(PP_HwId id, float freq, float phase, float duty,
                                uint16_t n_pulses, float prf,
                                float amplitude, float offset) {
  pp_ao_detail::Frame fr; float fs; uint16_t L;
  float grp = (float)n_pulses / freq;
  float prf_p = 1.0f / prf;
  pp_ao_detail::cadence_periodic(grp > prf_p ? grp : prf_p, &fs, &L);
  fr.header((uint16_t)WaveShape::PulseTrain, fs, L, amplitude, offset);
  fr.pf(0, freq); fr.pf(4, phase); fr.pf(8, duty);
  fr.pu16(12, n_pulses); fr.pf(16, prf);
  AO_EMIT(id, fr)
}

/* ========================== Speaker ========================== */

speaker::speaker(PP_HwId id)
{
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE);

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewHwOutput, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

/* ======================== Microphone ========================= */

microphone::microphone(PP_HwId id)
{
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE);

  /* Microphone is a scalar HwInput node: the board gives it no vector
   * buffer, so a VectorProbe on a microphone publishes 0 bytes per push.
   * dataRaw=0u keeps the host-side VectorProbeBytes accumulator in sync.
   * Use a scalar Probe (mic > p) for audio capture. */
  this->dataLines = 1u;
  this->dataRaw   = 0u;
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewHwInput, this->getId());

  FuncParam.ParamHwRoutineId(id);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

/* ========================== Recorder ========================= */

recorder::recorder()
{
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE);

  /* Recorder is a HwOutput sink: identical wire shape to a speaker, the
   * board just routes samples into the recording flash slot. The hardware
   * id is fixed to RECORDER_1 (only one recording slot exists). */
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewHwOutput, this->getId());

  FuncParam.ParamHwRoutineId(RECORDER_1);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

/* =========================== Replay ========================== */

replay::replay()
{
  PP_FuncParam FuncParam;

  const uint16_t SerialDataSize = PP_FIXED_SIZE +
                                  (PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE);

  /* Replay is a HwInput source: identical wire shape to a microphone, the
   * board just sources samples from the recording flash slot. As with the
   * microphone it is a scalar node with no vector buffer, so dataRaw stays
   * 0. The hardware id is fixed to REPLAY_1. */
  this->dataLines = 1u;
  this->dataRaw   = 0u;
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewHwInput, this->getId());

  FuncParam.ParamHwRoutineId(REPLAY_1);
  PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, PP_HW_ROUTINE_ID_TYPE, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

noise::noise(float value1, float value2, PP_NoiseType type)
{
    PP_FuncParam FuncParam;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE+
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE+
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE ;
                        

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewNoise, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = value1;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = value2;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamUint8 = type;
  PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}


adaptiveKF::adaptiveKF(PP_adaptiveKF* AKF)
{
    if (AKF == nullptr) return;

    /* dim_u > 0 declares control inputs and the board then reads
     * dim_x*dim_u floats of B, so a null B here would serialize through a
     * null pointer and put a malformed frame on the wire. Refuse before
     * anything is serialized. (With dim_u == 0 the board never uses B: a
     * pointer supplied anyway is simply not read.) */
    if ((AKF->dim_u != 0) && (AKF->B_data == nullptr))
    {
        SetDesignError(PP_DesignStatus::BadParam);
        return;
    }

    const uint16_t dim_x = AKF->dim_x;
    const uint16_t dim_z = AKF->dim_z;
    const uint16_t dim_u = AKF->dim_u;

    /* payload sizes (bytes) */
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_F    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_H    = (uint32_t)dim_z * (uint32_t)dim_x * sz_real;
    const uint32_t sz_Q    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_x0   = (uint32_t)dim_x * sz_real;
    const uint32_t sz_B  = (AKF->B_data != nullptr) ? (uint32_t)dim_x * dim_u * sz_real : (uint32_t)2* sz_real;
    /* total frame size */ 
    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_x
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_z
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_u
        + (PP_PARAM_INFO_SIZE + sz_F)     // F
        + (PP_PARAM_INFO_SIZE + sz_H)     // H
        + (PP_PARAM_INFO_SIZE + sz_Q)     // Q
        + (PP_PARAM_INFO_SIZE + sz_real )  // R_init
        + (PP_PARAM_INFO_SIZE + sz_x0)    // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)  // P_init
        + (PP_PARAM_INFO_SIZE + sz_real) //alpha
        + (PP_PARAM_INFO_SIZE + sz_B) // B
        + (PP_PARAM_INFO_SIZE + sz_u8); //tune

    PP_FuncParam FuncParam;

    /* header: 12 params */ 
    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 12u, NewAdaptiveKF, this->getId());

    /* param 0: dim_x (Uint16) */
    FuncParam.ParamUint16 = dim_x;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 1: dim_z (Uint16) */
    FuncParam.ParamUint16 = dim_z;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 2: F (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = AKF->F_data;
    PrepareParam(&Command, 5u, sz_F, TYPE_RealArray, &FuncParam);

    /* param 3: H (RealArray, dim_z*dim_x) */
    FuncParam.ParamRealArray = AKF->H_data;
    PrepareParam(&Command, 3u, sz_H, TYPE_RealArray, &FuncParam);

    /* param 4: Q (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = AKF->Q_data;
    PrepareParam(&Command, 4u, sz_Q, TYPE_RealArray, &FuncParam);

    /* param 5: x_init (RealArray, dim_x) */
    FuncParam.ParamRealArray = AKF->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    /* param 6: R_init (Real) */
    FuncParam.ParamReal = AKF->R_init;
    PrepareParam(&Command, 6u, sz_real , TYPE_Real, &FuncParam);

    /* param 7: P_init (Real) */
    FuncParam.ParamReal = AKF->P_init;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    /* param 8: alpha (Real) */
    FuncParam.ParamReal = AKF->alpha;
    PrepareParam(&Command, 8u, sz_real, TYPE_Real, &FuncParam);

    /* param 9: Tune  */
    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 9u, sz_u8, TYPE_Uint8, &FuncParam);

    /* param 10: dimu  */
    FuncParam.ParamUint16 = AKF->dim_u;
    PrepareParam(&Command, 10u, sz_u16, TYPE_Uint16, &FuncParam);

  /* param 11: B realarray  */
  float dummy[2] = {1,1};
  if (AKF->dim_u != 0 )
  { 
    FuncParam.ParamRealArray = AKF->B_data;
    PrepareParam(&Command, 11u, sz_B, TYPE_RealArray, &FuncParam);
  }
  else
  {
    FuncParam.ParamRealArray = dummy; // dummy if the B is null
    PrepareParam(&Command, 11u, sz_B, TYPE_RealArray, &FuncParam);
  }
    /* send */
    HandleCmd(&Command, SerialDataSize);
}

adaptiveKF::adaptiveKF(PP_adaptiveKF* AKF,PP_Tune select)
{
    if (AKF == nullptr) return;

    /* dim_u > 0 declares control inputs and the board then reads
     * dim_x*dim_u floats of B, so a null B here would serialize through a
     * null pointer and put a malformed frame on the wire. Refuse before
     * anything is serialized. (With dim_u == 0 the board never uses B: a
     * pointer supplied anyway is simply not read.) */
    if ((AKF->dim_u != 0) && (AKF->B_data == nullptr))
    {
        SetDesignError(PP_DesignStatus::BadParam);
        return;
    }

    const uint16_t dim_x = AKF->dim_x;
    const uint16_t dim_z = AKF->dim_z;
    const uint16_t dim_u = AKF->dim_u;

    /* payload sizes (bytes) */
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_F    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_H    = (uint32_t)dim_z * (uint32_t)dim_x * sz_real;
    const uint32_t sz_Q    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_x0   = (uint32_t)dim_x * sz_real;
    const uint32_t sz_B  = (AKF->B_data != nullptr) ? (uint32_t)dim_x * dim_u * sz_real : (uint32_t)2* sz_real;
    /* total frame size */ 
    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_x
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_z
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_u
        + (PP_PARAM_INFO_SIZE + sz_F)     // F
        + (PP_PARAM_INFO_SIZE + sz_H)     // H
        + (PP_PARAM_INFO_SIZE + sz_Q)     // Q
        + (PP_PARAM_INFO_SIZE + sz_real )  // R_init
        + (PP_PARAM_INFO_SIZE + sz_x0)    // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)  // P_init
        + (PP_PARAM_INFO_SIZE + sz_real) //alpha
        + (PP_PARAM_INFO_SIZE + sz_B) // B
        + (PP_PARAM_INFO_SIZE + sz_u8); //tune

    PP_FuncParam FuncParam;

    /* header: 12 params */ 
    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 12u, NewAdaptiveKF, this->getId());

    /* param 0: dim_x (Uint16) */
    FuncParam.ParamUint16 = dim_x;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 1: dim_z (Uint16) */
    FuncParam.ParamUint16 = dim_z;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 2: F (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = AKF->F_data;
    PrepareParam(&Command, 5u, sz_F, TYPE_RealArray, &FuncParam);

    /* param 3: H (RealArray, dim_z*dim_x) */
    FuncParam.ParamRealArray = AKF->H_data;
    PrepareParam(&Command, 3u, sz_H, TYPE_RealArray, &FuncParam);

    /* param 4: Q (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = AKF->Q_data;
    PrepareParam(&Command, 4u, sz_Q, TYPE_RealArray, &FuncParam);

    /* param 5: x_init (RealArray, dim_x) */
    FuncParam.ParamRealArray = AKF->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    /* param 6: R_init (Real) */
    FuncParam.ParamReal = AKF->R_init;
    PrepareParam(&Command, 6u, sz_real , TYPE_Real, &FuncParam);

    /* param 7: P_init (Real) */
    FuncParam.ParamReal = AKF->P_init;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    /* param 8: alpha (Real) */
    FuncParam.ParamReal = AKF->alpha;
    PrepareParam(&Command, 8u, sz_real, TYPE_Real, &FuncParam);

    /* param 9: Tune. The caller's live-tune choice goes on the wire; the
     * board reads this byte and enables the live-tune input when it is
     * PP_LiveTune. This used to hardcode PP_NoLiveTune and drop select. */
    FuncParam.ParamUint8 = select;
    PrepareParam(&Command, 9u, sz_u8, TYPE_Uint8, &FuncParam);

    /* param 10: dimu  */
    FuncParam.ParamUint16 = AKF->dim_u;
    PrepareParam(&Command, 10u, sz_u16, TYPE_Uint16, &FuncParam);

  /* param 11: B realarray  */
  float dummy[2] = {1,1};
  if (AKF->dim_u != 0 )
  { 
    FuncParam.ParamRealArray = AKF->B_data;
    PrepareParam(&Command, 11u, sz_B, TYPE_RealArray, &FuncParam);
  }
  else
  {
    FuncParam.ParamRealArray = dummy; // dummy if the B is null
    PrepareParam(&Command, 11u, sz_B, TYPE_RealArray, &FuncParam);
  }
    /* send */
    HandleCmd(&Command, SerialDataSize);
}

linearKF::linearKF(PP_linearKF* LKF)
{
    if (LKF == nullptr) return;

    const uint16_t dim_x = LKF->dim_x;
    const uint16_t dim_z = LKF->dim_z;
    const uint16_t dim_u = LKF->dim_u;

    /* payload sizes (bytes) */
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_F    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_H    = (uint32_t)dim_z * (uint32_t)dim_x * sz_real;
    const uint32_t sz_Q    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_x0   = (uint32_t)dim_x * sz_real;
    const uint32_t sz_B  = (LKF->B_data != nullptr) ? (uint32_t)dim_x * dim_u * sz_real : (uint32_t)2* sz_real;
    /* total frame size */ 
    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_x
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_z
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_u
        + (PP_PARAM_INFO_SIZE + sz_F)     // F
        + (PP_PARAM_INFO_SIZE + sz_H)     // H
        + (PP_PARAM_INFO_SIZE + sz_Q)     // Q
        + (PP_PARAM_INFO_SIZE + sz_real )  // R_init
        + (PP_PARAM_INFO_SIZE + sz_x0)    // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)  // P_init
        + (PP_PARAM_INFO_SIZE + sz_B) // B
        + (PP_PARAM_INFO_SIZE + sz_u8); //tune

    PP_FuncParam FuncParam;

    /* header: 11 params */ 
    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 11u, NewIdealKF, this->getId());

    /* param 0: dim_x (Uint16) */
    FuncParam.ParamUint16 = dim_x;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 1: dim_z (Uint16) */
    FuncParam.ParamUint16 = dim_z;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 2: F (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = LKF->F_data;
    PrepareParam(&Command, 5u, sz_F, TYPE_RealArray, &FuncParam);

    /* param 3: H (RealArray, dim_z*dim_x) */
    FuncParam.ParamRealArray = LKF->H_data;
    PrepareParam(&Command, 3u, sz_H, TYPE_RealArray, &FuncParam);

    /* param 4: Q (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = LKF->Q_data;
    PrepareParam(&Command, 4u, sz_Q, TYPE_RealArray, &FuncParam);

    /* param 5: x_init (RealArray, dim_x) */
    FuncParam.ParamRealArray = LKF->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    /* param 6: R_init (Real) */
    FuncParam.ParamReal = LKF->R_init;
    PrepareParam(&Command, 6u, sz_real , TYPE_Real, &FuncParam);

    /* param 7: P_init (Real) */
    FuncParam.ParamReal = LKF->P_init;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    /* param 8: Tune  */
    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 8u, sz_u8, TYPE_Uint8, &FuncParam);

    /* param 9: dimu  */
    FuncParam.ParamUint16 = LKF->dim_u;
    PrepareParam(&Command, 9u, sz_u16, TYPE_Uint16, &FuncParam);

  /* param 10: B realarray  */
  float dummy[2] = {1,1};
  if (LKF->dim_u != 0 )
  { 
    FuncParam.ParamRealArray = LKF->B_data;
    PrepareParam(&Command, 10u, sz_B, TYPE_RealArray, &FuncParam);
  }
  else
  {
    FuncParam.ParamRealArray = dummy; // dummy if the B is null
    PrepareParam(&Command, 10u, sz_B, TYPE_RealArray, &FuncParam);
  }
    /* send */
    HandleCmd(&Command, SerialDataSize);
}

linearKF::linearKF(PP_linearKF* LKF,PP_Tune select )
{
    if (LKF == nullptr) return;

    const uint16_t dim_x = LKF->dim_x;
    const uint16_t dim_z = LKF->dim_z;
    const uint16_t dim_u = LKF->dim_u;

    /* payload sizes (bytes) */
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_F    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_H    = (uint32_t)dim_z * (uint32_t)dim_x * sz_real;
    const uint32_t sz_Q    = (uint32_t)dim_x * (uint32_t)dim_x * sz_real;
    const uint32_t sz_x0   = (uint32_t)dim_x * sz_real;
    const uint32_t sz_B  = (LKF->B_data != nullptr) ? (uint32_t)dim_x * dim_u * sz_real : (uint32_t)2* sz_real;
    /* total frame size */ 
    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_x
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_z
        + (PP_PARAM_INFO_SIZE + sz_u16)   // dim_u
        + (PP_PARAM_INFO_SIZE + sz_F)     // F
        + (PP_PARAM_INFO_SIZE + sz_H)     // H
        + (PP_PARAM_INFO_SIZE + sz_Q)     // Q
        + (PP_PARAM_INFO_SIZE + sz_real )  // R_init
        + (PP_PARAM_INFO_SIZE + sz_x0)    // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)  // P_init
        + (PP_PARAM_INFO_SIZE + sz_B) // B
        + (PP_PARAM_INFO_SIZE + sz_u8); //tune

    PP_FuncParam FuncParam;

    /* header: 11 params */ 
    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 11u, NewIdealKF, this->getId());

    /* param 0: dim_x (Uint16) */
    FuncParam.ParamUint16 = dim_x;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 1: dim_z (Uint16) */
    FuncParam.ParamUint16 = dim_z;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 2: F (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = LKF->F_data;
    PrepareParam(&Command, 5u, sz_F, TYPE_RealArray, &FuncParam);

    /* param 3: H (RealArray, dim_z*dim_x) */
    FuncParam.ParamRealArray = LKF->H_data;
    PrepareParam(&Command, 3u, sz_H, TYPE_RealArray, &FuncParam);

    /* param 4: Q (RealArray, dim_x*dim_x) */
    FuncParam.ParamRealArray = LKF->Q_data;
    PrepareParam(&Command, 4u, sz_Q, TYPE_RealArray, &FuncParam);

    /* param 5: x_init (RealArray, dim_x) */
    FuncParam.ParamRealArray = LKF->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    /* param 6: R_init (Real) */
    FuncParam.ParamReal = LKF->R_init;
    PrepareParam(&Command, 6u, sz_real , TYPE_Real, &FuncParam);

    /* param 7: P_init (Real) */
    FuncParam.ParamReal = LKF->P_init;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    /* param 8: Tune  */
    FuncParam.ParamUint8 = select;
    PrepareParam(&Command, 8u, sz_u8, TYPE_Uint8, &FuncParam);

    /* param 9: dimu  */
    FuncParam.ParamUint16 = LKF->dim_u;
    PrepareParam(&Command, 9u, sz_u16, TYPE_Uint16, &FuncParam);

  /* param 10: B realarray  */
  float dummy[2] = {1,1};
  if (LKF->dim_u != 0 )
  { 
    FuncParam.ParamRealArray = LKF->B_data;
    PrepareParam(&Command, 10u, sz_B, TYPE_RealArray, &FuncParam);
  }
  else
  {
    FuncParam.ParamRealArray = dummy; // dummy if the B is null
    PrepareParam(&Command, 10u, sz_B, TYPE_RealArray, &FuncParam);
  }
    /* send */
    HandleCmd(&Command, SerialDataSize);
}


stateSpace::stateSpace(PP_stateSpace* config)
{
    if (config == nullptr) return;

    const uint16_t n = config->n;
    const uint16_t m = config->m;
    const uint16_t p = config->p;

    /* payload sizes (bytes) */
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint32_t sz_A    = (uint32_t)n * (uint32_t)n * PP_REAL_SIZE;
    const uint32_t sz_B    = (uint32_t)n * (uint32_t)m * PP_REAL_SIZE;
    const uint32_t sz_C    = (uint32_t)p * (uint32_t)n * PP_REAL_SIZE;
    const uint32_t sz_D    = (uint32_t)p * (uint32_t)m * PP_REAL_SIZE;
    const uint32_t sz_x0   = (uint32_t)n * PP_REAL_SIZE;

    /* total frame size */
    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + 3 * (PP_PARAM_INFO_SIZE + sz_u16)   // n, m, p
        + (PP_PARAM_INFO_SIZE + sz_A)          // A
        + (PP_PARAM_INFO_SIZE + sz_B)          // B
        + (PP_PARAM_INFO_SIZE + sz_C)          // C
        + (PP_PARAM_INFO_SIZE + sz_D)          // D
        + (PP_PARAM_INFO_SIZE + sz_x0);        // x_init

    PP_FuncParam FuncParam;

    /* header: 8 params */
    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewStateSpace, this->getId());

    /* param 0: n (Uint16) */
    FuncParam.ParamUint16 = n;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 1: m (Uint16) */
    FuncParam.ParamUint16 = m;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 2: p (Uint16) */
    FuncParam.ParamUint16 = p;
    PrepareParam(&Command, 2u, sz_u16, TYPE_Uint16, &FuncParam);

    /* param 3: A (RealArray, n*n) */
    FuncParam.ParamRealArray = config->A_data;
    PrepareParam(&Command, 3u, sz_A, TYPE_RealArray, &FuncParam);

    /* param 4: B (RealArray, n*m) */
    FuncParam.ParamRealArray = config->B_data;
    PrepareParam(&Command, 4u, sz_B, TYPE_RealArray, &FuncParam);

    /* param 5: C (RealArray, p*n) */
    FuncParam.ParamRealArray = config->C_data;
    PrepareParam(&Command, 5u, sz_C, TYPE_RealArray, &FuncParam);

    /* param 6: D (RealArray, p*m) */
    FuncParam.ParamRealArray = config->D_data;
    PrepareParam(&Command, 6u, sz_D, TYPE_RealArray, &FuncParam);

    /* param 7: x_init (RealArray, n) */
    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 7u, sz_x0, TYPE_RealArray, &FuncParam);

    /* send */
    HandleCmd(&Command, SerialDataSize);

    /* ------------------------------------------------------------------
     * Vector-probe shape for the internal state vector x[k].
     *
     * The state vector is n elements wide, one row.  When the user
     * wires ``ss_block >> VectorProbe`` in Studio (or in C++ via
     * ``operator>>``), node::__rshift__ copies these two fields into
     * the destination VectorProbe so its allocated buffer size and the
     * firmware's auto-push frame width both match the state dimension.
     * ------------------------------------------------------------------ */
    this->dataLines = n;
    this->dataRaw = 1u;
}


compFilter::compFilter(PP_compFilter* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real);    // alpha

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewCompFilter, this->getId());

    FuncParam.ParamReal = config->alpha;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}


slidingModeObserver::slidingModeObserver(PP_SMO* config)
{
    if (config == nullptr) return;

    const uint16_t n = config->n;
    const uint16_t m = config->m;
    const uint16_t p = config->p;

    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_A    = (uint32_t)n * (uint32_t)n * sz_real;
    const uint32_t sz_B    = (uint32_t)n * (uint32_t)m * sz_real;
    const uint32_t sz_C    = (uint32_t)p * (uint32_t)n * sz_real;
    const uint32_t sz_L    = (uint32_t)n * (uint32_t)p * sz_real;
    const uint32_t sz_K    = (uint32_t)n * (uint32_t)p * sz_real;
    const uint32_t sz_x0   = (uint32_t)n * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + 3 * (PP_PARAM_INFO_SIZE + sz_u16)    // n, m, p
        + (PP_PARAM_INFO_SIZE + sz_A)           // A
        + (PP_PARAM_INFO_SIZE + sz_B)           // B
        + (PP_PARAM_INFO_SIZE + sz_C)           // C
        + (PP_PARAM_INFO_SIZE + sz_L)           // L
        + (PP_PARAM_INFO_SIZE + sz_K)           // K
        + (PP_PARAM_INFO_SIZE + sz_x0)          // x_init
        + (PP_PARAM_INFO_SIZE + sz_real);       // epsilon

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 10u, NewSMO, this->getId());

    FuncParam.ParamUint16 = n;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamUint16 = m;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamUint16 = p;
    PrepareParam(&Command, 2u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamRealArray = config->A_data;
    PrepareParam(&Command, 3u, sz_A, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->B_data;
    PrepareParam(&Command, 4u, sz_B, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->C_data;
    PrepareParam(&Command, 5u, sz_C, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->L_data;
    PrepareParam(&Command, 6u, sz_L, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->K_data;
    PrepareParam(&Command, 7u, sz_K, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 8u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->epsilon;
    PrepareParam(&Command, 9u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

/* ---- Application EKF blocks ---- */

pmsmEKF::pmsmEKF(PP_PMSM_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 4u * 4u * sz_real;   // 64 bytes
    const uint32_t sz_R    = 2u * 2u * sz_real;   // 16 bytes
    const uint32_t sz_x0   = 4u * sz_real;        // 16 bytes

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)    // Rs
        + (PP_PARAM_INFO_SIZE + sz_real)    // Ls
        + (PP_PARAM_INFO_SIZE + sz_real)    // lambda_pm
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)    // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewPMSM_EKF, this->getId());

    FuncParam.ParamReal = config->Rs;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Ls;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->lambda_pm;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 3u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 4u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 5u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 7u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

ahrsEKF::ahrsEKF(PP_AHRS_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_mag  = 3u * sz_real;         // 12 bytes
    const uint32_t sz_Q    = 7u * 7u * sz_real;    // 196 bytes
    const uint32_t sz_R    = 6u * 6u * sz_real;    // 144 bytes
    const uint32_t sz_x0   = 7u * sz_real;         // 28 bytes

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_mag)    // mag_ref
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 6u, NewAHRS_EKF, this->getId());

    FuncParam.ParamRealArray = config->mag_ref;
    PrepareParam(&Command, 0u, sz_mag, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 1u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 2u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 3u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 5u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

batterySOC_EKF::batterySOC_EKF(PP_BatterySOC_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_ocv  = 4u * sz_real;         // 16 bytes
    const uint32_t sz_Q    = 2u * 2u * sz_real;    // 16 bytes
    const uint32_t sz_R    = 1u * sz_real;          // 4 bytes
    const uint32_t sz_x0   = 2u * sz_real;          // 8 bytes

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // R0
        + (PP_PARAM_INFO_SIZE + sz_real)   // R1
        + (PP_PARAM_INFO_SIZE + sz_real)   // C1
        + (PP_PARAM_INFO_SIZE + sz_real)   // Q_cap
        + (PP_PARAM_INFO_SIZE + sz_ocv)    // ocv_coef
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 10u, NewBatterySOC_EKF, this->getId());

    FuncParam.ParamReal = config->R0;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->R1;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->C1;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Q_cap;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->ocv_coef;
    PrepareParam(&Command, 4u, sz_ocv, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 5u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 6u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 7u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 8u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 9u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

tiltEKF::tiltEKF(PP_Tilt_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 2u * 2u * sz_real;    // 16 bytes
    const uint32_t sz_R    = 1u * sz_real;          // 4 bytes
    const uint32_t sz_x0   = 2u * sz_real;          // 8 bytes

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewTilt_EKF, this->getId());

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 0u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 1u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 4u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

loadTorqueEKF::loadTorqueEKF(PP_LoadTorque_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 2u * 2u * sz_real;    // 16 bytes
    const uint32_t sz_R    = 1u * sz_real;          // 4 bytes
    const uint32_t sz_x0   = 2u * sz_real;          // 8 bytes

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // J
        + (PP_PARAM_INFO_SIZE + sz_real)   // B
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 7u, NewLoadTorque_EKF, this->getId());

    FuncParam.ParamReal = config->J;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->B;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 2u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 3u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 4u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 6u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

/* ================================================================
 *  NEW APPLICATION EKF BLOCKS
 * ================================================================ */

thermalEKF::thermalEKF(PP_Thermal_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 2u * 2u * sz_real;
    const uint32_t sz_R    = 1u * sz_real;
    const uint32_t sz_x0   = 2u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)    // R_th
        + (PP_PARAM_INFO_SIZE + sz_real)    // C_core
        + (PP_PARAM_INFO_SIZE + sz_real)    // C_surf
        + (PP_PARAM_INFO_SIZE + sz_real)    // R_conv
        + (PP_PARAM_INFO_SIZE + sz_real)    // T_amb
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 10u, NewThermal_EKF, this->getId());

    FuncParam.ParamReal = config->R_th;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->C_core;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->C_surf;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->R_conv;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->T_amb;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 5u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 6u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 7u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 8u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 9u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

baroAltEKF::baroAltEKF(PP_BaroAlt_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 3u * 3u * sz_real;
    const uint32_t sz_R    = 1u * sz_real;
    const uint32_t sz_x0   = 3u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewBaroAlt_EKF, this->getId());

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 0u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 1u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 4u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

robotLocEKF::robotLocEKF(PP_RobotLoc_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 3u * 3u * sz_real;
    const uint32_t sz_R    = 2u * 2u * sz_real;
    const uint32_t sz_x0   = 3u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // wheel_radius
        + (PP_PARAM_INFO_SIZE + sz_real)   // wheel_base
        + (PP_PARAM_INFO_SIZE + sz_real)   // landmark_x
        + (PP_PARAM_INFO_SIZE + sz_real)   // landmark_y
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 9u, NewRobotLoc_EKF, this->getId());

    FuncParam.ParamReal = config->wheel_radius;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->wheel_base;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->landmark_x;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->landmark_y;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 4u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 5u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 6u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 8u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

sinTrackEKF::sinTrackEKF(PP_SinTrack_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 3u * 3u * sz_real;
    const uint32_t sz_R    = 1u * sz_real;
    const uint32_t sz_x0   = 3u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewSinTrack_EKF, this->getId());

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 0u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 1u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 4u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

gridSyncEKF::gridSyncEKF(PP_GridSync_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 3u * 3u * sz_real;
    const uint32_t sz_R    = 1u * sz_real;
    const uint32_t sz_x0   = 3u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // nom_freq
        + (PP_PARAM_INFO_SIZE + sz_real)   // nom_amplitude
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 7u, NewGridSync_EKF, this->getId());

    FuncParam.ParamReal = config->nom_freq;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->nom_amplitude;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 2u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 3u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 4u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 6u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

acimEKF::acimEKF(PP_ACIM_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 5u * 5u * sz_real;
    const uint32_t sz_R    = 2u * 2u * sz_real;
    const uint32_t sz_x0   = 5u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Rs
        + (PP_PARAM_INFO_SIZE + sz_real)   // Rr
        + (PP_PARAM_INFO_SIZE + sz_real)   // Ls
        + (PP_PARAM_INFO_SIZE + sz_real)   // Lr
        + (PP_PARAM_INFO_SIZE + sz_real)   // Lm
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_pairs
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 11u, NewACIM_EKF, this->getId());

    FuncParam.ParamReal = config->Rs;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Rr;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Ls;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Lr;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Lm;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->P_pairs;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 6u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 7u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 8u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 9u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 10u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

batterySOH_EKF::batterySOH_EKF(PP_BatterySOH_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_ocv  = 4u * sz_real;
    const uint32_t sz_Q    = 3u * 3u * sz_real;
    const uint32_t sz_R    = 1u * sz_real;
    const uint32_t sz_x0   = 3u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // R1
        + (PP_PARAM_INFO_SIZE + sz_real)   // C1
        + (PP_PARAM_INFO_SIZE + sz_ocv)    // ocv_coef
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewBatterySOH_EKF, this->getId());

    FuncParam.ParamReal = config->R1;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->C1;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->ocv_coef;
    PrepareParam(&Command, 2u, sz_ocv, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 3u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 4u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 5u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 7u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}


wmrEKF::wmrEKF(PP_WMR_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_mag  = 2u * sz_real;
    const uint32_t sz_Q    = 7u * 7u * sz_real;
    const uint32_t sz_R    = 7u * 7u * sz_real;
    const uint32_t sz_x0   = 7u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // wheel_base
        + (PP_PARAM_INFO_SIZE + sz_mag)    // mag_ref
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 7u, NewWMR_EKF, this->getId());

    FuncParam.ParamReal = config->wheel_base;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->mag_ref;
    PrepareParam(&Command, 1u, sz_mag, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 2u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 3u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 4u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 6u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

gpsinsEKF::gpsinsEKF(PP_GPSINS_EKF* config)
{
    if (config == nullptr) return;

    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;
    const uint32_t sz_Q    = 7u * 7u * sz_real;
    const uint32_t sz_R    = 4u * 4u * sz_real;
    const uint32_t sz_x0   = 7u * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_Q)      // Q
        + (PP_PARAM_INFO_SIZE + sz_R)      // R
        + (PP_PARAM_INFO_SIZE + sz_x0)     // x_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_u8);    // tune

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewGPSINS_EKF, this->getId());

    FuncParam.ParamRealArray = config->Q_data;
    PrepareParam(&Command, 0u, sz_Q, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->R_data;
    PrepareParam(&Command, 1u, sz_R, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->x_init;
    PrepareParam(&Command, 2u, sz_x0, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = PP_NoLiveTune;
    PrepareParam(&Command, 4u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

/* ================================================================
 *  ADAPTIVE DSP BLOCKS
 * ================================================================ */

lms::lms(PP_LMSConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // mu
        + (PP_PARAM_INFO_SIZE + sz_u16)    // N
        + (PP_PARAM_INFO_SIZE + sz_u8)     // normalize
        + (PP_PARAM_INFO_SIZE + sz_real);  // delta

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewLMS, this->getId());

    FuncParam.ParamReal = config->mu;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint16 = config->N;
    PrepareParam(&Command, 1u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamUint8 = config->normalize;
    PrepareParam(&Command, 2u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamReal = config->delta;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

adaptiveNotch::adaptiveNotch(PP_AdaptiveNotchConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // init_freq
        + (PP_PARAM_INFO_SIZE + sz_real)   // Q_factor
        + (PP_PARAM_INFO_SIZE + sz_real);  // mu

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewAdaptiveNotch, this->getId());

    FuncParam.ParamReal = config->init_freq;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Q_factor;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->mu;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

dob::dob(PP_DOBConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    uint32_t sz_Gn = ((uint32_t)config->plant_ord + 1u) * sz_real;
    uint32_t sz_Qf = ((uint32_t)config->qf_ord + 1u) * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_Gn)    // Gn_num
        + (PP_PARAM_INFO_SIZE + sz_Gn)    // Gn_den
        + (PP_PARAM_INFO_SIZE + sz_Qf)    // Qf_num
        + (PP_PARAM_INFO_SIZE + sz_Qf)    // Qf_den
        + (PP_PARAM_INFO_SIZE + sz_u8)    // plant_ord
        + (PP_PARAM_INFO_SIZE + sz_u8);   // qf_ord

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 6u, NewDOB, this->getId());

    FuncParam.ParamRealArray = config->Gn_num;
    PrepareParam(&Command, 0u, sz_Gn, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Gn_den;
    PrepareParam(&Command, 1u, sz_Gn, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Qf_num;
    PrepareParam(&Command, 2u, sz_Qf, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Qf_den;
    PrepareParam(&Command, 3u, sz_Qf, TYPE_RealArray, &FuncParam);

    FuncParam.ParamUint8 = config->plant_ord;
    PrepareParam(&Command, 4u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamUint8 = config->qf_ord;
    PrepareParam(&Command, 5u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

esc::esc(PP_ESCConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // a
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega
        + (PP_PARAM_INFO_SIZE + sz_real)   // k
        + (PP_PARAM_INFO_SIZE + sz_real)   // hpf_wc
        + (PP_PARAM_INFO_SIZE + sz_real);  // lpf_wc

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewESC, this->getId());

    FuncParam.ParamReal = config->a;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->k;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->hpf_wc;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->lpf_wc;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

adrc::adrc(PP_ADRCConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // b0
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega_o
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega_c
        + (PP_PARAM_INFO_SIZE + sz_u8);    // order

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewADRC, this->getId());

    FuncParam.ParamReal = config->b0;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega_o;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega_c;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = config->order;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

mrac::mrac(PP_MRACConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Am
        + (PP_PARAM_INFO_SIZE + sz_real)   // Bm
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_x
        + (PP_PARAM_INFO_SIZE + sz_real);  // gamma_r

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewMRAC, this->getId());

    FuncParam.ParamReal = config->Am;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Bm;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_x;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_r;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

mracLyapunov::mracLyapunov(PP_MRACLyapunovConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Am
        + (PP_PARAM_INFO_SIZE + sz_real)   // Bm
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_x
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_r
        + (PP_PARAM_INFO_SIZE + sz_real)   // sigma
        + (PP_PARAM_INFO_SIZE + sz_real);  // theta_max

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 6u, NewMRAC_Lyapunov, this->getId());

    FuncParam.ParamReal = config->Am;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Bm;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_x;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_r;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->sigma;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->theta_max;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

repetitiveCtrl::repetitiveCtrl(PP_RepCtrlConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)    // period_samples
        + (PP_PARAM_INFO_SIZE + sz_real)   // Q_gain
        + (PP_PARAM_INFO_SIZE + sz_real);  // Kr

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewRepetitiveCtrl, this->getId());

    FuncParam.ParamUint16 = config->period_samples;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = config->Q_gain;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Kr;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

str::str(PP_STRConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    uint32_t sz_poles = (uint32_t)config->na * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u8)     // na
        + (PP_PARAM_INFO_SIZE + sz_u8)     // nb
        + (PP_PARAM_INFO_SIZE + sz_real)   // lambda
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_poles); // desired_poles

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewSTR, this->getId());

    FuncParam.ParamUint8 = config->na;
    PrepareParam(&Command, 0u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamUint8 = config->nb;
    PrepareParam(&Command, 1u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamReal = config->lambda;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamRealArray = config->desired_poles;
    PrepareParam(&Command, 4u, sz_poles, TYPE_RealArray, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

ilc::ilc(PP_ILCConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)    // trial_length
        + (PP_PARAM_INFO_SIZE + sz_real)   // L_gain
        + (PP_PARAM_INFO_SIZE + sz_real);  // Q_gain

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewILC, this->getId());

    FuncParam.ParamUint16 = config->trial_length;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = config->L_gain;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Q_gain;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

/* ================================================================
 *  SELF-TUNING PID BLOCKS
 * ================================================================ */

gainSchedulePID::gainSchedulePID(PP_GainSchedulePIDConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    uint32_t sz_tbl = (uint32_t)config->num_points * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_tbl)    // schedule_points
        + (PP_PARAM_INFO_SIZE + sz_tbl)    // Kp_table
        + (PP_PARAM_INFO_SIZE + sz_tbl)    // Ki_table
        + (PP_PARAM_INFO_SIZE + sz_tbl)    // Kd_table
        + (PP_PARAM_INFO_SIZE + sz_real)   // Tau
        + (PP_PARAM_INFO_SIZE + sz_real)   // out_min
        + (PP_PARAM_INFO_SIZE + sz_real)   // out_max
        + (PP_PARAM_INFO_SIZE + sz_u8);    // num_points

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewGainSchedulePID, this->getId());

    FuncParam.ParamRealArray = config->schedule_points;
    PrepareParam(&Command, 0u, sz_tbl, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Kp_table;
    PrepareParam(&Command, 1u, sz_tbl, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Ki_table;
    PrepareParam(&Command, 2u, sz_tbl, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->Kd_table;
    PrepareParam(&Command, 3u, sz_tbl, TYPE_RealArray, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_min;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_max;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = config->num_points;
    PrepareParam(&Command, 7u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

gainScheduler::gainScheduler(PP_GainSchedulerConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    uint32_t sz_bp  = (uint32_t)config->num_points * sz_real;
    uint32_t sz_val = (uint32_t)config->num_points * (uint32_t)config->num_outputs * sz_real;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_bp)     // breakpoints
        + (PP_PARAM_INFO_SIZE + sz_val)    // values
        + (PP_PARAM_INFO_SIZE + sz_u8)     // num_points
        + (PP_PARAM_INFO_SIZE + sz_u8);    // num_outputs

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewGainScheduler, this->getId());

    FuncParam.ParamRealArray = config->breakpoints;
    PrepareParam(&Command, 0u, sz_bp, TYPE_RealArray, &FuncParam);

    FuncParam.ParamRealArray = config->values;
    PrepareParam(&Command, 1u, sz_val, TYPE_RealArray, &FuncParam);

    FuncParam.ParamUint8 = config->num_points;
    PrepareParam(&Command, 2u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamUint8 = config->num_outputs;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

relayAutoTune::relayAutoTune(PP_RelayAutoTuneConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // relay_amplitude
        + (PP_PARAM_INFO_SIZE + sz_real)   // hysteresis
        + (PP_PARAM_INFO_SIZE + sz_real)   // setpoint
        + (PP_PARAM_INFO_SIZE + sz_u8)     // tuning_rule
        + (PP_PARAM_INFO_SIZE + sz_u16);   // min_cycles

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewRelayAutoTune, this->getId());

    FuncParam.ParamReal = config->relay_amplitude;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->hysteresis;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->setpoint;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = config->tuning_rule;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamUint16 = config->min_cycles;
    PrepareParam(&Command, 4u, sz_u16, TYPE_Uint16, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

stepAutoTune::stepAutoTune(PP_StepAutoTuneConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u8   = PP_UINT8_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // step_size
        + (PP_PARAM_INFO_SIZE + sz_real)   // settle_pct
        + (PP_PARAM_INFO_SIZE + sz_u8)     // tuning_rule
        + (PP_PARAM_INFO_SIZE + sz_u8);    // id_method

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewStepAutoTune, this->getId());

    FuncParam.ParamReal = config->step_size;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->settle_pct;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = config->tuning_rule;
    PrepareParam(&Command, 2u, sz_u8, TYPE_Uint8, &FuncParam);

    FuncParam.ParamUint8 = config->id_method;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

strPID::strPID(PP_STR_PID_Config* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;

    /* Clamped here as well as on the board, so a value a caller made up
     * never reaches the wire. */
    uint16_t div = config->UpdateDivider_u16;
    if (div < 1u) { div = 1u; }
    if (div > 64u) { div = 64u; }

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // lambda
        + (PP_PARAM_INFO_SIZE + sz_real)   // P_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Tau
        + (PP_PARAM_INFO_SIZE + sz_real)   // desired_cl_bw
        + (PP_PARAM_INFO_SIZE + sz_u16);   // UpdateDivider_u16

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewSTR_PID, this->getId());

    FuncParam.ParamReal = config->lambda;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->P_init;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->desired_cl_bw;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    /* A board built before this parameter existed reads a shorter frame and
     * defaults it to 1, so the longer frame is safe to send to either. */
    FuncParam.ParamUint16 = div;
    PrepareParam(&Command, 4u, sz_u16, TYPE_Uint16, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

mracPID::mracPID(PP_MRAC_PID_Config* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Am
        + (PP_PARAM_INFO_SIZE + sz_real)   // Bm
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_p
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_i
        + (PP_PARAM_INFO_SIZE + sz_real)   // gamma_d
        + (PP_PARAM_INFO_SIZE + sz_real);  // Tau

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 6u, NewMRAC_PID, this->getId());

    FuncParam.ParamReal = config->Am;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Bm;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_p;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_i;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->gamma_d;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

escPID::escPID(PP_ESC_PID_Config* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kp_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Ki_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kd_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // a
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega_p
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega_i
        + (PP_PARAM_INFO_SIZE + sz_real)   // omega_d
        + (PP_PARAM_INFO_SIZE + sz_real)   // esc_gain
        + (PP_PARAM_INFO_SIZE + sz_real)   // lpf_wc
        + (PP_PARAM_INFO_SIZE + sz_real)   // Tau
        + (PP_PARAM_INFO_SIZE + sz_real);  // iae_window

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 11u, NewESC_PID, this->getId());

    FuncParam.ParamReal = config->Kp_init;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Ki_init;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Kd_init;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->a;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega_p;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega_i;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->omega_d;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->esc_gain;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->lpf_wc;
    PrepareParam(&Command, 8u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 9u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->iae_window;
    PrepareParam(&Command, 10u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

perfMonitorPID::perfMonitorPID(PP_PerfMonPID_Config* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kp_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Ki_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kd_init
        + (PP_PARAM_INFO_SIZE + sz_real)   // Tau
        + (PP_PARAM_INFO_SIZE + sz_real)   // iae_threshold
        + (PP_PARAM_INFO_SIZE + sz_real)   // out_min
        + (PP_PARAM_INFO_SIZE + sz_real)   // out_max
        + (PP_PARAM_INFO_SIZE + sz_real);  // eval_window

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewPerfMonitor_PID, this->getId());

    FuncParam.ParamReal = config->Kp_init;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Ki_init;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Kd_init;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->iae_threshold;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_min;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_max;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->eval_window;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

fuzzyPID::fuzzyPID(PP_FuzzyPIDConfig* config)
{
    if (config == nullptr) return;

    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kp_base
        + (PP_PARAM_INFO_SIZE + sz_real)   // Ki_base
        + (PP_PARAM_INFO_SIZE + sz_real)   // Kd_base
        + (PP_PARAM_INFO_SIZE + sz_real)   // e_range
        + (PP_PARAM_INFO_SIZE + sz_real)   // de_range
        + (PP_PARAM_INFO_SIZE + sz_real)   // Tau
        + (PP_PARAM_INFO_SIZE + sz_real)   // out_min
        + (PP_PARAM_INFO_SIZE + sz_real);  // out_max

    PP_FuncParam FuncParam;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 8u, NewFuzzyPID, this->getId());

    FuncParam.ParamReal = config->Kp_base;
    PrepareParam(&Command, 0u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Ki_base;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Kd_base;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->e_range;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->de_range;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->Tau;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_min;
    PrepareParam(&Command, 6u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = config->out_max;
    PrepareParam(&Command, 7u, sz_real, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

/* ================================================================
 *  MISCELLANEOUS BLOCKS
 * ================================================================ */

momentaryPower::momentaryPower(uint16_t windowSize)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewMomentaryPower, this->getId());

    FuncParam.ParamUint16 = windowSize;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

maxObserver::maxObserver(uint8_t windowSize)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewMaxObserver, this->getId());

    /* the byte is a sliding-window length in samples, not an input count */
    FuncParam.ParamUint8 = windowSize;
    PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

minObserver::minObserver(uint8_t windowSize)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewMinObserver, this->getId());

    /* the byte is a sliding-window length in samples, not an input count */
    FuncParam.ParamUint8 = windowSize;
    PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

mux::mux(uint8_t numInputs)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewMux, this->getId());

    FuncParam.ParamUint8 = numInputs;
    PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

demux::demux(uint8_t numOutputs)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, (PP_SubFuncId)NewDemux, this->getId());

    FuncParam.ParamUint8 = numOutputs;
    PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

loudness::loudness()
{
    uint16_t SerialDataSize = PP_FIXED_SIZE;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 0u, (PP_SubFuncId)NewLoudness, this->getId());

    HandleCmd(&Command, SerialDataSize);
}

cpuLoad::cpuLoad()
{
    uint16_t SerialDataSize = PP_FIXED_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 0u, (PP_SubFuncId)NewCpuLoad, this->getId());

    HandleCmd(&Command, SerialDataSize);
}

extSensor::extSensor(PP_HwId hwId, PP_SensorPartNumber partNumber, float outScale)
{
    PP_FuncParam FuncParam;
    /* Wire format: 3 params (hwId u16, partNumber u16, outScale real), which
     * is what the board expects for NewExtSensor.  An earlier 1-param form
     * was rejected by the board. */
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_HW_ROUTINE_ID_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                              PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, (PP_SubFuncId)NewExtSensor, this->getId());

    FuncParam.ParamUint16 = (uint16_t)hwId;
    PrepareParam(&Command, 0u, PP_HW_ROUTINE_ID_SIZE, TYPE_Uint16, &FuncParam);

    FuncParam.ParamUint16 = (uint16_t)partNumber;
    PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = outScale;
    PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

decibelsConverter::decibelsConverter()
{
    uint16_t SerialDataSize = PP_FIXED_SIZE;

    this->setId(currentNodeId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 0u, (PP_SubFuncId)NewDecibelsConverter, this->getId());

    HandleCmd(&Command, SerialDataSize);
}

combFeedForward::combFeedForward(uint16_t delay, float gain)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                              PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)NewCombFeedForward, this->getId());

    FuncParam.ParamUint16 = delay;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = gain;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

combFeedBack::combFeedBack(uint16_t delay, float gain)
{
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                              PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                              PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, (PP_SubFuncId)NewCombFeedBack, this->getId());

    FuncParam.ParamUint16 = delay;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = gain;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}


RRLS::RRLS(PP_RRLSParam* data)
{

  if (data == NULL) return;

    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_u16 = PP_UINT16_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;

    // Size of numerator and denominator arrays
    uint32_t sz_num = (data->lenNum)*sz_real;
    uint32_t sz_denom = (data->lenDenom)*sz_real;

    /* Clamped here as well as on the board, so a value the caller made up
     * never reaches the wire. 0 is not a rate and past 64 the anti-alias
     * cutoff falls below what the fit could resolve. */
    uint16_t div = data->UpdateDivider_u16;
    if (div < 1u) { div = 1u; }
    if (div > 64u) { div = 64u; }

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_num)       // numerator array
        + (PP_PARAM_INFO_SIZE + sz_denom)     // denominator array
        + (PP_PARAM_INFO_SIZE + sz_real)      // InitVariance_f32
        + (PP_PARAM_INFO_SIZE + sz_u8)        // ModelOrder_u8
        + (PP_PARAM_INFO_SIZE + sz_real)      // sensParam_f32
        + (PP_PARAM_INFO_SIZE + sz_u16);      // UpdateDivider_u16

    PP_FuncParam FuncParam;
    this->setId(node::currentNodeId++);   // allocate block id BEFORE wire frame
    this->dataLines = (2*data->ModelOrder_u8) +1;
    this->dataRaw = 1;
    // Header
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 6u, NewRRLS, this->getId());

    // Param 0: numerator array
    FuncParam.ParamRealArray = data->num;
    PrepareParam(&Command, 0u, sz_num, TYPE_RealArray, &FuncParam);

    // Param 1: denominator array
    FuncParam.ParamRealArray = data->denom;
    PrepareParam(&Command, 1u, sz_denom, TYPE_RealArray, &FuncParam);

    // Param 2: InitVariance
    FuncParam.ParamReal = data->InitVariance_f32;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    // Param 3: ModelOrder
    FuncParam.ParamUint8 = data->ModelOrder_u8;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    // Param 4: Sensitivity
    FuncParam.ParamReal = data->sensParam_f32;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    // Param 5: UpdateDivider. See the note in the RLS constructor.
    FuncParam.ParamUint16 = div;
    PrepareParam(&Command, 5u, sz_u16, TYPE_Uint16, &FuncParam);

    // Send command
    HandleCmd(&Command, SerialDataSize);

}

RLS::RLS(PP_RLSParam* data)
{

  if (data == NULL) return;

    const uint16_t sz_u8  = PP_UINT8_SIZE;
    const uint16_t sz_u16 = PP_UINT16_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;

    // Size of numerator and denominator arrays
    uint32_t sz_num = (data->lenNum)*sz_real;
    uint32_t sz_denom = (data->lenDenom)*sz_real;

    /* Clamped here as well as on the board, so a value the caller made up
     * never reaches the wire. 0 is not a rate and past 64 the anti-alias
     * cutoff falls below what the fit could resolve. */
    uint16_t div = data->UpdateDivider_u16;
    if (div < 1u) { div = 1u; }
    if (div > 64u) { div = 64u; }

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_num)       // numerator array
        + (PP_PARAM_INFO_SIZE + sz_denom)     // denominator array
        + (PP_PARAM_INFO_SIZE + sz_real)      // InitVariance_f32
        + (PP_PARAM_INFO_SIZE + sz_u8)         // ModelOrder_u8
        + (PP_PARAM_INFO_SIZE + sz_u16);       // UpdateDivider_u16

    PP_FuncParam FuncParam;
    this->setId(node::currentNodeId++);   // allocate block id BEFORE wire frame
    this->dataLines = (2*data->ModelOrder_u8) +1;
    this->dataRaw = 1;
    // Header
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewRLS, this->getId());

    // Param 0: numerator array
    FuncParam.ParamRealArray = data->num;
    PrepareParam(&Command, 0u, sz_num, TYPE_RealArray, &FuncParam);

    // Param 1: denominator array
    FuncParam.ParamRealArray = data->denom;
    PrepareParam(&Command, 1u, sz_denom, TYPE_RealArray, &FuncParam);

    // Param 2: InitVariance
    FuncParam.ParamReal = data->InitVariance_f32;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    // Param 3: ModelOrder
    FuncParam.ParamUint8 = data->ModelOrder_u8;
    PrepareParam(&Command, 3u, sz_u8, TYPE_Uint8, &FuncParam);

    // Param 4: UpdateDivider. A board built before this parameter existed
    // reads a shorter frame and defaults it to 1, which is the behaviour it
    // already had, so the longer frame is safe to send to either.
    FuncParam.ParamUint16 = div;
    PrepareParam(&Command, 4u, sz_u16, TYPE_Uint16, &FuncParam);

    // Send command
    HandleCmd(&Command, SerialDataSize);

}

/* pidFromModel Class ######################################################################################################### */

/* The identifier is a CONSTRUCTOR argument and not an input port, because
 * what this block reads is the identifier's private parameter vector and no
 * wire carries that. Only the identifier's block id travels, exactly as
 * fftMagResolver takes its fft.
 *
 * Two overloads rather than a base class, because the board accepts an RLS or
 * an RRLS and nothing else, and a compile error naming both is a better
 * refusal than a runtime one. They share every line, so the frame is built
 * once. */
static void PP_BuildPidFromModel ( uint16_t identifierId,
                                   uint16_t selfId, float lambda_c,
                                   float gain_slew_per_s, float kp_max,
                                   float ki_max, float kd_max,
                                   bool report_status )
{
    const uint16_t sz_u8   = PP_UINT8_SIZE;
    const uint16_t sz_u16  = PP_UINT16_SIZE;
    const uint16_t sz_real = PP_REAL_SIZE;

    uint32_t SerialDataSize =
          PP_FIXED_SIZE
        + (PP_PARAM_INFO_SIZE + sz_u16)       // identifier block id
        + (PP_PARAM_INFO_SIZE + sz_real)      // lambda_c
        + (PP_PARAM_INFO_SIZE + sz_real)      // gain_slew_per_s
        + (PP_PARAM_INFO_SIZE + sz_real)      // kp_max
        + (PP_PARAM_INFO_SIZE + sz_real)      // ki_max
        + (PP_PARAM_INFO_SIZE + sz_real)      // kd_max
        + (PP_PARAM_INFO_SIZE + sz_u8);       // report_status

    PP_FuncParam FuncParam;
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 7u,
                     NewPidFromModel, selfId);

    FuncParam.ParamUint16 = identifierId;
    PrepareParam(&Command, 0u, sz_u16, TYPE_Uint16, &FuncParam);

    FuncParam.ParamReal = lambda_c;
    PrepareParam(&Command, 1u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = gain_slew_per_s;
    PrepareParam(&Command, 2u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = kp_max;
    PrepareParam(&Command, 3u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = ki_max;
    PrepareParam(&Command, 4u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = kd_max;
    PrepareParam(&Command, 5u, sz_real, TYPE_Real, &FuncParam);

    FuncParam.ParamUint8 = report_status ? 1u : 0u;
    PrepareParam(&Command, 6u, sz_u8, TYPE_Uint8, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

pidFromModel::pidFromModel(RLS identifier, float lambda_c,
                           float gain_slew_per_s, float kp_max,
                           float ki_max, float kd_max)
{
    this->setId(node::currentNodeId++);
    /* Eight floats reach a vector probe: Kp, Ki, Kd, the derivative filter
     * time constant, the identified DC gain, its natural frequency in hertz,
     * its damping ratio, and the status code. */
    this->dataLines = 8;
    this->dataRaw = 1;
    PP_BuildPidFromModel(identifier.getId(), this->getId(),
                         lambda_c, gain_slew_per_s, kp_max, ki_max, kd_max,
                         false);
}

pidFromModel::pidFromModel(RRLS identifier, float lambda_c,
                           float gain_slew_per_s, float kp_max,
                           float ki_max, float kd_max)
{
    this->setId(node::currentNodeId++);
    this->dataLines = 8;
    this->dataRaw = 1;
    PP_BuildPidFromModel(identifier.getId(), this->getId(),
                         lambda_c, gain_slew_per_s, kp_max, ki_max, kd_max,
                         false);
}

/* VectorProbe Class ########################################################################################################### */
VectorProbe::VectorProbe()
{
  BindObjectToActiveContext(this->contextSlot);
};
VectorProbe::VectorProbe(const char *label)
{
  BindObjectToActiveContext(this->contextSlot);
  PP_FuncParam FuncParam;
  uint16_t labelLen;
  uint16_t SerialDataSize;

  if (TryGetCStringPayloadSize(label, labelLen) == false)
  {
    return;
  }

  SerialDataSize = PP_FIXED_SIZE +
                   PP_PARAM_INFO_SIZE + labelLen;

  /* 1. Prepare Configuration : Header + Function Info */
  this->label = label;
  this->id = currentVectorProbeId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewVectorProbe, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamString = label;
  PrepareParam(&Command, 0u, labelLen, TYPE_String, &FuncParam);

  /* 2. Send Configuration Request */
  HandleCmdVect(&Command, SerialDataSize);
}

uint16_t VectorProbe::getId()
{
  return this->id;
}

void VectorProbe::setId(uint16_t id)
{
  this->id = id;
}

uint8_t VectorProbe::getContextSlot() const
{
  return this->contextSlot;
}

void VectorProbe::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

uint32_t VectorProbe::getBufferOffsetBytes() const
{
  return this->bufferOffsetBytes;
}

void VectorProbe::setBufferOffsetBytes(uint32_t offsetBytes)
{
  this->bufferOffsetBytes = offsetBytes;
}

void VectorProbe::addToQueue()
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  /* If the preceding LinkSys2VectorProbe / LinkNode2VectorProbe (or any
   * prior command) failed and latched a non-OK design status, do NOT
   * advance the host vector-probe counter and do NOT accumulate
   * VectorProbeBytes. Otherwise the host's byte-layout map drifts past
   * what the firmware actually transmits → silent misalignment of
   * every subsequent getVectorProbes() read. */
  if (currentDesignStatus != PP_DesignStatus::DesignOk)
  {
    return;
  }

  /* Idempotent: a vector probe wired to multiple sources occupies one
   * firmware slot and one byte-offset window. Re-advancing the host
   * counter (and re-accumulating VectorProbeBytes) would corrupt the
   * byte-layout map and over-allocate per-frame transfer space. */
  if (this->idx != 0xFFu)
  {
    return;
  }

  if (currentVectorProbeIdx >= PP_MAX_VECTOR_PROBES_NUMBER)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  /* Own the byte-offset bookkeeping here (callers used to do it before
   * calling addToQueue, which made the operation non-idempotent and
   * forced every caller to repeat the formula). */
  this->bufferOffsetBytes = VectorProbe::VectorProbeBytes;
  VectorProbe::VectorProbeBytes += (uint32_t)this->dataLines *
                                   (uint32_t)this->dataRaw *
                                   (uint32_t)PP_REAL_SIZE;
  this->idx = currentVectorProbeIdx++;
}

const char *VectorProbe::getLabel()
{
  return this->label;
}

void VectorProbe::getSamples(float* samples, uint16_t nbrOfSamples)
{
  if (samples == NULL)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  uint16_t maxSamples = this->dataLines * this->dataRaw;
  if (nbrOfSamples > maxSamples)
  {
    nbrOfSamples = maxSamples;
  }

  /* Never read past what getVectorProbes() actually kept. On the MCU
   * profile the buffer holds one 400-byte chunk per probe and the rest
   * of the frame is drained, so a probe whose window starts beyond the
   * buffer has nothing to give; without this the read walked off the
   * end of a static array. */
  const uint32_t capacity = (uint32_t)sizeof(VectorProbesBuffer);
  if (this->bufferOffsetBytes >= capacity)
  {
    return;
  }
  const uint32_t held = (capacity - this->bufferOffsetBytes) / PP_REAL_SIZE;
  if ((uint32_t)nbrOfSamples > held)
  {
    nbrOfSamples = (uint16_t)held;
  }

  const uint8_t *base = &VectorProbesBuffer[this->bufferOffsetBytes];
  memcpy((void*)samples, (const void*)base, nbrOfSamples * PP_REAL_SIZE);
}

void VectorProbe::show(void)
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  uint16_t samplesSize = this->dataLines * this->dataRaw;

  /* Same clamp as getSamples(): print what the buffer holds, not what
   * the design would have produced with unlimited RAM. */
  const uint32_t capacity = (uint32_t)sizeof(VectorProbesBuffer);
  if (this->bufferOffsetBytes >= capacity)
  {
    Serial.println();
    return;
  }
  const uint32_t held = (capacity - this->bufferOffsetBytes) / PP_REAL_SIZE;
  if ((uint32_t)samplesSize > held)
  {
    samplesSize = (uint16_t)held;
  }

  const uint8_t *base = &VectorProbesBuffer[this->bufferOffsetBytes];

  for (uint16_t s = 0u; s < samplesSize; ++s)
  {
    float val;
    memcpy(&val, base + (uint32_t)s * PP_REAL_SIZE, PP_REAL_SIZE);
    Serial.print(val);
    Serial.print(' ');
  }

  Serial.println();
}


/* Macro Class ########################################################################################################### */
macro::macro()
{
  BindObjectToActiveContext(this->contextSlot);
  /* Default port selection: first input and first output */
  this->activeInIdx  = 0u;
  this->activeOutIdx = 0u;
}

uint16_t macro::getId()
{
  return this->id;
}

void macro::setId(uint16_t id)
{
  this->id = id;
}

uint8_t macro::getContextSlot() const
{
  return this->contextSlot;
}

void macro::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

macro macro::in(uint8_t InIdx)
{
  /* Return a CONFIGURED COPY (see node::in() for rationale).  The macro
   * keeps the cross-set of activeInIdx == activeOutIdx on the copy so the
   * single ``> macro.in(N)`` expression carries N to either side of the
   * link, without leaking that N back into the original instance, which
   * would cause the next bare ``macro > probe`` to ship port N (often
   * out-of-range for a macro's tiny output map) and trip BadParam (=6)
   * inside the firmware. */
  macro tmp = *this;
  tmp.activeInIdx = InIdx;
  tmp.activeOutIdx = InIdx;
  return tmp;
}

macro macro::out(uint8_t OutIdx)
{
  macro tmp = *this;
  tmp.activeOutIdx = OutIdx;
  tmp.activeInIdx = OutIdx;
  return tmp;
}

/* in()/out() set a "sticky" active port that the very next > consumes.
 * After a link is sent, both indices must drop back to 0 so that a later
 * implicit link like `pid > motor` (no explicit .out(N)) does not pick
 * up the last index used in a previous `.in(N)` and ship "macro output N"
 * to the firmware, which rejects out-of-range port indices as BadParam
 * (status 6).  This mirrors the Python lib's `_consume_active_ports`
 * called at the tail of every `__gt__` overload. */
static inline void _macro_consume_active_ports(macro *self)
{
  self->in(0);
  self->out(0);
}

void macro::operator>(tf Dst) // Macro2Sys
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  /* Source uses activeOutIdx, destination TF input is implicitly 0 */
  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), 0xFF, LinkMacro2Sys);
  _macro_consume_active_ports(this);
}

void macro::operator>(probe &Dst) // Macro2Probe
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  /* Source uses activeOutIdx, destination probe input is implicit */
  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), 0xFF, LinkMacro2Probe);
  Dst.addToQueue();
  _macro_consume_active_ports(this);
}

void macro::operator>(node Dst) // Macro2Node
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  /* Source uses activeOutIdx, destination node input index is provided by the node */
  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), Dst.getActiveInIdx(), LinkMacro2Node);
  _macro_consume_active_ports(this);
}

void macro::operator>(macro Dst) // Macro2Macro
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  /* Source uses activeOutIdx, destination uses its active input index */
  Linkblock2block(this->id, this->activeOutIdx, Dst.getId(), Dst.getActiveInIdx(), LinkMacro2Macro);
  _macro_consume_active_ports(this);
  /* Dst is by-value here, so resetting its ports does not affect the
   * caller's instance; that's a known limitation of the C++ pass-by-value
   * signature, but it does not cause the same bug as the source side
   * because Dst's active index is also implicitly consumed each time the
   * caller passes a fresh `dst.in(N)` rvalue. */
}

uint8_t macro::getActiveInIdx()
{
  return this->activeInIdx;
}

uint8_t macro::getActiveOutIdx()
{
  return this->activeOutIdx;
}

void macro::start()
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Manageblock, 0u, StartMacro, this->id);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

void macro::stop()
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Manageblock, 0u, StopMacro, this->id);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

macro::macro(uint8_t NbrOfInputs, uint8_t NbrOfOutputs)
{
  BindObjectToActiveContext(this->contextSlot);
  /* Default port selection: first input and first output */
  this->activeInIdx  = 0u;
  this->activeOutIdx = 0u;

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentMacroId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewMacro, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = NbrOfInputs;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = NbrOfOutputs;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

/* The board has no downsampling block, so both constructors build an
 * empty 1-in / 1-out macro and ignore their arguments: the signal passes
 * through unaltered, at the design's own rate. Declared here so a
 * hand-written sketch that names the class still compiles and wires up;
 * see the warning on the class in PAPAYA.h. */
decimation::decimation(float *Buffer)
  : macro(1u, 1u)
{
  (void)Buffer;
}

decimation::decimation(uint8_t factor, float gain, float fc, uint8_t filter_order)
  : macro(1u, 1u)
{
  (void)factor;
  (void)gain;
  (void)fc;
  (void)filter_order;
}


butterBq::butterBq(uint8_t n, float fc, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getButterBqSubFuncId(ftype);

  if ((NewBiquadButterLow == SubFuncId) || (NewBiquadButterHigh == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

butter::butter(uint8_t n, float fc, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getButterSubFuncId(ftype);

  if ((NewButterLow == SubFuncId) || (NewButterHigh == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;

    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

butterBq::butterBq(uint8_t n, float fc1, float fc2, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getButterBqSubFuncId(ftype);

  if ((NewBiquadButterBand == SubFuncId) || (NewBiquadButterStop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

butter::butter(uint8_t n, float fc1, float fc2, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getButterSubFuncId(ftype);

  if ((NewButterBand == SubFuncId) || (NewButterStop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}
fir::fir(uint16_t N, float f1, PP_FirWindowType wt, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getFirSubFuncId(ftype);

  if ((NewFirLow == SubFuncId) || (NewFirHigh == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;

    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamUint16 = N;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = f1;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint32 = wt;
    PrepareParam(&Command, 2u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

    /* 4. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

fir::fir(uint16_t N, float f1, float f2, PP_FirWindowType wt, PP_FilterType ftype)
{
  PP_SubFuncId SubFuncId = getFirSubFuncId(ftype);

  if ((NewFirBand == SubFuncId) || (NewFirStop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;

    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT16_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamUint16 = N;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = f1;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    FuncParam.ParamReal = f2;
    PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint32 = wt;
    PrepareParam(&Command, 3u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

    /* 4. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}
CustFir::CustFir(float *coeff, uint16_t taps)
{
  PP_CommandInfo Command;
  PP_FuncParam FuncParam;
  uint16_t param1_size = taps * PP_REAL_SIZE;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + param1_size +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewCustFir, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamRealArray = coeff;
  PrepareParam(&Command, 0u, param1_size, TYPE_RealArray, &FuncParam);

  /* 4. Prepare Param_2 */
  FuncParam.ParamUint16 = taps;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

period::period(float Max, float Min, float Epsilon)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewPeriodMeter, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Max;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = Min;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamReal = Epsilon;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 6. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

UpDwnperiod::UpDwnperiod(float Max, float Min, float Epsilon)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u,
                   NewUpDwnPeriodMeter, this->getId());

  /* 2. Prepare Param_1 : Max bound */
  FuncParam.ParamReal = Max;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 : Min bound */
  FuncParam.ParamReal = Min;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 : Epsilon */
  FuncParam.ParamReal = Epsilon;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

fft::fft(uint16_t Nbsamples)
{

  PP_FuncParam FuncParam;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  this->dataLines = Nbsamples;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewForwardFFT, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = Nbsamples;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

fft_HannWindow::fft_HannWindow(uint16_t Nbsamples)
{

  PP_FuncParam FuncParam;

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE ;
                        

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  this->dataLines = Nbsamples;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewForwardFFT_HannWindow, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = Nbsamples;
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}


fftMagResolver::fftMagResolver(fft fftInstance)
{
  this->setContextSlot(fftInstance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  /* The board publishes (N/2)+1 magnitude bins (DC + Nyquist + N/2-1
   * interior). Using N/2 here under-counted by 1 and left the host one
   * float short when streaming via VectorProbe. */
  this->dataLines = (fftInstance.dataLines >> 1u) + 1u;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewFftResolver, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = fftInstance.getId();
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

fftMagResolver::fftMagResolver(fft_HannWindow fft_hann_Instance)
{
  this->setContextSlot(fft_hann_Instance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  /* See fftMagResolver(fft) comment: half-spectrum is (N/2)+1 bins. */
  this->dataLines = (fft_hann_Instance.dataLines >> 1u) + 1u;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewFftResolver, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = fft_hann_Instance.getId();
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}
fft_phaseResolver::fft_phaseResolver(fft fftInstance)
{
  this->setContextSlot(fftInstance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  /* The phase resolver shares the magnitude resolver's buffer on the
   * board, so it also publishes (N/2)+1 bins. */
  this->dataLines = (fftInstance.dataLines >> 1u) + 1u;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewPhaseResolver , this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = fftInstance.getId();
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

fft_phaseResolver::fft_phaseResolver(fft_HannWindow fft_hann_Instance)
{
  this->setContextSlot(fft_hann_Instance.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  /* Missing dataLines/dataRaw set here meant VectorProbe on a
   * Hann-windowed phase resolver streamed 0 bytes per frame. */
  this->dataLines = (fft_hann_Instance.dataLines >> 1u) + 1u;
  this->dataRaw = 1u;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewPhaseResolver , this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint16 = fft_hann_Instance.getId();
  PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

// DWT Implementation
dwt::dwt(uint16_t signal_length, PP_WaveletType wavelet_type, uint8_t levels, float sampling_rate)
{
    PP_FuncParam FuncParam;
    
    // Parameter validation
    if (signal_length == 0 || signal_length > 8192) {
        signal_length = 1024;
    }
    if (levels == 0 || levels > 10) {
        levels = 4;
    }
    if (sampling_rate <= 0.0f) {
        sampling_rate = 1000.0f;
    }
    /* HAAR = 0 is a legitimate wavelet type: reject only 0xFF (NoWaveletType)
     * and values outside the COIF4 = 8 ceiling. The pre-fix `wavelet_type <= 0`
     * check silently substituted DB4 for every HAAR request. */
    if ((uint16_t)wavelet_type > (uint16_t)COIF4 && wavelet_type != NoWaveletType) {
        wavelet_type = DB4;
    } else if (wavelet_type == NoWaveletType) {
        wavelet_type = DB4;
    }
    
    // Store parameters
    this->nbSamples = signal_length;
    this->waveletType = wavelet_type;
    this->decompositionLevels = levels;
    this->samplingRate = sampling_rate;
    
    // Calculate SPI data size
    uint16_t SerialDataSize = PP_FIXED_SIZE + 
                             (4u * PP_PARAM_INFO_SIZE) +
                             PP_UINT16_SIZE +
                             PP_UINT16_SIZE +
                             PP_UINT16_SIZE +
                             PP_REAL_SIZE;
    
    this->setId(currentSysId++);
    /* A DWT block publishes its time-domain accumulator, signal_length
     * floats, to whatever probe is attached to it. */
    this->dataLines = signal_length;
    this->dataRaw   = 1u;
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewDWT, this->getId());
    
    FuncParam.ParamUint16 = signal_length;
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
    
    FuncParam.ParamUint16 = (uint16_t)wavelet_type;
    PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
    
    FuncParam.ParamUint16 = (uint16_t)levels;
    PrepareParam(&Command, 2u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
    
    FuncParam.ParamReal = sampling_rate;
    PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);
    
    HandleCmd(&Command, SerialDataSize);
}

interpolation::interpolation(uint32_t M_u32)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewInterpolation, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint32 = M_u32;
  PrepareParam(&Command, 0u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

dwt::~dwt() {}

uint16_t dwt::getNbSamples() const { return this->nbSamples; }
uint8_t dwt::getDecompositionLevels() const { return this->decompositionLevels; }
PP_WaveletType dwt::getWaveletType() const { return this->waveletType; }
float dwt::getSamplingRate() const { return this->samplingRate; }

void dwt::operator>(tf tfDst)
{
    if (EnsureSameContext(this->getContextSlot(), tfDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, tfDst.getId(), 0xFF, LinkSys2Sys);
}

void dwt::operator>(probe &probeDst)
{
    if (EnsureSameContext(this->getContextSlot(), probeDst.getContextSlot()) == false)
    {
        return;
    }

    probeDst.addToQueue();
    Linkblock2block(this->getId(), 0xFF, probeDst.getId(), 0xFF, LinkSys2Probe);
}

void dwt::operator>(node nodeDst)
{
    if (EnsureSameContext(this->getContextSlot(), nodeDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, nodeDst.getId(), nodeDst.getActiveInIdx(), LinkSys2Node);
}

void dwt::operator>(macro macroDst)
{
    if (EnsureSameContext(this->getContextSlot(), macroDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, macroDst.getId(), macroDst.getActiveInIdx(), LinkSys2Macro);
}

// IDWT Implementation
idwt::idwt(dwt &dwtInstance)
{
    this->setContextSlot(dwtInstance.getContextSlot());
    if (IsValidContextSlot(this->getContextSlot()))
    {
        ActivateContext(this->getContextSlot());
    }

    PP_FuncParam FuncParam;
    
    uint16_t SerialDataSize = PP_FIXED_SIZE + 
                             PP_PARAM_INFO_SIZE + 
                             PP_UINT16_SIZE;
    
    this->associatedDWT = &dwtInstance;
    this->setId(currentSysId++);
    /* An IDWT block exposes the reconstructed time-domain signal, the
     * same size as the parent DWT's accumulator. */
    this->dataLines = dwtInstance.dataLines;
    this->dataRaw   = 1u;
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewIDWT, this->getId());
    
    FuncParam.ParamUint16 = dwtInstance.getId();
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);
    
    HandleCmd(&Command, SerialDataSize);
}

dwt* idwt::getAssociatedDWT() const { return this->associatedDWT; }

void idwt::operator>(tf tfDst)
{
    if (EnsureSameContext(this->getContextSlot(), tfDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, tfDst.getId(), 0xFF, LinkSys2Sys);
}

void idwt::operator>(probe &probeDst)
{
    if (EnsureSameContext(this->getContextSlot(), probeDst.getContextSlot()) == false)
    {
        return;
    }

    probeDst.addToQueue();
    Linkblock2block(this->getId(), 0xFF, probeDst.getId(), 0xFF, LinkSys2Probe);
}

void idwt::operator>(node nodeDst)
{
    if (EnsureSameContext(this->getContextSlot(), nodeDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, nodeDst.getId(), nodeDst.getActiveInIdx(), LinkSys2Node);
}

void idwt::operator>(macro macroDst)
{
    if (EnsureSameContext(this->getContextSlot(), macroDst.getContextSlot()) == false)
    {
        return;
    }

    Linkblock2block(this->getId(), 0xFF, macroDst.getId(), macroDst.getActiveInIdx(), LinkSys2Macro);
}

// ======================== dwt_denoise ========================

dwt_denoise::dwt_denoise(dwt &dwtInstance, PP_ThresholdType thresh_type, float thresh_scale)
{
    this->setContextSlot(dwtInstance.getContextSlot());
    if (IsValidContextSlot(this->getContextSlot()))
        ActivateContext(this->getContextSlot());

    PP_FuncParam FuncParam;
    /* Slot 2 (thresh_scale, TYPE_Real) is ALWAYS emitted so the wire frame
     * matches the Python reference dwt_denoise(): 3 params, not 2. */
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                             (2u * PP_PARAM_INFO_SIZE) +
                             PP_UINT16_SIZE +
                             PP_UINT16_SIZE +
                             (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

    this->associatedDWT = &dwtInstance;
    this->threshType = thresh_type;
    this->threshScale = thresh_scale;
    this->setId(currentSysId++);
    /* A DWT denoise block publishes the parent DWT's accumulator after
     * thresholding (same size as the DWT). */
    this->dataLines = dwtInstance.dataLines;
    this->dataRaw   = 1u;
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewDwtDenoise, this->getId());

    FuncParam.ParamUint16 = dwtInstance.getId();
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    FuncParam.ParamUint16 = (uint16_t)thresh_type;
    PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    /* thresh_scale multiplies the firmware's auto-estimated MAD sigma before
     * thresholding (1.0 = firmware default). Always sent as slot 2. */
    FuncParam.ParamReal = thresh_scale;
    PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

dwt* dwt_denoise::getAssociatedDWT() const { return this->associatedDWT; }
PP_ThresholdType dwt_denoise::getThresholdType() const { return this->threshType; }
float dwt_denoise::getThresholdScale() const { return this->threshScale; }

/* Runtime live-update: re-send this denoise block's threshold scale to the
 * board without rebuilding the design. Emits a Manageblock/SetDwtDenoiseScale
 * frame whose header BlockId targets THIS block; the firmware validates the
 * target's CoreFuncId, so a stale/foreign id is safely rejected. Mirrors the
 * ctor's slot-2 TYPE_Real payload. */
void dwt_denoise::setScaleLive(float thresh_scale)
{
  if (IsValidContextSlot(this->getContextSlot()))
    ActivateContext(this->getContextSlot());

  /* Keep the cached member in sync so getThresholdScale() reflects the live
   * value (a redeploy re-emits the same scale). */
  this->threshScale = thresh_scale;

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, SetDwtDenoiseScale, this->getId());

  /* 2. Prepare Param_1 : thresh_scale (TYPE_Real) */
  FuncParam.ParamReal = thresh_scale;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

void dwt_denoise::operator>(tf tfDst)  { if (!EnsureSameContext(this->getContextSlot(), tfDst.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, tfDst.getId(), 0xFF, LinkSys2Sys); }
void dwt_denoise::operator>(probe &p)  { if (!EnsureSameContext(this->getContextSlot(), p.getContextSlot())) return; p.addToQueue(); Linkblock2block(this->getId(), 0xFF, p.getId(), 0xFF, LinkSys2Probe); }
void dwt_denoise::operator>(node n)    { if (!EnsureSameContext(this->getContextSlot(), n.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, n.getId(), n.getActiveInIdx(), LinkSys2Node); }
void dwt_denoise::operator>(macro m)   { if (!EnsureSameContext(this->getContextSlot(), m.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, m.getId(), m.getActiveInIdx(), LinkSys2Macro); }

// ======================== dwt_subband_gain ========================

dwt_subband_gain::dwt_subband_gain(dwt &dwtInstance, const float* gains)
{
    this->setContextSlot(dwtInstance.getContextSlot());
    if (IsValidContextSlot(this->getContextSlot()))
        ActivateContext(this->getContextSlot());

    PP_FuncParam FuncParam;

    this->associatedDWT = &dwtInstance;
    this->setId(currentSysId++);
    /* A sub-band gain block publishes the gain-modified DWT samples
     * (same size as the parent DWT accumulator). */
    this->dataLines = dwtInstance.dataLines;
    this->dataRaw   = 1u;

    if (gains == nullptr)
    {
        /* No gains supplied: 1 param (instance id only). The board fills in
         * unity gains, matching the Python reference (gains=None omits slot1). */
        uint16_t SerialDataSize = PP_FIXED_SIZE +
                                 PP_PARAM_INFO_SIZE +
                                 PP_UINT16_SIZE;
        PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewDwtSubbandGain, this->getId());

        FuncParam.ParamUint16 = dwtInstance.getId();
        PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

        HandleCmd(&Command, SerialDataSize);
    }
    else
    {
        /* One LINEAR gain per subband, in firmware subband order,
         * numBands = decomposition_levels + 1 (one approximation + N details).
         * Slot 1 is a TYPE_RealArray of numBands floats (mirrors CustFir). */
        uint16_t numBands  = (uint16_t)(dwtInstance.getDecompositionLevels() + 1u);
        uint16_t arr_bytes = (uint16_t)(numBands * PP_REAL_SIZE);
        uint16_t SerialDataSize = PP_FIXED_SIZE +
                                 (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) +
                                 (PP_PARAM_INFO_SIZE + arr_bytes);
        PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewDwtSubbandGain, this->getId());

        FuncParam.ParamUint16 = dwtInstance.getId();
        PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

        /* PrepareParam memcpy's the bytes during the synchronous HandleCmd
         * below, so the caller's `gains` buffer only needs to live until this
         * ctor returns. const_cast mirrors the SignalSource/CustFir idiom. */
        FuncParam.ParamRealArray = const_cast<float*>(gains);
        PrepareParam(&Command, 1u, arr_bytes, TYPE_RealArray, &FuncParam);

        HandleCmd(&Command, SerialDataSize);
    }
}

dwt* dwt_subband_gain::getAssociatedDWT() const { return this->associatedDWT; }

/* Runtime live-update: re-send this subband-gain block's per-band LINEAR gains
 * to the board without rebuilding the design. Emits a Manageblock/
 * SetDwtSubbandGains frame whose header BlockId targets THIS block; numBands
 * must equal the linked DWT's (levels + 1) and the array is in firmware subband
 * order ([0]=approximation, [1..J]=detail). The firmware validates the
 * target's CoreFuncId, so a stale/foreign id is safely rejected. Mirrors the
 * ctor's slot-1 TYPE_RealArray payload. */
void dwt_subband_gain::setGainsLive(const float* gains, uint16_t numBands)
{
  if ((gains == nullptr) || (numBands == 0u))
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  if (IsValidContextSlot(this->getContextSlot()))
    ActivateContext(this->getContextSlot());

  PP_FuncParam FuncParam;
  uint16_t arr_bytes = (uint16_t)(numBands * PP_REAL_SIZE);
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + arr_bytes;

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, SerialDataSize, Manageblock, 1u, SetDwtSubbandGains, this->getId());

  /* 2. Prepare Param_1 : LINEAR gains (TYPE_RealArray, numBands floats).
   * PrepareParam memcpy's the bytes during the synchronous HandleCmd below,
   * so the caller's `gains` buffer only needs to live until this returns.
   * const_cast mirrors the ctor / CustFir idiom. */
  FuncParam.ParamRealArray = const_cast<float*>(gains);
  PrepareParam(&Command, 0u, arr_bytes, TYPE_RealArray, &FuncParam);

  /* 3. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

void dwt_subband_gain::operator>(tf tfDst) { if (!EnsureSameContext(this->getContextSlot(), tfDst.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, tfDst.getId(), 0xFF, LinkSys2Sys); }
void dwt_subband_gain::operator>(probe &p) { if (!EnsureSameContext(this->getContextSlot(), p.getContextSlot())) return; p.addToQueue(); Linkblock2block(this->getId(), 0xFF, p.getId(), 0xFF, LinkSys2Probe); }
void dwt_subband_gain::operator>(node n)   { if (!EnsureSameContext(this->getContextSlot(), n.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, n.getId(), n.getActiveInIdx(), LinkSys2Node); }
void dwt_subband_gain::operator>(macro m)  { if (!EnsureSameContext(this->getContextSlot(), m.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, m.getId(), m.getActiveInIdx(), LinkSys2Macro); }

// ======================== dwt_subband_energy ========================

dwt_subband_energy::dwt_subband_energy(dwt &dwtInstance)
{
    this->setContextSlot(dwtInstance.getContextSlot());
    if (IsValidContextSlot(this->getContextSlot()))
        ActivateContext(this->getContextSlot());

    PP_FuncParam FuncParam;
    uint16_t SerialDataSize = PP_FIXED_SIZE +
                             PP_PARAM_INFO_SIZE +
                             PP_UINT16_SIZE;

    this->associatedDWT = &dwtInstance;
    this->setId(currentSysId++);
    /* A sub-band energy block publishes one energy value per sub-band.
     * numBands = decomposition_levels + 1 (one approximation + N details). */
    this->dataLines = (uint16_t)(dwtInstance.getDecompositionLevels() + 1u);
    this->dataRaw   = 1u;
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewDwtSubbandEnergy, this->getId());

    FuncParam.ParamUint16 = dwtInstance.getId();
    PrepareParam(&Command, 0u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

    HandleCmd(&Command, SerialDataSize);
}

dwt* dwt_subband_energy::getAssociatedDWT() const { return this->associatedDWT; }

void dwt_subband_energy::operator>(tf tfDst) { if (!EnsureSameContext(this->getContextSlot(), tfDst.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, tfDst.getId(), 0xFF, LinkSys2Sys); }
void dwt_subband_energy::operator>(probe &p) { if (!EnsureSameContext(this->getContextSlot(), p.getContextSlot())) return; p.addToQueue(); Linkblock2block(this->getId(), 0xFF, p.getId(), 0xFF, LinkSys2Probe); }
void dwt_subband_energy::operator>(node n)   { if (!EnsureSameContext(this->getContextSlot(), n.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, n.getId(), n.getActiveInIdx(), LinkSys2Node); }
void dwt_subband_energy::operator>(macro m)  { if (!EnsureSameContext(this->getContextSlot(), m.getContextSlot())) return; Linkblock2block(this->getId(), 0xFF, m.getId(), m.getActiveInIdx(), LinkSys2Macro); }

/* ============================ Audio processing ============================ */

compressor::compressor(float Attack, float Release, float Threshold_dB, float Ratio)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewCompressor, this->getId());

  FuncParam.ParamReal = Attack;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Release;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Threshold_dB;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Ratio;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

limiter::limiter(float Attack_s, float Release_s, float Ceiling_dB)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewLimiter, this->getId());

  FuncParam.ParamReal = Attack_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Release_s;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Ceiling_dB;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

noiseGate::noiseGate(float Attack_s, float Release_s, float Threshold_dB, float Range_dB)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewNoiseGate, this->getId());

  FuncParam.ParamReal = Attack_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Release_s;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Threshold_dB;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Range_dB;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

envFollower::envFollower(float Attack_s, float Release_s)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewEnvFollower, this->getId());

  FuncParam.ParamReal = Attack_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Release_s;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

adsr::adsr(float Attack_s, float Decay_s, float Sustain, float Release_s)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewADSR, this->getId());

  FuncParam.ParamReal = Attack_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Decay_s;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Sustain;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Release_s;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

fracDelay::fracDelay(uint32_t MaxDelaySamples)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT32_SIZE;

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewFracDelay, this->getId());

  FuncParam.ParamUint32 = MaxDelaySamples;
  PrepareParam(&Command, 0u, PP_UINT32_SIZE, TYPE_Uint32, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

chorus::chorus(float Rate_Hz, float Depth_ms, float Mix)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewChorus, this->getId());

  FuncParam.ParamReal = Rate_Hz;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Depth_ms;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Mix;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

flanger::flanger(float Rate_Hz, float Depth_ms, float Feedback, float Mix)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewFlanger, this->getId());

  FuncParam.ParamReal = Rate_Hz;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Depth_ms;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Feedback;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Mix;
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

phaser::phaser(float Rate_Hz, float Depth, float Feedback, uint8_t NumStages, float Mix)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            4u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 5u, NewPhaser, this->getId());

  FuncParam.ParamReal = Rate_Hz;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Depth;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Feedback;
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamUint8 = NumStages;
  PrepareParam(&Command, 3u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  FuncParam.ParamReal = Mix;
  PrepareParam(&Command, 4u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

reverb::reverb(float DecayTime_s, float Mix)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewReverb, this->getId());

  FuncParam.ParamReal = DecayTime_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Mix;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

stereoPan::stereoPan()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewStereoPan, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

distortion::distortion(float Drive, float Mix, uint8_t Type)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewDistortion, this->getId());

  FuncParam.ParamReal = Drive;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = Mix;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamUint8 = Type;
  PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

bitcrusher::bitcrusher(float BitDepth, uint16_t SRReduction)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT16_SIZE;

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewBitcrusher, this->getId());

  FuncParam.ParamReal = BitDepth;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamUint16 = SRReduction;
  PrepareParam(&Command, 1u, PP_UINT16_SIZE, TYPE_Uint16, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

ringMod::ringMod()
{
  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Createblock, 0, NewRingMod, this->getId());
  HandleCmd(&Command, PP_FIXED_SIZE);
}

pitchDetect::pitchDetect(float MinFreq, float MaxFreq)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewPitchDetect, this->getId());

  FuncParam.ParamReal = MinFreq;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = MaxFreq;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

vuMeter::vuMeter(float RiseTime_s, float FallTime_s)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewVUMeter, this->getId());

  FuncParam.ParamReal = RiseTime_s;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  FuncParam.ParamReal = FallTime_s;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

stereoMixer::stereoMixer(uint8_t NumChannels)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  this->setId(currentNodeId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewStereoMixer, this->getId());

  FuncParam.ParamUint8 = NumChannels;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  HandleCmd(&Command, SerialDataSize);
}

cheby1Bq::cheby1Bq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby1BqSubFuncId(ftype);

  if ((NewBiquadCheby1Band == SubFuncId) || (NewBiquadCheby1Stop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 3u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby1Bq::cheby1Bq(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby1BqSubFuncId(ftype);

  if ((NewBiquadCheby1Low == SubFuncId) || (NewBiquadCheby1High == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 2u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby1::cheby1(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby1SubFuncId(ftype);

  if ((NewChebyshev1Low == SubFuncId) || (NewChebyshev1High == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 2u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby1::cheby1(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby1SubFuncId(ftype);

  if ((NewChebyshev1Band == SubFuncId) || (NewChebyshev1Stop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    /* The board reads 4 params for a Chebyshev-1 bandpass or bandstop
     * (fc1, fc2, n, chebyCfg). The old size budget (3 slots) sized the body for 3
     * params and the header advertised NbrOfParams=3, so the 4th
     * PrepareParam (chebyCfg) was either truncated on the wire or
     * skipped entirely by the serializer that iterates NbrOfParams. */
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 3u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby2Bq::cheby2Bq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby2BqSubFuncId(ftype);

  if ((NewBiquadCheby2Band == SubFuncId) || (NewBiquadCheby2Stop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 3u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby2Bq::cheby2Bq(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby2BqSubFuncId(ftype);

  if ((NewBiquadCheby2Low == SubFuncId) || (NewBiquadCheby2High == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 2u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby2::cheby2(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby2SubFuncId(ftype);

  if ((NewChebyshev2Low == SubFuncId) || (NewChebyshev2High == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 2u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

cheby2::cheby2(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg)
{
  PP_SubFuncId SubFuncId = getCheby2SubFuncId(ftype);

  if ((NewChebyshev2Band == SubFuncId) || (NewChebyshev2Stop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    /* See cheby1::cheby1(n, fc1, fc2, ...): firmware reads 4 params,
     * the 3-slot budget here dropped chebyCfg from the wire. */
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_CHEBYX_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamChebyx(chebyCfg);
    PrepareParam(&Command, 3u, PP_CHEBYX_CFG_SIZE, PP_CHEBYX_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

ellipBq::ellipBq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_EllipCfg ellipCfg)
{
  PP_SubFuncId SubFuncId = getEllipBqSubFuncId(ftype);

  if ((NewBiquadEllipBand == SubFuncId) || (NewBiquadEllipStop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_ELLIP_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamEllip(ellipCfg);
    PrepareParam(&Command, 3u, PP_ELLIP_CFG_SIZE, PP_ELLIP_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

ellipBq::ellipBq(uint8_t n, float fc, PP_FilterType ftype, PP_EllipCfg ellipCfg)
{
  PP_SubFuncId SubFuncId = getEllipBqSubFuncId(ftype);

  if ((NewBiquadEllipLow == SubFuncId) || (NewBiquadEllipHigh == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_ELLIP_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentMacroId++);
    this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamEllip(ellipCfg);
    PrepareParam(&Command, 2u, PP_ELLIP_CFG_SIZE, PP_ELLIP_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

sineAm::sineAm(float sineFreq)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  this->out(0);  // Initialize activeIoIdx = 0 for single I/O behavior
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewSineAm, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = sineFreq;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

ellip::ellip(uint8_t n, float fc, PP_FilterType ftype, PP_EllipCfg ellipCfg)
{
  PP_SubFuncId SubFuncId = getEllipSubFuncId(ftype);

  if ((NewEllipLow == SubFuncId) || (NewEllipHigh == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_ELLIP_CFG_SIZE;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamEllip(ellipCfg);
    PrepareParam(&Command, 2u, PP_ELLIP_CFG_SIZE, PP_ELLIP_CFG_TYPE, &FuncParam);

    /* 5. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

ellip::ellip(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_EllipCfg ellipCfg)
{
  PP_SubFuncId SubFuncId = getEllipSubFuncId(ftype);

  if ((NewEllipBand == SubFuncId) || (NewEllipStop == SubFuncId))
  {
    PP_FuncParam FuncParam;
    uint16_t SerialDataSize;
    SerialDataSize = PP_FIXED_SIZE +
                     2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                     PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                     PP_PARAM_INFO_SIZE + PP_ELLIP_CFG_SIZE;
    ;

    /* 1. Prepare Configuration : Header + Function Info */
    this->setId(currentSysId++);
    PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, SubFuncId, this->getId());

    /* 2. Prepare Param_1 */
    FuncParam.ParamReal = fc1;
    PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 3. Prepare Param_2 */
    FuncParam.ParamReal = fc2;
    PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

    /* 4. Prepare Param_3 */
    FuncParam.ParamUint8 = n;
    PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

    /* 5. Prepare Param_4 */
    FuncParam.ParamEllip(ellipCfg);
    PrepareParam(&Command, 3u, PP_ELLIP_CFG_SIZE, PP_ELLIP_CFG_TYPE, &FuncParam);

    /* 6. Send Configuration Request */
    HandleCmd(&Command, SerialDataSize);
  }
}

allpass::allpass(float Val1, float Val2)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  /* Aligned with papaya/blocks.py allpass, which uses NewAllPass. The board
   * accepts both the old and the new sub-function id as wire-compatible
   * aliases for the same all-pass block, so a design built with either
   * host library behaves identically. */
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewAllPass, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Val1;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = Val2;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

notch::notch(float centernotch, float qualcoef)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewNotch, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = centernotch;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = qualcoef;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

peak::peak(float centernotch, float qualcoef)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentSysId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewPeak, this->getId());

  /* 2. Prepare Param_1 : center frequency */
  FuncParam.ParamReal = centernotch;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 : quality factor */
  FuncParam.ParamReal = qualcoef;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

rls::rls(uint8_t modelOrd, float gain, macro system)
{
  this->setContextSlot(system.getContextSlot());
  if (IsValidContextSlot(this->getContextSlot()))
  {
    ActivateContext(this->getContextSlot());
  }

  PP_FuncParam FuncParam;
  uint16_t SerialDataSize;

  SerialDataSize = PP_FIXED_SIZE +
                   PP_PARAM_INFO_SIZE + PP_UINT8_SIZE +
                   PP_PARAM_INFO_SIZE + PP_REAL_SIZE +
                   PP_PARAM_INFO_SIZE + PP_blockID_SIZE;

  /* 1. Prepare Configuration : Header + Function Info
   *
   * NewRLSMacro, not NewRLS: this three-parameter layout is not what
   * the board reads for NewRLS (that one takes num[], denom[],
   * InitVariance and modelOrder), so sending it there made the board
   * read a uint8 as if it were a pointer to floats. The board does not
   * implement NewRLSMacro yet and refuses it cleanly, which is the
   * point. Use the plain RLS block, whose layout matches. */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewRLSMacro, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamUint8 = modelOrd;
  PrepareParam(&Command, 0u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = gain;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamblockId(system.getId());
  PrepareParam(&Command, 2u, PP_blockID_SIZE, PP_block_ID_TYPE, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

/* Probe Class ########################################################################################################### */
probe::probe()
{
  BindObjectToActiveContext(this->contextSlot);
};

probe::probe(const char *label)
{
  BindObjectToActiveContext(this->contextSlot);
  PP_FuncParam FuncParam;
  uint16_t labelLen;
  uint16_t SerialDataSize;

  if (TryGetCStringPayloadSize(label, labelLen) == false)
  {
    return;
  }

  SerialDataSize = PP_FIXED_SIZE +
                   PP_PARAM_INFO_SIZE + labelLen;

  /* 1. Prepare Configuration : Header + Function Info */
  this->label = label;
  this->id = currentProbeId++;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 1u, NewProbe, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamString = label;
  PrepareParam(&Command, 0u, labelLen, TYPE_String, &FuncParam);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

uint16_t probe::getId()
{
  return this->id;
}

void probe::setId(uint16_t id)
{
  this->id = id;
}

uint8_t probe::getContextSlot() const
{
  return this->contextSlot;
}

void probe::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

void probe::addToQueue()
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  /* If the preceding Linkblock2block (or any prior command) failed and
   * latched a non-OK design status, do NOT advance the host probe
   * counter. Otherwise the host's currentProbeIdx drifts past the
   * firmware's NbrOfMonitoredProbes and every subsequent getProbes()
   * reads stale or misaligned bytes. */
  if (currentDesignStatus != PP_DesignStatus::DesignOk)
  {
    return;
  }

  /* Idempotent: a probe wired to multiple sources (`tf1 > p; tf2 > p;`)
   * occupies a single firmware slot, so the host counter must only
   * advance on the first link. The 0xFFu sentinel set by the class
   * default-init flags "not yet queued". */
  if (this->idx != 0xFFu)
  {
    return;
  }

  if (currentProbeIdx >= PP_MAX_PROBES_NUMBER)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  this->idx = currentProbeIdx++;
}

float probe::getVal()
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  float retval;
  memcpy((void *)&retval, (const void *)&ProbesBuffer[this->idx * PP_REAL_SIZE], PP_REAL_SIZE);
  return retval;
}

float probe::getVal(uint16_t id)
{
  /* EEPROM-stored apps: the host never built the design locally, so
   * the probe object that owns this slot does not exist on this side.
   * Map the Studio-assigned wire ID back to the buffer slot via
   * ``id - PP_PROBE_ID_BASE`` and auto-grow ``currentProbeIdx`` so the
   * next ``readProbes()`` request matches the firmware's response
   * size. */
  uint16_t slot = (uint16_t)(id - (uint16_t)PP_PROBE_ID_BASE);
  if (slot >= (uint16_t)PP_MAX_PROBES_NUMBER)
  {
    return 0.0f;
  }

  if (probe::currentProbeIdx <= (uint8_t)slot)
  {
    probe::currentProbeIdx = (uint8_t)(slot + 1u);
  }

  float retval;
  memcpy((void *)&retval, (const void *)&ProbesBuffer[slot * PP_REAL_SIZE], PP_REAL_SIZE);
  return retval;
}

int32_t probe::getIntVal()
{
  return (int32_t)this->getVal();
}

const char *probe::getLabel()
{
  return this->label;
}

void probe::show(void)
{
  this->value = this->getVal();
  Serial.print(">");
  Serial.print(this->getLabel());
  Serial.print(":");
  Serial.println(this->value);
}

/* Input Class ########################################################################################################### */
input::input()
{
  BindObjectToActiveContext(this->contextSlot);
};

input::input(const char *label, float val)
{
  BindObjectToActiveContext(this->contextSlot);
  PP_FuncParam FuncParam;
  uint16_t labelLen;

  if (TryGetCStringPayloadSize(label, labelLen) == false)
  {
    return;
  }

  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            PP_PARAM_INFO_SIZE + labelLen +
                            PP_PARAM_INFO_SIZE + PP_REAL_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->id = currentInputId++;
  this->val = val;
  this->label = label;
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewInput, this->id);

  /* 2. Prepare Param_1 */
  FuncParam.ParamString = this->label;
  PrepareParam(&Command, 0u, labelLen, TYPE_String, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = val;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

uint16_t input::getId()
{
  return this->id;
}

void input::setId(uint16_t id)
{
  this->id = id;
}

uint8_t input::getContextSlot() const
{
  return this->contextSlot;
}

void input::setContextSlot(uint8_t slot)
{
  this->contextSlot = slot;
}

void input::enableRemote(void)
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  if (currentInputIdx >= PP_MAX_INPUTS_NUMBER)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  this->idx = currentInputIdx++;
  this->addToQueue(this->val);

  /* 1. Prepare Configuration : Header + Function Info */
  PrepareCmdHeader(&Command, PP_FIXED_SIZE, Manageblock, 0u, EnableRemoteInput, this->id);

  /* 2. Send Configuration Request */
  HandleCmd(&Command, PP_FIXED_SIZE);
}

void input::addToQueue(float InputValue)
{
  if (IsValidContextSlot(this->contextSlot))
  {
    ActivateContext(this->contextSlot);
  }

  /* Guard: if the input object's slot was never populated by a prior
   * enableRemoteInput() (so idx is still its uninitialised default) or
   * the caller wired up >PP_MAX_INPUTS_NUMBER inputs, the memcpy below
   * walks past InputsBuffer's bounds and corrupts adjacent statics. */
  if (this->idx >= PP_MAX_INPUTS_NUMBER)
  {
    SetDesignError(PP_DesignStatus::BadParam);
    return;
  }

  memcpy((void *)&InputsBuffer[this->idx * PP_REAL_SIZE], (const void *)&InputValue, PP_REAL_SIZE);
}

void input::addToQueue(float InputValue, uint16_t id)
{
  /* EEPROM-stored apps: the host never built the design locally, so
   * the input object that owns this slot does not exist on this side.
   * Map the Studio-assigned wire ID back to the buffer slot via
   * ``id - PP_INPUT_ID_BASE`` and auto-grow ``currentInputIdx`` so the
   * next ``writeInputs()`` push covers every staged slot. */
  uint16_t slot = (uint16_t)(id - (uint16_t)PP_INPUT_ID_BASE);
  if (slot >= (uint16_t)PP_MAX_INPUTS_NUMBER)
  {
    return;
  }

  if (input::currentInputIdx <= (uint8_t)slot)
  {
    input::currentInputIdx = (uint8_t)(slot + 1u);
  }

  memcpy((void *)&InputsBuffer[slot * PP_REAL_SIZE], (const void *)&InputValue, PP_REAL_SIZE);
}

void input::operator>(tf Dst)
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), 0xFF, LinkIn2Sys);
}

void input::operator>(node Dst)
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), Dst.getActiveInIdx(), LinkIn2Node);
}

void input::operator>(macro Dst)
{
  if (EnsureSameContext(this->contextSlot, Dst.getContextSlot()) == false)
  {
    return;
  }

  Linkblock2block(this->id, 0xFF, Dst.getId(), Dst.getActiveInIdx(), LinkIn2Macro);
}

const char *input::getLabel(void)
{
  return this->label;
}

paramEQLow::paramEQLow(float Fc, uint8_t FilterOrder, float Gain)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewParamEQLow, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Fc;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = FilterOrder;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamReal = Gain; /* TRUE RBJ EQ: Gain is in decibels (dB), +boost / -cut, 0 = flat */
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

ParamEQHigh::ParamEQHigh(float Fc, uint8_t FilterOrder, float Gain)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 3u, NewParamEQHigh, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Fc;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamUint8 = FilterOrder;
  PrepareParam(&Command, 1u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamReal = Gain; /* TRUE RBJ EQ: Gain is in decibels (dB), +boost / -cut, 0 = flat */
  PrepareParam(&Command, 2u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 5. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

ParamEQBand::ParamEQBand(float Fc1, float Fc2, uint8_t FilterOrder, float Gain)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            3u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) +
                            PP_PARAM_INFO_SIZE + PP_UINT8_SIZE;

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 4u, NewParamEQBand, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Fc1;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = Fc2;
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Prepare Param_3 */
  FuncParam.ParamUint8 = FilterOrder;
  PrepareParam(&Command, 2u, PP_UINT8_SIZE, TYPE_Uint8, &FuncParam);

  /* 5. Prepare Param_4 */
  FuncParam.ParamReal = Gain; /* TRUE RBJ EQ: Gain is in decibels (dB), +boost / -cut, 0 = flat */
  PrepareParam(&Command, 3u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 6. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}

ParamEQPeak::ParamEQPeak(float Fc, float Gain)
{
  PP_FuncParam FuncParam;
  uint16_t SerialDataSize = PP_FIXED_SIZE +
                            2u * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE);

  /* 1. Prepare Configuration : Header + Function Info */
  this->setId(currentMacroId++);
  PrepareCmdHeader(&Command, SerialDataSize, Createblock, 2u, NewParamEQPeak, this->getId());

  /* 2. Prepare Param_1 */
  FuncParam.ParamReal = Fc;
  PrepareParam(&Command, 0u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 3. Prepare Param_2 */
  FuncParam.ParamReal = Gain; /* TRUE RBJ EQ: Gain is in decibels (dB), +boost / -cut, 0 = flat */
  PrepareParam(&Command, 1u, PP_REAL_SIZE, TYPE_Real, &FuncParam);

  /* 4. Send Configuration Request */
  HandleCmd(&Command, SerialDataSize);
}
