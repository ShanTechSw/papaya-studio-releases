/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe pole_angle;
probe pole_rate_2;
probe pole_energy;
probe upright_distanc;
probe control_mode;
probe accel_cmd;
probe drive_duty;
probe cart_velocity;
probe cart_position;

input start_angle;
input plant_in_loop;
input energy_target;
input swing_gain;
input swing_acc;
input cart_ref;
input mode_swing;
input mode_balance;
input leave_at;
input catch_at;
input acc_max;
input duty_limit;

/* Global Struct Declarations */
// Configuration for cart_drive
PP_motorBlockCfg cart_drive_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 0.01075424f, 0.01075424f, 0.005f, -0.95f, 0.95f},
  2,
  {MotorVelocity, MotorPosition, NoMotorOutput}
};


/* Global Array Declarations */
float balance_law_K[] = {-21.8738f, -16.6864f, -72.1338f, -14.1861f, 6.6667f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  start_angle = input("start_angle", 3.12f);
  plant_in_loop = input("plant_in_loop", 1.0f);
  energy_target = input("energy_target", 1.0f);
  swing_gain = input("swing_gain", 8.0f);
  swing_acc = input("swing_acc", 3.5f);
  cart_ref = input("cart_ref", 0.0f);
  mode_swing = input("mode_swing", -1.0f);
  mode_balance = input("mode_balance", 1.0f);
  leave_at = input("leave_at", 0.6f);
  catch_at = input("catch_at", 0.3f);
  acc_max = input("acc_max", 12.0f);
  duty_limit = input("duty_limit", 0.95f);
  analogIn pole_angle_pot = analogIn(AIN1, 1.047198, 0.0);
  expander fan_3 = expander(3);
  expander fan_2_3 = expander(2);
  expander fan_2_4 = expander(2);
  expander fan_2_5 = expander(2);
  gain swing_acc_lower = gain(-1.0);
  gain acc_lower = gain(-1.0);
  gain duty_lower = gain(-1.0);
  node model_pole_angle = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_3_2 = expander(3);
  switchBlock angle_source = switchBlock();
  expander fan_3_3 = expander(3);
  cosineFunc cos_pole = cosineFunc();
  expander fan_3_4 = expander(3);
  sineFunc sin_pole = sineFunc();
  atan2Block wrap_to___pi = atan2Block();
  expander fan_2_2 = expander(2);
  absVal abs_angle = absVal();
  derivative pole_rate = derivative(0.012);
  expander fan_4 = expander(4);
  node rate_times_cos = node("[1.0 1.0]", "[1.0]", Mul);
  sign pump_direction = sign();
  sqrMath rate_squared = sqrMath();
  gain kinetic_term = gain(0.020387);
  node energy_error = node("[1.0 1.0 -1.0]", "[1.0]", Sum);
  node energy_times_direction = node("[1.0 1.0 1.0]", "[1.0]", Mul);
  sat swing_clamp = sat();
  absVal abs_rate = absVal();
  node upright_distance = node("[1.0 0.201928]", "[1.0]", Sum);
  schmidt mode_gate = schmidt();
  switchBlock mode_select = switchBlock();
  sat acceleration_limit = sat();
  node drive_command = node("[0.033845 0.378269]", "[1.0]", Sum);
  sat duty_clamp = sat();
  expander fan_2_6 = expander(2);
  motor cart_drive = motor(&cart_drive_config);
  switchBlock cart_velocity_source = switchBlock();
  expander fan_4_2 = expander(4);
  node delivered_acceleration = node("[29.5465 -11.1765]", "[1.0]", Sum);
  expander fan_2_7 = expander(2);
  integrator model_cart_velocity = integrator();
  expander fan_2 = expander(2);
  integrator model_cart_position = integrator();
  switchBlock cart_position_source = switchBlock();
  expander fan_3_5 = expander(3);
  lqrServo balance_law = lqrServo(4, 1, 1, balance_law_K, 12.0);
  node swing_up_command = node("[1.0 -13.0 -3.0]", "[1.0]", Sum);
  cosineFunc model_cos_pole = cosineFunc();
  node model_a_times_cos = node("[1.0 1.0]", "[1.0]", Mul);
  sineFunc model_sin_pole = sineFunc();
  node model_pole_torque = node("[9.81 -1.0]", "[1.0]", Sum);
  gain model_over_l_eff = gain(2.5);
  integrator model_pole_rate = integrator();
  integrator model_angle_integral = integrator();
  pole_angle = probe("pole_angle_rad");
  pole_rate_2 = probe("pole_rate_rad_s");
  pole_energy = probe("pole_energy");
  upright_distanc = probe("upright_distanc");
  control_mode = probe("control_mode");
  accel_cmd = probe("accel_cmd_m_s2");
  drive_duty = probe("drive_duty");
  cart_velocity = probe("cart_velocity");
  cart_position = probe("cart_position_m");

  /* Connect Blocks */
  start_angle > model_pole_angle.in(1);
  plant_in_loop > fan_3;
  energy_target > energy_error.in(2);
  swing_gain > energy_times_direction.in(2);
  swing_acc > fan_2_3;
  cart_ref > balance_law.in(4);
  mode_swing > mode_gate.in(1);
  mode_balance > mode_gate.in(2);
  leave_at > mode_gate.in(3);
  catch_at > mode_gate.in(4);
  acc_max > fan_2_4;
  duty_limit > fan_2_5;
  pole_angle_pot > angle_source.in(2);
  fan_3.out(0) > angle_source.in(0);
  fan_3.out(2) > cart_velocity_source.in(0);
  fan_3.out(1) > cart_position_source.in(0);
  fan_2_3.out(0) > swing_acc_lower;
  fan_2_3.out(1) > swing_clamp.in(0);
  fan_2_4.out(0) > acc_lower;
  fan_2_4.out(1) > acceleration_limit.in(0);
  fan_2_5.out(0) > duty_lower;
  fan_2_5.out(1) > duty_clamp.in(0);
  swing_acc_lower > swing_clamp.in(1);
  acc_lower > acceleration_limit.in(1);
  duty_lower > duty_clamp.in(1);
  model_pole_angle > fan_3_2;
  fan_3_2.out(0) > angle_source.in(1);
  fan_3_2.out(2) > model_cos_pole;
  fan_3_2.out(1) > model_sin_pole;
  angle_source > fan_3_3;
  fan_3_3.out(2) > cos_pole;
  fan_3_3.out(1) > sin_pole;
  fan_3_3.out(0) > pole_rate;
  cos_pole > fan_3_4;
  fan_3_4.out(0) > wrap_to___pi.in(1);
  fan_3_4.out(2) > rate_times_cos.in(1);
  fan_3_4.out(1) > energy_error.in(1);
  sin_pole > wrap_to___pi.in(0);
  wrap_to___pi > fan_2_2;
  wrap_to___pi > pole_angle;
  fan_2_2.out(0) > abs_angle;
  fan_2_2.out(1) > balance_law.in(2);
  abs_angle > upright_distance.in(0);
  pole_rate > fan_4;
  pole_rate > pole_rate_2;
  fan_4.out(2) > rate_times_cos.in(0);
  fan_4.out(1) > rate_squared;
  fan_4.out(0) > abs_rate;
  fan_4.out(3) > balance_law.in(3);
  rate_times_cos > pump_direction;
  pump_direction > energy_times_direction.in(1);
  rate_squared > kinetic_term;
  kinetic_term > energy_error.in(0);
  energy_error > energy_times_direction.in(0);
  energy_error > pole_energy;
  energy_times_direction > swing_clamp.in(2);
  swing_clamp > swing_up_command.in(0);
  abs_rate > upright_distance.in(1);
  upright_distance > mode_gate.in(0);
  upright_distance > upright_distanc;
  mode_gate > mode_select.in(0);
  mode_gate > control_mode;
  mode_select > acceleration_limit.in(2);
  acceleration_limit > drive_command.in(0);
  acceleration_limit > accel_cmd;
  drive_command > duty_clamp.in(2);
  duty_clamp > fan_2_6;
  duty_clamp > drive_duty;
  fan_2_6.out(0) > cart_drive;
  fan_2_6.out(1) > delivered_acceleration.in(0);
  cart_drive.out(0) > cart_velocity_source.in(2);
  cart_drive.out(1) > cart_position_source.in(2);
  cart_velocity_source > fan_4_2;
  cart_velocity_source > cart_velocity;
  fan_4_2.out(2) > drive_command.in(1);
  fan_4_2.out(3) > delivered_acceleration.in(1);
  fan_4_2.out(1) > balance_law.in(1);
  fan_4_2.out(0) > swing_up_command.in(2);
  delivered_acceleration > fan_2_7;
  fan_2_7.out(0) > model_cart_velocity;
  fan_2_7.out(1) > model_a_times_cos.in(0);
  model_cart_velocity > fan_2;
  fan_2.out(0) > cart_velocity_source.in(1);
  fan_2.out(1) > model_cart_position;
  model_cart_position > cart_position_source.in(1);
  cart_position_source > fan_3_5;
  cart_position_source > cart_position;
  fan_3_5.out(1) > balance_law.in(0);
  fan_3_5.out(2) > balance_law.in(5);
  fan_3_5.out(0) > swing_up_command.in(1);
  balance_law > mode_select.in(1);
  swing_up_command > mode_select.in(2);
  model_cos_pole > model_a_times_cos.in(1);
  model_a_times_cos > model_pole_torque.in(1);
  model_sin_pole > model_pole_torque.in(0);
  model_pole_torque > model_over_l_eff;
  model_over_l_eff > model_pole_rate;
  model_pole_rate > model_angle_integral;
  model_angle_integral > model_pole_angle.in(0);

  /* Enable Remote Input Control */
  start_angle.enableRemote();
  plant_in_loop.enableRemote();
  energy_target.enableRemote();
  swing_gain.enableRemote();
  swing_acc.enableRemote();
  cart_ref.enableRemote();
  mode_swing.enableRemote();
  mode_balance.enableRemote();
  leave_at.enableRemote();
  catch_at.enableRemote();
  acc_max.enableRemote();
  duty_limit.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    pole_angle.show();
    pole_rate_2.show();
    pole_energy.show();
    upright_distanc.show();
    control_mode.show();
    accel_cmd.show();
    drive_duty.show();
    cart_velocity.show();
    cart_position.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}