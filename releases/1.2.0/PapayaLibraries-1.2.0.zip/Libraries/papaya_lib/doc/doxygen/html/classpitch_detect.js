var classpitch_detect =
[
    [ "pitchDetect", "classpitch_detect.html#aded7930bf3e1f03d43faddec429777d2", null ]
];