var struct_p_p___s_t_r___p_i_d___config =
[
    [ "desired_cl_bw", "struct_p_p___s_t_r___p_i_d___config.html#a3bdcfc57370c056581457d8fa0f410d4", null ],
    [ "lambda", "struct_p_p___s_t_r___p_i_d___config.html#ae26d30c0d186da1a335edcd579ddce83", null ],
    [ "P_init", "struct_p_p___s_t_r___p_i_d___config.html#a4f3589258544f14e9345fc7afd83c154", null ],
    [ "Tau", "struct_p_p___s_t_r___p_i_d___config.html#a39e30b58ec200226943b1483e20c472c", null ]
];