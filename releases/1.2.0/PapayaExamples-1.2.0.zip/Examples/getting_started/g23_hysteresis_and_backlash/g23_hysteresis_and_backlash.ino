/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe schmitt;
probe backlash;

input Trigger_p1;
input Trigger_p2;
input Trigger_p3;
input Trigger_p4;
input Play_p0;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(1.0f, 0.0f);
  Trigger_p1 = input("Trigger_p1", 1.0f);
  Trigger_p2 = input("Trigger_p2", -1.0f);
  Trigger_p3 = input("Trigger_p3", 0.5f);
  Trigger_p4 = input("Trigger_p4", -0.5f);
  Play_p0 = input("Play_p0", 0.2f);
  expander fan_2 = expander(2);
  schmidt Trigger = schmidt();
  backlashDeadBand Play = backlashDeadBand();
  schmitt = probe("schmitt");
  backlash = probe("backlash");

  /* Connect Blocks */
  Source > fan_2;
  Trigger_p1 > Trigger.in(1);
  Trigger_p2 > Trigger.in(2);
  Trigger_p3 > Trigger.in(3);
  Trigger_p4 > Trigger.in(4);
  Play_p0 > Play.in(0);
  fan_2.out(0) > Trigger.in(0);
  fan_2.out(1) > Play.in(1);
  Trigger > schmitt;
  Play > backlash;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    schmitt.show();
    backlash.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}