/* ============================================================================
 * papaya_auth_reference.c
 *
 * Reference implementation of the PAPAYA HMAC-SHA256 challenge-response
 * authentication used by Papaya Studio to verify that a connected USB
 * device is a genuine PAPAYA board.
 *
 * Drop this file into your STM32 firmware project (no STM32 HAL
 * dependency below: only ``mcu_get_unique_id`` is platform-specific,
 * and a worked body for it is at the bottom of this file).  Wire ``handle_authenticate``
 * into the configuration-mode command dispatcher so it runs when the
 * sub-function id ``Authenticate (0x2022)`` arrives, then reply with
 * the 32-byte HMAC as the command's response payload.
 *
 * Protocol (see PAPAYA Studio: papaya/auth.py)
 * ----------------------------------------------------------------------------
 *   Host  → Board:  Authenticate (0x2022) | body: 32-byte random nonce
 *   Board → Host:   ResponseOk            | payload: 32-byte HMAC
 *   HMAC = HMAC_SHA256(PSK, nonce || mcu_unique_id_12bytes)
 *
 * Threat model & caveats
 * ----------------------------------------------------------------------------
 *   * Defends against casual cloning: an attacker cannot mint a fake
 *     PAPAYA without first obtaining the 32-byte PSK.
 *   * The PSK lives in firmware flash; enable STM32 Read-Out Protection
 *     (RDP level 1 minimum, level 2 recommended for production) to
 *     stop a JTAG dump from leaking it.
 *   * The host must also hold the same PSK in order to check a response,
 *     so the key is recoverable from the host software too.  This is an
 *     inherent property of a symmetric challenge, not an implementation
 *     shortcut: it raises the cost of cloning, it does not make cloning
 *     cryptographically infeasible.  Treat it the way MFi and printer
 *     cartridge authentication are treated: it deters casual cloning and
 *     gives a clear signal when a device is not genuine.  Do not describe
 *     it as tamper-proof.
 *   * NOT a defence against firmware reverse-engineering by a motivated
 *     adversary with physical access and silicon-level attacks.  This
 *     is "consumer-grade" peripheral authentication, comparable to MFi
 *     or printer cartridges.
 *
 * Configuring the PSK
 * ----------------------------------------------------------------------------
 *   The key is a BUILD INPUT, never a committed constant.  Generate a
 *   header from the same secret the host side holds, defining both
 *   ``PAPAYA_AUTH_PSK_BYTES`` (the key material as a comma-separated byte
 *   list) and ``PAPAYA_AUTH_PSK_PROVISIONED``, then build this file with:
 *
 *       -DPAPAYA_AUTH_PSK_HEADER="\"papaya_auth_psk.h\"" \
 *       -DPAPAYA_AUTH_REQUIRE_PROVISIONED_PSK
 *
 *   The generated header is a secret: keep it out of source control,
 *   exactly like the key itself.  ``PAPAYA_AUTH_PSK_BYTES`` may also be
 *   defined directly on the compiler command line if your build system
 *   prefers that.
 *
 *   With nothing defined, the PUBLIC development key below is used so an
 *   unconfigured firmware and an unconfigured Papaya Studio checkout talk
 *   to each other out of the box.  It is published, so it protects
 *   nothing; ``PAPAYA_AUTH_REQUIRE_PROVISIONED_PSK`` turns using it into
 *   a compile error, which is what a production build should do.
 *
 *   Both sides stretch the agreed material through SHA-256 to a uniform
 *   32-byte key, so host and firmware only have to agree on the material.
 *
 * Integration steps
 * ----------------------------------------------------------------------------
 *   1. Add this file to your firmware project.
 *   2. Implement ``mcu_get_unique_id`` (or use the stub at the bottom of
 *      this file, after setting ``PAPAYA_UID_BASE`` to the unique-device-id
 *      address given in your MCU's reference manual).
 *   3. In your command dispatcher's case for ``Authenticate``:
 *         uint8_t hmac[32];
 *         handle_authenticate(body_nonce, hmac);
 *         send_response_ok_with_payload(hmac, 32);
 *   4. Build with one of:
 *         * ``USE_TINYCRYPT``:  link against TinyCrypt's HMAC + SHA-256
 *           (recommended; tiny ROM footprint, audited);
 *         * ``USE_MBEDTLS``:    link against mbedTLS;
 *         * default:             fall back to the stand-alone reference
 *           SHA-256 + HMAC implementation in this file (≈3 KB ROM).
 *   5. Enable STM32 RDP before shipping so the PSK cannot be JTAG-dumped:
 *         #pragma section ".option_bytes" → set RDP=0xCC (Level 2).
 * ============================================================================ */

#include <stdint.h>
#include <string.h>

/* A provisioned build supplies the key through a generated header (see
 * "Configuring the PSK" above).  The header defines PAPAYA_AUTH_PSK_BYTES
 * and PAPAYA_AUTH_PSK_PROVISIONED. */
#ifdef PAPAYA_AUTH_PSK_HEADER
#  include PAPAYA_AUTH_PSK_HEADER
#endif

#ifndef PAPAYA_AUTH_PSK_BYTES
/* ------------------------------------------------------------------------- *
 * PUBLIC DEVELOPMENT KEY: this is not a secret and is not meant to be one.
 * It is published here and in Papaya Studio's papaya/auth.py so an
 * unconfigured firmware and an unconfigured host authenticate each other
 * with zero setup.  Keep the copies byte-identical.  These bytes are used
 * RAW as the PSK; they are not hashed first.
 *
 * These are the exact bytes every board already in the field was flashed
 * with.  A previous revision replaced them with fresh material, on the
 * assumption that firmware and host ship together. They do not.  Boards
 * are flashed once and keep their key, so the change broke the handshake
 * for every existing board, surfacing only as "connection failed".
 *
 * The security boundary is the release preflight, which refuses to build
 * a release unless a real key has been provisioned, not this constant.
 * Do not rotate it without a firmware migration plan.
 * ------------------------------------------------------------------------- */
#define PAPAYA_AUTH_PSK_BYTES                                                  \
    'P','a','p','a','y','a','-','V','e','r','s','i','o','n','-',               \
    '1','.','0','-','S','h','a','r','e','d','S','e','c','r','e','t','!'
#endif

#if defined(PAPAYA_AUTH_REQUIRE_PROVISIONED_PSK) && !defined(PAPAYA_AUTH_PSK_PROVISIONED)
#  error "PAPAYA_AUTH_REQUIRE_PROVISIONED_PSK is set but no provisioned key was supplied. \
Supply a header that defines PAPAYA_AUTH_PSK_BYTES and PAPAYA_AUTH_PSK_PROVISIONED, build \
with -DPAPAYA_AUTH_PSK_HEADER=\"<path>\", or drop the requirement for a development build."
#endif

#define PAPAYA_AUTH_NONCE_LEN  32u
#define PAPAYA_AUTH_HMAC_LEN   32u
#define PAPAYA_AUTH_UID_LEN    12u   /* STM32 96-bit unique device id */

/* ------------------------------------------------------------------------- *
 * Reference SHA-256: drop-in standalone implementation (≈ 1.5 KB ROM).
 * Public-domain code derived from the FIPS 180-4 reference and the
 * "tiny-SHA2" projects.  If you are already linking a crypto library
 * just delete this block and ``#define USE_TINYCRYPT`` or
 * ``USE_MBEDTLS``; the dispatcher below picks up the right backend.
 * ------------------------------------------------------------------------- */
#if !defined(USE_TINYCRYPT) && !defined(USE_MBEDTLS)

typedef struct {
    uint32_t state[8];
    uint64_t bit_count;
    uint8_t  buf[64];
    size_t   buf_len;
} papaya_sha256_ctx;

static const uint32_t k256[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
};

#define ROTR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))

static void sha256_compress(papaya_sha256_ctx *c, const uint8_t blk[64]) {
    uint32_t w[64];
    for (int i = 0; i < 16; ++i) {
        w[i] = ((uint32_t)blk[i*4] << 24) | ((uint32_t)blk[i*4+1] << 16)
             | ((uint32_t)blk[i*4+2] << 8) | (uint32_t)blk[i*4+3];
    }
    for (int i = 16; i < 64; ++i) {
        uint32_t s0 = ROTR(w[i-15], 7) ^ ROTR(w[i-15], 18) ^ (w[i-15] >> 3);
        uint32_t s1 = ROTR(w[i-2], 17) ^ ROTR(w[i-2], 19) ^ (w[i-2] >> 10);
        w[i] = w[i-16] + s0 + w[i-7] + s1;
    }
    uint32_t a=c->state[0], b=c->state[1], cc=c->state[2], d=c->state[3];
    uint32_t e=c->state[4], f=c->state[5], g=c->state[6], h=c->state[7];
    for (int i = 0; i < 64; ++i) {
        uint32_t S1 = ROTR(e,6) ^ ROTR(e,11) ^ ROTR(e,25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = h + S1 + ch + k256[i] + w[i];
        uint32_t S0 = ROTR(a,2) ^ ROTR(a,13) ^ ROTR(a,22);
        uint32_t mj = (a & b) ^ (a & cc) ^ (b & cc);
        uint32_t t2 = S0 + mj;
        h = g; g = f; f = e; e = d + t1;
        d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->state[0]+=a; c->state[1]+=b; c->state[2]+=cc; c->state[3]+=d;
    c->state[4]+=e; c->state[5]+=f; c->state[6]+=g; c->state[7]+=h;
}

static void sha256_init(papaya_sha256_ctx *c) {
    c->state[0]=0x6a09e667; c->state[1]=0xbb67ae85; c->state[2]=0x3c6ef372; c->state[3]=0xa54ff53a;
    c->state[4]=0x510e527f; c->state[5]=0x9b05688c; c->state[6]=0x1f83d9ab; c->state[7]=0x5be0cd19;
    c->bit_count = 0; c->buf_len = 0;
}

static void sha256_update(papaya_sha256_ctx *c, const uint8_t *data, size_t len) {
    c->bit_count += (uint64_t)len * 8u;
    while (len > 0) {
        size_t take = 64 - c->buf_len;
        if (take > len) take = len;
        memcpy(c->buf + c->buf_len, data, take);
        c->buf_len += take; data += take; len -= take;
        if (c->buf_len == 64) { sha256_compress(c, c->buf); c->buf_len = 0; }
    }
}

static void sha256_final(papaya_sha256_ctx *c, uint8_t out[32]) {
    c->buf[c->buf_len++] = 0x80;
    if (c->buf_len > 56) {
        memset(c->buf + c->buf_len, 0, 64 - c->buf_len);
        sha256_compress(c, c->buf);
        c->buf_len = 0;
    }
    memset(c->buf + c->buf_len, 0, 56 - c->buf_len);
    for (int i = 0; i < 8; ++i)
        c->buf[56 + i] = (uint8_t)(c->bit_count >> (56 - i*8));
    sha256_compress(c, c->buf);
    for (int i = 0; i < 8; ++i) {
        out[i*4 + 0] = (uint8_t)(c->state[i] >> 24);
        out[i*4 + 1] = (uint8_t)(c->state[i] >> 16);
        out[i*4 + 2] = (uint8_t)(c->state[i] >> 8);
        out[i*4 + 3] = (uint8_t)(c->state[i]);
    }
}

static void hmac_sha256(const uint8_t *key, size_t key_len,
                        const uint8_t *msg, size_t msg_len,
                        uint8_t out[32]) {
    uint8_t k_block[64];
    uint8_t k_ipad[64];
    uint8_t k_opad[64];
    uint8_t inner_hash[32];
    papaya_sha256_ctx ctx;

    if (key_len > 64) {
        sha256_init(&ctx);
        sha256_update(&ctx, key, key_len);
        sha256_final(&ctx, k_block);
        memset(k_block + 32, 0, 32);
    } else {
        memcpy(k_block, key, key_len);
        memset(k_block + key_len, 0, 64 - key_len);
    }
    for (int i = 0; i < 64; ++i) {
        k_ipad[i] = k_block[i] ^ 0x36;
        k_opad[i] = k_block[i] ^ 0x5c;
    }
    sha256_init(&ctx);
    sha256_update(&ctx, k_ipad, 64);
    sha256_update(&ctx, msg, msg_len);
    sha256_final(&ctx, inner_hash);
    sha256_init(&ctx);
    sha256_update(&ctx, k_opad, 64);
    sha256_update(&ctx, inner_hash, 32);
    sha256_final(&ctx, out);
}

#elif defined(USE_TINYCRYPT)
#  include <tinycrypt/hmac.h>
#  include <tinycrypt/sha256.h>
   static void hmac_sha256(const uint8_t *key, size_t key_len,
                           const uint8_t *msg, size_t msg_len,
                           uint8_t out[32]) {
       struct tc_hmac_state_struct h;
       tc_hmac_set_key(&h, key, (unsigned)key_len);
       tc_hmac_init(&h);
       tc_hmac_update(&h, msg, (unsigned)msg_len);
       tc_hmac_final(out, 32, &h);
   }
#elif defined(USE_MBEDTLS)
#  include <mbedtls/md.h>
   static void hmac_sha256(const uint8_t *key, size_t key_len,
                           const uint8_t *msg, size_t msg_len,
                           uint8_t out[32]) {
       const mbedtls_md_info_t *info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
       mbedtls_md_hmac(info, key, key_len, msg, msg_len, out);
   }
#endif

/* ------------------------------------------------------------------------- *
 * Stretch the configured PSK material through SHA-256 once at boot so the
 * key has uniform 32-byte length.  Mirrors the host's ``_load_psk`` so
 * any agreed-upon input produces the same key on both sides.
 * ------------------------------------------------------------------------- */
static const uint8_t k_papaya_psk_raw[] = { PAPAYA_AUTH_PSK_BYTES };
static uint8_t       g_papaya_psk[32];
static int           g_papaya_psk_ready = 0;

static void papaya_psk_load(void) {
    if (g_papaya_psk_ready) return;
    papaya_sha256_ctx c;
    sha256_init(&c);
    sha256_update(&c, k_papaya_psk_raw, sizeof k_papaya_psk_raw);
    sha256_final(&c, g_papaya_psk);
    g_papaya_psk_ready = 1;
}

/* ------------------------------------------------------------------------- *
 * Read the MCU's 96-bit unique device id.
 *
 * The address of the unique-device-id register block differs from one
 * MCU family to the next.  Look yours up in your MCU's reference manual
 * and define ``PAPAYA_UID_BASE`` accordingly; the value below is only an
 * example and will read the wrong memory on a part it was not written
 * for.
 * ------------------------------------------------------------------------- */
#ifndef PAPAYA_UID_BASE
#define PAPAYA_UID_BASE  ((const uint8_t *)0x1FF1E800u)
#endif

static void mcu_get_unique_id(uint8_t out[PAPAYA_AUTH_UID_LEN]) {
    /* The 96-bit UID is exposed as twelve consecutive bytes; the host
     * reads it back in the same order via GetBoardInfo so the HMAC
     * inputs match exactly. */
    memcpy(out, PAPAYA_UID_BASE, PAPAYA_AUTH_UID_LEN);
}

/* ============================================================================
 * Public entry point: call from your Authenticate command handler.
 * ============================================================================ */
void handle_authenticate(const uint8_t nonce[PAPAYA_AUTH_NONCE_LEN],
                         uint8_t       out_hmac[PAPAYA_AUTH_HMAC_LEN]) {
    uint8_t msg[PAPAYA_AUTH_NONCE_LEN + PAPAYA_AUTH_UID_LEN];
    uint8_t uid[PAPAYA_AUTH_UID_LEN];

    papaya_psk_load();
    mcu_get_unique_id(uid);
    memcpy(msg, nonce, PAPAYA_AUTH_NONCE_LEN);
    memcpy(msg + PAPAYA_AUTH_NONCE_LEN, uid, PAPAYA_AUTH_UID_LEN);

    hmac_sha256(g_papaya_psk, sizeof g_papaya_psk,
                msg, sizeof msg,
                out_hmac);
}
