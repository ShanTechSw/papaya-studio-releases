/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ki_split_tap;
probe kd_split_tap;
probe live_pid_measur;
probe live_pi_measure;
probe live_pd_measure;

input kp;
input ki;
input kd;
input const_;
input const__2;

/* Global Array Declarations */
float LIVE_PID_plant_numerator[] = {1.0f};
float LIVE_PID_plant_denominator[] = {0.2f, 1.0f};
float LIVE_PI_plant_numerator[] = {1.0f};
float LIVE_PI_plant_denominator[] = {0.2f, 1.0f};
float LIVE_PD_plant_numerator[] = {1.0f};
float LIVE_PD_plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  kp = input("kp", 1.0f);
  ki = input("ki", 0.5f);
  kd = input("kd", 0.02f);
  signalSource Source = signalSource::square(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource Source_2 = signalSource::square(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource Source_3 = signalSource::square(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  expander kp_split = expander(3);
  expander ki_split = expander(3);
  expander kd_split = expander(3);
  node LIVE_PID_error = node("[1.0 -1.0]", "[1.0]", Sum);
  livePid Live_Pid = livePid();
  tf LIVE_PID_plant = tf(LIVE_PID_plant_numerator, 1, LIVE_PID_plant_denominator, 2);
  expander LIVE_PID_feedback = expander(2);
  node LIVE_PI_error = node("[1.0 -1.0]", "[1.0]", Sum);
  livePi Live_Pi = livePi();
  tf LIVE_PI_plant = tf(LIVE_PI_plant_numerator, 1, LIVE_PI_plant_denominator, 2);
  expander LIVE_PI_feedback = expander(2);
  node LIVE_PD_error = node("[1.0 -1.0]", "[1.0]", Sum);
  livePd Live_Pd = livePd();
  tf LIVE_PD_plant = tf(LIVE_PD_plant_numerator, 1, LIVE_PD_plant_denominator, 2);
  expander LIVE_PD_feedback = expander(2);
  ki_split_tap = probe("ki_split_o2");
  kd_split_tap = probe("kd_split_o1");
  live_pid_measur = probe("live_pid_measur");
  live_pi_measure = probe("live_pi_measure");
  live_pd_measure = probe("live_pd_measure");

  /* Connect Blocks */
  kp > kp_split;
  ki > ki_split;
  kd > kd_split;
  Source > LIVE_PID_error.in(0);
  Source_2 > LIVE_PI_error.in(0);
  Source_3 > LIVE_PD_error.in(0);
  const_ > Live_Pid.in(4);
  const__2 > Live_Pd.in(3);
  kp_split.out(0) > Live_Pid.in(1);
  kp_split.out(1) > Live_Pi.in(1);
  kp_split.out(2) > Live_Pd.in(1);
  ki_split.out(0) > Live_Pid.in(2);
  ki_split.out(1) > Live_Pi.in(2);
  ki_split.out(2) > ki_split_tap;
  kd_split.out(0) > Live_Pid.in(3);
  kd_split.out(2) > Live_Pd.in(2);
  kd_split.out(1) > kd_split_tap;
  LIVE_PID_error > Live_Pid.in(0);
  Live_Pid > LIVE_PID_plant;
  LIVE_PID_plant > LIVE_PID_feedback;
  LIVE_PID_feedback.out(0) > LIVE_PID_error.in(1);
  LIVE_PID_feedback.out(1) > live_pid_measur;
  LIVE_PI_error > Live_Pi.in(0);
  Live_Pi > LIVE_PI_plant;
  LIVE_PI_plant > LIVE_PI_feedback;
  LIVE_PI_feedback.out(0) > LIVE_PI_error.in(1);
  LIVE_PI_feedback.out(1) > live_pi_measure;
  LIVE_PD_error > Live_Pd.in(0);
  Live_Pd > LIVE_PD_plant;
  LIVE_PD_plant > LIVE_PD_feedback;
  LIVE_PD_feedback.out(0) > LIVE_PD_error.in(1);
  LIVE_PD_feedback.out(1) > live_pd_measure;

  /* Enable Remote Input Control */
  kp.enableRemote();
  ki.enableRemote();
  kd.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    ki_split_tap.show();
    kd_split_tap.show();
    live_pid_measur.show();
    live_pi_measure.show();
    live_pd_measure.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}