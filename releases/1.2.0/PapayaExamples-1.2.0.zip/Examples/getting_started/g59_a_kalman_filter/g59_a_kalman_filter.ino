/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 00:54:18
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe kf_state_0;
probe kf_state_1;
probe adaptive_0;
probe adaptive_1;
probe chi_squared;
probe fault_flag;

input innovation_variance;

/* Global Struct Declarations */
// Kalman: PP_linearKF config
float Kalman_F[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float Kalman_B[1] = {0.0f};
float Kalman_H[2] = {1.0f, 0.0f};
float Kalman_Q[4] = {0.0001f, 0.0f, 0.0f, 0.0001f};
float Kalman_R = 0.1f;
float Kalman_x[2] = {0.0f, 0.0f};
float Kalman_P = 1.0f;
PP_linearKF Kalman_config = {
  2, 1, 0,
  Kalman_x, Kalman_F, Kalman_H, Kalman_Q, Kalman_B,
  Kalman_R, Kalman_P
};

// Adaptive_Kalman: PP_adaptiveKF config
float Adaptive_Kalman_F[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float Adaptive_Kalman_H[2] = {1.0f, 0.0f};
float Adaptive_Kalman_Q[4] = {0.0001f, 0.0f, 0.0f, 0.0001f};
float Adaptive_Kalman_B[1] = {};
float Adaptive_Kalman_x0[2] = {0.0f, 0.0f};
PP_adaptiveKF Adaptive_Kalman_config = {
  2, 1, 0,
  Adaptive_Kalman_x0, Adaptive_Kalman_F, Adaptive_Kalman_H, Adaptive_Kalman_Q, Adaptive_Kalman_B,
  0.1f /* R_init */, 1.0f /* P_init */, 0.99f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(1.0f, 0.0f);
  innovation_variance = input("innovation_variance", 0.1f);
  expander measurement = expander(3);
  linearKF Kalman = linearKF(&Kalman_config);
  adaptiveKF Adaptive_Kalman = adaptiveKF(&Adaptive_Kalman_config);
  innovationChi2 Consistency = innovationChi2(1, 6.63);
  kf_state_0 = probe("kf_state_0");
  kf_state_1 = probe("kf_state_1");
  adaptive_0 = probe("adaptive_0");
  adaptive_1 = probe("adaptive_1");
  chi_squared = probe("chi_squared");
  fault_flag = probe("fault_flag");

  /* Connect Blocks */
  Source > measurement;
  innovation_variance > Consistency.in(1);
  measurement.out(0) > Kalman;
  measurement.out(1) > Adaptive_Kalman;
  measurement.out(2) > Consistency.in(0);
  Kalman.out(0) > kf_state_0;
  Kalman.out(1) > kf_state_1;
  Adaptive_Kalman.out(0) > adaptive_0;
  Adaptive_Kalman.out(1) > adaptive_1;
  Consistency.out(0) > chi_squared;
  Consistency.out(1) > fault_flag;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    kf_state_0.show();
    kf_state_1.show();
    adaptive_0.show();
    adaptive_1.show();
    chi_squared.show();
    fault_flag.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}