/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 10000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe out_0;
probe out_1;
probe out_2;
probe out_3;
probe out_4;
probe out_5;
probe out_6;
probe out_7;

input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(10000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Sine_sweep = signalSource::chirpLinear(20.0f, 2000.0f, 2.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  const_ = input("const", 0.0f);
  noise Noise = noise(-0.5, 0.5, uniform);
  node Signal_noise = node("[1.0 0.2]", "[1.0]", Sum);
  expander Fan_out = expander(8);
  butter Butterworth = butter(4, 500.0, passLow);
  butterBq Butterworth_Biquad = butterBq(4, 500.0, passLow);
  cheby1 Chebyshev1 = cheby1(4, 500.0, passLow, Cheby1Cfg1);
  cheby1Bq Chebyshev1_Biquad = cheby1Bq(4, 500.0, passLow, Cheby1Cfg1);
  cheby2 Chebyshev2 = cheby2(4, 500.0, passLow, Cheby2Cfg1);
  cheby2Bq Chebyshev2_Biquad = cheby2Bq(4, 500.0, passLow, Cheby2Cfg1);
  ellip Elliptic = ellip(4, 500.0, passLow, EllipCfg1);
  ellipBq Elliptic_Biquad = ellipBq(4, 500.0, passLow, EllipCfg1);
  out_0 = probe("butterworth");
  out_1 = probe("butterworth_biq");
  out_2 = probe("chebyshev1");
  out_3 = probe("chebyshev1_biqu");
  out_4 = probe("chebyshev2");
  out_5 = probe("chebyshev2_biqu");
  out_6 = probe("elliptic");
  out_7 = probe("elliptic_biquad");

  /* Connect Blocks */
  Sine_sweep > Signal_noise.in(0);
  const_ > Noise;
  Noise > Signal_noise.in(1);
  Signal_noise > Fan_out;
  Fan_out.out(0) > Butterworth;
  Fan_out.out(1) > Butterworth_Biquad;
  Fan_out.out(2) > Chebyshev1;
  Fan_out.out(3) > Chebyshev1_Biquad;
  Fan_out.out(4) > Chebyshev2;
  Fan_out.out(5) > Chebyshev2_Biquad;
  Fan_out.out(6) > Elliptic;
  Fan_out.out(7) > Elliptic_Biquad;
  Butterworth > out_0;
  Butterworth_Biquad > out_1;
  Chebyshev1 > out_2;
  Chebyshev1_Biquad > out_3;
  Chebyshev2 > out_4;
  Chebyshev2_Biquad > out_5;
  Elliptic > out_6;
  Elliptic_Biquad > out_7;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    out_0.show();
    out_1.show();
    out_2.show();
    out_3.show();
    out_4.show();
    out_5.show();
    out_6.show();
    out_7.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}