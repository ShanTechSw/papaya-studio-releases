"""What a board refusal MEANS, and what actually caused it.

Why this module exists
----------------------
When the PAPAYA board refuses a command it answers with a status byte.
The console printed the name and the number:

    #30    Manageblock/StartSampling         X BadRequest (status 8)

which is true, and is not an answer. Two things were missing and both of
them are things the caller can be told:

1. WHAT THE BOARD MEANS BY IT. ``BadRequest`` does not mean "unknown
   command"; it means "the requested operation is not permitted in the
   state the board is in right now". Those lead to different next steps
   and the console said the first one.

2. WHAT CAUSED IT. The status is a category, not a cause. The evidence
   that narrows it down is already at the call site and was thrown away:
   which command was refused, which block it named, what parameters were
   in the frame, whether a communication error came with it, what the
   board wrote in its own debug log, and how big the design is.

:func:`diagnose` puts those together and returns ranked causes, each with
what to do about it. Nothing here guesses: a cause is only raised when
the evidence for it is present, it says what that evidence was, and a
refusal that matches nothing returns the status meaning alone rather than
a plausible story.

Reading a diagnosis
-------------------
:class:`Diagnosis` renders to plain lines::

    BadRequest (status 8): the requested operation is not permitted in
    the state the board is in.
      Refused: Manageblock/StartSampling
      Most likely cause (certain): the command numbering is out of step
        Why: the board's own log says it expected sequence 0 and received 7.
        Fix: reconnect, which restarts the numbering on both sides.
        Fix: if it recurs, power the board off and on.

That is the whole public surface plus :func:`describe_design_status` and
:func:`describe_com_status` for callers that only want the meaning.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "COM_STATUS",
    "Cause",
    "DESIGN_STATUS",
    "Diagnosis",
    "Evidence",
    "StatusMeaning",
    "describe_com_status",
    "describe_design_status",
    "diagnose",
]


# ---------------------------------------------------------------------
# What the board means by each status
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class StatusMeaning:
    """One status byte, decoded.

    ``summary`` is the sentence to print beside the code. ``detail`` says
    what the board was actually checking when it produced it, which is
    what turns the summary into something a reader can act on.
    """

    code: int
    name: str
    summary: str
    detail: str = ""

    def label(self) -> str:
        """``BadRequest (status 8)``, the way the console names it."""
        return f"{self.name} (status {self.code})"

    def __bool__(self) -> bool:
        return self.code != 0


def _s(code: int, name: str, summary: str, detail: str = "") -> StatusMeaning:
    return StatusMeaning(code=code, name=name, summary=summary, detail=detail)


#: The design status the board answers every configuration command with.
#: The summaries follow what the firmware actually tests, not what the
#: name suggests: ``BadRequest`` in particular is a STATE refusal and was
#: being reported as an unrecognised command, which sends the reader to
#: look for a firmware version problem that is not there.
DESIGN_STATUS: Dict[int, StatusMeaning] = {
    0: _s(0, "DesignOk", "the board accepted the command."),
    1: _s(1, "MemError",
          "the board could not allocate memory for what was asked.",
          "Every block, probe and buffer a design creates is allocated "
          "from the board's heap when the design is built. Running out "
          "means the design as a whole does not fit, not that this one "
          "block is wrong."),
    2: _s(2, "TfError",
          "the transfer function was rejected.",
          "The board checks a transfer function's coefficients, its "
          "order and the sampling period it is being discretised at. A "
          "denominator whose leading coefficient is zero, an order "
          "beyond what the block supports, and a sampling period that "
          "makes the discretisation degenerate all land here."),
    3: _s(3, "UnknownC2dAlgo",
          "the continuous-to-discrete algorithm is not one the board knows.",
          "The board accepts Tustin, Euler backward and Euler forward. "
          "Anything else means the design carries a value from a newer "
          "or edited file."),
    4: _s(4, "TextOk", "the text coefficients were parsed."),
    5: _s(5, "TxtError",
          "a text coefficient could not be parsed.",
          "The board parses coefficients sent as text. A malformed "
          "number, or a string longer than the field it is sent in, "
          "produces this."),
    6: _s(6, "BadParam",
          "one or more parameters are out of range or invalid.",
          "The board range-checks every parameter of every block as it "
          "creates it. This names the command that carried the value, "
          "so the block it refers to is the one to open."),
    7: _s(7, "BadConnection",
          "the link was incompatible or already present.",
          "The board refuses a link whose two ends do not fit, and it "
          "refuses a second link onto a port that already has one. It "
          "also enforces an ORDER: a block that transforms its input "
          "cannot be linked as a source until its own input is wired, "
          "so a loop has to be closed at a summing or product node."),
    8: _s(8, "BadRequest",
          "the requested operation is not permitted in the state the "
          "board is in.",
          "This is a STATE refusal, not an unknown command. The board "
          "is in a configuration session, a sampling run, or neither, "
          "and only some commands are legal in each. The commonest "
          "cause by a wide margin is that the command numbering has "
          "gone out of step between the two sides."),
    9: _s(9, "SamplingFreqOutOfLimit",
          "the sampling frequency is outside what the board accepts.",
          "The rate is checked against the board's own limits before "
          "anything is built."),
    10: _s(10, "GPIO_Failure", "a digital pin could not be set up."),
    11: _s(11, "TIM_Failure", "a timer could not be set up."),
    12: _s(12, "ADC_Failure", "an analog input could not be set up."),
    13: _s(13, "DAC_Failure", "an analog output could not be set up."),
    14: _s(14, "COMP_Failure", "a comparator could not be set up."),
    15: _s(15, "DMA_Failure", "a data transfer channel could not be set up."),
    16: _s(16, "OPAMP_Failure",
           "an internal amplifier could not be set up."),
    17: _s(17, "SPI_Failure", "the SPI interface could not be set up."),
    18: _s(18, "UART_Failure", "the serial interface could not be set up."),
    19: _s(19, "I2C_Failure", "the I2C interface could not be set up."),
    20: _s(20, "USB_Failure", "the USB interface could not be set up."),
    21: _s(21, "UndefinedFailure",
           "a hardware failure the board could not classify."),
    255: _s(255, "NoDesignStatus", "the board reported no design status."),
}


#: The communication status, which is about the FRAME rather than about
#: what it asked for. A frame that never decoded cannot have a meaningful
#: design status beside it, which is why the two are reported separately.
COM_STATUS: Dict[int, StatusMeaning] = {
    0: _s(0, "ComOk", "the frame arrived intact."),
    1: _s(1, "WrongSeqNumber",
          "the frame's sequence number was not the one the board "
          "expected next.",
          "Every command carries a number and the board expects them in "
          "order. One lost or duplicated frame puts the two sides out of "
          "step and every command after it is refused until the "
          "numbering is restarted."),
    2: _s(2, "WrongCrc",
          "the frame's checksum did not match its contents.",
          "The bytes were altered or truncated between the two ends. "
          "This is about the link, not about the design."),
    3: _s(3, "UnknownComError",
          "the board reported a communication error it could not "
          "classify.",
          "In practice this is what a caller sees when no answer came "
          "back at all."),
    255: _s(255, "NoComStatus", "the board reported no communication status."),
}


def _unknown(code: int, kind: str) -> StatusMeaning:
    return StatusMeaning(
        code=int(code), name=f"status {int(code)}",
        summary=f"the board reported a {kind} status this build does not "
                f"have a name for.",
        detail="A board running newer firmware than this software can "
               "answer with codes it does not know yet.")


def describe_design_status(code) -> StatusMeaning:
    """The meaning of a design status byte. Never raises."""
    try:
        value = int(getattr(code, "value", code))
    except (TypeError, ValueError):
        return _unknown(-1, "design")
    known = DESIGN_STATUS.get(value)
    # ``is None``, not ``or``: DesignOk is code 0 and therefore falsy, so
    # ``get(value) or _unknown(...)`` reported the board's own SUCCESS as
    # a code this build does not know.
    return known if known is not None else _unknown(value, "design")


def describe_com_status(code) -> StatusMeaning:
    """The meaning of a communication status byte. Never raises."""
    try:
        value = int(getattr(code, "value", code))
    except (TypeError, ValueError):
        return _unknown(-1, "communication")
    known = COM_STATUS.get(value)
    return known if known is not None else _unknown(value, "communication")


# ---------------------------------------------------------------------
# The evidence, and what it points at
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class Evidence:
    """Everything known about one refusal, at the moment it happened.

    Every field is optional. The rules below fire only on the evidence
    that is actually present, so a caller that can supply little still
    gets the status meaning and whatever few rules its evidence reaches;
    it never gets a cause invented out of a missing field.
    """

    #: The status the board answered with.
    design_status: int = 0
    #: The communication status that came with it, when there was one.
    com_status: Optional[int] = None
    #: ``"Manageblock"`` / ``"StartSampling"`` as the board names them.
    func: str = ""
    sub: str = ""
    #: The block the command was about, as the board numbers them.
    block_id: Optional[int] = None
    #: The command's own sequence number on the wire.
    seq: Optional[int] = None
    #: The parameter lines the host recorded when it built the frame.
    notes: Sequence[str] = ()
    #: What the board wrote in its own log, newest last.
    board_log: str = ""
    #: True when the board answered nothing at all rather than refusing.
    timed_out: bool = False
    #: How many commands went out before this one in the same step. The
    #: board halts on the first failure, so a large number means the
    #: design was mostly accepted and one thing in it was not.
    preceding_commands: int = 0
    #: The design's own size, where the caller knows it.
    block_count: Optional[int] = None
    probe_count: Optional[int] = None
    vector_probe_count: Optional[int] = None
    remote_input_count: Optional[int] = None
    fs_hz: Optional[float] = None
    #: ``"usb"`` or ``"wireless"``; changes what "check the link" means.
    transport: str = ""


@dataclass(frozen=True)
class Cause:
    """One candidate cause, with the evidence for it and what to do.

    ``confidence`` is one of ``"certain"``, ``"likely"`` and
    ``"possible"``, and it means what it says: ``certain`` is reserved for
    a cause the evidence PROVES (the board's own log naming the mismatch,
    for instance), never for the most plausible of several.
    """

    confidence: str
    summary: str
    why: str = ""
    fixes: Tuple[str, ...] = ()

    #: Ordering key, so the caller never has to know the words.
    _RANK = {"certain": 0, "likely": 1, "possible": 2}

    @property
    def rank(self) -> int:
        return self._RANK.get(self.confidence, 3)


@dataclass(frozen=True)
class Diagnosis:
    """A refusal, decoded and explained."""

    status: StatusMeaning
    com: Optional[StatusMeaning] = None
    operation: str = ""
    block_id: Optional[int] = None
    causes: Tuple[Cause, ...] = field(default_factory=tuple)
    #: True when nothing came back at all. A timeout has no design status
    #: to report, so leading with one would say "the board accepted the
    #: command" about a board that answered nothing.
    timed_out: bool = False

    @property
    def is_ok(self) -> bool:
        return self.status.code == 0 and (self.com is None
                                          or self.com.code == 0)

    def lines(self) -> List[str]:
        """The whole diagnosis as console-ready plain text.

        One authority for the wording, so the two debuggers and any
        future caller word a refusal identically.
        """
        if self.timed_out:
            out: List[str] = [
                "No answer from the board: it did not reply to this "
                "command within the timeout."]
        else:
            out = [f"{self.status.label()}: {self.status.summary}"]
            if self.status.detail:
                out.append(f"  {self.status.detail}")
        if (not self.timed_out and self.com is not None
                and self.com.code not in (0, 255)):
            out.append(f"Also {self.com.label()}: {self.com.summary}")
            if self.com.detail:
                out.append(f"  {self.com.detail}")
        if self.operation:
            where = f"  Refused: {self.operation}"
            if self.block_id is not None:
                where += f", on block {self.block_id}"
            out.append(where)
        if not self.causes:
            out.append("  No single cause follows from what is known here. "
                       "The meaning above is what the board is telling you.")
            return out
        for index, cause in enumerate(self.causes):
            head = ("Most likely cause" if index == 0 else "Also")
            out.append(f"  {head} ({cause.confidence}): {cause.summary}")
            if cause.why:
                out.append(f"    Why: {cause.why}")
            for fix in cause.fixes:
                out.append(f"    Fix: {fix}")
        return out


# ---------------------------------------------------------------------
# The rules
# ---------------------------------------------------------------------
#
# Each rule is a small function that reads the evidence and returns the
# causes it can justify, or nothing. They are deliberately separate and
# deliberately narrow: a rule that fires on "status 8" alone would fire
# on every refusal and say nothing, and a rule that reads a field the
# caller did not fill in must return nothing rather than assume.

#: The board's own log line for a rejected header names both numbers.
#: This is the one piece of evidence that makes a desync CERTAIN rather
#: than likely, so it is matched exactly rather than by keyword.
_SEQ_LOG = re.compile(
    r"header invalid \(seq cmd=(\d+) board=(\d+)", re.IGNORECASE)

#: And the log's own word for a checksum rejection.
_CRC_LOG = re.compile(r"crc rx=(\w+) calc=(\w+)", re.IGNORECASE)

#: Commands that only make sense inside a configuration session.
_CONFIG_ONLY = ("createblock", "linkblock", "designinit", "newsys",
                "new", "setparam")

#: Commands that arm or run the monitor.
_MONITOR_OPS = ("startsampling", "stopsampling", "pushprobe",
                "enableremoteinput", "monitor")

# The board's monitor slot counts, read from the one place that mirrors
# the firmware's arrays rather than transcribed here.
try:
    from .constants import (
        PP_MAX_INPUTS_NUMBER as _MAX_REMOTE_INPUTS,
        PP_MAX_PROBES_NUMBER as _MAX_PROBES,
        PP_MAX_VECTOR_PROBES_NUMBER as _MAX_VECTOR_PROBES,
    )
except Exception:                                   # pragma: no cover
    _MAX_PROBES = _MAX_REMOTE_INPUTS = 16
    _MAX_VECTOR_PROBES = 9


def _op(evidence: Evidence) -> str:
    func, sub = str(evidence.func or ""), str(evidence.sub or "")
    if func and sub:
        return f"{func}/{sub}"
    return func or sub or ""


def _op_key(evidence: Evidence) -> str:
    return _op(evidence).lower()


def _rule_sequence_desync(ev: Evidence) -> List[Cause]:
    """The commonest BadRequest by a wide margin, and it is provable.

    The board writes the two numbers into its own log, so when the log
    has been fetched this is not an inference at all.
    """
    if ev.design_status != 8 and ev.com_status != 1:
        return []
    match = _SEQ_LOG.search(ev.board_log or "")
    if match:
        sent, expected = match.group(1), match.group(2)
        return [Cause(
            "certain",
            "the command numbering is out of step between this computer "
            "and the board",
            f"the board's own log says it expected sequence {expected} "
            f"and received {sent}.",
            ("Disconnect and connect again: re-claiming the board's "
             "configuration session restarts the numbering on both "
             "sides.",
             "If it comes back immediately, power the board off and on. "
             "A run that was interrupted part way can leave the board "
             "holding a session this computer no longer knows about."))]
    if ev.com_status == 1:
        return [Cause(
            "certain",
            "the command numbering is out of step between this computer "
            "and the board",
            "the board answered WrongSeqNumber, which is exactly that.",
            ("Disconnect and connect again to restart the numbering on "
             "both sides.",))]
    if ev.design_status == 8:
        return [Cause(
            "likely",
            "the command numbering is out of step between this computer "
            "and the board",
            "a state refusal on a configuration command is most often "
            "one side counting from a different place; the board's log "
            "would say so, and it was not read here.",
            ("Disconnect and connect again to restart the numbering.",
             "To confirm rather than guess, read the board's log: it "
             "records the number it expected and the one it received."))]
    return []


def _rule_state_refusal(ev: Evidence) -> List[Cause]:
    """A configuration command sent while the board is sampling, or the
    reverse. The evidence is the OPERATION, so it is only raised when
    the operation is one of the two that cannot cross that line."""
    if ev.design_status != 8:
        return []
    key = _op_key(ev)
    if any(word in key for word in _CONFIG_ONLY):
        return [Cause(
            "possible",
            "the board is still sampling, and a design cannot be "
            "changed while it runs",
            f"{_op(ev)} builds part of a design, and the board only "
            f"accepts that while it is idle.",
            ("Stop the run before changing the design.",))]
    if "startsampling" in key:
        return [Cause(
            "possible",
            "the board is already sampling",
            "a second start is refused rather than restarting the run.",
            ("Stop the run first, then start it again.",))]
    if "stopsampling" in key:
        return [Cause(
            "possible",
            "the board was not sampling",
            "there was nothing to stop.",
            ("Nothing to do: the board is already idle.",))]
    return []


def _rule_no_answer(ev: Evidence) -> List[Cause]:
    """Silence is its own failure, and it has one cause worth naming
    first: a frame whose declared length and written length disagree.

    The board waits for the bytes the header promised. If the frame
    declared five parameters and wrote four, the board waits for a fifth
    that never comes, and from this end that is indistinguishable from a
    dead board. It has been mistaken for one.
    """
    if not ev.timed_out:
        return []
    wireless = str(ev.transport or "").lower().startswith("wire")
    causes = [Cause(
        "likely",
        "the board is waiting for bytes that were never sent",
        "a command frame declares how many bytes follow it, and the "
        "board waits for exactly that many. A frame that declares more "
        "than it writes leaves the board waiting, which looks from here "
        "exactly like a board that has stopped.",
        ("Reconnect. The board releases the half-received command and "
         "starts again.",))]
    if wireless:
        causes.append(Cause(
            "possible",
            "the wireless link dropped the command or its answer",
            "nothing came back within the timeout, and this session is "
            "running over Wi-Fi.",
            ("Check the gateway is powered and on the network, then "
             "connect again.",)))
    else:
        causes.append(Cause(
            "possible",
            "the USB connection was interrupted",
            "nothing came back within the timeout.",
            ("Unplug the cable and plug it back in, then connect again.",)))
    causes.append(Cause(
        "possible",
        "the board is held in a state it cannot answer from",
        "a run interrupted part way can leave the board owning a "
        "session nobody is talking to.",
        ("Power the board off and on.",)))
    return causes


def _rule_memory(ev: Evidence) -> List[Cause]:
    if ev.design_status != 1:
        return []
    detail = []
    if ev.block_count is not None:
        detail.append(f"{ev.block_count} blocks")
    if ev.probe_count:
        detail.append(f"{ev.probe_count} probes")
    if ev.vector_probe_count:
        detail.append(f"{ev.vector_probe_count} vector probes")
    size = (", ".join(detail) if detail else "")
    why = ("the board allocates every block, probe and buffer when the "
           "design is built, and this one did not fit")
    if size:
        why += f" ({size})"
    why += "."
    where = ""
    if ev.preceding_commands:
        where = (f" It ran out after {ev.preceding_commands} command(s) "
                 f"had already been accepted, so most of the design did "
                 f"fit.")
    return [Cause(
        "certain", "the design is too large for the board's memory",
        why + where,
        ("Remove blocks, or split the work across two designs.",
         "Vector probes are the largest single consumer: each one "
         "reserves a buffer for a whole frame. Removing one frees more "
         "than removing several ordinary blocks.",
         "Reduce a transform's length (an FFT or a framer's N) if the "
         "design needs one: the buffer scales with it."))]


def _rule_bad_param(ev: Evidence) -> List[Cause]:
    """The status names the command, and the command names its block.
    Everything past that comes from the parameters the host recorded."""
    if ev.design_status != 6:
        return []
    suspects = _suspect_notes(ev.notes)
    if suspects:
        return [Cause(
            "likely",
            "a parameter of this block is outside what the board accepts",
            "the board range-checks each parameter as it creates the "
            "block, and these were in the refused command: "
            + "; ".join(suspects) + ".",
            ("Open that block and check the values named above against "
             "the range in its description.",
             "A value entered as an expression keeps its last computed "
             "number when a name it uses is renamed. Check the "
             "expression as well as the number."))]
    return [Cause(
        "likely",
        "a parameter of this block is outside what the board accepts",
        "the board range-checks each parameter as it creates the block "
        "and refused this one.",
        ("Open the block the command names and check its values against "
         "the ranges in its description.",))]


def _rule_bad_connection(ev: Evidence) -> List[Cause]:
    if ev.design_status != 7:
        return []
    return [
        Cause("likely",
              "the link could not be made in the order it was sent",
              "the board will not use a block as a source until that "
              "block's own input is wired, so a loop made only of "
              "blocks that transform their input cannot be built in any "
              "order.",
              ("Close the loop at a summing or product node: a node's "
               "inputs may be wired at any time.",)),
        Cause("possible",
              "the port already has a link on it",
              "the board accepts one source per input, and one vector "
              "source per vector probe.",
              ("Delete the second wire onto that port.",)),
    ]


def _rule_transfer_function(ev: Evidence) -> List[Cause]:
    if ev.design_status != 2:
        return []
    return [Cause(
        "likely",
        "the transfer function's coefficients, order or sampling period "
        "were not usable",
        "the board discretises the function at the design's sampling "
        "period and refused the result.",
        ("Check the denominator: its leading coefficient may not be "
         "zero.",
         "Check the order against what the block's description allows.",
         "Check the design's sampling frequency: a pole far above or "
         "far below it discretises into something the board cannot "
         "run."))]


def _rule_sampling_rate(ev: Evidence) -> List[Cause]:
    if ev.design_status != 9:
        return []
    rate = ""
    if ev.fs_hz:
        rate = f" The design asks for {ev.fs_hz:g} Hz."
    return [Cause(
        "certain", "the sampling frequency is outside the board's range",
        "the board checks the rate before it builds anything." + rate,
        ("Open Design Settings and set a sampling frequency inside the "
         "range the board accepts.",))]


def _rule_peripheral(ev: Evidence) -> List[Cause]:
    """The hardware families. What they share is the cause: two blocks
    asking for one physical thing."""
    families = {
        10: ("digital pin", "a digital input or output"),
        11: ("timer", "a PWM output, a frequency input or an encoder"),
        12: ("analog input", "an analog input"),
        13: ("analog output", "an analog output"),
        14: ("comparator", "a threshold or comparator block"),
        15: ("data transfer channel", "a high-rate input or output"),
        16: ("internal amplifier", "an amplified analog input"),
        17: ("SPI interface", "an external sensor or IO module"),
        18: ("serial interface", "a serial peripheral"),
        19: ("I2C interface", "an external sensor or IO module"),
        20: ("USB interface", "the USB link itself"),
    }
    entry = families.get(ev.design_status)
    if entry is None:
        return []
    thing, users = entry
    return [
        Cause("likely",
              f"two blocks are asking for the same {thing}",
              f"the board sets up each {thing} once, and the second "
              f"request for the same one fails. The blocks that use one "
              f"are {users}.",
              (f"Check every block that uses {users} and give each one "
               f"a different channel.",)),
        Cause("possible",
              f"the {thing} this design asks for is not available on "
              f"this board",
              "the board refused to set it up at all.",
              ("Check the channel number against the board's "
               "specification.",)),
    ]


def _rule_monitor_limits(ev: Evidence) -> List[Cause]:
    """A refusal on a monitoring command with a full monitor behind it.

    Only raised when the caller actually supplied the counts: the board
    does not say "too many probes", so this is an inference, and an
    inference with no numbers behind it is a guess.
    """
    if ev.design_status != 8:
        return []
    if not any(word in _op_key(ev) for word in _MONITOR_OPS):
        return []
    # Only when a count actually REACHES its limit. Below that the
    # monitor has room and saying "possible" would be a guess dressed as
    # a finding; the counts are known and so are the limits, so the rule
    # can be evidence-driven instead.
    over = []
    for count, limit, what in (
            (ev.probe_count, _MAX_PROBES, "probes"),
            (ev.vector_probe_count, _MAX_VECTOR_PROBES, "vector probes"),
            (ev.remote_input_count, _MAX_REMOTE_INPUTS, "remote inputs")):
        if count is not None and int(count) >= int(limit):
            over.append(f"{int(count)} {what} against a limit of "
                        f"{int(limit)}")
    if not over:
        return []
    return [Cause(
        "likely",
        "the design asks the board to monitor more than it can",
        f"the refused command is {_op(ev)} and this design has "
        + ", ".join(over) + ". The board's monitor has a fixed number of "
        "slots for each and refuses the one past the end.",
        ("Remove one of them, or hide it: a probe that is not monitored "
         "does not take a slot.",
         "Validate the design before deploying: the check refuses this "
         "on this computer and names the count."))]


def _rule_crc(ev: Evidence) -> List[Cause]:
    """Only when the two checksums actually DIFFER.

    The board's header-rejection line prints ``crc rx=... calc=...``
    whether or not they match, because the line is about the header and
    not about the checksum. Matching the line alone blamed the cable on
    every sequence mismatch, and put that answer FIRST.
    """
    mismatched = False
    match = _CRC_LOG.search(ev.board_log or "")
    if match:
        received, calculated = match.group(1), match.group(2)
        mismatched = (str(received).lower().lstrip("0x")
                      != str(calculated).lower().lstrip("0x"))
    if ev.com_status != 2 and not mismatched:
        return []
    wireless = str(ev.transport or "").lower().startswith("wire")
    fix = (("Check the gateway and the network, then connect again.",)
           if wireless else
           ("Try a different USB cable or port. A checksum failure is "
            "about the wire, not about the design.",))
    return [Cause(
        "certain", "the bytes were altered between this computer and the "
                   "board",
        "the board's checksum over the frame did not match its "
        "contents.",
        fix)]


_RULES = (
    _rule_no_answer,
    _rule_crc,
    _rule_sequence_desync,
    _rule_memory,
    _rule_sampling_rate,
    _rule_bad_param,
    _rule_bad_connection,
    _rule_transfer_function,
    _rule_peripheral,
    _rule_monitor_limits,
    _rule_state_refusal,
)


#: Words in a recorded parameter line that make it worth quoting back.
#: A frame carries dozens of notes and quoting all of them is noise; a
#: note holding a number that is zero, negative, enormous or not finite
#: is the one a range check is most likely to have refused.
_SUSPECT = re.compile(
    r"(?P<name>[A-Za-z_][A-Za-z0-9_ ]*)\s*[=:]\s*"
    r"(?P<value>-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?|nan|inf|-inf)")


def _suspect_notes(notes: Iterable[str], limit: int = 4) -> List[str]:
    """The parameter lines most likely to be the refused one.

    A judgement about WHICH note to show, never about what is wrong: the
    board did not say which parameter it refused, so this only narrows
    what to read first and the wording says so.
    """
    out: List[str] = []
    for note in notes or ():
        text = str(note).strip()
        if not text:
            continue
        for match in _SUSPECT.finditer(text):
            raw = match.group("value").lower()
            try:
                value = float(raw)
            except ValueError:
                out.append(text)
                break
            if raw in ("nan", "inf", "-inf") or value != value:
                out.append(text)
                break
            if value == 0.0 or value < 0.0 or abs(value) >= 1e6:
                out.append(text)
                break
        if len(out) >= limit:
            break
    return out


def diagnose(evidence: Evidence) -> Diagnosis:
    """Decode a refusal and rank what caused it.

    Never raises: it is called from a console handler on the failure
    path, and a diagnosis that throws would replace a bad message with no
    message.
    """
    try:
        status = describe_design_status(evidence.design_status)
        com = (describe_com_status(evidence.com_status)
               if evidence.com_status is not None else None)
        causes: List[Cause] = []
        seen = set()
        for rule in _RULES:
            try:
                found = rule(evidence) or []
            except Exception:                       # noqa: BLE001
                found = []
            for cause in found:
                if cause.summary in seen:
                    continue
                seen.add(cause.summary)
                causes.append(cause)
        causes.sort(key=lambda c: c.rank)
        return Diagnosis(status=status, com=com, operation=_op(evidence),
                         block_id=evidence.block_id,
                         causes=tuple(causes),
                         timed_out=bool(evidence.timed_out))
    except Exception:                               # noqa: BLE001
        return Diagnosis(status=_unknown(-1, "design"))
