/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe robot_heading;
probe robot_x;
probe robot_y;
probe ekf_pose;
probe unused_signals;

input const_;
input const__2;
input const__3;
input const__4;
input const__5;
input const__6;
input const__7;

/* Global Struct Declarations */
// Configuration for WMR_EKF
static float WMR_EKF_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float WMR_EKF_R_data[49] = {0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f};
static float WMR_EKF_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_WMR_EKF WMR_EKF_config = {
  .wheel_base = 0.3f,
  .mag_ref = { 1.0f, 0.0f },
  .Q_data = WMR_EKF_Q_data,
  .R_data = WMR_EKF_R_data,
  .x_init = WMR_EKF_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__left_wheel = signalSource::multisine(0.1f, 0.1f, 3, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.4f, /*offset=*/ 1.0f);
  signalSource SIM__right_wheel = signalSource::multisine(0.1f, 0.1f, 3, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.4f, /*offset=*/ 1.1f);
  signalSource SIM__IMU_gyro = signalSource::sine(0.2f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  const__3 = input("const", 0.0f);
  const__4 = input("const", 0.0f);
  const__5 = input("const", 0.0f);
  const__6 = input("const", 0.0f);
  const__7 = input("const", 0.0f);
  expander fan_3 = expander(4);
  expander fan_3_2 = expander(4);
  expander fan_2_3 = expander(1);
  node forward_velocity = node("[0.5 0.5]", "[1.0]", Sum);
  node yaw_rate = node("[-1.0 1.0]", "[1.0]", Sum);
  imuBiasEst gyro_bias_est = imuBiasEst(64, 0.001, 0.01);
  integrator heading = integrator();
  expander fan_2_2 = expander(2);
  expander fan_2 = expander(2);
  cosineFunc cos_heading = cosineFunc();
  sineFunc sin_heading = sineFunc();
  expander fan_cos = expander(2);
  expander fan_sin = expander(2);
  node x_velocity = node("[1.0 1.0]", "[1.0]", Mul);
  node y_velocity = node("[1.0 1.0]", "[1.0]", Mul);
  gain mag_y_sign = gain(-1.0);
  integrator x_position = integrator();
  integrator y_position = integrator();
  wmrEKF WMR_EKF = wmrEKF(&WMR_EKF_config);
  merger unused_bus = merger(17);
  robot_heading = probe("robot_heading");
  robot_x = probe("robot_x_m");
  robot_y = probe("robot_y_m");
  ekf_pose = probe("ekf_fused_pose");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  SIM__left_wheel > fan_3;
  SIM__right_wheel > fan_3_2;
  SIM__IMU_gyro > fan_2_3;
  const_ > WMR_EKF.in(0);
  const__2 > WMR_EKF.in(1);
  const__3 > gyro_bias_est.in(1);
  const__4 > gyro_bias_est.in(2);
  const__5 > gyro_bias_est.in(3);
  const__6 > gyro_bias_est.in(4);
  const__7 > gyro_bias_est.in(0);
  fan_3.out(0) > forward_velocity.in(0);
  fan_3.out(1) > yaw_rate.in(0);
  fan_3.out(2) > WMR_EKF.in(5);
  fan_3.out(3) > WMR_EKF.in(7);
  fan_3_2.out(0) > forward_velocity.in(1);
  fan_3_2.out(1) > yaw_rate.in(1);
  fan_3_2.out(2) > WMR_EKF.in(6);
  fan_3_2.out(3) > WMR_EKF.in(8);
  fan_2_3 > gyro_bias_est.in(5);
  forward_velocity > fan_2_2;
  yaw_rate > heading;
  gyro_bias_est.out(5) > WMR_EKF.in(2);
  gyro_bias_est.out(0) > unused_bus.in(6);
  gyro_bias_est.out(1) > unused_bus.in(7);
  gyro_bias_est.out(2) > unused_bus.in(8);
  gyro_bias_est.out(3) > unused_bus.in(9);
  gyro_bias_est.out(4) > unused_bus.in(10);
  gyro_bias_est.out(6) > unused_bus.in(11);
  gyro_bias_est.out(7) > unused_bus.in(12);
  gyro_bias_est.out(8) > unused_bus.in(13);
  gyro_bias_est.out(9) > unused_bus.in(14);
  gyro_bias_est.out(10) > unused_bus.in(15);
  gyro_bias_est.out(11) > unused_bus.in(16);
  heading > fan_2;
  heading > robot_heading;
  fan_2_2.out(0) > x_velocity.in(0);
  fan_2_2.out(1) > y_velocity.in(0);
  fan_2.out(0) > cos_heading;
  fan_2.out(1) > sin_heading;
  cos_heading > fan_cos;
  sin_heading > fan_sin;
  fan_cos.out(0) > x_velocity.in(1);
  fan_cos.out(1) > WMR_EKF.in(3);
  fan_sin.out(0) > y_velocity.in(1);
  fan_sin.out(1) > mag_y_sign;
  x_velocity > x_position;
  y_velocity > y_position;
  mag_y_sign > WMR_EKF.in(4);
  x_position > robot_x;
  y_position > robot_y;
  WMR_EKF.out(1) > unused_bus.in(0);
  WMR_EKF.out(2) > unused_bus.in(1);
  WMR_EKF.out(3) > unused_bus.in(2);
  WMR_EKF.out(4) > unused_bus.in(3);
  WMR_EKF.out(5) > unused_bus.in(4);
  WMR_EKF.out(6) > unused_bus.in(5);
  WMR_EKF.out(0) > ekf_pose;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    robot_heading.show();
    robot_x.show();
    robot_y.show();
    ekf_pose.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}