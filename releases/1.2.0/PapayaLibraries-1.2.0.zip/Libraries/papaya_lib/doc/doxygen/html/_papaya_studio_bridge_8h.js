var _papaya_studio_bridge_8h =
[
    [ "PapayaStudioBridge", "class_papaya_studio_bridge.html", "class_papaya_studio_bridge" ],
    [ "PapayaStudioBridge::Reply", "struct_papaya_studio_bridge_1_1_reply.html", "struct_papaya_studio_bridge_1_1_reply" ],
    [ "PAPAYA_BRIDGE_DEFAULT_RX_TIMEOUT_MS", "_papaya_studio_bridge_8h.html#a23a0f994d91cd8f4de1263513f506769", null ],
    [ "PAPAYA_BRIDGE_DEFAULT_TX_TIMEOUT_MS", "_papaya_studio_bridge_8h.html#a10a4cd0e8e897f2a2c8385cc3955b374", null ],
    [ "PAPAYA_BRIDGE_MAX_PAYLOAD", "_papaya_studio_bridge_8h.html#a2434d422a2d1b5bf00ba56f396c52873", null ],
    [ "PAPAYA_BRIDGE_MAX_POLL_MS", "_papaya_studio_bridge_8h.html#ae96d023a3a1e9340448e5c1a8c98aff4", null ],
    [ "PAPAYA_BRIDGE_OP_BYE", "_papaya_studio_bridge_8h.html#a633c575c14bcf1dbcbca0c83ed7752b5", null ],
    [ "PAPAYA_BRIDGE_OP_HELLO", "_papaya_studio_bridge_8h.html#aaaf6c6d3c50b20b343b74c3c48d8111e", null ],
    [ "PAPAYA_BRIDGE_OP_READ", "_papaya_studio_bridge_8h.html#ab37fe6e81e9bd579d3c16ea1a3b95b1e", null ],
    [ "PAPAYA_BRIDGE_OP_SEQ", "_papaya_studio_bridge_8h.html#a6a26da1e6e61b58fddb10cd89607c886", null ],
    [ "PAPAYA_BRIDGE_OP_WRITE", "_papaya_studio_bridge_8h.html#a4b85e0e72e5e99c55920496181476457", null ],
    [ "PAPAYA_BRIDGE_PROTO_VER", "_papaya_studio_bridge_8h.html#aa3c7221fd20946c319e24f1cfa85570f", null ],
    [ "PAPAYA_BRIDGE_READ_GRANULARITY", "_papaya_studio_bridge_8h.html#a09445b7229f10e9b88eb1557ffba56d8", null ],
    [ "PAPAYA_BRIDGE_SOCKET_GRACE_MS", "_papaya_studio_bridge_8h.html#aaf2353aa20babf344983c0bd9efe526c", null ]
];