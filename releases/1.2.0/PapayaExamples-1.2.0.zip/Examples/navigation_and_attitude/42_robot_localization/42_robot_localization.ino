/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe gyro_bias;
probe xy_heading;
probe wmr_pose;
probe fused_pose;
probe gps_gate;
probe unused_signals;

input gps_px_sigma;

/* Global Struct Declarations */
// Configuration for Left_wheel_enc
PP_encoderBlockCfg Left_wheel_enc_config = {
  ENC1,
  {1.0f, 1.0f, 0.01f},
  1,
  {EncoderVelocity, NoEncoderOutput}
};

// Configuration for Right_wheel_enc
PP_encoderBlockCfg Right_wheel_enc_config = {
  ENC2,
  {1.0f, 1.0f, 0.01f},
  1,
  {EncoderVelocity, NoEncoderOutput}
};

// Configuration for Robot_loc_EKF
static float Robot_loc_EKF_Q_data[9] = {0.01f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Robot_loc_EKF_R_data[4] = {0.1f, 0.0f, 0.0f, 0.1f};
static float Robot_loc_EKF_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_RobotLoc_EKF Robot_loc_EKF_config = {
  .wheel_radius = 0.05f,
  .wheel_base = 0.3f,
  .landmark_x = 1.0f,
  .landmark_y = 0.0f,
  .Q_data = Robot_loc_EKF_Q_data,
  .R_data = Robot_loc_EKF_R_data,
  .x_init = Robot_loc_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for WMR_EKF
static float WMR_EKF_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float WMR_EKF_R_data[49] = {0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f};
static float WMR_EKF_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_WMR_EKF WMR_EKF_config = {
  .wheel_base = 0.3f,
  .mag_ref = { 1.0f, 0.0f },
  .Q_data = WMR_EKF_Q_data,
  .R_data = WMR_EKF_R_data,
  .x_init = WMR_EKF_x_init,
  .P_init = 1.0f
};

// Configuration for GPS_INS_EKF
static float GPS_INS_EKF_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float GPS_INS_EKF_R_data[16] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
static float GPS_INS_EKF_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_GPSINS_EKF GPS_INS_EKF_config = {
  .Q_data = GPS_INS_EKF_Q_data,
  .R_data = GPS_INS_EKF_R_data,
  .x_init = GPS_INS_EKF_x_init,
  .P_init = 10.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  gps_px_sigma = input("gps_px_sigma", 0.5f);
  imu IMU_accel = imu(IMU_ACC, 1.0);
  imu IMU_gyro = imu(IMU_GYR, 1.0);
  imu IMU_mag = imu(IMU_MAG, 1.0);
  encoder Left_wheel_enc = encoder(&Left_wheel_enc_config);
  encoder Right_wheel_enc = encoder(&Right_wheel_enc_config);
  signalSource SIM__landmark_range = signalSource::sine(0.1f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.0f, /*offset=*/ 5.0f);
  signalSource SIM__landmark_bearing = signalSource::sine(0.07f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource SIM__GPS_px = signalSource::sine(0.05f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 2.0f);
  signalSource SIM__GPS_py = signalSource::sine(0.05f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 2.0f, /*offset=*/ 1.0f);
  signalSource SIM__GPS_pz = signalSource::sine(0.02f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.2f);
  signalSource SIM__GPS_speed = signalSource::sine(0.05f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 1.0f);
  expander fan_3 = expander(3);
  expander fan_3_2 = expander(3);
  expander fan_2 = expander(2);
  expander fan_2_2 = expander(2);
  expander fan_3_3 = expander(3);
  expander fan_3_4 = expander(3);
  expander fan_2_3 = expander(2);
  imuBiasEst IMU_bias_est = imuBiasEst(64, 0.001, 0.01);
  robotLocEKF Robot_loc_EKF = robotLocEKF(&Robot_loc_EKF_config);
  wmrEKF WMR_EKF = wmrEKF(&WMR_EKF_config);
  gpsinsEKF GPS_INS_EKF = gpsinsEKF(&GPS_INS_EKF_config);
  node gps_px_resid = node("[1.0 -1.0]", "[1.0]", Sum);
  innovationChi2 Chi2_GPS_gate = innovationChi2(1, 6.63);
  merger unused_bus = merger(27);
  gyro_bias = probe("gyro_bias_x");
  xy_heading = probe("x_y_heading");
  wmr_pose = probe("wheeled_robot");
  fused_pose = probe("fused_position");
  gps_gate = probe("gps_innovation");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  gps_px_sigma > Chi2_GPS_gate.in(1);
  IMU_accel.out(0) > fan_3;
  IMU_accel.out(1) > fan_3_2;
  IMU_accel.out(2) > fan_2;
  IMU_gyro.out(2) > fan_2_2;
  IMU_gyro.out(0) > IMU_bias_est.in(3);
  IMU_gyro.out(1) > IMU_bias_est.in(4);
  IMU_mag.out(0) > WMR_EKF.in(3);
  IMU_mag.out(1) > WMR_EKF.in(4);
  IMU_mag.out(2) > unused_bus.in(0);
  Left_wheel_enc > fan_3_3;
  Right_wheel_enc > fan_3_4;
  SIM__landmark_range > Robot_loc_EKF.in(0);
  SIM__landmark_bearing > Robot_loc_EKF.in(1);
  SIM__GPS_px > fan_2_3;
  SIM__GPS_py > GPS_INS_EKF.in(1);
  SIM__GPS_pz > GPS_INS_EKF.in(2);
  SIM__GPS_speed > GPS_INS_EKF.in(3);
  fan_3.out(0) > IMU_bias_est.in(0);
  fan_3.out(1) > WMR_EKF.in(0);
  fan_3.out(2) > GPS_INS_EKF.in(4);
  fan_3_2.out(0) > IMU_bias_est.in(1);
  fan_3_2.out(1) > WMR_EKF.in(1);
  fan_3_2.out(2) > GPS_INS_EKF.in(5);
  fan_2.out(0) > IMU_bias_est.in(2);
  fan_2.out(1) > GPS_INS_EKF.in(6);
  fan_2_2.out(0) > IMU_bias_est.in(5);
  fan_2_2.out(1) > WMR_EKF.in(2);
  fan_3_3.out(0) > Robot_loc_EKF.in(2);
  fan_3_3.out(1) > WMR_EKF.in(5);
  fan_3_3.out(2) > WMR_EKF.in(7);
  fan_3_4.out(0) > Robot_loc_EKF.in(3);
  fan_3_4.out(1) > WMR_EKF.in(6);
  fan_3_4.out(2) > WMR_EKF.in(8);
  fan_2_3.out(0) > GPS_INS_EKF.in(0);
  fan_2_3.out(1) > gps_px_resid.in(0);
  IMU_bias_est.out(0) > unused_bus.in(1);
  IMU_bias_est.out(1) > unused_bus.in(2);
  IMU_bias_est.out(2) > unused_bus.in(3);
  IMU_bias_est.out(3) > unused_bus.in(9);
  IMU_bias_est.out(4) > unused_bus.in(4);
  IMU_bias_est.out(5) > unused_bus.in(5);
  IMU_bias_est.out(6) > unused_bus.in(6);
  IMU_bias_est.out(7) > unused_bus.in(7);
  IMU_bias_est.out(8) > unused_bus.in(8);
  IMU_bias_est.out(10) > unused_bus.in(10);
  IMU_bias_est.out(11) > unused_bus.in(11);
  IMU_bias_est.out(9) > gyro_bias;
  Robot_loc_EKF.out(1) > unused_bus.in(12);
  Robot_loc_EKF.out(2) > unused_bus.in(13);
  Robot_loc_EKF.out(0) > xy_heading;
  WMR_EKF.out(1) > unused_bus.in(14);
  WMR_EKF.out(2) > unused_bus.in(15);
  WMR_EKF.out(3) > unused_bus.in(16);
  WMR_EKF.out(4) > unused_bus.in(17);
  WMR_EKF.out(5) > unused_bus.in(18);
  WMR_EKF.out(6) > unused_bus.in(19);
  WMR_EKF.out(0) > wmr_pose;
  GPS_INS_EKF.out(0) > gps_px_resid.in(1);
  GPS_INS_EKF.out(1) > unused_bus.in(20);
  GPS_INS_EKF.out(2) > unused_bus.in(21);
  GPS_INS_EKF.out(3) > unused_bus.in(22);
  GPS_INS_EKF.out(4) > unused_bus.in(23);
  GPS_INS_EKF.out(5) > unused_bus.in(24);
  GPS_INS_EKF.out(6) > unused_bus.in(25);
  GPS_INS_EKF.out(0) > fused_pose;
  gps_px_resid > Chi2_GPS_gate.in(0);
  Chi2_GPS_gate.out(0) > unused_bus.in(26);
  Chi2_GPS_gate.out(1) > gps_gate;
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  gps_px_sigma.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    gyro_bias.show();
    xy_heading.show();
    wmr_pose.show();
    fused_pose.show();
    gps_gate.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}