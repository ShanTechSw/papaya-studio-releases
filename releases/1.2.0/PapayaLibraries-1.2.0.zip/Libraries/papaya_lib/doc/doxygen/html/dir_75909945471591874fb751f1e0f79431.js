var dir_75909945471591874fb751f1e0f79431 =
[
    [ "Arduino.cpp", "host__arduino__compat_2src_2_arduino_8cpp.html", "host__arduino__compat_2src_2_arduino_8cpp" ],
    [ "SPI.cpp", "host__arduino__compat_2src_2_s_p_i_8cpp.html", "host__arduino__compat_2src_2_s_p_i_8cpp" ]
];