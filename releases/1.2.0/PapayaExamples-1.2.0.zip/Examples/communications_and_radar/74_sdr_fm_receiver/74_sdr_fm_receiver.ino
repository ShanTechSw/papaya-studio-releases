/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe discriminator;
probe demodulated_aud;

input const_;
input noise_seed_I;
input epsilon;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  noise_seed_I = input("noise_seed_I", 0.0f);
  epsilon = input("epsilon", 1e-06f);
  signalSource SIM__audio_message = signalSource::multisine(100.0f, 50.0f, 4, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.8f);
  const_ = input("const", 0.0f);
  noise SIM__channel_noise = noise(0.0, 0.02, gaussian);
  gain frequency_deviation = gain(5026.548245743669);
  noise SIM__channel_noise_I = noise(0.0, 0.02, gaussian);
  integrator FM_phase = integrator();
  expander fan_phase = expander(2);
  sineFunc Q_baseband = sineFunc();
  cosineFunc I_baseband = cosineFunc();
  node Q___noise = node("[1.0 1.0]", "[1.0]", Sum);
  node I___noise = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_I = expander(3);
  expander fan_Q = expander(3);
  sqrMath I_squared = sqrMath();
  sqrMath Q_squared = sqrMath();
  derivative dI_dt = derivative(0.0002);
  derivative dQ_dt = derivative(0.0002);
  node I_x_dQ = node("[1.0 1.0]", "[1.0]", Mul);
  node Q_x_dI = node("[1.0 1.0]", "[1.0]", Mul);
  node I2___Q2 = node("[1.0 1.0]", "[1.0]", Sum);
  node numerator = node("[1.0 -1.0]", "[1.0]", Sum);
  node guarded_magnitude = node("[1.0 1.0]", "[1.0]", Sum);
  inverse reciprocal = inverse();
  node discriminator_2 = node("[1.0 1.0]", "[1.0]", Mul);
  gain audio_scale = gain(0.00019894367886486917);
  butter de_emphasis = butter(1, 2122.0, passLow);
  discriminator = probe("discriminator");
  demodulated_aud = probe("demodulated_aud");

  /* Connect Blocks */
  noise_seed_I > SIM__channel_noise_I;
  epsilon > guarded_magnitude.in(1);
  SIM__audio_message > frequency_deviation;
  const_ > SIM__channel_noise;
  SIM__channel_noise > Q___noise.in(1);
  frequency_deviation > FM_phase;
  SIM__channel_noise_I > I___noise.in(1);
  FM_phase > fan_phase;
  fan_phase.out(0) > Q_baseband;
  fan_phase.out(1) > I_baseband;
  Q_baseband > Q___noise.in(0);
  I_baseband > I___noise.in(0);
  Q___noise > fan_Q;
  I___noise > fan_I;
  fan_I.out(2) > I_squared;
  fan_I.out(0) > dI_dt;
  fan_I.out(1) > I_x_dQ.in(0);
  fan_Q.out(2) > Q_squared;
  fan_Q.out(0) > dQ_dt;
  fan_Q.out(1) > Q_x_dI.in(0);
  I_squared > I2___Q2.in(0);
  Q_squared > I2___Q2.in(1);
  dI_dt > Q_x_dI.in(1);
  dQ_dt > I_x_dQ.in(1);
  I_x_dQ > numerator.in(0);
  Q_x_dI > numerator.in(1);
  I2___Q2 > guarded_magnitude.in(0);
  numerator > discriminator_2.in(0);
  guarded_magnitude > reciprocal;
  reciprocal > discriminator_2.in(1);
  discriminator_2 > audio_scale;
  discriminator_2 > discriminator;
  audio_scale > de_emphasis;
  de_emphasis > demodulated_aud;

  /* Enable Remote Input Control */
  noise_seed_I.enableRemote();
  epsilon.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    discriminator.show();
    demodulated_aud.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}