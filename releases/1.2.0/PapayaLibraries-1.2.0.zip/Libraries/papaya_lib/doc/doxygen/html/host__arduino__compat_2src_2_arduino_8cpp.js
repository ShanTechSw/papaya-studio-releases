var host__arduino__compat_2src_2_arduino_8cpp =
[
    [ "delay", "host__arduino__compat_2src_2_arduino_8cpp.html#a6bc5f943544a887f8b23cadfb26a5e30", null ],
    [ "delayMicroseconds", "host__arduino__compat_2src_2_arduino_8cpp.html#a62e0a53bc261f9de8700cc5a92307e85", null ],
    [ "digitalWrite", "host__arduino__compat_2src_2_arduino_8cpp.html#ae9647a9a056bb33fd1206da70c83bde3", null ],
    [ "millis", "host__arduino__compat_2src_2_arduino_8cpp.html#a6ff7f2532a22366f0013bc41397129fd", null ],
    [ "pinMode", "host__arduino__compat_2src_2_arduino_8cpp.html#ac7bdb53335528ad073ca13eb2b1bdc00", null ],
    [ "registerDigitalWriteHandler", "host__arduino__compat_2src_2_arduino_8cpp.html#a8b437eef8737447653d823ae48c5af6f", null ],
    [ "registerPinModeHandler", "host__arduino__compat_2src_2_arduino_8cpp.html#a2cfb4fc82d03e32047564095ed88a110", null ],
    [ "Serial", "host__arduino__compat_2src_2_arduino_8cpp.html#a67e14daf2286fd0b0f84ad20ac2b5e17", null ]
];