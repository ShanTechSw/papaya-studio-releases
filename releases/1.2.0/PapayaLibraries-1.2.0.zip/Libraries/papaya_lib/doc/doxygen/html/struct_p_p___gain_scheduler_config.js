var struct_p_p___gain_scheduler_config =
[
    [ "breakpoints", "struct_p_p___gain_scheduler_config.html#a881d5e769c1cfea83c153dc66857c75c", null ],
    [ "num_outputs", "struct_p_p___gain_scheduler_config.html#a2113777d7ceb9748d129546d76b1be92", null ],
    [ "num_points", "struct_p_p___gain_scheduler_config.html#a0e0fee6359cab9aed0cbb04e7aed385c", null ],
    [ "values", "struct_p_p___gain_scheduler_config.html#a78c1b06eece40a2dc29e9a8823f64253", null ]
];