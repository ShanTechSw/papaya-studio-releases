"""Multi-sensor health: which sensor saw it, and what that means.

Run this beside example 95.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

Each fault has its own sensor and its own indicator, and the script asks
them in the order that keeps them from being confused with each other:

  electrical      the magnetometer's bar ratio and the gyroscope's slip
                  beat, which agree with each other and with nothing else.
                  Asked first because an electrical fault is the one the
                  accelerometer cannot see at all, so it has to be ruled
                  out before a quiet accelerometer is taken as good news.

  bearing         the ball-pass line in the accelerometer's envelope, plus
                  the crest factor. A bearing raises the peak long before
                  it raises the level.

  unbalance       the shaft line, once the two above are ruled out.

  and the point   every indicator is printed every time, so which sensor
                  was silent is as visible as which one spoke.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "imbalance", "electrical", "bearing")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "health"
FEATURES = ("one_x", "e_bpfo", "a_rms", "crest", "e_slip", "g_rms",
            "e_supply", "bar_ratio", "state")

BASE_1X = 0.0142            # g, the healthy shaft line
BASE_BPFO = 0.00022         # g, the healthy ball-pass line
BASE_SLIP = 0.0011          # rad/s, the healthy slip beat
SUPPLY_PRESENT = 1.0        # uT

UNBALANCE = 2.5             # multiple of the healthy shaft line
BEARING = 8.0               # multiple of the healthy ball-pass line
CREST_IMPACT = 3.0
ELECTRICAL_BAR = 0.018      # bar ratio
ELECTRICAL_SLIP = 5.0       # multiple of the healthy slip beat

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def classify(row):
    one_x = row["one_x"] / max(BASE_1X, 1e-12)
    bpfo = row["e_bpfo"] / max(BASE_BPFO, 1e-12)
    slip = row["e_slip"] / max(BASE_SLIP, 1e-12)
    reasons = [
        f"accelerometer: shaft line {one_x:.2f}x, ball-pass line "
        f"{bpfo:.2f}x, crest {row['crest']:.2f}, level "
        f"{row['a_rms']:.4f} g",
        f"gyroscope:     slip beat {slip:.2f}x, torsional level "
        f"{row['g_rms']:.4f} rad/s",
        f"magnetometer:  supply {row['e_supply']:.3f} uT, bar ratio "
        f"{row['bar_ratio']:.4f}",
    ]

    energised = row["e_supply"] >= SUPPLY_PRESENT
    if not energised:
        reasons.append("no supply line in the field, so the bar ratio "
                       "means nothing")

    # Electrical first, because it is the one a quiet accelerometer hides.
    # BOTH indicators, not either. They are measured by different sensors
    # and they settle at different speeds, so after an electrical fault
    # ends the slower of the two is still decaying while the other has
    # recovered: on this record the bearing condition follows the
    # electrical one and its slip beat is still nine times the healthy
    # value. One indicator alone called that bearing an electrical fault.
    if energised and (row["bar_ratio"] >= ELECTRICAL_BAR
                      and slip >= ELECTRICAL_SLIP):
        reasons.append("the magnetometer and the gyroscope agree, which is "
                       "what makes this a finding rather than a suspicion")
        reasons.append(
            f"and the accelerometer level is {row['a_rms']:.4f} g, which "
            f"is what a healthy machine looks like to it")
        return ("electrical",
                "an electrical fault: a rotor bar, or something else that "
                "makes the torque uneven", reasons)

    if bpfo >= BEARING or row["crest"] >= CREST_IMPACT:
        reasons.append(
            f"the ball-pass line is {bpfo:.1f}x its healthy value and the "
            f"crest factor is {row['crest']:.2f}: impacts, at the rate a "
            f"ball passes a defect")
        return ("bearing", "a rolling-element defect", reasons)

    if one_x >= UNBALANCE:
        reasons.append(
            "everything at one times shaft speed, with no impacts and "
            "nothing electrical")
        return ("imbalance", "unbalance", reasons)

    return ("healthy", "all three sensors quiet", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 95_multisensor_machine_health.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA multi-sensor machine-health monitor")
    print("=" * 72)
    print("Three sensors, four faults, and no single sensor that sees all "
          "of them.")
    print("  accelerometer  unbalance and bearings, nearly blind to "
          "electrical faults")
    print("  gyroscope      torque ripple, which the accelerometer "
          "under-reads")
    print("  magnetometer   electrical faults, and nothing else at all")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
