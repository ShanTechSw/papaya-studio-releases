/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 8000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe window_frames;
probe Frames_tap;
VectorProbe stft_frames;
probe Overlapped_frames_tap;
VectorProbe hann_magnitude;
probe Magnitude_tap;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(8000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(505.0f, 0.0f);
  expander fan_3 = expander(3);
  fft_HannWindow Transform = fft_HannWindow(256);
  windowFramer Frames = windowFramer(256, 128);
  stftFramer Overlapped_frames = stftFramer(256, 128, 0);
  fftMagResolver Magnitude = fftMagResolver(Transform);
  window_frames = VectorProbe("window_frames");
  Frames_tap = probe("Frames_o0");
  stft_frames = VectorProbe("stft_frames");
  Overlapped_frames_tap = probe("Overlapped_0");
  hann_magnitude = VectorProbe("hann_magnitude");
  Magnitude_tap = probe("Magnitude_o0");

  /* Connect Blocks */
  Source > fan_3;
  fan_3.out(0) > Transform;
  fan_3.out(1) > Frames;
  fan_3.out(2) > Overlapped_frames;
  Transform > Magnitude;
  Frames >> window_frames;
  Frames > Frames_tap;
  Overlapped_frames >> stft_frames;
  Overlapped_frames > Overlapped_frames_tap;
  Magnitude >> hann_magnitude;
  Magnitude > Magnitude_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    window_frames.show();
    Frames_tap.show();
    stft_frames.show();
    Overlapped_frames_tap.show();
    hann_magnitude.show();
    Magnitude_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}