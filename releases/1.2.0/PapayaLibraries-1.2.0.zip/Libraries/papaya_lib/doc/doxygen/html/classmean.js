var classmean =
[
    [ "mean", "classmean.html#add8acfd91c07b10dacbd690a3456c42c", null ]
];