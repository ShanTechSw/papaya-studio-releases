var struct_p_p___a_c_i_m___e_k_f =
[
    [ "Lm", "struct_p_p___a_c_i_m___e_k_f.html#af37032dbb52673f9f3cc7d73c9bfdf09", null ],
    [ "Lr", "struct_p_p___a_c_i_m___e_k_f.html#ade120ef3202cce18630c1be4c6ac6d60", null ],
    [ "Ls", "struct_p_p___a_c_i_m___e_k_f.html#adeff463e89c697c2c715e373c4667e2a", null ],
    [ "P_init", "struct_p_p___a_c_i_m___e_k_f.html#ac5284f81d8ba5b39d69aef83296c9a07", null ],
    [ "P_pairs", "struct_p_p___a_c_i_m___e_k_f.html#aee0a4fd58622dab3c33590c8d277e43e", null ],
    [ "Q_data", "struct_p_p___a_c_i_m___e_k_f.html#a2b27e444c691727bf04d01563e8fc7ea", null ],
    [ "R_data", "struct_p_p___a_c_i_m___e_k_f.html#abbdd90d3b66b9d4c1734cef69998ae45", null ],
    [ "Rr", "struct_p_p___a_c_i_m___e_k_f.html#aca81644ad5a813808e17156545d231dd", null ],
    [ "Rs", "struct_p_p___a_c_i_m___e_k_f.html#ad43fa9f4da52ef673dbf6e9e5d93a10b", null ],
    [ "x_init", "struct_p_p___a_c_i_m___e_k_f.html#a002e25b32a0b364cbaec7a45101ef4b6", null ]
];