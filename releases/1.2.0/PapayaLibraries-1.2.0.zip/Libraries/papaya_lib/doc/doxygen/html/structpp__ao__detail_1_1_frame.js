var structpp__ao__detail_1_1_frame =
[
    [ "header", "structpp__ao__detail_1_1_frame.html#a213f4fa382a3ce6e2b2fdbe0387818c6", null ],
    [ "pf", "structpp__ao__detail_1_1_frame.html#a8bac2eb12c6687f61056a1029002cd88", null ],
    [ "pu16", "structpp__ao__detail_1_1_frame.html#a11bcdcbae8e119db9a58365365083f7c", null ],
    [ "pu32", "structpp__ao__detail_1_1_frame.html#acf919b947f668d983d118388eb2844ca", null ],
    [ "pu8", "structpp__ao__detail_1_1_frame.html#a0e5b508d0dcc6577d9496ae400a5a66e", null ],
    [ "buf", "structpp__ao__detail_1_1_frame.html#aee052faea17e5187dc9f1b2a4561271c", null ]
];