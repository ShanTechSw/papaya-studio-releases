var struct_p_p__adaptive_k_f =
[
    [ "alpha", "struct_p_p__adaptive_k_f.html#acaa249cd2534e510c7397de8c86c5304", null ],
    [ "B_data", "struct_p_p__adaptive_k_f.html#a8902f0fa0f691b5fcd03007dd896cd96", null ],
    [ "dim_u", "struct_p_p__adaptive_k_f.html#afb617613d687fd9ecaa6a110c31e2bb6", null ],
    [ "dim_x", "struct_p_p__adaptive_k_f.html#a488d1396c5d02caf3db59fd435a89282", null ],
    [ "dim_z", "struct_p_p__adaptive_k_f.html#af79e1d1daa36c672c46b2d1817c32c14", null ],
    [ "F_data", "struct_p_p__adaptive_k_f.html#aa089807e8471ef7976e071b722318db5", null ],
    [ "H_data", "struct_p_p__adaptive_k_f.html#a23a9b740d2ddc8b14dda883aaa10636a", null ],
    [ "P_init", "struct_p_p__adaptive_k_f.html#ac10ee194a588f2f5620c66d9a94c7a87", null ],
    [ "Q_data", "struct_p_p__adaptive_k_f.html#acb08e499770bede69fb9a4422d6881ac", null ],
    [ "R_init", "struct_p_p__adaptive_k_f.html#aeeba0711af41bd42222912e95b4522a1", null ],
    [ "x_init", "struct_p_p__adaptive_k_f.html#ad180ada75bc9f0e59e1bf1b0411df8b7", null ]
];