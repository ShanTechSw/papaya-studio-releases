/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe clean_rms;
VectorProbe soft_coeffs;
VectorProbe hard_coeffs;
probe soft_sigma;
probe hard_sigma;
VectorProbe subband_energy_2;
probe subband_energy_tap;
VectorProbe reconstructed;

input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__clean_signal = signalSource::chirpLinear(5.0f, 300.0f, 4.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  const_ = input("const", 0.0f);
  noise SIM__additive_noise = noise(-0.5, 0.5, uniform);
  expander fan_2 = expander(2);
  node noisy_signal = node("[1.0 1.0]", "[1.0]", Sum);
  rootMeanSquare clean_RMS = rootMeanSquare(200);
  expander fan_4 = expander(4);
  dwt DWT__soft_path_ = dwt(256, DB4, 5, 2000.0);
  dwt DWT__hard_path_ = dwt(256, DB4, 5, 2000.0);
  dwt DWT__best_basis_ = dwt(256, SYM8, 4, 2000.0);
  dwt DWT__round_trip_ = dwt(256, DB4, 5, 2000.0);
  dwt_denoise soft_threshold = dwt_denoise(DWT__soft_path_, PP_THRESH_SOFT, 1.0f);
  dwt_denoise hard_threshold = dwt_denoise(DWT__hard_path_, PP_THRESH_HARD, 1.0f);
  dwt_subband_energy subband_energy = dwt_subband_energy(DWT__best_basis_);
  idwt perfect_reconstruction = idwt(DWT__round_trip_);
  clean_rms = probe("clean_rms");
  soft_coeffs = VectorProbe("soft_coeffs");
  hard_coeffs = VectorProbe("hard_coeffs");
  soft_sigma = probe("soft_sigma");
  hard_sigma = probe("hard_sigma");
  subband_energy_2 = VectorProbe("subband_energy");
  subband_energy_tap = probe("subband energ_0");
  reconstructed = VectorProbe("reconstructed");

  /* Connect Blocks */
  SIM__clean_signal > fan_2;
  const_ > SIM__additive_noise;
  SIM__additive_noise > noisy_signal.in(1);
  fan_2.out(0) > noisy_signal.in(0);
  fan_2.out(1) > clean_RMS;
  noisy_signal > fan_4;
  clean_RMS > clean_rms;
  fan_4.out(0) > DWT__soft_path_;
  fan_4.out(1) > DWT__hard_path_;
  fan_4.out(2) > DWT__best_basis_;
  fan_4.out(3) > DWT__round_trip_;
  DWT__soft_path_ > soft_threshold;
  DWT__soft_path_ >> soft_coeffs;
  DWT__hard_path_ > hard_threshold;
  DWT__hard_path_ >> hard_coeffs;
  DWT__best_basis_ > subband_energy;
  DWT__round_trip_ > perfect_reconstruction;
  soft_threshold > soft_sigma;
  hard_threshold > hard_sigma;
  subband_energy >> subband_energy_2;
  subband_energy > subband_energy_tap;
  perfect_reconstruction >> reconstructed;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    clean_rms.show();
    soft_coeffs.show();
    hard_coeffs.show();
    soft_sigma.show();
    hard_sigma.show();
    subband_energy_2.show();
    subband_energy_tap.show();
    reconstructed.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}