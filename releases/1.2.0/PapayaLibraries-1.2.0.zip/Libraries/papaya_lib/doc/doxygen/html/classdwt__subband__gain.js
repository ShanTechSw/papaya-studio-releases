var classdwt__subband__gain =
[
    [ "dwt_subband_gain", "classdwt__subband__gain.html#a98a0e19362937fc9bd3459406258e2f9", null ],
    [ "getAssociatedDWT", "classdwt__subband__gain.html#a59bb9eebb4579babb89c4156fa70c7f8", null ],
    [ "operator>", "classdwt__subband__gain.html#a2990572e74b70a93256953556b76ff93", null ],
    [ "operator>", "classdwt__subband__gain.html#abb14ac7010a031674ce24e9681d26b23", null ],
    [ "operator>", "classdwt__subband__gain.html#a20f8551889d8ff70964c5abff907d7e0", null ],
    [ "operator>", "classdwt__subband__gain.html#ac3ab68e27a8b34fe996929eb79fed2e8", null ],
    [ "setGainsLive", "classdwt__subband__gain.html#aa1e58c645c50fa210ae5d5750ed0765d", null ],
    [ "associatedDWT", "classdwt__subband__gain.html#a1d05ae0260e20229eda01a3cc0e0caa3", null ]
];