var struct_p_p__pwm_out_cfg =
[
    [ "dutyLowerLimit", "struct_p_p__pwm_out_cfg.html#a145111e81071980d3c39e0c4ca33ea88", null ],
    [ "dutyUpperLimit", "struct_p_p__pwm_out_cfg.html#a5a6f49d9b71f274e61065cca4dcc1e40", null ],
    [ "frequency", "struct_p_p__pwm_out_cfg.html#a0df4fe75773b21e5f55fdf0e788b591e", null ],
    [ "id", "struct_p_p__pwm_out_cfg.html#a74fa40ae77306a7f626e139154a58f42", null ]
];