/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:40:01
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe butterworth_sos;
probe chebyshev1_sos;
probe chebyshev2_sos;
probe elliptic_sos;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::chirpLinear(5.0f, 400.0f, 4.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  expander fan_4 = expander(4);
  butterBq Butterworth_SOS = butterBq(6, 100.0, passLow);
  cheby1Bq Chebyshev_I_SOS = cheby1Bq(6, 100.0, passLow, Cheby1Cfg1);
  cheby2Bq Chebyshev_II_SOS = cheby2Bq(6, 100.0, passLow, Cheby2Cfg1);
  ellipBq Elliptic_SOS = ellipBq(6, 100.0, passLow, EllipCfg1);
  butterworth_sos = probe("butterworth_sos");
  chebyshev1_sos = probe("chebyshev1_sos");
  chebyshev2_sos = probe("chebyshev2_sos");
  elliptic_sos = probe("elliptic_sos");

  /* Connect Blocks */
  Source > fan_4;
  fan_4.out(0) > Butterworth_SOS;
  fan_4.out(1) > Chebyshev_I_SOS;
  fan_4.out(2) > Chebyshev_II_SOS;
  fan_4.out(3) > Elliptic_SOS;
  Butterworth_SOS > butterworth_sos;
  Chebyshev_I_SOS > chebyshev1_sos;
  Chebyshev_II_SOS > chebyshev2_sos;
  Elliptic_SOS > elliptic_sos;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    butterworth_sos.show();
    chebyshev1_sos.show();
    chebyshev2_sos.show();
    elliptic_sos.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}