/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe suppressed_out;
probe tracked_howl_hz;
probe fixed_notch_out;
VectorProbe howl_spectrum;
probe spectrum_tap;

input agc_pass;
input howl_thr;
input gain_cut_trigge;

/* Global Struct Declarations */
// Configuration for adaptive_howl_notch
PP_AdaptiveNotchConfig adaptive_howl_notch_config = {
  .init_freq = 180.0f,
  .Q_factor = 10.0f,
  .mu = 0.01f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  agc_pass = input("pass_level", 1.0f);
  howl_thr = input("howl_thr", 2.5f);
  gain_cut_trigge = input("gain_cut_trigge", 0.0f);
  signalSource SIM__stage_mic = signalSource::multisine(100.0f, 50.0f, 5, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  comp gain_cut_trigger = comp();
  node managed_gain = node("[1.0 1.0]", "[1.0]", Mul);
  expander fan_managed = expander(3);
  gain PA_volume = gain(0.9);
  node stage___return = node("[1.0 1.0]", "[1.0]", Sum);
  combFeedBack SIM__room_feedback = combFeedBack(240, 0.95);
  expander fan_3 = expander(3);
  adaptiveNotch adaptive_howl_notch = adaptiveNotch(&adaptive_howl_notch_config);
  expander fan_2 = expander(1);
  envFollower loudness_envelope = envFollower(0.005, 0.05);
  notch fixed_notch__compare_ = notch(200.0, 10.0);
  fft howl_detector_FFT = fft(512);
  fftMagResolver spectrum = fftMagResolver(howl_detector_FFT);
  suppressed_out = probe("suppressed_outp");
  tracked_howl_hz = probe("tracked_howl_Hz");
  fixed_notch_out = probe("fixed_notch_out");
  howl_spectrum = VectorProbe("howl_spectrum");
  spectrum_tap = probe("spectrum_o0");

  /* Connect Blocks */
  agc_pass > gain_cut_trigger.in(1);
  howl_thr > gain_cut_trigger.in(3);
  gain_cut_trigge > gain_cut_trigger.in(0);
  SIM__stage_mic > stage___return.in(0);
  gain_cut_trigger > managed_gain.in(1);
  managed_gain > fan_managed;
  fan_managed.out(0) > PA_volume;
  fan_managed.out(1) > loudness_envelope;
  fan_managed.out(2) > suppressed_out;
  PA_volume > stage___return.in(1);
  stage___return > SIM__room_feedback;
  SIM__room_feedback > fan_3;
  fan_3.out(0) > adaptive_howl_notch;
  fan_3.out(1) > fixed_notch__compare_;
  fan_3.out(2) > howl_detector_FFT;
  adaptive_howl_notch.out(0) > fan_2;
  adaptive_howl_notch.out(1) > tracked_howl_hz;
  fan_2 > managed_gain.in(0);
  loudness_envelope > gain_cut_trigger.in(2);
  fixed_notch__compare_ > fixed_notch_out;
  howl_detector_FFT > spectrum;
  spectrum >> howl_spectrum;
  spectrum > spectrum_tap;

  /* Enable Remote Input Control */
  agc_pass.enableRemote();
  howl_thr.enableRemote();
  gain_cut_trigge.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    suppressed_out.show();
    tracked_howl_hz.show();
    fixed_notch_out.show();
    howl_spectrum.show();
    spectrum_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}