var struct_p_p___battery_s_o_c___e_k_f =
[
    [ "C1", "struct_p_p___battery_s_o_c___e_k_f.html#a491d412c6e37e9594cfa6d44ea11a171", null ],
    [ "ocv_coef", "struct_p_p___battery_s_o_c___e_k_f.html#a1b6f2c9e57b693c9b31c6f695a411c53", null ],
    [ "P_init", "struct_p_p___battery_s_o_c___e_k_f.html#a7eb11ed901b96704b16634f7b0bb6df0", null ],
    [ "Q_cap", "struct_p_p___battery_s_o_c___e_k_f.html#a8654abc19d9f49a5315708e9121b7287", null ],
    [ "Q_data", "struct_p_p___battery_s_o_c___e_k_f.html#abb800f025153438c64bac55ed11758a6", null ],
    [ "R0", "struct_p_p___battery_s_o_c___e_k_f.html#aaba4513bffaa7a6b709e77826941b681", null ],
    [ "R1", "struct_p_p___battery_s_o_c___e_k_f.html#ad58e010e0043f12ebfdc28b9dbdad9cb", null ],
    [ "R_data", "struct_p_p___battery_s_o_c___e_k_f.html#a9456240b796f537fdad4921f9e67416f", null ],
    [ "x_init", "struct_p_p___battery_s_o_c___e_k_f.html#a8ce00bd4c153cd44e812c9b5bc1563ca", null ]
];