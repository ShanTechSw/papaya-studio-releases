var classadaptive_notch =
[
    [ "adaptiveNotch", "classadaptive_notch.html#af599802069562d013521b955ec2fd677", null ]
];