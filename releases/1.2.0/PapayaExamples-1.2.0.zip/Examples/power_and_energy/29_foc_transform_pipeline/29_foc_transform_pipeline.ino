/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Phase currents     phase A of a balanced three-phase set: a 2 A sine at 100
 *                         Hz. It is 100 Hz and not 50 because the theta sawtooth
 *                         spans two full turns per 50 Hz period, so the electrical
 *                         angle rotates at 100 Hz, and the currents must rotate
 *                         with it
 *      Phase currents B   phase B of the same set, 120 degrees behind phase A. With
 *                         both playing, the rotating frame sees pure torque
 *                         current: Id reads close to 0 A and Iq close to 2 A, the
 *                         field-oriented control signature
 *      Inverter refs      nothing to play: its model is a probe named
 *                         Inverter_refs_voltage that records the phase A voltage
 *                         reference the design produces, a 1 V sine at 100 Hz for
 *                         the default Vd = 0, Vq = 1
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe Id;
probe Iq;
probe Inv_Clarke_tap;

input Vd_ref;
input Vq_ref;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  Vd_ref = input("Vd_ref", 0.0f);
  Vq_ref = input("Vq_ref", 1.0f);
  analogIn Phase_currents = analogIn(AIN1, 1.0, 0.0);
  signalSource theta = signalSource::sawtooth(50.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 6.283f);
  analogIn Phase_currents_B = analogIn(AIN2, 1.0, 0.0);
  clarke Clarke = clarke();
  expander fan_2 = expander(2);
  park Park = park();
  invPark Inv_Park = invPark();
  invClarke Inv_Clarke = invClarke();
  analogOut Inverter_refs = analogOut(AO1, -9.0, 9.0);
  Id = probe("Id");
  Iq = probe("Iq");
  Inv_Clarke_tap = probe("Inv Clarke_o1");

  /* Connect Blocks */
  Vd_ref > Inv_Park.in(0);
  Vq_ref > Inv_Park.in(1);
  Phase_currents > Clarke.in(0);
  theta > fan_2;
  Phase_currents_B > Clarke.in(1);
  Clarke.out(0) > Park.in(0);
  Clarke.out(1) > Park.in(1);
  fan_2.out(0) > Park.in(2);
  fan_2.out(1) > Inv_Park.in(2);
  Park.out(0) > Id;
  Park.out(1) > Iq;
  Inv_Park.out(0) > Inv_Clarke.in(0);
  Inv_Park.out(1) > Inv_Clarke.in(1);
  Inv_Clarke.out(0) > Inverter_refs;
  Inv_Clarke.out(1) > Inv_Clarke_tap;

  /* Enable Remote Input Control */
  Vd_ref.enableRemote();
  Vq_ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    Id.show();
    Iq.show();
    Inv_Clarke_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}