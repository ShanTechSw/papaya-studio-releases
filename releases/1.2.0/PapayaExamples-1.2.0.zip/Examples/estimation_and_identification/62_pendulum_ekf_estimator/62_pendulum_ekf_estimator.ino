/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe true_state;
probe amplitude_estim;
probe frequency_estim;
probe kf_estimate;
probe linear_KF_tap;
probe sine_tracking_EKF_tap;
probe tracking_error;
probe innovation;
probe outlier_flag;

input const_;
input adc_step;
input const__2;
input innov_sigma;

/* Global Struct Declarations */
// Configuration for SIM__pendulum_plant
static float SIM__pendulum_plant_A_data[4] = {0.0f, 1.0f, -0.99937187882f, 1.99933241293f};
static float SIM__pendulum_plant_B_data[2] = {0.0f, 1.0f};
static float SIM__pendulum_plant_C_data[2] = {3.94658878531e-05f, 0.0f};
static float SIM__pendulum_plant_D_data[1] = {0.0f};
static float SIM__pendulum_plant_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__pendulum_plant_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__pendulum_plant_A_data,
  .B_data = SIM__pendulum_plant_B_data,
  .C_data = SIM__pendulum_plant_C_data,
  .D_data = SIM__pendulum_plant_D_data,
  .x_init = SIM__pendulum_plant_x_init
};

// Configuration for sine_tracking_EKF
static float sine_tracking_EKF_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float sine_tracking_EKF_R_data[1] = {0.1f};
static float sine_tracking_EKF_x_init[3] = {1.0f, 314.159265359f, 0.0f};
PP_SinTrack_EKF sine_tracking_EKF_config = {
  .Q_data = sine_tracking_EKF_Q_data,
  .R_data = sine_tracking_EKF_R_data,
  .x_init = sine_tracking_EKF_x_init,
  .P_init = 1.0f
};

// linear_KF: PP_linearKF config
float linear_KF_F[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float linear_KF_B[2] = {0.0f, 0.0f};
float linear_KF_H[2] = {1.0f, 0.0f};
float linear_KF_Q[4] = {0.0001f, 0.0f, 0.0f, 0.0001f};
float linear_KF_R = 0.1f;
float linear_KF_x[2] = {0.0f, 0.0f};
float linear_KF_P = 1.0f;
PP_linearKF linear_KF_config = {
  2, 1, 1,
  linear_KF_x, linear_KF_F, linear_KF_H, linear_KF_Q, linear_KF_B,
  linear_KF_R, linear_KF_P
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  adc_step = input("adc_step", 0.00048828125f);
  innov_sigma = input("innov_sigma", 0.3f);
  signalSource SIM__excitation = signalSource::chirpLinear(0.2f, 8.0f, 8.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  stateSpace SIM__pendulum_plant = stateSpace(&SIM__pendulum_plant_config);
  noise SIM__sensor_noise = noise(-0.5, 0.5, uniform);
  expander fan_2 = expander(2);
  node noisy_measurement = node("[1.0 1.0]", "[1.0]", Sum);
  quantizer converter_quantiser = quantizer();
  expander fan_3 = expander(3);
  sinTrackEKF sine_tracking_EKF = sinTrackEKF(&sine_tracking_EKF_config);
  linearKF linear_KF = linearKF(&linear_KF_config);
  expander fan_2_2 = expander(2);
  expander phase_fan = expander(2);
  node estimation_error = node("[1.0 -1.0]", "[1.0]", Sum);
  sineFunc sin_phase_ = sineFunc();
  node predicted_measurement = node("[1.0 1.0]", "[1.0]", Mul);
  node innovation_2 = node("[1.0 -1.0]", "[1.0]", Sum);
  innovationChi2 chi_square_gate = innovationChi2(1, 6.63);
  true_state = probe("true_state");
  amplitude_estim = probe("amplitude_estim");
  frequency_estim = probe("frequency_estim");
  kf_estimate = probe("kf_state_estima");
  linear_KF_tap = probe("linear KF_o1");
  sine_tracking_EKF_tap = probe("sine-tracking_2");
  tracking_error = probe("tracking_error");
  innovation = probe("innovation");
  outlier_flag = probe("outlier_flag");

  /* Connect Blocks */
  adc_step > converter_quantiser.in(1);
  innov_sigma > chi_square_gate.in(1);
  SIM__excitation > SIM__pendulum_plant;
  const_ > SIM__sensor_noise;
  const__2 > linear_KF.in(1);
  SIM__pendulum_plant > fan_2;
  SIM__pendulum_plant > true_state;
  SIM__sensor_noise > noisy_measurement.in(1);
  fan_2.out(0) > noisy_measurement.in(0);
  fan_2.out(1) > estimation_error.in(0);
  noisy_measurement > converter_quantiser.in(0);
  converter_quantiser > fan_3;
  fan_3.out(0) > sine_tracking_EKF;
  fan_3.out(1) > linear_KF.in(0);
  fan_3.out(2) > innovation_2.in(0);
  sine_tracking_EKF.out(0) > fan_2_2;
  sine_tracking_EKF.out(2) > phase_fan;
  sine_tracking_EKF.out(0) > amplitude_estim;
  sine_tracking_EKF.out(1) > frequency_estim;
  linear_KF.out(0) > kf_estimate;
  linear_KF.out(1) > linear_KF_tap;
  fan_2_2.out(1) > estimation_error.in(1);
  fan_2_2.out(0) > predicted_measurement.in(1);
  phase_fan.out(1) > sin_phase_;
  phase_fan.out(0) > sine_tracking_EKF_tap;
  estimation_error > tracking_error;
  sin_phase_ > predicted_measurement.in(0);
  predicted_measurement > innovation_2.in(1);
  innovation_2 > chi_square_gate.in(0);
  chi_square_gate.out(0) > innovation;
  chi_square_gate.out(1) > outlier_flag;

  /* Enable Remote Input Control */
  adc_step.enableRemote();
  innov_sigma.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    true_state.show();
    amplitude_estim.show();
    frequency_estim.show();
    kf_estimate.show();
    linear_KF_tap.show();
    sine_tracking_EKF_tap.show();
    tracking_error.show();
    innovation.show();
    outlier_flag.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}