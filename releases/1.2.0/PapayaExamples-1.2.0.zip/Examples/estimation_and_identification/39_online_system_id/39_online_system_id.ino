/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:10
 *  Fs (Hz)      : 150.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe theta_rls;
probe pred_err;
probe RLS_order_2_tap;
VectorProbe theta_rrls;
probe RRLS_sensitivity_0_99_tap;
probe RRLS_sensitivity_0_99_tap_2;

/* Global Struct Declarations */
// Configuration for RLS_order_2
// Order 2: num is {b0..b2}, denom is {1, a1..a2}, both 3 long
float RLS_order_2_num[3]   = {0.0f, 0.0f, 0.0f};   // no prior model
float RLS_order_2_denom[3] = {1.0f, 0.0f, 0.0f};   // monic, leading 1

// Covariance and system order
PP_RLSParam RLS_order_2_config = {RLS_order_2_num, 3, RLS_order_2_denom, 3, 1.0f, 2, 1};
// Replace num and denom with a starting model if you have one; the denominator's leading coefficient must not be zero.

// Configuration for RRLS_sensitivity_0_99
// denom is {1, a1..a2}, num is {b0..b2}
float RRLS_sensitivity_0_99_num[3]   = {0.0f, 0.0f, 0.0f};
float RRLS_sensitivity_0_99_denom[3] = {1.0f, 0.0f, 0.0f};
PP_RRLSParam RRLS_sensitivity_0_99_config = {RRLS_sensitivity_0_99_num, 3, RRLS_sensitivity_0_99_denom, 3, 1.0f, 2, 0.99f, 1};


/* Global Array Declarations */
float SIM__motor_plant_numerator[] = {1.0f};
float SIM__motor_plant_denominator[] = {0.001f, 0.04f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(150.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Log_chirp = signalSource::chirpLog(0.5f, 60.0f, 20.0f, 0.0f, /*mode=*/ WaveMode::OneShot, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 10.0f);
  expander fan_3 = expander(3);
  tf SIM__motor_plant = tf(SIM__motor_plant_numerator, 1, SIM__motor_plant_denominator, 3);
  expander fan_2 = expander(2);
  RLS RLS_order_2 = RLS(&RLS_order_2_config);
  RRLS RRLS_sensitivity_0_99 = RRLS(&RRLS_sensitivity_0_99_config);
  theta_rls = VectorProbe("theta_RLS");
  pred_err = probe("prediction_erro");
  RLS_order_2_tap = probe("RLS order 2_o0");
  theta_rrls = VectorProbe("theta_RRLS");
  RRLS_sensitivity_0_99_tap = probe("RRLS sensitiv_0");
  RRLS_sensitivity_0_99_tap_2 = probe("RRLS sensitiv_1");

  /* Connect Blocks */
  Log_chirp > fan_3;
  fan_3.out(0) > SIM__motor_plant;
  fan_3.out(1) > RLS_order_2.in(1);
  fan_3.out(2) > RRLS_sensitivity_0_99.in(1);
  SIM__motor_plant > fan_2;
  fan_2.out(0) > RLS_order_2.in(0);
  fan_2.out(1) > RRLS_sensitivity_0_99.in(0);
  RLS_order_2.out(0) >> theta_rls;
  RLS_order_2.out(1) > pred_err;
  RLS_order_2.out(0) > RLS_order_2_tap;
  RRLS_sensitivity_0_99.out(0) >> theta_rrls;
  RRLS_sensitivity_0_99.out(0) > RRLS_sensitivity_0_99_tap;
  RRLS_sensitivity_0_99.out(1) > RRLS_sensitivity_0_99_tap_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    theta_rls.show();
    pred_err.show();
    RLS_order_2_tap.show();
    theta_rrls.show();
    RRLS_sensitivity_0_99_tap.show();
    RRLS_sensitivity_0_99_tap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}