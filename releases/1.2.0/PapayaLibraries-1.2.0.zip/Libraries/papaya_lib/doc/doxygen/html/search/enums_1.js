var searchData=
[
  ['multisinephase_0',['MultisinePhase',['../_p_a_p_a_y_a_8h.html#ae73693c436f9c2b25f3d5133165fc9c7',1,'PAPAYA.h']]]
];
