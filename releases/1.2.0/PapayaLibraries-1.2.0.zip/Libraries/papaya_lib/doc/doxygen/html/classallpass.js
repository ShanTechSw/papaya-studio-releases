var classallpass =
[
    [ "allpass", "classallpass.html#aaf664261083d905fcd38c01f2604a61f", null ]
];