var struct_p_p___m_r_a_c___p_i_d___config =
[
    [ "Am", "struct_p_p___m_r_a_c___p_i_d___config.html#a5dd3285735e0db53942d6d7fb0895bac", null ],
    [ "Bm", "struct_p_p___m_r_a_c___p_i_d___config.html#a22300675a94ff15c204f61658126baba", null ],
    [ "gamma_d", "struct_p_p___m_r_a_c___p_i_d___config.html#ac3f62772348aff4bb6f366271733648d", null ],
    [ "gamma_i", "struct_p_p___m_r_a_c___p_i_d___config.html#a0cac0427de25143b27527bd31c2f57a1", null ],
    [ "gamma_p", "struct_p_p___m_r_a_c___p_i_d___config.html#a799b1fe74a41ba28785bbc0309f156dd", null ],
    [ "Tau", "struct_p_p___m_r_a_c___p_i_d___config.html#a57ef016d636e0dca43a16ae49bd66fc2", null ]
];