"""Band selection: measure which band is impulsive instead of guessing.

Run this beside example 94.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  is anything
  impacting       the largest band kurtosis. Excess kurtosis is near zero
                  for noise and for anything stationary, and large for a
                  signal made of short transients, so one threshold serves
                  every band regardless of how much energy each holds.

  which band      the band that wins, reported as a frequency range to take
                  into an envelope analysis.

  do the two
  measures agree  the winning band by KURTOSIS and the winning band by
                  LEVEL. When they disagree the reason is usually that
                  kurtosis is normalised by the band's own variance, so a
                  band with almost nothing in it but occasional clicks
                  scores highly on very little energy. This script says so
                  rather than picking one.

  and the point   the broadband RMS is printed beside all of it. On this
                  record it moves by less than a third across three
                  conditions, which is why a severity threshold finds
                  nothing here.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "ringing low", "ringing high")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "bands"
FEATURES = ("kurt0", "kurt1", "kurt2", "level0", "level1", "level2",
            "skew0", "skew1", "skew2", "kurt_best",
            "rms", "kurt_broad", "state")

# The bands, which must match the filters in the diagram.
BANDS = ((60.0, 200.0), (200.0, 500.0), (500.0, 960.0))

IMPULSIVE = 1.0             # excess kurtosis: above this a band has impacts
STRONGLY = 3.0

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def classify(row):
    kurt = [row["kurt0"], row["kurt1"], row["kurt2"]]
    level = [row["level0"], row["level1"], row["level2"]]
    skew = [row["skew0"], row["skew1"], row["skew2"]]

    best_k = max(range(3), key=lambda i: kurt[i])
    best_l = max(range(3), key=lambda i: level[i])
    reasons = [
        "kurtosis by band: " + ", ".join(
            f"{i} {kurt[i]:+.2f}" for i in range(3)),
        "level by band:    " + ", ".join(
            f"{i} {level[i]:.4f}" for i in range(3)),
        f"broadband RMS {row['rms']:.4f} g, broadband kurtosis "
        f"{row['kurt_broad']:+.2f}",
    ]

    if kurt[best_k] < IMPULSIVE:
        reasons.append(
            "no band is impulsive. That is not the same as no fault: a "
            "defect whose impacts overlap each other looks stationary, and "
            "so does a fault that is not an impact at all")
        return ("healthy", "nothing impacting in any band", reasons)

    lo, hi = BANDS[best_k]
    reasons.append(
        f"band {best_k}, {lo:.0f} to {hi:.0f} Hz, is the most impulsive at "
        f"{kurt[best_k]:+.2f}. That is the band to take into an envelope "
        f"analysis")
    reasons.append(
        f"its skewness is {skew[best_k]:+.2f}, which says whether the "
        f"impacts push one way or both")

    if best_k == best_l:
        reasons.append(
            f"the level agrees: band {best_l} also holds the most energy, "
            f"so the resonance really is there")
        agreement = ""
    else:
        reasons.append(
            f"but the LEVEL says band {best_l}. Kurtosis is normalised by "
            f"each band's own variance, so a nearly empty band scores "
            f"highly on very little energy. Look at both before choosing")
        agreement = ", with the level disagreeing"

    strength = "strongly " if kurt[best_k] >= STRONGLY else ""
    verdict = ("ringing low" if best_k <= 1 else "ringing high")
    return (verdict,
            f"{strength}impulsive in {lo:.0f} to {hi:.0f} Hz{agreement}",
            reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 94_spectral_kurtosis_band_selector.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA spectral-kurtosis band selector")
    print("=" * 72)
    print("Bands in use, which must match the filters in the diagram:")
    for i, (lo, hi) in enumerate(BANDS):
        print(f"  band {i}   {lo:6.0f} to {hi:6.0f} Hz")
    print(f"\nA band counts as impulsive above an excess kurtosis of "
          f"{IMPULSIVE:.1f}.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
