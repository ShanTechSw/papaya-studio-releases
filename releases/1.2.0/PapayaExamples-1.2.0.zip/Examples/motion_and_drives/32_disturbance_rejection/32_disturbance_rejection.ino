/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe est_dist;
probe SIM__rep_plant_tap;
probe iter_err;

input ref;

/* Global Struct Declarations */
// Configuration for ADRC
PP_ADRCConfig ADRC_config = {
  .b0 = 1.0f,
  .omega_o = 100.0f,
  .omega_c = 50.0f,
  .order = 2
};

// Configuration for SIM__ADRC_plant
static float SIM__ADRC_plant_A_data[4] = {1.0f, 0.001f, 0.0f, 1.0f};
static float SIM__ADRC_plant_B_data[2] = {5e-07f, 0.001f};
static float SIM__ADRC_plant_C_data[2] = {1.0f, 0.0f};
static float SIM__ADRC_plant_D_data[1] = {0.0f};
static float SIM__ADRC_plant_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__ADRC_plant_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__ADRC_plant_A_data,
  .B_data = SIM__ADRC_plant_B_data,
  .C_data = SIM__ADRC_plant_C_data,
  .D_data = SIM__ADRC_plant_D_data,
  .x_init = SIM__ADRC_plant_x_init
};

// Configuration for Disturbance_obs
static float Disturbance_obs_Gn_num[2] = {1.0f, 0.0f};
static float Disturbance_obs_Gn_den[2] = {1.0f, -0.9f};
static float Disturbance_obs_Qf_num[2] = {0.1f, 0.0f};
static float Disturbance_obs_Qf_den[2] = {1.0f, -0.9f};
PP_DOBConfig Disturbance_obs_config = {
  .Gn_num = Disturbance_obs_Gn_num,
  .Gn_den = Disturbance_obs_Gn_den,
  .Qf_num = Disturbance_obs_Qf_num,
  .Qf_den = Disturbance_obs_Qf_den,
  .plant_ord = 1,
  .qf_ord = 1
};

// Configuration for Repetitive_ctrl
PP_RepCtrlConfig Repetitive_ctrl_config = {
  .period_samples = 100,
  .Q_gain = 0.95f,
  .Kr = 0.5f
};

// Configuration for Iterative_learning
PP_ILCConfig Iterative_learning_config = {
  .trial_length = 500,
  .L_gain = 0.5f,
  .Q_gain = 0.95f
};


/* Global Array Declarations */
float SIM__rep_plant_numerator[] = {1.0f};
float SIM__rep_plant_denominator[] = {0.0016f, 1.0f};
float SIM__ILC_plant_numerator[] = {1.0f};
float SIM__ILC_plant_denominator[] = {0.1f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 1.0f);
  signalSource disturbance = signalSource::sine(10.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  expander fan_3 = expander(3);
  adrc ADRC = adrc(&ADRC_config);
  node reject_disturbance = node("[1.0 -1.0]", "[1.0]", Sum);
  expander fan_2_2 = expander(2);
  stateSpace SIM__ADRC_plant = stateSpace(&SIM__ADRC_plant_config);
  expander fan_2 = expander(2);
  dob Disturbance_obs = dob(&Disturbance_obs_config);
  node Rep_error = node("[1.0 -1.0]", "[1.0]", Sum);
  repetitiveCtrl Repetitive_ctrl = repetitiveCtrl(&Repetitive_ctrl_config);
  node u_sum = node("[1.0 1.0]", "[1.0]", Sum);
  tf SIM__rep_plant = tf(SIM__rep_plant_numerator, 1, SIM__rep_plant_denominator, 2);
  node ILC_error = node("[1.0 -1.0]", "[1.0]", Sum);
  ilc Iterative_learning = ilc(&Iterative_learning_config);
  tf SIM__ILC_plant = tf(SIM__ILC_plant_numerator, 1, SIM__ILC_plant_denominator, 2);
  est_dist = probe("est_disturbance");
  SIM__rep_plant_tap = probe("SIM: rep plan_0");
  iter_err = probe("error_per_itera");

  /* Connect Blocks */
  ref > fan_3;
  disturbance > u_sum.in(1);
  fan_3.out(0) > ADRC.in(0);
  fan_3.out(1) > Rep_error.in(0);
  fan_3.out(2) > ILC_error.in(0);
  ADRC > reject_disturbance.in(0);
  reject_disturbance > fan_2_2;
  fan_2_2.out(0) > SIM__ADRC_plant;
  fan_2_2.out(1) > Disturbance_obs.in(0);
  SIM__ADRC_plant > fan_2;
  fan_2.out(0) > ADRC.in(1);
  fan_2.out(1) > Disturbance_obs.in(1);
  Disturbance_obs > reject_disturbance.in(1);
  Disturbance_obs > est_dist;
  Rep_error > Repetitive_ctrl;
  Repetitive_ctrl > u_sum.in(0);
  u_sum > SIM__rep_plant;
  SIM__rep_plant > Rep_error.in(1);
  SIM__rep_plant > SIM__rep_plant_tap;
  ILC_error > Iterative_learning;
  ILC_error > iter_err;
  Iterative_learning > SIM__ILC_plant;
  SIM__ILC_plant > ILC_error.in(1);

  /* Enable Remote Input Control */
  ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    est_dist.show();
    SIM__rep_plant_tap.show();
    iter_err.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}