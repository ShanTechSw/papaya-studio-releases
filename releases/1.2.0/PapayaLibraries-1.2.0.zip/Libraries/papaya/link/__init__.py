"""PAPAYA Link: carrying a board's conversation over a network.

The board speaks its own protocol over USB or SPI. This package carries
that conversation between PAPAYA Studio and a host wired to the board,
across a link that is neither: Wi-Fi, or Bluetooth, or a socket.

:mod:`papaya.link.protocol` is the wire format and nothing else. It reads
and writes bytes objects, opens no connection and owns no state beyond a
decoder's own buffer, which is what makes it testable without a board, a
radio or a gateway.

The four pieces, and which end each belongs to:

* :class:`~papaya.link.client.LinkClient` is the end that wants a board.
  It composes commands, splits them by the board's own chunk size, and
  sorts what comes back, because a telemetry batch can land in the middle
  of waiting for a command's result.
* :class:`~papaya.link.gateway.Gateway` is the end wired to the board. It
  performs five transaction shapes and parses no opcodes at all, which is
  what stops a relay having to keep up with a firmware it does not model.
* :class:`~papaya.link.server.LinkServer` carries the gateway over a
  socket, one client at a time.
* :class:`~papaya.link.board_port.TransportBoardPort` binds the gateway to
  a real board through any transport that can write and read a framed
  exchange.

Two rules the whole package exists to keep, both of which fail silently
when broken:

* **A command is never abandoned partway.** The board has no inter-frame
  timeout, so a body that stops arriving leaves its receive state machine
  waiting forever, and nothing short of a reset clears it. When a command
  cannot be completed the remaining chunks are sent as filler, so the
  board finishes its receive, fails the body checksum, and answers an
  error. An error is recoverable; a stalled state machine is not.
* **Nothing here ever holds more than one body chunk**, whatever the size
  of the command passing through. That is what makes a host with 32 KB of
  memory in total a usable gateway, and it is why a command is split
  before it crosses the link rather than after.
"""
from .protocol import (
    LinkFrame, FrameDecoder, MessageType, TransactionShape, CommandOutcome,
    LinkProtocolError, BadMagic, BadChecksum, UnsupportedVersion,
    PayloadTooLarge,
    PROTOCOL_VERSION, MAGIC, HEADER_SIZE, CHECKSUM_SIZE, FRAME_OVERHEAD,
    MAX_PAYLOAD, BOARD_CHUNK_SIZE,
    encode, encode_command, decode_command,
    encode_command_chunk, decode_command_chunk, command_messages,
    encode_command_result, decode_command_result,
    encode_subscribe, decode_subscribe,
    encode_telemetry, decode_telemetry,
)
from .gateway import Gateway, BoardPort
from .board_port import TransportBoardPort
from .server import LinkServer, serve_connection
from .client import LinkClient, LinkClientError
from .discovery import Discovered, DiscoveryError, search

__all__ = [
    "LinkFrame", "FrameDecoder", "MessageType", "TransactionShape",
    "CommandOutcome", "Gateway", "BoardPort", "TransportBoardPort",
    "LinkServer", "serve_connection", "LinkClient", "LinkClientError",
    "Discovered", "DiscoveryError", "search",
    "LinkProtocolError", "BadMagic", "BadChecksum", "UnsupportedVersion",
    "PayloadTooLarge",
    "PROTOCOL_VERSION", "MAGIC", "HEADER_SIZE", "CHECKSUM_SIZE",
    "FRAME_OVERHEAD", "MAX_PAYLOAD", "BOARD_CHUNK_SIZE",
    "encode", "encode_command", "decode_command",
    "encode_command_chunk", "decode_command_chunk", "command_messages",
    "encode_command_result", "decode_command_result",
    "encode_subscribe", "decode_subscribe",
    "encode_telemetry", "decode_telemetry",
]
