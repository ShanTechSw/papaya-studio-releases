/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 10000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe regulation_error;
probe duty_cycle;
probe output_voltage;
probe ripple_rms;

input vout_setpoint;
input ramp_up_Vps;
input ramp_dn_Vps;
input duty_min;
input duty_max;

/* Global Array Declarations */
float SIM__buck_LC_stage_numerator[] = {12.0f};
float SIM__buck_LC_stage_denominator[] = {2.5e-07f, 0.0004f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(10000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  vout_setpoint = input("vout_setpoint_V", 3.3f);
  ramp_up_Vps = input("ramp_up_Vps", 33.0f);
  ramp_dn_Vps = input("ramp_dn_Vps", 33.0f);
  duty_min = input("duty_min", 0.0f);
  duty_max = input("duty_max", 1.0f);
  signalSource SIM__load_step = signalSource::step(0.5f, 0.0f, -0.4f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  rateLimiter soft_start_ramp = rateLimiter();
  node voltage_error = node("[1.0 -1.0]", "[1.0]", Sum);
  leadLag compensator_zero = leadLag(3.0, 900.0, 12000.0);
  pid PI_integral = pid(240.0, 0.6, 0.0, 0.001);
  sat duty_clamp_0__1 = sat();
  node duty___load = node("[1.0 1.0]", "[1.0]", Sum);
  tf SIM__buck_LC_stage = tf(SIM__buck_LC_stage_numerator, 1, SIM__buck_LC_stage_denominator, 3);
  expander fan_2 = expander(2);
  derivative ripple_detector = derivative(0.0002);
  rootMeanSquare ripple_RMS = rootMeanSquare(128);
  regulation_error = probe("regulation_erro");
  duty_cycle = probe("duty_cycle");
  output_voltage = probe("output_voltage");
  ripple_rms = probe("ripple_rms_V");

  /* Connect Blocks */
  vout_setpoint > soft_start_ramp.in(0);
  ramp_up_Vps > soft_start_ramp.in(1);
  ramp_dn_Vps > soft_start_ramp.in(2);
  duty_min > duty_clamp_0__1.in(1);
  duty_max > duty_clamp_0__1.in(0);
  SIM__load_step > duty___load.in(1);
  soft_start_ramp > voltage_error.in(0);
  voltage_error > compensator_zero;
  voltage_error > regulation_error;
  compensator_zero > PI_integral;
  PI_integral > duty_clamp_0__1.in(2);
  duty_clamp_0__1 > duty___load.in(0);
  duty_clamp_0__1 > duty_cycle;
  duty___load > SIM__buck_LC_stage;
  SIM__buck_LC_stage > fan_2;
  SIM__buck_LC_stage > output_voltage;
  fan_2.out(0) > voltage_error.in(1);
  fan_2.out(1) > ripple_detector;
  ripple_detector > ripple_RMS;
  ripple_RMS > ripple_rms;

  /* Enable Remote Input Control */
  vout_setpoint.enableRemote();
  ramp_up_Vps.enableRemote();
  ramp_dn_Vps.enableRemote();
  duty_min.enableRemote();
  duty_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    regulation_error.show();
    duty_cycle.show();
    output_voltage.show();
    ripple_rms.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}