/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe unused_signals;
probe sched_gain;

input ref;
input const_;
input clamp_min;
input clamp_max;

/* Global Struct Declarations */
// Configuration for Uncertain_plant
PP_motorBlockCfg Uncertain_plant_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  1,
  {MotorVelocity, NoMotorOutput, NoMotorOutput}
};

// Configuration for Esc_Pid
PP_ESC_PID_Config Esc_Pid_config = {
  .Kp_init = 1.0f,
  .Ki_init = 0.5f,
  .Kd_init = 0.1f,
  .a = 0.05f,
  .omega_p = 3.0f,
  .omega_i = 5.0f,
  .omega_d = 7.0f,
  .esc_gain = 0.1f,
  .lpf_wc = 1.0f,
  .Tau = 0.01f,
  .iae_window = 2.0f
};

// Configuration for Fuzzy_Pid
PP_FuzzyPIDConfig Fuzzy_Pid_config = {
  .Kp_base = 1.0f,
  .Ki_base = 0.5f,
  .Kd_base = 0.1f,
  .e_range = 10.0f,
  .de_range = 5.0f,
  .Tau = 0.01f,
  .out_min = -100.0f,
  .out_max = 100.0f
};

// Configuration for Gain_Schedule_Pid
static float Gain_Schedule_Pid_schedule_points[3] = {0.0f, 50.0f, 100.0f};
static float Gain_Schedule_Pid_Kp_table[3] = {1.0f, 2.0f, 3.0f};
static float Gain_Schedule_Pid_Ki_table[3] = {0.1f, 0.2f, 0.3f};
static float Gain_Schedule_Pid_Kd_table[3] = {0.01f, 0.02f, 0.03f};
PP_GainSchedulePIDConfig Gain_Schedule_Pid_config = {
  .schedule_points = Gain_Schedule_Pid_schedule_points,
  .Kp_table = Gain_Schedule_Pid_Kp_table,
  .Ki_table = Gain_Schedule_Pid_Ki_table,
  .Kd_table = Gain_Schedule_Pid_Kd_table,
  .Tau = 0.01f,
  .out_min = -100.0f,
  .out_max = 100.0f,
  .num_points = 3
};

// Configuration for Str_Pid
PP_STR_PID_Config Str_Pid_config = {
  .lambda = 0.98f,
  .P_init = 100.0f,
  .Tau = 0.01f,
  .desired_cl_bw = 10.0f
};

// Configuration for Mrac_Pid
PP_MRAC_PID_Config Mrac_Pid_config = {
  .Am = 0.999f,
  .Bm = 0.001f,
  .gamma_p = 1.0f,
  .gamma_i = 0.5f,
  .gamma_d = 0.1f,
  .Tau = 0.01f
};

// Configuration for Str
static float Str_desired_poles[2] = {0.5f, 0.3f};
PP_STRConfig Str_config = {
  .na = 2,
  .nb = 2,
  .lambda = 0.98f,
  .P_init = 100.0f,
  .desired_poles = Str_desired_poles
};

// Configuration for Mrac_Lyapunov
PP_MRACLyapunovConfig Mrac_Lyapunov_config = {
  .Am = 0.999f,
  .Bm = 0.001f,
  .gamma_x = 1.0f,
  .gamma_r = 1.0f,
  .sigma = 0.01f,
  .theta_max = 10.0f
};

// Configuration for Mrac
PP_MRACConfig Mrac_config = {
  .Am = 0.999f,
  .Bm = 0.001f,
  .gamma_x = 1.0f,
  .gamma_r = 1.0f
};

// Configuration for Extremum_seeking
PP_ESCConfig Extremum_seeking_config = {
  .a = 0.1f,
  .omega = 10.0f,
  .k = 1.0f,
  .hpf_wc = 5.0f,
  .lpf_wc = 1.0f
};

// Configuration for Gain_scheduler
static float Gain_scheduler_breakpoints[3] = {0.0f, 50.0f, 100.0f};
static float Gain_scheduler_values[3] = {1.0f, 2.0f, 3.0f};
PP_GainSchedulerConfig Gain_scheduler_config = {
  .breakpoints = Gain_scheduler_breakpoints,
  .values = Gain_scheduler_values,
  .num_points = 3,
  .num_outputs = 1
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 1.0f);
  clamp_min = input("clamp_min", -0.8f);
  clamp_max = input("clamp_max", 0.8f);
  const_ = input("const", 0.0f);
  expander fan_8 = expander(8);
  mux Controller_select = mux(8);
  sat Clamp = sat();
  motor Uncertain_plant = motor(&Uncertain_plant_config);
  expander fan_9 = expander(11);
  node ESC_PID_err = node("[1.0 -1.0]", "[1.0]", Sum);
  node Gain_sched_err = node("[1.0 -1.0]", "[1.0]", Sum);
  escPID Esc_Pid = escPID(&Esc_Pid_config);
  node FUZZY_PID_err = node("[1.0 -1.0]", "[1.0]", Sum);
  fuzzyPID Fuzzy_Pid = fuzzyPID(&Fuzzy_Pid_config);
  gainSchedulePID Gain_Schedule_Pid = gainSchedulePID(&Gain_Schedule_Pid_config);
  strPID Str_Pid = strPID(&Str_Pid_config);
  mracPID Mrac_Pid = mracPID(&Mrac_Pid_config);
  str Str = str(&Str_config);
  mracLyapunov Mrac_Lyapunov = mracLyapunov(&Mrac_Lyapunov_config);
  mrac Mrac = mrac(&Mrac_config);
  esc Extremum_seeking = esc(&Extremum_seeking_config);
  merger unused_bus = merger(17);
  gainScheduler Gain_scheduler = gainScheduler(&Gain_scheduler_config);
  unused_signals = probe("unused_signals");
  sched_gain = probe("scheduled_gain");

  /* Connect Blocks */
  ref > fan_8;
  clamp_min > Clamp.in(1);
  clamp_max > Clamp.in(0);
  const_ > Controller_select.in(8);
  fan_8.out(7) > ESC_PID_err.in(0);
  fan_8.out(5) > Gain_sched_err.in(0);
  fan_8.out(6) > FUZZY_PID_err.in(0);
  fan_8.out(4) > Str_Pid.in(0);
  fan_8.out(3) > Mrac_Pid.in(0);
  fan_8.out(2) > Str.in(0);
  fan_8.out(1) > Mrac_Lyapunov.in(0);
  fan_8.out(0) > Mrac.in(0);
  Controller_select > Clamp.in(2);
  Clamp > Uncertain_plant;
  Uncertain_plant > fan_9;
  fan_9.out(10) > ESC_PID_err.in(1);
  fan_9.out(9) > Gain_sched_err.in(1);
  fan_9.out(7) > Esc_Pid.in(1);
  fan_9.out(6) > FUZZY_PID_err.in(1);
  fan_9.out(5) > Gain_Schedule_Pid.in(1);
  fan_9.out(4) > Str_Pid.in(1);
  fan_9.out(3) > Mrac_Pid.in(1);
  fan_9.out(2) > Str.in(1);
  fan_9.out(1) > Mrac_Lyapunov.in(1);
  fan_9.out(0) > Mrac.in(1);
  fan_9.out(8) > Extremum_seeking;
  ESC_PID_err > Esc_Pid.in(0);
  Gain_sched_err > Gain_Schedule_Pid.in(0);
  Esc_Pid.out(0) > Controller_select.in(7);
  Esc_Pid.out(1) > unused_bus.in(14);
  Esc_Pid.out(2) > unused_bus.in(15);
  Esc_Pid.out(3) > unused_bus.in(16);
  FUZZY_PID_err > Fuzzy_Pid;
  Fuzzy_Pid.out(0) > Controller_select.in(6);
  Fuzzy_Pid.out(1) > unused_bus.in(11);
  Fuzzy_Pid.out(2) > unused_bus.in(12);
  Fuzzy_Pid.out(3) > unused_bus.in(13);
  Gain_Schedule_Pid.out(0) > Controller_select.in(5);
  Gain_Schedule_Pid.out(1) > unused_bus.in(8);
  Gain_Schedule_Pid.out(2) > unused_bus.in(9);
  Gain_Schedule_Pid.out(3) > unused_bus.in(10);
  Str_Pid.out(0) > Controller_select.in(4);
  Str_Pid.out(1) > unused_bus.in(5);
  Str_Pid.out(2) > unused_bus.in(6);
  Str_Pid.out(3) > unused_bus.in(7);
  Mrac_Pid.out(0) > Controller_select.in(3);
  Mrac_Pid.out(1) > unused_bus.in(2);
  Mrac_Pid.out(2) > unused_bus.in(3);
  Mrac_Pid.out(3) > unused_bus.in(4);
  Str > Controller_select.in(2);
  Mrac_Lyapunov.out(0) > Controller_select.in(1);
  Mrac_Lyapunov.out(1) > unused_bus.in(1);
  Mrac.out(0) > Controller_select.in(0);
  Mrac.out(1) > unused_bus.in(0);
  Extremum_seeking > Gain_scheduler;
  unused_bus > unused_signals;
  Gain_scheduler > sched_gain;

  /* Enable Remote Input Control */
  ref.enableRemote();
  clamp_min.enableRemote();
  clamp_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    unused_signals.show();
    sched_gain.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}