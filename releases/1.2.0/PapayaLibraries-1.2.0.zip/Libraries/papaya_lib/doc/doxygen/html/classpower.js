var classpower =
[
    [ "power", "classpower.html#abfc49db2fa38d061c61078d9502d7a7f", null ]
];