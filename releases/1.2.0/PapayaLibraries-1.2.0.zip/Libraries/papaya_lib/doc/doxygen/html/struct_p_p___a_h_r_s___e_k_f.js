var struct_p_p___a_h_r_s___e_k_f =
[
    [ "mag_ref", "struct_p_p___a_h_r_s___e_k_f.html#af0bd5c693d1244e5160f23ae55dc2951", null ],
    [ "P_init", "struct_p_p___a_h_r_s___e_k_f.html#a125c821f91f22e5478a3c965fd1ebb4a", null ],
    [ "Q_data", "struct_p_p___a_h_r_s___e_k_f.html#a6e79463316f5d088bae9f8513fdbb550", null ],
    [ "R_data", "struct_p_p___a_h_r_s___e_k_f.html#accd9221f20cfb31bf29fac9ad5be7c65", null ],
    [ "x_init", "struct_p_p___a_h_r_s___e_k_f.html#a7243ea9fc3378a5f73765cc925684771", null ]
];