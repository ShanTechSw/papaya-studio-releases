var struct_p_p___rep_ctrl_config =
[
    [ "Kr", "struct_p_p___rep_ctrl_config.html#a3f7752559d5100bdf1b0eebbc0f15376", null ],
    [ "period_samples", "struct_p_p___rep_ctrl_config.html#a65a1c2f59df075f8d2d8b18fb5fadeff", null ],
    [ "Q_gain", "struct_p_p___rep_ctrl_config.html#a085119c4e7a24a3768a35731d1f9f704", null ]
];