/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 8000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe distorted;
probe crushed;
probe pan_value;
probe left;
probe right;
probe mix_left;
probe mix_right;

input pan;
input mixer_ch1;
input mixer_ch2;
input mixer_ch3;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(8000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  pan = input("pan", 0.0f);
  signalSource Source = signalSource::sine(300.0f, 0.0f);
  mixer_ch1 = input("mixer_ch1", 0.0f);
  mixer_ch2 = input("mixer_ch2", 0.0f);
  mixer_ch3 = input("mixer_ch3", 0.0f);
  expander fan_3 = expander(3);
  expander fan_2 = expander(2);
  distortion Distort = distortion(5.0, 0.7, 2);
  bitcrusher Crush = bitcrusher(8.0, 4);
  gain pan_echo = gain(1.0);
  expander to_stereo = expander(2);
  stereoPan Pan = stereoPan();
  stereoMixer Mix = stereoMixer(4);
  distorted = probe("distorted");
  crushed = probe("crushed");
  pan_value = probe("pan_value");
  left = probe("left");
  right = probe("right");
  mix_left = probe("mix_left");
  mix_right = probe("mix_right");

  /* Connect Blocks */
  pan > fan_2;
  Source > fan_3;
  mixer_ch1 > Mix.in(1);
  mixer_ch2 > Mix.in(2);
  mixer_ch3 > Mix.in(3);
  fan_3.out(0) > Distort;
  fan_3.out(1) > Crush;
  fan_3.out(2) > to_stereo;
  fan_2.out(0) > pan_echo;
  fan_2.out(1) > Pan.in(1);
  Distort > distorted;
  Crush > crushed;
  pan_echo > pan_value;
  to_stereo.out(0) > Pan.in(0);
  to_stereo.out(1) > Mix.in(0);
  Pan.out(0) > left;
  Pan.out(1) > right;
  Mix.out(0) > mix_left;
  Mix.out(1) > mix_right;

  /* Enable Remote Input Control */
  pan.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    distorted.show();
    crushed.show();
    pan_value.show();
    left.show();
    right.show();
    mix_left.show();
    mix_right.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}