/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-06 22:08:13
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe DC_motor_1_tap;
probe DC_motor_2_tap;
probe Feed_fwd_PID_tap;
probe Axis2_PID_tap;

input pos_ref;
input axis2_ref;
input inner_kp;
input inner_ki;
input ff_kp;
input a2_kp;
input a2_ki;
input a2_kd;
input a2_tau;
input ff_ki;
input ff_kd;
input ff_tau;
input ax2_kp;
input ax2_ki;
input ax2_kd;
input ax2_tau;

/* Global Struct Declarations */
// Configuration for DC_motor_1
PP_motorBlockCfg DC_motor_1_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  3,
  {MotorVelocity, MotorPosition, MotorCurrent}
};

// Configuration for DC_motor_2
PP_motorBlockCfg DC_motor_2_config = {
  MOTOR2,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  2,
  {MotorPosition, MotorCurrent, NoMotorOutput}
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  pos_ref = input("pos_ref", 180.0f);
  inner_kp = input("inner_kp", 0.005f);
  inner_ki = input("inner_ki", 0.05f);
  axis2_ref = input("axis2_ref", 90.0f);
  ff_kp = input("ff_kp", 0.005f);
  a2_kp = input("a2_kp", 0.005f);
  a2_ki = input("a2_ki", 0.05f);
  a2_kd = input("a2_kd", 0.0f);
  a2_tau = input("a2_tau", 0.01f);
  ff_ki = input("ff_ki", 0.05f);
  ff_kd = input("ff_kd", 0.0f);
  ff_tau = input("ff_tau", 0.01f);
  ax2_kp = input("ax2_kp", 0.005f);
  ax2_ki = input("ax2_ki", 0.05f);
  ax2_kd = input("ax2_kd", 0.0f);
  ax2_tau = input("ax2_tau", 0.01f);
  signalSource outer_kp = signalSource::dc(2.0f);
  signalSource outer_kd = signalSource::dc(0.02f);
  signalSource outer_tau = signalSource::dc(0.01f);
  signalSource a2_b = signalSource::dc(1.0f);
  signalSource a2_c = signalSource::dc(0.0f);
  node Pos_error = node("[1.0 -1.0]", "[1.0]", Sum);
  livePd Outer_PD = livePd();
  node Vel_error = node("[1.0 -1.0]", "[1.0]", Sum);
  livePi Inner_PI = livePi();
  motor DC_motor_1 = motor(&DC_motor_1_config);
  expander fan_2 = expander(2);
  live2Pid _2_DOF_PID = live2Pid();
  motor DC_motor_2 = motor(&DC_motor_2_config);
  expander fan_2_2 = expander(2);
  node Axis2_error = node("[1.0 -1.0]", "[1.0]", Sum);
  expander fan_2_3 = expander(2);
  livePid Feed_fwd_PID = livePid();
  livePid Axis2_PID = livePid();
  DC_motor_1_tap = probe("DC motor 1_o0");
  DC_motor_2_tap = probe("DC motor 2_o0");
  Feed_fwd_PID_tap = probe("Feed-fwd PID_o0");
  Axis2_PID_tap = probe("Axis2 PID_o0");

  /* Connect Blocks */
  pos_ref > Pos_error.in(0);
  inner_kp > Inner_PI.in(1);
  inner_ki > Inner_PI.in(2);
  axis2_ref > fan_2;
  ff_kp > Feed_fwd_PID.in(1);
  a2_kp > _2_DOF_PID.in(2);
  a2_ki > _2_DOF_PID.in(3);
  a2_kd > _2_DOF_PID.in(4);
  a2_tau > _2_DOF_PID.in(5);
  ff_ki > Feed_fwd_PID.in(2);
  ff_kd > Feed_fwd_PID.in(3);
  ff_tau > Feed_fwd_PID.in(4);
  ax2_kp > Axis2_PID.in(1);
  ax2_ki > Axis2_PID.in(2);
  ax2_kd > Axis2_PID.in(3);
  ax2_tau > Axis2_PID.in(4);
  outer_kp > Outer_PD.in(1);
  outer_kd > Outer_PD.in(2);
  outer_tau > Outer_PD.in(3);
  a2_b > _2_DOF_PID.in(6);
  a2_c > _2_DOF_PID.in(7);
  Pos_error > Outer_PD.in(0);
  Outer_PD > Vel_error.in(0);
  Vel_error > Inner_PI.in(0);
  Inner_PI > DC_motor_1;
  DC_motor_1.out(1) > Pos_error.in(1);
  DC_motor_1.out(0) > Vel_error.in(1);
  DC_motor_1.out(2) > DC_motor_1_tap;
  fan_2.out(1) > _2_DOF_PID.in(0);
  fan_2.out(0) > Axis2_error.in(0);
  _2_DOF_PID > DC_motor_2;
  DC_motor_2.out(0) > fan_2_2;
  DC_motor_2.out(1) > DC_motor_2_tap;
  fan_2_2.out(1) > _2_DOF_PID.in(1);
  fan_2_2.out(0) > Axis2_error.in(1);
  Axis2_error > fan_2_3;
  fan_2_3.out(0) > Feed_fwd_PID.in(0);
  fan_2_3.out(1) > Axis2_PID.in(0);
  Feed_fwd_PID > Feed_fwd_PID_tap;
  Axis2_PID > Axis2_PID_tap;

  /* Enable Remote Input Control */
  pos_ref.enableRemote();
  inner_kp.enableRemote();
  inner_ki.enableRemote();
  axis2_ref.enableRemote();
  ff_kp.enableRemote();
  a2_kp.enableRemote();
  a2_ki.enableRemote();
  a2_kd.enableRemote();
  a2_tau.enableRemote();
  ff_ki.enableRemote();
  ff_kd.enableRemote();
  ff_tau.enableRemote();
  ax2_kp.enableRemote();
  ax2_ki.enableRemote();
  ax2_kd.enableRemote();
  ax2_tau.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    DC_motor_1_tap.show();
    DC_motor_2_tap.show();
    Feed_fwd_PID_tap.show();
    Axis2_PID_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}