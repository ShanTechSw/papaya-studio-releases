/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 00:23:26
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe estimated_noise;
probe Tonal_notch_tap;
probe Tonal_notch_tap_2;

/* Global Struct Declarations */
// Configuration for LMS___NLMS
PP_LMSConfig LMS___NLMS_config = {
  .mu = 0.05f,
  .N = 32,
  .normalize = 1,
  .delta = 0.001f
};

// Configuration for Tonal_notch
PP_AdaptiveNotchConfig Tonal_notch_config = {
  .init_freq = 50.0f,
  .Q_factor = 10.0f,
  .mu = 0.01f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  microphone Signal_mic = microphone(MIC_L);
  microphone Noise_ref_mic = microphone(MIC_R);
  expander fan_2 = expander(2);
  lms LMS___NLMS = lms(&LMS___NLMS_config);
  adaptiveNotch Tonal_notch = adaptiveNotch(&Tonal_notch_config);
  speaker Cleaned_out = speaker(SPEAKER1);
  estimated_noise = probe("estimated_noise");
  Tonal_notch_tap = probe("Tonal notch_o0");
  Tonal_notch_tap_2 = probe("Tonal notch_o1");

  /* Connect Blocks */
  Signal_mic > fan_2;
  Noise_ref_mic > LMS___NLMS.in(1);
  fan_2.out(0) > LMS___NLMS.in(0);
  fan_2.out(1) > Tonal_notch;
  LMS___NLMS.out(1) > Cleaned_out;
  LMS___NLMS.out(0) > estimated_noise;
  Tonal_notch.out(0) > Tonal_notch_tap;
  Tonal_notch.out(1) > Tonal_notch_tap_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    estimated_noise.show();
    Tonal_notch_tap.show();
    Tonal_notch_tap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}