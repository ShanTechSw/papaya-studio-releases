/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 19:58:06
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe stft_magnitude;
probe magnitude_tap;
VectorProbe stft_phase;
probe stretched_audio;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__input_audio = signalSource::multisine(100.0f, 50.0f, 6, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.8f);
  expander fan_3 = expander(4);
  fft_HannWindow magnitude_FFT = fft_HannWindow(1024);
  fft_HannWindow phase_FFT = fft_HannWindow(1024);
  fracDelay granular_stretch = fracDelay(8192);
  fftMagResolver magnitude = fftMagResolver(magnitude_FFT);
  fft_phaseResolver phase = fft_phaseResolver(phase_FFT);
  node overlap_add_blend = node("[0.5 0.5]", "[1.0]", Sum);
  stft_magnitude = VectorProbe("stft_magnitude");
  magnitude_tap = probe("magnitude_o0");
  stft_phase = VectorProbe("stft_phase");
  stretched_audio = probe("stretched_audio");

  /* Connect Blocks */
  SIM__input_audio > fan_3;
  fan_3.out(0) > magnitude_FFT;
  fan_3.out(1) > phase_FFT;
  fan_3.out(2) > granular_stretch;
  fan_3.out(3) > overlap_add_blend.in(0);
  magnitude_FFT > magnitude;
  phase_FFT > phase;
  granular_stretch > overlap_add_blend.in(1);
  magnitude >> stft_magnitude;
  magnitude > magnitude_tap;
  phase >> stft_phase;
  overlap_add_blend > stretched_audio;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    stft_magnitude.show();
    magnitude_tap.show();
    stft_phase.show();
    stretched_audio.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}