/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 4000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe phase_a_origina;
probe phase_a_returne;
probe phase_b_returne;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(4000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(50.0f, 0.0f);
  signalSource Electrical_angle = signalSource::sawtooth(50.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 3.14159265f, /*offset=*/ 3.14159265f);
  expander phases = expander(3);
  expander angle_split = expander(2);
  clarke Clarke = clarke();
  park Park = park();
  invPark Inverse_Park = invPark();
  invClarke Inverse_Clarke = invClarke();
  phase_a_origina = probe("phase_a_origina");
  phase_a_returne = probe("phase_a_returne");
  phase_b_returne = probe("phase_b_returne");

  /* Connect Blocks */
  Source > phases;
  Electrical_angle > angle_split;
  phases.out(0) > Clarke.in(0);
  phases.out(1) > Clarke.in(1);
  phases.out(2) > phase_a_origina;
  angle_split.out(0) > Park.in(2);
  angle_split.out(1) > Inverse_Park.in(2);
  Clarke.out(0) > Park.in(0);
  Clarke.out(1) > Park.in(1);
  Park.out(0) > Inverse_Park.in(0);
  Park.out(1) > Inverse_Park.in(1);
  Inverse_Park.out(0) > Inverse_Clarke.in(0);
  Inverse_Park.out(1) > Inverse_Clarke.in(1);
  Inverse_Clarke.out(0) > phase_a_returne;
  Inverse_Clarke.out(1) > phase_b_returne;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    phase_a_origina.show();
    phase_a_returne.show();
    phase_b_returne.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}