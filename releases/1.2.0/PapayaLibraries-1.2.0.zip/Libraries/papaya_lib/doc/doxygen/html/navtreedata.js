/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "PAPAYA C++ Host Library", "index.html", [
    [ "Introduction", "index.html#intro_sec", null ],
    [ "Top-level API", "index.html#api_sec", null ],
    [ "V2 protocol negotiation", "index.html#v2_sec", null ],
    [ "Transport ports", "index.html#transport_sec", null ],
    [ "Relationship to the Python library", "index.html#py_link_sec", null ],
    [ "Building", "index.html#build_sec", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Enumerations", "functions_enum.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_p_a_p_a_y_a_8cpp.html",
"_p_a_p_a_y_a_8h.html#a323ed08c59af6e3daae23fcd60e5dbc9a3e6f9d51d3acf38f31304eb3d5d67ebc",
"_p_a_p_a_y_a_8h.html#a37f57b723e0029144122d483835327da",
"_p_a_p_a_y_a_8h.html#ac0c73f373c49285eb35f59434297ec90",
"class_p_a_p_a_y_a.html#acd32f22ea85e9b7a5b0c73bda7436cfb",
"class_vector_probe.html#af1dc164db07c60cd0e0ac61be4f56e55",
"classimu_bias_est.html",
"classsign.html#a3af5c20b6e84c5df7c4f4c291be7efb3",
"globals_w.html",
"struct_p_p___fuzzy_p_i_d_config.html#ad01f5b8c0be2b6af193abcd1c971bac9",
"struct_p_p__linear_k_f.html#acf843ec233429df991a84e08190e42a4"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';