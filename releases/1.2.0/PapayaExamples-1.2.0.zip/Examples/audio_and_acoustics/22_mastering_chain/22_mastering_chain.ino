/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 19:58:05
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe env;
probe vu;
probe log_power;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  microphone Microphone = microphone(MIC_L);
  expander fan_2 = expander(2);
  noiseGate Noise_gate = noiseGate(0.005, 0.1, -50.0, -80.0);
  envFollower Envelope = envFollower(0.005, 0.05);
  compressor Compressor = compressor(0.01, 0.1, -18.0, 4.0);
  limiter Limiter = limiter(0.001, 0.1, -1.0);
  expander fan_3 = expander(3);
  speaker Monitor = speaker(SPEAKER1);
  vuMeter VU = vuMeter(0.3, 0.3);
  momentaryPower Momentary_power = momentaryPower(65);
  loudness Loudness = loudness();
  env = probe("envelope");
  vu = probe("VU");
  log_power = probe("log_power");

  /* Connect Blocks */
  Microphone > fan_2;
  fan_2.out(0) > Noise_gate;
  fan_2.out(1) > Envelope;
  Noise_gate > Compressor;
  Envelope > env;
  Compressor > Limiter;
  Limiter > fan_3;
  fan_3.out(0) > Monitor;
  fan_3.out(1) > VU;
  fan_3.out(2) > Momentary_power;
  VU > vu;
  Momentary_power > Loudness;
  Loudness > log_power;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    env.show();
    vu.show();
    log_power.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}