var class_desktop_serial =
[
    [ "begin", "class_desktop_serial.html#ac0a9ef3f83c430e14c57eb604492cd52", null ],
    [ "print", "class_desktop_serial.html#a4357cb1c91f7bcf8d24eaab56dbf0f67", null ],
    [ "println", "class_desktop_serial.html#a795e2596f5e063f5f17d63607b30451a", null ],
    [ "println", "class_desktop_serial.html#a9c6dce90dc680e9a430f867e1c31e0a2", null ]
];