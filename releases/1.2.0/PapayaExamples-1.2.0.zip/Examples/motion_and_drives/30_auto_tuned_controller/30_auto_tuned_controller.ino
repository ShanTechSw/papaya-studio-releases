/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-11 03:53:14
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe step_tuner_cmd;
probe unused_signals;

input ref;

/* Global Struct Declarations */
// Configuration for Step_autotune
PP_StepAutoTuneConfig Step_autotune_config = {
  .step_size = 1.0f,
  .settle_pct = 0.02f,
  .tuning_rule = 0,
  .id_method = 0
};

// Configuration for Perf_monitor_PID
PP_PerfMonPID_Config Perf_monitor_PID_config = {
  .Kp_init = 1.0f,
  .Ki_init = 0.5f,
  .Kd_init = 0.1f,
  .Tau = 0.01f,
  .iae_threshold = 5.0f,
  .out_min = -100.0f,
  .out_max = 100.0f,
  .eval_window = 2.0f
};

// Configuration for Relay_autotune
PP_RelayAutoTuneConfig Relay_autotune_config = {
  .relay_amplitude = 1.0f,
  .hysteresis = 0.05f,
  .setpoint = 0.0f,
  .tuning_rule = 0,
  .min_cycles = 5
};


/* Global Array Declarations */
float Step_plant_numerator[] = {1.0f};
float Step_plant_denominator[] = {1.0f, 2.0f, 1.0f};
float Plant_numerator[] = {1.0f};
float Plant_denominator[] = {1.0f, 2.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 1.0f);
  stepAutoTune Step_autotune = stepAutoTune(&Step_autotune_config);
  expander fan_step = expander(2);
  tf Step_plant = tf(Step_plant_numerator, 1, Step_plant_denominator, 3);
  node PM_error = node("[1.0 -1.0]", "[1.0]", Sum);
  perfMonitorPID Perf_monitor_PID = perfMonitorPID(&Perf_monitor_PID_config);
  switchBlock Tuner_select = switchBlock();
  tf Plant = tf(Plant_numerator, 1, Plant_denominator, 3);
  expander fan_3 = expander(2);
  relayAutoTune Relay_autotune = relayAutoTune(&Relay_autotune_config);
  expander fan_2 = expander(2);
  gain Done_to_select = gain(-1.0);
  merger unused_bus = merger(12);
  step_tuner_cmd = probe("step_tuner_u");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  ref > PM_error.in(0);
  Step_autotune.out(0) > fan_step;
  Step_autotune.out(1) > unused_bus.in(4);
  Step_autotune.out(2) > unused_bus.in(5);
  Step_autotune.out(3) > unused_bus.in(6);
  Step_autotune.out(4) > unused_bus.in(7);
  fan_step.out(1) > Step_plant;
  fan_step.out(0) > step_tuner_cmd;
  Step_plant > Step_autotune;
  PM_error > Perf_monitor_PID;
  Perf_monitor_PID.out(0) > Tuner_select.in(2);
  Perf_monitor_PID.out(1) > unused_bus.in(8);
  Perf_monitor_PID.out(2) > unused_bus.in(9);
  Perf_monitor_PID.out(3) > unused_bus.in(10);
  Perf_monitor_PID.out(4) > unused_bus.in(11);
  Tuner_select > Plant;
  Plant > fan_3;
  fan_3.out(0) > PM_error.in(1);
  fan_3.out(1) > Relay_autotune;
  Relay_autotune.out(0) > Tuner_select.in(1);
  Relay_autotune.out(4) > fan_2;
  Relay_autotune.out(1) > unused_bus.in(0);
  Relay_autotune.out(2) > unused_bus.in(1);
  Relay_autotune.out(3) > unused_bus.in(2);
  fan_2.out(1) > Done_to_select;
  fan_2.out(0) > unused_bus.in(3);
  Done_to_select > Tuner_select.in(0);
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    step_tuner_cmd.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}