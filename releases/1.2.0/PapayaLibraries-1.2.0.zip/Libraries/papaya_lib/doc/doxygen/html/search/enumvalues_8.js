var searchData=
[
  ['i2c1_0',['I2C1',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98aeb0f494c71f34592c5a4500ee98ab4a2',1,'PAPAYA.h']]],
  ['i2c2_1',['I2C2',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98ae2cc6f0481e798aedb5fd5c6a2bfc01b',1,'PAPAYA.h']]],
  ['i2c3_2',['I2C3',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98a85b6fc15a9c27469c6bdcbf4bd2f1495',1,'PAPAYA.h']]],
  ['i2c4_3',['I2C4',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98a22a4190e8807e182f46b10c0197df0ed',1,'PAPAYA.h']]],
  ['i2c_5ffailure_4',['I2C_Failure',['../_p_a_p_a_y_a_8h.html#acd819010e214d8ad32dc6d17ad016b70a87b2304d29c40705aba44737b40282d2',1,'PAPAYA.h']]],
  ['icm20948_5',['ICM20948',['../_p_a_p_a_y_a_8h.html#a253724c4643f2cd0861f4299a3ded381a0586dc31c4d9b60629bbcfe4ff990b7e',1,'PAPAYA.h']]],
  ['icm42688p_6',['ICM42688P',['../_p_a_p_a_y_a_8h.html#a253724c4643f2cd0861f4299a3ded381a019934cde2cd5976c7209abbb0e37e0a',1,'PAPAYA.h']]],
  ['impulse_7',['Impulse',['../_p_a_p_a_y_a_8h.html#a64dec478c6b69695e161832095a9083ca6b0a227bd9315bcde12dbcf6c217a9d7',1,'PAPAYA.h']]],
  ['imu_5facc_8',['IMU_ACC',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98a7bb2ba5b0e9129a7c3a580f838ab41b0',1,'PAPAYA.h']]],
  ['imu_5fgyr_9',['IMU_GYR',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98ad55db0c49407a889bf7c7819a1ee2b8b',1,'PAPAYA.h']]],
  ['imu_5fmag_10',['IMU_MAG',['../_p_a_p_a_y_a_8h.html#a87c0c7c6207076fb33aff5fae2f9fa98a0d397beb2c9ac70bf138ee0324788be1',1,'PAPAYA.h']]],
  ['internalerror_11',['InternalError',['../class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a8462b58246e70e5c83e5b939a9332cb5',1,'PapayaUsbBridgeBackend']]],
  ['invalidcommand_12',['InvalidCommand',['../class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20ae01b8763e8076df4395e3fa649286e67',1,'PapayaUsbBridgeBackend']]],
  ['invalidpayload_13',['InvalidPayload',['../class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a2d730f4aa6a660e8825d5294008a4ef7',1,'PapayaUsbBridgeBackend']]],
  ['ism330dhcx_14',['ISM330DHCX',['../_p_a_p_a_y_a_8h.html#a253724c4643f2cd0861f4299a3ded381a8c998ff81859055eae1e7360bd07d3b9',1,'PAPAYA.h']]]
];
