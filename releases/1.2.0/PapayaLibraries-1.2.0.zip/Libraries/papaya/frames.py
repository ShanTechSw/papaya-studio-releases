from __future__ import annotations

from dataclasses import dataclass, field
import html
from typing import Any, Iterable, List, Optional, Sequence


def _hex_bytes(data: bytes, sep: str = " ") -> str:
    return sep.join(f"{b:02X}" for b in data)


def _esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


# Colour palette for rendered frame-log HTML.  Every blue is derived from
# the Shanon Technologies logo hue, 216 degrees.  The values are the ones
# Papaya Studio uses elsewhere, so a frame log rendered here looks the same
# as one rendered inside the application. They must stay EXACTLY the
# application's values: the Studio console re-colours a printed frame card
# on a theme switch by substituting known pairs, and a colour a few points
# off (the six this held until 2026-09-07) survives the switch untouched.
LOG_SCREEN_CONFIG: dict[str, dict[str, str]] = {
    "dark": {
        "text": "#F3F6FC",
        "muted": "#A2B2CC",
        "accent": "#8FB8FF",         # logo hue L 0.78 (dark-mode accent)
        "accent_strong": "#C5DAFF",  # logo hue L 0.88
        "teal": "#5EC8C0",
        "warning": "#E4AE4A",        # warning ink, dark surfaces
        "value": "#FF9E1B",          # Shanon brand orange
        "error": "#F5A3AE",
        "panel": "#10192B",
        "panel_soft": "#172238",
        "hex_bg": "#050A12",         # the dark page ground
        "hex_text": "#C5DAFF",       # logo hue L 0.88, the dark accent_strong
        "border": "#2A3E5C",
        "border_soft": "#223551",
        "badge_text": "#08142A",
    },
    "light": {
        "text": "#0E1A2D",
        "muted": "#5F6E88",
        "accent": "#002D72",         # Shanon logo blue (exact)
        "accent_strong": "#004BB0",  # logo hue L 0.34
        "teal": "#0E8E84",
        # AA inks on the light hex/panel surfaces: the raw brand orange
        # (#FF9E1B, ~2:1) and amber (#C88A25, ~2.9:1) were near-unreadable
        # as text, so the light theme darkens both to reach AA contrast.
        "warning": "#875D10",        # warning ink, light surfaces
        "value": "#96590A",          # brand-orange ink, light surfaces
        "error": "#C83D47",
        "panel": "#FFFDF9",
        "panel_soft": "#EFF4FD",
        "hex_bg": "#EAF1FC",         # the light page ground
        "hex_text": "#002D72",       # the logo navy itself
        "border": "#BFCADB",
        "border_soft": "#D7DEEB",
        "badge_text": "#FFFFFF",
    },
}


def _palette(theme: str = "light") -> dict[str, str]:
    t = (theme or "light").strip().lower()
    return dict(LOG_SCREEN_CONFIG.get(t, LOG_SCREEN_CONFIG["light"]))


def hexdump(data: bytes, width: int = 16) -> str:
    """Classic offset + hex dump (ASCII omitted, because most payload is binary)."""
    lines: List[str] = []
    for offset in range(0, len(data), width):
        chunk = data[offset : offset + width]
        lines.append(f"{offset:04X}: {_hex_bytes(chunk)}")
    return "\n".join(lines)


@dataclass
class FrameField:
    name: str
    offset: int
    length: int
    value: Any = None
    note: Optional[str] = None

    def render(self) -> str:
        v = self.value
        if isinstance(v, bytes):
            v_str = _hex_bytes(v)
        else:
            v_str = str(v)
        note = f"  # {self.note}" if self.note else ""
        return f"- {self.name:<22} @0x{self.offset:02X} ({self.length:>3} B): {v_str}{note}"

    def render_html(self, theme: str = "light") -> str:
        c = _palette(theme)
        v = self.value
        if isinstance(v, bytes):
            v_str = _hex_bytes(v)
        else:
            v_str = str(v)
        note_html = f' <span style="color:{c["warning"]};"># {_esc(self.note)}</span>' if self.note else ""
        return (
            '<div style="margin:1px 0;">'
            f'<span style="color:{c["accent_strong"]};">{_esc(self.name)}</span> '
            f'<span style="color:{c["muted"]};">@0x{self.offset:02X}</span> '
            f'<span style="color:{c["muted"]};">({self.length} B)</span>: '
            f'<span style="color:{c["value"]};">{_esc(v_str)}</span>'
            f"{note_html}"
            "</div>"
        )


@dataclass
class PapayaFrame:
    """A single SPI frame (TX/RX) as produced by the Arduino library."""

    direction: str  # "TX" or "RX" (we only produce TX in this phase)
    name: str
    data: bytes
    fields: List[FrameField] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def render(self, show_hexdump: bool = True) -> str:
        parts: List[str] = []
        parts.append(f"[{self.direction}] {self.name}  ({len(self.data)} bytes)")
        if self.fields:
            parts.append("Fields:")
            parts.extend([f.render() for f in self.fields])
        if self.notes:
            parts.append("Notes:")
            parts.extend([f"- {n}" for n in self.notes])
        if show_hexdump:
            parts.append("Hex:")
            parts.append(hexdump(self.data))
        return "\n".join(parts)

    def render_html(self, show_hexdump: bool = True, theme: str = "light") -> str:
        c = _palette(theme)
        direction_color = c["accent"] if str(self.direction).upper() == "TX" else c["teal"]
        header = (
            '<div style="margin:6px 0 4px 0;">'
            f'<span style="display:inline-block;padding:1px 8px;border-radius:9px;'
            f'background:{direction_color};color:{c["badge_text"]};font-weight:700;">{_esc(self.direction)}</span> '
            f'<span style="color:{c["text"]};font-weight:700;">{_esc(self.name)}</span> '
            f'<span style="color:{c["muted"]};">({_esc(len(self.data))} bytes)</span>'
            "</div>"
        )

        fields_html = ""
        if self.fields:
            fields_joined = "".join(f.render_html(theme=theme) for f in self.fields)
            fields_html = (
                '<div style="margin:0 0 4px 12px;">'
                f'<div style="color:{c["muted"]};font-weight:700;margin-bottom:2px;">Fields</div>'
                f"{fields_joined}"
                "</div>"
            )

        notes_html = ""
        if self.notes:
            notes_joined = "".join(
                f'<div style="margin:1px 0;color:{c["warning"]};">- {_esc(n)}</div>' for n in self.notes
            )
            notes_html = (
                '<div style="margin:0 0 4px 12px;">'
                f'<div style="color:{c["muted"]};font-weight:700;margin-bottom:2px;">Notes</div>'
                f"{notes_joined}"
                "</div>"
            )

        hex_html = ""
        if show_hexdump:
            hex_html = (
                '<div style="margin:0 0 4px 12px;">'
                f'<div style="color:{c["muted"]};font-weight:700;margin-bottom:2px;">Hex</div>'
                f'<pre style="margin:0;padding:6px 8px;border:1px solid {c["border"]};border-radius:8px;'
                f'background:{c["hex_bg"]};color:{c["hex_text"]};font-family:\'Cascadia Code\',\'Consolas\',monospace;'
                f'line-height:1.25;">{_esc(hexdump(self.data))}</pre>'
                "</div>"
            )

        return (
            f'<div style="margin:8px 0 12px 0;padding:8px;border:1px solid {c["border_soft"]};'
            f'border-radius:10px;background:{c["panel"]};">'
            f"{header}{fields_html}{notes_html}{hex_html}"
            "</div>"
        )


@dataclass
class PapayaTransaction:
    """A full command transaction with transport-specific response handling."""

    title: str
    frames: List[PapayaFrame]
    seq: int
    func: Optional[str] = None
    subfunc: Optional[str] = None
    block_id: Optional[int] = None
    notes: List[str] = field(default_factory=list)

    def render(self) -> str:
        hdr = f"=== Transaction (seq=0x{self.seq:02X}) {self.title} ==="
        meta_parts: List[str] = []
        if self.func:
            meta_parts.append(f"func={self.func}")
        if self.subfunc:
            meta_parts.append(f"subfunc={self.subfunc}")
        if self.block_id is not None:
            meta_parts.append(f"block_id=0x{self.block_id:04X}")
        if meta_parts:
            hdr += "\n" + "Meta: " + ", ".join(meta_parts)
        if self.notes:
            hdr += "\n" + "Notes: " + " | ".join(self.notes)
        body = "\n\n".join(frame.render() for frame in self.frames)
        return hdr + "\n\n" + body

    def render_html(self, theme: str = "light") -> str:
        c = _palette(theme)
        meta_parts: List[str] = []
        if self.func:
            meta_parts.append(f"func={self.func}")
        if self.subfunc:
            meta_parts.append(f"subfunc={self.subfunc}")
        if self.block_id is not None:
            meta_parts.append(f"block_id=0x{self.block_id:04X}")

        meta_html = ""
        if meta_parts:
            meta_html = (
                f'<div style="margin:2px 0 6px 0;padding:0;color:{c["muted"]};">'
                f"<b>Meta:</b> {_esc(', '.join(meta_parts))}"
                "</div>"
            )

        notes_html = ""
        if self.notes:
            notes_joined = "".join(
                f'<div style="margin:1px 0;color:{c["warning"]};">- {_esc(n)}</div>' for n in self.notes
            )
            notes_html = (
                f'<div style="margin:2px 0 6px 0;padding:0;color:{c["muted"]};">'
                f"<b>Notes:</b>{notes_joined}"
                "</div>"
            )

        frames_html = "".join(frame.render_html(theme=theme) for frame in self.frames)
        return (
            f'<div style="margin:6px 0 10px 0;padding:0;border:none;background:transparent;">'
            f'<div style="margin:0;padding:0;color:{c["accent"]};font-weight:800;">'
            f'Transaction seq=0x{self.seq:02X} | {_esc(self.title)}'
            "</div>"
            f"{meta_html}{notes_html}{frames_html}"
            "</div>"
        )
