var classflanger =
[
    [ "flanger", "classflanger.html#a7a47275bceb52e52f1d91da0a3a67eb2", null ]
];