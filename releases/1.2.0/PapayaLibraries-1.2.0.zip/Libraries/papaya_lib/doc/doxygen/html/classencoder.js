var classencoder =
[
    [ "encoder", "classencoder.html#a35bde3e6c95e92d134ee2aa371c82110", null ],
    [ "encoder", "classencoder.html#a9c42302e767e1dc19f1a9aafc32a8b87", null ]
];