var _papaya_pc_usb_device_8h =
[
    [ "PapayaPcUsbDevice", "class_papaya_pc_usb_device.html", "class_papaya_pc_usb_device" ],
    [ "PAPAYA_USB_DEFAULT_RX_TIMEOUT_MS", "_papaya_pc_usb_device_8h.html#ac92aabee263494ddcdf3be05563237e6", null ],
    [ "PAPAYA_USB_DEFAULT_TX_TIMEOUT_MS", "_papaya_pc_usb_device_8h.html#a10f5e73df301d48b69a181c1cf718c10", null ],
    [ "PAPAYA_USB_EP_IN", "_papaya_pc_usb_device_8h.html#afc9d0b3b15f890f430ea7be887042e2c", null ],
    [ "PAPAYA_USB_EP_OUT", "_papaya_pc_usb_device_8h.html#a708fe03d035a9e9faa8ffc1168ba7430", null ],
    [ "PAPAYA_USB_PRODUCT_ID", "_papaya_pc_usb_device_8h.html#aa2a1160bbf9c254b1f314f5229620dc1", null ],
    [ "PAPAYA_USB_VENDOR_ID", "_papaya_pc_usb_device_8h.html#a650f8aac27982bb228cea6e2eb3e4704", null ]
];