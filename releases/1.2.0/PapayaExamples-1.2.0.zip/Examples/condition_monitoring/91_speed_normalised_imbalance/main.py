"""Speed-normalised unbalance: the board divides out the speed, this script checks that it worked.

Run this beside example 91.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  balance state   the speed-normalised shaft-line amplitude, against the
                  machine's own value when it was known good. Normalised,
                  because an unbalance force is m r omega squared and a raw
                  amplitude therefore changes by a third when the speed
                  changes by a sixth, with nothing wrong.

  is the
  normalisation
  working         the script watches BOTH indicators and reports how much
                  each of them swung while the speed swung. That comparison
                  is the example: if the normalised one swings as much as
                  the raw one, the normalisation is not doing anything and
                  the reason is usually that the two averages do not match.

  tachometer
  health          a keyphasor that misses a pulse reports double the
                  period and half the speed, and everything downstream then
                  divides by four times too little. The script watches for
                  a speed that jumps by a factor near two.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.3

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("balanced", "out of balance")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "normalised"
FEATURES = ("one_x_raw", "one_x_norm", "speed_hz", "speed_ratio_sq",
            "rms", "state")

BASELINE_NORM = 0.0154      # the balanced normalised amplitude, in g
ALERT = 2.0                 # multiple of it
ALARM = 3.0
SPEED_MIN, SPEED_MAX = 20.0, 120.0      # a plausible speed for this rig
SPEED_JUMP = 1.7            # a step this big is a missed or doubled pulse

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

_previous_speed = [None]


def classify(row):
    speed = row["speed_hz"]
    raw, norm = row["one_x_raw"], row["one_x_norm"]
    reasons = [
        f"shaft {speed:.2f} Hz ({speed * 60:.0f} rpm), speed ratio squared "
        f"{row['speed_ratio_sq']:.3f}",
        f"shaft line raw {raw:.4f} g, normalised {norm:.4f} g",
    ]

    # The tachometer first: every number above depends on it.
    if not SPEED_MIN <= speed <= SPEED_MAX:
        return ("tachometer fault",
                f"the keyphasor is reporting {speed:.1f} Hz, which is "
                f"outside anything this machine does",
                reasons + ["check the magnet, the gap and the trigger "
                           "thresholds before reading anything else"])
    last = _previous_speed[0]
    _previous_speed[0] = speed
    if last is not None and last > 0:
        jump = max(speed / last, last / speed)
        if jump >= SPEED_JUMP:
            return ("tachometer fault",
                    f"the speed jumped by {jump:.2f} in one reading",
                    reasons + ["a missed pulse doubles the period and "
                               "halves the speed; a double count does the "
                               "opposite. Neither is a change in the "
                               "machine"])

    level = norm / max(BASELINE_NORM, 1e-12)
    reasons.append(f"normalised amplitude is {level:.2f}x the balanced "
                   f"value")
    reasons.append(
        f"the RAW amplitude is {raw / max(BASELINE_NORM, 1e-12):.2f}x that "
        f"value, and the difference between those two numbers is entirely "
        f"the speed")

    if level >= ALARM:
        return ("out of balance", "badly out of balance", reasons)
    if level >= ALERT:
        return ("out of balance", "out of balance", reasons)
    return ("balanced", "balance is where it was", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 91_speed_normalised_imbalance.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA speed-normalised unbalance monitor")
    print("=" * 72)
    print("An unbalance force grows with the SQUARE of speed, so a raw "
          "amplitude on a\nmachine whose speed is not held says nothing "
          "on its own. This script reads\nboth and reports the difference.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
