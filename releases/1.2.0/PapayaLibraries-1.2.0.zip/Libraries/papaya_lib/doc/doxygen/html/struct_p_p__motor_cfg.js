var struct_p_p__motor_cfg =
[
    [ "cur_max_mA", "struct_p_p__motor_cfg.html#a56c53b65c938d1e19d1a2f1ba3e791e0", null ],
    [ "cur_min_mA", "struct_p_p__motor_cfg.html#a9b8344868caa96493be6abae6a7b05a0", null ],
    [ "dutyLowerLimit", "struct_p_p__motor_cfg.html#a7cb26b082577c0e08c6422b89b585393", null ],
    [ "dutyUpperLimit", "struct_p_p__motor_cfg.html#acb4bd9765beec4318be3640b97bb0d65", null ],
    [ "pos_conv", "struct_p_p__motor_cfg.html#a9bde120d56421c1dd56dad49561c855a", null ],
    [ "pwm_hz", "struct_p_p__motor_cfg.html#adf2ab39e4b844630a6ab2bc4f8b4e033", null ],
    [ "vel_conv", "struct_p_p__motor_cfg.html#a57dac8d61330d430aee546b22f184653", null ],
    [ "vel_tau", "struct_p_p__motor_cfg.html#a7043b4a990840354bee00717239afff9", null ]
];