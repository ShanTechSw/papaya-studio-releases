var classdwt__subband__energy =
[
    [ "dwt_subband_energy", "classdwt__subband__energy.html#a785ea79e80a637a612e20ae2926cb9e1", null ],
    [ "getAssociatedDWT", "classdwt__subband__energy.html#a84fca94c312801e35a304e0996d6dce3", null ],
    [ "operator>", "classdwt__subband__energy.html#adbbb198fd43eb8131bb5a0e14a0dac17", null ],
    [ "operator>", "classdwt__subband__energy.html#a201229da2ea4e4483ed568c77a25d940", null ],
    [ "operator>", "classdwt__subband__energy.html#ab4533b6f6571b8e7b45e5bbf5a8035e1", null ],
    [ "operator>", "classdwt__subband__energy.html#a58b0bb1bad69408760ab891863ba4305", null ],
    [ "associatedDWT", "classdwt__subband__energy.html#ae2cb740a2fc7034bd1e7f459b00c1473", null ]
];