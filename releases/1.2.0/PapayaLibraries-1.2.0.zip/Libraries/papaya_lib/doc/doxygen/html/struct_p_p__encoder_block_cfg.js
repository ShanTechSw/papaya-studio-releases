var struct_p_p__encoder_block_cfg =
[
    [ "config", "struct_p_p__encoder_block_cfg.html#ac306b0fa1512e254c126a90905719a9f", null ],
    [ "id", "struct_p_p__encoder_block_cfg.html#ac6fe330ffd702722d5fdb583cb657697", null ],
    [ "outputCount", "struct_p_p__encoder_block_cfg.html#a28620793f8309bd526bcbd90f5b5afc9", null ],
    [ "outputs", "struct_p_p__encoder_block_cfg.html#a2af7a3b49bd7e490464b578dfd07d9ad", null ]
];