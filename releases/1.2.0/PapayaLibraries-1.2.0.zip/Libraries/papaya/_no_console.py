"""Starting a child process without showing a console window.

On Windows, a console program started by a program that has no console of
its own is given one, and Windows shows it: a small window appears, paints
its own icon, and vanishes when the child exits. Anything launched from a
windowed application therefore has to say that it wants no console, or the
user sees the flash.

This module is the one place that decision is made for this library. Both
helpers return a mapping of keyword arguments to splat into ``subprocess``:

    subprocess.run([tool, "--version"], capture_output=True, **no_window())

Off Windows both return an empty mapping, so a call site can splat one
unconditionally and read the same on every platform.

Which of the two to use depends on whether the child needs a console to
exist at all:

* ``no_window()`` gives the child no console. Right for anything whose
  output you capture or discard, which is almost everything.
* ``hidden_console()`` creates a console and hides it. Right for a batch
  file, or anything run through a shell, which needs a console to exist
  but must not show one.
"""

from __future__ import annotations

import os
import subprocess
from typing import Any, Dict

__all__ = ["no_window", "hidden_console", "IS_WINDOWS"]

IS_WINDOWS = os.name == "nt"

#: 0x08000000. Read through getattr because the attribute exists only on
#: Windows builds of Python, and this module is imported on every platform.
_CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def no_window() -> Dict[str, Any]:
    """``subprocess`` keyword arguments that give the child no console.

    Returns ``{}`` off Windows.
    """
    if not IS_WINDOWS:
        return {}
    return {"creationflags": _CREATE_NO_WINDOW}


def hidden_console() -> Dict[str, Any]:
    """``subprocess`` keyword arguments for a child that needs a console.

    The console is created and hidden rather than suppressed, because a
    batch file or a shell pipeline needs one to exist. Returns ``{}`` off
    Windows.
    """
    if not IS_WINDOWS:
        return {}
    info = subprocess.STARTUPINFO()
    info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow = subprocess.SW_HIDE
    return {"startupinfo": info}
