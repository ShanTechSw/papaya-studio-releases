/**
 * @file    papaya_link_protocol.cpp
 * @brief   The PAPAYA Link wire format. See papaya_link_protocol.h.
 *
 * Deliberately dependency-free: stdint and memcpy, nothing else. A
 * gateway may be built for a target with no heap, no exceptions and no
 * standard library worth the name, and this file has to compile there
 * unchanged.
 */
#include "papaya_link_protocol.h"

#include <string.h>

namespace papaya {
namespace link {

namespace {

/* Little-endian accessors, written out rather than memcpy'd through a
 * struct, because a target that cannot do unaligned loads would fault on
 * the struct and this is the same speed once optimised. */

void putU16(uint8_t *out, uint16_t value)
{
  out[0] = (uint8_t)(value & 0xFFu);
  out[1] = (uint8_t)((value >> 8) & 0xFFu);
}

void putU32(uint8_t *out, uint32_t value)
{
  out[0] = (uint8_t)(value & 0xFFu);
  out[1] = (uint8_t)((value >> 8) & 0xFFu);
  out[2] = (uint8_t)((value >> 16) & 0xFFu);
  out[3] = (uint8_t)((value >> 24) & 0xFFu);
}

void putU64(uint8_t *out, uint64_t value)
{
  for (uint32_t i = 0u; i < 8u; i++)
  {
    out[i] = (uint8_t)((value >> (8u * i)) & 0xFFu);
  }
}

uint16_t getU16(const uint8_t *in)
{
  return (uint16_t)((uint16_t)in[0] | ((uint16_t)in[1] << 8));
}

uint32_t getU32(const uint8_t *in)
{
  return (uint32_t)in[0] | ((uint32_t)in[1] << 8)
       | ((uint32_t)in[2] << 16) | ((uint32_t)in[3] << 24);
}

uint64_t getU64(const uint8_t *in)
{
  uint64_t value = 0u;
  for (uint32_t i = 0u; i < 8u; i++)
  {
    value |= ((uint64_t)in[i]) << (8u * i);
  }
  return value;
}

/* Payload layouts, mirroring the Python side field for field. */
const uint32_t kCmdFixed = 11u;      /* shape u8, hdr u16, body u32, data u32 */
const uint32_t kChunkFixed = 2u;     /* index u16 */
const uint32_t kResultFixed = 8u;    /* outcome u8, reserved u8, u16, u32 */
const uint32_t kSubFixed = 16u;      /* four u16 then two u32 */
const uint32_t kTelemFixed = 16u;    /* u32, u64, u16, u16 */

/* Shapes that answer with a payload whose length nothing on the board's
 * wire announces, so the far end has to state it. A probe read is one of
 * them: the board's own read sizes itself from probe objects a relay
 * never constructed, so without a count it would ask for nothing. */
bool needsDataLength(uint8_t shape)
{
  return (shape == (uint8_t)kShapeConfigWithData)
      || (shape == (uint8_t)kShapeProbeRead);
}

bool knownShape(uint8_t shape)
{
  /* The range must end at the LAST shape, not at whichever one was last
   * when this was written. A new shape added above the bound is refused
   * here, before it ever reaches the dispatch that implements it, and
   * the refusal reads as "the command payload could not be read" -- a
   * framing complaint about a frame that framed perfectly well. */
  return (shape >= (uint8_t)kShapeConfig)
      && (shape <= (uint8_t)kShapeOpcodeOnly);
}

}  /* namespace */

uint32_t crc32Begin(void)
{
  return 0xFFFFFFFFu;
}

uint32_t crc32Update(uint32_t state, const uint8_t *data, uint32_t length)
{
  if (data == 0) { return state; }
  for (uint32_t i = 0u; i < length; i++)
  {
    state ^= (uint32_t)data[i];
    for (uint8_t bit = 0u; bit < 8u; bit++)
    {
      state = (state >> 1) ^ (0xEDB88320u & (uint32_t)(-(int32_t)(state & 1u)));
    }
  }
  return state;
}

uint32_t crc32Finish(uint32_t state)
{
  return state ^ 0xFFFFFFFFu;
}

uint32_t crc32(const uint8_t *data, uint32_t length)
{
  return crc32Finish(crc32Update(crc32Begin(), data, length));
}

/* ==================================================================== */
/* Frames                                                               */
/* ==================================================================== */

uint32_t encodeFrameHeader(uint8_t *out, uint32_t capacity, uint8_t type,
                           uint16_t seq, uint32_t payloadLength)
{
  if (out == 0) { return 0u; }
  if (payloadLength > kMaxPayload) { return 0u; }
  if (capacity < kHeaderSize) { return 0u; }

  putU16(&out[0], kMagic);
  out[2] = kProtocolVersion;
  out[3] = type;
  putU16(&out[4], seq);
  putU32(&out[6], payloadLength);
  return kHeaderSize;
}

uint32_t encodeFrameChecksum(uint8_t *out, uint32_t capacity,
                             uint32_t checksum)
{
  if ((out == 0) || (capacity < kChecksumSize)) { return 0u; }
  putU32(out, checksum);
  return kChecksumSize;
}

uint32_t encodeFrame(uint8_t *out, uint32_t capacity, uint8_t type,
                     uint16_t seq, const uint8_t *payload,
                     uint32_t payloadLength)
{
  if (out == 0) { return 0u; }
  if (payloadLength > kMaxPayload) { return 0u; }
  if ((payloadLength > 0u) && (payload == 0)) { return 0u; }

  const uint32_t total = kFrameOverhead + payloadLength;
  if (capacity < total) { return 0u; }

  encodeFrameHeader(out, capacity, type, seq, payloadLength);
  if (payloadLength > 0u)
  {
    memcpy(&out[kHeaderSize], payload, payloadLength);
  }
  putU32(&out[kHeaderSize + payloadLength],
         crc32(out, kHeaderSize + payloadLength));
  return total;
}

FrameDecoder::FrameDecoder(uint8_t *buffer, uint32_t capacity)
  : buffer_(buffer), capacity_(capacity), held_(0u), want_(0u), discard_(0u),
    state_(kSync), resyncs_(0u), oversized_(0u), versionMismatches_(0u)
{
}

void FrameDecoder::reset(void)
{
  held_ = 0u;
  want_ = 0u;
  discard_ = 0u;
  state_ = kSync;
}

bool FrameDecoder::consume(const uint8_t *data, uint32_t length,
                           uint32_t &used, Frame &out)
{
  used = 0u;
  if ((data == 0) || (length == 0u) || (buffer_ == 0)
      || (capacity_ < kFrameOverhead + 1u))
  {
    return false;
  }

  switch (state_)
  {
    case kDiscard:
    {
      /* An intact-looking frame this host is not sized to hold. Dropped
       * byte by byte as it arrives rather than accumulated, so a corrupt
       * length can neither overflow the buffer nor leave the decoder
       * hunting through a megabyte of payload for a magic. */
      uint32_t take = (length < discard_) ? length : discard_;
      discard_ -= take;
      used = take;
      if (discard_ == 0u) { state_ = kSync; held_ = 0u; }
      return false;
    }

    case kSync:
    {
      /* Hunt for the magic's first byte, then its second. Held one at a
       * time because a magic may straddle two feeds, and discarding a
       * lone trailing byte would lose the frame after the damaged one as
       * well as the damaged one. */
      if (held_ == 0u)
      {
        uint32_t i = 0u;
        while ((i < length) && (data[i] != (uint8_t)(kMagic & 0xFFu))) { i++; }
        if (i == length) { used = length; return false; }
        buffer_[0] = data[i];
        held_ = 1u;
        used = i + 1u;
        return false;
      }
      if (data[0] != (uint8_t)((kMagic >> 8) & 0xFFu))
      {
        /* Not the magic after all. The byte we held may itself start
         * one, so re-examine from scratch rather than swallowing it. */
        held_ = 0u;
        used = 0u;
        if (data[0] == (uint8_t)(kMagic & 0xFFu))
        {
          buffer_[0] = data[0];
          held_ = 1u;
        }
        used = 1u;
        return false;
      }
      buffer_[1] = data[0];
      held_ = 2u;
      used = 1u;
      state_ = kHeader;
      return false;
    }

    case kHeader:
    {
      uint32_t need = kHeaderSize - held_;
      uint32_t take = (length < need) ? length : need;
      memcpy(&buffer_[held_], data, take);
      held_ += take;
      used = take;
      if (held_ < kHeaderSize) { return false; }

      const uint32_t payloadLength = getU32(&buffer_[6]);
      if (payloadLength > kMaxPayload)
      {
        /* A length no real message reaches means this was never a frame
         * boundary. Treat it as damage and hunt again. */
        resyncs_++;
        held_ = 0u;
        state_ = kSync;
        return false;
      }
      if (kFrameOverhead + payloadLength > capacity_)
      {
        /* Plausible, but larger than this host can hold. Skip it whole:
         * see the note in kDiscard. */
        oversized_++;
        discard_ = payloadLength + kChecksumSize;
        held_ = 0u;
        state_ = kDiscard;
        return false;
      }
      want_ = kHeaderSize + payloadLength + kChecksumSize;
      state_ = kBody;
      return false;
    }

    case kBody:
    default:
    {
      uint32_t need = want_ - held_;
      uint32_t take = (length < need) ? length : need;
      memcpy(&buffer_[held_], data, take);
      held_ += take;
      used = take;
      if (held_ < want_) { return false; }

      const uint32_t payloadLength = want_ - kFrameOverhead;
      const uint32_t seen = getU32(&buffer_[kHeaderSize + payloadLength]);
      state_ = kSync;
      held_ = 0u;

      if (seen != crc32(buffer_, kHeaderSize + payloadLength))
      {
        /* We WERE aligned, so this is damage rather than noise, and the
         * next frame boundary is somewhere after it. */
        resyncs_++;
        return false;
      }

      const uint8_t version = buffer_[2];
      if (version != kProtocolVersion)
      {
        /* Intact but unspeakable. Counted rather than guessed at: the
         * two ends disagree about the header they would have to
         * negotiate in. */
        versionMismatches_++;
        return false;
      }

      out.type = buffer_[3];
      out.version = version;
      out.seq = getU16(&buffer_[4]);
      out.payload = (payloadLength > 0u) ? &buffer_[kHeaderSize] : 0;
      out.payloadLength = payloadLength;
      return true;
    }
  }
}

/* ==================================================================== */
/* Payload codecs                                                       */
/* ==================================================================== */

uint32_t encodeCommand(uint8_t *out, uint32_t capacity, uint8_t shape,
                       const uint8_t *header, uint16_t headerLength,
                       const uint8_t *firstChunk, uint32_t firstChunkLength,
                       uint32_t totalBodyLength, uint32_t expectedData)
{
  if ((out == 0) || !knownShape(shape)) { return 0u; }
  if (firstChunkLength > (uint32_t)kBoardChunkSize) { return 0u; }
  if (totalBodyLength < firstChunkLength) { return 0u; }
  if (needsDataLength(shape) && (expectedData == 0u)) { return 0u; }
  if (!needsDataLength(shape) && (expectedData != 0u)) { return 0u; }

  const uint32_t total = kCmdFixed + headerLength + firstChunkLength;
  if (capacity < total) { return 0u; }

  out[0] = shape;
  putU16(&out[1], headerLength);
  putU32(&out[3], totalBodyLength);
  putU32(&out[7], expectedData);
  if (headerLength > 0u) { memcpy(&out[kCmdFixed], header, headerLength); }
  if (firstChunkLength > 0u)
  {
    memcpy(&out[kCmdFixed + headerLength], firstChunk, firstChunkLength);
  }
  return total;
}

bool decodeCommand(const uint8_t *payload, uint32_t length, Command &out)
{
  if ((payload == 0) || (length < kCmdFixed)) { return false; }

  const uint8_t shape = payload[0];
  const uint16_t headerLength = getU16(&payload[1]);
  if (!knownShape(shape)) { return false; }
  if (length < kCmdFixed + (uint32_t)headerLength) { return false; }

  const uint32_t chunkLength = length - kCmdFixed - (uint32_t)headerLength;
  if (chunkLength > (uint32_t)kBoardChunkSize) { return false; }

  out.shape = shape;
  out.headerLength = headerLength;
  out.header = (headerLength > 0u) ? &payload[kCmdFixed] : 0;
  out.firstChunk = (chunkLength > 0u)
                 ? &payload[kCmdFixed + headerLength] : 0;
  out.firstChunkLength = chunkLength;
  out.totalBodyLength = getU32(&payload[3]);
  out.expectedData = getU32(&payload[7]);
  return true;
}

uint32_t encodeCommandChunk(uint8_t *out, uint32_t capacity, uint16_t index,
                            const uint8_t *chunk, uint32_t chunkLength)
{
  if (out == 0) { return 0u; }
  if (chunkLength > (uint32_t)kBoardChunkSize) { return 0u; }
  if (capacity < kChunkFixed + chunkLength) { return 0u; }

  putU16(&out[0], index);
  if (chunkLength > 0u) { memcpy(&out[kChunkFixed], chunk, chunkLength); }
  return kChunkFixed + chunkLength;
}

bool decodeCommandChunk(const uint8_t *payload, uint32_t length,
                        uint16_t &index, const uint8_t *&chunk,
                        uint32_t &chunkLength)
{
  if ((payload == 0) || (length < kChunkFixed)) { return false; }
  const uint32_t size = length - kChunkFixed;
  if (size > (uint32_t)kBoardChunkSize) { return false; }

  index = getU16(&payload[0]);
  chunk = (size > 0u) ? &payload[kChunkFixed] : 0;
  chunkLength = size;
  return true;
}

uint32_t encodeCommandResultHeader(uint8_t *out, uint32_t capacity,
                                   uint8_t outcome, uint16_t statusLength,
                                   uint32_t dataLength)
{
  if ((out == 0) || (capacity < kResultFixed)) { return 0u; }

  out[0] = outcome;
  out[1] = 0u;                                   /* reserved */
  putU16(&out[2], statusLength);
  putU32(&out[4], dataLength);
  return kResultFixed;
}

uint32_t encodeCommandResult(uint8_t *out, uint32_t capacity, uint8_t outcome,
                             const uint8_t *status, uint16_t statusLength,
                             const uint8_t *data, uint32_t dataLength)
{
  if (out == 0) { return 0u; }
  const uint32_t total = kResultFixed + (uint32_t)statusLength + dataLength;
  if (capacity < total) { return 0u; }

  encodeCommandResultHeader(out, capacity, outcome, statusLength, dataLength);
  if (statusLength > 0u)
  {
    memcpy(&out[kResultFixed], status, statusLength);
  }
  if (dataLength > 0u)
  {
    memcpy(&out[kResultFixed + statusLength], data, dataLength);
  }
  return total;
}

bool decodeCommandResult(const uint8_t *payload, uint32_t length,
                         CommandResult &out)
{
  if ((payload == 0) || (length < kResultFixed)) { return false; }

  const uint16_t statusLength = getU16(&payload[2]);
  const uint32_t dataLength = getU32(&payload[4]);
  if (length < kResultFixed + (uint32_t)statusLength + dataLength)
  {
    return false;
  }

  out.outcome = payload[0];
  out.statusLength = statusLength;
  out.status = (statusLength > 0u) ? &payload[kResultFixed] : 0;
  out.dataLength = dataLength;
  out.data = (dataLength > 0u)
           ? &payload[kResultFixed + statusLength] : 0;
  return true;
}

uint32_t encodeSubscribe(uint8_t *out, uint32_t capacity,
                         const Subscription &subscription)
{
  if (out == 0) { return 0u; }
  if ((subscription.scalarBytes == 0u) && (subscription.vectorBytes == 0u))
  {
    return 0u;
  }
  if (subscription.intervalMs == 0u) { return 0u; }
  if (capacity < kSubFixed) { return 0u; }

  putU16(&out[0], subscription.probeCount);
  putU16(&out[2], subscription.samplesPerBatch);
  putU16(&out[4], subscription.vectorCount);
  putU16(&out[6], subscription.intervalMs);
  putU32(&out[8], subscription.scalarBytes);
  putU32(&out[12], subscription.vectorBytes);
  return kSubFixed;
}

bool decodeSubscribe(const uint8_t *payload, uint32_t length,
                     Subscription &out)
{
  if ((payload == 0) || (length < kSubFixed)) { return false; }

  const uint32_t scalarBytes = getU32(&payload[8]);
  const uint32_t vectorBytes = getU32(&payload[12]);
  const uint16_t intervalMs = getU16(&payload[6]);
  if ((scalarBytes == 0u) && (vectorBytes == 0u)) { return false; }
  if (intervalMs == 0u) { return false; }

  out.probeCount = getU16(&payload[0]);
  out.samplesPerBatch = getU16(&payload[2]);
  out.vectorCount = getU16(&payload[4]);
  out.intervalMs = intervalMs;
  out.scalarBytes = scalarBytes;
  out.vectorBytes = vectorBytes;
  return true;
}

uint32_t encodeTelemetry(uint8_t *out, uint32_t capacity, uint32_t batchSeq,
                         uint64_t timestampUs, uint16_t probeCount,
                         uint16_t samplesPerProbe, const uint8_t *samples,
                         uint32_t samplesLength)
{
  if (out == 0) { return 0u; }
  if (capacity < kTelemFixed + samplesLength) { return 0u; }

  putU32(&out[0], batchSeq);
  putU64(&out[4], timestampUs);
  putU16(&out[12], probeCount);
  putU16(&out[14], samplesPerProbe);
  if (samplesLength > 0u)
  {
    memcpy(&out[kTelemFixed], samples, samplesLength);
  }
  return kTelemFixed + samplesLength;
}

uint32_t encodeWelcome(uint8_t *out, uint32_t capacity,
                       uint32_t maxBatchBytes)
{
  if (out == 0) { return 0u; }
  if (capacity < 4u) { return 0u; }
  putU32(&out[0], maxBatchBytes);
  return 4u;
}

bool decodeWelcome(const uint8_t *payload, uint32_t length,
                   uint32_t &maxBatchBytes)
{
  /* AT LEAST four bytes, not exactly four. A later version may add a
   * field, and a decoder that insisted on the exact length would read
   * that as a damaged frame and throw away a welcome it understands the
   * whole of. */
  if ((payload == 0) || (length < 4u)) { return false; }
  maxBatchBytes = getU32(payload);
  return true;
}

bool decodeTelemetry(const uint8_t *payload, uint32_t length,
                     TelemetryBatch &out)
{
  if ((payload == 0) || (length < kTelemFixed)) { return false; }

  out.batchSeq = getU32(&payload[0]);
  out.timestampUs = getU64(&payload[4]);
  out.probeCount = getU16(&payload[12]);
  out.samplesPerProbe = getU16(&payload[14]);
  out.samplesLength = length - kTelemFixed;
  out.samples = (out.samplesLength > 0u) ? &payload[kTelemFixed] : 0;
  return true;
}

}  /* namespace link */
}  /* namespace papaya */
