var classellip_bq =
[
    [ "ellipBq", "classellip_bq.html#a9114daedeef885a23ba906024c0459ce", null ],
    [ "ellipBq", "classellip_bq.html#aaf856fbe87ddf3437eff976c4a93ce58", null ]
];