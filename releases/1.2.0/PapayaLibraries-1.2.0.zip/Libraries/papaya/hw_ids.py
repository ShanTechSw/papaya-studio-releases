"""One place that turns a hardware identifier into a hardware identifier.

Everything that needs to know which pin a block addresses comes through
here. Before this module there were four separate places that treated the
identifier's *spelling* as data:

* one parsed the channel number out of the text after the last underscore,
* one passed the text where a number was wanted, so the call raised
  ``int() argument`` and a whole output mode was unreachable,
* nine substituted channel 1 whenever the identifier was missing,
* and one keyed a hardware constraint on the exact spelling of two names.

All four are the same mistake, and a rename is exactly the event that turns
it from harmless into a design running on the wrong pin. So the rule is:
**an identifier is resolved, never read.**

Why this refuses rather than defaults
-------------------------------------
``resolve`` raises on anything it does not recognise. That is deliberate
and it is the safer half of dropping the deprecated aliases: with no
fallback there is no second chance, so a spelling that no longer exists
stops the design instead of quietly addressing channel 1. A default here
would turn a missed migration into a silent miswire, which is the failure
this whole module exists to prevent.

The wire values never move, so an identifier is also freely convertible to
and from its number, and code that has one does not need to care which it
was handed.
"""
from __future__ import annotations

from typing import Any, Optional

from .enums import PP_HwId

__all__ = ["resolve", "resolve_or_none", "routine_index", "wire_value",
           "migrate", "LEGACY_NAMES", "UnknownHardwareId"]


def _legacy_map() -> "dict[str, str]":
    """Old identifier spelling to new, for designs saved before the change.

    The rule is the silkscreen designator with its spaces removed, so most
    of this is mechanical. It is written out rather than derived because a
    migration table has to keep describing the past after the present has
    moved on: derive it from today's names and it silently becomes the
    identity the moment they change again.

    There are no aliases anywhere else. This map exists for exactly one
    moment, when a saved design is read, and nothing consults it
    afterwards. A spelling that reaches the resolver unmigrated is refused,
    which is what makes a missed load path loud instead of silent.
    """
    out = {}
    for n in range(1, 11):
        out[f"AN_IN_{n}"] = f"AIN{n}"
    for n in range(1, 6):
        out[f"AN_OUT_{n}"] = f"AO{n}"
    for n in range(1, 9):
        out[f"PWM_OUT_{n}"] = f"FO{n}"
    for n in range(1, 6):
        out[f"PWM_IN_PULSE_{n}"] = f"FI{n}_PULSE"
        out[f"PWM_IN_PERIOD_{n}"] = f"FI{n}_PERIOD"
        out[f"PWM_IN_DELAY_{n}"] = f"FI{n}_DELAY"
    for n in (1, 2):
        out[f"ENCODER_{n}"] = f"ENC{n}"
        out[f"DC_MOT_{n}"] = f"MOTOR{n}"
        out[f"SPEAKER_{n}"] = f"SPEAKER{n}"
    # The microphones moved twice. MIC_1 and MIC_2 are the spellings
    # from before the silkscreen alignment; MIC1 and MIC2 are the ones
    # it produced, correct only while the board still printed MIC 1 and
    # MIC 2. Both eras have to arrive at the name the board prints now.
    for old, new in (("MIC_1", "MIC_L"), ("MIC1", "MIC_L"),
                     ("MIC_2", "MIC_R"), ("MIC2", "MIC_R")):
        out[old] = new
    for n in range(1, 5):
        out[f"EXT_SENSOR_SPI_{n}"] = f"SPI{n}"
        out[f"EXT_SENSOR_I2C_{n}"] = f"I2C{n}"
    return out


#: The 56 identifiers that moved. ``IMU_ACC``, ``IMU_GYR``, ``IMU_MAG``,
#: ``RECORDER_1``, ``REPLAY_1`` and ``NoHwRoutine`` are absent because they
#: name on-board parts, flash slots and a sentinel, none of which the board
#: prints a label for.
LEGACY_NAMES = _legacy_map()


def migrate_tree(node: Any) -> int:
    """Rewrite every ``hw_id`` in a loaded project, in place. Returns how many.

    Deliberately a blind recursive walk rather than a tour of the known
    places. A design carries identifiers in a block's parameters, in the
    ``config_array`` of a multi-channel block, and again inside every macro
    subgraph, nested to any depth. Enumerating those is how a migration
    misses one, and a missed one is not cosmetic: with the aliases gone
    there is no fallback, so an unmigrated spelling reaches :func:`resolve`
    and stops the design.

    That refusal is the safety net and it is meant to be. This is what
    keeps it from firing on a user's own file.

    Running it twice is a no-op, because a new spelling is not a key in the
    table. It lives here rather than in the editor so that every tool and
    test can migrate a design without importing a GUI.
    """
    converted = 0
    if isinstance(node, dict):
        for key, value in list(node.items()):
            if key == "hw_id" and isinstance(value, str):
                new = migrate(value)
                if new != value:
                    node[key] = new
                    converted += 1
            else:
                converted += migrate_tree(value)
    elif isinstance(node, list):
        for value in node:
            converted += migrate_tree(value)
    return converted


def migrate(value: Any) -> Any:
    """Rewrite one old identifier spelling. Anything else passes through.

    Deliberately total and deliberately quiet: it is called on values that
    may not be identifiers at all, and its job is to leave those alone.
    Rejecting what it does not recognise is :func:`resolve`'s job, one
    layer later, once the value is actually being used.
    """
    if isinstance(value, str):
        return LEGACY_NAMES.get(value.strip(), value)
    return value


class UnknownHardwareId(ValueError):
    """A hardware identifier that does not name anything on the board.

    Carries the offending value so a caller can say which block was wrong
    rather than only that something was.
    """

    def __init__(self, value: Any, *, context: str = "") -> None:
        self.value = value
        where = f" ({context})" if context else ""
        super().__init__(
            f"{value!r} does not name any hardware on this board{where}. "
            f"If this came from a saved design, that design predates the "
            f"identifier naming change and its migration did not run."
        )


def resolve(value: Any, *, context: str = "") -> PP_HwId:
    """Return the :class:`PP_HwId` *value* denotes, or raise.

    Accepts the member itself, its name, or its wire number, in either
    ``int`` or ``str`` form, because those are the three shapes an
    identifier arrives in: from the catalogue, from a ``.pap`` file, and
    from a decoded frame.

    ``context`` is folded into the message so a failure names the block it
    came from rather than leaving the caller to guess.
    """
    if isinstance(value, PP_HwId):
        return value

    # bool is an int subclass, and True would otherwise resolve to DC_MOT_2.
    if isinstance(value, int) and not isinstance(value, bool):
        try:
            return PP_HwId(value)
        except ValueError:
            raise UnknownHardwareId(value, context=context) from None

    if isinstance(value, str):
        text = value.strip()
        if not text:
            raise UnknownHardwareId(value, context=context)
        # A qualified spelling, PP_HwId.AN_IN_1, is what a round trip
        # through str() of the enum produces, and it reaches here from
        # generated code being read back.
        if "." in text:
            text = text.rsplit(".", 1)[-1]
        try:
            return PP_HwId[text]
        except KeyError:
            pass
        try:
            return PP_HwId(int(text, 0))
        except (ValueError, KeyError):
            raise UnknownHardwareId(value, context=context) from None

    raise UnknownHardwareId(value, context=context)


def resolve_or_none(value: Any) -> Optional[PP_HwId]:
    """:func:`resolve`, but ``None`` for an absent identifier.

    For the blocks that legitimately have none. It still raises on a value
    that is present and wrong, because "present and wrong" is the case
    worth hearing about.
    """
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    return resolve(value)


def wire_value(value: Any, *, context: str = "") -> int:
    """The number that crosses USB and SPI for *value*.

    This is the contract with boards already flashed, so it is derived
    from the enum and never from the spelling.
    """
    return int(resolve(value, context=context))


def routine_index(value: Any, *, context: str = "") -> int:
    """The zero-based index of *value* within its family.

    Derived from the wire value, which is what the firmware indexes by,
    rather than from the digits at the end of the name. ``AN_IN_10``
    yields 9 whether it is spelled that way or any other.

    One sharp edge, stated rather than hidden: the external-sensor SPI and
    I2C ports share a family base, so ``EXT_SENSOR_SPI_1`` yields 0 and
    ``EXT_SENSOR_I2C_1`` yields 4, continuing the same run. That is the
    firmware's own numbering. Callers wanting a per-connector port number
    must not use this for those two families.
    """
    return int(resolve(value, context=context)) & 0xFF
