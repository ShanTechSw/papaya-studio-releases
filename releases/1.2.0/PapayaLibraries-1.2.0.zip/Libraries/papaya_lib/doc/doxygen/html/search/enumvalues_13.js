var searchData=
[
  ['wrongcrc_0',['WrongCrc',['../_p_a_p_a_y_a_8h.html#a45ad2d7cd4a5a32dbd1434a6c4ddf453aecd90787bf458436daaf42a33aa41e81',1,'PAPAYA.h']]],
  ['wrongseqnumber_1',['WrongSeqNumber',['../_p_a_p_a_y_a_8h.html#a45ad2d7cd4a5a32dbd1434a6c4ddf453a94102b929a53c07ca0c876abfa2b5325',1,'PAPAYA.h']]]
];
