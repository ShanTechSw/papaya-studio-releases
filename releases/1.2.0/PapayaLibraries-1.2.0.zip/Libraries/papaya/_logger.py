r"""
Structured logging for Papaya Studio.

Writes to %LOCALAPPDATA%\Papaya Studio\logs\studio.log with rotation
(keep last 5 x 5 MiB). Format:

    2026-05-15T16:23:45 | INFO    | papaya.startup | message text...

Idempotent: `configure()` can be called multiple times without
attaching duplicate handlers. Safe in dev mode: writes to the same
per-user location whether running frozen or via `python main.py`.
"""

from __future__ import annotations

import logging
import logging.handlers

from . import _app_paths


_LOG_FILE_NAME = "studio.log"
_LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
_DATEFMT = "%Y-%m-%dT%H:%M:%S"
_MAX_BYTES = 5 * 1024 * 1024
_BACKUPS = 5

_configured = False


def configure(level: int = logging.INFO) -> logging.Logger:
    """Wire the file handler onto the `papaya` logger. Idempotent."""
    global _configured
    root = logging.getLogger("papaya")
    if _configured:
        return root

    log_path = _app_paths.logs_dir() / _LOG_FILE_NAME
    handler = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=_MAX_BYTES, backupCount=_BACKUPS, encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATEFMT))
    root.addHandler(handler)
    root.setLevel(level)
    _configured = True
    root.info("Logger configured (file=%s)", log_path)
    return root


def logger(name: str = "papaya") -> logging.Logger:
    """Get a configured logger. Configures lazily on first call."""
    if not _configured:
        configure()
    return logging.getLogger(name)
