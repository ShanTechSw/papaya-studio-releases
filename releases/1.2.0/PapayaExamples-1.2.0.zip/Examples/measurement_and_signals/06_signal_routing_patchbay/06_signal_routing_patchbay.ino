/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe selected;
probe ch0;
probe ch1;
probe ch2;
probe fan0;
probe fan1;

input const_;
input demux_select;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  demux_select = input("demux_select", 0.0f);
  signalSource Sine = signalSource::sine(10.0f, 0.0f);
  signalSource Square = signalSource::square(10.0f, 0.0f);
  signalSource Saw = signalSource::sawtooth(10.0f, 0.0f, 0);
  const_ = input("const", 0.0f);
  expander fan_3 = expander(3);
  expander fan_3_2 = expander(3);
  expander fan_3_3 = expander(3);
  mux Mux = mux(3);
  switchBlock A_B_switch = switchBlock();
  merger Merger = merger(3);
  demux Demux = demux(3);
  expander Expander = expander(2);
  selected = probe("selected");
  ch0 = probe("ch0");
  ch1 = probe("ch1");
  ch2 = probe("ch2");
  fan0 = probe("fan_out_0");
  fan1 = probe("fan_out_1");

  /* Connect Blocks */
  demux_select > Demux.in(1);
  Sine > fan_3;
  Square > fan_3_2;
  Saw > fan_3_3;
  const_ > Mux.in(3);
  fan_3.out(0) > Mux.in(0);
  fan_3.out(1) > A_B_switch.in(0);
  fan_3.out(2) > Merger.in(0);
  fan_3_2.out(0) > Mux.in(1);
  fan_3_2.out(1) > A_B_switch.in(1);
  fan_3_2.out(2) > Merger.in(1);
  fan_3_3.out(0) > Mux.in(2);
  fan_3_3.out(1) > A_B_switch.in(2);
  fan_3_3.out(2) > Merger.in(2);
  Mux > Demux.in(0);
  A_B_switch > selected;
  Merger > Expander;
  Demux.out(0) > ch0;
  Demux.out(1) > ch1;
  Demux.out(2) > ch2;
  Expander.out(0) > fan0;
  Expander.out(1) > fan1;

  /* Enable Remote Input Control */
  demux_select.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    selected.show();
    ch0.show();
    ch1.show();
    ch2.show();
    fan0.show();
    fan1.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}