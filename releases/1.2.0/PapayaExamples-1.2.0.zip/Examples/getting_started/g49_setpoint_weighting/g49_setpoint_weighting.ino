/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe command;
probe measured;

input b_weight;
input c_weight;
input kp_fixed;
input ki_fixed;
input kd_fixed;
input tau_fixed;

/* Global Array Declarations */
float Plant_numerator[] = {1.0f};
float Plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  b_weight = input("b_weight", 1.0f);
  c_weight = input("c_weight", 0.0f);
  signalSource Source = signalSource::square(0.4f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  kp_fixed = input("kp_fixed", 2.0f);
  ki_fixed = input("ki_fixed", 1.0f);
  kd_fixed = input("kd_fixed", 0.05f);
  tau_fixed = input("tau_fixed", 0.02f);
  live2Pid Two_degrees_of_freedom = live2Pid();
  tf Plant = tf(Plant_numerator, 1, Plant_denominator, 2);
  expander Feedback = expander(2);
  command = probe("command");
  measured = probe("measured");

  /* Connect Blocks */
  b_weight > Two_degrees_of_freedom.in(6);
  c_weight > Two_degrees_of_freedom.in(7);
  Source > Two_degrees_of_freedom.in(0);
  kp_fixed > Two_degrees_of_freedom.in(2);
  ki_fixed > Two_degrees_of_freedom.in(3);
  kd_fixed > Two_degrees_of_freedom.in(4);
  tau_fixed > Two_degrees_of_freedom.in(5);
  Two_degrees_of_freedom > Plant;
  Two_degrees_of_freedom > command;
  Plant > Feedback;
  Feedback.out(0) > Two_degrees_of_freedom.in(1);
  Feedback.out(1) > measured;

  /* Enable Remote Input Control */
  b_weight.enableRemote();
  c_weight.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    command.show();
    measured.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}