var dir_a2a9761229e342813a45b51950f4e12f =
[
    [ "PapayaLinuxSpidevBackend.h", "_papaya_linux_spidev_backend_8h.html", "_papaya_linux_spidev_backend_8h" ]
];