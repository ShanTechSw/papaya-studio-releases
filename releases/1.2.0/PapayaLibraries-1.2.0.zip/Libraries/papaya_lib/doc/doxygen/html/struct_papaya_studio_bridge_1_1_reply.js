var struct_papaya_studio_bridge_1_1_reply =
[
    [ "payload", "struct_papaya_studio_bridge_1_1_reply.html#aec67c420175d46544046698518499815", null ],
    [ "status", "struct_papaya_studio_bridge_1_1_reply.html#a58e6ae28c3e801d241defec6e93e9a68", null ]
];