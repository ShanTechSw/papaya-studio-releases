var classbutter =
[
    [ "butter", "classbutter.html#a81d9e24664a5ebfd7fee9d2b91be4773", null ],
    [ "butter", "classbutter.html#a061502d12732e567d4740214ed22fadd", null ]
];