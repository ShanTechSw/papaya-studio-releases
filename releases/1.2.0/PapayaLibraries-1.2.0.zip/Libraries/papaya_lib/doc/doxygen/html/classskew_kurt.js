var classskew_kurt =
[
    [ "skewKurt", "classskew_kurt.html#a811e4cc051c0ee4a407221d778fe78c8", null ]
];