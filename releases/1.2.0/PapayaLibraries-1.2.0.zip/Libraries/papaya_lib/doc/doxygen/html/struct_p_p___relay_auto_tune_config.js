var struct_p_p___relay_auto_tune_config =
[
    [ "hysteresis", "struct_p_p___relay_auto_tune_config.html#a28c94f80311c3f08fc58f781c5db9de9", null ],
    [ "min_cycles", "struct_p_p___relay_auto_tune_config.html#a936d2de49dc9b16e2542412467cb51dd", null ],
    [ "relay_amplitude", "struct_p_p___relay_auto_tune_config.html#af6378ed1a13a744c94110e7224e120fc", null ],
    [ "setpoint", "struct_p_p___relay_auto_tune_config.html#ae0afc40e1c78157015103d93df156a67", null ],
    [ "tuning_rule", "struct_p_p___relay_auto_tune_config.html#ab1a9e20741a3b56f776aceda575c3532", null ]
];