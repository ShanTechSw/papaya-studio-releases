/**
 * @file    PAPAYA.h
 * @brief   Public C++ API for the PAPAYA host library.
 *
 * Declares the @c PAPAYA class plus the on-the-wire command opcodes,
 * V2 protocol constants, and ID bases shared with the firmware and the
 * Python @c papaya/ package. See @ref index "main page" for usage and
 * the host transport contract.
 */
#ifndef PAPAYA_H
#define PAPAYA_H

/* ---------------------------------------------------------------------
 * Target profile
 * ---------------------------------------------------------------------
 * A generated project may drop a ``papaya_target_config.h`` next to this
 * header to size the library for the machine it will run on. PAPAYA
 * Studio writes one into every microcontroller export; a PC or Raspberry
 * Pi export has no reason to and does not, so a host build keeps the
 * generous defaults below unchanged.
 *
 * Why a header rather than a -D build flag: the Arduino IDE has no
 * per-sketch compiler flags at all, and this library is a separate
 * translation unit from the sketch, so a #define written into the
 * generated design header would never reach PAPAYA.cpp. A header beside
 * the library reaches every translation unit that uses it, in every one
 * of the four build systems, and the user can read and edit it.
 */
#if defined(__has_include)
#  if __has_include("papaya_target_config.h")
#    include "papaya_target_config.h"
#  endif
#endif

/**
 * @brief 1 when this library is being built for a microcontroller.
 *
 * Auto-detected from the toolchain when nothing has said: the Arduino
 * cores always define @c ARDUINO, an STM32CubeIDE HAL project always
 * defines @c USE_HAL_DRIVER. Set it explicitly in
 * ``papaya_target_config.h`` to override the guess.
 *
 * It selects the buffer sizes below, and nothing else: the protocol, the
 * command set and the API are identical on every host.
 */
#ifndef PAPAYA_TARGET_MCU
#  if defined(ARDUINO) || defined(USE_HAL_DRIVER) || defined(__AVR__)
#    define PAPAYA_TARGET_MCU 1
#  else
#    define PAPAYA_TARGET_MCU 0
#  endif
#endif

#include "Arduino.h"
#include "SPI.h"
/* The four control lines the host drives itself, as Arduino pin numbers.
 *
 * The defaults are the Arduino Uno R3 shield positions PAPAYA's J7
 * connector presents: D2 reset, D9 and D8 address select, D10 chip
 * select. A host whose footprint matches J7 needs none of this.
 *
 * They are overridable because on some hosts the Arduino pin number
 * that carries a given shield pad is NOT the same number. On an ESP32
 * the Arduino pin number IS the GPIO number, so a board whose Uno
 * footprint routes D10 to GPIO5 must be told so; and on parts whose
 * flash bus occupies GPIO6 to GPIO11, taking the defaults would drive
 * the pins the program is executing from.
 *
 * Define any of them ahead of this header, or from the build (for
 * example ``-D PP_CS_PIN=5``), and the value here is left alone. The
 * SPI clock, MISO and MOSI lines are not listed: those belong to the
 * SPIClass handed to begin(), and every core routes them itself.
 */
#ifndef PP_RESET_PIN
#  define PP_RESET_PIN 2
#endif
#ifndef PP_ID_PIN_2
#  define PP_ID_PIN_2 9
#endif
#ifndef PP_ID_PIN_1
#  define PP_ID_PIN_1 8
#endif
#ifndef PP_CS_PIN
#  define PP_CS_PIN 10
#endif

#define PP_CMD_WRITE 0x00u
#define PP_CMD_READ 0x01u
#define PP_CMD_READ_VECT_PROBE 0x02u
#define PP_CMD_SWITCH_BACK_TO_CFG 0x03u
#define PP_CMD_FLOW_CREDIT 0x04u

/* V2 Protocol constants */
#define PP_V2_HANDSHAKE_MAGIC 0x5041u       /* "PA" */
#define PP_V2_BATCH_MAGIC 0x44455347u       /* "DESG" */
#define PP_V2_PROTOCOL_VERSION 0x02u
#define PP_V2_HANDSHAKE_SIZE 8u
#define PP_V2_BATCH_HEADER_SIZE 14u
#define PP_V2_BATCH_RESPONSE_SIZE 13u

#define PP_NODE_ID_BASE 0x1000u
#define PP_SYS_ID_BASE 0x2000u
#define PP_MACRO_ID_BASE 0x3000u
#define PP_INPUT_ID_BASE 0x4000u
#define PP_PROBE_ID_BASE 0x5000u
#define PP_VECTOR_PROBE_ID_BASE 0x6000u

#define PP_INT_SIZE 4u
#define PP_REAL_SIZE 4u
#define PP_UINT8_SIZE 1u
#define PP_UINT16_SIZE 2u
#define PP_UINT32_SIZE 4u
#define PP_PARAM_DESC_SIZE PP_UINT16_SIZE
#define PP_PARAM_DESC_ID_SHIFT 12u
#define PP_PARAM_DESC_ID_MASK 0xF000u
#define PP_PARAM_DESC_SIZE_MASK 0x0FFFu
#define PP_PARAM_DESC_MAX_ID 0x0Fu
#define PP_PARAM_DESC_MAX_SIZE PP_PARAM_DESC_SIZE_MASK
#define PP_PARAM_ID_SIZE 0u
#define PP_PARAM_SIZE_SIZE PP_PARAM_DESC_SIZE
#define PP_PARAM_INFO_SIZE PP_PARAM_DESC_SIZE

#define PP_ELLIP_CFG_SIZE PP_UINT8_SIZE
#define PP_CHEBYX_CFG_SIZE PP_UINT8_SIZE
#define PP_C2D_ALGO_SIZE PP_UINT8_SIZE
#define PP_NODE_TYPE_SIZE PP_UINT8_SIZE
#define PP_DESIGN_STATUS_SIZE PP_UINT8_SIZE
#define PP_COM_STATUS_SIZE PP_UINT8_SIZE
#define PP_HW_ROUTINE_ID_SIZE PP_UINT16_SIZE
#define PP_WAVE_FORM_SIZE PP_UINT16_SIZE
#define PP_SPECIAL_SYS_FUNC_SIZE PP_UINT16_SIZE
#define PP_ONE_BAND_FILTER_SIZE PP_UINT32_SIZE
#define PP_TWO_BANDS_FILTER_SIZE PP_UINT32_SIZE
#define PP_SPECIAL_FILTER_SIZE PP_UINT16_SIZE
#define PP_MON_INTERFACE_SIZE PP_UINT8_SIZE
#define PP_FUNC_PARAM_ID_SIZE PP_UINT8_SIZE
#define PP_blockID_SIZE PP_UINT16_SIZE
#define PP_BAUDRATE_SIZE PP_UINT32_SIZE

#define PP_ELLIP_CFG_TYPE TYPE_Uint8
#define PP_CHEBYX_CFG_TYPE TYPE_Uint8
#define PP_C2D_ALGO_TYPE TYPE_Uint8
#define PP_NODE_TYPE_TYPE TYPE_Uint8
#define PP_DESIGN_STATUS_TYPE TYPE_Uint8
#define PP_COM_STATUS_TYPE TYPE_Uint8
#define PP_HW_ROUTINE_ID_TYPE TYPE_Uint16
#define PP_WAVE_FORM_TYPE TYPE_Uint16
#define PP_SPECIAL_SYS_FUNC_TYPE TYPE_Uint16
#define PP_ONE_BAND_FILTER_TYPE TYPE_Uint32
#define PP_TWO_BANDS_FILTER_TYPE TYPE_Uint32
#define PP_SPECIAL_FILTER_TYPE TYPE_Uint16
#define PP_MON_INTERFACE_TYPE TYPE_Uint8
#define PP_block_ID_TYPE TYPE_Uint16
#define PP_BAUDRATE_TYPE TYPE_Uint32

#define ParamC2dAlgo(X) ParamUint8 = (uint8_t)(X)
#define ParamNodeType(X) ParamUint8 = (uint8_t)(X)
#define ParamDesignStatus(X) ParamUint8 = (uint8_t)(X)
#define ParamComStatus(X) ParamUint8 = (uint8_t)(X)
#define ParamHwRoutineId(X) ParamUint16 = (uint16_t)(X)
#define ParamWaveForm(X) ParamUint16 = (uint16_t)(X)
#define ParamSpecialSysFunc(X) ParamUint16 = (uint16_t)(X)
#define ParamOneBandFilter(X) ParamUint32 = (uint32_t)(X)
#define ParamTwoBandsFilter(X) ParamUint32 = (uint32_t)(X)
#define ParamSpecialFilter(X) ParamUint16 = (uint16_t)(X)
#define ParamblockId(X) ParamUint16 = (uint16_t)(X)
#define ParamMonInterface(X) ParamUint8 = (uint8_t)(X)
#define ParamChebyx(X) ParamUint8 = (uint8_t)(X)
#define ParamEllip(X) ParamUint8 = (uint8_t)(X)

#define PP_FUNC_PARAM_MAX_NBR 20u
#define PP_MAX_PROBES_NUMBER 16u
#define PP_MAX_INPUTS_NUMBER 16u

/**
 * @brief One command chunk on the wire, bytes.
 *
 * Every command body travels in pieces of at most this size, however
 * long the whole body is: the header carries a chunk count and a
 * last-chunk size, and the sender walks the body one chunk at a time
 * straight out of the command structure. So this number is ALSO the
 * largest command buffer the library ever has to hold, which is what
 * makes the library fit on a microcontroller at all.
 *
 * It is a protocol constant, shared with the firmware and with
 * ``PP_CMD_CHUNK_SIZE`` in the Python library (papaya/constants.py).
 * Do not change it to tune memory: change the knobs below.
 */
#define PP_CMD_CHUNK_SIZE 400u

/* Host-side sizing knobs.
 *
 * Set them in ``papaya_target_config.h`` (or with a -D build flag on a
 * build system that has them). The defaults come in two profiles.
 *
 * A PC or Raspberry Pi host has memory to spare, so it keeps a whole
 * vector-probe frame and a whole pushed probe batch resident.
 *
 * A microcontroller does not: the generous profile asks for roughly
 * 380 KB of static RAM, which no Arduino and few STM32 parts have, and
 * an Arduino build simply fails to link. The MCU profile keeps the same
 * protocol and the same API and holds ONE chunk (400 bytes) per vector
 * probe instead of a whole frame. Nothing is lost on the wire:
 * getVectorProbes() reads every byte the board sends, stores what fits
 * and drains the remainder, so the link stays in step and a design with
 * frames larger than the buffer still runs. What a caller reads back
 * from such a probe is the first PP_MAX_VECTOR_PROBES_BYTES of it.
 * Raise the number in papaya_target_config.h if the target has the RAM
 * and the design needs the whole frame.
 *
 * PP_MAX_BOARD_CONTEXTS is the number of stacked PAPAYA boards one
 * program drives. The MCU default is 1; the exports write the design's
 * actual board count into papaya_target_config.h.
 */
#ifndef PP_MAX_VECTOR_PROBES_NUMBER
#define PP_MAX_VECTOR_PROBES_NUMBER 9u
#endif
#ifndef PP_MAX_VECTOR_PROBES_BYTES
#  if PAPAYA_TARGET_MCU
#    define PP_MAX_VECTOR_PROBES_BYTES PP_CMD_CHUNK_SIZE
#  else
#    define PP_MAX_VECTOR_PROBES_BYTES 8192u
#  endif
#endif
#ifndef PP_MAX_BOARD_CONTEXTS
#  if PAPAYA_TARGET_MCU
#    define PP_MAX_BOARD_CONTEXTS 1u
#  else
#    define PP_MAX_BOARD_CONTEXTS 4u
#  endif
#endif

/* SPI-master timing knobs (override with a -D build flag).
 * PP_DEFAULT_CS_DELAY_US: CS-setup / inter-frame gap (us). The PAPAYA
 *   cfg-SPI slave needs >~100 us to arm its receive DMA after CS goes
 *   low; the former 50 us default was too short. 200 us keeps margin.
 * PP_BOOT_SETTLE_MS: wait after releasing the board reset so the PAPAYA
 *   firmware boots and arms its SPI slave before the first command. */
#ifndef PP_DEFAULT_CS_DELAY_US
#define PP_DEFAULT_CS_DELAY_US 200u
#endif
#ifndef PP_RESET_ASSERT_MS
#define PP_RESET_ASSERT_MS 100u
#endif
#ifndef PP_BOOT_SETTLE_MS
#define PP_BOOT_SETTLE_MS 3000u
#endif

/* EEPROM Application Storage */
#define PP_EEP_MAX_APPS 16u
#define PP_EEP_APP_LABEL_MAX_SIZE 128u

#define PP_CMD_SEQ_NUMBER_IDX 0x00u
#define PP_CMD_READ_WRITE_IDX 0x02u
#define PP_CMD_SIZEL_IDX 0x03u
#define PP_CMD_SIZEH_IDX 0x04u
#define PP_CMD_blockIDL_IDX 0x05u
#define PP_CMD_blockIDH_IDX 0x06u
#define PP_CMD_FUNC_ID_IDX 0x07u
#define PP_CMD_SUB_FUNC_IDL_IDX 0x08u
#define PP_CMD_SUB_FUNC_IDH_IDX 0x09u
#define PP_CMD_NBR_OF_PARAMS_IDX 0x0Au
#define PP_CMD_NBR_OF_CHUNKS_IDX 0x0Bu
#define PP_CMD_LAST_CHUNK_SIZEL_IDX 0x0Cu
#define PP_CMD_LAST_CHUNK_SIZEH_IDX 0x0Du
#define PP_CMD_BODY_START_IDX 0x00u
#define PP_CMD_HEADER_CRC_IDX 0x0Eu
#define PP_CMD_HEADER_SIZE 0x12u
#define PP_CMD_CRC_SIZE 0x04u

#define PP_RESPONSE_REQ_CRC_IDX 0x05u
#define PP_RESPONSE_REQ_SIZE 0x09u
#define PP_RESPONSE_SIZE 0x07u
#define PP_RESPONSE_POLL_INTERVAL_MS 2u
#define PP_RESPONSE_TIMEOUT_MS 1000u
/* PP_CMD_CHUNK_SIZE is defined with the target profile at the top of
 * this header, because the sizing knobs there are expressed in it. */
#define PP_CMD_BODY_MAX_SIZE PP_CMD_CHUNK_SIZE
/* Wire-level body+CRC ceiling: the on-the-wire ``DataSize`` field is u16,
 * so 65535 is the absolute protocol cap.  This value must match
 * ``PP_CMD_BODY_HARD_MAX_SIZE`` in the Python lib (papaya/constants.py)
 * and stay within the board's 65536-byte command receive buffer, so the
 * board accepts anything the wire can express.  The Arduino master
 * streams chunk-by-chunk, so its working
 * scratch buffer ``PP_CMD_MAX_SIZE`` is only ``PP_CMD_CHUNK_SIZE`` (400);
 * the hard cap below only gates host-side wire validation. */
#define PP_CMD_BODY_HARD_MAX_SIZE 65535u
#define PP_CMD_MAX_SIZE PP_CMD_CHUNK_SIZE
#define PP_RES_SEQ_NUMBER_IDX 0x00u
#define PP_RES_RESCODE_IDX 0x02u
#define PP_RES_CRC_IDX 0x03u

#define PP_CMD_RESPONSE_ID 0xFFFF
#define PP_FIXED_SIZE PP_CMD_CRC_SIZE

class node;
class tf;
class macro;
class input;
class probe;
class fftMagResolver;   /* dependency type for eegBandpower / spectralFeatures / cepstrum */
class VectorProbe;

typedef enum
{
  Tustin,
  EulerBackward,
  EulerForward,

  NoC2dAlgo = 0xFF
} PP_C2dAlgo;

typedef enum
{
  Sum,
  Mul,

  NoNodeType = 0xFF
} PP_NodeType;

typedef enum
{
  DesignOk,
  MemError,
  TfError,
  UnknownC2dAlgo,
  TextOk,
  TxtError,
  BadParam,
  BadConnection,
  BadRequest,
  SamplingFreqOutOfLimit,
  GPIO_Failure,
  TIM_Failure,
  ADC_Failure,
  DAC_Failure,
  COMP_Failure,
  DMA_Failure,
  OPAMP_Failure,
  SPI_Failure,
  UART_Failure,
  I2C_Failure,
  USB_Failure,
  UndefinedFailure,
  NoDesignStatus = 0xFF
} PP_DesignStatus;

typedef enum
{
  ComOk,
  WrongSeqNumber,
  WrongCrc,
  UnknownComError,

  NoComStatus = 0xFF
} PP_ComStatus;

typedef enum
{
  Createblock = 0x00,
  Linkblock = 0x01,
  Manageblock = 0x02,

  NoFuncId = 0xFF
} PP_FuncId;

typedef enum
{
  /* ================= Create ================= */
  NewSys                    = 0x0000,
  NewSysLightC              = 0x0001,
  NewSysLightD              = 0x0002,

  NewInput                  = 0x0003,
  NewHwInput                = 0x0004,
  NewHwOutput               = 0x0005,

  NewNode                   = 0x0006,
  NewFlexNode               = 0x0007,
  NewMacro                  = 0x0008,

  NewProbe                  = 0x0009,
  NewVectorProbe            = 0x000A,

  NewSine                   = 0x000B,
  NewTri                    = 0x000C,
  NewSqr                    = 0x000D,
  NewSaw                    = 0x000E,
  NewNoise                  = 0x000F,

  NewSineAm                 = 0x0010,

  NewButterLow              = 0x0011,
  NewButterHigh             = 0x0012,
  NewButterBand             = 0x0013,
  NewButterStop             = 0x0014,

  NewBiquadButterLow        = 0x0015,
  NewBiquadButterHigh       = 0x0016,
  NewBiquadButterBand       = 0x0017,
  NewBiquadButterStop       = 0x0018,

  NewChebyshev1Low          = 0x0019,
  NewChebyshev1High         = 0x001A,
  NewChebyshev1Band         = 0x001B,
  NewChebyshev1Stop         = 0x001C,

  NewBiquadCheby1Low        = 0x001D,
  NewBiquadCheby1High       = 0x001E,
  NewBiquadCheby1Band       = 0x001F,
  NewBiquadCheby1Stop       = 0x0020,

  NewChebyshev2Low          = 0x0021,
  NewChebyshev2High         = 0x0022,
  NewChebyshev2Band         = 0x0023,
  NewChebyshev2Stop         = 0x0024,

  NewBiquadCheby2Low        = 0x0025,
  NewBiquadCheby2High       = 0x0026,
  NewBiquadCheby2Band       = 0x0027,
  NewBiquadCheby2Stop       = 0x0028,

  NewEllipLow               = 0x0029,
  NewEllipHigh              = 0x002A,
  NewEllipBand              = 0x002B,
  NewEllipStop              = 0x002C,

  NewBiquadEllipLow         = 0x002D,
  NewBiquadEllipHigh        = 0x002E,
  NewBiquadEllipBand        = 0x002F,
  NewBiquadEllipStop        = 0x0030,

  NewNotch                  = 0x0031,
  NewPeak                   = 0x0032,

  NewAllPass                = 0x0033,

  NewFirLow                 = 0x0034,
  NewFirHigh                = 0x0035,
  NewFirBand                = 0x0036,
  NewFirStop                = 0x0037,
  NewCustFir                = 0x0038,

  NewParamEQLow             = 0x0039,
  NewParamEQHigh            = 0x003A,
  NewParamEQBand            = 0x003B,
  NewParamEQPeak            = 0x003C,

  NewCompressor             = 0x003D,
  NewDecibelsConverter      = 0x003E,
  NewCombFeedForward        = 0x003F,
  NewCombFeedBack           = 0x0040,

  NewInterpolation          = 0x0041,
  NewMovingAverage          = 0x0042,
  NewDelayOp                = 0x0043,

  NewForwardFFT             = 0x0044,
  NewForwardFFT_HannWindow  = 0x0045,
  NewFftResolver            = 0x0046,
  NewPhaseResolver          = 0x0047,

  NewDWT                    = 0x0048,
  NewIDWT                   = 0x0049,
  NewDwtDenoise             = 0x00C6,
  NewDwtSubbandGain         = 0x00C7,
  NewDwtSubbandEnergy       = 0x00C8,

  /* Unified signalSource engine: one opcode, every shape + run mode. */
  NewSignalSource           = 0x00CA,
  SetSignalSourceParams     = 0x00CB,
  SignalSourceManualTrigger = 0x00CC,

  /* Infrastructure blocks (sub-function ids 0x00D0-0x00DF) */
  NewQuatMult               = 0x00CD,
  NewWindowFramer           = 0x00CE,
  NewStftFramer             = 0x00CF,
  NewImuBiasEst             = 0x00D4,
  NewFeatureStack           = 0x00D5,
  NewZScoreNorm             = 0x00D6,
  NewInnovationChi2         = 0x00D7,
  NewMadgwickAhrs           = 0x00D8,
  NewMahonyAhrs             = 0x00D9,
  NewComplementaryAhrs      = 0x00DA,
  NewMixerMultirotor        = 0x00DB,
  NewLqrServo               = 0x00DC,
  NewTrajScurve             = 0x00DD,
  NewTrajTrapezoid          = 0x00DE,
  NewFrictionStribeck       = 0x00DF,
  NewInputShaper            = 0x00E0,
  NewHjorth                 = 0x00E1,
  NewEmgEnvelope            = 0x00E2,
  NewEmgHudgins             = 0x00E3,
  NewEcgBlRemove            = 0x00E4,
  NewHrvTime                = 0x00E5,
  NewEegBandpower           = 0x00E6,
  NewSkewKurt               = 0x00E7,
  NewPercentile             = 0x00E8,
  NewPeakToPeak             = 0x00E9,
  NewCrestFactor            = 0x00EA,
  NewZcr                    = 0x00EB,
  NewSpectralFeatures       = 0x00EC,
  NewCepstrum               = 0x00ED,
  NewAutocorrLags           = 0x00EE,
  NewPcaProject             = 0x00EF,
  NewDecisionTree           = 0x00F0,
  NewQuatFromEuler          = 0x00D0,
  NewQuatToEuler            = 0x00D1,
  NewQuatToRotmat           = 0x00D2,
  NewQuatNormConj           = 0x00D3,

  NewAbsMax                 = 0x004A,
  NewAbsMin                 = 0x004B,
  NewEntropy                = 0x004C,
  NewPower                  = 0x004D,
  NewMean                   = 0x004E,
  NewMaximum                = 0x004F,
  NewMinimum                = 0x0050,
  NewRootMeanSquare         = 0x0051,
  NewStandardDeviation      = 0x0052,
  NewVariance               = 0x0053,

  NewPeriodMeter            = 0x0054,
  NewUpDwnPeriodMeter       = 0x0055,

  NewMag2                   = 0x0056,
  NewMag3                   = 0x0057,

  NewPid                    = 0x0058,
  NewTunePID                = 0x0059,
  NewTunePI                 = 0x005A,
  NewTunePD                 = 0x005B,
  NewTune2PID               = 0x005C,

  NewComp                   = 0x005D,
  NewSchmidt                = 0x005E,
  NewSat                    = 0x005F,
  NewDeadZone               = 0x0060,
  NewBacklashDeadBand       = 0x0061,
  NewSign                   = 0x0062,

  NewGain                   = 0x0073,

  /* ---- Math / DSP ---- */
  NewSqrMath                = 0x0074,
  NewSqrt                   = 0x0075,
  NewSineFunc               = 0x0076,
  NewCosineFunc             = 0x0077,
  NewAbsVal                 = 0x0078,
  NewAtan2                  = 0x0079,
  NewLogFunc                = 0x007A,
  NewExpFunc                = 0x007B,
  NewNegate                 = 0x007C,
  NewInverse                = 0x007D,

  /* ---- Control ---- */
  NewSwitch                 = 0x007E,
  NewQuantizer              = 0x007F,
  NewIntegrator             = 0x0080,
  NewDerivative             = 0x0081,
  NewRateLimiter            = 0x0082,
  NewSampleHold             = 0x0083,

  /* ---- Motor control transforms ---- */
  NewClarke                 = 0x0084,
  NewInvClarke              = 0x0085,
  NewPark                   = 0x0086,
  NewInvPark                = 0x0087,

  /* ---- Classical compensators ---- */
  NewLeadLag                = 0x0088,
  NewWashout                = 0x0089,

  /* ---- State-space system ---- */
  NewStateSpace             = 0x008A,

  /* ---- Observers ---- */
  NewCompFilter             = 0x008B,
  NewSMO                    = 0x008C,

  /* ---- Application EKF/UKF blocks ---- */
  NewPMSM_EKF               = 0x008D,
  NewAHRS_EKF               = 0x008E,
  NewBatterySOC_EKF         = 0x008F,
  NewTilt_EKF               = 0x0090,
  NewLoadTorque_EKF         = 0x0091,

  /* ---- New Application EKF blocks ---- */
  NewThermal_EKF            = 0x0092,
  NewBaroAlt_EKF            = 0x0093,
  NewRobotLoc_EKF           = 0x0094,
  NewSinTrack_EKF           = 0x0095,
  NewGridSync_EKF           = 0x0096,
  NewACIM_EKF               = 0x0097,
  NewBatterySOH_EKF         = 0x0098,
  NewWMR_EKF                = 0x0099,
  NewGPSINS_EKF             = 0x009A,

  /* ---- Adaptive DSP blocks ---- */
  NewLMS                    = 0x009B,
  NewAdaptiveNotch          = 0x009C,
  NewDOB                    = 0x009D,
  NewESC                    = 0x009E,
  NewADRC                   = 0x009F,
  NewMRAC                   = 0x00A0,
  NewMRAC_Lyapunov          = 0x00A1,
  NewRepetitiveCtrl         = 0x00A2,
  NewSTR                    = 0x00A3,
  NewILC                    = 0x00A4,

  /* ---- Self-tuning PID blocks ---- */
  NewGainSchedulePID        = 0x00A5,
  NewGainScheduler          = 0x00A6,
  NewRelayAutoTune          = 0x00A7,
  NewStepAutoTune           = 0x00A8,
  NewSTR_PID                = 0x00A9,
  NewMRAC_PID               = 0x00AA,
  NewESC_PID                = 0x00AB,
  NewPerfMonitor_PID        = 0x00AC,
  NewFuzzyPID               = 0x00AD,

  /* ---- Miscellaneous blocks ---- */
  NewMomentaryPower         = 0x00AE,
  NewMaxObserver            = 0x00AF,
  NewMinObserver            = 0x00B0,
  NewMux                    = 0x00B1,
  NewDemux                  = 0x00B2,
  NewLoudness               = 0x00B3,
  NewCpuLoad                = 0x00B4,
  NewExtSensor              = 0x00B5,

  /* ---- Audio processing blocks ---- */
  NewLimiter                = 0x00B6,
  NewNoiseGate              = 0x00B7,
  NewEnvFollower            = 0x00B8,
  NewADSR                   = 0x00B9,
  NewFracDelay              = 0x00BA,
  NewChorus                 = 0x00BB,
  NewFlanger                = 0x00BC,
  NewPhaser                 = 0x00BD,
  NewReverb                 = 0x00BE,
  NewStereoPan              = 0x00BF,
  NewDistortion             = 0x00C0,
  NewBitcrusher             = 0x00C1,
  NewRingMod                = 0x00C2,
  NewPitchDetect            = 0x00C3,
  NewVUMeter                = 0x00C4,
  NewStereoMixer            = 0x00C5,

  NewAdaptiveKF             = 0x0063,
  NewIdealKF                = 0x0064,
  NewRLS                    = 0x0065,
  NewRRLS                   = 0x0066,
  /* The `rls` MACRO's own id. It used to share NewRLS while sending a
   * different parameter layout, and the board reads the first parameter
   * of a NewRLS command as an array of floats, so the macro made the
   * board read a uint8 as if it were a pointer to floats.
   * 0x00F1 is the first id past the block-creation range (which ends at
   * NewDecisionTree = 0x00F0; Link starts at 0x1000). The board does not
   * implement it yet: it refuses with "unknown sub-function",
   * which is the point. See the rls class comment.
   *
   * HAZARD, read before adding a block opcode: 0x00F1 is HOST-ONLY and
   * sits directly on the board's next free block-creation id. A new block
   * appended after NewDecisionTree (0x00F0) would land here and silently
   * turn this safely refused id into a live constructor with a different
   * parameter layout. 0x00F1 itself must not move (wire values never
   * move), so the next block id must skip it and take 0x00F2. */
  NewRLSMacro               = 0x00F1,

  /* Anti-windup controllers. 0x00F1 is not reused: it belonged to
   * NewPercentile before that block moved, and it is now NewRLSMacro's
   * host-only id (see the hazard note above), so these start at 0x00F2.
   * There is deliberately no live-PD entry: a PD controller has no
   * integrator and cannot wind up. */
  NewPidAw                  = 0x00F2,
  NewTunePIDAw              = 0x00F3,
  NewTunePIAw               = 0x00F4,
  NewTune2PIDAw             = 0x00F5,

  /* Identified model to live PID gains. 0x00F6 is the next free value: the
   * anti-windup family above ends at 0x00F5, and 0x00F1 is retired twice
   * over (see the hazard note further up). */
  NewPidFromModel           = 0x00F6,
  NewIntegratorIC           = 0x00F7,
  NewModulo                 = 0x00F8,

  NewMerger                 = 0x0067,
  NewExpander               = 0x0068,

  NewSingleAnIn             = 0x0069,
  NewListOfAnIn             = 0x006A,
  NewSinglePwmIn            = 0x006B,
  NewListOfPwmIn            = 0x006C,
  NewSinglePwmOut           = 0x006D,
  NewListOfPwmOut           = 0x006E,

  NewAccelerometer          = 0x006F,
  NewGyroscope              = 0x0070,
  NewMagnetometer           = 0x0071,
  NewMotor                  = 0x0072,
  NewEncoder                = 0x00C9,

  /* ================= Link ================= */
  LinkSys2Sys               = 0x1000,
  LinkNode2Node             = 0x1001,
  LinkSys2Node              = 0x1002,
  LinkIn2Node               = 0x1003,
  LinkNode2Probe            = 0x1004,
  LinkSys2Probe             = 0x1005,
  LinkIn2Sys                = 0x1006,
  LinkNode2Sys              = 0x1007,
  LinkMacro2Macro           = 0x1008,
  LinkMacro2Sys             = 0x1009,
  LinkSys2Macro             = 0x100A,
  LinkMacro2Node            = 0x100B,
  LinkNode2Macro            = 0x100C,
  LinkIn2Macro              = 0x100D,
  LinkMacro2Probe           = 0x100E,
  LinkSys2VectorProbe       = 0x100F,
  LinkNode2VectorProbe      = 0x1010,

  /* ================= Manage ================= */
  DesignInit                = 0x2000,
  SetInput                  = 0x2001,
  StopDesign                = 0x2002,
  StartMacro                = 0x2003,
  StopMacro                 = 0x2004,
  StartSampling             = 0x2005,
  StopSampling              = 0x2006,
  EnableRemoteInput         = 0x2007,
  SetMonInterface           = 0x2008,
  GetDesignInfo             = 0x2009,
  SwitchToCfg               = 0x200D,


  /* ---- EEPROM App Storage ---- */
  EnableStorage             = 0x200E,
  CommitToEeprom            = 0x200F,
  LoadApp                   = 0x2010,
  DumpApp                   = 0x2011,
  UploadApp                 = 0x2012,
  ListApps                  = 0x2013,
  DeleteApp                 = 0x2014,
  SyncEeprom                = 0x2015,

  /* ---- Reset ---- */
  McuReset                  = 0x2016,
  SoftReset                 = 0x2017,

  /* ---- Offline monitoring ---- */
  SetMonitorMode            = 0x2018,
  SetTraceSize              = 0x2019,
  SetLiveRate               = 0x201A,
  GetCaptureStatus          = 0x201B,
  DownloadTrace             = 0x201C,

  /* ---- Boot configuration ---- */
  SetBootApp                = 0x201D,
  GetBootCfg                = 0x201E,

  /* ---- Bulk maintenance ---- */
  EraseAll                  = 0x201F,

  /* ---- Board identity ---- */
  GetBoardInfo              = 0x2020,

  /* ---- Monitoring metadata queries ---- */
  DescribeVectProbes        = 0x2021,

  /* ---- HMAC-SHA256 challenge-response authentication ----
   * Body: 32-byte host-supplied nonce.
   * Response payload: 32-byte HMAC = HMAC-SHA256(PSK,
   *   nonce || mcu_unique_id_12bytes).
   * Required before Papaya Studio will treat the device as a genuine
   * board and allow the rest of the command set.
   * See papaya_lib/papaya_auth_reference.c for the full reference
   * implementation (algorithm + RAM layout + integration steps). */
  Authenticate              = 0x2022,

  /* ---- Bootloader entry (Studio-driven firmware update) ---- */
  EnterBootloader           = 0x2023,

  /* ---- Recorder lifecycle / debug-log helpers ----
   * AbortStorage cancels a half-recorded EEPROM save without committing.
   * GetDebugLog / ClearDebugLog manage the board's debug ring, which
   * Studio reads after every save attempt to surface failure context. */
  AbortStorage              = 0x2024,
  GetDebugLog               = 0x2025,
  ClearDebugLog             = 0x2026,

  /* ---- Online feasibility check ---- */
  MeasureCycleTime          = 0x2027,

  /* ---- DC motor data capture ---- */
  StartDcMotorCapture       = 0x2028,
  GetDcMotorCaptureStatus   = 0x2029,
  DownloadDcMotorCapture    = 0x202A,
  StopDcMotorCapture        = 0x202B,
  GetDcMotorCaptureBoardState = 0x202C,

  /* ---- Live-sampling diagnostic counters ---- */
  GetLiveDiagCounters       = 0x202D,

  /* ---- FreqIn comparator-mode + pin-swap (Session 1) ---- */
  SetFreqInCh2Source        = 0x2030,
  SetFreqInSwapPins         = 0x2031,

  /* ---- Extension-MCU sampling deadline counters ---- */
  GetExtSamplingDeadlineInfo = 0x2032,

  /* ---- Design instrumentation (heap / CPU load) ---- */
  GetDesignInstrumentation  = 0x2033,

  /* ---- Audio-slot management ---- */
  ListAudioSlots            = 0x2034,
  GetAudioSlotInfo          = 0x2035,
  EraseAudioSlot            = 0x2036,
  EraseAllAudioSlots        = 0x2037,
  DownloadAudioSlot         = 0x2038,
  UploadAudioSlotStart      = 0x2039,
  UploadAudioSlotChunk      = 0x203A,
  UploadAudioSlotCommit     = 0x203B,

  /* ---- DWT live tuning (runtime child-block updates) ---- */
  SetDwtSubbandGains        = 0x203C,
  SetDwtDenoiseScale        = 0x203D,

  /* ---- Dataset FLASH slots ----
   * Recorded signals stored on the board so a signalSource::dataset
   * block can play one back with no host in the loop. Upload is
   * Start -> Chunk... -> Commit; the slot only becomes valid on Commit,
   * so an abandoned upload leaves it empty rather than half-written. */
  ListDatasets              = 0x2040,
  GetDatasetInfo            = 0x2041,
  EraseDataset              = 0x2042,
  UploadDatasetStart        = 0x2043,
  UploadDatasetChunk        = 0x2044,
  UploadDatasetCommit       = 0x2045,
  DownloadDataset           = 0x2046,

  NoSubFuncId               = 0xFFFF

} PP_SubFuncId;

/*
 * PP_HwId names its buses SPI1..SPI4 and I2C1..I2C4, which read
 * naturally and match what is silkscreened on the board.
 *
 * On an STM32 target those are ALSO macros. ST's CMSIS device header
 * defines SPI1 as ((SPI_TypeDef *) SPI1_BASE), so the enum below expands
 * into an expression where an identifier belongs and the file does not
 * compile at all. It is not a subtle failure: PAPAYA.h simply cannot be
 * included beside a device header that defines them without this.
 *
 * Undefining them here is the fix that keeps the published API. Renaming
 * the enumerators would break every program already written against the
 * library, for the benefit of one toolchain.
 *
 * It is safe in the translation units that include this header: nothing
 * in the PAPAYA library or in a generated program refers to a CMSIS
 * peripheral pointer. The Arduino core keeps its own definitions,
 * because the core is compiled separately from anything that includes
 * this file.
 *
 * Do NOT put a condition around this block. Testing the target instead
 * of the macro is what used to be here, and it listed the family
 * symbols the STM32 Arduino core defines. A project made with
 * STM32CubeMX defines none of those: it defines a device macro named
 * after the exact part instead. The list therefore never matched, the
 * undefines never ran, and the enum below was cut in half at SPI1 in
 * every such project. Any new list would leave out the next part the
 * same way.
 *
 * `#undef` of a name that is not a macro is defined to do nothing, so no
 * condition is needed. It also removes MACROS only: on a core where SPI1
 * is an object rather than a #define, the object is untouched.
 */
#undef SPI1
#undef SPI2
#undef SPI3
#undef SPI4
#undef I2C1
#undef I2C2
#undef I2C3
#undef I2C4

typedef enum
{
  MOTOR1 = 0x0000,
  MOTOR2,

  FI1_PULSE = 0x0100,
  FI2_PULSE,
  FI3_PULSE,
  FI4_PULSE,
  FI5_PULSE,

  FI1_PERIOD = 0x0200,
  FI2_PERIOD,
  FI3_PERIOD,
  FI4_PERIOD,
  FI5_PERIOD,

  FI1_DELAY = 0x0300,
  FI2_DELAY,
  FI3_DELAY,
  FI4_DELAY,
  FI5_DELAY,

  FO1 = 0x0400,
  FO2,
  FO3,
  FO4,
  FO5,
  FO6,
  FO7,
  FO8,

  AO1 = 0x0500,
  AO2,
  AO3,
  AO4,
  AO5,

  AIN1 = 0x0600,
  AIN2,
  AIN3,
  AIN4,
  AIN5,
  AIN6,
  AIN7,
  AIN8,
  AIN9,
  AIN10,

  MIC_L = 0x0700,
  MIC_R,

  SPEAKER1 = 0x0800,
  SPEAKER2,

  IMU_ACC = 0x0900,
  IMU_GYR,
  IMU_MAG,

  SPI1 = 0x0A00,
  SPI2,
  SPI3,
  SPI4,
  I2C1,
  I2C2,
  I2C3,
  I2C4,

  ENC1 = 0x0B00,
  ENC2,

  RECORDER_1 = 0x0C00,

  REPLAY_1 = 0x0D00,

  NoHwRoutine = 0xFFFF
} PP_HwId;

/**
 * @brief The external sensor parts the board recognises.
 *
 *        Pass one of these to extSensor together with the bus route. The
 *        board already knows the part: how many measurement channels it
 *        has, in what order, and how to scale them. The channel count is
 *        therefore fixed by the part and is not something you set.
 *
 *        These values cross the wire, so they never change meaning; the
 *        Python library uses the same names and the same numbers.
 */
typedef enum
{
  SENSOR_NONE = 0,

  /* Accelerometers */
  LIS3DH = 1,
  ADXL345,
  ADXL362,
  BMA400,
  LIS2DW12,

  /* 6-axis IMU */
  MPU6050,
  LSM6DSO,
  BMI270,
  ICM42688P,
  ISM330DHCX,
  LSM6DSV16X,

  /* 9-axis IMU */
  MPU9250,
  ICM20948,
  LSM9DS1,

  /* Magnetometers */
  BMM150,
  MMC5983MA,
  LIS3MDL,

  /* Environmental */
  BME280,
  BMP280,
  BME680,
  BMP390,
  LPS22HH,
  DPS310,
  MS5611,
  HTS221,

  /* Biomedical (SPI) */
  MAX86141,
  MAX30001,
  ADS1292R,
  ADS1298R,
  ADS1299,
  AFE4900,

  /* External ADC (SPI) */
  MCP3008,
  MCP3208,
  ADS1220,
  ADS131M08,

  /* External DAC (SPI) */
  DAC8552,
  MCP4922,

  /* I2C-only: PPG / Biomedical */
  MAX30102,
  MAX30105,
  MAX86150,
  AFE4404,

  /* I2C-only: Temperature */
  TMP117,
  MCP9808,

  /* I2C-only: Humidity + Temperature */
  SHT40,
  SHT31,
  HDC1080,
  SI7021,

  /* I2C-only: External ADC */
  ADS1115,
  NAU7802,

  /* I2C-only: External DAC */
  MCP4725,
  MCP4728,
  AD5693R,
} PP_SensorPartNumber;

typedef enum
{
  MotorVelocity = 0u,
  MotorPosition = 1u,
  MotorCurrent = 2u,

  NoMotorOutput = 0xFFu
} PP_MotorOutput;

typedef enum
{
  EncoderVelocity = 0u,
  EncoderPosition = 1u,

  NoEncoderOutput = 0xFFu
} PP_EncoderOutput;

typedef enum
{
  PP_MonMode_Live = 0u,
  PP_MonMode_Offline = 1u,
  PP_MonMode_Dual = 2u,

  PP_NoMonitorMode = 0xFFu
} PP_MonitorMode;

typedef struct
{
  uint16_t dim_x;
  uint16_t dim_z;
  uint16_t dim_u;
  float *x_init;
  float *F_data; // dim_x × dim_x (fixed, from user config)
  float *H_data; // dim_z × dim_x (fixed, from user config)
  float *Q_data; // dim_x × dim_x (fixed, from user config)
  float *B_data; // dim_x × dim_u (fixed, from user config)
                 //               float* x_init;    // dim_x × 1 (initial state)
  float R_init;  // scalar initial measurement noise covariance
  float P_init;  // scalar initial covariance diagonal value
  float alpha;
} PP_adaptiveKF;

typedef struct
{
  uint16_t dim_x;
  uint16_t dim_z;
  uint16_t dim_u;
  float *x_init;
  float *F_data; // dim_x × dim_x (fixed, from user config)
  float *H_data; // dim_z × dim_x (fixed, from user config)
  float *Q_data; // dim_x × dim_x (fixed, from user config)
  float *B_data; // dim_x × dim_u (fixed, from user config)
  //               float* x_init;    // dim_x × 1 (initial state)
  float R_init; // scalar initial measurement noise covariance
  float P_init; // scalar initial covariance diagonal value
} PP_linearKF;

/**
 * @brief Configuration for the state-space system node (SISO / MIMO).
 *
 * Discrete-time equations:
 *   x[k+1] = A·x[k] + B·u[k]
 *   y[k]   = C·x[k] + D·u[k]
 */
typedef struct
{
  uint16_t n;       // Number of states
  uint16_t m;       // Number of inputs
  uint16_t p;       // Number of outputs
  float *A_data;    // n × n, row-major
  float *B_data;    // n × m, row-major
  float *C_data;    // p × n, row-major
  float *D_data;    // p × m, row-major
  float *x_init;    // n × 1, initial state vector
} PP_stateSpace;

/**
 * @brief Configuration for the complementary filter node.
 */
typedef struct
{
  float alpha;       // Blend factor (0..1)
} PP_compFilter;

/**
 * @brief Configuration for the sliding mode observer node (SISO / MIMO).
 */
typedef struct
{
  uint16_t n;        // Number of states
  uint16_t m;        // Number of control inputs
  uint16_t p;        // Number of measured outputs
  float *A_data;     // n × n, row-major
  float *B_data;     // n × m, row-major
  float *C_data;     // p × n, row-major
  float *L_data;     // n × p, row-major (linear observer gain)
  float *K_data;     // n × p, row-major (sliding mode gain)
  float *x_init;     // n × 1, initial state vector
  float epsilon;     // Boundary layer thickness for sat()
} PP_SMO;

typedef struct {
  float Rs; float Ls; float lambda_pm;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_PMSM_EKF;

typedef struct {
  float mag_ref[3];
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_AHRS_EKF;

typedef struct {
  float R0; float R1; float C1; float Q_cap;
  float ocv_coef[4];
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_BatterySOC_EKF;

typedef struct {
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_Tilt_EKF;

typedef struct {
  float J; float B;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_LoadTorque_EKF;

/* ---- New Application EKF config structs ---- */

typedef struct {
  float R_th; float C_core; float C_surf; float R_conv; float T_amb;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_Thermal_EKF;

typedef struct {
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_BaroAlt_EKF;

typedef struct {
  float wheel_radius; float wheel_base; float landmark_x; float landmark_y;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_RobotLoc_EKF;

typedef struct {
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_SinTrack_EKF;

typedef struct {
  float nom_freq; float nom_amplitude;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_GridSync_EKF;

typedef struct {
  float Rs; float Rr; float Ls; float Lr; float Lm; float P_pairs;
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_ACIM_EKF;

typedef struct {
  float R1; float C1;
  float ocv_coef[4];
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_BatterySOH_EKF;


typedef struct {
  float wheel_base; float mag_ref[2];
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_WMR_EKF;

typedef struct {
  float *Q_data; float *R_data; float *x_init;
  float P_init;
} PP_GPSINS_EKF;

/* ---- Adaptive DSP config structs ---- */

typedef struct {
  float mu; uint16_t N; uint8_t normalize; float delta;
} PP_LMSConfig;

typedef struct {
  float init_freq; float Q_factor; float mu;
} PP_AdaptiveNotchConfig;

typedef struct {
  float *Gn_num; float *Gn_den; float *Qf_num; float *Qf_den;
  uint8_t plant_ord; uint8_t qf_ord;
} PP_DOBConfig;

typedef struct {
  float a; float omega; float k; float hpf_wc; float lpf_wc;
} PP_ESCConfig;

typedef struct {
  float b0; float omega_o; float omega_c; uint8_t order;
} PP_ADRCConfig;

typedef struct {
  float Am; float Bm; float gamma_x; float gamma_r;
} PP_MRACConfig;

typedef struct {
  float Am; float Bm; float gamma_x; float gamma_r;
  float sigma; float theta_max;
} PP_MRACLyapunovConfig;

typedef struct {
  uint16_t period_samples; float Q_gain; float Kr;
} PP_RepCtrlConfig;

typedef struct {
  uint8_t na; uint8_t nb; float lambda; float P_init;
  float *desired_poles;
} PP_STRConfig;

typedef struct {
  uint16_t trial_length; float L_gain; float Q_gain;
} PP_ILCConfig;

/* ---- Self-tuning PID config structs ---- */

typedef struct {
  float *schedule_points; float *Kp_table; float *Ki_table; float *Kd_table;
  float Tau; float out_min; float out_max;
  uint8_t num_points;
} PP_GainSchedulePIDConfig;

typedef struct {
  float *breakpoints; float *values;
  uint8_t num_points; uint8_t num_outputs;
} PP_GainSchedulerConfig;

typedef struct {
  float relay_amplitude; float hysteresis; float setpoint;
  uint8_t tuning_rule; uint16_t min_cycles;
} PP_RelayAutoTuneConfig;

typedef struct {
  float step_size; float settle_pct;
  uint8_t tuning_rule; uint8_t id_method;
} PP_StepAutoTuneConfig;

typedef struct {
  float lambda; float P_init; float Tau; float desired_cl_bw;
  /** Fit the model one tick in N, 1 to 64. The identifier then runs at Fs/N
   *  with both its inputs anti-alias filtered, while the PID keeps running
   *  every tick. 1 leaves the behaviour exactly as it was. */
  uint16_t UpdateDivider_u16;
} PP_STR_PID_Config;

typedef struct {
  float Am; float Bm; float gamma_p; float gamma_i; float gamma_d; float Tau;
} PP_MRAC_PID_Config;

typedef struct {
  float Kp_init; float Ki_init; float Kd_init;
  float a; float omega_p; float omega_i; float omega_d;
  float esc_gain; float lpf_wc; float Tau; float iae_window;
} PP_ESC_PID_Config;

typedef struct {
  float Kp_init; float Ki_init; float Kd_init; float Tau;
  float iae_threshold; float out_min; float out_max; float eval_window;
} PP_PerfMonPID_Config;

typedef struct {
  float Kp_base; float Ki_base; float Kd_base;
  float e_range; float de_range; float Tau;
  float out_min; float out_max;
} PP_FuzzyPIDConfig;

typedef struct
{
  float *num;
  uint8_t lenNum;
  float *denom;
  uint8_t lenDenom;
  float InitVariance_f32;
  uint8_t ModelOrder_u8;
  /** Fit the model once every N ticks, 1 to 64. The identifier then runs at
   *  Fs/N and its model is a discrete model at that rate, which is what the
   *  poles read off it are against. Both of its inputs are anti-alias
   *  filtered first. 1 leaves the behaviour exactly as it was. */
  uint16_t UpdateDivider_u16;
} PP_RLSParam;

typedef struct
{
  float *num;
  uint8_t lenNum;
  float *denom;
  uint8_t lenDenom;
  float InitVariance_f32;
  uint8_t ModelOrder_u8;
  float sensParam_f32;
  /** Fit the model once every N ticks, 1 to 64. The identifier then runs at
   *  Fs/N and its model is a discrete model at that rate, which is what the
   *  poles read off it are against. Both of its inputs are anti-alias
   *  filtered first. 1 leaves the behaviour exactly as it was. */
  uint16_t UpdateDivider_u16;
} PP_RRLSParam;

typedef struct
{
  float outScale;
  float offset;
  PP_HwId id;
} PP_anInCfg;

/** @brief One row of a multi-channel @ref pwmIn block. */
typedef struct
{
  float outScale;        /**< @brief Measurement RANGE in SECONDS: the longest interval this channel can time. Not a multiplier; the output is the measured time in seconds whatever this is. Default 1.0f. */
  PP_HwId id;            /**< @brief Frequency input and mode: FI1_PULSE..FI5_DELAY. One block per physical channel, whichever of the three modes it is in. */
} PP_pwmInCfg;

/** @brief One row of a multi-channel @ref pwmOut block. Every row is held to
 *  the same ranges as the single-channel constructor. */
typedef struct
{
  float frequency;       /**< @brief Carrier frequency in Hz. Realisable span 0.06403 to 137500000; outside it the channel runs at a different frequency and nothing reports it. */
  float dutyLowerLimit;  /**< @brief Lower duty clamp, a FRACTION in 0.0f..1.0f. */
  float dutyUpperLimit;  /**< @brief Upper duty clamp, same fraction and range. Must not be below dutyLowerLimit: the board swaps a reversed pair silently. */
  PP_HwId id;            /**< @brief Frequency output channel, FO1..FO8. */
} PP_pwmOutCfg;

/** @brief One row of a multi-channel input-driven @ref analogOut block. */
typedef struct
{
  float lowerLimit;      /**< @brief Lower output clamp in VOLTS, within -10.0f..+10.0f. The clamp can only narrow the span, never extend it. Default -10.0f. */
  float upperLimit;      /**< @brief Upper output clamp in VOLTS, same range. Must not be below lowerLimit: the board swaps a reversed pair silently. Default +10.0f. */
  PP_HwId id;            /**< @brief Analog output channel, AO1..AO5. */
} PP_anOutCfg;

/**
 * @brief Numeric configuration for a brushed-DC motor channel.
 *
 * Wire-format order matches the struct layout: the host serialises
 * fields in declared order into the NewMotor command, the board parses
 * them at the matching indices, and the relevant subset is forwarded
 * to the subsystem which owns the physical PWM + ADC + encoder timer.
 */
typedef struct
{
  float pwm_hz;          /**< @brief H-bridge PWM frequency in Hz. Typical 20 000 (above audible). Sets the duty resolution: about 8500 steps at 20 000 Hz, fewer as it rises. */
  float cur_min_mA;      /**< @brief Lower bound of the current MEASUREMENT window (mA), default -5000. It does NOT trip: this firmware never cuts the drive out on current. The sense chain resolves about -5470 to +5470 mA, so a wider bound is never reached. */
  float cur_max_mA;      /**< @brief Upper bound of the current MEASUREMENT window (mA), default +5000. Must be > cur_min_mA. Same span and the same measurement-only caveat as cur_min_mA. */
  float vel_conv;        /**< @brief Velocity scale, an EMPIRICAL calibration constant, not 2*pi/PPR. The board computes omega = 275000 * vel_conv / ccr, where ccr is its input-capture count for one encoder edge interval. Calibrate at a known no-load speed: vel_conv_correct = vel_conv_used * (true speed / reported speed). Must be > 0; default 1.0f. */
  float pos_conv;        /**< @brief Position scale, rad per quadrature count. This one IS the kinematic ratio 2*pi/PPR_quad. Must be > 0. */
  float vel_tau;         /**< @brief Velocity LPF time constant (s). Bilinear first-order, DC gain exactly 1, so it changes noise and settling only. Must be > 0; default 0.01f. */
  float dutyLowerLimit;  /**< @brief Lower clamp on the duty input, a SIGNED FRACTION in -1.0f..+1.0f (-1 is full reverse). Default -1.0f. */
  float dutyUpperLimit;  /**< @brief Upper clamp on the duty input, same signed fraction and range. Must be > dutyLowerLimit. Default +1.0f. */
} PP_motorCfg;

/**
 * @brief Full motor block descriptor: identifier + numeric config + output selection.
 *
 * Including velocity or position in @c outputs claims the encoder
 * peripheral and forbids a standalone @c encoder block on the same
 * physical channel. Use @c {MotorCurrent} only to release the encoder
 * for the standalone @c encoder block.
 */
typedef struct
{
  PP_HwId id;                  /**< @brief MOTOR1 or MOTOR2. */
  PP_motorCfg config;          /**< @brief Numeric configuration (see PP_motorCfg). */
  uint8_t outputCount;         /**< @brief Number of selected outputs (1..3, must match outputs[] length). */
  PP_MotorOutput outputs[3];   /**< @brief Ordered measurement port list: any non-empty subset of {velocity, position, current}. */
} PP_motorBlockCfg;

/**
 * @brief Numeric configuration for a standalone quadrature encoder block.
 *
 * The encoder shares its physical timer pair with the motor block on
 * the same channel (Encoder 1 ↔ MOTOR1, Encoder 2 ↔ MOTOR2). The
 * firmware applies the same bilinear first-order velocity LPF as the
 * motor block, sampled on the board at MainSamplingFrequency.
 * vel_conv / pos_conv are independent of the motor's conversions.
 */
typedef struct
{
  float vel_conv;  /**< @brief Velocity scale, (rad/s) per (encoder tick/s). */
  float pos_conv;  /**< @brief Position scale, rad per encoder tick. */
  float vel_tau;   /**< @brief Velocity LPF time constant (s). Default 0.01f. */
} PP_encoderCfg;

/**
 * @brief Full encoder block descriptor: identifier + numeric config + output selection.
 *
 * The Studio validator + firmware peripheral-arbitration check ensure
 * this block and a corresponding motor block on the same physical
 * channel cannot both claim velocity/position simultaneously.
 */
typedef struct
{
  PP_HwId id;                    /**< @brief ENC1 or ENC2. */
  PP_encoderCfg config;          /**< @brief Numeric configuration (see PP_encoderCfg). */
  uint8_t outputCount;           /**< @brief Number of selected outputs (1 or 2). */
  PP_EncoderOutput outputs[2];   /**< @brief Ordered list: any non-empty subset of {velocity, position}. */
} PP_encoderBlockCfg;

typedef struct
{
  float ConvConst1;
  float ConvConst2;
  PP_HwId HwId;
} PP_SensorSpec;

typedef struct
{
  float ConvConst1;
  float LowerLimit;
  float UpperLimit;
  PP_HwId HwId;
} PP_ActuatorSpec;

typedef enum
{
  passLow,
  passHigh,
  passBand,
  stopBand,

  NoFilterType = 0xFF
} PP_FilterType;

typedef enum
{
  /* These are the raw wire codes the board's FIR window selector expects:
   * the enum value is sent as a Uint32 and used directly to pick the
   * window. Index 0 is Hamming, so hann is 3. Do not reorder to a plain
   * 0/1 pair. */
  hamming,        /* 0 */
  blackMan,       /* 1 */
  rectangular,    /* 2 */
  hann,           /* 3 */
  bartlett,       /* 4 */
  flatTop,        /* 5 */
  blackManHarris, /* 6 */
  kaiser5,        /* 7 */
  kaiser8,        /* 8 */

  NoFirWindowType = 0xFF
} PP_FirWindowType;

typedef enum
{
  uniform,
  gaussian
} PP_NoiseType;

typedef enum
{
  PP_LiveTune,
  PP_NoLiveTune
} PP_Tune;

typedef enum
{
  Cheby1Cfg1,
  Cheby1Cfg2,
  Cheby1Cfg3,
  Cheby1Cfg4,
  Cheby1Cfg5,

  NoCheby1Cfg = 0xFF
} PP_Cheby1Cfg;

typedef enum
{
  Cheby2Cfg1,
  Cheby2Cfg2,
  Cheby2Cfg3,
  Cheby2Cfg4,
  Cheby2Cfg5,

  NoCheby2Cfg = 0xFF
} PP_Cheby2Cfg;

typedef enum
{
  EllipCfg1,
  EllipCfg2,
  EllipCfg3,
  EllipCfg4,

  NoEllipCfg = 0xFF
} PP_EllipCfg;

typedef enum
{
  Sine = NewSine,
  Tri = NewTri,
  Sqr = NewSqr,
  Saw = NewSaw,

  NoWaveForm = 0xFFFF
} PP_WaveForm;

/* ---------------- Unified signalSource (new in v?) ----------------------
 * Shapes / modes / trigger polarity for the new ``signalSource`` block.
 * Wire-stable IDs. The Python library uses the same names and the same
 * numbers, so a design written either way behaves identically.
 */
enum class WaveShape : uint16_t {
  Sine        = 0,  Square     = 1,  Triangle    = 2,  Sawtooth   = 3,
  Pulse       = 4,  Sinc       = 5,  Gauspuls    = 6,  DC         = 7,
  Arbitrary   = 8,  LinearChirp= 9,  LogChirp    = 10, Multisine  = 11,
  PRBS        = 12, Step       = 13, Ramp        = 14, Impulse    = 15,
  PulseTrain  = 16,
  /* Recorded dataset played back from an external-FLASH slot. The board
   * resolves the slot to an Arbitrary lookup table when the block is
   * created. Only freq/phase/dataset_slot travel on the wire: the
   * samples live in FLASH (uploaded via the Studio dataset picker). */
  Dataset     = 17
};

enum class WaveMode : uint16_t {
  Perpetual = 0, RepeatN = 1, OneShot = 2, TrigEdge = 3, TrigGate = 4
};

enum class WaveTrigPol : uint16_t {
  Rising = 0, Falling = 1, GateHigh = 2, GateLow = 3
};

enum class MultisinePhase : uint8_t {
  Schroeder = 0, Random = 1, AllZero = 2
};

typedef enum
{
  HAAR = 0,     ///< Haar / DB1  (2 taps)
  DB4  = 1,     ///< Daubechies-4  (8 taps)
  DB6  = 2,     ///< Daubechies-6  (12 taps)
  DB8  = 3,     ///< Daubechies-8  (16 taps)
  DB10 = 4,     ///< Daubechies-10 (20 taps)
  SYM4 = 5,     ///< Symlet-4      (8 taps)
  SYM8 = 6,     ///< Symlet-8      (16 taps)
  COIF2 = 7,    ///< Coiflet-2     (12 taps)
  COIF4 = 8,    ///< Coiflet-4     (24 taps)

  NoWaveletType = 0xFF
} PP_WaveletType;

typedef enum
{
  MonitoringOverUsb,
  MonitoringOverSpi,

  NoMonInterface = 0xFF
} PP_MonInterface;

typedef enum
{
  TYPE_String,
  TYPE_RealArray,
  TYPE_Uint32Array,
  TYPE_Uint16Array,
  TYPE_Uint8Array,
  TYPE_Uint32,
  TYPE_Real,
  TYPE_Uint16,
  TYPE_Uint8,

  TYPE_NoType = 0xFF
} PP_FuncParamId;

typedef union
{
  const char *ParamString;
  float *ParamRealArray;
  uint32_t *ParamUint32Array;
  uint16_t *ParamUint16Array;
  uint8_t *ParamUint8Array;
  uint32_t ParamUint32;
  float ParamReal;
  uint16_t ParamUint16;
  uint8_t ParamUint8;
} PP_FuncParam;

typedef struct
{
  PP_FuncParam FuncParams[PP_FUNC_PARAM_MAX_NBR];
  PP_FuncParamId FuncParamIds[PP_FUNC_PARAM_MAX_NBR];
  uint16_t FuncParamSizes[PP_FUNC_PARAM_MAX_NBR];
  uint16_t DataSize;
  uint16_t LastChunkSize;
  uint16_t blockId;
  PP_SubFuncId SubFuncId;
  PP_FuncId FuncId;
  uint8_t NbrOfParams;
  uint8_t NbrOfChunks;
} PP_FuncInfo;

typedef struct
{
  uint32_t ReceivedCrc;
  uint32_t CalculatedCrc;
  uint16_t SeqNbr;
  uint8_t ReadWrite;
} PP_TransactionInfo;

typedef struct
{
  PP_FuncInfo FuncInfo;
  PP_TransactionInfo TransactionInfo;
} PP_CommandInfo;

typedef void (*PP_ErrorHandlerType)(void);

typedef void (*PP_TransportVoidFn)(void *context);
typedef void (*PP_TransportBeginTransactionFn)(void *context, const SPISettings *settings);
typedef void (*PP_TransportTransferBufferFn)(void *context, uint8_t *buffer, uint16_t size);
/** Bytes in the board's 96-bit MCU unique id. */
#define PP_BOARD_UNIQUE_ID_SIZE 12u
/** Wire size of the GetBoardInfo payload: u16 part number + the UID. */
#define PP_BOARD_INFO_WIRE_SIZE (2u + PP_BOARD_UNIQUE_ID_SIZE)
/** Wire size of the GetDesignInstrumentation payload. */
#define PP_DESIGN_INSTRUMENTATION_WIRE_SIZE 32u

/**
 * @brief Board identity, as answered by PAPAYA::getBoardInfo.
 */
typedef struct
{
  /** Product part number: identifies the board model. */
  uint16_t partNumber;
  /** 96-bit MCU unique id; a tamper-evident board fingerprint. */
  uint8_t uniqueId[PP_BOARD_UNIQUE_ID_SIZE];
} PP_BoardInfo;

/** Wire size of the GetCaptureStatus payload. */
#define PP_CAPTURE_STATUS_WIRE_SIZE 9u

/* Dataset FLASH slots. STORAGE for recorded signals; nothing plays a slot.
 * A signalSource::dataset block carries its own recording in the command
 * that creates it. These values are what the board reports and expects. */
#define PP_DATASET_SLOT_COUNT 8u
/** One list/info record: u8, u8, u16, then four u32. A record carried a
 *  char name[64] and does not any more: a recording is played by a block,
 *  and a block has an id. */
#define PP_DATASET_RECORD_WIRE_SIZE 20u
/** Samples one slot's payload holds: 458752 B / 4. This is the board's
 *  own per-slot ceiling; a longer upload is refused. */
#define PAPAYA_DATASET_MAX_SAMPLES 114688u
/** Payload bytes in ONE wire param. The descriptor packs the length into
 *  12 bits, so 4095 is the ceiling; 4092 is the largest multiple of 4 under
 *  it, which keeps whole float32 samples in a segment. Matches the Python
 *  library's _DATASET_UPLOAD_SEG_BYTES. */
#define PAPAYA_DATASET_SEG_BYTES 4092u

/* What a Dataset block needs to work out its own playback rate. A
 * recording plays once over its natural duration, so the traversal rate is
 * Fs / N: the sampling frequency startDesign() was given, over the number
 * of samples in the slot. Both are recorded by the library, which is why
 * signalSource::dataset() takes no frequency. Exposed so a program that
 * wants the number (to print it, say) does not have to recompute it. */
float PapayaDesignSamplingFreq(void);
uint32_t PapayaDatasetSlotSamples(uint16_t slot);
float PapayaDatasetPlaybackFreq(uint32_t nSamples, float fs);
void PapayaNoteDatasetSlot(uint16_t slot, uint32_t nSamples);
/** Payload bytes per UploadDatasetChunk command. 14 segments of 4092 B,
 *  the same step the Python library uses, so both send the same frames.
 *  A chunk travels as 14 SEPARATE params, not one: see SendSlotChunk. */
#define PAPAYA_DATASET_CHUNK_BYTES 57288u

/* Audio recording slots. Same Start/Chunk/Commit shape as datasets, but
 * the record carries no name and the occupancy byte is a STATE rather
 * than a flag. These values are what the board reports and expects. */
#define PP_AUDIO_SLOT_COUNT 1u
/** One list/info record: the same 20 header bytes, with no name. */
#define PP_AUDIO_RECORD_WIRE_SIZE 20u

/**
 * @brief What an audio slot is currently doing.
 *
 * Unlike a dataset slot, an audio slot can be mid-recording. Treating
 * that as merely "not occupied" would invite a caller to overwrite a
 * capture that is still being flushed, so it is its own state.
 */
typedef enum
{
  PP_AudioSlot_Empty = 0u,
  PP_AudioSlot_Occupied = 1u,
  /** Recording or flushing: the slot is in use; do not write to it. */
  PP_AudioSlot_Busy = 2u
} PP_AudioSlotState;

/**
 * @brief One audio slot's header.
 */
typedef struct
{
  uint8_t slotId;
  PP_AudioSlotState state;
  uint16_t format;
  uint32_t sampleRateHz;
  uint32_t lengthSamples;
  uint32_t crc32;
  uint32_t timestamp;
} PP_AudioSlotInfo;

/**
 * @brief One dataset slot's header.
 *
 * @c occupied false means the slot is empty and every other field is
 * meaningless. Check it before trusting a length.
 */
typedef struct
{
  uint8_t slotId;
  bool occupied;
  /** Sample encoding; 0 is the float32 default the upload helpers use. */
  uint16_t format;
  uint32_t sampleRateHz;
  uint32_t lengthSamples;
  /** CRC-32 the uploader committed, for verifying a download. */
  uint32_t crc32;
  /** Unix timestamp recorded at commit, or 0 if the uploader passed none. */
  uint32_t timestamp;
} PP_DatasetInfo;

/* Maximum payload the firmware can send for the two variable-length
 * text queries. These matter more than they look: the response carries
 * no length, and a read SHORTER than what the board sent leaves the
 * remainder in the pipe, where it is mistaken for the next command's
 * response. Every command after that fails and the board looks dead.
 * Reading MORE than was sent is harmless (the transfer ends on its own
 * short packet), so both queries always request the maximum. */
#define PP_DESIGN_INFO_MAX_SIZE 1024u
#define PP_DEBUG_LOG_MAX_SIZE (16u * 1024u)

/**
 * @brief Progress of an offline capture, from PAPAYA::getCaptureStatus.
 */
typedef struct
{
  /** Samples written to the trace so far. */
  uint32_t capturedSamples;
  /** Samples the capture was asked for (see PAPAYA::setTraceSize). */
  uint32_t requestedSamples;
  /** Non-zero once the capture has finished. */
  uint8_t complete;
} PP_CaptureStatus;

/**
 * @brief Design cost on the board, as answered by
 *        PAPAYA::getDesignInstrumentation.
 *
 * Field order and units follow the firmware's 32-byte payload exactly.
 * ``cpuLoadPctX100`` is percent scaled by 100 (4250 = 42.50 %) so the
 * value stays integral on the wire.
 */
typedef struct
{
  /** Worst-case processing time for one sample period, microseconds. */
  uint32_t cpuCycleUs;
  /** The sample period itself, microseconds (0 when Fs is unset). */
  uint32_t periodUs;
  /** Application memory the design occupies, bytes. */
  uint32_t appMemUsedBytes;
  /** Application memory still available, bytes. */
  uint32_t appMemFreeBytes;
  /** Total application memory pool, bytes. */
  uint32_t appMemTotalBytes;
  /** Peak application memory use, bytes. */
  uint32_t appMemHighWatermark;
  /** CPU load as percent x100; saturates at 10000 (100 %). */
  uint16_t cpuLoadPctX100;
  /** Application memory use as a whole percent, 0..100. */
  uint8_t appMemUsedPct;
} PP_DesignInstrumentation;

/**
 * @brief Samples the board packs per probe in one pushed batch.
 *
 * The board packs at most 128 samples per probe into one pushed batch.
 * Only an upper bound is needed here: the actual count is derived from
 * each packet's length.
 */
#define PP_MON_MAX_SAMPLES_PER_PROBE 128u

/**
 * @brief Size of the scratch buffer for one pushed probe batch.
 *
 * Full size is 16 probes x 128 samples x 4 bytes + 1 opcode ~= 8 KB,
 * which is nothing on a PC host and impossible on a small MCU.
 *
 * The push model is USB-only. A microcontroller reaches the board over
 * SPI, never reads a pushed packet, and so gets 1 byte here by default
 * (see PAPAYA_TARGET_MCU at the top of this header). A host build keeps
 * the full buffer. Either way, set it in ``papaya_target_config.h`` to
 * override.
 */
#ifndef PAPAYA_PUSH_PROBE_BUFFER_BYTES
#  if PAPAYA_TARGET_MCU
#    define PAPAYA_PUSH_PROBE_BUFFER_BYTES 1u
#  else
#    define PAPAYA_PUSH_PROBE_BUFFER_BYTES \
       (1u + (PP_MAX_PROBES_NUMBER * PP_MON_MAX_SAMPLES_PER_PROBE * PP_REAL_SIZE))
#  endif
#endif

/**
 * @brief Read ONE whole auto-pushed packet, reporting its real length.
 *
 * Optional, and only meaningful on a transport where the board pushes
 * unprompted, i.e. USB. The ordinary byte hooks cannot express this:
 * they read an exact count and return nothing, so there is no way to ask
 * "what arrived, and how much of it".
 *
 * Implementations must return the number of bytes of one transfer copied
 * into @p buffer, or 0 if nothing arrived before @p timeoutMs. They must
 * NOT block for the full timeout once a packet has been delivered, and
 * must never return a partial packet: the batch decoder derives the
 * samples-per-probe count from the length, so a short read would be
 * silently mis-decoded rather than detected.
 *
 * Register with PAPAYA::setPacketReader(). Without one, readProbesLive()
 * and readProbesLatest() decline; getProbes() (the request/response pull
 * model, which SPI needs anyway) is unaffected.
 */
typedef uint16_t (*PP_TransportRxPacketFn)(uint8_t *buffer,
                                           uint16_t capacity,
                                           uint32_t timeoutMs);

/** Longest input/probe name this host will keep, including the NUL. */
#define PP_REMOTE_NAME_MAX 32u
/** Names held per kind by PP_RemoteDesign. */
#define PP_REMOTE_MAX_NAMES 16u

/**
 * @brief What the board says its loaded design offers.
 *
 * This is everything interaction code needs and nothing it does not: the
 * inputs it may write (only those with remote monitoring enabled reach
 * this list), and the probes it may read, by name, in the order their
 * values appear on the wire.
 *
 * It exists so an interaction program does NOT have to contain the
 * diagram. The diagram is authored in PAPAYA Studio and deployed; the
 * interaction program attaches to whatever is loaded and asks. A program
 * that instead rebuilt the diagram would carry a stale copy of it and
 * break every time the design changed.
 */
typedef struct
{
  /** Sampling rate of the loaded design, Hz. */
  float sampleRateHz;
  /** Samples the board packs per probe in one pushed batch. */
  uint16_t samplesPerProbe;

  uint8_t inputCount;
  char inputNames[PP_REMOTE_MAX_NAMES][PP_REMOTE_NAME_MAX];
  /** Value each input held when the design was described. */
  float inputValues[PP_REMOTE_MAX_NAMES];

  uint8_t probeCount;
  char probeNames[PP_REMOTE_MAX_NAMES][PP_REMOTE_NAME_MAX];
} PP_RemoteDesign;

/** Label length in a vector-probe descriptor, including the NUL. */
#define PP_VECTOR_PROBE_LABEL_MAX 16u
/** One descriptor on the wire: 4 u16 fields + the label. */
#define PP_VECTOR_PROBE_DESC_WIRE_SIZE 24u

/**
 * @brief Shape of one monitored vector probe.
 *
 * A vector probe carries a block of values per sample rather than a
 * single number, so a caller decoding its payload needs to know how that
 * block is laid out. Without this table the payload is an anonymous run
 * of bytes and the only way to interpret it is to have built the design
 * yourself and remembered.
 */
typedef struct
{
  /** Position in the monitored set, matching the payload's ordering. */
  uint16_t index;
  uint16_t lines;
  uint16_t rows;
  /** Bytes this probe contributes to each pushed payload. */
  uint16_t bytes;
  /** NUL-terminated. */
  char label[PP_VECTOR_PROBE_LABEL_MAX];
} PP_VectorProbeDesc;

/**
 * @brief Outcome of a live probe read, including how stale it was.
 *
 * The board pushes batches at its own cadence and they queue up. A
 * caller slower than that cadence reads progressively older data while
 * every individual read still succeeds, so "it worked" is not the same
 * as "this is current", and only @ref ageBatches distinguishes them.
 */
typedef struct
{
  /** True when a batch was received and the probe buffer refreshed. */
  bool ok;
  /** Samples the board packed per probe in this batch. */
  uint16_t samplesPerProbe;
  /**
   * Newer batches that were already waiting behind this one.
   *
   * Always 0 for readProbesLive(), which takes the oldest queued batch.
   * For readProbesLatest() it is how many were discarded to reach the
   * newest: 0 means the caller is keeping up, and a persistently
   * rising value means it is not.
   */
  uint16_t ageBatches;
} PP_ProbeRead;

typedef uint8_t (*PP_TransportTransferByteFn)(void *context, uint8_t value);
typedef void (*PP_TransportTxBytesFn)(uint8_t *txBuffer, uint16_t numberOfBytes);
typedef void (*PP_TransportRxBytesFn)(uint8_t *rxBuffer, uint16_t numberOfBytes);
typedef void (*PP_TransportPinModeFn)(void *context, int pin, int mode);
typedef void (*PP_TransportDigitalWriteFn)(void *context, int pin, int value);
typedef void (*PP_TransportSelectBoardFn)(void *context, uint8_t boardId);
typedef void (*PP_TransportSetResetFn)(void *context, bool asserted);
typedef void (*PP_TransportChipSelectFn)(void *context, int csPin, bool selected, uint16_t csDelayUs);
typedef void (*PP_TransportDelayMsFn)(void *context, unsigned long delayMs);
typedef void (*PP_TransportDelayUsFn)(void *context, unsigned int delayUs);
typedef unsigned long (*PP_TransportMillisFn)(void *context);

typedef struct
{
  void *context = nullptr;
  PP_TransportVoidFn begin = nullptr;
  PP_TransportVoidFn end = nullptr;
  PP_TransportBeginTransactionFn beginTransaction = nullptr;
  PP_TransportVoidFn endTransaction = nullptr;
  PP_TransportTransferBufferFn transferBuffer = nullptr;
  PP_TransportTransferByteFn transferByte = nullptr;
  PP_TransportPinModeFn pinMode = nullptr;
  PP_TransportDigitalWriteFn digitalWrite = nullptr;
  PP_TransportSelectBoardFn selectBoard = nullptr;
  PP_TransportSetResetFn setReset = nullptr;
  PP_TransportChipSelectFn chipSelect = nullptr;
  PP_TransportDelayMsFn delayMs = nullptr;
  PP_TransportDelayUsFn delayUs = nullptr;
  PP_TransportMillisFn millis = nullptr;
} PP_TransportHooks;

/**
 * @brief Scalar probe for monitoring a signal (connected to a block output).
 * @details
 *  - Inputs (1): signal
 *  - Outputs (0): none
 */
class probe
{
private:
  uint16_t id;
  /* 0xFFu sentinel = "not yet queued". addToQueue() is idempotent against
   * double-linking (e.g. `tf1 > p; tf2 > p;` would otherwise advance the
   * host probe counter twice while the firmware uses one slot). */
  uint8_t idx = 0xFFu;
  uint8_t contextSlot = 0xFFu;
  const char *label;

public:
  static uint16_t currentProbeId;
  static uint8_t currentProbeIdx;
  float value;

  /**
   * @brief Construct a new probe object
   *
   */
  probe();

  /**
   * @brief Construct a new probe object with label
   *
   * @param label
   */
  explicit probe(const char *label);

  /**
   * @brief Returns the probe’s ID.
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Displays probe information
   *
   */
  void show();

  /**
   * @brief Manually assigns an ID to the probe.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this probe.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the probe to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Retrieves the probe’s current floating-point value.
   *
   * @return float
   */
  float getVal();

  /**
   * @brief ID-keyed read for EEPROM-stored applications.
   *
   * @details Use this overload when the host (typically a SPI or USB
   *          master) is driving an application that was created by
   *          PAPAYA Studio and stored to EEPROM, so the probe block was
   *          never instantiated locally and you only know the probe by
   *          the wire ID Studio assigned at save-time
   *          (``PROBE_<APP>_<NAME>`` from the generated SPI-master
   *          header).  The slot is derived from
   *          ``id - PP_PROBE_ID_BASE``; ``currentProbeIdx`` auto-grows
   *          so the next ``readProbesLive()`` request matches the
   *          firmware's response size.
   *
   * @param id  Studio-assigned wire ID (>= ``PP_PROBE_ID_BASE``).
   * @return    Most recent value sampled into the host's probe buffer,
   *            or 0 if ``id`` falls outside the buffer.
   */
  static float getVal(uint16_t id);

  /**
   * @brief Value at a buffer POSITION, for code that discovered it.
   *
   * getVal(id) keys on the Studio-assigned wire id; this keys on the
   * position the value occupies on the wire, which is what
   * PAPAYA::describeDesign reports and what PAPAYA::remoteProbeIndex
   * returns. Interaction code knows names and positions, not ids.
   */
  static float valueAt(uint8_t index);

  /**
   * @brief Retrieves the probe’s integer value.
   *
   * @return int32_t
   */
  int32_t getIntVal();

  /**
   * @brief Returns the probe’s label.
   *
   * @return const char*
   */
  const char *getLabel();

  /**
   * @brief Adds the probe to a processing/measurement queue.
   *
   */
  void addToQueue();
};

/**
 * @brief Vector probe for multi-sample outputs (FFT/DWT/RLS...).
 * @details
 *  - Inputs (0): none
 *  - Outputs (0): none (receives vector data via buffer port)
 */
class VectorProbe
{
private:
  uint16_t id;
  /* 0xFFu sentinel = "not yet queued"; addToQueue() is idempotent so a
   * double-link (e.g. `tf1 >> v; tf2 >> v;`) does not double-advance
   * VectorProbeBytes and currentVectorProbeIdx. */
  uint8_t idx = 0xFFu;
  /* uint32_t: with PP_MAX_VECTOR_PROBES_NUMBER=9 * PP_MAX_VECTOR_PROBES_BYTES=8192
   * the cumulative offset can reach 73728 > 0xFFFF; uint16 wrapped silently
   * and corrupted later probes' read offsets. */
  uint32_t bufferOffsetBytes = 0u;
  uint8_t contextSlot = 0xFFu;
  const char *label;

public:
  uint16_t dataLines;
  uint16_t dataRaw;
  static uint16_t currentVectorProbeId;
  static uint32_t VectorProbeBytes;
  static uint8_t currentVectorProbeIdx;

  /**
   * @brief Construct a new Vector Probe object
   *
   */
  VectorProbe();

  /**
   * @brief Construct a new Vector Probe object with label
   *
   * @param label
   */
  explicit VectorProbe(const char *label);

  /**
   * @brief Get the Id object
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Prints vector probe information.
   *
   */
  void show();

  /**
   * @brief Manually assigns an ID to the vector probe.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this vector probe.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the vector probe to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Returns the byte offset of this probe inside the shared vector buffer.
   *
   * @return uint32_t
   */
  uint32_t getBufferOffsetBytes() const;

  /**
   * @brief Sets the byte offset of this probe inside the shared vector buffer.
   *
   * @param offsetBytes
   */
  void setBufferOffsetBytes(uint32_t offsetBytes);

  /**
   * @brief Retrieves a set of samples and stores them in VectorProbesBuffer.
   *
   * @param samples
   * @param nbrOfSamples
   */
  void getSamples(float *samples, uint16_t nbrOfSamples);

  /**
   * @brief Returns the label.
   *
   * @return const char*
   */
  const char *getLabel();

  /**
   * @brief Registers the vector probe into the processing queue.
   *
   */
  void addToQueue();
};

/* =============================== Nodes & Macros =============================== */

/**
 * @brief Generic processing node with configurable multi-input/multi-output coefficients.
 * @details IO count is driven by coefficient sizes (or explicitly provided).
 */
class node
{
private:
  uint16_t id;
  uint8_t contextSlot = 0xFFu;

  /**
   * @brief Selected destination input index when this node is used as a destination.
   *
   */
  uint8_t activeInIdx;

  /**
   * @brief Selected source output index when this node is used as a source.
   *
   */
  uint8_t activeOutIdx;

public:
  uint16_t dataLines;
  uint16_t dataRaw;
  static uint16_t currentNodeId;

  /**
   * @brief Construct a default node object
   *
   */
  node();

  /**
   * @brief Creates a node object with specific input/output coefficient parameters.
   *
   * @param inCoef : input coefficient string
   * @param outCoef : output coefficient string
   * @param Type : node type
   */
  node(const char *inCoef, const char *outCoef, PP_NodeType Type);

  /**
   * @brief Construct a new node object
   *
   * @param inCoef : input coefficient array
   * @param inSize : size of input coefficient array
   * @param outCoef : output coefficient array
   * @param outSize : size of output coefficient array
   * @param Type : node type
   */
  node(const float *inCoef, uint8_t inSize, const float *outCoef, uint8_t outSize, PP_NodeType Type);

  /**
   * @brief Returns the node’s ID.
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Manually assigns an ID.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this node.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the node to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Returns the current selected input index.
   *
   * @return uint8_t
   */
  uint8_t getActiveInIdx();

  /**
   * @brief Returns the current selected output index.
   *
   * @return uint8_t
   */
  uint8_t getActiveOutIdx();

  /**
   * @brief Selects a specific input index, returns the node for chaining.
   *
   * @param inIdx
   * @return node
   */
  node in(uint8_t inIdx);

  /**
   * @brief Selects a specific output index, returns the node for chaining.
   *
   * @param outIdx
   * @return node
   */
  node out(uint8_t outIdx);

  /**
   * @brief Connects this node to a transfer-function object.
   *
   * @param tfDst
   */
  void operator>(tf tfDst);

  /**
   * @brief Routes this node’s output to a scalar probe.
   *
   * @param probeDst
   */
  void operator>(probe &probeDst);

  /**
   * @brief Chains this node into another node.
   *
   * @param nodeDst
   */
  void operator>(node nodeDst);

  /**
   * @brief Sends output into a macro-level processing block.
   *
   * @param macroDst
   */
  void operator>(macro macroDst);

  /**
   * @brief Sends a vector output to a VectorProbe object.
   *
   * @param vectorProbeDst
   */
  void operator>>(VectorProbe &vectorProbeDst);
};

/**
 * @brief Composite subgraph that encapsulates internal nodes and connections.
 * @details Used to modularize and hide complexity.
 *
 * A macro can expose up to N inputs and M outputs. To allow tf-like usage for macros that expose
 * exactly one input and/or one output, the macro maintains two independent active indices:
 *  - activeInIdx  : selected destination input index when this macro is used as a destination
 *  - activeOutIdx : selected source output index when this macro is used as a source
 *
 * If the user does not explicitly select ports using in(i)/out(i), the default selected ports are:
 *  - activeInIdx  = 0
 *  - activeOutIdx = 0
 *
 * This enables connections like:  butterBq(...) > otherBlock;
 * without requiring explicit indexing for single-I/O macros.
 */
class macro
{
private:
  uint16_t id;
  uint8_t contextSlot = 0xFFu;
  uint8_t activeInIdx;
  uint8_t activeOutIdx;

public:
  static uint16_t currentMacroId;

  /**
   * @brief Creates a default macro object.
   *
   */
  macro();

  /**
   * @brief Creates a macro with specific input/output coefficient parameters.
   *
   * @param NbrOfInputs  : number of inputs
   * @param NbrOfOutputs : number of outputs
   */
  macro(uint8_t NbrOfInputs, uint8_t NbrOfOutputs);

  /**
   * @brief Returns the macro’s unique ID.
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Manually assigns an ID.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this macro.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the macro to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Returns the currently active input index.
   *
   * @return uint8_t
   */
  uint8_t getActiveInIdx();

  /**
   * @brief Returns the currently active output index.
   *
   * @return uint8_t
   */
  uint8_t getActiveOutIdx();

  /**
   * @brief Selects a specific input and returns the macro (for chaining).
   *
   * @param InIdx
   * @return macro
   */
  macro in(uint8_t InIdx);

  /**
   * @brief Selects a specific output and returns the macro.
   *
   * @param OutIdx
   * @return macro
   */
  macro out(uint8_t OutIdx);

  /**
   * @brief Connects macro output to a transfer-function block.
   *
   * @param Dst
   */
  void operator>(tf Dst);

  /**
   * @brief Routes macro output to a scalar probe.
   *
   * @param Dst
   */
  void operator>(probe &Dst);

  /**
   * @brief Connects macro into a node.
   *
   * @param Dst
   */
  void operator>(node Dst);

  /**
   * @brief Chains this macro into another macro.
   *
   * @param Dst
   */
  void operator>(macro Dst);

  /**
   * @brief Activates or enables the macro’s internal processing.
   *
   */
  void start();

  /**
   * @brief Deactivates or pauses the macro.
   *
   */
  void stop();
};

/* =============================== Input Source =============================== */

/**
 * @brief External scalar source whose value is provided by the host.
 * @details Can be constant or host-modified at runtime.
 *  - Inputs (0): none
 *  - Outputs (1): value
 */
class input
{
private:
  uint16_t id;
  float val;
  uint8_t idx;
  uint8_t contextSlot = 0xFFu;
  const char *label;

public:
  static uint16_t currentInputId;
  static uint8_t currentInputIdx;

  /**
   * @brief Creates an empty input with default values.
   *
   */
  input();

  /**
   * @brief Creates an input with a descriptive label and initial value
   *
   * @param label
   * @param val : initial value
   */
  input(const char *label, float val);

  /**
   * @brief Returns the input’s unique ID.
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Manually assigns an ID.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this input.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the input to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Submits a new value to the system queue
   *
   * @param inputValue
   */
  void addToQueue(float inputValue);

  /**
   * @brief ID-keyed write for EEPROM-stored applications.
   *
   * @details Use this overload when the host (typically a SPI or USB
   *          master) is driving an application that was created by
   *          PAPAYA Studio and stored to EEPROM, so the input block
   *          was never instantiated locally and you only know the
   *          input by the wire ID Studio assigned at save-time
   *          (``INPUT_<APP>_<NAME>`` from the generated SPI-master
   *          header).  The slot is derived from
   *          ``id - PP_INPUT_ID_BASE``; ``currentInputIdx`` auto-grows
   *          so the next ``writeInputsLive()`` push covers every staged
   *          slot.
   *
   * @param inputValue  Float value to stage.
   * @param id          Studio-assigned wire ID (>= ``PP_INPUT_ID_BASE``).
   */
  static void addToQueue(float inputValue, uint16_t id);

  /**
   * @brief Stage a value at a buffer POSITION, for discovered inputs.
   *
   * Companion to probe::valueAt: takes the position
   * PAPAYA::remoteInputIndex returns. Stages only: call
   * PAPAYA::writeInputsLive() to push, so several inputs can be set and
   * applied together rather than the design seeing a half-updated set.
   */
  static void setValueAt(uint8_t index, float value);

  /**
   * @brief Enables remote managed input updates.
   *
   */
  void enableRemote();

  /**
   * @brief Returns the input label.
   *
   * @return const char*
   */
  const char *getLabel();

  /**
   * @brief Connects the input to a transfer function.
   *
   * @param tfDst
   */
  void operator>(tf tfDst);

  /**
   * @brief Connects this input to a processing node.
   *
   * @param nodeDst
   */
  void operator>(node nodeDst);

  /**
   * @brief Connects the input to a macro-level processing block.
   *
   * @param macroDst
   */
  void operator>(macro macroDst);
};

/* =============================== Transfer Functions & Friends =============================== */

/**
 * @brief Continuous-time linear transfer function defined by numerator/denominator.
 * @details Discrete version is computed using sampling frequency and the selected discretization algorithm.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class tf
{
private:
  uint16_t id;
  uint8_t contextSlot = 0xFFu;

public:
  uint16_t dataLines;
  uint16_t dataRaw;
  static uint16_t currentSysId;
  /**
   * @brief Default constructor creating a default transfer function.
   *
   */
  tf();

  /**
   * @brief Returns the transfer function’s ID.
   *
   * @return uint16_t
   */
  uint16_t getId();

  /**
   * @brief Manually assigns an ID.
   *
   * @param id
   */
  void setId(uint16_t id);

  /**
   * @brief Returns the board context bound to this transfer function.
   *
   * @return uint8_t
   */
  uint8_t getContextSlot() const;

  /**
   * @brief Binds the transfer function to a board context.
   *
   * @param slot
   */
  void setContextSlot(uint8_t slot);

  /**
   * @brief Creates a transfer function using coefficient strings
   *
   * @param numerator
   * @param denominator
   */
  tf(const char *numerator, const char *denominator);

  /**
   * @brief Creates a transfer function using numeric arrays and explicit size parameters.
   *
   * @param numerator : pointer to numerator coefficients
   * @param numSize   : size of numerator array
   * @param denominator : pointer to denominator coefficients
   * @param denomSize : size of denominator array
   */
  tf(float *numerator, uint8_t numSize, float *denominator, uint8_t denomSize);

  /**
   * @brief Sends this TF's output into another transfer function.
   *
   * @param dstTf : destination transfer function
   */
  void operator>(tf dstTf);

  /**
   * @brief Sends this TF's output to a scalar probe.
   *
   * @param dstProbe : destination probe
   */
  void operator>(probe &dstProbe);

  /**
   * @brief Sends TF output into a node.
   *
   * @param nodeDst : destination node
   */
  void operator>(node nodeDst);

  /**
   * @brief Sends TF output into a macro.
   *
   * @param macroDst : destination macro
   */
  void operator>(macro macroDst);

  /**
   * @brief Routes TF output into a vector probe
   *
   * @param vectorProbeDst : destination vector probe
   */
  void operator>>(VectorProbe &vectorProbeDst);
};

/**
 * @brief Discrete-time linear transfer function.
 * @details User must ensure the coefficients match the configured sampling frequency.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class tfd : public tf
{
public:
  /**
   * @brief Creates a discrete transfer function
   *
   * @param numerator :  numerator coefficients
   * @param denominator : denominator coefficients
   * @param sysord : system order
   */
  tfd(float *numerator, float *denominator, uint8_t sysord);
};

/**
 * @brief Butterworth filter (low/high/band/stop).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class butter : public tf
{
public:
  /**
   * @brief Construct a new Single-Cutoff butterworth Filter
   *
   * @param n     Filter order
   * @param fc    Cutoff frequency
   * @param ftype Filter type (passLow, passHigh, passBand, stopBand)
   */
  butter(uint8_t n, float fc, PP_FilterType ftype);

  /**
   * @brief Construct a new butter object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   */
  butter(uint8_t n, float fc1, float fc2, PP_FilterType ftype);
};

/**
 * @brief Noise source (uniform or Gaussian).
 * @details Input may be used as a modulation/carrier depending on firmware behavior.
 *  - Inputs (1): in
 *  - Outputs (1): noise
 */
class noise : public tf
{
public:
  /**
   * @brief This constructor initializes the noise generator
   *
   * @param value1 : Minimum amplitude
   * @param value2 : Maximum amplitude
   * @param type : uniform,gaussian
   */
  noise(float value1, float value2, PP_NoiseType type);
};

/**
 * @brief FIR filter designed by windowing method (N, cutoff(s), window, type).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class fir : public tf
{
public:
  /**
   * @brief Construct a new single-cutoff fir
   *
   * @param N : Filter order
   * @param f1 : Cutoff frequency
   * @param wt : Window type ( Hanning, Blackman)
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   */
  fir(uint16_t N, float f1, PP_FirWindowType wt, PP_FilterType ftype);

  /**
   * @brief Construct a new Dual-Cutoff FIR
   *
   * @param N : Filter order
   * @param f1 : Lower cutoff frequency
   * @param f2 : Upper cutoff frequency
   * @param wt : Window type ( Hanning, Blackman
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   */
  fir(uint16_t N, float f1, float f2, PP_FirWindowType wt, PP_FilterType ftype);
};

/**
 * @brief Custom FIR filter with user-provided coefficients.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class CustFir : public tf
{
public:
  /**
   * @brief Construct a new Cust Fir object
   *
   * @param coefficients : pointer to filter coefficients
   * @param size : number of coefficients
   */
  CustFir(float *coefficients, uint16_t size);
};

/**
 * @brief 2D magnitude (sqrt(x^2 + y^2)).
 * @details
 *  - Inputs (2): x, y
 *  - Outputs (1): mag
 */
class mag2 : public node
{
public:
  /**
   * @brief Construct a new mag2 object.
   *
   */
  mag2();
};

/**
 * @brief 3D magnitude (sqrt(x^2 + y^2 + z^2)).
 * @details
 *  - Inputs (3): x, y, z
 *  - Outputs (1): mag
 */
class mag3 : public node
{
public:
  /**
   * @brief Construct a new mag3 object.
   *
   */
  mag3();
};

/* ---------------------------------------------------------------------------
 * Infrastructure blocks
 * ---------------------------------------------------------------------------
 */

/**
 * @brief Hamilton product (multiplication) of two quaternions: q3 = q1 (x) q2.
 *
 * Component form (Diebel 2006):
 *   qw = w1*w2 - x1*x2 - y1*y2 - z1*z2
 *   qx = w1*x2 + x1*w2 + y1*z2 - z1*y2
 *   qy = w1*y2 - x1*z2 + y1*w2 + z1*x2
 *   qz = w1*z2 + x1*y2 - y1*x2 + z1*w2
 *
 * @details
 *  - Inputs  (8): q1w, q1x, q1y, q1z, q2w, q2x, q2y, q2z
 *  - Outputs (4): qw, qx, qy, qz
 *
 * Foundation block for AHRS pipelines and rigid-body kinematics. Composition
 * convention: ``q1 (x) q2`` applies q2 first, then q1. If both inputs are
 * unit quaternions, the output is unit (no per-step renormalisation
 * required).
 *
 * @note Reference: Diebel 2006, Representing Attitude (Stanford TR).
 */
class quatMult : public node
{
public:
  /**
   * @brief Construct a new quatMult block.
   *
   * Zero-parameter constructor; the block always exposes 8 inputs and 4
   * outputs in the order documented above.
   */
  quatMult();
};

/**
 * @brief Convert Euler angles (roll, pitch, yaw) to a quaternion (ZYX order).
 * @details
 *  - Inputs (3) : roll, pitch, yaw (radians)
 *  - Outputs (4): w, x, y, z
 * @note Reference: Diebel 2006 §5.6 (aerospace ZYX convention).
 */
class quatFromEuler : public node { public: quatFromEuler(); };

/**
 * @brief Convert a quaternion to Euler angles (roll, pitch, yaw, ZYX order).
 * @details
 *  - Inputs (4) : w, x, y, z
 *  - Outputs (3): roll, pitch, yaw (radians); pitch clipped to ±π/2
 * @note Reference: Diebel 2006 §5.6.
 */
class quatToEuler : public node { public: quatToEuler(); };

/**
 * @brief Convert a quaternion to a 3×3 rotation matrix (row-major, 9 outputs).
 * @details
 *  - Inputs (4)  : w, x, y, z
 *  - Outputs (9) : r00, r01, r02, r10, r11, r12, r20, r21, r22
 * @note Reference: Diebel 2006 §5.5.
 */
class quatToRotmat : public node { public: quatToRotmat(); };

/**
 * @brief Quaternion normalise / conjugate / inverse selector.
 * @details
 *  - Inputs (5) : w, x, y, z, mode (0=NORM, 1=CONJ, 2=INV)
 *  - Outputs (4): w', x', y', z'
 */
class quatNormConj : public node { public: quatNormConj(); };

/**
 * @brief Sliding-window framer with hop H.
 *
 * Maintains a circular buffer of the most-recent N input samples; every H
 * samples emits a chronological length-N frame snapshot via VectorProbe and
 * pulses output 0 (frame_ready = 1.0).
 *
 * @details
 *  - Inputs  (1): x (scalar sample)
 *  - Outputs (1): frame_ready (1.0f on emit cycle, else 0.0f)
 *  - VectorProbe: rows = N, lines = 1 (oldest-to-newest)
 *
 * @param N  frame length (1 <= N <= 2048)
 * @param H  hop length   (1 <= H <= N; H == N for non-overlapping)
 *
 * @note Reference: Allen & Rabiner 1977 - Proc-IEEE 65 (STFT framing).
 */
class windowFramer : public tf
{
public:
  windowFramer(uint16_t N, uint16_t H);
};

/**
 * @brief STFT framer: windowed sliding-window framer.
 *
 * Same ring + hop pattern as ``windowFramer``, but each emitted frame is
 * element-wise multiplied by an analysis window (Hann / Hamming / Blackman).
 *
 * @details
 *  - Inputs  (1): x (scalar)
 *  - Outputs (1): frame_ready (1.0f on emit cycle, else 0.0f)
 *  - VectorProbe: rows = N, lines = 1 (windowed frame)
 *
 * @param N            frame length (1 <= N <= 2048)
 * @param H            hop length   (1 <= H <= N)
 * @param WindowType   0 = Hann (default), 1 = Hamming, 2 = Blackman
 *
 * @note Reference: Harris 1978 - Proc-IEEE 66.
 */
class stftFramer : public tf
{
public:
  stftFramer(uint16_t N, uint16_t H, uint16_t WindowType);
};

/**
 * @brief Welford running z-score normalizer.
 * @details
 *  - Inputs (2) : x, freeze (>0.5 to force-freeze)
 *  - Outputs (1): z
 */
class zScoreNorm : public node
{
public:
  zScoreNorm(uint16_t TrainWindowN, float Epsilon);
};

/**
 * @brief Chi-square innovation gate.
 * @details
 *  - Inputs (2·NMeas): y_0..y_{n-1}, σ_0..σ_{n-1}
 *  - Outputs (2): chi2, fault
 */
class innovationChi2 : public node
{
public:
  innovationChi2(uint16_t NMeas, float Threshold);
};

/**
 * @brief IMU accel + gyro bias estimator.
 * @details
 *  - Inputs (6) : ax, ay, az, gx, gy, gz
 *  - Outputs (12): ax̃, ãy, ãz, ω̃x, ω̃y, ω̃z, bias_ax, bias_ay, bias_az, bias_gx, bias_gy, bias_gz
 */
class imuBiasEst : public node
{
public:
  imuBiasEst(uint16_t VarWindow, float RestThreshold, float Alpha);
};

/**
 * @brief Variable-K feature-vector concatenator.
 * @details
 *  - Inputs (K) : in_0..in_{K-1}, packed in port order into one length-K
 *    feature vector every cycle.
 *  - Outputs (1): out_0 is 1.0 on every cycle in which the stack was
 *    refreshed, which is every cycle. It carries no feature data. Its
 *    purpose is to give the block a linkable output, since a block with
 *    no connected output is never placed on the execution schedule.
 *    Connect it or the VectorProbe (or both), or the block never runs.
 *  - The feature vector itself is read from a VectorProbe attached to this
 *    block (rows = K, lines = 1). No block consumes it: pcaProject and
 *    decisionTree read their own K scalar inputs, so wire the feature
 *    sources into those as well.
 */
class featureStack : public node
{
public:
  featureStack(uint16_t K);
};

/* Flight and fusion blocks.
 * The sample period comes from the design's global Fs, which the board
 * reads at run time; there is no Ts parameter on the wire. */
class madgwickAhrs : public node {
public: madgwickAhrs(float Beta);
};
class mahonyAhrs : public node {
public: mahonyAhrs(float Kp, float Ki);
};
class complementaryAhrs : public node {
public: complementaryAhrs(float Alpha);
};
class mixerMultirotor : public node {
public: mixerMultirotor(uint8_t FrameType, float PwmMin, float PwmMax);
};

/* LQR state-feedback with servo integrator.
 *
 *   Inputs  (n + p):  x_0..x_{n-1}  plant state
 *                     e_0..e_{p-1}  tracking error r-y (wire an external
 *                                   Sum node "[1 -1]" with r at in(0) and
 *                                   y at in(1))
 *   Outputs (m):      u_0..u_{m-1}  saturated control
 *
 *   u[k]     = -K_x·x[k] - K_i·x_i[k],    clipped to [-UMax, +UMax]
 *   x_i[k+1] = x_i[k] + Ts·e[k]
 *
 * K is m·(n+p) row-major: K[i,:] = [ K_x_i (n) | K_i_i (p) ].
 * UMax<=0 disables saturation.  Sample period Ts is taken from the design's
 * global Fs, which the board reads at run time. */
class lqrServo : public node {
public: lqrServo(uint16_t n, uint16_t m, uint16_t p, float* K, float UMax);
};

/* Motion and control blocks. Sample period from global Fs. */
class trajScurve     : public node { public: trajScurve(); };
class trajTrapezoid  : public node { public: trajTrapezoid(); };
class frictionStribeck : public tf { public: frictionStribeck(float Fc, float Fs, float vs, float Bv); };
class inputShaper    : public tf { public: inputShaper(uint8_t Mode, float Wn, float Zeta); };

/* Biomedical blocks. emgEnvelope sample period from global Fs at create. */
class hjorth         : public node { public: hjorth(uint16_t WindowN); };
class emgEnvelope    : public tf { public: emgEnvelope(float CutoffHz); };
class emgHudgins     : public node { public: emgHudgins(uint16_t WindowN, float ZcThreshold); };
class ecgBlRemove    : public tf { public: ecgBlRemove(uint16_t WindowW); };
class hrvTime        : public node { public: hrvTime(uint16_t RingN); };
class eegBandpower   : public node { public: eegBandpower(fftMagResolver fftMagInstance); };

/* AI and feature-extraction blocks */
class skewKurt        : public node { public: skewKurt(uint16_t WindowN); };
class percentile      : public tf { public: percentile(float Quantile); };
class peakToPeak      : public tf { public: peakToPeak(uint16_t WindowN); };
class crestFactor     : public tf { public: crestFactor(uint16_t WindowN); };
class zcr             : public tf { public: zcr(uint16_t WindowN, float ZcThreshold); };
class spectralFeatures: public node { public: spectralFeatures(fftMagResolver fftMagInstance); };
class cepstrum        : public node { public: cepstrum(fftMagResolver fftMagInstance); };
class autocorrLags    : public tf { public: autocorrLags(uint16_t N, uint16_t L, uint16_t D); };
class pcaProject      : public node { public: pcaProject(uint16_t K, uint16_t P, float* W, float* mu); };
class decisionTree    : public node { public: decisionTree(uint16_t K, uint16_t C, uint16_t NNodes,
                                                            uint16_t* FeatIdx, float* Thresh,
                                                            uint16_t* Left, uint16_t* Right, float* LeafVal); };

/**
 * @brief Delay operator delaying signal by N samples.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): delayed
 */
class delayop : public tf
{
public:
  /**
   * @brief Construct a new delay op object
   *
   * @param NbrOfSamples
   */
  delayop(uint16_t NbrOfSamples);
};

/**
 * @brief Moving average filter (sliding window).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): avg
 */
class movingAverage : public tf
{
public:
  /**
   * @brief Construct a new moving Average object
   *
   * @param NbrOfSamples
   */
  movingAverage(uint16_t NbrOfSamples);
};
/**
 * @brief Measures signal period by timing intervals between detected edges.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): period
 */
class period : public tf
{
public:
  /**
   * @brief Construct a new period object
   *
   * @param Max : Maximum expected signal value
   * @param Min : Minimum expected signal value
   * @param Epsilon : Measurement resolution
   */
  period(float Max, float Min, float Epsilon);
};

/**
 * @brief Measures up/down period characteristics of a signal.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): period
 */
class UpDwnperiod : public tf
{
public:
  /**
   * @brief This constructor initializes the dual-edge period meter for precise detection of rising and falling edges.
   *
   * @param Max : Maximum expected signal amplitude
   * @param Min : Minimum expected signal amplitude
   * @param Epsilon : Measurement resolution
   */
  UpDwnperiod(float Max, float Min, float Epsilon);
};

/**
 * @brief Chebyshev Type I IIR filter expressed as a transfer function (TF).
 * @details Achieves a steeper transition band than Butterworth by allowing controlled passband ripple.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class cheby1 : public tf
{
public:
  /**
   * @brief Construct a new cheby1 object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg : Chebyshev configuration
   */
  cheby1(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg);

  /**
   * @brief Construct a new cheby1 object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg :  Chebyshev configuration
   */
  cheby1(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg);
};

/**
 * @brief Chebyshev Type II (inverse Chebyshev) IIR filter expressed as a transfer function (TF).
 * @details Has a ripple-free passband and an equiripple stopband.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class cheby2 : public tf
{
public:
  /**
   * @brief Construct a new cheby2 object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg : Chebyshev configuration
   */
  cheby2(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg);

  /**
   * @brief Construct a new cheby2 object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg : Chebyshev configuration
   */
  cheby2(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg);
};

/**
 * @brief Elliptic (Cauer) IIR filter expressed as a transfer function (TF).
 * @details Achieves the steepest transition band by allowing ripple in both passband and stopband.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class ellip : public tf
{
public:
  /**
   * @brief Construct a new ellip object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param ellipCfg
   */
  ellip(uint8_t n, float fc, PP_FilterType ftype, PP_EllipCfg ellipCfg);

  /**
   * @brief Construct a new ellip object
   *
   * @param n : filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param ellipCfg
   */
  ellip(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_EllipCfg ellipCfg);
};

/**
 * @brief Biquad cascade implementation of Butterworth filter.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class butterBq : public macro
{
public:
  /**
   * @brief Construct a new butter Bq object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   */
  butterBq(uint8_t n, float fc, PP_FilterType ftype);

  /**
   * @brief Construct a new butter Bq object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   */
  butterBq(uint8_t n, float fc1, float fc2, PP_FilterType ftype);
};

/**
 * @brief Chebyshev Type I IIR filter implemented as a cascade of biquads (second-order sections).
 * @details Biquad cascade is more numerically robust for higher orders and narrow bands.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class cheby1Bq : public macro
{
public:
  /**
   * @brief Construct a new cheby1 Bq object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg
   */
  cheby1Bq(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg);

  /**
   * @brief Construct a new cheby1 Bq object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg
   */
  cheby1Bq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby1Cfg chebyCfg);
};

/**
 * @brief Chebyshev Type II (inverse Chebyshev) IIR filter implemented as a cascade of biquads (second-order sections).
 * @details Cascaded biquads (SOS) are typically more numerically robust than a single high-order TF realization.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class cheby2Bq : public macro
{
public:
  /**
   * @brief Construct a new cheby2 Bq object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg
   */
  cheby2Bq(uint8_t n, float fc, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg);

  /**
   * @brief Construct a new cheby2 Bq object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param chebyCfg
   */
  cheby2Bq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_Cheby2Cfg chebyCfg);
};

/**
 * @brief Elliptic (Cauer) IIR filter implemented as a cascade of biquads (second-order sections).
 * @details Implementing the filter as SOS improves numerical stability for higher orders.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class ellipBq : public macro
{
public:
  /**
   * @brief Construct a new ellip Bq object
   *
   * @param n : Filter order
   * @param fc : Cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param ellipCfg
   */
  ellipBq(uint8_t n, float fc, PP_FilterType ftype, PP_EllipCfg ellipCfg);

  /**
   * @brief Construct a new ellip Bq object
   *
   * @param n : Filter order
   * @param fc1 : Lower cutoff frequency
   * @param fc2 : Upper cutoff frequency
   * @param ftype : Filter type (passLow,passHigh,passBand,stopBand)
   * @param ellipCfg
   */
  ellipBq(uint8_t n, float fc1, float fc2, PP_FilterType ftype, PP_EllipCfg ellipCfg);
};

/**
 * @brief Measures amplitude of a sine wave at a given frequency.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): amplitude
 */
class sineAm : public macro
{
public:
  /**
   * @brief Construct a new sine Am object
   *
   * @param sineFreq
   */
  explicit sineAm(float sineFreq);
};

/**
 * @brief PI/PD/PID controller depending on constructor used.
 * @details
 *  - Inputs (1): error
 *  - Outputs (1): command
 */
class pid : public tf
{
public:
  /**
   * @brief Creates a Proportional-Integral controller.
   *
   * @param ki : integral gain
   * @param kp : proportional gain
   */
  pid(float ki, float kp);

  /**
   * @brief Creates a Proportional-Derivative controller with a derivative filter.
   *
   * @param kp : proportional gain
   * @param kd : derivative gain
   * @param tau : derivative low-pass filter time constant
   */
  pid(float kp, float kd, float tau);

  /**
   * @brief Implements a complete PID controller with filtered derivative.
   *
   * @param ki : integral gain
   * @param kp : proportional gain
   * @param kd : derivative gain
   * @param tau : derivative low-pass filter time constant
   */
  pid(float ki, float kp, float kd, float tau);
};

/**
 * @brief Live PID controller (gains tunable via inputs).
 * @details
 *  - Inputs (5): error, Kp, Ki, Kd, Tau
 *  - Outputs (1): command
 */
class livePid : public macro
{
public:
  /**
   * @brief Implements a complete tuneable PID controller with filtered derivative.
   *
   */
  livePid();
};

/**
 * @brief Live PI controller (gains tunable via inputs).
 * @details
 *  - Inputs (3): error, Kp, Ki
 *  - Outputs (1): command
 */
class livePi : public macro
{
public:
  /**
   * @brief Implements a tuneable PI controller.
   *
   */
  livePi();
};

/**
 * @brief Live PD controller (gains tunable via inputs).
 * @details
 *  - Inputs (4): error, Kp, Kd, Tau
 *  - Outputs (1): command
 */
class livePd : public macro
{
public:
  /**
   * @brief implements a tuneable PD controller with filtered derivative.
   *
   */
  livePd();
};

/**
 * @brief 2-DOF Live PID controller.
 * @details
 *  - Inputs (8): ref, meas, ki, kp, kd, tau, b, c
 *  - Outputs (1): command
 */
class live2Pid : public macro
{
public:
  /**
   * @brief Construct a new live2 Pid object
   *
   */
  live2Pid();
};

/**
 * @brief PI/PID controller with output limits and anti-windup.
 * @details
 *  - Inputs (1): error
 *  - Outputs (1 or 2): command, then saturated only when report is 1.
 *    The saturated output reads 1.0 on any sample where the clamp
 *    CHANGED the command, which is not the same as the command
 *    being at a limit: in integrator-clamp mode the integral term
 *    is held back so the command reaches the limit without being
 *    clipped, and the flag reads 0.0 while it sits there.
 *  - mode selects the anti-windup strategy: 1 back-calculation,
 *    2 conditional integration, 3 integrator clamp.
 */
class pidAw : public node
{
public:
  /**
   * @brief Creates a PI/PID controller that limits its own output and holds
   *        its integral term in check while the output sits at a limit.
   *
   * @param ki : integral gain. Must not be zero: a controller with no
   *             integral term cannot wind up, so clamp its output with sat
   *             instead.
   * @param kp : proportional gain
   * @param kd : derivative gain. Zero gives a PI controller.
   * @param tau : derivative low-pass filter time constant, in seconds. Only
   *              used when kd is non-zero, and must then be positive.
   * @param u_min : lowest command the actuator accepts
   * @param u_max : highest command the actuator accepts
   * @param Tt : recovery time constant, in seconds. Only used by
   *             back-calculation.
   * @param mode : 1 back-calculation, 2 conditional integration,
   *               3 integrator clamp
   * @param report : 1 adds the saturated output, 0 leaves it out
   */
  pidAw(float ki, float kp, float kd, float tau,
        float u_min, float u_max, float Tt,
        uint8_t mode, uint8_t report);
};

/**
 * @brief Live PID controller with anti-windup: gains, limits and the
 *        recovery time constant all arrive as signals.
 * @details
 *  - Inputs (7 or 8): error, Kp, Ki, Kd, Tau, out_max, out_min, then Tt
 *    only in mode 1 (back-calculation). The port count depends on mode: a
 *    recovery time constant means nothing to modes 2 and 3, so they have
 *    no Tt port.
 *  - Outputs (1 or 2): command, then saturated only when report is 1.
 */
class livePidAw : public node
{
public:
  /**
   * @brief Construct a new livePidAw object
   *
   * @param mode : 1 back-calculation, 2 conditional integration,
   *               3 integrator clamp
   * @param report : 1 adds the saturated output, 0 leaves it out
   */
  livePidAw(uint8_t mode, uint8_t report);
};

/**
 * @brief Live PI controller with anti-windup.
 * @details
 *  - Inputs (5 or 6): error, Kp, Ki, out_max, out_min, then Tt only in
 *    mode 1 (back-calculation). The port count depends on mode: modes 2
 *    and 3 have no Tt port.
 *  - Outputs (1 or 2): command, then saturated only when report is 1.
 */
class livePiAw : public node
{
public:
  /**
   * @brief Construct a new livePiAw object
   *
   * @param mode : 1 back-calculation, 2 conditional integration,
   *               3 integrator clamp
   * @param report : 1 adds the saturated output, 0 leaves it out
   */
  livePiAw(uint8_t mode, uint8_t report);
};

/**
 * @brief 2-DOF live PID controller with anti-windup.
 * @details
 *  - Inputs (10 or 11): ref, meas, kp, ki, kd, tau, b, c, out_max,
 *    out_min, then Tt only in mode 1 (back-calculation). The port count
 *    depends on mode: modes 2 and 3 have no Tt port.
 *  - Outputs (1 or 2): command, then saturated only when report is 1.
 */
class live2PidAw : public node
{
public:
  /**
   * @brief Construct a new live2PidAw object
   *
   * @param mode : 1 back-calculation, 2 conditional integration,
   *               3 integrator clamp
   * @param report : 1 adds the saturated output, 0 leaves it out
   */
  live2PidAw(uint8_t mode, uint8_t report);
};

/**
 * @brief All-pass filter (phase shaping with unity magnitude).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class allpass : public tf
{
public:
  /**
   * @brief Construct a new allpass object
   *
   * @param freq : Center frequency of the all-pass filter
   * @param phi  : Desired phase shift at the specified frequency (radians)
   */
  allpass(float freq, float phi);
};

/**
 * @brief Notch filter around a given center frequency and Q.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class notch : public tf
{
public:
  notch(float centernotch, float qualcoef);
};

/**
 * @brief Peaking filter around a given center frequency and Q.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class peak : public tf
{
public:
  /**
   * @brief Construct a new peak object
   *
   * @param centernotch : Center frequency of the peak filter
   * @param qualcoef : Quality factor (Q) that determines the bandwidth
   */
  peak(float centernotch, float qualcoef);
};

/**
 * @brief Dynamics compressor with attack, release, threshold, and ratio.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class compressor : public tf
{
public:
  /**
   * @brief Construct a new compressor object
   *
   * @param Attack : The time the compressor takes to start applying gain reduction after the input signal exceeds the threshold.
   * @param Release : The time the compressor takes to return the gain back to normal after the signal falls below the threshold.
   * @param Threshold_dB : The level above which compression starts.
   * @param Ratio : The amount of compression applied once the signal passes the threshold.
   */
  compressor(float Attack, float Release, float Threshold_dB, float Ratio);
};

/**
 * @brief Sliding-window absolute maximum.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): abs_max
 */
class absMax : public tf
{
public:
  /**
   * @brief Construct a new abs Max object
   *
   * @param Length
   */
  absMax(uint8_t Length);
};

/**
 * @brief Sliding-window absolute minimum.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): abs_min
 */
class absMin : public tf
{
public:
  /**
   * @brief Construct a new abs Min object
   *
   * @param Length
   */
  absMin(uint8_t Length);
};
/**
 * @brief Sliding-window maximum.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): max
 */
class maximum : public tf
{
public:
  /**
   * @brief Construct a new maximum object
   *
   * @param Length
   */
  maximum(uint32_t Length);
};

/**
 * @brief Sliding-window minimum.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): min
 */
class minimum : public tf
{
public:
  /**
   * @brief Construct a new min object
   *
   * @param Length
   */
  minimum(uint32_t Length);
};
/**
 * @brief Sliding-window entropy measure.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): entropy
 */
class entropy : public tf
{
public:
  /**
   * @brief Construct a new entropy object
   *
   * @param Length
   */
  entropy(uint8_t Length);
};

/**
 * @brief Sliding-window power (mean-square) measure.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): power
 */
class power : public tf
{
public:
  /**
   * @brief Construct a new power object
   *
   * @param Length
   */
  power(uint8_t Length);
};

/**
 * @brief Sliding-window mean (average).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): mean
 */
class mean : public tf
{
public:
  /**
   * @brief Construct a new mean object
   *
   * @param Length
   */
  mean(uint8_t Length);
};

/**
 * @brief Sliding-window RMS.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): rms
 */
class rootMeanSquare : public tf
{
public:
  /**
   * @brief Construct a new root Mean Square object
   *
   * @param Length
   */
  rootMeanSquare(uint8_t Length);
};

/**
 * @brief Sliding-window standard deviation.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): std_dev
 */
class standardDeviation : public tf
{
public:
  /**
   * @brief Construct a new standard Deviation object
   *
   * @param Length
   */
  standardDeviation(uint8_t Length);
};

/**
 * @brief Sliding-window variance.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): variance
 */
class variance : public tf
{
public:
  /**
   * @brief Construct a new variance object
   *
   * @param Length
   */
  variance(uint8_t Length);
};

/**
 * @brief Interpolator block (anti-imaging filter used during interpolation).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class interpolation : public tf
{
public:
  /**
   * @brief Construct a new interpolation object
   *
   * @param M_u32
   */
  explicit interpolation(uint32_t M_u32);
};

/* =============================== System / Plant / IO =============================== */

/**
 * @brief Schmitt trigger node (hysteresis comparator).
 * @details
 *  - Inputs (5): signal, Vmax, Vmin, high_th, low_th
 *  - Outputs (1): out
 */
class schmidt : public node
{
public:
  /**
   * @brief Construct a new schmidt object
   *
   */
  schmidt();
};

/**
 * @brief Comparator node.
 * @details
 *  - Inputs (4): Vsatp, Vsatm, Vinp, Vinm
 *  - Outputs (1): out
 */
class comp : public node
{
public:
  /**
   * @brief Construct a new comp object
   *
   */
  comp();
};

/**
 * @brief Saturation nonlinearity.
 * @details
 *  - Inputs (3): Vsatp, Vsatm, signal
 *  - Outputs (1): out
 */
class sat : public node
{
public:
  /**
   * @brief Construct a new sat object
   *
   */
  sat();
};

/**
 * @brief Dead-zone nonlinearity.
 * @details
 *  - Inputs (3): dead1, dead2, signal
 *  - Outputs (1): out
 */
class deadZone : public node
{
public:
  deadZone();
};

/**
 * @brief Backlash + deadband nonlinearity.
 * @details
 *  - Inputs (2): deadband, signal
 *  - Outputs (1): out
 */
class backlashDeadBand : public node
{
public:
  backlashDeadBand();
};

/**
 * @brief Merger node that reduces multiple inputs into a single output.
 * @details Typically sum/merge behavior as defined in firmware.
 *  - Inputs (variable): input signals
 *  - Outputs (1): out
 */
class merger : public node
{
public:
  /**
   * @brief Construct a new merger object
   *
   * @param nbrOfInputs
   */
  explicit merger(uint8_t nbrOfInputs);
};

/**
 * @brief Sign function node (+1 / -1).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): sign
 */
class sign : public node
{
public:
  /**
   * @brief Construct a new sign object
   *
   */
  sign(void);
};

/**
 * @brief Gain block: multiplies input by a constant coefficient.
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class gain : public node
{
public:
  /**
   * @brief Construct a new gain object
   *
   * @param gainValue The gain coefficient
   */
  explicit gain(float gainValue);
};

/**
 * @brief Square function system (x²).
 * @details  Single input / single output, order 0.
 */
class sqrMath : public tf
{
public:
  sqrMath(void);
};

/**
 * @brief Square-root system.
 * @details  Single input / single output, order 0.
 */
class sqrtBlock : public tf
{
public:
  sqrtBlock(void);
};

/**
 * @brief Sine function system sin(x), input in radians.
 * @details  Single input / single output, order 0.
 */
class sineFunc : public tf
{
public:
  sineFunc(void);
};

/**
 * @brief Cosine function system cos(x), input in radians.
 * @details  Single input / single output, order 0.
 */
class cosineFunc : public tf
{
public:
  cosineFunc(void);
};

/**
 * @brief Absolute-value system |x|.
 * @details  Single input / single output, order 0.
 */
class absVal : public tf
{
public:
  absVal(void);
};

/**
 * @brief Two-argument arc-tangent node atan2(y, x).
 * @details  Inputs (2): y, x  |  Outputs (1): angle
 */
class atan2Block : public node
{
public:
  atan2Block(void);
};

/**
 * @brief Natural-logarithm system ln(x).
 * @details  Single input / single output, order 0.
 */
class logFunc : public tf
{
public:
  logFunc(void);
};

/**
 * @brief Exponential system e^x.
 * @details  Single input / single output, order 0.
 */
class expFunc : public tf
{
public:
  expFunc(void);
};

/**
 * @brief Negation system (-x).
 * @details  Single input / single output, order 0.
 */
class negate : public tf
{
public:
  negate(void);
};

/**
 * @brief Reciprocal system (1/x).
 * @details  Single input / single output, order 0.
 */
class inverse : public tf
{
public:
  inverse(void);
};

/**
 * @brief Conditional switch.  out = (control >= 0) ? in1 : in2.
 * @details  Inputs (3): control, in1, in2  |  Outputs (1): out
 */
class switchBlock : public node
{
public:
  switchBlock(void);
};

/**
 * @brief Quantiser node.  out = round(signal / step) * step.
 * @details  Inputs (2): signal, step  |  Outputs (1): out
 */
class quantizer : public node
{
public:
  quantizer(void);
};

/**
 * @brief Integrator with an initial condition and an external reset.
 * @details  Inputs (3): signal, reset, initial condition  |  Outputs (1): out
 *           While reset is above 0.5 the output is held at the initial
 *           condition; when it falls back, integration resumes from there.
 */
class integratorIC : public node
{
public:
  integratorIC(void);
};

/**
 * @brief Floored modulo.  out = x - floor(x / m) * m.
 * @details  Inputs (2): x, m  |  Outputs (1): out
 *           The result takes the sign of the divisor; a modulus of zero
 *           passes x through unchanged.
 */
class modulo : public node
{
public:
  modulo(void);
};

/**
 * @brief Pure integrator system H(s) = 1/s.
 * @details  Single input / single output.  Auto-discretised.
 */
class integrator : public tf
{
public:
  integrator(void);
};

/**
 * @brief Filtered derivative system H(s) = s / (tau*s + 1).
 * @details  Single input / single output.  Auto-discretised.
 * @param Tau  Filter time constant (seconds).
 */
class derivative : public tf
{
public:
  derivative(float Tau = 0.01f);
};

/**
 * @brief Slew-rate limiter.
 * @details  Inputs (3): signal, rising_rate, falling_rate  |  Outputs (1): out
 */
class rateLimiter : public node
{
public:
  rateLimiter(void);
};

/**
 * @brief Sample-and-hold.  Latches on rising edge of trigger.
 * @details  Inputs (2): signal, trigger  |  Outputs (1): held
 */
class sampleHold : public node
{
public:
  sampleHold(void);
};

/**
 * @brief Clarke transform (Ia, Ib) -> (Ialpha, Ibeta).
 * @details  Inputs (2): Ia, Ib  |  Outputs (2): Ialpha, Ibeta
 */
class clarke : public node
{
public:
  clarke(void);
};

/**
 * @brief Inverse Clarke transform (Ialpha, Ibeta) -> (Ia, Ib).
 * @details  Inputs (2): Ialpha, Ibeta  |  Outputs (2): Ia, Ib
 */
class invClarke : public node
{
public:
  invClarke(void);
};

/**
 * @brief Park transform (Ialpha, Ibeta, theta) -> (Id, Iq).
 * @details  Inputs (3): Ialpha, Ibeta, theta  |  Outputs (2): Id, Iq
 */
class park : public node
{
public:
  park(void);
};

/**
 * @brief Inverse Park transform (Id, Iq, theta) -> (Ialpha, Ibeta).
 * @details  Inputs (3): Id, Iq, theta  |  Outputs (2): Ialpha, Ibeta
 */
class invPark : public node
{
public:
  invPark(void);
};

/**
 * @brief Lead-lag compensator K*(s+z)/(s+p).
 * @details  Inputs (1): in  |  Outputs (1): out
 */
class leadLag : public tf
{
public:
  leadLag(float K, float z, float p);
};

/**
 * @brief Washout (high-pass) filter s/(s+a).
 * @details  Inputs (1): in  |  Outputs (1): out
 */
class washout : public tf
{
public:
  explicit washout(float a);
};

/**
 * @brief Expander node that fans out a single input to multiple outputs.
 * @details
 *  - Inputs (1): in
 *  - Outputs (variable): output signals
 */
class expander : public node
{
public:
  /**
   * @brief Construct a new expander object
   *
   * @param nbrOfOutputs
   */
  explicit expander(uint8_t nbrOfOutputs);
};

/**
 * @brief Adaptive Kalman Filter (AKF) for state estimation in systems where the
 *        measurement noise characteristics change over time.
 * @details Adaptively updates R at each sample: R = alpha*R + (1-alpha)*(y*y' + H*P*H').
 *
 * IO configuration (variable, depends on dim_x, dim_z, dim_u):
 *  - Inputs [0..dim_z-1]: Measurement vector z
 *  - Inputs [dim_z..dim_z+dim_u-1]: Control input vector u (if dim_u > 0)
 *  - Input  [dim_z+dim_u]: Live-tune Q diagonal value (PP_LiveTune mode only)
 *  - Outputs [0..dim_x-1]: Estimated state vector x
 *
 * Requires design-time matrices: F (state transition), H (observation),
 * Q (process noise), B (control input). Initial conditions: x_init, P_init, R_init.
 */
class adaptiveKF : public node
{
public:
  /**
   * @brief Construct a new adaptive Kalman Filter object
   *
   * @param AKF : parameter structure.
   */
  adaptiveKF(PP_adaptiveKF *AKF);

  /**
   * @brief Construct a new tunable adaptive Kalman object
   *
   * @param AKF : parameter structure.
   * @param select : selects a tuning mode
   */
  adaptiveKF(PP_adaptiveKF *AKF, PP_Tune select);
};

/**
 * @brief Linear Kalman Filter (LKF) for optimal state estimation in linear systems
 *        affected by process and measurement noise.
 * @details
 * IO configuration (variable, depends on dim_x, dim_z, dim_u):
 *  - Inputs [0..dim_z-1]: Measurement vector z
 *  - Inputs [dim_z..dim_z+dim_u-1]: Control input vector u (if dim_u > 0)
 *  - Input  [dim_z+dim_u]: Live-tune Q diagonal value (PP_LiveTune mode only)
 *  - Outputs [0..dim_x-1]: Estimated state vector x
 *
 * Requires design-time matrices: F (state transition), H (observation),
 * Q (process noise), B (control input). Initial conditions: x_init, P_init, R_init.
 */
class linearKF : public node
{
public:
  /**
   * @brief Construct a new linear Kalman Filter object
   *
   * @param LKF : configuration structure.
   */
  linearKF(PP_linearKF *LKF);

  /**
   * @brief Construct a new tunable linear Kalman Filter object
   *
   * @param LKF : configuration structure.
   * @param select : selects a tuning mode
   */
  linearKF(PP_linearKF *LKF, PP_Tune select);
};

/**
 * @brief Discrete-time state-space system (SISO / MIMO).
 * @details
 * Implements:
 *   x[k+1] = A·x[k] + B·u[k]
 *   y[k]   = C·x[k] + D·u[k]
 *
 * IO configuration:
 *  - Inputs  [0..m-1]: Input vector u
 *  - Outputs [0..p-1]: Output vector y
 */
class stateSpace : public node
{
public:
  /**
   * @brief Construct a new state-space system node.
   *
   * @param config : configuration structure with A, B, C, D matrices and initial state.
   */
  stateSpace(PP_stateSpace *config);
};

/**
 * @brief Complementary filter for sensor fusion.
 * @details
 *  y[k] = alpha * (y[k-1] + rate[k] * Ts) + (1 - alpha) * meas[k]
 *  - Input 0: rate signal (e.g. gyroscope angular rate)
 *  - Input 1: absolute measurement (e.g. accelerometer angle)
 *  - Output 0: filtered estimate
 */
class compFilter : public node
{
public:
  /**
   * @brief Construct a new complementary filter node.
   * @param config : configuration structure with alpha blend factor.
   */
  compFilter(PP_compFilter *config);
};

/**
 * @brief Sliding Mode Observer (SISO / MIMO).
 * @details
 *  x_hat[k+1] = A*x_hat + B*u + L*e + K*sat(e/epsilon)
 *  where e = y - C*x_hat
 *  - Inputs [0..m-1]: control input u
 *  - Inputs [m..m+p-1]: measurement y
 *  - Outputs [0..n-1]: estimated state x_hat
 */
class slidingModeObserver : public node
{
public:
  /**
   * @brief Construct a new sliding mode observer node.
   * @param config : configuration structure with A, B, C, L, K matrices and initial state.
   */
  slidingModeObserver(PP_SMO *config);
};

class pmsmEKF : public node { public: pmsmEKF(PP_PMSM_EKF *config); };
class ahrsEKF : public node { public: ahrsEKF(PP_AHRS_EKF *config); };
class batterySOC_EKF : public node { public: batterySOC_EKF(PP_BatterySOC_EKF *config); };
class tiltEKF : public node { public: tiltEKF(PP_Tilt_EKF *config); };
class loadTorqueEKF : public node { public: loadTorqueEKF(PP_LoadTorque_EKF *config); };

/* ---- New Application EKF block classes ---- */
class thermalEKF : public node { public: thermalEKF(PP_Thermal_EKF *config); };
class baroAltEKF : public node { public: baroAltEKF(PP_BaroAlt_EKF *config); };
class robotLocEKF : public node { public: robotLocEKF(PP_RobotLoc_EKF *config); };
class sinTrackEKF : public node { public: sinTrackEKF(PP_SinTrack_EKF *config); };
class gridSyncEKF : public node { public: gridSyncEKF(PP_GridSync_EKF *config); };
class acimEKF : public node { public: acimEKF(PP_ACIM_EKF *config); };
class batterySOH_EKF : public node { public: batterySOH_EKF(PP_BatterySOH_EKF *config); };
class wmrEKF : public node { public: wmrEKF(PP_WMR_EKF *config); };
class gpsinsEKF : public node { public: gpsinsEKF(PP_GPSINS_EKF *config); };

/* ---- Adaptive DSP block classes ---- */
class lms : public node { public: lms(PP_LMSConfig *config); };
class adaptiveNotch : public node { public: adaptiveNotch(PP_AdaptiveNotchConfig *config); };
class dob : public node { public: dob(PP_DOBConfig *config); };
class esc : public node { public: esc(PP_ESCConfig *config); };
class adrc : public node { public: adrc(PP_ADRCConfig *config); };
class mrac : public node { public: mrac(PP_MRACConfig *config); };
class mracLyapunov : public node { public: mracLyapunov(PP_MRACLyapunovConfig *config); };
class repetitiveCtrl : public node { public: repetitiveCtrl(PP_RepCtrlConfig *config); };
class str : public node { public: str(PP_STRConfig *config); };
class ilc : public node { public: ilc(PP_ILCConfig *config); };

/* ---- Self-tuning PID block classes ---- */
class gainSchedulePID : public node { public: gainSchedulePID(PP_GainSchedulePIDConfig *config); };
class gainScheduler : public node { public: gainScheduler(PP_GainSchedulerConfig *config); };
class relayAutoTune : public node { public: relayAutoTune(PP_RelayAutoTuneConfig *config); };
class stepAutoTune : public node { public: stepAutoTune(PP_StepAutoTuneConfig *config); };
class strPID : public node { public: strPID(PP_STR_PID_Config *config); };
class mracPID : public node { public: mracPID(PP_MRAC_PID_Config *config); };
class escPID : public node { public: escPID(PP_ESC_PID_Config *config); };
class perfMonitorPID : public node { public: perfMonitorPID(PP_PerfMonPID_Config *config); };
class fuzzyPID : public node { public: fuzzyPID(PP_FuzzyPIDConfig *config); };

/* ---- Miscellaneous block classes ---- */
class momentaryPower : public tf { public: momentaryPower(uint16_t windowSize); };
/** @brief Sliding-window maximum: the output follows the largest of the
 *         last windowSize input samples.
 *  @param windowSize Window length in samples. */
class maxObserver : public tf { public: maxObserver(uint8_t windowSize); };
/** @brief Sliding-window minimum: the output follows the smallest of the
 *         last windowSize input samples.
 *  @param windowSize Window length in samples. */
class minObserver : public tf { public: minObserver(uint8_t windowSize); };
/** @brief Multiplexer: selects one of N data inputs based on a selector input.
 *  @details Inputs 0..N-1 are data channels, input N is the selector (float,
 *           rounded and clamped to [0, N-1]).  Output 0 carries the selected value.
 *  @param numInputs Number of data input channels (selector port is added automatically). */
class mux : public node { public: mux(uint8_t numInputs); };
/** @brief Demultiplexer: routes one data input to one of N outputs based on a selector input.
 *  @details Input 0 is the data signal, input 1 is the selector (float,
 *           rounded and clamped to [0, N-1]).  Non-selected outputs are zeroed.
 *  @param numOutputs Number of output channels. */
class demux : public node { public: demux(uint8_t numOutputs); };
class loudness : public node { public: loudness(); };
class cpuLoad : public tf { public: cpuLoad(); };
class extSensor : public node { public: extSensor(PP_HwId hwId, PP_SensorPartNumber partNumber, float outScale = 1.0f); };
class decibelsConverter : public node { public: decibelsConverter(); };
class combFeedForward : public tf { public: combFeedForward(uint16_t delay, float gain); };
class combFeedBack : public tf { public: combFeedBack(uint16_t delay, float gain); };

/**
 * @brief Robust Recursive Least Squares identification.
 * @details Produces vector output compatible with VectorProbe.
 *  - Inputs (2): y, u
 *  - Outputs (2): y_hat, error
 */
class RRLS : public node
{
public:
  /**
   * @brief Construct a new RRLS object
   *
   * @param data : configuration structure.
   */
  explicit RRLS(PP_RRLSParam *data);
};

/**
 * @brief Recursive Least Squares identification.
 * @details Produces vector output compatible with VectorProbe.
 *  - Inputs (2): y, u
 *  - Outputs (2): y_hat, error
 */
class RLS : public node
{
public:
  /**
   * @brief Construct a new RLS object
   *
   * @param data : configuration structure.
   */
  explicit RLS(PP_RLSParam *data);
};

/**
 * @brief PID gains computed from an identified model.
 *
 * @details
 *   Reads the model an RLS or RRLS block has fitted, maps it back to
 *   continuous time through the design's own discretisation, and computes
 *   internal-model-control PID gains for it. Drive the four outputs into the
 *   Kp, Ki, Kd and Tau inputs of a live PID.
 *
 *   The identifier is a constructor argument rather than a wired input,
 *   because the coefficients are its internal state and no wire carries
 *   them. Only RLS and RRLS are accepted.
 *
 *   - Inputs (1):  identifier
 *   - Outputs (4): Kp, Ki, Kd, Tau
 *   - Vector output (8): Kp, Ki, Kd, Tau, identified DC gain, identified
 *     natural frequency in Hz, identified damping ratio, status
 *
 *   The closed loop the gains produce is 1/(lambda*s + 1)^2, whose -3 dB
 *   bandwidth is 0.1024/lambda Hz. On a plant it cannot tune it holds the
 *   previous gains rather than computing a plausible wrong one, and the
 *   status value says why.
 *
 * @param identifier      The RLS or RRLS block whose model to read.
 * @param lambda_c        Closed-loop time constant, seconds.
 * @param gain_slew_per_s Largest change per second in any gain, as a
 *                        fraction of the value it is moving towards.
 *                        0 disables the rate limit.
 * @param kp_max          Ceiling on the magnitude of Kp. 0 means none.
 * @param ki_max          Ceiling on the magnitude of Ki. 0 means none.
 * @param kd_max          Ceiling on the magnitude of Kd. 0 means none.
 */
class pidFromModel : public node
{
public:
  /* One overload per accepted identifier, which is how this header spells
   * "any one of these": the block needs an RLS or an RRLS, not both. */
  pidFromModel(RLS identifier, float lambda_c, float gain_slew_per_s,
               float kp_max, float ki_max, float kd_max);
  pidFromModel(RRLS identifier, float lambda_c, float gain_slew_per_s,
               float kp_max, float ki_max, float kd_max);
};

/**
 * @brief AM-modulated periodic oscillator.
 *
 * @details
 *   The output is multiplied at every sample by an external @b amplitude
 *   input port, so the amplitude is a runtime signal, not a parameter.
 *   Reach for ``amOscillator`` whenever the amplitude must come from
 *   another block (AM modulation, runtime gain control, envelope shaping).
 *   For a static-amplitude generator with 17 shapes / run modes /
 *   triggering, use ``signalSource`` instead.
 *
 *   - Inputs (1):  amplitude,   runtime gain a(t)
 *   - Outputs (1): out,         a(t) * shape(2*pi*freq*t + phaseshift)
 *
 */
class amOscillator : public tf
{
public:
  /**
   * @brief Construct an AM oscillator.
   *
   * @param waveform   : Type of waveform (NewSine, NewTriangle, NewSquare, NewSawtooth)
   * @param freq       : Carrier frequency in Hz
   * @param phaseshift : Phase shift in radians
   */
  amOscillator(PP_WaveForm waveform, float freq, float phaseshift);
};


/* Arbitrary-LUT caps. The Python library uses the same numbers, so a
 * design built in either language sends the same frames.
 *
 * The samples travel as wire parameters. A parameter descriptor packs its
 * length into 12 bits, so one parameter carries at most 4092 bytes, i.e.
 * 1023 float32 samples. That never capped the LUT itself, only one
 * parameter: a longer table is split across consecutive parameters and the
 * board reassembles it. What caps the whole table is how many parameters a
 * signal source has left, since nine of the twenty are already spent on the
 * common header, the frequency, the phase and the sample count. */
#define PAPAYA_ARB_SAMPLES_PER_PARAM 1023u
#define PAPAYA_ARB_PARAMS_MAX 11u
/** What the WIRE could carry: 11253 samples. Not the limit that binds. */
#define PAPAYA_ARB_WIRE_MAX_SAMPLES \
  (PAPAYA_ARB_SAMPLES_PER_PARAM * PAPAYA_ARB_PARAMS_MAX)

/** Samples in one Arbitrary lookup table, and the ONE restriction a table is
 *  under: the board's FAST HEAP.
 *
 *  The board copies the samples into its fast heap (110 KB, shared with
 *  every other block) and iterates them there, because a table read every
 *  tick has to be in fast memory and the board's large heap is too slow
 *  for that. One table gets 20 KB of the fast heap: 5120 float32 samples,
 *  5.1 s at 1 kHz. The board and the Python library both enforce the same
 *  5120-sample ceiling, and a longer table is refused rather than
 *  truncated.
 *
 *  Comfortably under the wire's own 11253, which is why a recording needs no
 *  upload and no slot: 20 KB is 6 of the 20 parameters a command carries. */
#define PAPAYA_ARB_MAX_SAMPLES 5120u

/**
 * @brief Unified signal generator: every modern waveform shape + mode.
 *
 * Pair with ``amOscillator`` when amplitude must be a runtime input.
 * Sine, Square, Triangle, Sawtooth,
 * Pulse (variable duty), Sinc, Gauspuls, DC, Arbitrary LUT, Linear /
 * Log Chirp, Multisine, PRBS, Step, Ramp, Impulse, Pulse-Train. All
 * one class. Modes: Perpetual, RepeatN, OneShot, TrigEdge, TrigGate.
 *
 * The static factory helpers (signalSource::sine, ::chirpLinear, ::step,
 * …) keep the simple cases short while preserving access to the full
 * trailing kwargs (amplitude / offset / mode / n_periods / trig_pol).
 *
 * See ``papaya_lib/PAPAYA.cpp`` for the wire-frame builder.
 */
class signalSource : public tf {
public:
  /* Generic constructor: every field on display. Most users prefer the
   * static factories below. emitFrame=false allocates the block id but
   * suppresses the create frame; the static factories use it so they can
   * emit a single frame carrying header + shape-specific params (matching
   * papaya.signalSource). emitFrame=true (default) sends a header-only
   * frame, correct for shapes with no extra params (e.g. DC). */
  signalSource(WaveShape shape, float amplitude = 1.0f, float offset = 0.0f,
               WaveMode mode = WaveMode::Perpetual, uint32_t n_periods = 0,
               WaveTrigPol trig_pol = WaveTrigPol::Rising, bool emitFrame = true);

  /* Periodic shapes */
  static signalSource sine     (float freq, float phase = 0.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource square   (float freq, float phase = 0.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource triangle (float freq, float phase = 0.0f, float symmetry = 0.5f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource sawtooth (float freq, float phase = 0.0f, uint8_t direction = 0,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource pulse    (float freq, float duty, float phase = 0.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource sinc     (float freq, uint16_t n_lobes = 5, float phase = 0.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource gauspuls (float freq, float bw_fraction = 0.5f, float prf = 10.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource dc       (float value);
  /* Arbitrary lookup table. `n_samples` is at most PAPAYA_ARB_MAX_SAMPLES;
   * a longer table latches a BadParam design error rather than shipping a
   * truncated one. `samples` only has to live until the call returns.
   *
   * `freq` is table traversals a second. Leave it at 0 for a recording: a
   * recording has one natural speed, so 0 plays the table once over its own
   * duration (Fs / n_samples, from the sampling frequency startDesign() was
   * given). Set it when the table is a waveform you designed and the rate is
   * part of the signal, as it is for sine(). */
  static signalSource arbitrary(const float * samples, uint16_t n_samples,
                                float freq = 0.0f, float phase = 0.0f,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);

  /* Sweeps */
  static signalSource chirpLinear(float f0, float f1, float t_sweep, float phase = 0.0f,
                                  WaveMode mode = WaveMode::OneShot,
                                  uint32_t n_periods = 1,
                                  WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                  float amplitude = 1.0f, float offset = 0.0f);
  static signalSource chirpLog   (float f0, float f1, float t_sweep, float phase = 0.0f,
                                  WaveMode mode = WaveMode::OneShot,
                                  uint32_t n_periods = 1,
                                  WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                  float amplitude = 1.0f, float offset = 0.0f);

  /* Stochastic / structured */
  static signalSource multisine(float f0, float df, uint16_t n_lines = 8,
                                MultisinePhase phase_scheme = MultisinePhase::Schroeder,
                                uint32_t lfsr_seed = 0xACE1u,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource prbs     (uint8_t bits = 9, uint32_t clock_div = 1,
                                uint32_t lfsr_seed = 0xACE1u,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);

  /* Transients (one-shot by default) */
  static signalSource step     (float t_step, float value_before = 0.0f, float value_after = 1.0f,
                                WaveMode mode = WaveMode::OneShot, uint32_t n_periods = 1,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource ramp     (float slope, float t_start = 0.0f,
                                float sat_low = -1.0e9f, float sat_high = 1.0e9f,
                                WaveMode mode = WaveMode::OneShot, uint32_t n_periods = 1,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource impulse  (float t_impulse = 0.0f,
                                WaveMode mode = WaveMode::OneShot, uint32_t n_periods = 1,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f);
  static signalSource pulseTrain(float freq, float duty, uint16_t n_pulses, float prf,
                                 float phase = 0.0f,
                                 WaveMode mode = WaveMode::OneShot, uint32_t n_periods = 1,
                                 WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                 float amplitude = 1.0f, float offset = 0.0f);

  /* Recorded dataset: hand it the samples; it does the rest.
   *
   * ONE call. It puts the recording on the board and creates the block that
   * plays it, because those are one intention and splitting them into two
   * statements only creates an order to get wrong and a step to forget.
   * Everything between them is bookkeeping:
   *
   *     signalSource src = signalSource::dataset(kMyRecording, 60001);
   *
   * It asks for nothing it can work out. No flash slot: the library hands
   * out the next one and remembers it, and which slot a recording landed in
   * is not something a design means. No name: the block has an id, assigned
   * here. No sample rate: the samples are fed to the graph one per tick, so
   * the rate they play at IS the design's. And no frequency, which is the
   * difference between this and every factory above: for sine() a frequency
   * IS the signal and you choose it, while a recording plays once over its
   * own duration, so the rate is Fs / N and follows from the recording.
   *
   * n_samples is there because a raw pointer has no length. At most
   * PAPAYA_DATASET_MAX_SAMPLES, and a design may play PP_DATASET_SLOT_COUNT
   * of them; both are refused rather than half-done. Mirrors
   * papaya.signalSource.dataset(samples). */
  static signalSource dataset  (const float * samples, uint32_t n_samples,
                                WaveMode mode = WaveMode::Perpetual,
                                uint32_t n_periods = 0,
                                WaveTrigPol trig_pol = WaveTrigPol::Rising,
                                float amplitude = 1.0f, float offset = 0.0f,
                                float phase = 0.0f);
};

/**
 * @brief Recursive Least Squares macro for adaptive parameter estimation.
 */
class rls : public macro
{
public:
  /**
   * @brief Construct a new rls object
   *
   * @param modelOrd
   * @param gain
   * @param system
   */
  rls(uint8_t modelOrd, float gain, macro system);
};

/**
 * @brief Placeholder for a downsampling block. It does not downsample.
 *
 * @warning Neither constructor changes the signal. Both build an empty
 *          1-in / 1-out macro, so samples pass through unaltered at the
 *          design's own rate: no rate change, no anti-alias filtering,
 *          and every parameter ignored. The board cannot realise this
 *          block, and PAPAYA Studio will not generate a design that
 *          contains one, so a sketch reaching these constructors was
 *          written by hand. Downsample on the host instead, after
 *          reading the samples off the board.
 */
class decimation : public macro
{
public:
  /**
   * @brief Construct a new decimation object (raw-buffer form).
   *
   * @param Buffer Ignored. The class keeps no state and writes nothing
   *               into it, so a caller may pass nullptr.
   */
  explicit decimation(float *Buffer);

  /**
   * @brief Construct a new decimation object (parameter form).
   *
   * All four values are ignored. The on-wire effect is identical to the
   * raw-buffer overload: a pass-through 1-in / 1-out macro.
   *
   * @param factor       Ignored; no downsampling is performed.
   * @param gain         Ignored; the signal is not scaled.
   * @param fc           Ignored; no anti-alias filter is created.
   * @param filter_order Ignored; no filter stages are created.
   */
  decimation(uint8_t factor, float gain, float fc, uint8_t filter_order);
};

/**
 * @brief TRUE RBJ low-shelf parametric EQ (cascaded shelving biquads).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class paramEQLow : public macro
{
public:
  /**
   * @brief Construct a new param E Q Low object
   *
   * @param Fc          : Shelf corner frequency (Hz)
   * @param FilterOrder : Stage count -> n = max(1, FilterOrder/2) biquads
   * @param Gain        : Shelf gain in decibels (dB); +boost / -cut, 0 = flat
   */
  paramEQLow(float Fc, uint8_t FilterOrder, float Gain);
};

/**
 * @brief TRUE RBJ high-shelf parametric EQ (cascaded shelving biquads).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class ParamEQHigh : public macro
{
public:
  /**
   * @brief Construct a new Param E Q High object
   *
   * @param Fc          : Shelf corner frequency (Hz)
   * @param FilterOrder : Stage count -> n = max(1, FilterOrder/2) biquads
   * @param Gain        : Shelf gain in decibels (dB); +boost / -cut, 0 = flat
   */
  ParamEQHigh(float Fc, uint8_t FilterOrder, float Gain);
};

/**
 * @brief TRUE RBJ band (peaking) parametric EQ (cascaded peaking biquads).
 * @details f0 = sqrt(Fc1*Fc2), Q = f0/(Fc2-Fc1) clamped to >= 0.1.
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class ParamEQBand : public macro
{
public:
  /**
   * @brief Construct a new Param E Q Band object
   *
   * @param Fc1         : Lower band edge (Hz)
   * @param Fc2         : Upper band edge (Hz), Fc2 > Fc1
   * @param FilterOrder : Stage count -> n = max(1, FilterOrder/2) biquads
   * @param Gain        : Band gain in decibels (dB); +boost / -cut, 0 = flat
   */
  ParamEQBand(float Fc1, float Fc2, uint8_t FilterOrder, float Gain);
};

/**
 * @brief TRUE RBJ peaking parametric EQ (single peaking biquad, fixed Q = 5.0).
 * @details
 *  - Inputs (1): in
 *  - Outputs (1): out
 */
class ParamEQPeak : public macro
{
public:
  /**
   * @brief Construct a new Param E Q Peak object
   *
   * @param Fc   : Center frequency of the peak (Hz)
   * @param Gain : Peak gain in decibels (dB); +boost / -cut, 0 = flat
   */
  ParamEQPeak(float Fc, float Gain);
};

/**
 * @brief FFT transform. Produces vector output suitable for VectorProbe.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): spectrum
 */
class fft : public tf
{
public:
  /**
   * @brief Construct a new fft object
   *
   * @param Nbsamples : Number of samples to process per FFT computation (must be written as n = 2^m )
   */
  explicit fft(uint16_t Nbsamples);
};

/**
 * @brief FFT with Hann window. Produces vector output suitable for VectorProbe.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): spectrum
 */
class fft_HannWindow : public tf
{
public:
  /**
   * @brief Construct a new fft HannWindow object
   *
   * @param Nbsamples : Number of samples to process per FFT computation (must be written as n = 2^m )
   */
  explicit fft_HannWindow(uint16_t Nbsamples);
};

/**
 * @brief Magnitude spectrum resolver from an FFT block.
 * @details
 *  - Inputs (1): fft
 *  - Outputs (1): magnitude
 */
class fftMagResolver : public tf
{
public:
  /**
   * @brief Construct a new fft Mag Resolver object
   *
   * @param fftInstance
   */
  fftMagResolver(fft fftInstance);

  /**
   * @brief Construct a new fft Mag Resolver object
   *
   * @param fft_hann_Instance
   */
  fftMagResolver(fft_HannWindow fft_hann_Instance);
};

/**
 * @brief Phase spectrum resolver from an FFT block.
 * @details
 *  - Inputs (1): fft
 *  - Outputs (1): phase
 */
class fft_phaseResolver : public tf
{
public:
  /**
   * @brief Construct a new fft phaseResolver object
   *
   * @param fftInstance
   */
  fft_phaseResolver(fft fftInstance);

  /**
   * @brief Construct a new fft phaseResolver object
   *
   * @param fft_hann_Instance
   */
  fft_phaseResolver(fft_HannWindow fft_hann_Instance);
};

/**
 * @brief Analog input block. Supports single or multiple hardware channels with scaling and offset.
 * @details
 *  - Inputs (0): none
 *  - Outputs (1): value
 */
class analogIn : public node
{
public:
  /**
   * @brief Construct a new analog In object
   *
   * @param id        Analog input channel, `AIN1`..`AIN10`.
   * @param outScale  Units per volt. The channel already reads VOLTS over
   *                  -10 V to +10 V before this is applied, so 1.0 gives
   *                  volts. Set it only to express the reading in the
   *                  sensor's own units. `outScale = 0` is accepted and
   *                  parks the block at @p offset for ever, which looks
   *                  exactly like a dead sensor; PAPAYA Studio warns about
   *                  it, this library does not.
   * @param offset    Added AFTER the scaling, in the same units as the
   *                  result: the value the block reports at 0 V.
   */
  analogIn(PP_HwId id, float outScale, float offset);

  /**
   * @brief Construct a new analog In object
   *
   * @param config : Configuration structure
   * @param items
   */
  analogIn(PP_anInCfg *config, uint8_t items);
};

/**
 * @brief PWM input measurement block supporting pulse, period, or delay acquisition.
 * @details
 *  - Inputs (0): none
 *  - Outputs: one for a PERIOD identifier, TWO for a PULSE or DELAY one
 *      - output 0: value, the measured interval IN SECONDS
 *      - output 1 (PULSE and DELAY only): the full period of the same signal,
 *        also in seconds
 *
 *  The output is a time, always. Which time depends on the identifier:
 *  FI1_PULSE..FI5_PULSE give the pulse high time, FI1_PERIOD..FI5_PERIOD the
 *  full period, FI1_DELAY..FI5_DELAY the interval between the two edges.
 *  Nothing multiplies it: convert to your own units downstream with a gain
 *  block (period to RPM is a reciprocal then a gain of 60).
 *
 *  WIRE EVERY OUTPUT THE BLOCK HAS. On a PULSE or DELAY identifier that means
 *  BOTH: link out(0) to whatever consumes the measurement AND out(1) to a
 *  consumer or a probe. The board starts a block only once every one of its
 *  outputs is connected, so leaving out(1) unwired keeps the block out of the
 *  run entirely. The design still uploads, still reports success, and out(0)
 *  then reads 0.0 for as long as the design runs: nothing reports it, because
 *  the board's check for unconnected outputs only inspects blocks that are
 *  already running. A PERIOD identifier has one output and cannot hit this.
 *
 *  A design built in PAPAYA Studio's Model Builder always has one port per
 *  configured channel, so pulse-width and edge-delay capture does not work
 *  from a diagram or from a program generated out of one. Measure the period
 *  there, or write the program by hand and wire both outputs.
 */
class pwmIn : public node
{
public:
  /**
   * @brief Construct a new pwm In object
   *
   * @param id       Frequency input and mode, e.g. PP_HwId::FI1_PULSE. Must be
   *                 a frequency input: passing 0 selects MOTOR1 and the board
   *                 refuses the design.
   * @param outScale Measurement RANGE, in seconds: the longest interval this
   *                 channel can time. NOT a multiplier, and it never changes
   *                 the value on the output port. 1.0 measures up to one
   *                 second; use 0.01 for millisecond-scale pulses. Too small
   *                 and a long interval wraps and reads short; too large and a
   *                 short one is timed coarsely. Neither is reported.
   */
  pwmIn(PP_HwId id, float outScale);

  /**
   * @brief Construct a new pwm In object
   *
   * @param config
   * @param items
   */
  pwmIn(PP_pwmInCfg *config, uint8_t items);
};

/**
 * @brief PWM output block driving hardware channels with configurable frequency and duty-cycle limits.
 * @details
 *  - Inputs (1): duty, a FRACTION of the carrier period (0.0 = off,
 *    1.0 = fully on)
 *  - Outputs (0): none
 *
 *  The signal on the duty port and both limits are the same dimensionless
 *  fraction. Nothing converts a percentage anywhere, in either library or on
 *  the board: 95 does not mean 95 %, it means ninety-five times full scale
 *  and holds the pin permanently on.
 *
 *  ### Ranges the board can honour
 *  PAPAYA Studio refuses a design outside these before it is deployed. This
 *  library does not check them, so a program that builds a design directly
 *  has to respect them itself.
 *
 *  | Parameter | Range | Outside it |
 *  | --- | --- | --- |
 *  | `frequency` | 0.06403 Hz to 137500000 Hz | The channel runs at a
 *    different frequency and nothing reports it. At or below 0 the timer
 *    never starts. |
 *  | `dutyLowerLimit`, `dutyUpperLimit` | 0.0 to 1.0 | Above 1.0 the pin has
 *    no low phase at all; below 0.0 is meaningless on this output. |
 *
 *  The carrier is built from whole ticks of a 275 MHz timebase and every
 *  channel counts to 16 bits, so the realised frequency is only exact where
 *  275000000 divides evenly, and the number of duty steps falls as the
 *  frequency rises: about 55000 steps at 1 kHz, 13750 at 20 kHz, 275 at
 *  1 MHz. The realised duty is truncated to a multiple of 1/steps.
 */
class pwmOut : public node
{
public:
  /**
   * @brief Construct a new pwm Out object
   *
   * @param id              Frequency output channel, `FO1`..`FO8`. One block
   *                        per channel: a second block on the same channel
   *                        overwrites the first one's configuration, and
   *                        nothing on the board reports it.
   * @param frequency       Carrier frequency in HERTZ, fixed for the life of
   *                        the design. Realisable span 0.06403 to 137500000.
   * @param dutyLowerLimit  Lower clamp on the duty port, as a FRACTION in
   *                        0.0 to 1.0. The clamp is applied before the timer,
   *                        so the load is protected but the block driving the
   *                        port is told nothing about the saturation.
   * @param dutyUpperLimit  Upper clamp, same fraction and same range. Must
   *                        not be below @p dutyLowerLimit: the board swaps a
   *                        reversed pair silently and runs a window nobody
   *                        asked for. Equal limits are legal and pin the
   *                        output at that duty.
   */
  pwmOut(PP_HwId id, float frequency, float dutyLowerLimit, float dutyUpperLimit);

  /**
   * @brief Construct a new pwm Out object
   *
   * @param config
   * @param items
   */
  pwmOut(PP_pwmOutCfg *config, uint8_t items);
};

/**
 * @brief IMU interface block providing accelerometer, gyroscope, or magnetometer measurements.
 * @details Depends on the selected hardware id.
 *  - Inputs (0): none
 *  - Outputs (3): x, y, z
 */
class imu : public node
{
public:
  /**
   * @brief Construct a new imu object
   *
   * @param id        Motion channel: `IMU_ACC` (acceleration), `IMU_GYR`
   *                  (angular rate) or `IMU_MAG` (magnetic field). The three
   *                  are separate channels, one block each.
   * @param outScale  Multiplier on all three axes, applied to the channel's
   *                  own native units. 1.0 leaves them as they are.
   *                  `outScale = 0` is accepted and parks all three outputs
   *                  at 0 for ever; PAPAYA Studio warns about it, this
   *                  library does not.
   */
  imu(PP_HwId id, float outScale);
};

/**
 * @brief DC motor hardware block with one duty-cycle input and 1 to 3 selectable measurement outputs.
 * @details
 *  Drives a brushed-DC motor via an on-board H-bridge.
 *  Accepts a fractional duty-cycle command (in -1.0..+1.0, clamped to
 *  the configured limits) and emits any non-empty subset of
 *  {MotorVelocity, MotorPosition, MotorCurrent} as outputs.
 *
 *  - **Inputs (1)**: duty, a SIGNED fraction whose sign is the direction
 *  - **Outputs (variable, 1 to 3)**: in the order configured by @p outputs
 *
 *  ### Ranges the board can honour
 *  PAPAYA Studio refuses a design outside these before it is deployed; this
 *  library does not check them.
 *
 *  | `PP_motorCfg` field | Range | Meaning |
 *  | --- | --- | --- |
 *  | `dutyLowerLimit`, `dutyUpperLimit` | -1.0 to +1.0 | A signed FRACTION,
 *    not a percentage: -1 is full reverse, 0 is stopped, +1 is full forward.
 *    The drive clamps to -1..+1 again after these, so a wider limit does
 *    nothing. `dutyUpperLimit` must be strictly above `dutyLowerLimit`. |
 *  | `cur_min_mA`, `cur_max_mA` | about -5470 to +5470 mA | The window the
 *    winding current is MEASURED over, and nothing else: see the note below.
 *    An end outside the sensing span can never be reached. Defaults are
 *    -5000 and +5000, and `cur_max_mA` must be above `cur_min_mA`. |
 *  | `pwm_hz` | > 0, and see `pwmOut` for what the timebase can build | The
 *    drive carrier. It sets the duty resolution: the default 20000 Hz gives
 *    about 8500 steps, and fewer as the carrier rises. |
 *
 *  ### The current window measures; it does not protect
 *  `cur_min_mA` and `cur_max_mA` bound the range the winding current is
 *  measured over. This firmware does NOT cut the drive out when the current
 *  leaves that window, so do not design around it: protect the drive with a
 *  fuse, a supply current limit, or your own logic on the current output.
 *  Earlier revisions of this header called these an over-current trip level,
 *  which was wrong.
 *
 *  ### Encoder peripheral sharing
 *  Motor 1 (`MOTOR1`) shares its quadrature encoder timer with the
 *  standalone @ref encoder block on `ENC1`; Motor 2 shares with
 *  `ENC2`. Including `MotorVelocity` or `MotorPosition` in
 *  @p outputs claims the encoder peripheral and forbids a standalone
 *  encoder block on the same channel. Use `{MotorCurrent}` only to
 *  release the encoder for the standalone block.
 */
class motor : public node
{
public:
  /**
   * @brief Construct from explicit (id, cfg, outputs) tuple.
   * @param id           Physical motor channel: `MOTOR1` or `MOTOR2`.
   * @param config       Pointer to a PP_motorCfg with PWM, current
   *                     limits, conversion constants, and duty clamps.
   * @param outputs      Pointer to an array of PP_MotorOutput selectors
   *                     in the order they should appear on output ports.
   * @param outputCount  Number of valid entries in @p outputs (1..3).
   *                     Must match the user's `output_mode` selection.
   */
  motor(PP_HwId id, const PP_motorCfg *config, const PP_MotorOutput *outputs, uint8_t outputCount);

  /**
   * @brief Construct from a pre-populated descriptor (e.g. emitted by
   *        Studio's Arduino code generator).
   * @param config Pointer to a fully-populated PP_motorBlockCfg.
   */
  explicit motor(const PP_motorBlockCfg *config);
};

/**
 * @brief Standalone quadrature encoder block providing position and/or velocity.
 * @details
 *  Reads the quadrature timer on a physical encoder channel
 *  independently of the matching motor block. Velocity is low-pass
 *  filtered on the board with the same bilinear first-order LPF as the
 *  motor block, sampled in the main sampling interrupt at the design's
 *  MainSamplingFrequency.
 *
 *  - **Inputs (0)**: none (pure source block).
 *  - **Outputs (variable, 1 or 2)**: in the order configured by @p outputs.
 *
 *  ### Channel sharing (checked by Studio, not by the board)
 *  ENC1 is the same physical counter that Motor 1 measures with; ENC2
 *  is the same one Motor 2 measures with. This block is only valid
 *  when no Motor on the same channel is active OR when that Motor is
 *  configured for `MotorCurrent`-only output, which is the one output
 *  mode that does not read the counter.
 *
 *  PAPAYA Studio refuses the combination on every route a block can be
 *  created: the block dialog greys out the conflicting `ENC` choice,
 *  the Board Explorer refuses the second block, a pasted copy is moved
 *  or refused, opening a saved design that contains the conflict warns
 *  about it, and deploy and code generation both refuse it.
 *
 *  The board itself does NOT refuse it. A design that double-claims a
 *  channel and reaches the board by some route other than Studio has
 *  both blocks reading the counter with whichever configuration was
 *  sent last, and nothing reports an error. Check it in your own code
 *  if you build designs with this library directly.
 */
class encoder : public node
{
public:
  /**
   * @brief Construct from explicit (id, cfg, outputs) tuple.
   * @param id           Physical encoder channel: `ENC1` or `ENC2`.
   * @param config       Pointer to a PP_encoderCfg with conversion
   *                     constants and the velocity LPF time constant.
   * @param outputs      Pointer to an array of PP_EncoderOutput
   *                     selectors. Allowed entries: EncoderVelocity,
   *                     EncoderPosition (current is not available).
   * @param outputCount  Number of valid entries in @p outputs (1 or 2).
   */
  encoder(PP_HwId id, const PP_encoderCfg *config, const PP_EncoderOutput *outputs, uint8_t outputCount);

  /**
   * @brief Construct from a pre-populated descriptor (e.g. emitted by
   *        Studio's Arduino code generator).
   * @param config Pointer to a fully-populated PP_encoderBlockCfg.
   */
  explicit encoder(const PP_encoderBlockCfg *config);
};

/**
 * @brief Analog voltage output block driving the board's analog output channels.
 * @details
 *  Two modes:
 *   - InputDriven (the two limit constructors): the block has a voltage input,
 *     written to the DAC every design cycle, clamped to [lowerLimit, upperLimit].
 *   - PredefinedWaveform (the ergonomic factories below): the block has no
 *     input/output; it carries a waveform spec that the board
 *     synthesises and plays back autonomously.  The 17
 *     shapes mirror ``signalSource`` exactly.
 *
 *  ### Ranges the board can honour
 *  PAPAYA Studio refuses a design outside these before it is deployed. This
 *  library does not check them, so a program building a design directly has
 *  to respect them itself.
 *
 *  - **Volts.** The channel drives -10 V to +10 V and stops at the rail.
 *    `lowerLimit`, `upperLimit` and a predefined waveform's `offset` all
 *    live in that span; a value outside it changes nothing about the pin.
 *    `lowerLimit` must not be above `upperLimit`, because the board swaps a
 *    reversed pair without saying so.
 *  - **Amplitude.** A waveform that passes 10 V is playable and comes out
 *    FLAT-TOPPED: the clamp is hard saturation per sample, not a smooth
 *    limit, so the part outside the span is lost rather than scaled down.
 *    Judge it on the highest and lowest volts one played cycle actually
 *    reaches, NOT on |amplitude| + |offset|. That sum is the exact peak only
 *    for the shapes that really do run the full -1 to +1: `sine`, `square`,
 *    `triangle`, `pulse`, `prbs`, `sawtooth` and the two chirps.
 *
 *    Fourteen of the sixteen shapes keep their normalised cycle inside -1 to
 *    +1, so for those the sum is an upper bound, but often a loose one and a
 *    waveform with room to spare then looks like it clips: a `pulseTrain`
 *    and an `impulse` sit between 0 and 1, a `sinc` between -0.22 and +1, a
 *    `gauspuls` on its defaults between +0.94 and +1, and a `multisine` of
 *    eight lines between -0.41 and +0.43, because its lines do not all peak
 *    at the same instant. A `dc` holds the offset alone; its amplitude never
 *    reaches the pin.
 *
 *    `step` and `ramp` are the two shapes that can leave -1 to +1, and for
 *    them the sum is not even a bound, because the level comes from the
 *    shape's own parameters rather than from the amplitude. A `step` sits at
 *    amplitude * value_after + offset (and at amplitude * value_before +
 *    offset before `t_step`), so amplitude 1 with `value_after` 500 asks the
 *    output for 500 V. A `ramp` reaches
 *    amplitude * min(sat_high, slope * cycle) + offset, and the cycle played
 *    for this shape is one second, so raising `sat_high` on its own moves
 *    nothing until the slope can climb that far within the second: at the
 *    default slope of 1 the ramp tops out just under 1 whatever `sat_high`
 *    says, while at slope 100 it reaches 50 with `sat_high` 50 and 100 with
 *    `sat_high` left wide. `sat_low` bounds the descent the same way.
 *  - **Repetition rate.** The output plays at up to 1000000 samples per
 *    second and needs at least 8 samples per cycle, so the fastest waveform
 *    it can repeat is 125 kHz. A `freq` above that cannot be synthesised.
 *  - **Table length.** One cycle is stored in a table of at most 2048
 *    samples. A `prbs` sequence has to fit whole, so (2^bits - 1) * clockDiv
 *    must not exceed 2048: 11 bits at `clockDiv` 1, and fewer as it rises.
 *
 *  ### AO1, AO4 and AO5 share one playback trigger
 *  In PredefinedWaveform mode those three channels are advanced by ONE
 *  trigger; only AO2 and AO3 own a private one. Setting the playback rate of
 *  any of the three reprograms that trigger, so the last one created
 *  silently changes the rate of the other two, INCLUDING channels already
 *  running. The rate follows the waveform's own cycle, so give any two of
 *  AO1, AO4 and AO5 waveforms of the same period, or put one of them on AO2
 *  or AO3. Nothing on the board reports the clash.
 */
class analogOut : public node
{
public:
  /**
   * @brief Input-driven analog output: one voltage written per design cycle.
   *
   * @param id          Analog output channel, `AO1`..`AO5`.
   * @param lowerLimit  Lower clamp on the input, in VOLTS, within
   *                    -10.0f..+10.0f. Equal limits are legal and pin the
   *                    output at that voltage.
   * @param upperLimit  Upper clamp, in VOLTS, same range. Must not be below
   *                    @p lowerLimit.
   */
  analogOut(PP_HwId id, float lowerLimit, float upperLimit);

  /**
   * @brief Several input-driven channels from one descriptor array.
   *
   * @param config  Array of PP_anOutCfg, one per channel; each row is held
   *                to the same volt range and ordering rule as above.
   * @param items   Number of valid rows in @p config.
   */
  analogOut(PP_anOutCfg *config, uint8_t items);

  /* Predefined-waveform factories: autonomous waveform generation on the
   * DAC channel.  See papaya/signal_source.py for the shape catalogue. */
  static analogOut sine     (PP_HwId id, float freq, float phase = 0.0f,
                             float amplitude = 1.0f, float offset = 0.0f);
  static analogOut square   (PP_HwId id, float freq, float phase = 0.0f,
                             float amplitude = 1.0f, float offset = 0.0f);
  static analogOut triangle (PP_HwId id, float freq, float phase = 0.0f,
                             float symmetry = 0.5f, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut sawtooth (PP_HwId id, float freq, float phase = 0.0f,
                             uint8_t direction = 0, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut pulse    (PP_HwId id, float freq, float phase = 0.0f,
                             float duty = 0.5f, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut sinc     (PP_HwId id, float freq, float phase = 0.0f,
                             uint16_t n_lobes = 5, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut gauspuls (PP_HwId id, float freq, float bw_fraction = 0.5f,
                             float prf = 10.0f, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut dc       (PP_HwId id, float value = 0.0f);
  static analogOut chirpLinear(PP_HwId id, float f0, float f1, float t_sweep,
                             float phase = 0.0f, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut chirpLog (PP_HwId id, float f0, float f1, float t_sweep,
                             float phase = 0.0f, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut multisine(PP_HwId id, float f0, float df, uint16_t n_lines = 8,
                             MultisinePhase phase_scheme = MultisinePhase::Schroeder,
                             uint32_t lfsr_seed = 0xACE1, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut prbs     (PP_HwId id, uint8_t bits = 9, uint32_t clock_div = 1,
                             uint32_t lfsr_seed = 0xACE1, float amplitude = 1.0f,
                             float offset = 0.0f);
  static analogOut step     (PP_HwId id, float t_step = 0.0f,
                             float value_before = 0.0f, float value_after = 1.0f,
                             float amplitude = 1.0f, float offset = 0.0f);
  static analogOut ramp     (PP_HwId id, float slope = 1.0f, float t_start = 0.0f,
                             float sat_low = -10.0f, float sat_high = 10.0f,
                             float amplitude = 1.0f, float offset = 0.0f);
  static analogOut impulse  (PP_HwId id, float t_impulse = 0.0f,
                             float amplitude = 1.0f, float offset = 0.0f);
  static analogOut pulseTrain(PP_HwId id, float freq, float phase = 0.0f,
                             float duty = 0.5f, uint16_t n_pulses = 1,
                             float prf = 10.0f, float amplitude = 1.0f,
                             float offset = 0.0f);

private:
  analogOut() {}  /* no-op ctor used by the predefined-waveform factories */
};

/**
 * @brief Speaker output block streaming audio to the board's amplified audio output.
 * @details
 *  - Inputs (1): audio (normalized [-1.0, +1.0])
 *  - Outputs (0): none
 */
class speaker : public node
{
public:
  speaker(PP_HwId id);
};

/**
 * @brief Microphone input block capturing audio from the board's on-board digital microphone.
 * @details
 *  - Inputs (0): none
 *  - Outputs (1): audio (normalized [-1.0, +1.0])
 */
class microphone : public node
{
public:
  microphone(PP_HwId id);
};

/**
 * @brief Audio recorder block: captures its input stream into the board's recording slot.
 * @details
 *  Behaves on the wire exactly like a speaker (NewHwOutput + hw_id), but the
 *  board writes each sample into its persistent recording flash slot
 *  instead of sending it to an audio output. Place it after a microphone
 *  (optionally via a decimator) to record sound; the recording is committed
 *  to flash when sampling stops. The hardware id is fixed to ::RECORDER_1.
 *  - Inputs (1): audio (normalized [-1.0, +1.0])
 *  - Outputs (0): none
 */
class recorder : public node
{
public:
  recorder();
};

/**
 * @brief Audio replay block: streams the board's recording slot back into the graph.
 * @details
 *  Behaves on the wire exactly like a microphone (NewHwInput + hw_id), but the
 *  board reads each sample from its persistent recording flash slot
 *  instead of from a live microphone. Place it before a speaker (optionally
 *  via an interpolator) to play a recording back. The hardware id is fixed to
 *  ::REPLAY_1.
 *  - Inputs (0): none
 *  - Outputs (1): audio (normalized [-1.0, +1.0])
 */
class replay : public node
{
public:
  replay();
};

/* =============================== Wavelet Transforms =============================== */

/**
 * @brief Discrete Wavelet Transform. Produces coefficient vector output.
 * @details
 *  - Inputs (1): signal
 *  - Outputs (1): coeffs
 */
class dwt : public tf
{
private:
  uint16_t nbSamples;
  PP_WaveletType waveletType;
  uint8_t decompositionLevels;
  float samplingRate;

public:
  /**
   * @brief Construct a new dwt object
   *
   * @param signal_length : Length of the input signal
   * @param wavelet_type : Type of wavelet to use for the transform
   * @param levels : Number of decomposition levels
   * @param sampling_rate  : Sampling rate of the input signal
   */
  dwt(uint16_t signal_length, PP_WaveletType wavelet_type, uint8_t levels, float sampling_rate);

  /**
   * @brief Destroy the dwt object
   *
   */
  ~dwt();

  /**
   * @brief Get the Nb Samples object
   *
   * @return uint16_t : Number of samples
   */
  uint16_t getNbSamples() const;

  /**
   * @brief Get the Decomposition Levels object
   *
   * @return uint8_t : Number of decomposition levels
   */
  uint8_t getDecompositionLevels() const;

  /**
   * @brief Get the Wavelet Type object
   *
   * @return PP_WaveletType : Type of wavelet
   */
  PP_WaveletType getWaveletType() const;

  /**
   * @brief Get the Sampling Rate object
   *
   * @return float : Sampling rate
   */
  float getSamplingRate() const;
  /**
   * @brief  Chains this dwt block to a tf.
   *
   * @param tfDst
   */
  void operator>(tf tfDst);

  /**
   * @brief Chains this dwt block to a probe.
   *
   * @param probeDst
   */
  void operator>(probe &probeDst);

  /**
   * @brief Chains this dwt block to a node.
   *
   * @param nodeDst
   */
  void operator>(node nodeDst);

  /**
   * @brief Chains this dwt block to a macro.
   *
   * @param macroDst
   */
  void operator>(macro macroDst);
};

/**
 * @brief Inverse DWT associated with a given DWT instance.
 * @details
 *  - Inputs (1): coeffs
 *  - Outputs (1): signal
 */
class idwt : public tf
{
private:
  dwt *associatedDWT;

public:
  /**
   * @brief Construct a new idwt object
   *
   * @param dwtInstance  : Associated DWT instance
   */
  idwt(dwt &dwtInstance);

  /**
   * @brief Get the Associated D W T object
   *
   * @return dwt*
   */
  dwt *getAssociatedDWT() const;
  /**
   * @brief Chains this idwt block to a tf.
   *
   * @param tfDst
   */
  void operator>(tf tfDst);

  /**
   * @brief Chains this idwt block to a probe.
   *
   * @param probeDst
   */
  void operator>(probe &probeDst);

  /**
   * @brief Chains this idwt block to a node.
   *
   * @param nodeDst
   */
  void operator>(node nodeDst);

  /**
   * @brief Chains this idwt block to a macro.
   *
   * @param macroDst
   */
  void operator>(macro macroDst);
};

/* =========================== Wavelet Processing ============================ */

/** @brief Threshold type for wavelet denoising */
typedef enum {
  PP_THRESH_HARD    = 0,
  PP_THRESH_SOFT    = 1,
  PP_THRESH_GARROTE = 2
} PP_ThresholdType;

/**
 * @brief DWT Denoising block: estimates noise and applies level-dependent thresholding.
 *
 * @param dwtInstance  The associated dwt block supplying the coefficient stream.
 * @param thresh_type  Hard / Soft / Garrote thresholding rule.
 * @param thresh_scale Multiplier applied to the firmware's auto-estimated MAD
 *                     sigma before thresholding (1.0 = firmware default). Always
 *                     transmitted on the wire (slot 2, TYPE_Real).
 */
class dwt_denoise : public tf
{
private:
  dwt *associatedDWT;
  PP_ThresholdType threshType;
  float threshScale;

public:
  dwt_denoise(dwt &dwtInstance, PP_ThresholdType thresh_type = PP_THRESH_SOFT, float thresh_scale = 1.0f);
  dwt *getAssociatedDWT() const;
  PP_ThresholdType getThresholdType() const;
  float getThresholdScale() const;
  /**
   * @brief Runtime live-update of the threshold scale (no design rebuild).
   *
   * Emits a Manageblock / ::SetDwtDenoiseScale frame whose header BlockId
   * targets THIS block. @p thresh_scale is sent as a single TYPE_Real
   * (LINEAR, 1.0 = firmware default), mirroring the constructor's slot 2.
   * The firmware validates the target's CoreFuncId, so a stale/foreign id
   * is safely rejected.
   *
   * @param thresh_scale New MAD-sigma multiplier applied before thresholding.
   */
  void setScaleLive(float thresh_scale);
  void operator>(tf tfDst);
  void operator>(probe &probeDst);
  void operator>(node nodeDst);
  void operator>(macro macroDst);
};

/**
 * @brief DWT Subband Gain block: applies per-subband scalar gains.
 *
 * @param dwtInstance The associated dwt block supplying the coefficient stream.
 * @param gains       Optional pointer to an array of LINEAR gain multipliers, one
 *                    per subband in firmware subband order. The array must hold
 *                    (dwtInstance.getDecompositionLevels() + 1) elements. When
 *                    nullptr (default) no gain array is sent and the firmware
 *                    applies unity gain (slot 1 omitted), matching the Python
 *                    reference. When non-null, slot 1 carries a TYPE_RealArray.
 */
class dwt_subband_gain : public tf
{
private:
  dwt *associatedDWT;

public:
  dwt_subband_gain(dwt &dwtInstance, const float* gains = nullptr);
  dwt *getAssociatedDWT() const;
  /**
   * @brief Runtime live-update of the per-subband gains (no design rebuild).
   *
   * Emits a Manageblock / ::SetDwtSubbandGains frame whose header BlockId
   * targets THIS block. @p gains is sent as a TYPE_RealArray of @p numBands
   * LINEAR multipliers in firmware subband order ([0]=approximation,
   * [1..J]=detail); @p numBands must equal the linked DWT's
   * (getDecompositionLevels() + 1), matching the constructor's slot 1. The
   * firmware validates the target's CoreFuncId, so a stale/foreign id is
   * safely rejected.
   *
   * @param gains    Pointer to @p numBands LINEAR gain multipliers.
   * @param numBands Number of subbands (decomposition levels + 1).
   */
  void setGainsLive(const float* gains, uint16_t numBands);
  void operator>(tf tfDst);
  void operator>(probe &probeDst);
  void operator>(node nodeDst);
  void operator>(macro macroDst);
};

/**
 * @brief DWT Subband Energy block: measures energy per subband (vector output).
 */
class dwt_subband_energy : public tf
{
private:
  dwt *associatedDWT;

public:
  dwt_subband_energy(dwt &dwtInstance);
  dwt *getAssociatedDWT() const;
  void operator>(tf tfDst);
  void operator>(probe &probeDst);
  void operator>(node nodeDst);
  void operator>(macro macroDst);
};

/* ============================= Audio processing ============================ */

/**
 * @brief Brick-wall limiter with attack/release smoothing and dB ceiling.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class limiter : public tf
{
public:
  /**
   * @param Attack_s   Attack time (seconds).
   * @param Release_s  Release time (seconds).
   * @param Ceiling_dB Maximum output level in dB (e.g., -0.3).
   */
  limiter(float Attack_s, float Release_s, float Ceiling_dB);
};

/**
 * @brief Downward expander / noise gate with attack/release smoothing.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class noiseGate : public tf
{
public:
  /**
   * @param Attack_s    Attack time (seconds).
   * @param Release_s   Release time (seconds).
   * @param Threshold_dB Gate open threshold (dB).
   * @param Range_dB    Attenuation applied when closed (dB, e.g., -80).
   */
  noiseGate(float Attack_s, float Release_s, float Threshold_dB, float Range_dB);
};

/**
 * @brief Envelope follower with asymmetric attack/release smoothing.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): envelope amplitude (linear, >= 0)
 */
class envFollower : public tf
{
public:
  /**
   * @param Attack_s  Attack time constant (seconds).
   * @param Release_s Release time constant (seconds).
   */
  envFollower(float Attack_s, float Release_s);
};

/**
 * @brief ADSR envelope generator driven by a gate input.
 * @details
 *  - Inputs  (1): gate (>= 0.5 means note on)
 *  - Outputs (1): envelope value in [0, 1]
 */
class adsr : public tf
{
public:
  /**
   * @param Attack_s  Attack time (seconds).
   * @param Decay_s   Decay time (seconds).
   * @param Sustain   Sustain level [0, 1].
   * @param Release_s Release time (seconds).
   */
  adsr(float Attack_s, float Decay_s, float Sustain, float Release_s);
};

/**
 * @brief Fractional (interpolated) delay line with runtime-tunable delay length.
 * @details
 *  - Inputs  (2): signal, delay (fractional samples)
 *  - Outputs (1): delayed signal
 */
class fracDelay : public tf
{
public:
  /**
   * @param MaxDelaySamples Maximum delay length in samples (buffer size).
   */
  explicit fracDelay(uint32_t MaxDelaySamples);
};

/**
 * @brief Chorus effect: modulated short delay summed with dry signal.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class chorus : public tf
{
public:
  /**
   * @param Rate_Hz   LFO rate (Hz), typical 0.1..5.
   * @param Depth_ms  Modulation depth (ms), typical 1..20.
   * @param Mix       Wet/dry mix [0, 1].
   */
  chorus(float Rate_Hz, float Depth_ms, float Mix);
};

/**
 * @brief Flanger effect: very short modulated delay with feedback.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class flanger : public tf
{
public:
  /**
   * @param Rate_Hz  LFO rate (Hz), typical 0.1..2.
   * @param Depth_ms Maximum delay excursion (ms), typical 1..10.
   * @param Feedback Feedback amount [-0.95, 0.95].
   * @param Mix      Wet/dry mix [0, 1].
   */
  flanger(float Rate_Hz, float Depth_ms, float Feedback, float Mix);
};

/**
 * @brief Phaser effect: cascaded allpass stages with LFO-modulated coefficients.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class phaser : public tf
{
public:
  /**
   * @param Rate_Hz   LFO rate (Hz).
   * @param Depth     Modulation depth [0, 1].
   * @param Feedback  Feedback amount [-0.95, 0.95].
   * @param NumStages Number of allpass stages (typically 2, 4, or 6; max 6).
   * @param Mix       Wet/dry mix [0, 1].
   */
  phaser(float Rate_Hz, float Depth, float Feedback, uint8_t NumStages, float Mix);
};

/**
 * @brief Feedback-delay-network reverberator.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class reverb : public tf
{
public:
  /**
   * @param DecayTime_s Approximate RT60 in seconds (0.5..10).
   * @param Mix         Wet/dry mix [0, 1].
   */
  reverb(float DecayTime_s, float Mix);
};

/**
 * @brief Constant-power stereo panner.
 * @details
 *  - Inputs  (2): mono signal, pan position [-1 left .. +1 right]
 *  - Outputs (2): left, right
 */
class stereoPan : public node
{
public:
  stereoPan();
};

/**
 * @brief Waveshaping distortion with selectable nonlinearity.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class distortion : public tf
{
public:
  /**
   * @param Drive Pre-gain (1.0 = clean, 10+ = heavy distortion).
   * @param Mix   Wet/dry mix [0, 1].
   * @param Type  0 = soft clip (cubic), 1 = hard clip, 2 = tanh.
   */
  distortion(float Drive, float Mix, uint8_t Type);
};

/**
 * @brief Bitcrusher: bit-depth reduction plus sample-rate decimation.
 * @details
 *  - Inputs  (1): in
 *  - Outputs (1): out
 */
class bitcrusher : public tf
{
public:
  /**
   * @param BitDepth    Effective bit depth (e.g., 8.0).
   * @param SRReduction Sample-rate reduction factor (1 = none, 10 = 1/10th).
   */
  bitcrusher(float BitDepth, uint16_t SRReduction);
};

/**
 * @brief Ring modulator: multiplies two signals.
 * @details
 *  - Inputs  (2): signal, carrier
 *  - Outputs (1): modulated signal (signal * carrier)
 */
class ringMod : public node
{
public:
  ringMod();
};

/**
 * @brief Autocorrelation-based fundamental-frequency detector.
 * @details
 *  - Inputs  (1): audio signal
 *  - Outputs (1): detected frequency (Hz)
 */
class pitchDetect : public tf
{
public:
  /**
   * @param MinFreq Minimum detectable frequency (Hz, e.g., 50).
   * @param MaxFreq Maximum detectable frequency (Hz, e.g., 2000).
   */
  pitchDetect(float MinFreq, float MaxFreq);
};

/**
 * @brief VU / PPM meter: asymmetric rise/fall smoothing on |x|, output in dB.
 * @details
 *  - Inputs  (1): audio signal
 *  - Outputs (1): metered level (dB)
 */
class vuMeter : public tf
{
public:
  /**
   * @param RiseTime_s Rise time constant (seconds). VU ≈ 0.3, PPM ≈ 0.001.
   * @param FallTime_s Fall time constant (seconds). VU ≈ 0.3, PPM ≈ 1.5.
   */
  vuMeter(float RiseTime_s, float FallTime_s);
};

/**
 * @brief N-channel stereo mixer: sums all inputs, duplicates to L/R outputs.
 *        Per-channel gain is set via node coefficients; chain with stereoPan
 *        upstream for true stereo placement.
 * @details
 *  - Inputs  (NumChannels): mono channels
 *  - Outputs (2): left, right (identical mono sum)
 */
class stereoMixer : public node
{
public:
  /**
   * @param NumChannels Number of input channels (1..16).
   */
  explicit stereoMixer(uint8_t NumChannels);
};

/* =============================== Host Facade =============================== */
/**
 * @brief The PAPAYA class serves as the main interface for users to interact
 *        with the PAPAYA real-time signal processing system.
 */
class PAPAYA
{
private:
  /**
   * @brief The part begin() and attach() share: everything but the reset.
   *
   * Written once rather than twice on purpose. The two entry points
   * differ in exactly one decision -- whether the board is restarted --
   * and a copy of this block would be a place for the next transport
   * fix to land in one of them and not the other.
   *
   * @param driveReset true to pulse the reset line and wait out the
   *        board's boot; false to leave a running board running.
   */
  bool setUpTransport(int Id, SPIClass &spi, uint8_t csPin,
                      const SPISettings &settings, bool callSpiBegin,
                      uint16_t csDelayUs, bool driveReset);

  int cs;
  int _boardId = -1;
  uint8_t _contextSlot = 0xFFu;
  PP_TransportHooks _transportHooks = {};
  PP_TransportTxBytesFn _transportTx = nullptr;
  PP_TransportRxBytesFn _transportRx = nullptr;
  // Optional user-provided SPI bus (Arduino library style). If nullptr, global SPI is used.
  SPIClass *_spi = nullptr;
  SPISettings _spiSettings = SPISettings(8000000, MSBFIRST, SPI_MODE0);
  bool _callSpiBegin = true;
  uint16_t _csDelayUs = PP_DEFAULT_CS_DELAY_US;

public:
  /**
   * @brief Construct a new PAPAYA object
   *
   */
  PAPAYA();

  /**
   * @brief Construct a new PAPAYA object
   *
   * @param Id
   */
  explicit PAPAYA(int Id);

  /**
   * @brief Construct a PAPAYA host interface bound to a specific SPI bus and CS pin.
   *        This constructor does NOT assert board reset/ID. Call begin(...) if you
   *        want to apply the full hardware init sequence.
   */
  explicit PAPAYA(SPIClass &spi, uint8_t csPin = PP_CS_PIN);

  /**
   * @brief Constructor that performs the full init sequence
   *        but using the provided SPI bus and CS pin.
   */
  PAPAYA(int Id, SPIClass &spi, uint8_t csPin = PP_CS_PIN);

  /**
   * @brief Constructor that binds the board instance to explicit transmit and receive callbacks.
   *
   * The user owns all transport setup in this mode.
   *
   * @param boardId Logical PAPAYA board ID.
   * @param txFunction User-defined transmit function.
   * @param rxFunction User-defined receive function.
   */
  PAPAYA(uint8_t boardId, PP_TransportTxBytesFn txFunction, PP_TransportRxBytesFn rxFunction);

  /**
   * @brief Construct a PAPAYA instance bound to user-supplied transport callbacks.
   *
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   */
  explicit PAPAYA(const PP_TransportHooks &hooks);

  /**
   * @brief Construct a PAPAYA instance bound to user-supplied transport callbacks and a specific CS pin.
   *
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   * @param csPin Logical CS pin identifier forwarded to transport callbacks.
   */
  PAPAYA(const PP_TransportHooks &hooks, uint8_t csPin);

  /**
   * @brief Constructor that performs the full init sequence through user-supplied transport callbacks.
   *
   * @param Id Device ID.
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   */
  PAPAYA(int Id, const PP_TransportHooks &hooks);

  /**
   * @brief Constructor that performs the full init sequence through user-supplied transport callbacks.
   *
   * @param Id Device ID.
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   * @param csPin Logical CS pin identifier forwarded to transport callbacks.
   */
  PAPAYA(int Id, const PP_TransportHooks &hooks, uint8_t csPin);

  /**
   * @brief Arduino-style initialization.
   *
   * This is the recommended way to initialize the library.
   * It configures pins, selects device ID, performs reset, and configures SPI.
   */
  bool begin(int Id);

  /**
   * @brief Initialize the PAPAYA runtime with explicit transmit and receive callbacks.
   *
   * The user owns all transport setup in this mode.
   *
   * @param boardId Logical PAPAYA board ID.
   * @param txFunction User-defined transmit function.
   * @param rxFunction User-defined receive function.
   * @return true if the board ID is valid.
   * @return false otherwise.
   */
  bool begin(uint8_t boardId, PP_TransportTxBytesFn txFunction, PP_TransportRxBytesFn rxFunction);

  /**
   * @brief Arduino-style initialization using a user-provided SPI bus + settings.
   *
   * @param Id Device ID passed to the full-init constructor.
   * @param spi SPI bus to use (e.g., SPI, SPI1, etc.).
   * @param csPin Chip select pin to use.
   * @param settings SPISettings (clock, bit order, mode).
   * @param callSpiBegin If true, calls spi.begin(). If you already began SPI elsewhere, set false.
   * @param csDelayUs Delay (µs) inserted before/after CS to preserve timing margins.
   */
  bool begin(int Id, SPIClass &spi, uint8_t csPin, const SPISettings &settings,
             bool callSpiBegin = true, uint16_t csDelayUs = PP_DEFAULT_CS_DELAY_US);

  /**
   * @brief Take up a board that is ALREADY RUNNING, without restarting it.
   *
   * Identical to begin() in every respect but one: it never drives the
   * reset line, so whatever the board is doing carries on undisturbed.
   * Use it when the host restarts and the board did not, which is
   * exactly what a gateway does when it reopens its network listener.
   * begin() would restart the board and throw away the design running
   * on it; this keeps it.
   *
   * The reset line is left DE-ASSERTED and is written before the pin is
   * made an output, so no pulse reaches the board at any point.
   *
   * This does NOT wait out a boot, because there is no boot to wait for.
   * It does reset the host's own session state (the command sequence
   * number and the status latches), which is right: the host restarted,
   * so the board's counter and this one must be brought back together,
   * and the board begins each connection at zero.
   *
   * @param Id Device ID. Must match the address switch on the board.
   * @return true when the id is valid and the transport is ready.
   */
  bool attach(int Id);

  /**
   * @brief attach() with an explicit SPI bus, chip select and settings.
   *
   * @param Id Device ID.
   * @param spi SPI bus to use.
   * @param csPin Chip select pin to use.
   * @param settings SPISettings (clock, bit order, mode).
   * @param callSpiBegin If true, calls spi.begin().
   * @param csDelayUs Delay (us) inserted before/after CS.
   */
  bool attach(int Id, SPIClass &spi, uint8_t csPin, const SPISettings &settings,
              bool callSpiBegin = true, uint16_t csDelayUs = PP_DEFAULT_CS_DELAY_US);

  /**
   * @brief Initialization using user-supplied transport callbacks.
   *
   * @param Id Device ID.
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   * @param csPin Logical CS pin identifier forwarded to transport callbacks.
   * @param settings Transport settings passed through to beginTransaction callbacks.
   * @param callTransportBegin If true, calls the transport begin callback if provided.
   * @param csDelayUs Delay passed to the chip-select callback or used by the default CS handler.
   */
  bool begin(int Id, const PP_TransportHooks &hooks, uint8_t csPin, const SPISettings &settings,
             bool callTransportBegin = true, uint16_t csDelayUs = PP_DEFAULT_CS_DELAY_US);

  /**
   * @brief Initialization using user-supplied transport callbacks and the default PAPAYA CS pin identifier.
   *
   * @param Id Device ID.
   * @param hooks Transport callbacks for SPI/USB/GPIO integration.
   * @param settings Transport settings passed through to beginTransaction callbacks.
   * @param callTransportBegin If true, calls the transport begin callback if provided.
   * @param csDelayUs Delay passed to the chip-select callback or used by the default CS handler.
   */
  bool begin(int Id, const PP_TransportHooks &hooks, const SPISettings &settings = SPISettings(8000000, MSBFIRST, SPI_MODE0),
             bool callTransportBegin = true, uint16_t csDelayUs = PP_DEFAULT_CS_DELAY_US);

  /**
   * @brief Optional deinitialization hook.
   */
  void end();

  /**
   * @brief Update SPI settings at runtime.
   */
  void setSPISettings(const SPISettings &settings);

  /**
   * @brief Update transport hooks at runtime.
   *
   * @param hooks
   */
  void setTransportHooks(const PP_TransportHooks &hooks);

  /**
   * @brief Update CS timing (µs) at runtime.
   */
  void setCsDelayMicroseconds(uint16_t csDelayUs);

  /**
   * @brief Set the Com Error Handler object
   *
   * @param UserHandler : User-defined error handler function for communication errors
   */
  void setComErrorHandler(PP_ErrorHandlerType UserHandler);

  /**
   * @brief Set the Design Error Handler object
   *
   * @param UserHandler : User-defined error handler function for design errors
   */
  void setDesignErrorHandler(PP_ErrorHandlerType UserHandler);

  /**
   * @brief  Stops the current design session.
   *
   */
  void stopDesign(void);

  /**
   * @brief  Starts a new design session with the specified sampling frequency and algorithm.
   *
   * @param SamplingFreq    Sampling frequency for the design session (Hz).
   * @param Algo            Discretization algorithm.
   */
  void startDesign(float SamplingFreq, PP_C2dAlgo Algo);

  /**
   * @brief  Starts  sampling and processing.
   *
   */
  void startSampling(void);

  /**
   * @brief Stops sampling and processing.
   *
   */
  void stopSampling(void);

  /**
   * @brief Set the Monitoring Interface object
   *
   * @param InterfaceId : Monitoring interface to be used .
   */
  void setMonitoringInterface(PP_MonInterface InterfaceId);

  /**
   * @brief  Gets the current design status.
   *
   * @return PP_DesignStatus
   */
  PP_DesignStatus GetcurrentDesignStatus(void);

  /**
   * @brief Gets the current communication status.
   *
   * @return PP_ComStatus
   */
  PP_ComStatus GetcurrentComStatus(void);

  /**
   * @brief Get the Sequence Number
   *
   * @return uint8_t
   */
  uint16_t getSequenceNumber(void);

  /**
   * @brief Set the Inputs .
   *
   */
  void setInputs(void);

  /**
   * @brief Get the Probes .
   *
   */
  void getProbes(void);

  /* ------------------------------------------------------------------
   * Board / design queries
   *
   * Each of these sends a status-only command and then reads the
   * separate data payload the firmware queues behind the response.
   * They work over USB and SPI alike: over USB the payload follows the
   * status immediately, over SPI it is delivered on the next chip-select
   * assertion. (Only the EEPROM app-storage MUTATIONS are USB-exclusive
   * on the board; these queries are not.)
   *
   * All return false, and leave the output untouched, when the command
   * itself did not succeed, so a caller never reads a struct filled
   * from a payload that was never sent.
   *
   * CONFIG MODE ONLY: this applies to EVERY query below, and to the
   * slot and trace calls further down. While sampling, the board is
   * pushing probe batches on the same pipe a data response would arrive
   * on, and the two contend. That is not a degraded read: it can wedge
   * the board past SwitchToCfg, softReset and McuReset, leaving a
   * physical replug as the only way back. Calls made while sampling are
   * refused with BadRequest rather than attempted. Stop sampling first.
   * ------------------------------------------------------------------ */

  /**
   * @brief Read the board's identity (part number + 96-bit MCU UID).
   * @param info Filled on success.
   * @return true on success.
   */
  bool getBoardInfo(PP_BoardInfo &info);

  /**
   * @brief Measure the design's on-chip CPU and memory footprint.
   *
   * Issue AFTER the design is built (all create/link commands sent) and
   * BEFORE startSampling(). The board builds its own copy of the block
   * array, times five processing passes, snapshots the application
   * memory pool and then tears the copy down, so this never disturbs a
   * running design, but it is also meaningless before one exists.
   *
   * @param info Filled on success.
   * @return true on success.
   */
  bool getDesignInstrumentation(PP_DesignInstrumentation &info);

  /**
   * @brief Ask the board what design it is carrying.
   *
   * The one call interaction code needs before it can do anything: it
   * returns the remote-writable inputs and the readable probes, by name,
   * so a program can work with a deployed diagram without containing it.
   *
   * Config mode only, like every data-response read: call it before
   * startSampling().
   *
   * @param design Filled on success.
   * @return true on success.
   */
  bool describeDesign(PP_RemoteDesign &design);

  /**
   * @brief Index of a named remote input, or -1.
   *
   * The index is the position its value occupies in the input buffer, so
   * this is what turns a name into something writeInputsLive() can use.
   */
  static int remoteInputIndex(const PP_RemoteDesign &design, const char *name);

  /**
   * @brief Index of a named probe, or -1.
   *
   * The index is the position its value occupies in the probe buffer, so
   * this is what turns a name into something probe::getVal(idx) can use.
   */
  static int remoteProbeIndex(const PP_RemoteDesign &design, const char *name);

  /**
   * @brief Read the monitoring metadata string (Fs, buffer size, labels).
   *
   * The payload is NUL-terminated text whose length the response does
   * NOT carry, so the whole of the firmware's maximum is always read and
   * @p capacity must be at least ``PP_DESIGN_INFO_MAX_SIZE + 1``. A
   * smaller buffer is refused rather than served: reading less than the
   * board sent would leave the remainder in the pipe, where the next
   * command mistakes it for its own response and every call after that
   * fails.
   *
   * @param buffer   Destination, at least PP_DESIGN_INFO_MAX_SIZE + 1.
   * @param capacity Size of @p buffer, including room for the NUL.
   * @return true on success.
   */
  bool getDesignInfo(char *buffer, uint16_t capacity);

  /* ------------------------------------------------------------------
   * Audio recording slots
   *
   * Same Start -> Chunk... -> Commit shape as the dataset slots. The
   * difference that matters to a caller is PP_AudioSlotState: a slot can
   * be BUSY (recording or flushing), which is not the same as empty, and
   * writing to one in that state would fight the capture.
   * ------------------------------------------------------------------ */

  /**
   * @brief List every audio slot.
   * @param count Optional; set to how many entries were written.
   * @return true on success.
   */
  bool listAudioSlots(PP_AudioSlotInfo *out, uint8_t capacity,
                      uint8_t *count = nullptr);

  /** @brief Read one audio slot's header. @return true on success. */
  bool getAudioSlotInfo(uint8_t slotId, PP_AudioSlotInfo &info);

  /** @brief Erase one audio slot. @return true when accepted. */
  bool eraseAudioSlot(uint8_t slotId);

  /** @brief Erase every audio slot. @return true when accepted. */
  bool eraseAllAudioSlots(void);

  /**
   * @brief Begin an audio upload: erase the slot and declare what follows.
   *
   * There is no name: a slot header, audio or dataset, does not carry one.
   *
   * @return true when the board accepted the command.
   */
  bool uploadAudioSlotStart(uint8_t slotId, uint16_t format,
                            uint32_t sampleRateHz, uint32_t lengthSamples);

  /** @brief Send one piece of the audio payload. @return true when accepted. */
  bool uploadAudioSlotChunk(uint8_t slotId, uint32_t offset,
                            const uint8_t *data, uint16_t size);

  /** @brief Finish an audio upload and validate the slot. */
  bool uploadAudioSlotCommit(uint8_t slotId, uint32_t crc32,
                             uint32_t timestampUnix);

  /** @brief Read part of an audio slot's float32 PCM payload. */
  bool downloadAudioSlot(uint8_t slotId, uint32_t offset, uint16_t length,
                         uint8_t *buffer);

  /* ------------------------------------------------------------------
   * Dataset FLASH slots
   *
   * The board keeps recorded signals in FLASH so a
   * signalSource::dataset block can play one back with no host in the
   * loop. C++ could already CREATE that block but not put anything in a
   * slot, list what was there, or read one back. Half a feature.
   *
   * Upload is Start -> Chunk... -> Commit: the board erases and sizes
   * the slot on Start, takes the payload in pieces, and only marks the
   * slot valid on Commit. An upload abandoned midway therefore leaves
   * the slot empty rather than half-written.
   * ------------------------------------------------------------------ */

  /**
   * @brief List every dataset slot.
   * @param out      Array to fill, one entry per slot.
   * @param capacity Entries @p out can hold; PP_DATASET_SLOT_COUNT is enough.
   * @param count    Optional; set to how many entries were written.
   * @return true on success.
   */
  bool listDatasets(PP_DatasetInfo *out, uint8_t capacity, uint8_t *count = nullptr);

  /**
   * @brief Read one slot's header.
   * @return true on success.
   */
  bool getDatasetInfo(uint8_t slotId, PP_DatasetInfo &info);

  /**
   * @brief Erase one slot, so it reads back empty.
   * @return true when the board accepted the command.
   */
  bool eraseDataset(uint8_t slotId);

  /**
   * @brief Begin an upload: erase the slot and declare what is coming.
   *
   * @param slotId        Target slot, < PP_DATASET_SLOT_COUNT.
   * @param format        Sample encoding; 0 for float32.
   * @param sampleRateHz  Rate the data was captured at.
   * @param lengthSamples Total samples that will be sent.
   * @return true when the board accepted the command.
   */
  bool uploadDatasetStart(uint8_t slotId, uint16_t format, uint32_t sampleRateHz,
                          uint32_t lengthSamples);

  /**
   * @brief Send one piece of the payload at a byte @p offset.
   * @return true when the board accepted the chunk.
   */
  bool uploadDatasetChunk(uint8_t slotId, uint32_t offset,
                          const uint8_t *data, uint16_t size);

  /**
   * @brief Finish an upload and mark the slot valid.
   *
   * @param crc32         CRC-32 of the whole payload, stored for later
   *                      verification; 0 if the caller has none.
   * @param timestampUnix Capture time, or 0.
   * @return true when the board accepted the slot.
   */
  bool uploadDatasetCommit(uint8_t slotId, uint32_t crc32, uint32_t timestampUnix);

  /**
   * @brief Put a whole recording in a slot: Start, chunks, Commit.
   *
   * The Python library has had this for as long as the three calls below
   * have existed, and generated C++ needs it for the same reason: a program
   * that plays a dataset has to get the recording onto the board, and the
   * three-step sequence with its CRC is not something a generated file
   * should be spelling out.
   *
   * The CRC-32 is the zlib polynomial over the payload bytes, which is what
   * the board checks the slot against.
   *
   * The rate stamped into the slot header is the design's sampling
   * frequency, taken from startDesign(). It is not a required argument
   * because it is not a separate fact: the samples are fed to the graph
   * one per tick, so the rate they play at IS the rate the design runs
   * at. sampleRateHz overrides it for the one case that differs, a
   * recording uploaded for something other than the running design.
   *
   * @param slotId       Slot to fill, 0 to 7.
   * @param samples      Sample values, float32.
   * @param count        How many of them.
   * @param sampleRateHz Override for the header rate; 0 means "the
   *                     design's", which is what you want.
   * @return true only when every step was accepted.
   */
  bool uploadDataset(uint8_t slotId, const float *samples, uint32_t count,
                     uint32_t sampleRateHz = 0u);

  /**
   * @brief Read part of a slot's payload back.
   *
   * Datasets are usually far bigger than one buffer, so this is chunked
   * the same way the upload is.
   *
   * @param length Bytes to read; @p buffer must be at least this large.
   * @return true on success.
   */
  bool downloadDataset(uint8_t slotId, uint32_t offset, uint16_t length,
                       uint8_t *buffer);

  /* ------------------------------------------------------------------
   * Live probe reads (push model)
   *
   * getProbes() asks the board for the current values and waits for the
   * answer, the right shape for SPI, where the master drives every
   * exchange. Over USB the board instead PUSHES batches while sampling,
   * and they queue. Polling that queue with a request/response call
   * cannot tell a fresh batch from a backlogged one, which is how a
   * control loop ends up acting on data several batches old while every
   * read reports success.
   *
   * These two read the push stream and say how stale the answer is.
   * Both need a packet reader (see setPacketReader) and decline without
   * one, rather than pretending the pull model is equivalent.
   * ------------------------------------------------------------------ */

  /**
   * @brief Supply the packet reader the live reads need. See
   *        PP_TransportRxPacketFn.
   */
  void setPacketReader(PP_TransportRxPacketFn reader);

  /**
   * @brief Take the OLDEST queued batch and refresh the probe values.
   *
   * After this, probe::getVal() returns the newest sample this batch
   * carried, for every registered scalar probe.
   *
   * Reads the oldest batch waiting, not the newest, so a caller slower
   * than the board falls further behind on every call. Use
   * readProbesLatest() in anything that acts on what it reads.
   *
   * @param result   Optional; filled with the outcome and staleness.
   * @param timeoutMs How long to wait for a batch.
   * @return true when a batch was received.
   */
  bool readProbesLive(PP_ProbeRead *result = nullptr, uint32_t timeoutMs = 250u);

  /**
   * @brief Discard the backlog and refresh from the NEWEST batch.
   *
   * Same effect on probe::getVal() as readProbesLive(), but the batches
   * that had piled up behind the newest are dropped rather than handed
   * out one per call. ``result->ageBatches`` is how many were skipped,
   * which is a direct measure of how far behind the caller had fallen.
   *
   * This is the read to use in a loop that closes on what it reads.
   *
   * @param result   Optional; filled with the outcome and staleness.
   * @param timeoutMs How long to wait for the first batch.
   * @return true when a batch was received.
   */
  bool readProbesLatest(PP_ProbeRead *result = nullptr, uint32_t timeoutMs = 250u);

  /**
   * @brief Read the shape of every monitored vector probe.
   *
   * Answers what the pushed payload actually contains: how many probes,
   * how many bytes each contributes, and their labels. A caller that did
   * not build the design itself has no other way to interpret the block.
   *
   * @param out      Array to fill.
   * @param capacity Entries @p out can hold.
   * @param count    Optional; set to how many were written.
   * @return true on success.
   */
  bool describeVectProbes(PP_VectorProbeDesc *out, uint8_t capacity,
                          uint8_t *count = nullptr);

  /* ------------------------------------------------------------------
   * Offline capture (trace) and diagnostics
   *
   * The board can record at the full sample rate into its large sample
   * memory and hand the trace over afterwards, which is how you capture
   * something faster
   * than the link can stream. Typical order:
   *
   *   setMonitorMode(Offline) -> setTraceSize(n) -> startSampling()
   *   ... wait for the capture to fill -- do NOT poll ...
   *   stopSampling() -> getCaptureStatus() -> downloadTrace() in chunks
   *
   * Note where getCaptureStatus() sits: AFTER stopSampling(), not during
   * the wait. It returns a data payload, and reading one while the board
   * is pushing probe batches contends on the same pipe -- which can wedge
   * the board past every software reset. Both it and downloadTrace()
   * refuse with BadRequest while sampling. Size the wait from the capture
   * instead: n samples at the design's Fs takes n/Fs seconds.
   * ------------------------------------------------------------------ */

  /**
   * @brief Choose live streaming, offline trace capture, or both.
   * @param mode One of PP_MonitorMode.
   * @return true when the board accepted the command.
   */
  bool setMonitorMode(PP_MonitorMode mode);

  /**
   * @brief Set the offline trace depth, in full-rate samples.
   *
   * Set BEFORE starting sampling; the board sizes its trace buffer from
   * this. A request larger than the trace memory is refused by the
   * board rather than silently truncated.
   *
   * @param totalSamples Depth in samples.
   * @return true when the board accepted the command.
   */
  bool setTraceSize(uint32_t totalSamples);

  /* NOTE: there is deliberately no setLiveRate() here. The Python
   * library still exposes one, but the board's SetLiveRate command is
   * deprecated and answers BadParam unconditionally: the
   * samples-per-probe rate is fixed on the board. Mirroring Python
   * faithfully would have added a call that can only ever fail, and
   * (because the board latches a failure) would break the commands
   * issued after it. Verified against hardware. */

  /**
   * @brief Read how far an offline capture got.
   *
   * Despite the name this is NOT for polling during a capture: it reads
   * a data payload, which contends with the board's probe push and can
   * wedge the link. Call it after stopSampling(); while sampling it
   * refuses with BadRequest.
   *
   * @param status Filled on success.
   * @return true on success.
   */
  bool getCaptureStatus(PP_CaptureStatus &status);

  /**
   * @brief Read part of the offline trace.
   *
   * The trace is normally far larger than any sensible single buffer, so
   * it is read in chunks: pass the byte @p offset and how many bytes to
   * take. The board refuses a range that runs past the end of the
   * recorded trace rather than returning short.
   *
   * @param offset Byte offset into the trace.
   * @param length Bytes to read; @p buffer must be at least this large.
   * @param buffer Destination.
   * @return true on success.
   */
  bool downloadTrace(uint32_t offset, uint16_t length, uint8_t *buffer);

  /**
   * @brief Read the board's diagnostic log.
   *
   * Useful when a design is refused and the status code alone does not
   * say why.
   *
   * The board's log buffer is PP_DEBUG_LOG_MAX_SIZE (16 KB) and it sends
   * as much of it as it holds, so @p capacity must be at least
   * ``PP_DEBUG_LOG_MAX_SIZE + 1``. That is deliberately large: a smaller
   * read leaves the rest of the log in the pipe and every subsequent
   * command fails, which is exactly the "board appears dead after a
   * successful GetDebugLog" failure the firmware warns about. A buffer
   * that is too small is refused rather than half-filled.
   *
   * @param buffer   Destination, at least PP_DEBUG_LOG_MAX_SIZE + 1.
   * @param capacity Size of @p buffer, including room for the NUL.
   * @return true on success.
   */
  bool getDebugLog(char *buffer, uint32_t capacity);

  /**
   * @brief Empty the board's diagnostic log.
   *
   * Worth doing before reproducing a problem, so what you read back
   * afterwards is only about that attempt.
   *
   * @return true when the board accepted the command.
   */
  bool clearDebugLog(void);

  /**
   * @brief Software-fire a triggered signalSource, with no wired trigger.
   *
   * Restarts the source's timeline and emits its burst / opens its gate
   * exactly as a hardware trigger edge would. Safe to call while
   * sampling: it is a runtime control, like the DWT live-tune calls.
   *
   * A block id that is not a triggered signal source is a safe no-op on
   * the board, which type-guards the target.
   *
   * @param blockId On-board wire id of the target block.
   * @return true when the board accepted the command.
   */
  bool signalSourceManualTrigger(uint16_t blockId);

  /**
   * @brief Get the Vector Probes .
   *
   */
  void getVectorProbes(void);

  /* ---- Gateway relay API ----
   *
   * Executing commands somebody ELSE composed.
   *
   * Every other entry point in this class builds its own command: a
   * constructor decides what to say and this library says it. A host that
   * relays for PAPAYA Studio is the opposite case. The bytes arrive
   * already formed, over whatever link the host speaks, and the host's
   * only job is to put them on the wire correctly and bring the answer
   * back. It builds nothing and it interprets nothing.
   *
   * That is why these take raw buffers and explicit sizes. In particular
   * the reads below exist because getProbes() sizes itself from
   * probe::currentProbeIdx -- the number of probe objects THIS PROGRAM
   * constructed -- and a relay constructs none, so it would ask the board
   * for zero bytes and get nothing. The size has to come from the far end,
   * which knows the design.
   *
   * The relay never needs to know what an opcode means. There are only
   * five transaction shapes on this wire, and these are them.
   */

  /**
   * @brief Shape 1: run a config command and collect its status.
   *
   * Sends @p header (PP_CMD_HEADER_SIZE bytes), then @p body in protocol
   * chunks, then polls until the board answers or the response deadline
   * expires. The 7-byte status frame lands in @p response.
   *
   * @param header      an already-serialised command header.
   * @param body        already-serialised body, or nullptr when empty.
   * @param bodyLength  bytes in @p body.
   * @param response    receives PP_RESPONSE_SIZE bytes.
   * @return false if the arguments are unusable or no context is active.
   *         A board that answers with an error status still returns true:
   *         that is a reply, and the far end is the one entitled to judge
   *         it.
   */
  bool relayCommand(const uint8_t *header, const uint8_t *body,
                    uint16_t bodyLength, uint8_t *response);

  /**
   * @brief Shape 2: as relayCommand(), then read the data payload.
   *
   * Some commands answer with a status frame AND a payload, which the
   * board holds for one further exchange. The caller must know how many
   * bytes to expect; on this transport nothing announces a length.
   */
  bool relayCommandWithData(const uint8_t *header, const uint8_t *body,
                            uint16_t bodyLength, uint8_t *response,
                            uint8_t *data, uint16_t dataLength);

  /**
   * @brief Shape 5: send a command that will not answer.
   *
   * The reset-class opcodes reboot the MCU before a response could be
   * composed, so polling for one burns the whole deadline and then
   * reports a comms failure for a command that did exactly what it was
   * asked. The far end knows which commands these are; this library does
   * not need to.
   */
  void relayCommandNoResponse(const uint8_t *header, const uint8_t *body,
                              uint16_t bodyLength);

  /* ---- Shape 1, in pieces ----
   *
   * relayCommand() takes the whole body, which is right for a host that
   * has the whole body. A host relaying over the air does not: a command
   * reaches it a chunk at a time precisely so that it never needs a
   * buffer larger than one chunk, whatever the size of the command
   * passing through. The largest legitimate command carries an inline
   * waveform table of 65 553 bytes, and the smallest hosts this is for
   * have 32 KB of memory in total.
   *
   * So the same transaction is available as three steps. The timing
   * belongs to the library either way: the chip-select guard, the chunk
   * size and the response deadline are the board's, not a choice a host
   * gets to make.
   *
   * ONE OBLIGATION comes with using them. The board has no inter-frame
   * timeout: a command begun and not finished leaves its receive state
   * machine waiting forever, and nothing short of a reset clears it. A
   * host that cannot finish a body must send the rest as filler anyway
   * and consume the error the board then answers with. An error is
   * recoverable; a stalled state machine is not.
   */

  /**
   * @brief Begin a relayed command: put its header on the wire.
   *
   * Adopts the sequence number out of @p header, because the far end
   * composed the command and the poll has to carry the number the board
   * will answer with.
   */
  void relayBeginCommand(const uint8_t *header);

  /**
   * @brief One body chunk of a command already begun.
   *
   * @param length at most PP_CMD_CHUNK_SIZE, the board's own figure.
   * @return false if the arguments are unusable or no context is active.
   */
  bool relaySendBodyChunk(const uint8_t *chunk, uint16_t length);

  /**
   * @brief Poll for the status of a command already sent whole.
   *
   * @param response receives PP_RESPONSE_SIZE bytes.
   * @return false only when the conversation did not happen. An error
   *         status is a reply, and judging it is the far end's business.
   */
  bool relayAwaitResponse(uint8_t *response);

  /**
   * @brief The payload the board queued behind a status.
   *
   * Call ONLY after a status that reported success. Reading a payload the
   * board never queued consumes the next command's response instead, and
   * the link is desynchronised from that point on. The caller must know
   * how many bytes to expect; nothing on this transport announces a
   * length.
   */
  bool relayReadDataPayload(uint8_t *data, uint16_t dataLength);

  /**
   * @brief Shape 3: poll probes by explicit byte count.
   *
   * @param buffer     receives up to @p byteCount bytes.
   * @param byteCount  probes x sizeof(float), from the far end.
   * @return bytes read, or 0.
   */
  uint16_t relayReadProbes(uint8_t *buffer, uint16_t byteCount);

  /** @brief Shape 3, vector probes. Same contract as relayReadProbes(). */
  uint16_t relayReadVectorProbes(uint8_t *buffer, uint16_t byteCount);

  /**
   * @brief Shape 4: push input values by explicit byte count.
   *
   * All slots travel in one exchange. Splitting them leaves the firmware
   * waiting for floats and mis-parsing whatever arrives next, so the
   * values must be handed over whole.
   */
  bool relayWriteInputs(const uint8_t *values, uint16_t byteCount);

  /**
   * @brief Shape 6: one opcode byte on the wire, and nothing else.
   *
   * Several exchanges on this wire are a single byte: the mode change
   * back to configuration is the one that matters most, because it is
   * the only command the firmware accepts in any state and without
   * checking the sequence number, which is what makes it the way back
   * from a session that ended badly.
   *
   * A relay could not send one before. Every other relay entry point
   * puts a header on the wire first, and for a lone opcode that is not
   * merely wasteful: the firmware reads byte zero of that header as the
   * opcode, and byte zero of a bare header is 0x00, which means write
   * input values. So asking a relayed board to return to configuration
   * mode did not fail, it left the board waiting for floats.
   *
   * One chip-select pulse carrying one byte, and nothing polled
   * afterwards, because these opcodes do not answer.
   *
   * @param opcode the single byte, e.g. PP_CMD_SWITCH_BACK_TO_CFG.
   * @return true when the byte reached the transport.
   */
  bool relaySendOpcode(uint8_t opcode);

  /**
   * @brief Assert and release the board's reset line.
   *
   * The capability a USB host does not have. Over a cable the host can
   * only ASK the board to reset, using the protocol, which is no help
   * once the board has stopped listening -- and there is a documented
   * state where a lost mode-change byte leaves it streaming into an
   * endpoint nobody drains, recoverable by nothing short of physical
   * reset. A wired host owns the line, so for a relayed board that state
   * stops meaning "go and visit the machine".
   *
   * Uses the same assert and boot-settle timing as bring-up, and returns
   * only once the board has had time to come back.
   *
   * @return false when the active transport has no reset hook, so a
   *         caller can tell "not wired" from "tried and failed".
   */
  bool resetBoard(void);

  /* ---- Live (sampling-mode) developer API ----
   *
   * Mirrors the Python helpers of the same name. Use these from a host
   * MCU after startSampling() has been issued to poll probes and push
   * inputs without going through the design-time transaction flow.
   */

  /**
   * @brief Receive one USB auto-push probe packet and refresh ProbesBuffer.
   *
   * The board autonomously pushes a single bulk packet per sample period:
   *   [PP_CMD_READ (0x01)] + <currentProbeIdx * 4> bytes of float32.
   * On success, subsequent calls to ``probe::getVal()`` return the fresh
   * live sample. Returns true on success, false on wrong opcode / short
   * read / no transport bound.
   *
   * @param timeoutUs Max time (microseconds) to wait for the packet.
   */
  bool readProbesLive(uint32_t timeoutUs = 250000u);

  /**
   * @brief Push the current InputsBuffer contents to the board now.
   *
   * Wire format: [PP_CMD_WRITE (0x00)] + <currentInputIdx * 4> bytes
   * of float32 (in registration order).
   */
  bool writeInputsLive(void);

  /**
   * @brief Queue a new value for a remote input and push it immediately.
   */
  bool setInputLive(class input &inp, float value);

  /* ---- EEPROM App Storage ----
   *
   * USB-exclusive set (the board answers design status 8, BadRequest,
   * when one is issued from a non-USB transport such as an SPI master):
   * enableStorage,
   * commitToEeprom, abortStorage, uploadApp, dumpApp, deleteApp,
   * eraseAll, syncEeprom, setBootApp.  These exist on this library so
   * a USB-attached host can use the same API; an Arduino SPI master
   * should restrict itself to the SPI-allowed subset:
   *     loadApp / listApps / getBootCfg
   * (plus the live data-exchange helpers above).
   */

  /** @brief Begin recording commands for EEPROM storage.  USB-only. */
  void enableStorage(const char* label);

  /** @brief Finalize recording and write to EEPROM.  USB-only. */
  void commitToEeprom(void);

  /** @brief Discard the in-progress recording without committing.  USB-only. */
  void abortStorage(void);

  /** @brief Load and replay a stored app from EEPROM (no auto-start).
   *
   *  Tears down any prior design + sampling, replays the stored command
   *  stream, and leaves the design loaded but idle.  Caller is expected
   *  to call ``startSampling`` once ready to receive.  Allowed over SPI.
   *
   *  @param appId Directory id (see ``listApps``). */
  void loadApp(uint16_t appId);

  /** @brief Load + replay + (optionally) auto-start a stored app.
   *
   *  Same as the single-argument overload, but synthesises a
   *  ``StartSampling`` at the end of replay when ``autoStart`` is
   *  ``true`` so probes start streaming immediately.  Allowed over SPI.
   *
   *  @param appId     Directory id (see ``listApps``).
   *  @param autoStart When ``true``, firmware fires ``StartSampling``
   *                   at the end of replay. */
  void loadApp(uint16_t appId, bool autoStart);

  /** @brief Read the raw bytes of a stored app.  USB-only.
   *
   *  Used by Studio to re-decode an app back into the editor.  An SPI
   *  master never needs this: it issues ``loadApp`` and lets the
   *  firmware replay onto the live design directly. */
  void dumpApp(uint16_t appId);

  /** @brief Replace the bytes of an existing stored app.  USB-only.
   *
   *  In-place update (preserves AppId / boot pointer).  Studio uses this
   *  via the "Update on Board" path after editing a saved diagram. */
  void uploadApp(uint16_t appId, const uint8_t* data, uint16_t length);

  /** @brief Delete a stored app from EEPROM.  USB-only. */
  void deleteApp(uint16_t appId);

  /** @brief Wipe every stored app + the boot pointer.  USB-only. */
  void eraseAll(void);

  /** @brief List all stored apps (returns data via response).  Allowed over SPI. */
  void listApps(void);

  /** @brief Flush pending EEPROM writes.  USB-only.
   *
   *  Mutates physical EEPROM, hence USB-only.  An SPI master never
   *  needs this since it cannot issue write-side EEPROM commands. */
  void syncEeprom(void);

  /** @brief Persist which app the firmware auto-loads on power-up.  USB-only.
   *
   *  Pass ``bootId == 0xFFFFu`` to clear (boot to idle).  Callers that
   *  want the change to survive a power cycle must follow up with
   *  ``syncEeprom()`` to flush the board's in-memory mirror to the
   *  non-volatile store. */
  void setBootApp(uint16_t bootId, bool autoLoad);

  /** @brief Read the persisted boot config.  Allowed over SPI.
   *
   *  Firmware replies with a 3-byte data response: little-endian
   *  uint16 BootAppId followed by uint8 AutoLoad flag.  Useful for an
   *  SPI master that wants to confirm which app is auto-loading on
   *  reset before issuing its own ``loadApp(otherId)``. */
  void getBootCfg(void);

  /* ---- Reset ---- */

  /** @brief Destructive reset of the board's processor. Everything the
   *  board is holding, including a loaded design, is lost. */
  void mcuReset(void);

  /** @brief Soft reset: stop sampling, free blocks, stay connected. */
  void softReset(void);

  /** @brief Drive the FreqIn-x CH2 source mux on PAPAYA VL.
   *
   *  channel is 0..4 (FreqIn 1..5). source is 0 for the external CN pin
   *  (default) or 1 for the on-board comparator output. When source
   *  is 1 the matching analog-output channel must drive AN_OUT_<channel+1>
   *  to the desired threshold voltage. */
  void setFreqInCh2Source(uint8_t channel, uint8_t source);

  /** @brief Exchange which of a frequency input's two pins is the reference.
   *
   *  Only meaningful for Delay-mode designs, where the delay is measured
   *  from the reference pin's edge to the other pin's edge: call this when
   *  the first rising edge actually arrives on the second pin, so the
   *  measured delay comes out as a full period minus the delay you wanted.
   *  Must be called AFTER the matching pwmIn(...) create. */
  void setFreqInSwapPins(uint8_t channel);
};

#endif /* PAPAYA_H */
