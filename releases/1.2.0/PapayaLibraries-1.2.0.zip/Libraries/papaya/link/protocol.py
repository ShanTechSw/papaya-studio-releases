"""The PAPAYA Link wire format.

Pure. Reads and writes bytes, opens nothing, and holds no state beyond a
decoder's own buffer. That is deliberate: the interesting failures on this
link are framing failures, and framing is exactly the part that can be
tested to exhaustion without a board, a radio or a gateway.

Why a frame at all, on a link that may be TCP
---------------------------------------------
TCP would give ordering and delivery for free, so a header with a checksum
looks like belt and braces. It is not, for three reasons:

* **The link is not always TCP.** Bluetooth is a datagram service with
  stack-dependent fragmentation, and a coprocessor-based host reaches its
  own radio over a serial line. A frame that only survives on one of those
  is a frame that has to be re-invented for the others.
* **A relay is not a pipe.** The far end must be able to resynchronise
  after a truncated write or a half-finished session, and there is nothing
  in a byte stream to resynchronise *to* without a magic to hunt for.
* **The payload is a board's command.** Handing the board a subtly wrong
  command is materially worse than handing it none, because the failure
  surfaces later and somewhere else. Paying four bytes to refuse it here
  is a good trade.

The 400-byte rule, which shapes everything
------------------------------------------
A command's body travels the board's own wire in chunks of
:data:`BOARD_CHUNK_SIZE`, and the gateway's job is to put those chunks on
that wire. **So the gateway must never need a buffer bigger than one
chunk**, whatever the size of the command passing through it.

That is not a nicety. The smallest hosts this feature targets have 32 KB
of RAM in total, and the largest legitimate command -- an inline waveform
table -- is 65 553 bytes. A link that handed the gateway a whole command
would be unusable on those boards and wasteful on the rest.

So a command arrives as a first frame carrying its header and first chunk,
followed by chunk frames. Most commands fit entirely in the first frame,
because most bodies are a few dozen bytes and a design is hundreds of
commands: turning every one of those into a three-message handshake would
triple the round trips on the link where round trips are the expensive
part. Only the large ones are split.

One consequence to carry into the gateway, not solved here: the board has
**no inter-frame timeout**. A command abandoned partway leaves its receive
state machine waiting forever. A gateway that loses the link mid-command
must therefore finish the chunks the header declared, so the board
completes its receive, fails the body checksum and answers an error --
which is recoverable, where a wedged state machine is not.

Why the length is 32 bits
-------------------------
Chunking bounds command traffic, but not everything on this link is a
command: a telemetry batch or a trace payload is one message and can be
larger. A 16-bit length would cap those at 65535 for no reason, so the
field is 32 bits and :data:`MAX_PAYLOAD` is the real bound.

Frame layout, little-endian throughout::

     0  magic     u16   0x504C, spelling "PL" on the wire
     2  version   u8
     3  type      u8    MessageType
     4  seq       u16   wraps; matches a reply to its request
     6  length    u32   payload bytes
    10  payload   length bytes
    10+ checksum  u32   CRC-32 over bytes 0 .. 10+length-1

The checksum is the same CRC-32 the board's own protocol uses, so a host
already carrying one does not gain a second implementation.
"""
from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field
from enum import IntEnum
from typing import List, Optional, Tuple

#: "PL", readable in a hex dump, which matters when someone is staring at
#: a capture wondering whose bytes these are.
MAGIC = 0x504C

PROTOCOL_VERSION = 1

_HEADER = struct.Struct("<HBBHI")
HEADER_SIZE = _HEADER.size          # 10
CHECKSUM_SIZE = 4
FRAME_OVERHEAD = HEADER_SIZE + CHECKSUM_SIZE

#: Generous, and still a bound. A trace download is the large case; this
#: sits well above it and well below "a corrupt length allocates a gigabyte".
MAX_PAYLOAD = 1 << 20

#: The board's own command chunk size, mirrored here on purpose.
#:
#: A command body crosses the board's wire in pieces this size, and the
#: gateway's job is to put those pieces on that wire. Bounding the link's
#: command chunks to the same figure means the gateway needs a buffer of
#: exactly one chunk no matter how large the command is -- which is what
#: makes a 32 KB host viable at all.
#:
#: It is NOT a tuning knob. It is the board's constant, and the two must
#: agree or a chunk arrives that cannot be forwarded whole.
BOARD_CHUNK_SIZE = 400


class MessageType(IntEnum):
    """Numbered in groups, with gaps, because these cross a version
    boundary the moment one gateway is older than the Studio driving it."""

    # -- session --------------------------------------------------
    HELLO = 0x01
    WELCOME = 0x02
    AUTH_CHALLENGE = 0x03
    AUTH_RESPONSE = 0x04

    # -- relaying a board command ---------------------------------
    CMD = 0x10
    CMD_RESULT = 0x11
    #: One further body chunk for the command already begun. See the
    #: 400-byte rule in the module docstring.
    CMD_CHUNK = 0x12

    # -- a design, taken whole before any of it reaches the board --
    DESIGN_BEGIN = 0x20
    DESIGN_CHUNK = 0x21
    DESIGN_COMMIT = 0x22
    DESIGN_ABORT = 0x23

    # -- things the gateway does locally, never relayed ------------
    MODE = 0x30
    RESET = 0x31

    # -- telemetry -------------------------------------------------
    SUBSCRIBE = 0x40
    UNSUBSCRIBE = 0x41
    TELEMETRY = 0x42
    VECTOR_TELEMETRY = 0x43

    # -- driving a running design ----------------------------------
    INPUT = 0x50

    # -- diagnosis -------------------------------------------------
    EVENT = 0x60
    PING = 0x70
    PONG = 0x71
    STATS = 0x72
    BYE = 0x7F


class TransactionShape(IntEnum):
    """How a relayed command is performed on the board's wire.

    The gateway implements these six and parses no opcodes at all, which
    is what stops it drifting away from a firmware it does not model. The
    far end knows what it is asking for and says which shape it needs.
    """

    #: Header, body chunks, then poll for the status.
    CONFIG = 1
    #: As CONFIG, then one further exchange for the payload the board
    #: queued behind that status.
    CONFIG_WITH_DATA = 2
    #: Opcode byte, then read a known number of bytes.
    PROBE_READ = 3
    #: Opcode byte, then the values, whole.
    INPUT_WRITE = 4
    #: Header and body, and no poll: the board reboots before it could
    #: answer, so waiting spends the whole deadline and then reports a
    #: failure for a command that did exactly what it was asked.
    FIRE_AND_FORGET = 5
    #: One opcode byte on the wire, nothing before it, nothing after it,
    #: and no poll.
    #:
    #: The board's wire carries a handful of exchanges that are a single
    #: byte, and a cable sends them as one byte because a cable can. Every
    #: other shape here puts a header on the wire first, and for these
    #: that is not merely wasteful, it is wrong: the board reads byte zero
    #: of a bare header as an opcode, and byte zero is 0x00, which is the
    #: input-write opcode. So a mode change sent as a CONFIG transaction
    #: did not fail, it made the board expect input values.
    #:
    #: The opcode travels in the header's read/write field, where the
    #: board's own protocol puts it and where PROBE_READ already reads
    #: it from, so this costs nothing on the wire beyond the shape value
    #: itself.
    #:
    #: No status is polled because these opcodes do not produce one.
    OPCODE_ONLY = 6


# ==========================================================================
# Errors
# ==========================================================================
class LinkProtocolError(Exception):
    """Base for every framing failure, so a caller can catch one thing."""


class BadMagic(LinkProtocolError):
    """The stream is not aligned to a frame."""


class BadChecksum(LinkProtocolError):
    """A frame arrived corrupt. Distinct from BadMagic on purpose: this
    one means we WERE aligned, which is a different diagnosis."""


class UnsupportedVersion(LinkProtocolError):
    """Peer speaks a version this build does not."""

    def __init__(self, seen: int) -> None:
        super().__init__(
            f"peer speaks link protocol version {seen}, this build speaks "
            f"{PROTOCOL_VERSION}. Update whichever end is older; they cannot "
            f"negotiate below the header they disagree about.")
        self.seen = seen


class PayloadTooLarge(LinkProtocolError):
    """A length no legitimate message reaches. Refused before allocating,
    because the whole point of the bound is to not act on a corrupt one."""


# ==========================================================================
# Frames
# ==========================================================================
@dataclass(frozen=True)
class LinkFrame:
    type: MessageType
    payload: bytes = b""
    seq: int = 0
    version: int = PROTOCOL_VERSION

    def __post_init__(self) -> None:
        if len(self.payload) > MAX_PAYLOAD:
            raise PayloadTooLarge(
                f"{len(self.payload)} bytes exceeds the {MAX_PAYLOAD} limit")


def encode(frame: LinkFrame) -> bytes:
    """Serialise one frame, checksum included."""
    if len(frame.payload) > MAX_PAYLOAD:
        raise PayloadTooLarge(
            f"{len(frame.payload)} bytes exceeds the {MAX_PAYLOAD} limit")

    head = _HEADER.pack(MAGIC, frame.version, int(frame.type),
                        frame.seq & 0xFFFF, len(frame.payload))
    body = head + frame.payload
    return body + struct.pack("<I", zlib.crc32(body) & 0xFFFFFFFF)


class FrameDecoder:
    """Turns a byte stream back into frames.

    Incremental because the transports are: TCP delivers whatever it
    delivers, and a serial link to a radio coprocessor delivers less than
    that. Feed it arbitrary slices and it yields whole frames.

    On corruption it resynchronises by hunting for the next magic rather
    than giving up on the connection. A relay that dropped the link every
    time a frame was mangled would turn a recoverable glitch into a
    reconnect, and a reconnect costs the board's session.
    """

    def __init__(self) -> None:
        self._buffer = bytearray()
        #: Frames discarded to regain alignment. A rising count is the
        #: symptom worth surfacing; a single one is a glitch.
        self.resyncs = 0

    def feed(self, data: bytes) -> List[LinkFrame]:
        self._buffer.extend(data)
        frames: List[LinkFrame] = []
        while True:
            frame = self._take_one()
            if frame is None:
                return frames
            frames.append(frame)

    @property
    def pending(self) -> int:
        """Bytes held back waiting for the rest of a frame."""
        return len(self._buffer)

    def _take_one(self) -> Optional[LinkFrame]:
        while True:
            if len(self._buffer) < HEADER_SIZE:
                return None

            magic, version, kind, seq, length = _HEADER.unpack_from(self._buffer)

            if magic != MAGIC or length > MAX_PAYLOAD:
                # Not aligned, or a length no real message reaches. Both
                # mean the same thing: this is not a frame boundary.
                self._resync()
                continue

            total = HEADER_SIZE + length + CHECKSUM_SIZE
            if len(self._buffer) < total:
                return None                      # the rest is still in flight

            body = bytes(self._buffer[:HEADER_SIZE + length])
            seen = struct.unpack_from(
                "<I", self._buffer, HEADER_SIZE + length)[0]

            if seen != (zlib.crc32(body) & 0xFFFFFFFF):
                self._resync()
                continue

            del self._buffer[:total]

            if version != PROTOCOL_VERSION:
                # Raised, not resynced: the frame was intact, so this is a
                # disagreement rather than damage, and quietly skipping it
                # would leave the peer waiting for a reply forever.
                raise UnsupportedVersion(version)

            try:
                message = MessageType(kind)
            except ValueError:
                # An intact frame of a type we do not know. A newer peer
                # is entitled to send one; ignoring it is how a protocol
                # stays extensible.
                continue

            return LinkFrame(type=message, payload=body[HEADER_SIZE:],
                             seq=seq, version=version)

    def _resync(self) -> None:
        """Drop to the next plausible frame start."""
        self.resyncs += 1
        nxt = self._buffer.find(struct.pack("<H", MAGIC), 1)
        if nxt < 0:
            # Keep the last byte: a magic may straddle this feed and the
            # next one, and discarding it would lose the frame after the
            # damaged one as well.
            del self._buffer[:max(0, len(self._buffer) - 1)]
        else:
            del self._buffer[:nxt]


# ==========================================================================
# Payload codecs
# ==========================================================================
_CMD = struct.Struct("<BHII")      # shape, header_len, total_body_len, data_len
_CHUNK = struct.Struct("<H")       # chunk index


def encode_command(shape: TransactionShape, header: bytes,
                   first_chunk: bytes = b"", total_body_length: int = 0,
                   expected_data: int = 0) -> bytes:
    """Payload for :attr:`MessageType.CMD`: a command's header and its
    first body chunk.

    Carries the shape and already-formed bytes. It does NOT carry an
    opcode, a block, or anything about what the command means: the gateway
    is not entitled to an opinion, and giving it one is how a relay starts
    having to keep up with firmware.

    ``expected_data`` is how many bytes come back after the status, which
    only the far end can know because nothing on the board's wire
    announces it.

    Use :func:`command_messages` rather than calling this directly; it
    handles the split.
    """
    if len(first_chunk) > BOARD_CHUNK_SIZE:
        raise PayloadTooLarge(
            f"a command body travels in chunks of at most {BOARD_CHUNK_SIZE} "
            f"bytes, the size the board itself uses. See the module note on "
            f"why the gateway must never need a larger buffer than that")
    if total_body_length < len(first_chunk):
        raise LinkProtocolError(
            "total body length is smaller than the first chunk")
    # Two shapes come back with bytes whose count nothing on the board's
    # wire announces, so the far end has to say. A probe read is one of
    # them: the board's own read sizes itself from probe objects a relay
    # never constructed, so without a count it would ask for nothing.
    _needs_length = (TransactionShape.CONFIG_WITH_DATA,
                     TransactionShape.PROBE_READ)

    if shape in _needs_length and expected_data <= 0:
        raise LinkProtocolError(
            f"{shape.name} returns a payload whose length the board's wire "
            f"does not announce, so a reader with no count either stops "
            f"early or eats the next command's response")
    if shape not in _needs_length and expected_data:
        raise LinkProtocolError(
            f"{shape.name} returns no data payload, so a length here would "
            f"make the gateway read bytes nobody queued")

    return (_CMD.pack(int(shape), len(header), total_body_length, expected_data)
            + header + first_chunk)


def decode_command(payload: bytes) -> Tuple[TransactionShape, bytes, bytes, int, int]:
    """Inverse of :func:`encode_command`.

    Returns ``(shape, header, first_chunk, total_body_length, expected_data)``.
    The receiver knows the command is complete once it has forwarded
    ``total_body_length`` body bytes.
    """
    if len(payload) < _CMD.size:
        raise LinkProtocolError("command payload is shorter than its header")

    shape_id, header_len, total_body, data_len = _CMD.unpack_from(payload)
    start = _CMD.size
    if len(payload) < start + header_len:
        raise LinkProtocolError(
            f"command payload declares an {header_len}-byte header and "
            f"carries {len(payload) - start}")

    try:
        shape = TransactionShape(shape_id)
    except ValueError as exc:
        raise LinkProtocolError(f"unknown transaction shape {shape_id}") from exc

    header = payload[start:start + header_len]
    first_chunk = payload[start + header_len:]
    if len(first_chunk) > BOARD_CHUNK_SIZE:
        raise PayloadTooLarge(
            f"first chunk is {len(first_chunk)} bytes, above the "
            f"{BOARD_CHUNK_SIZE} the board's wire uses")
    return shape, header, first_chunk, total_body, data_len


def encode_command_chunk(index: int, chunk: bytes) -> bytes:
    """Payload for :attr:`MessageType.CMD_CHUNK`: one more body chunk.

    Indexed rather than merely ordered. The transports below this are
    ordered, but a relay that silently forwarded a chunk out of place
    would hand the board a body whose checksum fails somewhere far from
    the cause, and an index makes that a refusal instead.
    """
    if len(chunk) > BOARD_CHUNK_SIZE:
        raise PayloadTooLarge(
            f"{len(chunk)} bytes exceeds the {BOARD_CHUNK_SIZE}-byte chunk "
            f"the board's wire uses")
    return _CHUNK.pack(index & 0xFFFF) + chunk


def decode_command_chunk(payload: bytes) -> Tuple[int, bytes]:
    """Inverse of :func:`encode_command_chunk`."""
    if len(payload) < _CHUNK.size:
        raise LinkProtocolError("chunk payload carries no index")
    index = _CHUNK.unpack_from(payload)[0]
    chunk = payload[_CHUNK.size:]
    if len(chunk) > BOARD_CHUNK_SIZE:
        raise PayloadTooLarge(
            f"{len(chunk)} bytes exceeds the {BOARD_CHUNK_SIZE}-byte chunk "
            f"the board's wire uses")
    return index, chunk


def command_messages(shape: TransactionShape, header: bytes, body: bytes = b"",
                     expected_data: int = 0, seq: int = 0) -> List[LinkFrame]:
    """Split one board command into the frames that carry it.

    A small command is a single frame, which is the overwhelming majority
    of them: a design is hundreds of commands and most bodies are a few
    dozen bytes. Making every one of those a three-message handshake would
    triple the round trips over a link where a round trip is the expensive
    part.

    A large one -- an inline waveform table is the real case -- becomes a
    first frame plus chunk frames, so the receiver still never holds more
    than one chunk.
    """
    frames = [LinkFrame(
        type=MessageType.CMD,
        payload=encode_command(shape, header, body[:BOARD_CHUNK_SIZE],
                               len(body), expected_data),
        seq=seq,
    )]
    index = 1
    for start in range(BOARD_CHUNK_SIZE, len(body), BOARD_CHUNK_SIZE):
        frames.append(LinkFrame(
            type=MessageType.CMD_CHUNK,
            payload=encode_command_chunk(index, body[start:start + BOARD_CHUNK_SIZE]),
            seq=seq,
        ))
        index += 1
    return frames


#: outcome, reserved, status_len, data_len.
#:
#: Both lengths travel explicitly. An earlier version assumed a status
#: frame was always present and always 7 bytes, which is true of a config
#: command and false of a probe read -- that one answers with a payload
#: and no status at all, so a fixed-size assumption ate the first 7 bytes
#: of the samples and returned the rest.
_RESULT = struct.Struct("<BBHI")


class CommandOutcome(IntEnum):
    """What became of a relayed command, as distinct from what the board
    thought of it.

    The board's own status byte travels alongside untouched. These say
    whether the conversation happened at all, which is the gateway's
    business; judging an error status is the far end's, because it is the
    one that knows what it asked for.
    """

    #: The board answered. Its status may still be an error.
    ANSWERED = 0
    #: The board never answered within the response deadline.
    NO_ANSWER = 1
    #: Refused before anything reached the wire.
    REFUSED = 2
    #: The link died mid-command; the remainder was flushed so the board's
    #: receive state machine could finish. See the no-inter-frame-timeout
    #: note in the module docstring.
    ABANDONED = 3


def encode_command_result(outcome: "CommandOutcome", status: bytes = b"",
                          data: bytes = b"") -> bytes:
    """Payload for :attr:`MessageType.CMD_RESULT`.

    A status frame, a data payload, either or neither: a config command
    answers with a status, a probe read answers with samples and no status
    at all, and a refusal answers with nothing. Both lengths are stated so
    the reader never has to infer which case it is holding.
    """
    return (_RESULT.pack(int(outcome), 0, len(status), len(data))
            + status + data)


def decode_command_result(payload: bytes) -> Tuple["CommandOutcome", bytes, bytes]:
    """Inverse of :func:`encode_command_result`."""
    if len(payload) < _RESULT.size:
        raise LinkProtocolError("result payload is shorter than its header")

    outcome_id, _reserved, status_len, data_len = _RESULT.unpack_from(payload)
    try:
        outcome = CommandOutcome(outcome_id)
    except ValueError as exc:
        raise LinkProtocolError(f"unknown outcome {outcome_id}") from exc

    start = _RESULT.size
    if len(payload) < start + status_len + data_len:
        raise LinkProtocolError(
            f"result declares {status_len + data_len} bytes and carries "
            f"{len(payload) - start}")

    status = payload[start:start + status_len]
    data = payload[start + status_len:start + status_len + data_len]
    return outcome, status, data


#: probe_count, samples_per_batch, vector_count, interval_ms,
#: scalar_bytes, vector_bytes.
_SUB = struct.Struct("<HHHHII")


def encode_subscribe(probe_count: int, samples_per_batch: int,
                     scalar_bytes: int, vector_count: int = 0,
                     vector_bytes: int = 0, interval_ms: int = 20) -> bytes:
    """Payload for :attr:`MessageType.SUBSCRIBE`: what to poll, how often.

    Every field here exists because the board's wire does not announce
    it. A probe read is an opcode and then a payload, with no length, no
    count and no boundary anywhere in the exchange, so a gateway that was
    not told these numbers would have nothing to ask for. The board's own
    read sizes itself from probe objects the *program* constructed, and a
    relay constructs none.

    ``samples_per_batch`` is carried rather than derived because the
    reader deinterleaves with it: the payload is probe-major, so getting
    it wrong does not fail, it silently puts every probe's samples under
    the next probe's name.
    """
    if scalar_bytes <= 0 and vector_bytes <= 0:
        raise LinkProtocolError(
            "a subscription that asks for no bytes would poll the board "
            "forever and return nothing, because a probe read carries no "
            "length of its own")
    if interval_ms <= 0:
        raise LinkProtocolError(
            "a poll interval of zero is a busy loop on the board's wire, "
            "which starves the commands sharing it")
    return _SUB.pack(probe_count & 0xFFFF, samples_per_batch & 0xFFFF,
                     vector_count & 0xFFFF, interval_ms & 0xFFFF,
                     scalar_bytes & 0xFFFFFFFF, vector_bytes & 0xFFFFFFFF)


def decode_subscribe(payload: bytes) -> Tuple[int, int, int, int, int, int]:
    """Inverse of :func:`encode_subscribe`.

    Returns ``(probe_count, samples_per_batch, scalar_bytes, vector_count,
    vector_bytes, interval_ms)``, in the order a caller reads them rather
    than the order they are packed.
    """
    if len(payload) < _SUB.size:
        raise LinkProtocolError("subscribe payload is shorter than its header")
    (probes, samples, vectors, interval_ms,
     scalar_bytes, vector_bytes) = _SUB.unpack_from(payload)
    if scalar_bytes <= 0 and vector_bytes <= 0:
        raise LinkProtocolError(
            "a subscription that asks for no bytes would poll the board "
            "forever and return nothing")
    if interval_ms <= 0:
        raise LinkProtocolError("a poll interval of zero is a busy loop")
    return (probes, samples, scalar_bytes, vectors, vector_bytes, interval_ms)


_TELEM = struct.Struct("<IQHH")    # batch_seq, timestamp_us, probes, samples


def encode_telemetry(batch_seq: int, timestamp_us: int, probe_count: int,
                     samples_per_probe: int, samples: bytes) -> bytes:
    """Payload for :attr:`MessageType.TELEMETRY`.

    ``batch_seq`` is the whole reason this is not raw samples. The board's
    SPI monitoring carries no sequence, no checksum and no gap marker, so
    a host that misses a batch cannot tell. The gateway stamps one, and a
    gap in it is the only honest signal that something was dropped --
    which the Monitor already knows how to display.
    """
    return _TELEM.pack(batch_seq & 0xFFFFFFFF, timestamp_us & 0xFFFFFFFFFFFFFFFF,
                       probe_count, samples_per_probe) + samples


#: Payload for :attr:`MessageType.WELCOME`: one unsigned 32-bit count of
#: bytes, little-endian like everything else on this wire.
_WELCOME = struct.Struct("<I")


def encode_welcome(max_batch_bytes: int) -> bytes:
    """What a gateway says it can carry, announced as a session opens."""
    return _WELCOME.pack(int(max_batch_bytes) & 0xFFFFFFFF)


def decode_welcome(payload: bytes) -> int:
    """The largest telemetry batch the gateway will accept, in bytes.

    AT LEAST four bytes, not exactly four. A later gateway may add a
    field, and a decoder that demanded the exact length would read that
    as a damaged frame and discard a welcome it understands all of.
    """
    if len(payload) < _WELCOME.size:
        raise LinkProtocolError("welcome payload is shorter than its header")
    return int(_WELCOME.unpack_from(payload)[0])


def decode_telemetry(payload: bytes) -> Tuple[int, int, int, int, bytes]:
    """Inverse of :func:`encode_telemetry`."""
    if len(payload) < _TELEM.size:
        raise LinkProtocolError("telemetry payload is shorter than its header")

    batch_seq, timestamp_us, probes, samples = _TELEM.unpack_from(payload)
    return batch_seq, timestamp_us, probes, samples, payload[_TELEM.size:]
