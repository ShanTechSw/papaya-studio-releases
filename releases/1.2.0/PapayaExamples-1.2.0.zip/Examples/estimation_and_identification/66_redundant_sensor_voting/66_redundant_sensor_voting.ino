/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-11 03:53:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe voted_estimate;
probe chi2_flag;
probe chi_square_test_tap;
probe fault_flag_1_tap;
probe fault_flag_2_tap;
probe fault_flag_3_tap;

input flag_hi_1;
input dev_thr_1;
input flag_hi_2;
input dev_thr_2;
input flag_hi_3;
input dev_thr_3;
input sensor_sigma;
input const_;
input const__2;
input const__3;
input fault_flag_1_2;
input fault_flag_2_2;
input fault_flag_3_2;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  flag_hi_1 = input("rail_hi_1", 1.0f);
  dev_thr_1 = input("dev_thr_1", 0.35f);
  flag_hi_2 = input("rail_hi_2", 1.0f);
  dev_thr_2 = input("dev_thr_2", 0.35f);
  flag_hi_3 = input("rail_hi_3", 1.0f);
  dev_thr_3 = input("dev_thr_3", 0.35f);
  sensor_sigma = input("sensor_sigma", 0.1f);
  fault_flag_1_2 = input("fault_flag_1", 0.0f);
  fault_flag_2_2 = input("fault_flag_2", 0.0f);
  fault_flag_3_2 = input("fault_flag_3", 0.0f);
  signalSource SIM__true_measurand = signalSource::sine(0.5f, 0.0f);
  signalSource SIM__stuck_fault = signalSource::step(1.0f, 0.0f, 0.7f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  const__3 = input("const", 0.0f);
  noise SIM__noise_1 = noise(-0.5, 0.5, uniform);
  noise SIM__noise_2 = noise(-0.5, 0.5, uniform);
  noise SIM__noise_3 = noise(-0.5, 0.5, uniform);
  expander fan_3 = expander(3);
  node sensor_1 = node("[1.0 1.0]", "[1.0]", Sum);
  node sensor_2 = node("[1.0 1.0]", "[1.0]", Sum);
  node sensor_3 = node("[1.0 1.0]", "[1.0]", Sum);
  node faulted_sensor_3 = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_2 = expander(2);
  expander fan_2_2 = expander(2);
  expander fan_3_2 = expander(3);
  node voted_average = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  gain _1_3_mean = gain(0.3333333333333333);
  expander fan_4 = expander(4);
  node deviation_1 = node("[1.0 -1.0]", "[1.0]", Sum);
  node deviation_2 = node("[1.0 -1.0]", "[1.0]", Sum);
  node deviation_3 = node("[1.0 -1.0]", "[1.0]", Sum);
  node fault_residual = node("[1.0 -1.0]", "[1.0]", Sum);
  absVal abs_dev_1 = absVal();
  absVal abs_dev_2 = absVal();
  absVal abs_dev_3 = absVal();
  innovationChi2 chi_square_test = innovationChi2(1, 11.34);
  comp fault_flag_1 = comp();
  comp fault_flag_2 = comp();
  comp fault_flag_3 = comp();
  voted_estimate = probe("voted_estimate");
  chi2_flag = probe("chi2_outlier");
  chi_square_test_tap = probe("chi-square_0");
  fault_flag_1_tap = probe("fault flag 1_o0");
  fault_flag_2_tap = probe("fault flag 2_o0");
  fault_flag_3_tap = probe("fault flag 3_o0");

  /* Connect Blocks */
  flag_hi_1 > fault_flag_1.in(0);
  dev_thr_1 > fault_flag_1.in(3);
  flag_hi_2 > fault_flag_2.in(0);
  dev_thr_2 > fault_flag_2.in(3);
  flag_hi_3 > fault_flag_3.in(0);
  dev_thr_3 > fault_flag_3.in(3);
  sensor_sigma > chi_square_test.in(1);
  fault_flag_1_2 > fault_flag_1.in(1);
  fault_flag_2_2 > fault_flag_2.in(1);
  fault_flag_3_2 > fault_flag_3.in(1);
  SIM__true_measurand > fan_3;
  SIM__stuck_fault > faulted_sensor_3.in(1);
  const_ > SIM__noise_1;
  const__2 > SIM__noise_2;
  const__3 > SIM__noise_3;
  SIM__noise_1 > sensor_1.in(1);
  SIM__noise_2 > sensor_2.in(1);
  SIM__noise_3 > sensor_3.in(1);
  fan_3.out(0) > sensor_1.in(0);
  fan_3.out(1) > sensor_2.in(0);
  fan_3.out(2) > sensor_3.in(0);
  sensor_1 > fan_2;
  sensor_2 > fan_2_2;
  sensor_3 > faulted_sensor_3.in(0);
  faulted_sensor_3 > fan_3_2;
  fan_2.out(0) > voted_average.in(0);
  fan_2.out(1) > deviation_1.in(0);
  fan_2_2.out(0) > voted_average.in(1);
  fan_2_2.out(1) > deviation_2.in(0);
  fan_3_2.out(0) > voted_average.in(2);
  fan_3_2.out(1) > deviation_3.in(0);
  fan_3_2.out(2) > fault_residual.in(0);
  voted_average > _1_3_mean;
  _1_3_mean > fan_4;
  _1_3_mean > voted_estimate;
  fan_4.out(0) > deviation_1.in(1);
  fan_4.out(1) > deviation_2.in(1);
  fan_4.out(2) > deviation_3.in(1);
  fan_4.out(3) > fault_residual.in(1);
  deviation_1 > abs_dev_1;
  deviation_2 > abs_dev_2;
  deviation_3 > abs_dev_3;
  fault_residual > chi_square_test.in(0);
  abs_dev_1 > fault_flag_1.in(2);
  abs_dev_2 > fault_flag_2.in(2);
  abs_dev_3 > fault_flag_3.in(2);
  chi_square_test.out(1) > chi2_flag;
  chi_square_test.out(0) > chi_square_test_tap;
  fault_flag_1 > fault_flag_1_tap;
  fault_flag_2 > fault_flag_2_tap;
  fault_flag_3 > fault_flag_3_tap;

  /* Enable Remote Input Control */
  flag_hi_1.enableRemote();
  dev_thr_1.enableRemote();
  flag_hi_2.enableRemote();
  dev_thr_2.enableRemote();
  flag_hi_3.enableRemote();
  dev_thr_3.enableRemote();
  sensor_sigma.enableRemote();
  fault_flag_1_2.enableRemote();
  fault_flag_2_2.enableRemote();
  fault_flag_3_2.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    voted_estimate.show();
    chi2_flag.show();
    chi_square_test_tap.show();
    fault_flag_1_tap.show();
    fault_flag_2_tap.show();
    fault_flag_3_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}