/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe eeg_cplx;
probe hrv;
probe gesture;
probe unused_signals;

input beat_rail_hi;
input beat_thr;
input qrs_beat_detect;

/* Global Array Declarations */
uint16_t Gesture_classifier_feat_idx[] = {0, 65535, 65535};
float Gesture_classifier_thresh[] = {0.011f, 0.0f, 0.0f};
uint16_t Gesture_classifier_left[] = {1, 65535, 65535};
uint16_t Gesture_classifier_right[] = {2, 65535, 65535};
float Gesture_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  beat_rail_hi = input("rail_hi", 1.0f);
  beat_thr = input("beat_thr", 0.3f);
  qrs_beat_detect = input("qrs_beat_detect", 0.0f);
  signalSource SIM__ECG_front_end = signalSource::sine(1.2f, 0.0f);
  signalSource SIM__EMG_front_end = signalSource::multisine(100.0f, 50.0f, 8, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  signalSource SIM__EEG_front_end = signalSource::multisine(2.0f, 5.0f, 10, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  signalSource SIM__contraction = signalSource::square(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 0.5f);
  ecgBlRemove Baseline_remove = ecgBlRemove(128);
  expander fan_2_3 = expander(2);
  node gated_EMG = node("[1.0 1.0]", "[1.0]", Mul);
  fft EEG_FFT = fft(256);
  hjorth Hjorth_params = hjorth(128);
  expander fan_2 = expander(2);
  expander fan_2_2 = expander(2);
  period RR_interval = period(1.5, -1.5, 0.05);
  comp QRS_beat_detect = comp();
  emgEnvelope EMG_envelope = emgEnvelope(4.0);
  emgHudgins EMG_Hudgins = emgHudgins(256, 0.02);
  fftMagResolver EEG_magnitude = fftMagResolver(EEG_FFT);
  hrvTime HRV_time = hrvTime(64);
  decisionTree Gesture_classifier = decisionTree(1, 1, 3, Gesture_classifier_feat_idx, Gesture_classifier_thresh, Gesture_classifier_left, Gesture_classifier_right, Gesture_classifier_leaf_val);
  eegBandpower EEG_bandpower = eegBandpower(EEG_magnitude);
  merger unused_bus = merger(15);
  eeg_cplx = probe("EEG_complexity");
  hrv = probe("HRV_metrics");
  gesture = probe("gesture");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  beat_rail_hi > QRS_beat_detect.in(0);
  beat_thr > QRS_beat_detect.in(3);
  qrs_beat_detect > QRS_beat_detect.in(1);
  SIM__ECG_front_end > Baseline_remove;
  SIM__EMG_front_end > gated_EMG.in(0);
  SIM__EEG_front_end > fan_2_3;
  SIM__contraction > gated_EMG.in(1);
  Baseline_remove > fan_2;
  fan_2_3.out(0) > EEG_FFT;
  fan_2_3.out(1) > Hjorth_params;
  gated_EMG > fan_2_2;
  EEG_FFT > EEG_magnitude;
  Hjorth_params.out(0) > unused_bus.in(13);
  Hjorth_params.out(1) > unused_bus.in(12);
  Hjorth_params.out(2) > eeg_cplx;
  fan_2.out(0) > RR_interval;
  fan_2.out(1) > QRS_beat_detect.in(2);
  fan_2_2.out(0) > EMG_envelope;
  fan_2_2.out(1) > EMG_Hudgins;
  RR_interval > HRV_time.in(0);
  QRS_beat_detect > HRV_time.in(1);
  EMG_envelope > Gesture_classifier;
  EMG_Hudgins.out(0) > unused_bus.in(14);
  EMG_Hudgins.out(1) > unused_bus.in(4);
  EMG_Hudgins.out(2) > unused_bus.in(5);
  EMG_Hudgins.out(3) > unused_bus.in(6);
  EEG_magnitude > EEG_bandpower;
  HRV_time.out(1) > unused_bus.in(0);
  HRV_time.out(2) > unused_bus.in(1);
  HRV_time.out(3) > unused_bus.in(2);
  HRV_time.out(4) > unused_bus.in(3);
  HRV_time.out(0) > hrv;
  Gesture_classifier > gesture;
  EEG_bandpower.out(0) > unused_bus.in(7);
  EEG_bandpower.out(1) > unused_bus.in(8);
  EEG_bandpower.out(2) > unused_bus.in(9);
  EEG_bandpower.out(3) > unused_bus.in(10);
  EEG_bandpower.out(4) > unused_bus.in(11);
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  beat_rail_hi.enableRemote();
  beat_thr.enableRemote();
  qrs_beat_detect.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    eeg_cplx.show();
    hrv.show();
    gesture.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}