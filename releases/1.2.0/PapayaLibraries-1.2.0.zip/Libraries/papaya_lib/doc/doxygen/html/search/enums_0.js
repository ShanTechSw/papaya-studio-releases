var searchData=
[
  ['bridgecommand_0',['BridgeCommand',['../class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6cae',1,'PapayaUsbBridgeBackend']]],
  ['bridgestatus_1',['BridgeStatus',['../class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20',1,'PapayaUsbBridgeBackend']]]
];
