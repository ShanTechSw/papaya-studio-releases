"""Cart pendulum: the board balances it, this script runs the lab.

Run this beside example 51. It starts the design, watches the nine probes,
names what the rig is doing, and then drives the remote inputs to perform
three measurements that a cart pendulum is worth building for.

    python main.py

WARNING: this program MOVES A REAL CART if a rig is attached. Clear the rail,
know where the power switch is, and read MOVING TO THE RIG in the design's
Project Description before the first run. With plant_in_loop at its default
+1 nothing physical moves: the loop closes on the plant model inside the
design and the motor is still driven, so the cart will still travel unless
the rig is disconnected or the drive is off.

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  phase           hanging, pumping, arriving, catching, balanced, or lost.
                  Read from the pole's normalised energy, the mode gate and
                  the upright distance together, because no one of them says
                  it alone: energy near zero means the pole has the right
                  ENERGY, not that it is anywhere near the top.

  swing-up        did it arrive, how long did it take, how much rail did it
                  spend, and did the drive ever run out of duty. A swing-up
                  that works but uses 90 per cent of the rail is one warm
                  bearing away from not working.

  catch envelope  the largest angle the balance law recovers from, found by
                  bisection rather than assumed. Compare it with acc_max
                  divided by the angle gain, which is where the law stops
                  being linear. The measured envelope is normally the
                  larger of the two, because saturating briefly in the
                  right direction is not the same as failing.

  cart step       the wrong-way motion at the start of a cart move. The
                  closed loop from cart_ref to cart position has a zero at
                  +4.9523 rad/s, in the right half plane and sitting exactly
                  on the pole's own unstable rate. No controller that
                  stabilises an unstable pole can avoid that: to send the
                  cart right you must first tip the pole right, and that
                  means going left. On the design's own plant model it is
                  0.65 per cent of the step at every step size.

Everything the script decides is in DIAGNOSE and the three experiment
functions. Nothing there talks to the board, so a class can change a
threshold and re-run without touching the transport code below it.
"""
from __future__ import annotations

import statistics
import time

# ---------------------------------------------------------------------------
# Configuration. These describe the RIG, not the board.
# ---------------------------------------------------------------------------

# Which world the lab runs in. "model" drives plant_in_loop to +1 and closes
# the loop on the plant model inside the design, which is what to use on a
# desk. "rig" drives it to -1 and closes it on the potentiometer and the
# motor. Experiment 2 only runs on the model, because it displaces the pole
# through start_angle and a real pole has to be displaced by hand.
RUN_ON = "model"

RAIL_HALF_M = 0.40        # usable half rail, metres
DUTY_HEADROOM = 0.85      # above this the amplifier is effectively out
BALANCED_DISTANCE = 0.05  # upright distance inside which the pole is balanced
QUIET_CART = 0.05         # m/s, below this the cart counts as stopped
IDLE_ACCEL = 0.5          # m/s^2, below this the drive is doing nothing
ARRIVING_DISTANCE = 0.45  # upright distance below which the catch is close
NEAR_TOP = 0.50           # never below this means it never reached the top
HANGING_ENERGY = -1.5     # normalised energy below which the pole is hanging

# "Settled" here is the SAME test the design's Project Description quotes,
# so the two can be compared: |angle| under 0.05 rad and staying there for
# three seconds. A tighter test measures a different thing and the numbers
# stop being comparable, which is how two correct measurements disagree.
SETTLE_ANGLE = 0.05
SETTLE_HOLD = 3.0

# Measured on the design's own plant model. On a rig these move.
EXPECT_SETTLE_S = 5.56
EXPECT_CART_PEAK_M = 0.213

# The balance law's gains, from the design. Only used to report where the
# law stops being linear, so a measured envelope has something to beat.
ANGLE_GAIN = 72.1338
ACC_MAX = 12.0

WATCH_SECONDS = 14.0
SAMPLE_PERIOD = 0.02


# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def phase_of(row):
    """Name what the rig is doing from one reading.

    Each test needs more than one channel. A low pole rate on its own does
    not mean hanging: it also happens at the top of every pump swing, and
    naming that "hanging" makes the phase report flicker several times a
    second. What separates them is whether anything is DRIVING: at the ends
    of a pump swing the command is at its clamp and the cart is moving.
    """
    rate = abs(row["pole_rate"])
    balancing = row["mode"] > 0
    quiet_cart = abs(row["cart_rate"]) < QUIET_CART
    idle = abs(row["accel"]) < IDLE_ACCEL

    if abs(row["cart"]) > 0.95 * RAIL_HALF_M:
        return "rail", "the cart is at the end stop"
    if balancing and row["distance"] < BALANCED_DISTANCE and quiet_cart:
        return "balanced", "upright and quiet"
    if balancing:
        return "catching", "the balance law has it and is still working"
    if row["energy"] < HANGING_ENERGY and rate < 0.2 and quiet_cart and idle:
        return "hanging", "at rest at the bottom, waiting to be pumped"
    if row["distance"] < ARRIVING_DISTANCE:
        return "arriving", "near the top but not yet inside the catch window"
    return "pumping", "the energy law is adding energy"


def diagnose(trace):
    """Everything worth saying about one complete swing-up attempt."""
    notes = []
    cart = [abs(r["cart"]) for r in trace]
    duty = [abs(r["duty"]) for r in trace]
    energy = [r["energy"] for r in trace]
    mode = [r["mode"] for r in trace]

    caught = next((r["t"] for r in trace if r["mode"] > 0), None)
    settled = _first_sustained(trace, SETTLE_ANGLE, SETTLE_HOLD)
    flips = sum(1 for a, b in zip(mode, mode[1:]) if (a > 0) != (b > 0))
    closest = min(r["distance"] for r in trace)

    if settled is None:
        notes.append("NOT BALANCED inside the watch window.")
        if closest > NEAR_TOP:
            notes.append(
                f"the pole never came closer to upright than "
                f"{closest:.3f} on the upright-distance probe, so this is "
                f"not a catch problem at all: it never arrived. If the pole "
                f"is spinning through the top rather than stalling below it, "
                f"energy_target is above 1.0 and the pump is aiming past the "
                f"top. If it is stalling, swing_acc is too small or the "
                f"kinetic term gain (l_eff/2g) does not match this pole")
        elif max(cart) > 0.95 * RAIL_HALF_M:
            notes.append(
                "the cart reached the end stop, so the swing-up ran out of "
                "rail before it ran out of energy. Lower swing_acc first; "
                "raising the centring gain on velocity usually makes this "
                "worse, because the pump works by moving the cart")
        elif max(energy) < -0.15:
            notes.append(
                f"the pole never got its energy above {max(energy):+.3f}, so "
                f"it never reached the top at all. Either swing_acc is too "
                f"small for this pole, or l_eff is wrong: the kinetic term "
                f"gain is l_eff/2g and it is what the energy is measured in")
        elif flips > 3:
            notes.append(
                f"the mode changed {flips} times, which is chatter at the "
                f"handover rather than a catch. Widen the gap between "
                f"catch_at and leave_at")
        else:
            notes.append(
                "the pole reached the top with about the right energy but "
                "was not caught. catch_at is probably too small: the pole "
                "arrives quietly but never quietly enough")
    else:
        notes.append(f"balanced at {settled:.2f} s"
                     + (f", caught at {caught:.2f} s" if caught else ""))
        if caught and settled - caught > 2.0:
            notes.append(
                f"the catch took {settled - caught:.2f} s to settle, which "
                f"is a long time for a loop whose fastest pole is 7.6 rad/s. "
                f"The catch was probably taken far out and saturated")

    peak = max(cart)
    notes.append(
        f"peak cart travel {peak:.3f} m, {100 * peak / RAIL_HALF_M:.0f} per "
        f"cent of the half rail")
    if peak > 0.85 * RAIL_HALF_M:
        notes.append(
            "that is too close to the end stop to be repeatable. Reduce "
            "swing_acc: it costs a second or two and buys the margin back")

    peak_duty = max(duty)
    notes.append(f"peak duty {peak_duty:.3f}")
    if peak_duty > DUTY_HEADROOM:
        notes.append(
            "the amplifier ran out of duty. Anything the controller asked "
            "for above that never happened, so the gains are not what was "
            "actually applied")

    tail = [r for r in trace if r["t"] > trace[-1]["t"] - 2.0]
    if settled is not None and len(tail) > 5:
        rms = statistics.pstdev([r["pole_angle"] for r in tail])
        drift = tail[-1]["cart"] - tail[0]["cart"]
        notes.append(
            f"holding to {rms * 1000:.2f} mrad rms with the cart moving "
            f"{drift * 1000:+.1f} mm over the last two seconds")
        if abs(drift) > 0.01:
            notes.append(
                "a cart that keeps walking while the pole stays up is the "
                "servo integral chasing something real, usually rail "
                "friction or a potentiometer zero that is slightly off")
    return notes


def envelope_verdict(recovered, failed):
    """What the measured catch envelope means."""
    linear = ACC_MAX / ANGLE_GAIN
    notes = [f"largest recovered release: {recovered:.4f} rad "
             f"({recovered * 57.2958:.2f} degrees)",
             f"smallest failed release:  {failed:.4f} rad "
             f"({failed * 57.2958:.2f} degrees)",
             f"the law stops being linear at acc_max / angle gain = "
             f"{linear:.4f} rad, so the envelope is "
             f"{recovered / linear:.2f} times the linear limit"]
    if recovered < linear:
        notes.append(
            "an envelope SMALLER than the linear limit means something other "
            "than saturation is ending it: look at the rate channel, because "
            "a noisy derivative costs envelope before the actuator does")
    else:
        notes.append(
            "an envelope larger than the linear limit is normal and is why "
            "catch_at can sit where it does: saturating briefly in the right "
            "direction still removes energy")
    return notes


def step_verdict(step, undershoot, settle_s, peak_angle):
    notes = [f"commanded {step * 1000:+.0f} mm",
             f"initial motion the WRONG way: {undershoot * 1000:.2f} mm, "
             f"{100 * abs(undershoot / step):.1f} per cent of the step",
             f"pole disturbed to {peak_angle:.4f} rad "
             f"({peak_angle * 57.2958:.2f} degrees) getting there"]
    if settle_s is None:
        notes.append("did not settle inside the window")
    else:
        notes.append(f"settled to 1 mm in {settle_s:.2f} s")
    if abs(undershoot) < 1e-4:
        notes.append(
            "no measurable undershoot. That is suspicious rather than good: "
            "the closed loop has a right-half-plane zero at +4.9523 rad/s "
            "and the cart CANNOT start toward a new position without first "
            "going the other way. Sample faster, or the step was too small "
            "to see against the noise")
    else:
        notes.append(
            "that undershoot is the closed loop's right-half-plane zero, "
            "which sits on the pole's unstable rate because an unstable "
            "pole cannot be cancelled. It is not a tuning fault and no "
            "retune removes it")
    return notes


def _first_sustained(trace, tol, hold_s):
    """First time after which |angle| stays under tol for hold_s seconds."""
    for i, row in enumerate(trace):
        if abs(row["pole_angle"]) >= tol:
            continue
        end = row["t"] + hold_s
        if trace[-1]["t"] < end:
            return None
        if all(abs(r["pole_angle"]) < tol
               for r in trace[i:] if r["t"] <= end):
            return row["t"]
    return None


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

PROBES = (("pole_angle", "pole_angle"), ("pole_rate", "pole_rate_2"),
          ("cart", "cart_position"), ("cart_rate", "cart_velocity"),
          ("energy", "pole_energy"), ("distance", "upright_distanc"),
          ("mode", "control_mode"), ("accel", "accel_cmd"),
          ("duty", "drive_duty"))


def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 51_inverted_pendulum_swingup.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d, t0):
    """One reading of all nine probes, from a single transfer."""
    if not d.papaya0.readProbesLive():
        return None
    row = {name: getattr(d, var).getVal() for name, var in PROBES}
    if any(v is None for v in row.values()):
        return None
    row["t"] = time.perf_counter() - t0
    return row


def first_row(d, timeout=2.0):
    """One reading, waited for rather than assumed.

    read_row returns None whenever no batch arrives inside its window,
    and a single missed batch is normal. Every loop below already treats
    None as "read again"; the one place that wanted a single value did
    not, so one missed batch ended the run with a type error after two
    experiments had already finished. The wait is bounded so a board that
    has genuinely stopped answering is reported rather than spun on.
    """
    deadline = time.perf_counter() + timeout
    while time.perf_counter() < deadline:
        row = read_row(d, time.perf_counter())
        if row is not None:
            return row
    return None


def watch(d, seconds, t0=None):
    t0 = t0 if t0 is not None else time.perf_counter()
    trace, nxt = [], 0.0
    while True:
        row = read_row(d, t0)
        if row is None:
            continue
        if row["t"] > seconds:
            return trace
        if row["t"] >= nxt:
            trace.append(row)
            nxt = row["t"] + SAMPLE_PERIOD


def settle_at(d, angle_ref, timeout=8.0):
    """Wait until the pole is balanced and the cart has stopped."""
    t0 = time.perf_counter()
    while time.perf_counter() - t0 < timeout:
        row = read_row(d, t0)
        if (row and row["distance"] < BALANCED_DISTANCE
                and abs(row["cart_rate"]) < 0.02):
            return True
    return False


# ---------------------------------------------------------------------------
# The three experiments
# ---------------------------------------------------------------------------

def experiment_swingup(d):
    print("\n=== 1. swing-up and catch ===")
    print(f"  watching {WATCH_SECONDS:.0f} s from release\n")
    t0 = time.perf_counter()
    trace, last_phase, nxt = [], None, 0.0
    while True:
        row = read_row(d, t0)
        if row is None:
            continue
        if row["t"] > WATCH_SECONDS:
            break
        if row["t"] >= nxt:
            trace.append(row)
            nxt = row["t"] + SAMPLE_PERIOD
        name, why = phase_of(row)
        if name != last_phase:
            print(f"  {row['t']:6.2f} s  {name:9s} {why}")
            print(f"            angle {row['pole_angle']:+7.4f} rad  "
                  f"rate {row['pole_rate']:+7.3f}  energy "
                  f"{row['energy']:+7.4f}  cart {row['cart']:+7.4f} m")
            last_phase = name

    print("\n  verdict:")
    for note in diagnose(trace):
        print(f"    {note}")

    settled = _first_sustained(trace, SETTLE_ANGLE, SETTLE_HOLD)
    peak = max(abs(r["cart"]) for r in trace)
    if settled is not None:
        print(f"\n  against the design's own model "
              f"({EXPECT_SETTLE_S:.2f} s, {EXPECT_CART_PEAK_M:.3f} m):")
        print(f"    settle {settled:+.2f} s "
              f"({settled - EXPECT_SETTLE_S:+.2f} s), cart peak {peak:.3f} m "
              f"({peak - EXPECT_CART_PEAK_M:+.3f} m)")
    return trace


def experiment_envelope(d, on_model):
    print("\n=== 2. catch envelope ===")
    if not on_model:
        print("  skipped: this experiment displaces the pole through "
              "start_angle, which only exists for the plant model. On the "
              "rig, do it by hand and read the angle off the probe.")
        return
    print("  forcing the balance branch, then displacing the pole by "
          "bisection\n")
    d.papaya0.setInput(d.mode_swing, 1.0)      # both modes balance: no swing-up
    if not settle_at(d, 0.0):
        print("  the pole is not balanced to start from; aborting")
        d.papaya0.setInput(d.mode_swing, -1.0)
        return

    base = 0.0
    lo, hi = 0.02, 0.60                        # known good, known bad
    recovered, failed = lo, hi
    for _ in range(6):
        mid = 0.5 * (lo + hi)
        base += mid
        d.papaya0.setInput(d.start_angle, base)
        trace = watch(d, 4.0)
        ok = _first_sustained(trace, SETTLE_ANGLE, 1.0) is not None
        peak = max(abs(r["cart"]) for r in trace)
        print(f"    release {mid:.4f} rad ({mid * 57.2958:5.2f} deg)  "
              f"{'recovered' if ok else 'LOST     '}  "
              f"cart used {peak:.3f} m")
        if ok:
            recovered, lo = mid, mid
        else:
            failed, hi = mid, mid
            base -= mid                        # it fell; put the model back
            d.papaya0.setInput(d.start_angle, base)
            if not settle_at(d, 0.0, timeout=12.0):
                print("    could not recover between trials; stopping here")
                break

    print("\n  verdict:")
    for note in envelope_verdict(recovered, failed):
        print(f"    {note}")
    d.papaya0.setInput(d.mode_swing, -1.0)


def experiment_cart_step(d, step=0.10):
    print("\n=== 3. cart step, and the wrong-way start ===")
    if not settle_at(d, 0.0):
        print("  the pole is not balanced; skipping")
        return
    row = first_row(d)
    if row is None:
        print("  no probe data arrived; skipping")
        return
    start = row["cart"]
    d.papaya0.setInput(d.cart_ref, start + step)
    trace = watch(d, 10.0)
    d.papaya0.setInput(d.cart_ref, 0.0)

    moved = [r["cart"] - start for r in trace]
    early = [m for m, r in zip(moved, trace) if r["t"] < 0.6]
    undershoot = min(early) if step > 0 else max(early)
    peak_angle = max(abs(r["pole_angle"]) for r in trace)
    settle_s = None
    for i, (m, r) in enumerate(zip(moved, trace)):
        if all(abs(mm - step) < 0.001 for mm in moved[i:]):
            settle_s = r["t"]
            break

    print()
    for note in step_verdict(step, undershoot, settle_s, peak_angle):
        print(f"    {note}")


def main():
    try:
        d = load_design()
    except Exception as exc:                                   # noqa: BLE001
        print(f"ERROR: {exc}")
        import traceback
        traceback.print_exc()
        return 1

    if RUN_ON not in ("model", "rig"):
        raise SystemExit(f"RUN_ON must be 'model' or 'rig', not {RUN_ON!r}")
    on_model = RUN_ON == "model"
    d.papaya0.setInput(d.plant_in_loop, 1.0 if on_model else -1.0)
    print()
    print(f"running on the "
          f"{'plant model in the design' if on_model else 'RIG'} "
          f"(plant_in_loop = {'+1' if on_model else '-1'}).")
    if not on_model:
        print("THE CART WILL MOVE. Clear the rail before continuing.")

    row = None
    while row is None:
        row = read_row(d, time.perf_counter())
    print(f"connected. first reading: angle {row['pole_angle']:+.4f} rad, "
          f"cart {row['cart']:+.4f} m, mode "
          f"{'balance' if row['mode'] > 0 else 'swing-up'}")

    try:
        experiment_swingup(d)
        experiment_envelope(d, on_model)
        experiment_cart_step(d)
    finally:
        # leave the rig in the state the design ships with
        for name, value in (("cart_ref", 0.0), ("mode_swing", -1.0)):
            d.papaya0.setInput(getattr(d, name), value)
    print("\ndone. The design is back at its shipped input values.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
