from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Optional, Sequence, Union

import struct

from .constants import (
    PP_REAL_SIZE,
    PP_UINT8_SIZE,
    PP_UINT16_SIZE,
    PP_UINT32_SIZE,
    PP_PARAM_INFO_SIZE,
    PP_blockID_SIZE,
    PP_FIXED_SIZE,
    PP_MAX_VECTOR_PROBES_BYTES,
    PP_MAX_INPUTS_NUMBER,
    PP_MAX_PROBES_NUMBER,
    PP_INPUT_ID_BASE,
    PP_PROBE_ID_BASE,
)
from .context import CTX, CommandInfo
from .enums import (
    PP_C2dAlgo,
    PP_ComStatus,
    PP_DesignStatus,
    PP_FirWindowType,
    PP_FuncId,
    PP_FuncParamId,
    PP_FilterType,
    PP_HwId,
    PP_MonInterface,
    PP_MotorOutput,
    PP_EncoderOutput,
    PP_AnOutMode,
    PP_NoiseType,
    PP_NodeType,
    PP_SubFuncId,
    PP_ThresholdType,
    PP_Tune,
    PP_WaveForm,
    PP_WaveMode,
    PP_WaveMultisinePhase,
    PP_WaveShape,
    PP_WaveTrigPol,
    PP_WaveletType,
)
from .structs import (
    PP_adaptiveKF,
    PP_linearKF,
    PP_stateSpace,
    PP_compFilter,
    PP_SMO,
    PP_RLSParam,
    PP_RRLSParam,
    PP_PMSM_EKF,
    PP_AHRS_EKF,
    PP_BatterySOC_EKF,
    PP_Tilt_EKF,
    PP_LoadTorque_EKF,
    PP_Thermal_EKF,
    PP_BaroAlt_EKF,
    PP_RobotLoc_EKF,
    PP_SinTrack_EKF,
    PP_GridSync_EKF,
    PP_ACIM_EKF,
    PP_BatterySOH_EKF,
    PP_WMR_EKF,
    PP_GPSINS_EKF,
    PP_LMSConfig,
    PP_AdaptiveNotchConfig,
    PP_DOBConfig,
    PP_ESCConfig,
    PP_ADRCConfig,
    PP_MRACConfig,
    PP_MRACLyapunovConfig,
    PP_RepCtrlConfig,
    PP_STRConfig,
    PP_ILCConfig,
    PP_GainSchedulePIDConfig,
    PP_GainSchedulerConfig,
    PP_RelayAutoTuneConfig,
    PP_StepAutoTuneConfig,
    PP_STR_PID_Config,
    PP_MRAC_PID_Config,
    PP_ESC_PID_Config,
    PP_PerfMonPID_Config,
    PP_FuzzyPIDConfig,
    PP_anInCfg,
    PP_anOutCfg,
    PP_motorBlockCfg,
    PP_motorCfg,
    PP_encoderBlockCfg,
    PP_encoderCfg,
    PP_pwmInCfg,
    PP_pwmOutCfg,
)

# -----------------------------------------------------------------------------
# Helper mappings (ported from PAPAYA.cpp)
# -----------------------------------------------------------------------------

def _get_butter_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewButterLow
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewButterHigh
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewButterBand
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewButterStop
    return PP_SubFuncId.NoSubFuncId


def _get_butter_bq_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewBiquadButterLow
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewBiquadButterHigh
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewBiquadButterBand
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewBiquadButterStop
    return PP_SubFuncId.NoSubFuncId


def _get_cheby1_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewChebyshev1Low
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewChebyshev1High
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewChebyshev1Band
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewChebyshev1Stop
    return PP_SubFuncId.NoSubFuncId


def _get_cheby1_bq_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewBiquadCheby1Low
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewBiquadCheby1High
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewBiquadCheby1Band
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewBiquadCheby1Stop
    return PP_SubFuncId.NoSubFuncId


def _get_cheby2_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewChebyshev2Low
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewChebyshev2High
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewChebyshev2Band
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewChebyshev2Stop
    return PP_SubFuncId.NoSubFuncId


def _get_cheby2_bq_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewBiquadCheby2Low
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewBiquadCheby2High
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewBiquadCheby2Band
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewBiquadCheby2Stop
    return PP_SubFuncId.NoSubFuncId


def _get_ellip_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewEllipLow
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewEllipHigh
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewEllipBand
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewEllipStop
    return PP_SubFuncId.NoSubFuncId


def _get_ellip_bq_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewBiquadEllipLow
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewBiquadEllipHigh
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewBiquadEllipBand
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewBiquadEllipStop
    return PP_SubFuncId.NoSubFuncId


def _get_fir_subfunc(ftype: PP_FilterType) -> PP_SubFuncId:
    if ftype == PP_FilterType.passLow:
        return PP_SubFuncId.NewFirLow
    if ftype == PP_FilterType.passHigh:
        return PP_SubFuncId.NewFirHigh
    if ftype == PP_FilterType.passBand:
        return PP_SubFuncId.NewFirBand
    if ftype == PP_FilterType.stopBand:
        return PP_SubFuncId.NewFirStop
    return PP_SubFuncId.NoSubFuncId


def _validate_designed_fir_length(n: int) -> int:
    n = int(n)
    if n < 3:
        raise ValueError("Designed FIR length N must be >= 3.")
    if (n % 2) == 0:
        raise ValueError("Designed FIR length N must be odd. Even lengths are not accepted by the STM32 FIR designer.")
    return n


def _validate_custom_fir_taps(coeff: Sequence[float], taps: int) -> int:
    taps = int(taps)
    if taps < 1:
        raise ValueError("Custom FIR taps must be >= 1.")
    if len(coeff) != taps:
        raise ValueError(f"Custom FIR taps={taps} does not match coefficient count={len(coeff)}.")
    return taps


def _is_pwm_period(hw: PP_HwId) -> bool:
    return PP_HwId.FI1_PERIOD <= hw <= PP_HwId.FI5_PERIOD


def _is_pwm_pulse(hw: PP_HwId) -> bool:
    return PP_HwId.FI1_PULSE <= hw <= PP_HwId.FI5_PULSE


def _is_pwm_delay(hw: PP_HwId) -> bool:
    return PP_HwId.FI1_DELAY <= hw <= PP_HwId.FI5_DELAY


def _outputs_per_hw_input(hw: PP_HwId) -> int:
    if _is_pwm_period(hw):
        return 1
    if _is_pwm_pulse(hw) or _is_pwm_delay(hw):
        return 2
    if hw in (PP_HwId.IMU_ACC, PP_HwId.IMU_GYR, PP_HwId.IMU_MAG):
        return 3
    return 1


def _sensor_create_subfunc(hw: PP_HwId) -> PP_SubFuncId:
    if hw == PP_HwId.IMU_ACC:
        return PP_SubFuncId.NewAccelerometer
    if hw == PP_HwId.IMU_GYR:
        return PP_SubFuncId.NewGyroscope
    if hw == PP_HwId.IMU_MAG:
        return PP_SubFuncId.NewMagnetometer
    return PP_SubFuncId.NoSubFuncId


def _normalize_motor_outputs(
    outputs: Sequence[Union[PP_MotorOutput, int]],
    output_count: Optional[int] = None,
) -> list[PP_MotorOutput]:
    out_list = list(outputs or [])
    if output_count is not None:
        count = int(output_count)
        if count < 0:
            raise ValueError("outputCount must be >= 0")
        out_list = out_list[:count]

    if not (1 <= len(out_list) <= 3):
        raise ValueError("Motor blocks require 1 to 3 outputs.")

    normalized: list[PP_MotorOutput] = []
    seen: set[int] = set()
    for raw in out_list:
        try:
            item = raw if isinstance(raw, PP_MotorOutput) else PP_MotorOutput(int(raw))
        except Exception as exc:
            raise ValueError(f"Invalid motor output: {raw}") from exc
        if item == PP_MotorOutput.NoMotorOutput:
            raise ValueError("NoMotorOutput is not a valid selected motor output.")
        if int(item) in seen:
            raise ValueError("Motor outputs must be unique.")
        seen.add(int(item))
        normalized.append(item)
    return normalized


def _normalize_encoder_outputs(
    outputs: Sequence[Union[PP_EncoderOutput, int]],
    output_count: Optional[int] = None,
) -> list[PP_EncoderOutput]:
    out_list = list(outputs or [])
    if output_count is not None:
        count = int(output_count)
        if count < 0:
            raise ValueError("outputCount must be >= 0")
        out_list = out_list[:count]

    if not (1 <= len(out_list) <= 2):
        raise ValueError("Encoder blocks require 1 or 2 outputs.")

    normalized: list[PP_EncoderOutput] = []
    seen: set[int] = set()
    for raw in out_list:
        try:
            item = raw if isinstance(raw, PP_EncoderOutput) else PP_EncoderOutput(int(raw))
        except Exception as exc:
            raise ValueError(f"Invalid encoder output: {raw}") from exc
        if item == PP_EncoderOutput.NoEncoderOutput:
            raise ValueError("NoEncoderOutput is not a valid selected encoder output.")
        if int(item) in seen:
            raise ValueError("Encoder outputs must be unique.")
        seen.add(int(item))
        normalized.append(item)
    return normalized


# -----------------------------------------------------------------------------
# Low-level Link helper (ported from Linkblock2block() in PAPAYA.cpp)
# -----------------------------------------------------------------------------

def _link_block2block(src_id: int, out_idx: int, dst_id: int, in_idx: int, subfunc: PP_SubFuncId) -> None:
    # Base size: fixed + 2*(param_info + blockId)
    serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_blockID_SIZE)
    nbr_params = 2

    if subfunc in (
        PP_SubFuncId.LinkSys2Node,
        PP_SubFuncId.LinkSys2Macro,
        PP_SubFuncId.LinkIn2Node,
        PP_SubFuncId.LinkIn2Macro,
    ):
        serial_size += PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        nbr_params = 3

    elif subfunc in (
        PP_SubFuncId.LinkNode2Sys,
        PP_SubFuncId.LinkNode2Probe,
        PP_SubFuncId.LinkNode2VectorProbe,
        PP_SubFuncId.LinkMacro2Sys,
        PP_SubFuncId.LinkMacro2Probe,
    ):
        serial_size += PP_PARAM_INFO_SIZE + PP_UINT8_SIZE
        nbr_params = 3

    elif subfunc in (
        PP_SubFuncId.LinkNode2Node,
        PP_SubFuncId.LinkNode2Macro,
        PP_SubFuncId.LinkMacro2Node,
        PP_SubFuncId.LinkMacro2Macro,
    ):
        serial_size += 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        nbr_params = 4

    cmd = CTX.prepare_cmd_header(
        serial_data_size=serial_size,
        func_id=PP_FuncId.Linkblock,
        nbr_of_params=nbr_params,
        sub_func_id=subfunc,
        block_id=0xFFFF,
        use_global_command=True,
    )

    # Fill params exactly like the C++ switch/cases
    if subfunc in (
        PP_SubFuncId.LinkSys2Sys,
        PP_SubFuncId.LinkSys2Probe,
        PP_SubFuncId.LinkSys2VectorProbe,
        PP_SubFuncId.LinkIn2Sys,
    ):
        CTX.prepare_param(cmd, 0, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, src_id)
        CTX.prepare_param(cmd, 1, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, dst_id)

    elif subfunc in (
        PP_SubFuncId.LinkSys2Node,
        PP_SubFuncId.LinkSys2Macro,
        PP_SubFuncId.LinkIn2Node,
        PP_SubFuncId.LinkIn2Macro,
    ):
        CTX.prepare_param(cmd, 0, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, src_id)
        CTX.prepare_param(cmd, 1, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, dst_id)
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, in_idx)

    elif subfunc in (
        PP_SubFuncId.LinkNode2Sys,
        PP_SubFuncId.LinkNode2Probe,
        PP_SubFuncId.LinkNode2VectorProbe,
        PP_SubFuncId.LinkMacro2Sys,
        PP_SubFuncId.LinkMacro2Probe,
    ):
        CTX.prepare_param(cmd, 0, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, src_id)
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, out_idx)
        CTX.prepare_param(cmd, 2, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, dst_id)

    elif subfunc in (
        PP_SubFuncId.LinkNode2Node,
        PP_SubFuncId.LinkNode2Macro,
        PP_SubFuncId.LinkMacro2Node,
        PP_SubFuncId.LinkMacro2Macro,
    ):
        CTX.prepare_param(cmd, 0, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, src_id)
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, out_idx)
        CTX.prepare_param(cmd, 2, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, dst_id)
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, in_idx)

    CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Core primitive blocks
# -----------------------------------------------------------------------------

class probe:
    """Scalar probe for monitoring a signal (connected to a block output).

    Inputs:
        signal: input 0
    """

    currentProbeId: int = 0x5000
    currentProbeIdx: int = 0

    def __init__(self, label: Optional[str] = None) -> None:
        self.id: int = 0
        self.idx: int = 0
        self.label: Optional[str] = None
        self.value: float = 0.0

        if label is not None:
            self.label = label
            self.id = probe.currentProbeId
            probe.currentProbeId += 1

            param1_size = len(label.encode("utf-8")) + 1
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size)

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewProbe, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_String, label)
            CTX.handle_cmd(cmd, serial_size)

    def getId(self) -> int:
        return self.id

    def setId(self, id_: int) -> None:
        self.id = id_ & 0xFFFF

    def getLabel(self) -> Optional[str]:
        return self.label

    def addToQueue(self) -> None:
        self.idx = probe.currentProbeIdx
        probe.currentProbeIdx += 1
        if self.label is not None:
            CTX.register_probe_label(self.idx, self.label)

    def getVal(self, id: Optional[int] = None) -> float:
        """Return the latest value sampled into the host's probe buffer.

        ``id`` is the wire ID Studio assigned to the probe at save-time
        (e.g. ``0x5000``).  Use it when the host never instantiated the
        probe locally (typically a SPI/USB master driving an
        EEPROM-stored app) and only knows the probe by its stored ID.
        Without ``id`` the call uses ``self.idx`` exactly as before.
        """
        if id is not None:
            slot = (int(id) - PP_PROBE_ID_BASE) & 0xFFFF
            if slot >= PP_MAX_PROBES_NUMBER:
                raise ValueError(
                    f"probe id 0x{int(id):04X} maps to slot {slot}, which is "
                    f"outside [0, {PP_MAX_PROBES_NUMBER})"
                )
            # Auto-grow currentProbeIdx so the next readProbes() request
            # matches the firmware's response size.  Idempotent.
            if probe.currentProbeIdx <= slot:
                probe.currentProbeIdx = slot + 1
            start = slot * PP_REAL_SIZE
            raw = bytes(CTX.probes_buffer[start : start + 4])
            return struct.unpack("<f", raw)[0]

        start = self.idx * PP_REAL_SIZE
        raw = bytes(CTX.probes_buffer[start : start + 4])
        return struct.unpack("<f", raw)[0]

    def getIntVal(self, id: Optional[int] = None) -> int:
        # Not implemented in provided C++ sources; best-effort interpretation.
        if id is not None:
            slot = (int(id) - PP_PROBE_ID_BASE) & 0xFFFF
            if slot >= PP_MAX_PROBES_NUMBER:
                raise ValueError(
                    f"probe id 0x{int(id):04X} maps to slot {slot}, which is "
                    f"outside [0, {PP_MAX_PROBES_NUMBER})"
                )
            if probe.currentProbeIdx <= slot:
                probe.currentProbeIdx = slot + 1
            start = slot * PP_REAL_SIZE
            raw = bytes(CTX.probes_buffer[start : start + 4])
            return struct.unpack("<i", raw)[0]
        start = self.idx * PP_REAL_SIZE
        raw = bytes(CTX.probes_buffer[start : start + 4])
        return struct.unpack("<i", raw)[0]

    def show(self) -> None:
        # C++ show() mostly disables Serial printing; it at least updates this->value.
        self.value = self.getVal()


def _check_vector_probe_size(src) -> None:
    """Refuse a vector-probe link the firmware would reject anyway.

    The board enforces a per-probe byte ceiling when a vector probe
    pushes to the monitor, and refuses the link with design status 8,
    BadRequest, but only AFTER it has already wired the probe into the
    design, so the design and the monitor end up disagreeing and the
    session latches a failure behind a generic 'failed to upload the
    design'.  Raising here, BEFORE the frame is emitted, turns that into
    an actionable host-side error and keeps the board clean.
    PP_MAX_VECTOR_PROBES_BYTES is that same ceiling.
    """
    lines = int(getattr(src, "dataLines", 0) or 0)
    raw = int(getattr(src, "dataRaw", 0) or 0)
    nbytes = lines * raw * PP_REAL_SIZE
    if nbytes > PP_MAX_VECTOR_PROBES_BYTES:
        name = getattr(src, "name", None) or type(src).__name__
        raise ValueError(
            f"Vector probe on '{name}' needs {nbytes} bytes "
            f"({lines}x{raw} floats) but the board's per-probe monitor "
            f"buffer is {PP_MAX_VECTOR_PROBES_BYTES} bytes. Reduce the "
            f"block's vector size (e.g. FFT points / filter taps)."
        )


class VectorProbe:
    """Vector probe for multi-sample outputs (FFT/DWT/RLS...)."""

    currentVectorProbeId: int = 0x6000
    VectorProbeBytes: int = 0
    currentVectorProbeIdx: int = 0

    def __init__(self, label: Optional[str] = None) -> None:
        self.id: int = 0
        self.idx: int = 0
        self.label: Optional[str] = None
        self.dataLines: int = 0
        self.dataRaw: int = 0
        self.bufferOffsetBytes: int = 0

        if label is not None:
            self.label = label
            self.id = VectorProbe.currentVectorProbeId
            VectorProbe.currentVectorProbeId += 1

            param1_size = len(label.encode("utf-8")) + 1
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size)

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewVectorProbe, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_String, label)
            CTX.handle_cmd(cmd, serial_size, vect=True)

    def getId(self) -> int:
        return self.id

    def addToQueue(self) -> None:
        self.idx = VectorProbe.currentVectorProbeIdx
        VectorProbe.currentVectorProbeIdx += 1
        if self.label is not None:
            CTX.register_vector_probe_label(self.idx, self.label)
        # Registry of the vector probes created during one code-generation
        # run.  Papaya Studio reads it when it writes a standalone Python
        # script, so each probe's read can be sized from the probe itself;
        # it is cleared at the start of every run.  With the registry empty
        # the generated script has to fall back to the 512-byte worst case
        # for every probe, which reads far more bytes than it needs, so this
        # must be populated here.  Keep it append-only: duplicate
        # registrations are not expected because addToQueue is invoked
        # exactly once per VectorProbe link (tf.__rshift__ / node.__rshift__).
        try:
            instances = VectorProbe._instances  # type: ignore[attr-defined]
        except AttributeError:
            VectorProbe._instances = []
            instances = VectorProbe._instances
        instances.append(self)

    def show(self) -> None:
        # purely local view of the current buffer contents
        pass

    def getSamples(self, samples_size: int) -> bytes:
        base = self.bufferOffsetBytes
        return bytes(CTX.vector_probes_buffer[base : base + samples_size * PP_REAL_SIZE])


class input:
    """External scalar source whose value is provided by the host. Can be constant or host-modified at runtime.

    Outputs:
        value: output 0
    """

    currentInputId: int = 0x4000
    currentInputIdx: int = 0

    def __init__(self, label: Optional[str] = None, val: Optional[float] = None) -> None:
        self.id: int = 0
        self.idx: int = 0
        self.label: Optional[str] = None
        self.val: float = 0.0

        if label is not None and val is not None:
            self.label = label
            self.val = float(val)

            self.id = input.currentInputId
            input.currentInputId += 1

            param1_size = len(label.encode("utf-8")) + 1
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size) + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewInput, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_String, label)
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, self.val)
            CTX.handle_cmd(cmd, serial_size)

    def getId(self) -> int:
        return self.id

    def enableRemote(self) -> None:
        # Matches C++: idx assigned and currentInputIdx incremented, then addToQueue(val), then EnableRemoteInput manage command.
        self.idx = input.currentInputIdx
        input.currentInputIdx += 1
        if self.label is not None:
            CTX.register_input_label(self.idx, self.label)

        self.addToQueue(self.val)

        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.EnableRemoteInput, self.id)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def addToQueue(self, input_value: float, id: Optional[int] = None) -> None:
        """Stage ``input_value`` for the next ``writeInputs()`` push.

        ``id`` is the wire ID Studio assigned to the input at save-time
        (e.g. ``0x4000``).  Use it when the host never instantiated the
        input locally (typically a SPI/USB master driving an
        EEPROM-stored app) and only knows the input by its stored ID.
        Without ``id`` the call uses ``self.idx`` exactly as before.
        """
        if id is not None:
            slot = (int(id) - PP_INPUT_ID_BASE) & 0xFFFF
            if slot >= PP_MAX_INPUTS_NUMBER:
                raise ValueError(
                    f"input id 0x{int(id):04X} maps to slot {slot}, which is "
                    f"outside [0, {PP_MAX_INPUTS_NUMBER})"
                )
            # Auto-grow currentInputIdx so writeInputs() pushes enough
            # bytes for every input the firmware expects.  Idempotent.
            if input.currentInputIdx <= slot:
                input.currentInputIdx = slot + 1
            b = struct.pack("<f", float(input_value))
            start = slot * PP_REAL_SIZE
            CTX.inputs_buffer[start : start + 4] = b
            return

        # Writes float32 little-endian into InputsBuffer at idx
        b = struct.pack("<f", float(input_value))
        start = self.idx * PP_REAL_SIZE
        CTX.inputs_buffer[start : start + 4] = b
        self.val = float(input_value)

    def __gt__(self, dst: Union["tf", "node", "macro"]) -> None:
        if isinstance(dst, tf):
            _link_block2block(self.id, 0xFF, dst.getId(), 0xFF, PP_SubFuncId.LinkIn2Sys)
        elif isinstance(dst, node):
            _link_block2block(self.id, 0xFF, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkIn2Node)
        elif isinstance(dst, macro):
            _link_block2block(self.id, 0xFF, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkIn2Macro)
            dst._consume_active_ports()
        else:
            raise TypeError(f"Unsupported destination type for input > : {type(dst)}")


# -----------------------------------------------------------------------------
# Transfer function (sys) blocks
# -----------------------------------------------------------------------------

class tf:
    """Continuous-time linear transfer function defined by numerator/denominator.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    currentSysId: int = 0x2000

    def __init__(
        self,
        numerator: Optional[Union[str, Sequence[float]]] = None,
        denominator: Optional[Union[str, Sequence[float]]] = None,
        numSize: Optional[int] = None,
        denomSize: Optional[int] = None,
    ) -> None:
        self.id: int = 0
        self.dataLines: int = 0
        self.dataRaw: int = 0

        # Default constructor (no frames)
        if numerator is None and denominator is None:
            return

        # String coefficients constructor
        if isinstance(numerator, str) and isinstance(denominator, str):
            num_b = numerator.encode("utf-8")
            den_b = denominator.encode("utf-8")
            param1_size = len(num_b) + 1
            param2_size = len(den_b) + 1
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size) + (PP_PARAM_INFO_SIZE + param2_size)

            self.id = tf.currentSysId
            tf.currentSysId += 1

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewSys, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_String, numerator)
            CTX.prepare_param(cmd, 1, param2_size, PP_FuncParamId.TYPE_String, denominator)
            CTX.handle_cmd(cmd, serial_size)
            return

        # Numeric array constructor: tf(float* numerator, uint8_t numSize, float* denominator, uint8_t denomSize)
        # Accept lists, tuples, or any array-like (numpy ndarray, etc.).
        # numSize/denomSize are optional, auto-derived from len() when omitted.
        def _is_array_like(x):
            if isinstance(x, (list, tuple)):
                return True
            # numpy ndarray / pandas Series / anything with __len__ + __iter__
            try:
                len(x)
                iter(x)
                return not isinstance(x, (str, bytes))
            except (TypeError, AttributeError):
                return False

        if _is_array_like(numerator) and _is_array_like(denominator):
            num_list = [float(v) for v in numerator]
            den_list = [float(v) for v in denominator]
            n_sz = int(numSize) if numSize is not None else len(num_list)
            d_sz = int(denomSize) if denomSize is not None else len(den_list)
            if n_sz <= 0 or d_sz <= 0:
                raise ValueError(
                    f"tf: numerator and denominator must be non-empty "
                    f"(got numSize={n_sz}, denomSize={d_sz})"
                )
            param1_size = n_sz * PP_REAL_SIZE
            param3_size = d_sz * PP_REAL_SIZE
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size) + (PP_PARAM_INFO_SIZE + param3_size) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)

            self.id = tf.currentSysId
            tf.currentSysId += 1

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewSysLightC, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_RealArray, num_list)
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, n_sz)
            CTX.prepare_param(cmd, 2, param3_size, PP_FuncParamId.TYPE_RealArray, den_list)
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, d_sz)
            CTX.handle_cmd(cmd, serial_size)
            return

        raise TypeError(
            f"Unsupported tf constructor signature: "
            f"numerator={type(numerator).__name__}={numerator!r}, "
            f"denominator={type(denominator).__name__}={denominator!r}, "
            f"numSize={numSize}, denomSize={denomSize}. "
            f"Expected (str, str), (array-like, array-like), or "
            f"(array-like, int, array-like, int)."
        )

    def getId(self) -> int:
        return self.id

    def setId(self, id_: int) -> None:
        self.id = id_ & 0xFFFF

    def __gt__(self, dst: Union["tf", "node", "macro", probe]) -> None:
        if isinstance(dst, tf):
            _link_block2block(self.id, 0xFF, dst.getId(), 0xFF, PP_SubFuncId.LinkSys2Sys)
        elif isinstance(dst, probe):
            _link_block2block(self.id, 0xFF, dst.getId(), 0xFF, PP_SubFuncId.LinkSys2Probe)
            dst.addToQueue()
        elif isinstance(dst, node):
            _link_block2block(self.id, 0xFF, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkSys2Node)
        elif isinstance(dst, macro):
            _link_block2block(self.id, 0xFF, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkSys2Macro)
            dst._consume_active_ports()
        else:
            raise TypeError(f"Unsupported destination type for tf > : {type(dst)}")

    def __rshift__(self, dst: VectorProbe) -> None:
        _check_vector_probe_size(self)
        _link_block2block(self.id, 0xFF, dst.getId(), 0xFF, PP_SubFuncId.LinkSys2VectorProbe)
        dst.dataLines = self.dataLines
        dst.dataRaw = self.dataRaw
        dst.bufferOffsetBytes = VectorProbe.VectorProbeBytes
        VectorProbe.VectorProbeBytes += self.dataLines * self.dataRaw * PP_REAL_SIZE
        dst.addToQueue()


class tfd(tf):
    """Discrete-time linear transfer function.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, numerator: Sequence[float], denominator: Sequence[float], sysord: int) -> None:
        super().__init__()
        self.id = tf.currentSysId
        tf.currentSysId += 1

        # An order-N filter has N+1 coefficients (b0..bN, a0..aN). The board
        # reserves (sysord+1) floats per coefficient array and its IIR
        # routine reads indices 0..sysord inclusive. Sending
        # only sysord coefficients leaves the last slot uninitialised and
        # silently degrades the filter (e.g. an order-2 stable Butterworth
        # collapses to an order-1 unstable response on the board).
        param1_size = (int(sysord) + 1) * PP_REAL_SIZE
        param2_size = (int(sysord) + 1) * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size) + (PP_PARAM_INFO_SIZE + param2_size) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)

        # C++ uses a local PP_CommandInfo Command; we emulate by using a fresh command object.
        cmd = CTX.prepare_cmd_header(
            serial_data_size=serial_size,
            func_id=PP_FuncId.Createblock,
            nbr_of_params=3,
            sub_func_id=PP_SubFuncId.NewSysLightD,
            block_id=self.id,
            use_global_command=False,
        )
        CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_RealArray, numerator)
        CTX.prepare_param(cmd, 1, param2_size, PP_FuncParamId.TYPE_RealArray, denominator)
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(sysord))
        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Node blocks
# -----------------------------------------------------------------------------

class node:
    """Generic processing node with configurable multi-input/multi-output coefficients."""

    currentNodeId: int = 0x1000

    def __init__(self, inCoef: Optional[Any] = None, outCoef: Optional[Any] = None, Type: Optional[PP_NodeType] = None) -> None:
        self.id: int = 0
        self.activeInIdx: int = 0
        self.activeOutIdx: int = 0
        self.dataLines: int = 0
        self.dataRaw: int = 0
        # Python keyword workaround: allow calling obj.in(…) like the C++ API\n        self.in = self.in_  # type: ignore[attr-defined]\n
        # Default node constructor: only sets active indices.
        if inCoef is None and outCoef is None and Type is None:
            return

        # String-based node constructor (implemented in C++)
        if isinstance(inCoef, str) and isinstance(outCoef, str) and Type is not None:
            param1_size = len(inCoef.encode("utf-8")) + 1
            param2_size = len(outCoef.encode("utf-8")) + 1
            serial_size = (
                PP_FIXED_SIZE
                + (PP_PARAM_INFO_SIZE + param1_size)
                + (PP_PARAM_INFO_SIZE + param2_size)
                + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )

            self.id = node.currentNodeId
            node.currentNodeId += 1

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewNode, self.id)
            CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_String, inCoef)
            CTX.prepare_param(cmd, 1, param2_size, PP_FuncParamId.TYPE_String, outCoef)
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Type))
            CTX.handle_cmd(cmd, serial_size)
            return

        # Numeric-array (flex) node.
        #
        # This used to raise NotImplementedError claiming the constructor
        # was "declared in the header but not implemented in PAPAYA.cpp".
        # That was true once and is not any more: the C++ library
        # implements it and emits NewFlexNode with five params
        # (inCoef array, inSize, outCoef array, outSize, Type). Leaving
        # the error in place meant flex nodes could be built from C++ and
        # not from Python, and the message sent anyone who checked
        # looking for a C++ bug that no longer existed.
        if inCoef is not None and outCoef is not None and Type is not None:
            in_coef = [float(v) for v in inCoef]
            out_coef = [float(v) for v in outCoef]
            if not in_coef or not out_coef:
                raise ValueError("node(inCoef, outCoef, Type): coefficient arrays must not be empty")
            if len(in_coef) > 0xFF or len(out_coef) > 0xFF:
                raise ValueError("node(): coefficient arrays are limited to 255 entries (sizes are sent as uint8)")

            in_bytes = len(in_coef) * PP_REAL_SIZE
            out_bytes = len(out_coef) * PP_REAL_SIZE
            serial_size = (
                PP_FIXED_SIZE
                + (PP_PARAM_INFO_SIZE + in_bytes)
                + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
                + (PP_PARAM_INFO_SIZE + out_bytes)
                + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
                + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )

            self.id = node.currentNodeId
            node.currentNodeId += 1

            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewFlexNode, self.id)
            CTX.prepare_param(cmd, 0, in_bytes, PP_FuncParamId.TYPE_RealArray, in_coef)
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, len(in_coef))
            CTX.prepare_param(cmd, 2, out_bytes, PP_FuncParamId.TYPE_RealArray, out_coef)
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, len(out_coef))
            CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Type))
            CTX.handle_cmd(cmd, serial_size)
            return

        raise TypeError(
            "node() takes either (inCoef: str, outCoef: str, Type) or "
            "(inCoef: sequence[float], outCoef: sequence[float], Type), "
            "or no arguments at all"
        )

    def getId(self) -> int:
        return self.id

    def setId(self, id_: int) -> None:
        self.id = id_ & 0xFFFF

    def getActiveInIdx(self) -> int:
        return self.activeInIdx & 0xFF

    def getActiveOutIdx(self) -> int:
        return self.activeOutIdx & 0xFF

    def in_(self, inIdx: int) -> "node":
        # Python-friendly alias of C++ in()
        self.activeInIdx = int(inIdx) & 0xFF
        return self

    def out(self, outIdx: int) -> "node":
        self.activeOutIdx = int(outIdx) & 0xFF
        return self


    def __gt__(self, dst: Union[tf, "node", "macro", probe]) -> None:
        if isinstance(dst, tf):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), 0xFF, PP_SubFuncId.LinkNode2Sys)
        elif isinstance(dst, probe):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), 0xFF, PP_SubFuncId.LinkNode2Probe)
            dst.addToQueue()
        elif isinstance(dst, node):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkNode2Node)
        elif isinstance(dst, macro):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkNode2Macro)
            dst._consume_active_ports()
        else:
            raise TypeError(f"Unsupported destination type for node > : {type(dst)}")

    def __rshift__(self, dst: VectorProbe) -> None:
        _check_vector_probe_size(self)
        _link_block2block(self.id, self.activeOutIdx, dst.getId(), 0xFF, PP_SubFuncId.LinkNode2VectorProbe)
        dst.dataLines = self.dataLines
        dst.dataRaw = self.dataRaw
        dst.bufferOffsetBytes = VectorProbe.VectorProbeBytes
        VectorProbe.VectorProbeBytes += self.dataLines * self.dataRaw * PP_REAL_SIZE
        dst.addToQueue()


# Simple no-param nodes
class schmidt(node):
    """Schmitt trigger node (hysteresis comparator).

    Inputs:
        signal: input 0
        Vmax: input 1
        Vmin: input 2
        high_th: input 3
        low_th: input 4
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSchmidt, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class comp(node):
    """Comparator node.

    Inputs:
        Vsatp: input 0
        Vsatm: input 1
        Vinp: input 2
        Vinm: input 3
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewComp, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class sat(node):
    """Saturation nonlinearity.

    Inputs:
        Vsatp: input 0
        Vsatm: input 1
        signal: input 2
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSat, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class deadZone(node):
    """Dead-zone nonlinearity.

    Inputs:
        dead1: input 0
        dead2: input 1
        signal: input 2
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewDeadZone, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class backlashDeadBand(node):
    """Backlash + deadband nonlinearity.

    Inputs:
        deadband: input 0
        signal: input 1
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewBacklashDeadBand, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class merger(node):
    """Merger node that reduces multiple inputs into a single output.

    Outputs:
        out: output 0
    """

    def __init__(self, nbrOfInputs: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMerger, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(nbrOfInputs))
        CTX.handle_cmd(cmd, serial_size)


class sign(node):
    """Sign function node (+1 / -1).

    Inputs:
        in: input 0
    Outputs:
        sign: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        self.out(0)  # explicit in C++
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSign, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class gain(node):
    """Gain block: multiplies input by a constant coefficient.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, gainValue: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewGain, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, gainValue)
        CTX.handle_cmd(cmd, serial_size)


# ======================== Math / DSP systems ========================

class sqrMath(tf):
    """Square function system (x**2).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSqrMath, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class sqrtBlock(tf):
    """Square-root system.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSqrt, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class sineFunc(tf):
    """Sine function system sin(x), input in radians.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSineFunc, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class cosineFunc(tf):
    """Cosine function system cos(x), input in radians.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewCosineFunc, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class absVal(tf):
    """Absolute-value system |x|.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewAbsVal, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class atan2Block(node):
    """Two-argument arc-tangent node atan2(y, x).

    Inputs:
        y: input 0
        x: input 1
    Outputs:
        angle: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewAtan2, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class logFunc(tf):
    """Natural-logarithm system ln(x).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewLogFunc, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class expFunc(tf):
    """Exponential system e^x.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewExpFunc, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class negateBlock(tf):
    """Negation system (-x).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewNegate, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class inverseBlock(tf):
    """Reciprocal system (1/x).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewInverse, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


# ======================== Control blocks ========================

class switchBlock(node):
    """Conditional switch.  out = (control >= 0) ? in1 : in2.

    Inputs:
        control: input 0
        in1: input 1
        in2: input 2
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSwitch, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class modulo(node):
    """Floored modulo: out = x - floor(x / m) * m.

    The result takes the sign of the DIVISOR, so wrapping a rising clock
    into a period gives a sawtooth that starts at zero and never goes
    negative. A modulus of zero passes x through unchanged.

    Inputs:
        x: input 0, the value to wrap
        m: input 1, the modulus
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewModulo, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class integratorICBlock(node):
    """Integrator with an initial condition and an external reset.

    While reset is above 0.5 the output is held at the initial condition.
    When reset falls back the block integrates on from that value, so a
    model can be put into a known state before a run and released.

    Inputs:
        in: input 0, the signal to integrate
        reset: input 1, holds the output at the initial condition above 0.5
        ic: input 2, the initial condition
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewIntegratorIC, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class quantizer(node):
    """Quantiser node.  out = round(signal / step) * step.

    Inputs:
        signal: input 0
        step: input 1
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewQuantizer, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class integratorBlock(tf):
    """Pure integrator system H(s) = 1/s.

    Auto-discretised on the board using the design's C2D algorithm.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewIntegrator, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class derivativeBlock(tf):
    """Filtered derivative system H(s) = s / (tau*s + 1).

    Auto-discretised on the board using the design's C2D algorithm.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, tau: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewDerivative, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(tau))
        CTX.handle_cmd(cmd, serial_size)


class rateLimiter(node):
    """Slew-rate limiter.

    Inputs:
        signal: input 0
        rising_rate: input 1
        falling_rate: input 2
    Outputs:
        out: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewRateLimiter, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class sampleHold(node):
    """Sample-and-hold.  Latches signal on rising edge of trigger.

    Inputs:
        signal: input 0
        trigger: input 1
    Outputs:
        held: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewSampleHold, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


# ======================== Motor control transforms ========================

class clarkeTransform(node):
    """Clarke transform (Ia, Ib) -> (Ialpha, Ibeta).

    Inputs:
        Ia: input 0
        Ib: input 1
    Outputs:
        Ialpha: output 0
        Ibeta: output 1
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewClarke, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class invClarkeTransform(node):
    """Inverse Clarke transform (Ialpha, Ibeta) -> (Ia, Ib).

    Inputs:
        Ialpha: input 0
        Ibeta: input 1
    Outputs:
        Ia: output 0
        Ib: output 1
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewInvClarke, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class parkTransform(node):
    """Park transform (Ialpha, Ibeta, theta) -> (Id, Iq).

    Inputs:
        Ialpha: input 0
        Ibeta: input 1
        theta: input 2
    Outputs:
        Id: output 0
        Iq: output 1
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewPark, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class invParkTransform(node):
    """Inverse Park transform (Id, Iq, theta) -> (Ialpha, Ibeta).

    Inputs:
        Id: input 0
        Iq: input 1
        theta: input 2
    Outputs:
        Ialpha: output 0
        Ibeta: output 1
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewInvPark, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


# ======================== Classical compensators ========================

class leadLag(tf):
    """Lead-lag compensator K*(s+z)/(s+p).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, K: float, z: float, p: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewLeadLag, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(K))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(z))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(p))
        CTX.handle_cmd(cmd, serial_size)


class washout(tf):
    """Washout (high-pass) filter s/(s+a).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, a: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewWashout, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(a))
        CTX.handle_cmd(cmd, serial_size)


class expander(node):
    """Expander node that fans out a single input to multiple outputs.

    Inputs:
        in: input 0
    """

    def __init__(self, nbrOfOutputs: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewExpander, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(nbrOfOutputs))
        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Macro blocks
# -----------------------------------------------------------------------------

class macro:
    """Composite subgraph that encapsulates internal nodes and connections."""

    currentMacroId: int = 0x3000

    def __init__(self, nbrOfInputs: Optional[int] = None, nbrOfOutputs: Optional[int] = None) -> None:
        self.id: int = 0
        self.activeInIdx: int = 0
        self.activeOutIdx: int = 0
        # Python keyword workaround: allow calling obj.in(…) like the C++ API\n        self.in = self.in_  # type: ignore[attr-defined]\n
        if nbrOfInputs is None and nbrOfOutputs is None:
            return

        if nbrOfInputs is not None and nbrOfOutputs is not None:
            self.id = macro.currentMacroId
            macro.currentMacroId += 1

            serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewMacro, self.id)
            CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(nbrOfInputs))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(nbrOfOutputs))
            CTX.handle_cmd(cmd, serial_size)
            return

        raise TypeError("macro requires both nbrOfInputs and nbrOfOutputs")

    def getId(self) -> int:
        return self.id

    def setId(self, id_: int) -> None:
        self.id = id_ & 0xFFFF

    def getActiveInIdx(self) -> int:
        return self.activeInIdx & 0xFF

    def getActiveOutIdx(self) -> int:
        return self.activeOutIdx & 0xFF

    def in_(self, inIdx: int) -> "macro":
        # Mirror C++ macro::in(): activeInIdx and activeOutIdx hold the
        # SAME value on a macro (the macro has one "active port" that is
        # interpreted as input or output depending on the operator
        # context). Without this cross-set, ``retMacro.out(N)`` followed
        # by ``src > retMacro.out(N)`` sends the prior ``in_()`` index in
        # the wire param the firmware reads as the macro's port, which
        # silently routes to the wrong output and eventually trips a
        # BadConnection when a real link collides with the misplaced one.
        self.activeInIdx = int(inIdx) & 0xFF
        self.activeOutIdx = self.activeInIdx
        return self

    def out(self, outIdx: int) -> "macro":
        self.activeOutIdx = int(outIdx) & 0xFF
        self.activeInIdx = self.activeOutIdx
        return self

    def _consume_active_ports(self) -> None:
        # ``in_()`` / ``out()`` set a sticky "active port" on the macro
        # that the next ``>`` operator reads. Once a link has consumed
        # that selection, drop it back to the default (0) so a later
        # implicit link like ``ecg_sensor > preprocessing`` (no explicit
        # ``.in_(0)``) does not pick up the last index used inside
        # build_preprocessing() and try to send "macro input N" for an
        # N that doesn't exist on this macro, which the firmware
        # rightly rejects with BadParam.
        self.activeInIdx = 0
        self.activeOutIdx = 0


    def __gt__(self, dst: Union[tf, node, "macro", probe]) -> None:
        if isinstance(dst, tf):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), 0xFF, PP_SubFuncId.LinkMacro2Sys)
        elif isinstance(dst, probe):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), 0xFF, PP_SubFuncId.LinkMacro2Probe)
            dst.addToQueue()
        elif isinstance(dst, node):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkMacro2Node)
        elif isinstance(dst, macro):
            _link_block2block(self.id, self.activeOutIdx, dst.getId(), dst.getActiveInIdx(), PP_SubFuncId.LinkMacro2Macro)
            dst._consume_active_ports()
        else:
            raise TypeError(f"Unsupported destination type for macro > : {type(dst)}")
        self._consume_active_ports()

    def start(self) -> None:
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.StartMacro, self.id)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)

    def stop(self) -> None:
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Manageblock, 0, PP_SubFuncId.StopMacro, self.id)
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


# -----------------------------------------------------------------------------
# Specific block constructors (filters, generators, DSP blocks, etc.)
# -----------------------------------------------------------------------------

class butter(tf):
    """Butterworth filter (low/high/band/stop).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType) -> None:
        # Accept both calling styles:
        #   butter(n, fc, filter_type)
        #   butter(n, fc1, fc2, filter_type)
        if fc2 is not None and ftype == PP_FilterType.NoFilterType:
            # If the 3rd positional argument looks like a FilterType, treat it
            # as such (single-band calling style).
            _ft_candidate: Optional[int] = None
            if isinstance(fc2, IntEnum):
                _ft_candidate = int(fc2)
            elif isinstance(fc2, int) and not isinstance(fc2, bool):
                _ft_candidate = int(fc2)
            elif isinstance(fc2, float) and abs(fc2 - round(fc2)) < 1e-9:
                _ft_candidate = int(round(fc2))

            if _ft_candidate is not None:
                try:
                    ftype = PP_FilterType(_ft_candidate)
                    fc2 = None
                except Exception:
                    pass

        super().__init__()
        subf = _get_butter_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        if fc2 is None:
            # Only low/high allowed in C++ single-cutoff constructor
            if subf not in (PP_SubFuncId.NewButterLow, PP_SubFuncId.NewButterHigh):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.handle_cmd(cmd, serial_size)
        else:
            # Band/stop uses fc1, fc2 + n
            if subf not in (PP_SubFuncId.NewButterBand, PP_SubFuncId.NewButterStop):
                return
            serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.handle_cmd(cmd, serial_size)


class butterBq(macro):
    """Biquad cascade implementation of Butterworth filter.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType) -> None:
        # Accept both calling styles:
        #   butterBq(n, fc, filter_type)
        #   butterBq(n, fc1, fc2, filter_type)
        if fc2 is not None and ftype == PP_FilterType.NoFilterType:
            _ft_candidate: Optional[int] = None
            if isinstance(fc2, IntEnum):
                _ft_candidate = int(fc2)
            elif isinstance(fc2, int) and not isinstance(fc2, bool):
                _ft_candidate = int(fc2)
            elif isinstance(fc2, float) and abs(fc2 - round(fc2)) < 1e-9:
                _ft_candidate = int(round(fc2))

            if _ft_candidate is not None:
                try:
                    ftype = PP_FilterType(_ft_candidate)
                    fc2 = None
                except Exception:
                    pass

        super().__init__()
        subf = _get_butter_bq_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewBiquadButterLow, PP_SubFuncId.NewBiquadButterHigh):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewBiquadButterBand, PP_SubFuncId.NewBiquadButterStop):
                return
            serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.handle_cmd(cmd, serial_size)


class cheby1(tf):
    """Chebyshev Type I IIR filter expressed as a transfer function.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, chebyCfg: int = 0xFF) -> None:
        # Accept both calling styles:
        #   cheby1(n, fc, filter_type, config)
        #   cheby1(n, fc1, fc2, filter_type, config)
        if chebyCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            # Likely called as (n, fc, filter_type, config) which binds
            #   fc2 <- filter_type
            #   ftype <- config
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                chebyCfg = _cfg
                fc2 = None
            except Exception:
                # If conversion fails, keep original arguments.
                pass

        super().__init__()
        subf = _get_cheby1_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewChebyshev1Low, PP_SubFuncId.NewChebyshev1High):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewChebyshev1Band, PP_SubFuncId.NewChebyshev1Stop):
                return
            # Four params on the wire: fc1, fc2, n, chebyCfg.
            #
            # This used to advertise NbrOfParams=3 and budget the body
            # for three, so the chebyCfg written at index 3 never
            # reached the board and the ripple configuration was left to
            # whatever the firmware defaulted to. The comment that
            # justified it ("matches the provided C++ ... bug/quirk")
            # had gone stale three ways over: the C++ library was
            # corrected to send four (papaya_lib/PAPAYA.cpp,
            # cheby1/cheby2 band+stop), and the biquad and elliptic
            # siblings in THIS file already send four. This pair was the
            # one left behind.
            #
            # (butter/butterBq band+stop keep NbrOfParams=3 just below:
            # they have no ripple configuration to send.)
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class cheby1Bq(macro):
    """Chebyshev Type I IIR filter implemented as a cascade of biquads.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, chebyCfg: int = 0xFF) -> None:
        # Accept both calling styles:
        #   cheby1Bq(n, fc, filter_type, config)
        #   cheby1Bq(n, fc1, fc2, filter_type, config)
        if chebyCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                chebyCfg = _cfg
                fc2 = None
            except Exception:
                pass

        super().__init__()
        subf = _get_cheby1_bq_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewBiquadCheby1Low, PP_SubFuncId.NewBiquadCheby1High):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewBiquadCheby1Band, PP_SubFuncId.NewBiquadCheby1Stop):
                return
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class cheby2(tf):
    """Chebyshev Type II (inverse Chebyshev) IIR filter expressed as a transfer function.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, chebyCfg: int = 0xFF) -> None:
        # Accept both calling styles:
        #   cheby2(n, fc, filter_type, config)
        #   cheby2(n, fc1, fc2, filter_type, config)
        if chebyCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                chebyCfg = _cfg
                fc2 = None
            except Exception:
                pass

        super().__init__()
        subf = _get_cheby2_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewChebyshev2Low, PP_SubFuncId.NewChebyshev2High):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewChebyshev2Band, PP_SubFuncId.NewChebyshev2Stop):
                return
            # Four params on the wire: fc1, fc2, n, chebyCfg.
            #
            # This used to advertise NbrOfParams=3 and budget the body
            # for three, so the chebyCfg written at index 3 never
            # reached the board and the ripple configuration was left to
            # whatever the firmware defaulted to. The comment that
            # justified it ("matches the provided C++ ... bug/quirk")
            # had gone stale three ways over: the C++ library was
            # corrected to send four (papaya_lib/PAPAYA.cpp,
            # cheby1/cheby2 band+stop), and the biquad and elliptic
            # siblings in THIS file already send four. This pair was the
            # one left behind.
            #
            # (butter/butterBq band+stop keep NbrOfParams=3 just below:
            # they have no ripple configuration to send.)
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class cheby2Bq(macro):
    """Chebyshev Type II (inverse Chebyshev) IIR filter implemented as a cascade of biquads.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, chebyCfg: int = 0xFF) -> None:
        if chebyCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                chebyCfg = _cfg
                fc2 = None
            except Exception:
                pass

        super().__init__()
        subf = _get_cheby2_bq_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewBiquadCheby2Low, PP_SubFuncId.NewBiquadCheby2High):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewBiquadCheby2Band, PP_SubFuncId.NewBiquadCheby2Stop):
                return
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(chebyCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class ellip(tf):
    """Elliptic (Cauer) IIR filter expressed as a transfer function.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, ellipCfg: int = 0xFF) -> None:
        # Accept both calling styles:
        #   ellip(n, fc, filter_type, config)
        #   ellip(n, fc1, fc2, filter_type, config)
        if ellipCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                ellipCfg = _cfg
                fc2 = None
            except Exception:
                pass

        super().__init__()
        subf = _get_ellip_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewEllipLow, PP_SubFuncId.NewEllipHigh):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(ellipCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewEllipBand, PP_SubFuncId.NewEllipStop):
                return
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(ellipCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class ellipBq(macro):
    """Elliptic (Cauer) IIR filter implemented as a cascade of biquads.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, n: int, fc_or_fc1: float, fc2: Optional[float] = None, ftype: PP_FilterType = PP_FilterType.NoFilterType, ellipCfg: int = 0xFF) -> None:
        if ellipCfg == 0xFF and fc2 is not None and not isinstance(ftype, PP_FilterType):
            try:
                _cfg = int(ftype)  # type: ignore[arg-type]
                _ft = PP_FilterType(int(fc2))
                ftype = _ft
                ellipCfg = _cfg
                fc2 = None
            except Exception:
                pass

        super().__init__()
        subf = _get_ellip_bq_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        if fc2 is None:
            if subf not in (PP_SubFuncId.NewBiquadEllipLow, PP_SubFuncId.NewBiquadEllipHigh):
                return
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(ellipCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewBiquadEllipBand, PP_SubFuncId.NewBiquadEllipStop):
                return
            serial_size = (
                PP_FIXED_SIZE
                + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            )
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc_or_fc1))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(fc2))
            CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n))
            CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(ellipCfg) & 0xFF)
            CTX.handle_cmd(cmd, serial_size)


class notch(tf):
    """Notch filter around a given center frequency and Q.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, centernotch: float, qualcoef: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewNotch, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(centernotch))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(qualcoef))
        CTX.handle_cmd(cmd, serial_size)


class peak(tf):
    """Peaking filter around a given center frequency and Q.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, center_freq: float, quality_factor: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewPeak, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(center_freq))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(quality_factor))
        CTX.handle_cmd(cmd, serial_size)


class allpass(tf):
    """All-pass filter (phase shaping with unity magnitude).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, val1: float, val2: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewAllPass, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(val1))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(val2))
        CTX.handle_cmd(cmd, serial_size)


class noise(tf):
    """Noise source (uniform or Gaussian).

    Inputs:
        in: input 0
    Outputs:
        noise: output 0
    """

    def __init__(self, value1: float, value2: float, ntype: PP_NoiseType) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (
            PP_FIXED_SIZE
            + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        )
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewNoise, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(value1))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(value2))
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(ntype) & 0xFF)
        CTX.handle_cmd(cmd, serial_size)


class cpuLoad(tf):
    """CPU load measurement block.

    Measures the fraction of each sampling period consumed by the
    design's execution, timed with a cycle-accurate counter on the board.
    No inputs.  Output 0 is the CPU load in percent (0 to 100).
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewCpuLoad, self.getId()
        )
        CTX.handle_cmd(cmd, serial_size)


class extSensor(node):
    """External sensor block, read over SPI or I2C.

    Creates a hardware input node backed by an external sensor. The board
    looks the sensor up by part number to determine how many channels it
    has and how to read it, so the channel count is fixed by the part and
    is not something you set.

    Args:
        hwId:       Hardware route identifier (SPI1..4 or I2C1..4).
        partNumber: One of the sensor parts the board supports; see
                    ``PP_SensorPartNumber``.
        outScale:   Output scaling factor applied to every channel.
    """

    def __init__(self, hwId, partNumber, outScale: float = 1.0) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        # Resolve partNumber from name string if needed
        if isinstance(partNumber, str):
            from .enums import PP_SensorPartNumber
            partNumber = PP_SensorPartNumber[partNumber]

        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 3,
            PP_SubFuncId.NewExtSensor, self.getId()
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(hwId))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(partNumber))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(outScale))
        CTX.handle_cmd(cmd, serial_size)


class compressor(tf):
    """Dynamics compressor with attack, release, threshold, and ratio.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, attack: float, release: float, threshold_db: float, ratio: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewCompressor, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(attack))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(release))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(threshold_db))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(ratio))
        CTX.handle_cmd(cmd, serial_size)


class decibelsConverter(node):
    """Decibels converter: converts a linear signal amplitude to decibels.

    y = 20 * log10(|x|)

    Inputs:
        in: input 0
    Outputs:
        dB: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewDecibelsConverter, self.getId()
        )
        CTX.handle_cmd(cmd, serial_size)


class combFeedForward(tf):
    """Comb filter (feed-forward): H(z) = 1 + gain * z^(-delay).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, delay: int, gain: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 2,
            PP_SubFuncId.NewCombFeedForward, self.getId()
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(delay))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(gain))
        CTX.handle_cmd(cmd, serial_size)


class combFeedBack(tf):
    """Comb filter (feed-back): H(z) = 1 / (1 - gain * z^(-delay)).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, delay: int, gain: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (PP_FIXED_SIZE
                       + PP_PARAM_INFO_SIZE + PP_UINT16_SIZE
                       + PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 2,
            PP_SubFuncId.NewCombFeedBack, self.getId()
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(delay))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(gain))
        CTX.handle_cmd(cmd, serial_size)


class fir(tf):
    """FIR filter designed by windowing method (N, cutoff(s), window, type).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(
        self,
        N: int,
        f1: float,
        f2: Optional[float] = None,
        wt: PP_FirWindowType = PP_FirWindowType.NoFirWindowType,
        ftype: PP_FilterType = PP_FilterType.NoFilterType,
    ) -> None:
        # Accept both calling styles:
        #   fir(N, cutoff_freq, window_type, filter_type)
        #   fir(N, cutoff_freq1, cutoff_freq2, window_type, filter_type)
        #
        # The Python signature mirrors the Arduino overloads, but Studio emits
        # the single-band style as (N, f1, window_type, filter_type). That
        # binds `f2 <- window_type` and `wt <- filter_type`, so fix it here.
        if (
            f2 is not None
            and ftype == PP_FilterType.NoFilterType
            and isinstance(f2, PP_FirWindowType)
            and isinstance(wt, PP_FilterType)
        ):
            ftype = wt
            wt = f2
            f2 = None

        n = _validate_designed_fir_length(N)

        super().__init__()
        subf = _get_fir_subfunc(ftype)
        if subf == PP_SubFuncId.NoSubFuncId:
            return

        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        if f2 is None:
            if subf not in (PP_SubFuncId.NewFirLow, PP_SubFuncId.NewFirHigh):
                return
            serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, n)
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(f1))
            CTX.prepare_param(cmd, 2, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(wt))
            CTX.handle_cmd(cmd, serial_size)
        else:
            if subf not in (PP_SubFuncId.NewFirBand, PP_SubFuncId.NewFirStop):
                return
            serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, subf, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, n)
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(f1))
            CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(f2))
            CTX.prepare_param(cmd, 3, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(wt))
            CTX.handle_cmd(cmd, serial_size)


class CustFir(tf):
    """Custom FIR filter with user-provided coefficients.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, coeff: Sequence[float], taps: int) -> None:
        taps = _validate_custom_fir_taps(coeff, taps)

        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        param1_size = taps * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + param1_size) + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)

        # C++ uses a local PP_CommandInfo Command; emulate by fresh command object.
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewCustFir, self.getId(), use_global_command=False)
        CTX.prepare_param(cmd, 0, param1_size, PP_FuncParamId.TYPE_RealArray, coeff)
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, taps)
        CTX.handle_cmd(cmd, serial_size)


class interpolation(tf):
    """Interpolator block (anti-imaging filter used during interpolation).

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, M_u32: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewInterpolation, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(M_u32))
        CTX.handle_cmd(cmd, serial_size)


class fft(tf):
    """FFT transform. Produces vector output suitable for VectorProbe.

    Inputs:
        signal: input 0
    Outputs:
        spectrum: output 0
    """

    def __init__(self, NbSamples: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewForwardFFT, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(NbSamples))
        CTX.handle_cmd(cmd, serial_size)

        # Firmware exposes N raw float32 in the packed real-FFT layout
        # (Re(X[0]), Re(X[N/2]), Re(X[1]), Im(X[1]), ...).  Match
        # firmware ProbeInfo.{lines=N, rows=1}.
        self.dataLines = int(NbSamples)
        self.dataRaw = 1


class fft_HannWindow(tf):
    """FFT with Hann window. Produces vector output suitable for VectorProbe.

    Inputs:
        signal: input 0
    Outputs:
        spectrum: output 0
    """

    def __init__(self, NbSamples: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewForwardFFT_HannWindow, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(NbSamples))
        CTX.handle_cmd(cmd, serial_size)

        # Same packing as fft (packed real-FFT).  See note on fft.
        self.dataLines = int(NbSamples)
        self.dataRaw = 1


class fftMagResolver(tf):
    """Magnitude spectrum resolver from an FFT block.

    Inputs:
        fft: input 0
    Outputs:
        magnitude: output 0
    """

    def __init__(self, fft_instance: Union[fft, fft_HannWindow]) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewFftResolver, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, fft_instance.getId())
        CTX.handle_cmd(cmd, serial_size)

        # Firmware writes N/2+1 magnitudes (DC + Nyquist + N/2-1
        # interior bins).  Legacy host used N//2 (off by one), which
        # made VectorProbe-on-FFT_MAG mis-split by 4 bytes against
        # the firmware descriptor and the panel went blank.
        self.dataLines = (int(fft_instance.dataLines) >> 1) + 1
        self.dataRaw = 1


class fft_phaseResolver(tf):
    """Phase spectrum resolver from an FFT block.

    Inputs:
        fft: input 0
    Outputs:
        phase: output 0
    """

    def __init__(self, fft_instance: Union[fft, fft_HannWindow]) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewPhaseResolver, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, fft_instance.getId())
        CTX.handle_cmd(cmd, serial_size)

        # Same N/2+1 layout as the magnitude resolver.
        self.dataLines = (int(fft_instance.dataLines) >> 1) + 1
        self.dataRaw = 1


class dwt(tf):
    """Discrete Wavelet Transform. Produces coefficient vector output.

    Inputs:
        signal: input 0
    Outputs:
        coeffs: output 0
    """

    def __init__(self, signal_length: int, wavelet_type: PP_WaveletType, levels: int, sampling_rate: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        self.signal_length = int(signal_length)
        self.wavelet_type = wavelet_type
        self.levels = int(levels)
        self.sampling_rate = float(sampling_rate)
        self.nbSamples = int(signal_length)

        serial_size = PP_FIXED_SIZE + 4 * PP_PARAM_INFO_SIZE + 3 * PP_UINT16_SIZE + PP_REAL_SIZE
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewDWT, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, self.signal_length)
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(wavelet_type))
        CTX.prepare_param(cmd, 2, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, self.levels)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, self.sampling_rate)
        CTX.handle_cmd(cmd, serial_size)

        # Firmware exposes the in-place transform buffer as N float32
        # (approximation + detail subbands packed sequentially).
        self.dataLines = int(signal_length)
        self.dataRaw = 1

    def getNbSamples(self) -> int:
        return self.nbSamples


class idwt(tf):
    """Inverse DWT associated with a given DWT instance.

    Inputs:
        coeffs: input 0
    Outputs:
        signal: output 0
    """

    def __init__(self, associated_dwt: dwt) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        self.associatedDWT = associated_dwt
        self.nbSamples = associated_dwt.getNbSamples()

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewIDWT, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, associated_dwt.getId())
        CTX.handle_cmd(cmd, serial_size)

        # Firmware writes a full N-sample reconstruction per cycle.
        self.dataLines = int(self.nbSamples)
        self.dataRaw = 1

    def getNbSamples(self) -> int:
        return self.nbSamples


class amOscillator(tf):
    """AM-modulated periodic oscillator. Amplitude is wired as an input port.

    Distinct from ``signalSource``: this block's amplitude comes from a runtime
    signal (the ``amplitude`` input), not a parameter. Reach for it when the
    amplitude must be modulated by another block: AM, gain control, envelope.
    For a static-amplitude generator with 17 shapes / run modes / triggers,
    use ``signalSource`` instead.

    Inputs:
        amplitude: input 0 (runtime, multiplied into the output)
    Outputs:
        out: output 0
    """

    def __init__(self, waveform: PP_WaveForm, freq: float, phaseshift: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        # Two real params on the wire: frequency, phase shift.
        # The shape (Sine/Tri/Sqr/Saw) is encoded in the subfunc id: the
        # board has one sub-function per shape, and the id is what selects
        # it.
        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size,
            PP_FuncId.Createblock,
            2,
            PP_SubFuncId(int(waveform)),
            self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(freq))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(phaseshift))
        CTX.handle_cmd(cmd, serial_size)


def _resolve_wave_shape(v) -> PP_WaveShape:
    if isinstance(v, PP_WaveShape):
        return v
    if isinstance(v, str):
        try:
            return PP_WaveShape[v]
        except KeyError:
            raise ValueError(f"Unknown signalSource shape '{v}'")
    return PP_WaveShape(int(v))


def _resolve_wave_mode(v) -> PP_WaveMode:
    if isinstance(v, PP_WaveMode):
        return v
    if isinstance(v, str):
        try:
            return PP_WaveMode[v]
        except KeyError:
            raise ValueError(f"Unknown signalSource mode '{v}'")
    return PP_WaveMode(int(v))


def _resolve_wave_trig_pol(v) -> PP_WaveTrigPol:
    if isinstance(v, PP_WaveTrigPol):
        return v
    if isinstance(v, str):
        try:
            return PP_WaveTrigPol[v]
        except KeyError:
            raise ValueError(f"Unknown signalSource trig_pol '{v}'")
    return PP_WaveTrigPol(int(v))


def _resolve_multisine_phase(v) -> int:
    if isinstance(v, PP_WaveMultisinePhase):
        return int(v)
    if isinstance(v, str):
        try:
            return int(PP_WaveMultisinePhase[v])
        except KeyError:
            raise ValueError(f"Unknown multisine phase_scheme '{v}'")
    return int(v)


class signalSource(tf):
    """Unified signal generator: every modern waveform shape + mode in one block.

    Pair with ``amOscillator`` (the AM-input oscillator) when amplitude must
    come from another block at runtime; ``signalSource``
    takes amplitude as a static parameter but offers 17 shapes plus run
    modes (Perpetual / RepeatN / OneShot / TrigEdge / TrigGate) and an
    optional trigger input.

    Constructor (full form)::

        signalSource(
            shape       = PP_WaveShape.Sine,
            mode        = PP_WaveMode.Perpetual,
            n_periods   = 0,                       # used by RepeatN/TrigEdge
            trig_pol    = PP_WaveTrigPol.Rising,   # used by Trig* modes
            amplitude   = 1.0,
            offset      = 0.0,
            **shape_kwargs,                        # shape-specific params
        )

    Ergonomic factory helpers (one per shape) are documented at the end of
    this class; they fill in sensible defaults so simple cases stay short::

        signalSource.sine(freq=50)
        signalSource.chirp_linear(f0=100, f1=2000, t_sweep=0.5)
        signalSource.step(t_step=0.1, value_before=0, value_after=1)
        signalSource.prbs(bits=9, lfsr_seed=0xACE1)

    Outputs:
        out: the generated waveform (one float per host sample period)

    Inputs:
        (none) in Perpetual/RepeatN/OneShot modes
        trigger: input 0 in TrigEdge/TrigGate modes; values > 0.5 are "high"

    See ``papaya/signal_source.py`` for the wire-encoding scheme + the
    NumPy reference compute that the firmware mirrors exactly.
    """

    def __init__(
        self,
        shape: PP_WaveShape = PP_WaveShape.Sine,
        mode: PP_WaveMode = PP_WaveMode.Perpetual,
        n_periods: int = 0,
        trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising,
        amplitude: float = 1.0,
        offset: float = 0.0,
        **shape_kwargs,
    ) -> None:
        # Studio codegen passes a single dict positional arg
        # (the canvas parameters block). Unpack it transparently so the
        # same constructor works for ergonomic Python AND the codegen path.
        from_studio_dict = isinstance(shape, dict)
        if from_studio_dict:
            cfg = dict(shape)
            shape       = cfg.pop("shape",       PP_WaveShape.Sine)
            mode        = cfg.pop("mode",        PP_WaveMode.Perpetual)
            n_periods   = cfg.pop("n_periods",   0)
            trig_pol    = cfg.pop("trig_pol",    PP_WaveTrigPol.Rising)
            amplitude   = cfg.pop("amplitude",   1.0)
            offset      = cfg.pop("offset",      0.0)
            shape_kwargs = cfg

        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        # Resolve enums passed as plain ints / strings (common from
        # reverse-decoders and Studio canvas params).
        shape    = _resolve_wave_shape(shape)
        mode     = _resolve_wave_mode(mode)
        trig_pol = _resolve_wave_trig_pol(trig_pol)
        if "phase_scheme" in shape_kwargs:
            shape_kwargs["phase_scheme"] = _resolve_multisine_phase(shape_kwargs["phase_scheme"])

        # Shape 17 (Dataset) is retired on the board: it named a flash slot
        # and the runtime played the slot in place, and that path no longer
        # exists, so the board refuses the create with BadParam and the user
        # would see only a generic failure. Refuse here instead, before the
        # wire, with the replacement named. Only the direct construction
        # path refuses: Studio's canvas-dict path is exempt because its two
        # lanes are already split correctly upstream (the board lane arrives
        # here as Arbitrary with the samples inline; the simulation lane
        # legitimately keeps this small command form and hands the samples
        # to the simulator out of band, at any length).
        if shape == PP_WaveShape.Dataset and not from_studio_dict:
            raise ValueError(
                "signalSource shape=Dataset cannot be created: the board "
                "retired flash-slot playback (shape 17) and refuses it. Pass "
                "the recording's samples to signalSource.dataset(samples) "
                "instead; they travel inside the create command as the "
                "block's own lookup table, up to PP_WAVE_ARB_MAX_SAMPLES "
                "samples.")

        from . import signal_source as _ss
        specs = _ss.build_param_specs(
            shape=shape, mode=mode, trig_pol=trig_pol, n_periods=n_periods,
            amplitude=amplitude, offset=offset, shape_kwargs=shape_kwargs,
        )

        # Compute serial size: PP_FIXED_SIZE header + Σ(PP_PARAM_INFO_SIZE + size)
        body_bytes = sum(PP_PARAM_INFO_SIZE + s for (_n, _t, s, _v) in specs)
        serial_size = PP_FIXED_SIZE + body_bytes

        cmd = CTX.prepare_cmd_header(
            serial_size,
            PP_FuncId.Createblock,
            len(specs),
            PP_SubFuncId.NewSignalSource,
            self.getId(),
        )
        for idx, (_name, ptype, size, value) in enumerate(specs):
            CTX.prepare_param(cmd, idx, size, ptype, value)
        CTX.handle_cmd(cmd, serial_size)

        # Remember the config so reverse-decoders / Easy DLP can introspect it.
        self.shape = shape
        self.mode = mode
        self.trig_pol = trig_pol
        self.n_periods = int(n_periods)
        self.amplitude = float(amplitude)
        self.offset = float(offset)
        self.shape_params = {n: v for (n, _t, _s, v) in specs[6:]}

    # ------------------------------------------------------------------
    # Ergonomic factories: short forms for every shape
    # ------------------------------------------------------------------
    @classmethod
    def sine(cls, freq: float, phase: float = 0.0, *,
             amplitude: float = 1.0, offset: float = 0.0,
             mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
             trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Sine, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase)

    @classmethod
    def square(cls, freq: float, phase: float = 0.0, *,
               amplitude: float = 1.0, offset: float = 0.0,
               mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
               trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Square, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase)

    @classmethod
    def triangle(cls, freq: float, phase: float = 0.0, symmetry: float = 0.5, *,
                 amplitude: float = 1.0, offset: float = 0.0,
                 mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                 trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Triangle, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, symmetry=symmetry)

    @classmethod
    def sawtooth(cls, freq: float, phase: float = 0.0, direction: int = 0, *,
                 amplitude: float = 1.0, offset: float = 0.0,
                 mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                 trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Sawtooth, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, direction=direction)

    @classmethod
    def pulse(cls, freq: float, duty: float, phase: float = 0.0, *,
              amplitude: float = 1.0, offset: float = 0.0,
              mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
              trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Pulse, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, duty=duty)

    @classmethod
    def sinc(cls, freq: float, n_lobes: int = 5, phase: float = 0.0, *,
             amplitude: float = 1.0, offset: float = 0.0,
             mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
             trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Sinc, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, n_lobes=n_lobes)

    @classmethod
    def gauspuls(cls, freq: float, bw_fraction: float = 0.5, prf: float = 10.0, *,
                 amplitude: float = 1.0, offset: float = 0.0,
                 mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                 trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Gauspuls, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, bw_fraction=bw_fraction, prf=prf)

    @classmethod
    def dc(cls, value: float = 0.0, *, amplitude: float = 1.0,
           offset: Optional[float] = None,
           mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
           trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        # DC output = the constant `offset`. ``value`` is the DC level; an
        # explicit ``offset`` (e.g. emitted by the code generator, which passes
        # both) takes precedence. The firmware ignores ``amplitude`` for DC.
        # Accepting the same kwargs as the other factories keeps the generated-
        # code renderer uniform (it appends amplitude=/offset=/mode= to every
        # shape); without them this raised "unexpected keyword argument".
        off = value if offset is None else offset
        return cls(PP_WaveShape.DC, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=off)

    @classmethod
    def arbitrary(cls, samples: Sequence[float], freq: Optional[float] = None,
                  phase: float = 0.0, *,
                  amplitude: float = 1.0, offset: float = 0.0,
                  mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                  trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        """Play a lookup table of up to
        :data:`~papaya.signal_source.PP_WAVE_ARB_MAX_SAMPLES` samples.

        ``freq`` is how many times a second the table is traversed. Omit it
        for a recording: a recording has one natural speed, so leaving it
        out plays the table once over its own duration, ``Fs / N``, worked
        out from the sampling frequency ``startDesign`` was given and the
        length of ``samples``. Give it when the table is a waveform you
        designed and the rate is part of the signal, as it is for
        :meth:`sine`.
        """
        from .signal_source import dataset_playback_freq

        table = list(samples)
        if freq is None:
            fs = float(CTX.sampling_freq_hz or 0.0)
            if fs <= 0:
                raise ValueError(
                    "the design has no sampling frequency yet, so this "
                    "table's traversal rate cannot be worked out. Call "
                    "startDesign() before creating blocks, or pass freq=.")
            if not table:
                raise ValueError("an Arbitrary table needs at least one sample")
            freq = dataset_playback_freq(len(table), fs)
        return cls(PP_WaveShape.Arbitrary, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, samples=table)

    @classmethod
    def chirp_linear(cls, f0: float, f1: float, t_sweep: float, phase: float = 0.0, *,
                     amplitude: float = 1.0, offset: float = 0.0,
                     mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
                     trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.LinearChirp, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   f0=f0, f1=f1, t_sweep=t_sweep, phase=phase)

    @classmethod
    def chirp_log(cls, f0: float, f1: float, t_sweep: float, phase: float = 0.0, *,
                  amplitude: float = 1.0, offset: float = 0.0,
                  mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
                  trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.LogChirp, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   f0=f0, f1=f1, t_sweep=t_sweep, phase=phase)

    @classmethod
    def multisine(cls, f0: float, df: float, n_lines: int = 8,
                  phase_scheme: PP_WaveMultisinePhase = PP_WaveMultisinePhase.Schroeder,
                  lfsr_seed: int = 0xACE1, *,
                  amplitude: float = 1.0, offset: float = 0.0,
                  mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                  trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Multisine, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   f0=f0, df=df, n_lines=n_lines,
                   phase_scheme=int(phase_scheme), lfsr_seed=lfsr_seed)

    @classmethod
    def prbs(cls, bits: int = 9, clock_div: int = 1, lfsr_seed: int = 0xACE1, *,
             amplitude: float = 1.0, offset: float = 0.0,
             mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
             trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.PRBS, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   bits=bits, clock_div=clock_div, lfsr_seed=lfsr_seed)

    @classmethod
    def step(cls, t_step: float, value_before: float = 0.0, value_after: float = 1.0, *,
             amplitude: float = 1.0, offset: float = 0.0,
             mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
             trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Step, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   t_step=t_step, value_before=value_before, value_after=value_after)

    @classmethod
    def ramp(cls, slope: float, t_start: float = 0.0,
             sat_low: float = -1.0e9, sat_high: float = 1.0e9, *,
             amplitude: float = 1.0, offset: float = 0.0,
             mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
             trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Ramp, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   slope=slope, t_start=t_start, sat_low=sat_low, sat_high=sat_high)

    @classmethod
    def impulse(cls, t_impulse: float = 0.0, *,
                amplitude: float = 1.0, offset: float = 0.0,
                mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
                trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.Impulse, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   t_impulse=t_impulse)

    @classmethod
    def pulse_train(cls, freq: float, duty: float, n_pulses: int, prf: float,
                    phase: float = 0.0, *,
                    amplitude: float = 1.0, offset: float = 0.0,
                    mode: PP_WaveMode = PP_WaveMode.OneShot, n_periods: int = 1,
                    trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        return cls(PP_WaveShape.PulseTrain, mode=mode, n_periods=n_periods,
                   trig_pol=trig_pol, amplitude=amplitude, offset=offset,
                   freq=freq, phase=phase, duty=duty, n_pulses=n_pulses, prf=prf)

    @classmethod
    def dataset(cls, samples: Sequence[float], *, phase: float = 0.0,
                amplitude: float = 1.0, offset: float = 0.0,
                mode: PP_WaveMode = PP_WaveMode.Perpetual, n_periods: int = 0,
                trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising) -> "signalSource":
        """Play a recording. Hand it the samples; that is the whole call.

        ONE command reaches the board: the recording travels as the block's
        own lookup table, inside the create command. Nothing is uploaded
        first, so there is no slot to name, no upload to order and no step to
        forget::

            src = signalSource.dataset(MY_RECORDING)

        **It asks for nothing it can work out.** No name: the block has an id,
        assigned here. No sample rate: the samples are fed to the graph one
        per tick, so the rate they play at IS the design's. And no frequency,
        which is where a recording differs from every generated shape: for
        :meth:`sine` a frequency IS the signal and you choose it, while a
        recording plays once over its own duration, so the traversal rate is
        ``Fs / N`` and follows from the recording.

        The parameters it does take are the ones a recording genuinely has:
        ``amplitude`` and ``offset`` scale and shift it, ``mode``,
        ``n_periods`` and ``trig_pol`` control repetition and triggering, and
        ``phase`` starts playback part-way in.

        **The one restriction is the board's fast heap.** The board copies
        the samples into that heap and iterates them there, because a
        table read every tick belongs in fast memory, so a recording is at
        most :data:`~papaya.signal_source.PP_WAVE_ARB_MAX_SAMPLES` samples,
        20 KB of the 110 KB that heap has. A longer recording is not a board
        design; it is a simulation, where the heap is the host machine's.

        This is the same call as :meth:`arbitrary` with the rate left out.
        The two differ only in what the caller means: a table you designed
        has a frequency you chose, a recording does not.
        """
        return cls.arbitrary(samples, None, phase, amplitude=amplitude,
                             offset=offset, mode=mode, n_periods=n_periods,
                             trig_pol=trig_pol)


class sineAm(macro):
    """Measures amplitude of a sine wave at a given frequency.

    Inputs:
        signal: input 0
    Outputs:
        amplitude: output 0
    """

    def __init__(self, sineFreq: float) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewSineAm, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(sineFreq))
        CTX.handle_cmd(cmd, serial_size)


class pid(tf):
    """PI/PD/PID controller depending on constructor used.

    Inputs:
        error: input 0
    Outputs:
        command: output 0
    """

    def __init__(self, ki: float, kp: float, kd: float, tau: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewPid, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(ki))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(kp))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(kd))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(tau))
        CTX.handle_cmd(cmd, serial_size)


class livePid(macro):
    """Live PID controller (gains tunable via inputs).

    Inputs:
        error: input 0
        Kp: input 1
        Ki: input 2
        Kd: input 3
        Tau: input 4
    Outputs:
        command: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewTunePID, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class livePi(macro):
    """Live PI controller (gains tunable via inputs).

    Inputs:
        error: input 0
        Kp: input 1
        Ki: input 2
    Outputs:
        command: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewTunePI, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class livePd(macro):
    """Live PD controller (gains tunable via inputs).

    Inputs:
        error: input 0
        Kp: input 1
        Kd: input 2
        Tau: input 3
    Outputs:
        command: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewTunePD, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class pidAw(node):
    """PI/PID controller that limits its own output and holds its integral
    term in check while the output sits at a limit.

    Below the limits this is exactly the controller ``pid`` is, sample for
    sample: the integrator and the derivative filter use the same
    discretisation algorithm the design was started with, and the
    anti-windup correction is driven by the difference between the
    clamped and unclamped command, which is exactly zero while nothing is
    being clamped.

    Args:
        ki: integral gain. Must not be zero. A controller with no integral
            term cannot wind up, so clamp its output with ``sat`` instead.
        kp: proportional gain.
        kd: derivative gain. Zero gives a PI controller.
        tau: derivative-filter time constant, in seconds. Only used when
            ``kd`` is non-zero, and must then be positive.
        u_min: lowest command the actuator accepts, in this controller's
            own output units.
        u_max: highest command the actuator accepts.
        Tt: recovery time constant, in seconds. Only used by
            back-calculation. The usual choice is the geometric mean of
            the integral time Kp/Ki and the derivative time Kd/Kp for a
            PID, and the integral time for a PI.
        mode: 1 back-calculation, 2 conditional integration, 3 integrator
            clamp.

    Inputs:
        error: input 0
    Outputs:
        command: output 0
        saturated: output 1, present only when report is 1. Reads 1.0 on
            any sample where the clamp changed the command, and 0.0
            otherwise. That is not the same as the command being at a
            limit: in integrator-clamp mode the integral term is held
            back so the command reaches the limit without needing to be
            clipped, and the flag then reads 0.0 while the command sits
            on it. In back-calculation the two agree sample for sample.
    """

    def __init__(self, ki: float, kp: float, kd: float, tau: float,
                 u_min: float, u_max: float, Tt: float,
                 mode: int = 1, report: int = 0) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (PP_FIXED_SIZE
                       + 7 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                       + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 9,
                                     PP_SubFuncId.NewPidAw, self.getId())
        for idx, value in enumerate((ki, kp, kd, tau, u_min, u_max, Tt)):
            CTX.prepare_param(cmd, idx, PP_REAL_SIZE,
                              PP_FuncParamId.TYPE_Real, float(value))
        CTX.prepare_param(cmd, 7, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(mode))
        CTX.prepare_param(cmd, 8, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(bool(report)))
        CTX.handle_cmd(cmd, serial_size)


class livePidAw(node):
    """Live PID controller with anti-windup: gains, limits and the recovery
    time constant all arrive as signals.

    Everything the controller needs is a port, so all of it can be moved
    while the design is running by wiring ``input`` blocks and writing to
    them.

    The port count depends on ``mode``, because a recovery time constant
    only means something to back-calculation. Offering the port in the
    other two modes would be offering a control that does nothing.

    Args:
        mode: 1 back-calculation (8 inputs), 2 conditional integration
            (7 inputs), 3 integrator clamp (7 inputs).

    Inputs:
        error: input 0
        Kp: input 1
        Ki: input 2
        Kd: input 3
        Tau: input 4
        out_max: input 5
        out_min: input 6
        Tt: input 7, back-calculation only
    Outputs:
        command: output 0
        saturated: output 1, present only when report is 1. Same
            meaning as pidAw's: 1.0 on a sample where the clamp
            changed the command, which in integrator-clamp mode
            is not the same as the command being at a limit.
    """

    def __init__(self, mode: int = 1, report: int = 0) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        serial_size = (PP_FIXED_SIZE
                       + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2,
                                     PP_SubFuncId.NewTunePIDAw, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(mode))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(bool(report)))
        CTX.handle_cmd(cmd, serial_size)


class livePiAw(node):
    """Live PI controller with anti-windup.

    Inputs:
        error: input 0
        Kp: input 1
        Ki: input 2
        out_max: input 3
        out_min: input 4
        Tt: input 5, back-calculation only
    Outputs:
        command: output 0
        saturated: output 1, present only when report is 1. Same
            meaning as pidAw's: 1.0 on a sample where the clamp
            changed the command, which in integrator-clamp mode
            is not the same as the command being at a limit.
    """

    def __init__(self, mode: int = 1, report: int = 0) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        serial_size = (PP_FIXED_SIZE
                       + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2,
                                     PP_SubFuncId.NewTunePIAw, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(mode))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(bool(report)))
        CTX.handle_cmd(cmd, serial_size)


class live2PidAw(node):
    """2-DOF live PID controller with anti-windup.

    Inputs:
        ref: input 0
        meas: input 1
        kp: input 2
        ki: input 3
        kd: input 4
        tau: input 5
        b: input 6
        c: input 7
        out_max: input 8
        out_min: input 9
        Tt: input 10, back-calculation only
    Outputs:
        command: output 0
        saturated: output 1, present only when report is 1. Same
            meaning as pidAw's: 1.0 on a sample where the clamp
            changed the command, which in integrator-clamp mode
            is not the same as the command being at a limit.
    """

    def __init__(self, mode: int = 1, report: int = 0) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        serial_size = (PP_FIXED_SIZE
                       + 2 * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2,
                                     PP_SubFuncId.NewTune2PIDAw, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(mode))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE,
                          PP_FuncParamId.TYPE_Uint8, int(bool(report)))
        CTX.handle_cmd(cmd, serial_size)


class live2Pid(macro):
    """2-DOF Live PID controller.

    Inputs:
        ref: input 0
        meas: input 1
        ki: input 2
        kp: input 3
        kd: input 4
        tau: input 5
        b: input 6
        c: input 7
    Outputs:
        command: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewTune2PID, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class mag2(node):
    """2D magnitude (sqrt(x^2 + y^2)).

    Inputs:
        x: input 0
        y: input 1
    Outputs:
        mag: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewMag2, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class mag3(node):
    """3D magnitude (sqrt(x^2 + y^2 + z^2)).

    Inputs:
        x: input 0
        y: input 1
        z: input 2
    Outputs:
        mag: output 0
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewMag3, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class delayop(tf):
    """Delay operator delaying signal by N samples.

    Inputs:
        in: input 0
    Outputs:
        delayed: output 0
    """

    def __init__(self, NbrOfSamples: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewDelayOp, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(NbrOfSamples))
        CTX.handle_cmd(cmd, serial_size)


class movingAverage(tf):
    """Moving average filter (sliding window).

    Inputs:
        in: input 0
    Outputs:
        avg: output 0
    """

    def __init__(self, NbrOfSamples: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMovingAverage, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(NbrOfSamples))
        CTX.handle_cmd(cmd, serial_size)


class absMax(tf):
    """Sliding-window absolute maximum.

    Inputs:
        in: input 0
    Outputs:
        abs_max: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewAbsMax, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class absMin(tf):
    """Sliding-window absolute minimum.

    Inputs:
        in: input 0
    Outputs:
        abs_min: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewAbsMin, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class entropy(tf):
    """Sliding-window entropy measure.

    Inputs:
        in: input 0
    Outputs:
        entropy: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewEntropy, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class mean(tf):
    """Sliding-window mean (average).

    Inputs:
        in: input 0
    Outputs:
        mean: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMean, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class maximum(tf):
    """Sliding-window maximum.

    Inputs:
        in: input 0
    Outputs:
        max: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMaximum, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class minimum(tf):
    """Sliding-window minimum.

    Inputs:
        in: input 0
    Outputs:
        min: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMinimum, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(Length))
        CTX.handle_cmd(cmd, serial_size)


def _check_window_length(Length: int, block: str) -> int:
    """Validate a sliding-window length sent as a firmware ``uint8_t``.

    The statistics blocks (variance/std/RMS/power) take the window length
    as a ``uint8_t`` and reject ``Length == 0``. Without this guard a
    caller passing 256 would be silently masked to 0 by the wire encoder
    (memcpy semantics) and the board would reject the createblock at runtime
    with an opaque BadParam, caught here at construction with a clear message.
    """
    n = int(Length)
    if not (1 <= n <= 255):
        raise ValueError(
            f"{block} window length must be 1..255 (firmware uint8_t); got {Length}."
        )
    return n


class power(tf):
    """Sliding-window power (mean-square) measure.

    Inputs:
        in: input 0
    Outputs:
        power: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        Length = _check_window_length(Length, "power")
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewPower, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class rootMeanSquare(tf):
    """Sliding-window RMS.

    Inputs:
        in: input 0
    Outputs:
        rms: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        Length = _check_window_length(Length, "rootMeanSquare")
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewRootMeanSquare, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class standardDeviation(tf):
    """Sliding-window standard deviation.

    Inputs:
        in: input 0
    Outputs:
        std_dev: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        Length = _check_window_length(Length, "standardDeviation")
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewStandardDeviation, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class variance(tf):
    """Sliding-window variance.

    Inputs:
        in: input 0
    Outputs:
        variance: output 0
    """

    def __init__(self, Length: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        Length = _check_window_length(Length, "variance")
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewVariance, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Length))
        CTX.handle_cmd(cmd, serial_size)


class period(tf):
    """Measures signal period by timing intervals between detected edges.

    Inputs:
        signal: input 0
    Outputs:
        period: output 0
    """

    def __init__(self, Max: float, Min: float, Epsilon: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewPeriodMeter, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Max))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Min))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Epsilon))
        CTX.handle_cmd(cmd, serial_size)


class UpDwnperiod(tf):
    """Measures up/down period characteristics of a signal.

    Inputs:
        signal: input 0
    Outputs:
        period: output 0
    """

    def __init__(self, Max: float, Min: float, Epsilon: float) -> None:
        # Declared in header, not implemented in PAPAYA.cpp. Implemented here based on obvious pattern.
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewUpDwnPeriodMeter, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Max))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Min))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Epsilon))
        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Hardware I/O nodes
# -----------------------------------------------------------------------------

class analogIn(node):
    """Analog input block. Supports single or multiple hardware channels with scaling and offset.

    Args:
        id_or_cfg: An analog input identifier (``AIN1``..``AIN10``), or a list
            of ``PP_anInCfg`` for the multi-channel form.
        outScale: Units per volt. The channel already reads VOLTS over -10 V
            to +10 V before this is applied, so ``1.0`` gives volts; set it
            only to express the reading in the sensor's own units. ``0`` is
            accepted and parks the block at ``offset`` for ever, which looks
            exactly like a dead sensor. PAPAYA Studio warns about that; this
            library does not.
        offset: Added AFTER the scaling, in the same units as the result: the
            value the block reports at 0 V.

    Outputs:
        value: output 0, ``volts * outScale + offset``
    """

    def __init__(self, id_or_cfg: Union[PP_HwId, Sequence[PP_anInCfg]], outScale: Optional[float] = None, offset: Optional[float] = None, items: Optional[int] = None) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        # Single (id, outScale, offset)
        if isinstance(id_or_cfg, PP_HwId):
            if outScale is None or offset is None:
                raise TypeError("analogIn(PP_HwId, outScale, offset) requires outScale and offset")
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewHwInput, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(id_or_cfg))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(outScale))
            CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(offset))
            CTX.handle_cmd(cmd, serial_size)
            return

        # List of configs
        cfg_list = list(id_or_cfg)
        if items is None:
            items = len(cfg_list)
        if items <= 0:
            raise ValueError("items must be > 0")

        # Param sizes
        ids_size = items * PP_UINT16_SIZE
        out_scale_size = items * PP_REAL_SIZE
        offset_size = items * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + 3 * PP_PARAM_INFO_SIZE + ids_size + out_scale_size + offset_size

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewHwInput, self.getId())
        CTX.prepare_param(cmd, 0, ids_size, PP_FuncParamId.TYPE_Uint16Array, [int(c.id) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 1, out_scale_size, PP_FuncParamId.TYPE_RealArray, [float(c.outScale) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 2, offset_size, PP_FuncParamId.TYPE_RealArray, [float(c.offset) for c in cfg_list[:items]])
        CTX.handle_cmd(cmd, serial_size)


class pwmIn(node):
    """PWM input measurement block supporting pulse, period, or delay acquisition.

    The output is a TIME IN SECONDS, always. Which time depends on the
    identifier: ``FI1_PULSE``..``FI5_PULSE`` give the pulse high time,
    ``FI1_PERIOD``..``FI5_PERIOD`` the full period, ``FI1_DELAY``..``FI5_DELAY``
    the interval between the two edges. Nothing multiplies it; convert to your
    own units downstream (period to RPM is a reciprocal then a gain of 60).

    Args:
        id_or_cfg: A frequency-input identifier, or a list of ``PP_pwmInCfg``
            for the multi-channel form. It must be a frequency input: ``0`` is
            ``MOTOR1``, and the board refuses the design with a bad-parameter
            status.
        outScale: The measurement RANGE, in seconds - the longest interval this
            channel can time. It is NOT a multiplier and never changes the
            value on the output port. ``1.0`` measures up to one second; use
            ``0.01`` for millisecond-scale pulses. Too small and a long
            interval wraps and reads short; too large and a short one is timed
            coarsely. Neither is reported.

    Outputs:
        value: output 0, the measured interval in seconds.
        period: output 1, present only on a ``FIn_PULSE`` or ``FIn_DELAY``
            identifier: the full period of the same signal, in seconds. A
            ``FIn_PERIOD`` identifier has output 0 alone.

    Wire EVERY output the block has. The board starts a block only once every
    one of its outputs is connected, so on a pulse or delay identifier both
    ``out(0)`` and ``out(1)`` must go somewhere, a consumer or a probe. Leaving
    ``out(1)`` unwired keeps the whole block out of the run: the design still
    uploads, the board still reports success, and ``out(0)`` reads 0.0 for as
    long as the design runs. Nothing reports it, because the board's check for
    unconnected outputs only inspects blocks that are already running.

    A design built in PAPAYA Studio's Model Builder has one port per configured
    channel, so pulse-width and edge-delay capture does not work from a diagram,
    nor from a program generated out of one. Measure the period there, or write
    the program by hand and wire both outputs::

        cap = pwmIn(PP_HwId.FI1_PULSE, 0.01)
        cap.out(0) > high_time_probe      # the pulse width, in seconds
        cap.out(1) > period_probe         # the period of the same signal
    """

    def __init__(self, id_or_cfg: Union[PP_HwId, Sequence[PP_pwmInCfg]], outScale: Optional[float] = None, items: Optional[int] = None) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        if isinstance(id_or_cfg, PP_HwId):
            if outScale is None:
                raise TypeError("pwmIn(PP_HwId, outScale) requires outScale")
            outs = _outputs_per_hw_input(id_or_cfg)
            self.dataLines = outs
            self.dataRaw = 1

            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewHwInput, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(id_or_cfg))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(outScale))
            CTX.handle_cmd(cmd, serial_size)
            return

        cfg_list = list(id_or_cfg)
        if items is None:
            items = len(cfg_list)
        if items <= 0:
            raise ValueError("items must be > 0")

        total_outs = sum(_outputs_per_hw_input(c.id) for c in cfg_list[:items])
        self.dataLines = total_outs
        self.dataRaw = 1

        ids_size = items * PP_UINT16_SIZE
        out_scale_size = items * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + 2 * PP_PARAM_INFO_SIZE + ids_size + out_scale_size

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewHwInput, self.getId())
        CTX.prepare_param(cmd, 0, ids_size, PP_FuncParamId.TYPE_Uint16Array, [int(c.id) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 1, out_scale_size, PP_FuncParamId.TYPE_RealArray, [float(c.outScale) for c in cfg_list[:items]])
        CTX.handle_cmd(cmd, serial_size)


class pwmOut(node):
    """PWM output block driving hardware channels with configurable frequency and duty-cycle limits.

    The signal on the duty port and both limits are the same dimensionless
    FRACTION of the carrier period: 0.0 is off, 1.0 is fully on. Nothing
    converts a percentage anywhere, in either library or on the board, so 95
    does not mean 95 percent, it means ninety-five times full scale and holds
    the pin permanently on.

    Ranges the board can honour. PAPAYA Studio refuses a design outside these
    before it is deployed; this library does not check them, so a program that
    builds a design directly has to respect them itself.

    ===================================  =============================
    Parameter                            Range
    ===================================  =============================
    ``frequency``                        0.06403 Hz to 137500000 Hz
    ``dutyLowerLimit``, ``dutyUpperLimit``  0.0 to 1.0
    ===================================  =============================

    Outside the frequency span the board runs the channel at a DIFFERENT
    frequency and reports nothing; at or below 0 the timer never starts. The
    carrier is built from whole ticks of a 275 MHz timebase and every channel
    counts to 16 bits, so the number of duty steps falls as the frequency
    rises: about 55000 at 1 kHz, 13750 at 20 kHz, 275 at 1 MHz.

    Args:
        id_or_cfg: A frequency output identifier (``FO1``..``FO8``), or a list
            of ``PP_pwmOutCfg`` for the multi-channel form. One block per
            channel: a second block on the same channel overwrites the first
            one's configuration, and nothing on the board reports it.
        frequency: Carrier frequency in HERTZ, fixed for the life of the
            design.
        dutyLowerLimit: Lower clamp on the duty port, as a fraction in 0.0 to
            1.0. The clamp is applied before the timer, so the load is
            protected but the block driving the port is told nothing about the
            saturation.
        dutyUpperLimit: Upper clamp, same fraction and range. Must not be
            below ``dutyLowerLimit``: the board swaps a reversed pair silently
            and runs a window nobody asked for. Equal limits are legal and pin
            the output at that duty.

    Inputs:
        duty: input 0, a fraction of the carrier period
    """

    def __init__(
        self,
        id_or_cfg: Union[PP_HwId, Sequence[PP_pwmOutCfg]],
        frequency: Optional[float] = None,
        dutyLowerLimit: Optional[float] = None,
        dutyUpperLimit: Optional[float] = None,
        items: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        if isinstance(id_or_cfg, PP_HwId):
            if frequency is None or dutyLowerLimit is None or dutyUpperLimit is None:
                raise TypeError("pwmOut(PP_HwId, frequency, dutyLowerLimit, dutyUpperLimit) requires all parameters")
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewHwOutput, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(id_or_cfg))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(frequency))
            CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(dutyLowerLimit))
            CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(dutyUpperLimit))
            CTX.handle_cmd(cmd, serial_size)
            return

        cfg_list = list(id_or_cfg)
        if items is None:
            items = len(cfg_list)
        if items <= 0:
            raise ValueError("items must be > 0")

        ids_size = items * PP_UINT16_SIZE
        freq_size = items * PP_REAL_SIZE
        dll_size = items * PP_REAL_SIZE
        dul_size = items * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + 4 * PP_PARAM_INFO_SIZE + ids_size + freq_size + dll_size + dul_size

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewHwOutput, self.getId())
        CTX.prepare_param(cmd, 0, ids_size, PP_FuncParamId.TYPE_Uint16Array, [int(c.id) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 1, freq_size, PP_FuncParamId.TYPE_RealArray, [float(c.frequency) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 2, dll_size, PP_FuncParamId.TYPE_RealArray, [float(c.dutyLowerLimit) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 3, dul_size, PP_FuncParamId.TYPE_RealArray, [float(c.dutyUpperLimit) for c in cfg_list[:items]])
        CTX.handle_cmd(cmd, serial_size)


class imu(node):
    """IMU interface block providing accelerometer, gyroscope, or magnetometer measurements.

    Args:
        id: Motion channel: ``IMU_ACC`` (acceleration), ``IMU_GYR`` (angular
            rate) or ``IMU_MAG`` (magnetic field). The three are separate
            channels, one block each.
        outScale: Multiplier on all three axes, applied to the channel's own
            native units; ``1.0`` leaves them as they are. ``0`` is accepted
            and parks all three outputs at 0 for ever. PAPAYA Studio warns
            about that; this library does not.

    Outputs:
        x: output 0, the x axis reading times ``outScale``
        y: output 1, the y axis reading times ``outScale``
        z: output 2, the z axis reading times ``outScale``

    The three axes are referred to the frame printed on the board: X runs
    across the board, Y runs up it, and Z comes out of the face.
    """

    def __init__(self, id: PP_HwId, outScale: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        subfunc = _sensor_create_subfunc(id)
        if subfunc == PP_SubFuncId.NoSubFuncId:
            raise ValueError("imu() requires IMU_ACC, IMU_GYR, or IMU_MAG hardware ids")

        outs = _outputs_per_hw_input(id)
        self.dataLines = outs
        self.dataRaw = 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, subfunc, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(id))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(outScale))
        CTX.handle_cmd(cmd, serial_size)


class accelerometer(imu):
    """Accelerometer sensor (IMU). 3 outputs: x, y, z acceleration."""

    def __init__(self, outScale: float) -> None:
        super().__init__(PP_HwId.IMU_ACC, outScale)


class gyroscope(imu):
    """Gyroscope sensor (IMU). 3 outputs: x, y, z angular velocity."""

    def __init__(self, outScale: float) -> None:
        super().__init__(PP_HwId.IMU_GYR, outScale)


class magnetometer(imu):
    """Magnetometer sensor (IMU). 3 outputs: x, y, z magnetic field."""

    def __init__(self, outScale: float) -> None:
        super().__init__(PP_HwId.IMU_MAG, outScale)


class motor(node):
    """DC motor hardware block with one duty-cycle input and 1 to 3 selectable measurement outputs.

    Drives a brushed-DC motor via an on-board H-bridge.
    Accepts a fractional duty-cycle command and provides up to three
    feedback measurements selected by the ``outputs`` list:

    * ``PP_MotorOutput.MotorVelocity``: filtered velocity (rad/s)
    * ``PP_MotorOutput.MotorPosition``: encoder position (rad)
    * ``PP_MotorOutput.MotorCurrent``:  shunt current (mA)

    The duty command is a SIGNED FRACTION and its sign is the direction: -1
    is full reverse, 0 is stopped, +1 is full forward. It is not a
    percentage, in either library or on the board.

    Ranges the board can honour. PAPAYA Studio refuses a design outside
    these before it is deployed; this library does not check them.

    * ``dutyLowerLimit`` and ``dutyUpperLimit`` live in -1.0 to +1.0, and
      the upper must be strictly above the lower. The drive clamps to
      -1..+1 again afterwards, so a wider limit does nothing.
    * ``cur_min_mA`` and ``cur_max_mA`` bound the range the current is
      MEASURED over, roughly -5470 to +5470 mA. They do not trip: this
      firmware never cuts the drive out on current. Protect the drive with
      a fuse, a supply current limit, or your own logic on the current
      output.
    * ``pwm_hz`` must be > 0 and sets the duty resolution: the default
      20000 Hz gives about 8500 steps, and fewer as the carrier rises.

    Inputs:
        in[0]: duty cycle, a signed fraction, clamped to
            ``[dutyLowerLimit, dutyUpperLimit]`` before being applied to
            the PWM driver.
    Outputs:
        out[0..N-1]: measurement ports in the order configured by
            ``outputs``. For example ``[MotorVelocity, MotorCurrent]``
            gives ``mot.out(0)`` = velocity, ``mot.out(1)`` = current.

    Constructor forms:
        ``motor(PP_HwId.MOTOR1, PP_motorCfg(...), [MotorVelocity], 1)``
        ``motor(PP_motorBlockCfg(...))``

    Args:
        id_or_cfg: Either a ``PP_HwId`` (``MOTOR1`` or ``MOTOR2``)
            or a fully-populated ``PP_motorBlockCfg``.
        config: ``PP_motorCfg`` (required when first arg is a
            ``PP_HwId``).
        outputs: Ordered sequence of ``PP_MotorOutput`` selectors.
        outputCount: Number of selected outputs (1..3). Must match
            ``len(outputs)``.

    Encoder peripheral sharing:
        The motor's encoder timer pair is shared with the corresponding
        :class:`encoder` block (``MOTOR1`` ↔ ``ENC1``,
        ``MOTOR2`` ↔ ``ENC2``). Including velocity or position
        in this block's ``outputs`` claims the encoder peripheral and
        prevents a standalone Encoder block on the same channel. Set
        ``outputs=[MotorCurrent]`` to release the encoder.
    """

    def __init__(
        self,
        id_or_cfg: Union[PP_HwId, PP_motorBlockCfg],
        config: Optional[PP_motorCfg] = None,
        outputs: Optional[Sequence[Union[PP_MotorOutput, int]]] = None,
        outputCount: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        if isinstance(id_or_cfg, PP_motorBlockCfg):
            block_cfg = id_or_cfg
            hw_id = block_cfg.id
            motor_cfg = block_cfg.config
            raw_outputs = list(block_cfg.outputs or [])
            count = int(block_cfg.outputCount)
        else:
            hw_id = id_or_cfg
            motor_cfg = config
            raw_outputs = list(outputs or [])
            count = int(outputCount) if outputCount is not None else len(raw_outputs)

        if hw_id not in (PP_HwId.MOTOR1, PP_HwId.MOTOR2):
            raise ValueError("motor() requires MOTOR1 or MOTOR2")
        if motor_cfg is None:
            raise TypeError("motor() requires a PP_motorCfg or PP_motorBlockCfg")

        selected_outputs = _normalize_motor_outputs(raw_outputs, count)
        self.dataLines = len(selected_outputs)
        self.dataRaw = 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            + 8 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            + len(selected_outputs) * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 10 + len(selected_outputs), PP_SubFuncId.NewMotor, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(hw_id))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.pwm_hz))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.cur_min_mA))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.cur_max_mA))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.vel_conv))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.pos_conv))
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.vel_tau))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.dutyLowerLimit))
        CTX.prepare_param(cmd, 8, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(motor_cfg.dutyUpperLimit))
        CTX.prepare_param(cmd, 9, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, len(selected_outputs))
        for idx, output in enumerate(selected_outputs):
            CTX.prepare_param(cmd, 10 + idx, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(output))
        CTX.handle_cmd(cmd, serial_size)


class encoder(node):
    """Standalone quadrature encoder block with 1 or 2 selectable measurement outputs.

    Reads the quadrature encoder timer on a physical channel
    independently of any :class:`motor` block on the same channel.
    Velocity is low-pass filtered on the board with the same bilinear
    first-order LPF as the motor block (see :class:`PP_encoderCfg`),
    sampled in the main sampling interrupt at the design's sampling
    frequency.

    Channel sharing:
        ENC1 is the same physical counter that Motor 1 measures with;
        ENC2 is the same one Motor 2 measures with. This block is only
        valid when no Motor on the same channel is active, OR when that
        Motor is configured for ``MotorCurrent``-only output, which is
        the one output mode that does not read the counter.

        PAPAYA Studio refuses the combination on every route a block can
        be created: it greys out the conflicting ``ENC`` choice in the
        block dialog, refuses the second block when you add one from the
        Board Explorer, moves or refuses a pasted copy, warns when a
        saved design that contains the conflict is opened, and refuses to
        deploy or generate code for it.

        The board itself does NOT refuse it. If a design that
        double-claims a channel does reach the board, by any route other
        than Studio, both blocks read the counter using whichever
        configuration was sent last, and neither reports an error. Check
        it in your own code if you build designs with this library
        directly.

    Inputs:
        none (pure source block).
    Outputs:
        out[0..N-1]: measurement ports in the order configured by
            ``outputs``. ``[EncoderVelocity, EncoderPosition]`` gives
            ``enc.out(0)`` = velocity, ``enc.out(1)`` = position.

    Constructor forms:
        ``encoder(PP_HwId.ENC1, PP_encoderCfg(...), [EncoderVelocity], 1)``
        ``encoder(PP_encoderBlockCfg(...))``

    Args:
        id_or_cfg: Either a ``PP_HwId`` (``ENC1`` or
            ``ENC2``) or a fully-populated ``PP_encoderBlockCfg``.
        config: ``PP_encoderCfg`` (required when first arg is a
            ``PP_HwId``).
        outputs: Ordered sequence of ``PP_EncoderOutput`` selectors.
            Allowed: any non-empty subset of {EncoderVelocity,
            EncoderPosition}.
        outputCount: Number of selected outputs (1 or 2). Must match
            ``len(outputs)``.
    """

    def __init__(
        self,
        id_or_cfg: Union[PP_HwId, PP_encoderBlockCfg],
        config: Optional[PP_encoderCfg] = None,
        outputs: Optional[Sequence[Union[PP_EncoderOutput, int]]] = None,
        outputCount: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        if isinstance(id_or_cfg, PP_encoderBlockCfg):
            block_cfg = id_or_cfg
            hw_id = block_cfg.id
            enc_cfg = block_cfg.config
            raw_outputs = list(block_cfg.outputs or [])
            count = int(block_cfg.outputCount)
        else:
            hw_id = id_or_cfg
            enc_cfg = config
            raw_outputs = list(outputs or [])
            count = int(outputCount) if outputCount is not None else len(raw_outputs)

        if hw_id not in (PP_HwId.ENC1, PP_HwId.ENC2):
            raise ValueError("encoder() requires ENC1 or ENC2")
        if enc_cfg is None:
            raise TypeError("encoder() requires a PP_encoderCfg or PP_encoderBlockCfg")

        selected_outputs = _normalize_encoder_outputs(raw_outputs, count)
        self.dataLines = len(selected_outputs)
        self.dataRaw = 1

        # Wire layout: hw_id (u16) + vel_conv (f32) + pos_conv (f32) +
        # vel_tau (f32) + outputCount (u8) + N output IDs (u8).
        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
            + len(selected_outputs) * (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5 + len(selected_outputs), PP_SubFuncId.NewEncoder, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(hw_id))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(enc_cfg.vel_conv))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(enc_cfg.pos_conv))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(enc_cfg.vel_tau))
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, len(selected_outputs))
        for idx, output in enumerate(selected_outputs):
            CTX.prepare_param(cmd, 5 + idx, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(output))
        CTX.handle_cmd(cmd, serial_size)


def _resolve_anout_mode(mode) -> PP_AnOutMode:
    """Coerce a mode given as enum / int / string to PP_AnOutMode."""
    if isinstance(mode, PP_AnOutMode):
        return mode
    if isinstance(mode, str):
        return PP_AnOutMode[mode]
    return PP_AnOutMode(int(mode))


class analogOut(node):
    """Analog voltage output block driving the board's analog output channels.

    Two modes (``PP_AnOutMode``):

    * **InputDriven** (default): the block has a voltage input; the value is
      written to the DAC every design cycle, clamped to [lowerLimit, upperLimit].
      Single channel or a list of ``PP_anOutCfg`` for several channels.

    * **PredefinedWaveform**: the block has no input/output; it carries a
      waveform spec (any of the 17 source-generator shapes) that the board
      synthesises and plays back autonomously, with no per-cycle CPU cost.  Use the constructor with ``mode=PP_AnOutMode.PredefinedWaveform``
      or the ergonomic factories (``analogOut.sine``, ``analogOut.chirpLinear``,
      …).  See ``papaya/signal_source.py`` for the shape catalogue.

    Ranges the board can honour. PAPAYA Studio refuses a design outside these
    before it is deployed; this library does not check them.

    * **Volts.** The channel drives -10 V to +10 V and stops at the rail.
      ``lowerLimit``, ``upperLimit`` and a predefined waveform's ``offset``
      all live in that span; a value outside it changes nothing about the
      pin. ``lowerLimit`` must not be above ``upperLimit``, because the board
      swaps a reversed pair without saying so. Equal limits are legal and pin
      the output at that voltage.
    * **Amplitude.** A waveform that passes 10 V is playable and comes out
      FLAT-TOPPED: the clamp is hard saturation per sample, not a smooth
      limit, so the part outside the span is lost rather than scaled down.
      Judge it on the highest and lowest volts one played cycle actually
      reaches, NOT on ``|amplitude| + |offset|``. That sum is the exact peak
      only for the shapes that really do run the full -1 to +1: ``Sine``,
      ``Square``, ``Triangle``, ``Pulse``, ``PRBS``, ``Sawtooth`` and the two
      chirps.

      Fourteen of the sixteen shapes keep their normalised cycle inside
      -1 to +1, so for those the sum is an upper bound, but often a loose
      one and a waveform with room to spare then looks like it clips: a
      ``PulseTrain`` and an ``Impulse`` sit between 0 and 1, a ``Sinc``
      between -0.22 and +1, a ``Gauspuls`` on its defaults between +0.94
      and +1, and a ``Multisine`` of eight lines between -0.41 and +0.43,
      because its lines do not all peak at the same instant. A ``DC`` holds
      the offset alone; its amplitude never reaches the pin.

      ``Step`` and ``Ramp`` are the two shapes that can leave -1 to +1, and
      for them the sum is not even a bound, because the level comes from the
      shape's own parameters rather than from the amplitude:

      * A ``Step`` sits at ``amplitude * value_after + offset`` (and at
        ``amplitude * value_before + offset`` before ``t_step``), so
        amplitude 1 with ``value_after`` 500 asks the output for 500 V.
      * A ``Ramp`` reaches ``amplitude * min(sat_high, slope * cycle) +
        offset``, and the cycle played for this shape is one second, so
        raising ``sat_high`` on its own moves nothing until the slope can
        climb that far within the second. At the default slope of 1 the
        ramp tops out just under 1 whatever ``sat_high`` says; at slope 100
        it reaches 50 with ``sat_high`` 50, and 100 with ``sat_high`` left
        wide. ``sat_low`` bounds the descent the same way.

      :func:`papaya.signal_source.ao_predef_span` returns those two numbers
      for a given shape and its parameters, and is what PAPAYA Studio warns
      from.
    * **Repetition rate.** The output plays at up to 1000000 samples per
      second and needs at least 8 samples per cycle, so the fastest waveform
      it can repeat is 125 kHz. A ``freq`` above that cannot be synthesised.
    * **Table length.** One cycle is stored in a table of at most 2048
      samples. A ``prbs`` sequence has to fit whole, so
      ``(2**bits - 1) * clock_div`` must not exceed 2048: 11 bits at
      ``clock_div`` 1, and fewer as it rises.

    AO1, AO4 and AO5 share one playback trigger. In PredefinedWaveform mode
    those three channels are advanced by ONE trigger; only AO2 and AO3 own a
    private one. Setting the playback rate of any of the three reprograms that
    trigger, so the last one created silently changes the rate of the other
    two, INCLUDING channels already running. The rate follows the waveform's
    own cycle, so give any two of AO1, AO4 and AO5 waveforms of the same
    period, or put one of them on AO2 or AO3. Nothing on the board reports the
    clash.

    Args:
        id_or_cfg: An analog output identifier (``AO1``..``AO5``), or a list of
            ``PP_anOutCfg`` for the multi-channel input-driven form.
        lowerLimit: Lower clamp on the input, in VOLTS, within -10.0 to +10.0.
        upperLimit: Upper clamp, in VOLTS, same range; not below
            ``lowerLimit``.

    Inputs:
        voltage: input 0 (InputDriven mode only), in volts.
    """

    def __init__(
        self,
        id_or_cfg: Union[PP_HwId, Sequence[PP_anOutCfg], dict, None] = None,
        lowerLimit: Optional[float] = None,
        upperLimit: Optional[float] = None,
        items: Optional[int] = None,
        *,
        mode: Union[PP_AnOutMode, int, str] = PP_AnOutMode.InputDriven,
        shape: Optional[PP_WaveShape] = None,
        amplitude: float = 1.0,
        offset: float = 0.0,
        **shape_kwargs,
    ) -> None:
        # Studio codegen passes a single dict positional arg (canvas params).
        if isinstance(id_or_cfg, dict):
            cfg = dict(id_or_cfg)
            mode        = cfg.pop("mode", PP_AnOutMode.InputDriven)
            id_or_cfg   = cfg.pop("hw_id", cfg.pop("id", None))
            lowerLimit  = cfg.pop("lower_limit", cfg.pop("lowerLimit", lowerLimit))
            upperLimit  = cfg.pop("upper_limit", cfg.pop("upperLimit", upperLimit))
            shape       = cfg.pop("shape", shape)
            amplitude   = cfg.pop("amplitude", amplitude)
            offset      = cfg.pop("offset", offset)
            shape_kwargs = cfg

        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        self.mode = _resolve_anout_mode(mode)

        if self.mode == PP_AnOutMode.PredefinedWaveform:
            self._emit_predefined(id_or_cfg, shape, amplitude, offset, shape_kwargs)
        else:
            self._emit_input_driven(id_or_cfg, lowerLimit, upperLimit, items)

    # ------------------------------------------------------------------
    # InputDriven mode: voltage written per design cycle
    # ------------------------------------------------------------------
    def _emit_input_driven(self, id_or_cfg, lowerLimit, upperLimit, items) -> None:
        # The board (and the C++ lib) expect 4 params per channel:
        # (hwId, freq, lowerLimit, upperLimit).  A voltage output has no
        # PWM frequency, so slot 1 is a 0.0f placeholder the board stores
        # and then ignores: it keeps the parser uniform with pwmOut.
        if isinstance(id_or_cfg, PP_HwId):
            if lowerLimit is None or upperLimit is None:
                raise TypeError("analogOut(PP_HwId, lowerLimit, upperLimit) requires all parameters")
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewHwOutput, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(id_or_cfg))
            CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, 0.0)
            CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(lowerLimit))
            CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(upperLimit))
            CTX.handle_cmd(cmd, serial_size)
            return

        cfg_list = list(id_or_cfg)
        if items is None:
            items = len(cfg_list)
        if items <= 0:
            raise ValueError("items must be > 0")

        ids_size = items * PP_UINT16_SIZE
        freq_size = items * PP_REAL_SIZE
        ll_size = items * PP_REAL_SIZE
        ul_size = items * PP_REAL_SIZE
        serial_size = PP_FIXED_SIZE + 4 * PP_PARAM_INFO_SIZE + ids_size + freq_size + ll_size + ul_size

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewHwOutput, self.getId())
        CTX.prepare_param(cmd, 0, ids_size, PP_FuncParamId.TYPE_Uint16Array, [int(c.id) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 1, freq_size, PP_FuncParamId.TYPE_RealArray, [0.0 for _ in cfg_list[:items]])
        CTX.prepare_param(cmd, 2, ll_size, PP_FuncParamId.TYPE_RealArray, [float(c.lowerLimit) for c in cfg_list[:items]])
        CTX.prepare_param(cmd, 3, ul_size, PP_FuncParamId.TYPE_RealArray, [float(c.upperLimit) for c in cfg_list[:items]])
        CTX.handle_cmd(cmd, serial_size)

    # ------------------------------------------------------------------
    # PredefinedWaveform mode: autonomous waveform played by the board
    # ------------------------------------------------------------------
    def _emit_predefined(self, hw_id, shape, amplitude, offset, shape_kwargs) -> None:
        from . import signal_source as _ss

        if hw_id is None:
            raise TypeError("PredefinedWaveform analogOut requires a hw id")
        if shape is None:
            shape = PP_WaveShape.Sine
        shape = _resolve_wave_shape(shape)
        if "phase_scheme" in shape_kwargs:
            shape_kwargs["phase_scheme"] = _resolve_multisine_phase(shape_kwargs["phase_scheme"])

        # Build the 36-byte AO_WaveCfg wire blob (host owns shape + cadence).
        blob = _ss.ao_predef_frame(shape, amplitude, offset, **shape_kwargs)

        blob_size = _ss.AO_CFG_PREDEF_LEN
        serial_size = (PP_FIXED_SIZE
                       + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)   # hw id
                       + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)   # mode tag
                       + (PP_PARAM_INFO_SIZE + blob_size))       # waveform blob
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3,
                                     PP_SubFuncId.NewHwOutput, self.getId())
        # Resolved, not read: this took the identifier's NAME from the
        # Studio's config dict and called int() on it, so every predefined
        # waveform raised instead of running. The input-driven path next
        # door was already handed a resolved value, which is why the mode
        # could be offered in the dialog and be unreachable in practice.
        from .hw_ids import wire_value as _hw_wire_value
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          _hw_wire_value(hw_id, context="analogOut waveform"))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          int(PP_AnOutMode.PredefinedWaveform))
        CTX.prepare_param(cmd, 2, blob_size, PP_FuncParamId.TYPE_Uint8Array, list(blob))
        CTX.handle_cmd(cmd, serial_size)

        # Keep the config for reverse-decoders / introspection.
        self.shape = shape
        self.amplitude = float(amplitude)
        self.offset = float(offset)
        self.shape_params = dict(shape_kwargs)

    # ------------------------------------------------------------------
    # Ergonomic factories: one predefined waveform per shape
    # ------------------------------------------------------------------
    @classmethod
    def _predef(cls, hw_id, shape, *, amplitude=1.0, offset=0.0, **kw) -> "analogOut":
        return cls(hw_id, mode=PP_AnOutMode.PredefinedWaveform, shape=shape,
                   amplitude=amplitude, offset=offset, **kw)

    @classmethod
    def sine(cls, hw_id, freq, phase=0.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Sine, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase)

    @classmethod
    def square(cls, hw_id, freq, phase=0.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Square, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase)

    @classmethod
    def triangle(cls, hw_id, freq, phase=0.0, symmetry=0.5, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Triangle, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase, symmetry=symmetry)

    @classmethod
    def sawtooth(cls, hw_id, freq, phase=0.0, direction=0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Sawtooth, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase, direction=direction)

    @classmethod
    def pulse(cls, hw_id, freq, phase=0.0, duty=0.5, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Pulse, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase, duty=duty)

    @classmethod
    def sinc(cls, hw_id, freq, phase=0.0, n_lobes=5, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Sinc, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase, n_lobes=n_lobes)

    @classmethod
    def gauspuls(cls, hw_id, freq, bw_fraction=0.5, prf=10.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Gauspuls, amplitude=amplitude,
                           offset=offset, freq=freq, bw_fraction=bw_fraction, prf=prf)

    @classmethod
    def dc(cls, hw_id, *, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.DC, amplitude=1.0, offset=offset)

    @classmethod
    def chirpLinear(cls, hw_id, f0, f1, t_sweep, phase=0.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.LinearChirp, amplitude=amplitude,
                           offset=offset, f0=f0, f1=f1, t_sweep=t_sweep, phase=phase)

    @classmethod
    def chirpLog(cls, hw_id, f0, f1, t_sweep, phase=0.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.LogChirp, amplitude=amplitude,
                           offset=offset, f0=f0, f1=f1, t_sweep=t_sweep, phase=phase)

    @classmethod
    def multisine(cls, hw_id, f0, df, n_lines=8, phase_scheme=0, lfsr_seed=0xACE1,
                  *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Multisine, amplitude=amplitude,
                           offset=offset, f0=f0, df=df, n_lines=n_lines,
                           phase_scheme=phase_scheme, lfsr_seed=lfsr_seed)

    @classmethod
    def prbs(cls, hw_id, bits=9, clock_div=1, lfsr_seed=0xACE1, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.PRBS, amplitude=amplitude,
                           offset=offset, bits=bits, clock_div=clock_div, lfsr_seed=lfsr_seed)

    @classmethod
    def step(cls, hw_id, t_step=0.0, value_before=0.0, value_after=1.0,
             *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Step, amplitude=amplitude,
                           offset=offset, t_step=t_step, value_before=value_before,
                           value_after=value_after)

    @classmethod
    def ramp(cls, hw_id, slope=1.0, t_start=0.0, sat_low=-10.0, sat_high=10.0,
             *, amplitude=1.0, offset=0.0):
        # The saturation pair defaults to the output's own rail, not to the
        # effectively-unbounded +/-1e9 the shared shape defaults carry. This
        # ramp drives a physical channel that stops at +/-10 V whatever is
        # asked of it, and the C++ twin and the block catalogue have always
        # said -10/+10 here. With 1e9 the same call ramped without limit in
        # Python, so a simulation ran off to 1e9 while the board it was
        # standing in for held at the rail. signalSource.ramp keeps 1e9,
        # because it is a number on a wire and not tied to a rail.
        return cls._predef(hw_id, PP_WaveShape.Ramp, amplitude=amplitude,
                           offset=offset, slope=slope, t_start=t_start,
                           sat_low=sat_low, sat_high=sat_high)

    @classmethod
    def impulse(cls, hw_id, t_impulse=0.0, *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.Impulse, amplitude=amplitude,
                           offset=offset, t_impulse=t_impulse)

    @classmethod
    def pulseTrain(cls, hw_id, freq, phase=0.0, duty=0.5, n_pulses=1, prf=10.0,
                   *, amplitude=1.0, offset=0.0):
        return cls._predef(hw_id, PP_WaveShape.PulseTrain, amplitude=amplitude,
                           offset=offset, freq=freq, phase=phase, duty=duty,
                           n_pulses=n_pulses, prf=prf)


class speaker(node):
    """Speaker output block streaming audio to the board's amplified audio output.

    Inputs:
        audio: input 0 (normalized audio stream [-1.0, +1.0])
    """

    def __init__(self, hw_id: PP_HwId) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewHwOutput, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(hw_id))
        CTX.handle_cmd(cmd, serial_size)


class microphone(node):
    """Microphone input block capturing audio from the board's on-board digital microphone.

    Outputs:
        audio: output 0 (normalized audio stream [-1.0, +1.0])
    """

    def __init__(self, hw_id: PP_HwId) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        self.dataLines = 1
        self.dataRaw = 0

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewHwInput, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(hw_id))
        CTX.handle_cmd(cmd, serial_size)


class recorder(node):
    """Audio recorder block: captures its input stream to the board's recording slot.

    A sink that behaves on the wire exactly like a speaker (NewHwOutput),
    but the board writes each sample into its persistent recording flash
    slot instead of sending it to an audio output.  Place it after a
    microphone (optionally via a decimator) to record sound; the recording
    is committed to flash when sampling stops.

    Inputs:
        audio: input 0 (normalized audio stream [-1.0, +1.0])
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewHwOutput, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(PP_HwId.RECORDER_1))
        CTX.handle_cmd(cmd, serial_size)


class replay(node):
    """Audio replay block: streams the board's recording slot back into the graph.

    A source that behaves on the wire exactly like a microphone
    (NewHwInput), but the board reads each sample from its persistent
    recording flash slot instead of from a live microphone.  Place it
    before a speaker (optionally via an interpolator) to play a recording
    back.

    Outputs:
        audio: output 0 (normalized audio stream [-1.0, +1.0])
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        self.dataLines = 1
        self.dataRaw = 0

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewHwInput, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(PP_HwId.REPLAY_1))
        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# State-space system
# -----------------------------------------------------------------------------

class stateSpace(node):
    """Discrete-time state-space system (SISO / MIMO).

    Implements:
        x[k+1] = A·x[k] + B·u[k]
        y[k]   = C·x[k] + D·u[k]

    IO:
        Inputs  [0..m-1]: Input vector u
        Outputs [0..p-1]: Output vector y

    Vector-probe support:
        The internal n-dimensional state vector x[k] is published via
        the node's ProbeInfo path, so a ``stateSpace >> VectorProbe``
        link in Studio streams the full state vector once per host
        sample period (n floats per frame, one row).
    """

    def __init__(self, config: PP_stateSpace) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        n = int(config.n)
        m = int(config.m)
        p = int(config.p)

        # Vector-probe shape: the state vector x[k] is n elements wide,
        # one row.  These two fields are consumed by ``node.__rshift__``
        # (the ``>>`` operator) when the user wires a VectorProbe to
        # this block: they propagate to the probe's allocated buffer
        # size and to the firmware's auto-push frame width.
        self.dataLines = n
        self.dataRaw = 1

        sz_u16 = PP_UINT16_SIZE
        sz_A = n * n * PP_REAL_SIZE
        sz_B = n * m * PP_REAL_SIZE
        sz_C = p * n * PP_REAL_SIZE
        sz_D = p * m * PP_REAL_SIZE
        sz_x0 = n * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + 3 * (PP_PARAM_INFO_SIZE + sz_u16)   # n, m, p
            + (PP_PARAM_INFO_SIZE + sz_A)          # A
            + (PP_PARAM_INFO_SIZE + sz_B)          # B
            + (PP_PARAM_INFO_SIZE + sz_C)          # C
            + (PP_PARAM_INFO_SIZE + sz_D)          # D
            + (PP_PARAM_INFO_SIZE + sz_x0)         # x_init
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewStateSpace, self.getId())

        CTX.prepare_param(cmd, 0, sz_u16, PP_FuncParamId.TYPE_Uint16, n)
        CTX.prepare_param(cmd, 1, sz_u16, PP_FuncParamId.TYPE_Uint16, m)
        CTX.prepare_param(cmd, 2, sz_u16, PP_FuncParamId.TYPE_Uint16, p)
        CTX.prepare_param(cmd, 3, sz_A, PP_FuncParamId.TYPE_RealArray, config.A_data)
        CTX.prepare_param(cmd, 4, sz_B, PP_FuncParamId.TYPE_RealArray, config.B_data)
        CTX.prepare_param(cmd, 5, sz_C, PP_FuncParamId.TYPE_RealArray, config.C_data)
        CTX.prepare_param(cmd, 6, sz_D, PP_FuncParamId.TYPE_RealArray, config.D_data)
        CTX.prepare_param(cmd, 7, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Observers
# -----------------------------------------------------------------------------

class compFilter(node):
    """Complementary filter for sensor fusion.

    Implements:  y[k] = alpha * (y[k-1] + rate[k] * Ts) + (1 - alpha) * meas[k]

    IO:
        Input 0: rate signal (e.g. gyroscope angular rate)
        Input 1: absolute measurement (e.g. accelerometer angle)
        Output 0: filtered estimate
    """

    def __init__(self, config: PP_compFilter) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)  # alpha
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewCompFilter, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.alpha))
        CTX.handle_cmd(cmd, serial_size)


class smo(node):
    """Sliding Mode Observer (SISO / MIMO).

    Implements:
        x_hat[k+1] = A*x_hat + B*u + L*e + K*sat(e/epsilon)
        where e = y - C*x_hat

    IO:
        Inputs  [0..m-1]: control input u
        Inputs  [m..m+p-1]: measurement y
        Outputs [0..n-1]: estimated state x_hat
    """

    def __init__(self, config: PP_SMO) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        n = int(config.n)
        m = int(config.m)
        p = int(config.p)

        sz_u16 = PP_UINT16_SIZE
        sz_A = n * n * PP_REAL_SIZE
        sz_B = n * m * PP_REAL_SIZE
        sz_C = p * n * PP_REAL_SIZE
        sz_L = n * p * PP_REAL_SIZE
        sz_K = n * p * PP_REAL_SIZE
        sz_x0 = n * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + 3 * (PP_PARAM_INFO_SIZE + sz_u16)    # n, m, p
            + (PP_PARAM_INFO_SIZE + sz_A)           # A
            + (PP_PARAM_INFO_SIZE + sz_B)           # B
            + (PP_PARAM_INFO_SIZE + sz_C)           # C
            + (PP_PARAM_INFO_SIZE + sz_L)           # L
            + (PP_PARAM_INFO_SIZE + sz_K)           # K
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # epsilon
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 10, PP_SubFuncId.NewSMO, self.getId())

        CTX.prepare_param(cmd, 0, sz_u16, PP_FuncParamId.TYPE_Uint16, n)
        CTX.prepare_param(cmd, 1, sz_u16, PP_FuncParamId.TYPE_Uint16, m)
        CTX.prepare_param(cmd, 2, sz_u16, PP_FuncParamId.TYPE_Uint16, p)
        CTX.prepare_param(cmd, 3, sz_A, PP_FuncParamId.TYPE_RealArray, config.A_data)
        CTX.prepare_param(cmd, 4, sz_B, PP_FuncParamId.TYPE_RealArray, config.B_data)
        CTX.prepare_param(cmd, 5, sz_C, PP_FuncParamId.TYPE_RealArray, config.C_data)
        CTX.prepare_param(cmd, 6, sz_L, PP_FuncParamId.TYPE_RealArray, config.L_data)
        CTX.prepare_param(cmd, 7, sz_K, PP_FuncParamId.TYPE_RealArray, config.K_data)
        CTX.prepare_param(cmd, 8, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 9, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.epsilon))

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Application-specific EKF blocks
# -----------------------------------------------------------------------------

class pmsmEKF(node):
    """Sensorless PMSM Extended Kalman Filter observer.

    States: [i_alpha, i_beta, omega, theta]
    Inputs: [v_alpha, v_beta]
    Outputs: [i_alpha_hat, i_beta_hat, omega_hat, theta_hat]
    """

    def __init__(self, config: PP_PMSM_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 4 * 4 * PP_REAL_SIZE
        sz_R = 2 * 2 * PP_REAL_SIZE
        sz_x0 = 4 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Rs
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Ls
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # lambda_pm
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewPMSM_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Rs))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Ls))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.lambda_pm))
        CTX.prepare_param(cmd, 3, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 4, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 5, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 7, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class ahrsEKF(node):
    """AHRS quaternion Extended Kalman Filter estimator.

    States: [q0, q1, q2, q3, gyro_bias_x, gyro_bias_y, gyro_bias_z]
    Inputs: [gx, gy, gz, ax, ay, az, mx, my, mz]
    Outputs: [q0, q1, q2, q3, gyro_bias_x, gyro_bias_y, gyro_bias_z]
    """

    def __init__(self, config: PP_AHRS_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_mag = 3 * PP_REAL_SIZE
        sz_Q = 7 * 7 * PP_REAL_SIZE
        sz_R = 6 * 6 * PP_REAL_SIZE
        sz_x0 = 7 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_mag)         # mag_ref
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 6, PP_SubFuncId.NewAHRS_EKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_mag, PP_FuncParamId.TYPE_RealArray, config.mag_ref)
        CTX.prepare_param(cmd, 1, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 2, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 3, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 5, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class batterySOC_EKF(node):
    """Battery SOC Extended Kalman Filter estimator (1-RC Thevenin model).

    States: [SOC, V_rc]
    Inputs: [I_bat]
    Outputs: [SOC_hat, V_rc_hat]
    """

    def __init__(self, config: PP_BatterySOC_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_ocv = 4 * PP_REAL_SIZE
        sz_Q = 2 * 2 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 2 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R0
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R1
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # C1
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Q_cap
            + (PP_PARAM_INFO_SIZE + sz_ocv)         # ocv_coef
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 10, PP_SubFuncId.NewBatterySOC_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.R0))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.R1))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.C1))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Q_cap))
        CTX.prepare_param(cmd, 4, sz_ocv, PP_FuncParamId.TYPE_RealArray, config.ocv_coef)
        CTX.prepare_param(cmd, 5, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 6, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 7, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 8, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 9, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class tiltEKF(node):
    """Single-axis tilt Extended Kalman Filter estimator.

    States: [angle, gyro_bias]
    Inputs: [gyro_rate, accel_angle]
    Outputs: [angle_hat, gyro_bias_hat]
    """

    def __init__(self, config: PP_Tilt_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 2 * 2 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 2 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewTilt_EKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 1, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class loadTorqueEKF(node):
    """Load torque Extended Kalman Filter estimator.

    States: [omega, T_load]
    Inputs: [T_motor]
    Outputs: [omega_hat, T_load_hat]
    """

    def __init__(self, config: PP_LoadTorque_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 2 * 2 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 2 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # J
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # B
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 7, PP_SubFuncId.NewLoadTorque_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.J))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.B))
        CTX.prepare_param(cmd, 2, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 3, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 4, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 6, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Application EKF blocks (continued)
# -----------------------------------------------------------------------------

class thermalEKF(node):
    """Thermal model temperature estimator EKF (2-node lumped RC).

    States: [T_core, T_surface]
    Input: power dissipation P
    Measurement: surface/ambient temperature sensor T_meas
    """

    def __init__(self, config: PP_Thermal_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 2 * 2 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 2 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R_th
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # C_core
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # C_surf
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R_conv
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # T_amb
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 10, PP_SubFuncId.NewThermal_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.R_th))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.C_core))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.C_surf))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.R_conv))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.T_amb))
        CTX.prepare_param(cmd, 5, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 6, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 7, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 8, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 9, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class baroAltEKF(node):
    """Barometric altitude estimator EKF.

    States: [altitude, vertical_velocity, accel_bias]
    Input: vertical accelerometer az
    Measurement: barometric altitude h_baro
    """

    def __init__(self, config: PP_BaroAlt_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 3 * 3 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 3 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewBaroAlt_EKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 1, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class robotLocEKF(node):
    """2D robot localization EKF (differential-drive odometry + range/bearing).

    States: [x, y, theta]
    Inputs: [v_left, v_right]
    Measurements: [range, bearing] to a known landmark
    """

    def __init__(self, config: PP_RobotLoc_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 3 * 3 * PP_REAL_SIZE
        sz_R = 2 * 2 * PP_REAL_SIZE
        sz_x0 = 3 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # wheel_radius
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # wheel_base
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # landmark_x
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # landmark_y
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 9, PP_SubFuncId.NewRobotLoc_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.wheel_radius))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.wheel_base))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.landmark_x))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.landmark_y))
        CTX.prepare_param(cmd, 4, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 5, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 6, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 8, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class sinTrackEKF(node):
    """Sinusoidal signal tracker EKF.

    States: [amplitude, frequency(rad/s), phase]
    No control input.  Measurement: noisy signal sample.
    """

    def __init__(self, config: PP_SinTrack_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 3 * 3 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 3 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewSinTrack_EKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 1, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class gridSyncEKF(node):
    """Single-phase grid frequency and phase tracker EKF.

    States: [theta, omega, V_amp]
    No control input.  Measurement: grid voltage sample.
    """

    def __init__(self, config: PP_GridSync_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 3 * 3 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 3 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # nom_freq
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # nom_amplitude
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 7, PP_SubFuncId.NewGridSync_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.nom_freq))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.nom_amplitude))
        CTX.prepare_param(cmd, 2, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 3, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 4, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 6, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class acimEKF(node):
    """Sensorless AC induction motor (ACIM) observer EKF.

    States: [i_alpha, i_beta, psi_r_alpha, psi_r_beta, omega_r]
    Inputs: [v_alpha, v_beta]
    Measurements: [i_alpha, i_beta]
    """

    def __init__(self, config: PP_ACIM_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 5 * 5 * PP_REAL_SIZE
        sz_R = 2 * 2 * PP_REAL_SIZE
        sz_x0 = 5 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Rs
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Rr
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Ls
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Lr
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Lm
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_pairs
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 11, PP_SubFuncId.NewACIM_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Rs))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Rr))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Ls))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Lr))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Lm))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_pairs))
        CTX.prepare_param(cmd, 6, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 7, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 8, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 9, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 10, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class batterySOH_EKF(node):
    """Battery State-of-Health (SOH) estimator EKF.

    States: [SOC, R0, Q_cap]
    Input: current I
    Measurement: terminal voltage V_t
    """

    def __init__(self, config: PP_BatterySOH_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_ocv = 4 * PP_REAL_SIZE
        sz_Q = 3 * 3 * PP_REAL_SIZE
        sz_R = 1 * PP_REAL_SIZE
        sz_x0 = 3 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R1
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # C1
            + (PP_PARAM_INFO_SIZE + sz_ocv)         # ocv_coef
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewBatterySOH_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.R1))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.C1))
        CTX.prepare_param(cmd, 2, sz_ocv, PP_FuncParamId.TYPE_RealArray, config.ocv_coef)
        CTX.prepare_param(cmd, 3, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 4, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 5, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 7, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class wmrEKF(node):
    """Wheeled Mobile Robot position estimator EKF (full IMU + encoder fusion).

    States: [x, y, theta, v, omega, gyro_bias, mag_bias]
    Inputs: [enc_left, enc_right]
    Measurements: [ax, ay, gz, mx, my, enc_vL, enc_vR]
    """

    def __init__(self, config: PP_WMR_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_mag = 2 * PP_REAL_SIZE
        sz_Q = 7 * 7 * PP_REAL_SIZE
        sz_R = 7 * 7 * PP_REAL_SIZE
        sz_x0 = 7 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # wheel_base
            + (PP_PARAM_INFO_SIZE + sz_mag)         # mag_ref
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 7, PP_SubFuncId.NewWMR_EKF, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.wheel_base))
        CTX.prepare_param(cmd, 1, sz_mag, PP_FuncParamId.TYPE_RealArray, config.mag_ref)
        CTX.prepare_param(cmd, 2, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 3, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 4, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 6, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


class gpsinsEKF(node):
    """GPS/INS position-velocity fusion EKF.

    States: [px, py, pz, vx, vy, vz, heading]
    Inputs: [ax, ay, az]
    Measurements: [gps_px, gps_py, gps_pz, gps_speed]
    """

    def __init__(self, config: PP_GPSINS_EKF, tune: PP_Tune = PP_Tune.PP_NoLiveTune) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Q = 7 * 7 * PP_REAL_SIZE
        sz_R = 4 * 4 * PP_REAL_SIZE
        sz_x0 = 7 * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_Q)           # Q
            + (PP_PARAM_INFO_SIZE + sz_R)           # R
            + (PP_PARAM_INFO_SIZE + sz_x0)          # x_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tune
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewGPSINS_EKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_Q, PP_FuncParamId.TYPE_RealArray, config.Q_data)
        CTX.prepare_param(cmd, 1, sz_R, PP_FuncParamId.TYPE_RealArray, config.R_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, config.x_init)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(tune))

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Adaptive control blocks
# -----------------------------------------------------------------------------

class lms(node):
    """LMS / NLMS adaptive filter.

    Inputs: [desired signal d, reference input x]
    Outputs: [filter output y, error e]
    """

    def __init__(self, config: PP_LMSConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # mu
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # N
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # normalize
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # delta
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewLMS, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.mu))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(config.N))
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.normalize))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.delta))

        CTX.handle_cmd(cmd, serial_size)


class adaptiveNotch(node):
    """Adaptive notch filter with frequency tracking.

    Input: signal
    Outputs: [filtered signal, estimated frequency]
    """

    def __init__(self, config: PP_AdaptiveNotchConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # init_freq
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Q_factor
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # mu
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewAdaptiveNotch, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.init_freq))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Q_factor))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.mu))

        CTX.handle_cmd(cmd, serial_size)


class dob(node):
    """Disturbance observer (DOB).

    Inputs: [plant input u, plant output y]
    Output: disturbance estimate d_hat
    """

    def __init__(self, config: PP_DOBConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_Gn_num = (config.plant_ord + 1) * PP_REAL_SIZE
        sz_Gn_den = (config.plant_ord + 1) * PP_REAL_SIZE
        sz_Qf_num = (config.qf_ord + 1) * PP_REAL_SIZE
        sz_Qf_den = (config.qf_ord + 1) * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_Gn_num)      # Gn_num
            + (PP_PARAM_INFO_SIZE + sz_Gn_den)      # Gn_den
            + (PP_PARAM_INFO_SIZE + sz_Qf_num)      # Qf_num
            + (PP_PARAM_INFO_SIZE + sz_Qf_den)      # Qf_den
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # plant_ord
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # qf_ord
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 6, PP_SubFuncId.NewDOB, self.getId())

        CTX.prepare_param(cmd, 0, sz_Gn_num, PP_FuncParamId.TYPE_RealArray, config.Gn_num)
        CTX.prepare_param(cmd, 1, sz_Gn_den, PP_FuncParamId.TYPE_RealArray, config.Gn_den)
        CTX.prepare_param(cmd, 2, sz_Qf_num, PP_FuncParamId.TYPE_RealArray, config.Qf_num)
        CTX.prepare_param(cmd, 3, sz_Qf_den, PP_FuncParamId.TYPE_RealArray, config.Qf_den)
        CTX.prepare_param(cmd, 4, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.plant_ord))
        CTX.prepare_param(cmd, 5, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.qf_ord))

        CTX.handle_cmd(cmd, serial_size)


class esc(node):
    """Extremum seeking control (ESC).

    Input: cost function J
    Output: optimised parameter + dither
    """

    def __init__(self, config: PP_ESCConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # a
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # k
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # hpf_wc
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # lpf_wc
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewESC, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.a))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.k))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.hpf_wc))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.lpf_wc))

        CTX.handle_cmd(cmd, serial_size)


class adrc(node):
    """Active Disturbance Rejection Control (ADRC).

    Inputs: [reference, plant output]
    Output: control signal
    """

    def __init__(self, config: PP_ADRCConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # b0
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega_o
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega_c
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # order
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewADRC, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.b0))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega_o))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega_c))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.order))

        CTX.handle_cmd(cmd, serial_size)


class mrac(node):
    """Model Reference Adaptive Control (MRAC).

    Inputs: [reference, plant output]
    Outputs: [control, tracking error]
    """

    def __init__(self, config: PP_MRACConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Am
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Bm
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_x
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_r
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewMRAC, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Am))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Bm))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_x))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_r))

        CTX.handle_cmd(cmd, serial_size)


class mracLyapunov(node):
    """MRAC with Lyapunov stability guarantee and sigma-modification.

    Inputs: [reference, plant output]
    Outputs: [control, tracking error]
    """

    def __init__(self, config: PP_MRACLyapunovConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Am
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Bm
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_x
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_r
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # sigma
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # theta_max
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 6, PP_SubFuncId.NewMRAC_Lyapunov, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Am))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Bm))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_x))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_r))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.sigma))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.theta_max))

        CTX.handle_cmd(cmd, serial_size)


class repetitiveCtrl(node):
    """Repetitive controller.

    Input: error
    Output: repetitive correction signal
    """

    def __init__(self, config: PP_RepCtrlConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # period_samples
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # Q_gain
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # Kr
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewRepetitiveCtrl, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(config.period_samples))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Q_gain))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kr))

        CTX.handle_cmd(cmd, serial_size)


class str_(node):
    """Self-Tuning Regulator (STR) -- indirect adaptive control.

    Inputs: [reference, plant output]
    Output: control signal
    """

    def __init__(self, config: PP_STRConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_poles = config.na * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # na
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # nb
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # lambda
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # P_init
            + (PP_PARAM_INFO_SIZE + sz_poles)        # desired_poles
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewSTR, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.na))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.nb))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.lambda_))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 4, sz_poles, PP_FuncParamId.TYPE_RealArray, config.desired_poles)

        CTX.handle_cmd(cmd, serial_size)


class ilc(node):
    """Iterative Learning Control (ILC).

    Input: tracking error (current trial)
    Output: feedforward correction (applied next trial)
    """

    def __init__(self, config: PP_ILCConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # trial_length
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # L_gain
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # Q_gain
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewILC, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(config.trial_length))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.L_gain))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Q_gain))

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Self-tuning PID blocks
# -----------------------------------------------------------------------------

class gainSchedulePID(node):
    """Gain-scheduled PID controller.

    Inputs: [error, scheduling_variable]
    Output: control signal
    """

    def __init__(self, config: PP_GainSchedulePIDConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        n = config.num_points
        sz_sched = n * PP_REAL_SIZE
        sz_Kp    = n * PP_REAL_SIZE
        sz_Ki    = n * PP_REAL_SIZE
        sz_Kd    = n * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_sched)       # schedule_points
            + (PP_PARAM_INFO_SIZE + sz_Kp)          # Kp_table
            + (PP_PARAM_INFO_SIZE + sz_Ki)          # Ki_table
            + (PP_PARAM_INFO_SIZE + sz_Kd)          # Kd_table
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_min
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_max
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # num_points
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewGainSchedulePID, self.getId())

        CTX.prepare_param(cmd, 0, sz_sched, PP_FuncParamId.TYPE_RealArray, config.schedule_points)
        CTX.prepare_param(cmd, 1, sz_Kp, PP_FuncParamId.TYPE_RealArray, config.Kp_table)
        CTX.prepare_param(cmd, 2, sz_Ki, PP_FuncParamId.TYPE_RealArray, config.Ki_table)
        CTX.prepare_param(cmd, 3, sz_Kd, PP_FuncParamId.TYPE_RealArray, config.Kd_table)
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_min))
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_max))
        CTX.prepare_param(cmd, 7, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.num_points))

        CTX.handle_cmd(cmd, serial_size)


class gainScheduler(node):
    """Generic gain scheduler (multi-output table interpolation).

    Input: scheduling variable
    Outputs: interpolated values
    """

    def __init__(self, config: PP_GainSchedulerConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        sz_bp  = config.num_points * PP_REAL_SIZE
        sz_val = config.num_points * config.num_outputs * PP_REAL_SIZE

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + sz_bp)          # breakpoints
            + (PP_PARAM_INFO_SIZE + sz_val)         # values
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # num_points
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # num_outputs
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewGainScheduler, self.getId())

        CTX.prepare_param(cmd, 0, sz_bp, PP_FuncParamId.TYPE_RealArray, config.breakpoints)
        CTX.prepare_param(cmd, 1, sz_val, PP_FuncParamId.TYPE_RealArray, config.values)
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.num_points))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.num_outputs))

        CTX.handle_cmd(cmd, serial_size)


class relayAutoTune(node):
    """Relay feedback PID auto-tuner (Astrom-Hagglund).

    Input: process variable
    Outputs: [relay output, Kp, Ki, Kd, done flag]
    """

    def __init__(self, config: PP_RelayAutoTuneConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # relay_amplitude
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # hysteresis
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # setpoint
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # tuning_rule
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # min_cycles
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewRelayAutoTune, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.relay_amplitude))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.hysteresis))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.setpoint))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.tuning_rule))
        CTX.prepare_param(cmd, 4, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(config.min_cycles))

        CTX.handle_cmd(cmd, serial_size)


class stepAutoTune(node):
    """Step response PID auto-tuner (FOPDT identification).

    Input: process variable
    Outputs: [step output, Kp, Ki, Kd, done flag]
    """

    def __init__(self, config: PP_StepAutoTuneConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # step_size
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # settle_pct
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # tuning_rule
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # id_method
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewStepAutoTune, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.step_size))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.settle_pct))
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.tuning_rule))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(config.id_method))

        CTX.handle_cmd(cmd, serial_size)


class strPID(node):
    """Self-Tuning PID (RLS identification + PID mapping).

    Inputs: [reference, plant output]
    Outputs: [control, Kp, Ki, Kd]
    """

    def __init__(self, config: PP_STR_PID_Config) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # lambda
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # P_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # desired_cl_bw
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # UpdateDivider_u16
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewSTR_PID, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.lambda_))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.P_init))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.desired_cl_bw))
        # Clamped here as well as on the board, so a value a caller made up
        # never reaches the wire. A board built before this parameter existed
        # reads a shorter frame and defaults it to 1.
        divider = int(getattr(config, "UpdateDivider_u16", 1) or 1)
        divider = max(1, min(64, divider))
        CTX.prepare_param(cmd, 4, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, divider)

        CTX.handle_cmd(cmd, serial_size)


class mracPID(node):
    """Model Reference Adaptive PID.

    Inputs: [reference, plant output]
    Outputs: [control, Kp, Ki, Kd]
    """

    def __init__(self, config: PP_MRAC_PID_Config) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Am
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Bm
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_p
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_i
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # gamma_d
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 6, PP_SubFuncId.NewMRAC_PID, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Am))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Bm))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_p))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_i))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.gamma_d))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))

        CTX.handle_cmd(cmd, serial_size)


class escPID(node):
    """Extremum Seeking PID Optimizer.

    Inputs: [error, plant output]
    Outputs: [control, Kp, Ki, Kd]
    """

    def __init__(self, config: PP_ESC_PID_Config) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kp_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Ki_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kd_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # a
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega_p
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega_i
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # omega_d
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # esc_gain
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # lpf_wc
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # iae_window
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 11, PP_SubFuncId.NewESC_PID, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kp_init))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Ki_init))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kd_init))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.a))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega_p))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega_i))
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.omega_d))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.esc_gain))
        CTX.prepare_param(cmd, 8, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.lpf_wc))
        CTX.prepare_param(cmd, 9, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))
        CTX.prepare_param(cmd, 10, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.iae_window))

        CTX.handle_cmd(cmd, serial_size)


class perfMonitorPID(node):
    """Performance-Monitoring Adaptive PID.

    Inputs: [error, scheduling variable (optional)]
    Outputs: [control, Kp, Ki, Kd, status]
    """

    def __init__(self, config: PP_PerfMonPID_Config) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kp_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Ki_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kd_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # iae_threshold
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_min
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_max
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # eval_window
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewPerfMonitor_PID, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kp_init))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Ki_init))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kd_init))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.iae_threshold))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_min))
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_max))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.eval_window))

        CTX.handle_cmd(cmd, serial_size)


class fuzzyPID(node):
    """Fuzzy logic PID gain adjuster.

    Input: error
    Outputs: [control, Kp, Ki, Kd]
    """

    def __init__(self, config: PP_FuzzyPIDConfig) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kp_base
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Ki_base
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Kd_base
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # e_range
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # de_range
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # Tau
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_min
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # out_max
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 8, PP_SubFuncId.NewFuzzyPID, self.getId())

        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kp_base))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Ki_base))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Kd_base))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.e_range))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.de_range))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.Tau))
        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_min))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(config.out_max))

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Misc blocks
# -----------------------------------------------------------------------------

class momentaryPower(tf):
    """Short-term loudness / momentary power measurement.

    Input: signal
    Output: short-term power
    """

    def __init__(self, block_size: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # block_size
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMomentaryPower, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(block_size))

        CTX.handle_cmd(cmd, serial_size)


class maxObserver(tf):
    """Maximum value observer (sliding window).

    Input: signal
    Output: running maximum
    """

    def __init__(self, window_size: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # window_size
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMaxObserver, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(window_size))

        CTX.handle_cmd(cmd, serial_size)


class minObserver(tf):
    """Minimum value observer (sliding window).

    Input: signal
    Output: running minimum
    """

    def __init__(self, window_size: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # window_size
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMinObserver, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(window_size))

        CTX.handle_cmd(cmd, serial_size)


class mux(node):
    """Multiplexer node: selects one of N input signals based on a selector input.

    The selector is a float signal, rounded to the nearest integer and clamped
    to the valid range [0, N-1].

    Inputs 0..N-1: data channels
    Input  N:      selector (float, 0-based)
    Output 0:      selected channel value
    """

    def __init__(self, n_inputs: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # n_inputs
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewMux, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n_inputs))

        CTX.handle_cmd(cmd, serial_size)


class demux(node):
    """Demultiplexer node: routes a single input to one of N outputs based on a selector.

    The selector is a float signal, rounded to the nearest integer and clamped
    to the valid range [0, N-1].  Non-selected outputs are set to zero.

    Input  0:      data signal
    Input  1:      selector (float, 0-based)
    Outputs 0..N-1: output channels (only the selected one receives data)
    """

    def __init__(self, n_outputs: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # n_outputs
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewDemux, self.getId())

        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(n_outputs))

        CTX.handle_cmd(cmd, serial_size)


class loudness(node):
    """Loudness computer (ITU-R BS.1770-style).

    Input: signal
    Output: loudness measurement
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 0, PP_SubFuncId.NewLoudness, self.getId())

        CTX.handle_cmd(cmd, serial_size)


# -----------------------------------------------------------------------------
# Kalman / RLS nodes
# -----------------------------------------------------------------------------

class adaptiveKF(node):
    """Adaptive Kalman Filter (AKF) for state estimation in systems where
    the measurement noise characteristics change over time.

    The AKF adaptively updates the measurement noise covariance R at each
    sample using the alpha gain: R = alpha*R + (1-alpha)*(y*y' + H*P*H').

    IO (variable, depends on dimensions):
        Inputs [0..dim_z-1]: Measurement vector z
        Inputs [dim_z..dim_z+dim_u-1]: Control vector u (if dim_u > 0)
        Input  [dim_z+dim_u]: Live-tune Q diagonal (PP_LiveTune mode only)
        Outputs [0..dim_x-1]: Estimated state vector x

    Requires design-time matrices: F, H, Q, B and initial conditions x_init, P_init, R_init.
    """

    def __init__(self, AKF: PP_adaptiveKF, select: Optional[PP_Tune] = None) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        dim_x = int(AKF.dim_x)
        dim_z = int(AKF.dim_z)
        dim_u = int(AKF.dim_u)

        sz_u16 = PP_UINT16_SIZE
        sz_x0 = dim_x * PP_REAL_SIZE
        sz_F = dim_x * dim_x * PP_REAL_SIZE
        sz_H = dim_z * dim_x * PP_REAL_SIZE
        sz_Q = dim_x * dim_x * PP_REAL_SIZE
        sz_B = dim_x * dim_u * PP_REAL_SIZE

        # dim_u and B must agree before anything is serialized: dim_u > 0
        # declares control inputs, and the firmware then reads dim_x*dim_u
        # floats of B, so a missing or wrongly sized B would put a
        # malformed frame on the wire. Refuse it here instead (the old
        # path sent a two-float placeholder where dim_x*dim_u floats were
        # expected). With dim_u = 0 the firmware never uses B: a supplied
        # B is ignored and a two-float placeholder is sent, which is what
        # the C++ library's no-B path sends too.
        if dim_u > 0:
            if not AKF.B_data:
                raise ValueError(
                    f"adaptiveKF: dim_u = {dim_u} declares control inputs "
                    f"but B_data is missing; provide a dim_x*dim_u B matrix "
                    f"(row-major) or set dim_u = 0.")
            if len(AKF.B_data) != dim_x * dim_u:
                raise ValueError(
                    f"adaptiveKF: B_data has {len(AKF.B_data)} values; a "
                    f"dim_x*dim_u = {dim_x}*{dim_u} = {dim_x * dim_u} "
                    f"matrix (row-major) is required.")
            B_data = AKF.B_data
        else:
            sz_B = 2 * PP_REAL_SIZE
            B_data = [0.0, 0.0]

        serial_size = (
            PP_FIXED_SIZE
            + 2 * (PP_PARAM_INFO_SIZE + sz_u16)
            + (PP_PARAM_INFO_SIZE + sz_x0)
            + 4 * (PP_PARAM_INFO_SIZE + sz_F)  # F,Q,B sizes use sz_F for F and Q; B can differ, but C++ adds (PP_PARAM_INFO_SIZE + sz_B) separately
        )
        # The above is not a clean formula in the C++ code; we replicate their exact computation below:
        serial_size = (
            PP_FIXED_SIZE
            + 2 * (PP_PARAM_INFO_SIZE + sz_u16)  # dim_x, dim_z
            + (PP_PARAM_INFO_SIZE + sz_x0)
            + 2 * (PP_PARAM_INFO_SIZE + sz_F)    # F, Q
            + (PP_PARAM_INFO_SIZE + sz_H)
            + (PP_PARAM_INFO_SIZE + sz_B)
            + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)  # R_init, P_init
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)      # alpha
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # tune
            + (PP_PARAM_INFO_SIZE + sz_u16)          # dim_u
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 12, PP_SubFuncId.NewAdaptiveKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_x)
        CTX.prepare_param(cmd, 1, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_z)

        CTX.prepare_param(cmd, 5, sz_F, PP_FuncParamId.TYPE_RealArray, AKF.F_data)
        CTX.prepare_param(cmd, 3, sz_H, PP_FuncParamId.TYPE_RealArray, AKF.H_data)
        CTX.prepare_param(cmd, 4, sz_Q, PP_FuncParamId.TYPE_RealArray, AKF.Q_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, AKF.x_init)

        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(AKF.R_init))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(AKF.P_init))
        CTX.prepare_param(cmd, 8, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(AKF.alpha))

        # The caller's live-tune choice goes on the wire; the firmware reads
        # param 9 and enables the live-tune input when it is PP_LiveTune.
        # This used to hardcode PP_NoLiveTune and drop `select` silently.
        tune_val = int(select) if select is not None else int(PP_Tune.PP_NoLiveTune)
        CTX.prepare_param(cmd, 9, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, tune_val)

        CTX.prepare_param(cmd, 10, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_u)
        CTX.prepare_param(cmd, 11, sz_B, PP_FuncParamId.TYPE_RealArray, B_data)

        CTX.handle_cmd(cmd, serial_size)


class linearKF(node):
    """Linear Kalman Filter (LKF) for optimal state estimation in linear
    systems affected by process and measurement noise.

    IO (variable, depends on dimensions):
        Inputs [0..dim_z-1]: Measurement vector z
        Inputs [dim_z..dim_z+dim_u-1]: Control vector u (if dim_u > 0)
        Input  [dim_z+dim_u]: Live-tune Q diagonal (PP_LiveTune mode only)
        Outputs [0..dim_x-1]: Estimated state vector x

    Requires design-time matrices: F, H, Q, B and initial conditions x_init, P_init, R_init.
    """

    def __init__(self, LKF: PP_linearKF, select: Optional[PP_Tune] = None) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        dim_x = int(LKF.dim_x)
        dim_z = int(LKF.dim_z)
        dim_u = int(LKF.dim_u)

        sz_u16 = PP_UINT16_SIZE
        sz_x0 = dim_x * PP_REAL_SIZE
        sz_F = dim_x * dim_x * PP_REAL_SIZE
        sz_H = dim_z * dim_x * PP_REAL_SIZE
        sz_Q = dim_x * dim_x * PP_REAL_SIZE
        sz_B = dim_x * dim_u * PP_REAL_SIZE

        if LKF.B_data is None:
            sz_B = 2 * PP_REAL_SIZE
            B_data = [0.0, 0.0]
        else:
            B_data = LKF.B_data

        serial_size = (
            PP_FIXED_SIZE
            + 2 * (PP_PARAM_INFO_SIZE + sz_u16)
            + (PP_PARAM_INFO_SIZE + sz_x0)
            + 2 * (PP_PARAM_INFO_SIZE + sz_F)
            + (PP_PARAM_INFO_SIZE + sz_H)
            + (PP_PARAM_INFO_SIZE + sz_B)
            + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # R_init, P_init
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)      # tune
            + (PP_PARAM_INFO_SIZE + sz_u16)              # dim_u
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 11, PP_SubFuncId.NewIdealKF, self.getId())

        CTX.prepare_param(cmd, 0, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_x)
        CTX.prepare_param(cmd, 1, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_z)

        CTX.prepare_param(cmd, 5, sz_F, PP_FuncParamId.TYPE_RealArray, LKF.F_data)
        CTX.prepare_param(cmd, 3, sz_H, PP_FuncParamId.TYPE_RealArray, LKF.H_data)
        CTX.prepare_param(cmd, 4, sz_Q, PP_FuncParamId.TYPE_RealArray, LKF.Q_data)
        CTX.prepare_param(cmd, 2, sz_x0, PP_FuncParamId.TYPE_RealArray, LKF.x_init)

        CTX.prepare_param(cmd, 6, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(LKF.R_init))
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(LKF.P_init))

        tune_val = int(select) if select is not None else int(PP_Tune.PP_NoLiveTune)
        CTX.prepare_param(cmd, 8, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, tune_val)

        CTX.prepare_param(cmd, 9, sz_u16, PP_FuncParamId.TYPE_Uint16, dim_u)
        CTX.prepare_param(cmd, 10, sz_B, PP_FuncParamId.TYPE_RealArray, B_data)

        CTX.handle_cmd(cmd, serial_size)


class RRLS(node):
    """Robust Recursive Least Squares identification. Produces vector output compatible with VectorProbe.

    Inputs:
        y: input 0
        u: input 1
    Outputs:
        y_hat: output 0
        error: output 1
    """

    def __init__(self, data: PP_RRLSParam) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        num_size = int(data.lenNum) * PP_REAL_SIZE
        den_size = int(data.lenDenom) * PP_REAL_SIZE
        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + num_size)       # num
            + (PP_PARAM_INFO_SIZE + den_size)        # denom
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # InitVariance
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)   # ModelOrder
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)    # sensParam
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)  # UpdateDivider
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 6, PP_SubFuncId.NewRRLS, self.getId())
        CTX.prepare_param(cmd, 0, num_size, PP_FuncParamId.TYPE_RealArray, data.num)
        CTX.prepare_param(cmd, 1, den_size, PP_FuncParamId.TYPE_RealArray, data.denom)
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(data.InitVariance_f32))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(data.ModelOrder_u8))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(data.sensParam_f32))
        CTX.prepare_param(cmd, 5, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          int(getattr(data, "UpdateDivider_u16", 1) or 1))
        CTX.handle_cmd(cmd, serial_size)

        self.dataLines = 2 * int(data.ModelOrder_u8) + 1
        self.dataRaw = 1


class RLS(node):
    """Recursive Least Squares identification. Produces vector output compatible with VectorProbe.

    Inputs:
        y: input 0
        u: input 1
    Outputs:
        y_hat: output 0
        error: output 1
    """

    def __init__(self, data: PP_RLSParam) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        num_size = int(data.lenNum) * PP_REAL_SIZE
        den_size = int(data.lenDenom) * PP_REAL_SIZE
        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + num_size)      # num
            + (PP_PARAM_INFO_SIZE + den_size)       # denom
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)   # InitVariance
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)  # ModelOrder
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) # UpdateDivider
        )

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewRLS, self.getId())
        CTX.prepare_param(cmd, 0, num_size, PP_FuncParamId.TYPE_RealArray, data.num)
        CTX.prepare_param(cmd, 1, den_size, PP_FuncParamId.TYPE_RealArray, data.denom)
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(data.InitVariance_f32))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(data.ModelOrder_u8))
        CTX.prepare_param(cmd, 4, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          int(getattr(data, "UpdateDivider_u16", 1) or 1))
        CTX.handle_cmd(cmd, serial_size)

        self.dataLines = 2 * int(data.ModelOrder_u8) + 1
        self.dataRaw = 1


class pidFromModel(node):
    """PID gains computed from an identified model.

    Attaches to an RLS or RRLS block rather than being wired to it, the way
    fftMagResolver attaches to an fft: the parameter vector it needs is the
    identifier's private state and no wire carries it. The identifier is
    passed to the constructor and its block id travels on the wire.

    Inputs:
        identifier: input 0
    Outputs:
        Kp: output 0
        Ki: output 1
        Kd: output 2
        Tau: output 3
        status: output 4, only when report_status is True
    """

    def __init__(self, identifier: Union[RLS, RRLS],
                 lambda_c: float = 0.1,
                 gain_slew_per_s: float = 2.0,
                 kp_max: float = 0.0,
                 ki_max: float = 0.0,
                 kd_max: float = 0.0,
                 report_status: bool = False) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = (
            PP_FIXED_SIZE
            + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)      # parent block id
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)        # lambda_c
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)        # gain_slew_per_s
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)        # kp_max
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)        # ki_max
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)        # kd_max
            + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)       # report_status
        )
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 7,
                                     PP_SubFuncId.NewPidFromModel, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          identifier.getId())
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(lambda_c))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(gain_slew_per_s))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(kp_max))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(ki_max))
        CTX.prepare_param(cmd, 5, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(kd_max))
        CTX.prepare_param(cmd, 6, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8,
                          1 if report_status else 0)
        CTX.handle_cmd(cmd, serial_size)

        # The block publishes eight floats to a vector probe:
        # Kp, Ki, Kd, Tau, the identified DC gain, the identified natural
        # frequency in Hz, the identified damping ratio, and the status.
        self.dataLines = 8
        self.dataRaw = 1


# -----------------------------------------------------------------------------
# Macro RLS wrapper + ParamEQ macros
# -----------------------------------------------------------------------------

class rls(macro):
    """RLS macro wrapper for adaptive parameter estimation.

    **This block does not work on the board yet, and now says so instead of
    corrupting it.** It sends its own sub-function id
    (:attr:`PP_SubFuncId.NewRLSMacro`, 241 = 0xF1), which firmware does not
    implement, so the board answers "unknown sub-function" and refuses.

    Until 2026-07-30 it sent this four-parameter layout
    (``[Uint8 modelOrd, Real gain, Uint8 0xFF, Uint16 systemId]``) on
    ``NewRLS`` (101 = 0x65), the plain :class:`RLS` block's opcode. For that
    opcode the board reads a completely different parameter layout::

        param 0 : numerator coefficients   (array of floats)
        param 1 : denominator coefficients (array of floats)
        param 2 : initial variance         (float)
        param 3 : model order              (uint8)

    so ``modelOrd`` landed in the slot the board reads as a pointer to
    floats, and the board dereferenced it. That is a wild pointer read on
    the board, not merely a wrong result.

    Not reachable from the Model Builder (codegen emits the plain
    :class:`RLS`), so this is a hand-written-code-only API.

    **What the board would need, and why it is not done here:** the board
    has no macro-shaped RLS block. The RLS it does have wants numerator
    and denominator coefficient arrays, an initial variance and a model
    order. This macro's ``gain`` is not an initial variance and it carries
    no coefficient arrays at all, so a handler for 0xF1 cannot be
    written without first deciding what the macro is supposed to build.
    That is a firmware design decision.

    Use :class:`RLS` directly: its layout matches the firmware exactly.
    """

    def __init__(self, modelOrd: int, gain: float, system: macro) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        # Three parameters, matching the C++ library exactly. Python used to
        # send a fourth (an undocumented ``Uint8 0xFF`` at index 2), which
        # made the two libraries build different frames for the same block.
        # That divergence was invisible because ``test_python_cpp_wire_sync``
        # carried it as a known difference attributed to the plain ``NewRLS``
        # opcode; splitting the ids exposed it. The filler byte cannot be
        # missed: no firmware handler reads this id at all, and the C++ side
        # never sent it.
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE) + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_blockID_SIZE)

        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewRLSMacro, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(modelOrd))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(gain))
        CTX.prepare_param(cmd, 2, PP_blockID_SIZE, PP_FuncParamId.TYPE_Uint16, system.getId())
        CTX.handle_cmd(cmd, serial_size)


class decimation(macro):
    """Placeholder for a downsampling block. It cannot be built.

    The board has no downsampling block, so there is nothing for this
    class to create and constructing it always raises. PAPAYA Studio will
    not generate a design that contains one either. Downsample on the
    host instead, after reading the samples off the board.
    """

    def __init__(self, Buffer: Sequence[float]) -> None:
        raise NotImplementedError(
            "decimation cannot be created: the board has no downsampling "
            "block. Read the samples and downsample them on the host.")


class paramEQLow(macro):
    """TRUE RBJ low-shelf parametric EQ.

    Cascade of ``n = max(1, FilterOrder // 2)`` RBJ "Audio EQ Cookbook"
    low-shelf biquads (each at ``Gain/n`` dB, total = ``Gain`` dB). Flat
    unity floor above the shelf corner.

    Args:
        Fc: Shelf corner frequency (Hz).
        FilterOrder: Stage count -> n = max(1, FilterOrder // 2) biquads.
        Gain: Shelf gain in DECIBELS (dB); positive boosts, negative cuts,
            0 dB is flat.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Fc: float, FilterOrder: int, Gain: float) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewParamEQLow, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fc))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(FilterOrder))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Gain))
        CTX.handle_cmd(cmd, serial_size)


class ParamEQHigh(macro):
    """TRUE RBJ high-shelf parametric EQ.

    Cascade of ``n = max(1, FilterOrder // 2)`` RBJ high-shelf biquads
    (each at ``Gain/n`` dB, total = ``Gain`` dB). Flat unity floor below
    the shelf corner.

    Args:
        Fc: Shelf corner frequency (Hz).
        FilterOrder: Stage count -> n = max(1, FilterOrder // 2) biquads.
        Gain: Shelf gain in DECIBELS (dB); positive boosts, negative cuts,
            0 dB is flat.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Fc: float, FilterOrder: int, Gain: float) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewParamEQHigh, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fc))
        CTX.prepare_param(cmd, 1, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(FilterOrder))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Gain))
        CTX.handle_cmd(cmd, serial_size)


class ParamEQBand(macro):
    """TRUE RBJ band (peaking) parametric EQ.

    RBJ peaking EQ centred at the geometric mean ``f0 = sqrt(Fc1*Fc2)`` with
    ``Q = f0 / (Fc2 - Fc1)`` (clamped to >= 0.1), cascaded
    ``n = max(1, FilterOrder // 2)`` times at ``Gain/n`` dB each. Flat unity
    floor outside the band.

    Args:
        Fc1: Lower band edge (Hz).
        Fc2: Upper band edge (Hz), Fc2 > Fc1.
        FilterOrder: Stage count -> n = max(1, FilterOrder // 2) biquads.
        Gain: Band gain in DECIBELS (dB); positive boosts, negative cuts,
            0 dB is flat.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Fc1: float, Fc2: float, FilterOrder: int, Gain: float) -> None:
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE) + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewParamEQBand, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fc1))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fc2))
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(FilterOrder))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Gain))
        CTX.handle_cmd(cmd, serial_size)


class ParamEQPeak(macro):
    """TRUE RBJ peaking parametric EQ.

    Single RBJ "Audio EQ Cookbook" peaking biquad at fixed Q = 5.0. Flat
    unity floor away from the centre frequency.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Fccenter: float, Gain: float) -> None:
        """TRUE RBJ peaking parametric EQ macro.

        The board hard-codes the resonator
        Q at 5.0; Q is not user-configurable.

        Args:
            Fccenter: Centre frequency (Hz).
            Gain: Peak gain in DECIBELS (dB); positive boosts, negative
                cuts, 0 dB is flat.
        """
        super().__init__()
        self.setId(macro.currentMacroId)
        macro.currentMacroId += 1
        self.out(0)

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewParamEQPeak, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fccenter))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Gain))
        CTX.handle_cmd(cmd, serial_size)


# ======================== Audio processing ========================

class limiter(tf):
    """Brick-wall limiter with attack/release smoothing and dB ceiling.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Attack_s: float, Release_s: float, Ceiling_dB: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewLimiter, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Attack_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Release_s))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Ceiling_dB))
        CTX.handle_cmd(cmd, serial_size)


class noiseGate(tf):
    """Downward expander / noise gate with attack/release smoothing.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Attack_s: float, Release_s: float, Threshold_dB: float, Range_dB: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewNoiseGate, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Attack_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Release_s))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Threshold_dB))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Range_dB))
        CTX.handle_cmd(cmd, serial_size)


class envFollower(tf):
    """Envelope follower with asymmetric attack/release smoothing.

    Inputs:
        in: input 0
    Outputs:
        envelope: output 0
    """

    def __init__(self, Attack_s: float, Release_s: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewEnvFollower, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Attack_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Release_s))
        CTX.handle_cmd(cmd, serial_size)


class adsr(tf):
    """ADSR envelope generator driven by a gate input.

    Inputs:
        gate: input 0 (>= 0.5 means note on)
    Outputs:
        envelope: output 0 (in [0, 1])
    """

    def __init__(self, Attack_s: float, Decay_s: float, Sustain: float, Release_s: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewADSR, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Attack_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Decay_s))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Sustain))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Release_s))
        CTX.handle_cmd(cmd, serial_size)


class fracDelay(tf):
    """Fractional (interpolated) delay line with runtime-tunable delay length.

    Inputs:
        signal: input 0
        delay: input 1 (fractional samples)
    Outputs:
        out: output 0
    """

    def __init__(self, MaxDelaySamples: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT32_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewFracDelay, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT32_SIZE, PP_FuncParamId.TYPE_Uint32, int(MaxDelaySamples))
        CTX.handle_cmd(cmd, serial_size)


class chorus(tf):
    """Chorus effect: modulated short delay summed with dry signal.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Rate_Hz: float, Depth_ms: float, Mix: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewChorus, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Rate_Hz))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Depth_ms))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Mix))
        CTX.handle_cmd(cmd, serial_size)


class flanger(tf):
    """Flanger effect: very short modulated delay with feedback.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Rate_Hz: float, Depth_ms: float, Feedback: float, Mix: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 4, PP_SubFuncId.NewFlanger, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Rate_Hz))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Depth_ms))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Feedback))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Mix))
        CTX.handle_cmd(cmd, serial_size)


class phaser(tf):
    """Phaser effect: cascaded allpass stages with LFO-modulated coefficients.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Rate_Hz: float, Depth: float, Feedback: float, NumStages: int, Mix: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (PP_FIXED_SIZE
                       + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                       + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5, PP_SubFuncId.NewPhaser, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Rate_Hz))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Depth))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Feedback))
        CTX.prepare_param(cmd, 3, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(NumStages))
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Mix))
        CTX.handle_cmd(cmd, serial_size)


class reverb(tf):
    """Feedback-delay-network reverberator.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, DecayTime_s: float, Mix: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewReverb, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(DecayTime_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Mix))
        CTX.handle_cmd(cmd, serial_size)


class stereoPan(node):
    """Constant-power stereo panner.

    Inputs:
        signal: input 0
        pan: input 1 (in [-1, +1])
    Outputs:
        left: output 0
        right: output 1
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewStereoPan, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class distortion(tf):
    """Waveshaping distortion with selectable nonlinearity.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, Drive: float, Mix: float, Type: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (PP_FIXED_SIZE
                       + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                       + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewDistortion, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Drive))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Mix))
        CTX.prepare_param(cmd, 2, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(Type))
        CTX.handle_cmd(cmd, serial_size)


class bitcrusher(tf):
    """Bitcrusher: bit-depth reduction plus sample-rate decimation.

    Inputs:
        in: input 0
    Outputs:
        out: output 0
    """

    def __init__(self, BitDepth: float, SRReduction: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = (PP_FIXED_SIZE
                       + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
                       + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE))
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewBitcrusher, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(BitDepth))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(SRReduction))
        CTX.handle_cmd(cmd, serial_size)


class ringMod(node):
    """Ring modulator: multiplies two signals.

    Inputs:
        signal: input 0
        carrier: input 1
    Outputs:
        out: output 0 (signal * carrier)
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(PP_FIXED_SIZE, PP_FuncId.Createblock, 0, PP_SubFuncId.NewRingMod, self.getId())
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class pitchDetect(tf):
    """Autocorrelation-based fundamental-frequency detector.

    Inputs:
        in: input 0
    Outputs:
        frequency: output 0 (Hz)
    """

    def __init__(self, MinFreq: float, MaxFreq: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewPitchDetect, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(MinFreq))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(MaxFreq))
        CTX.handle_cmd(cmd, serial_size)


class vuMeter(tf):
    """VU / PPM meter: asymmetric rise/fall smoothing on |x|, output in dB.

    Inputs:
        in: input 0
    Outputs:
        level_dB: output 0
    """

    def __init__(self, RiseTime_s: float, FallTime_s: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewVUMeter, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(RiseTime_s))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(FallTime_s))
        CTX.handle_cmd(cmd, serial_size)


class stereoMixer(node):
    """N-channel stereo mixer: sums all inputs, duplicates to L/R outputs.

    Per-channel gain is set via node coefficients; chain with ``stereoPan``
    upstream for true stereo placement.

    Inputs:
        ch_i: input i (NumChannels inputs total)
    Outputs:
        left: output 0
        right: output 1 (identical mono sum)
    """

    def __init__(self, NumChannels: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT8_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewStereoMixer, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT8_SIZE, PP_FuncParamId.TYPE_Uint8, int(NumChannels))
        CTX.handle_cmd(cmd, serial_size)


# ======================== Wavelet-domain post-processing ========================

class dwt_denoise(tf):
    """DWT Denoising block: estimates noise and applies level-dependent thresholding.

    Must be linked to an existing :class:`dwt` instance that supplies the
    wavelet coefficient stream.

    Inputs:
        coeffs: input 0 (from associated DWT)
    Outputs:
        denoised_coeffs: output 0
    """

    def __init__(self, associated_dwt: dwt,
                 thresh_type: PP_ThresholdType = PP_ThresholdType.PP_THRESH_SOFT,
                 thresh_scale: float = 1.0) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        self.associatedDWT = associated_dwt
        self.threshType = thresh_type
        # thresh_scale multiplies the firmware's auto-estimated MAD sigma before
        # thresholding (1.0 = firmware default).  Slot 2 is always emitted; the
        # firmware treats a value <= 0 as 1.0 and older firmware that only reads
        # slots 0/1 simply ignores it (forward/backward-compatible).
        self.threshScale = float(thresh_scale)

        serial_size = (
            PP_FIXED_SIZE
            + 2 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        )
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3, PP_SubFuncId.NewDwtDenoise, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, associated_dwt.getId())
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(thresh_type))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(thresh_scale))
        CTX.handle_cmd(cmd, serial_size)

        # Denoise rewrites the parent DWT's coefficient buffer in-place;
        # the firmware probe exposes the same N-sample buffer.
        self.dataLines = int(associated_dwt.getNbSamples())
        self.dataRaw = 1

    def getAssociatedDWT(self) -> dwt:
        return self.associatedDWT

    def getThresholdType(self) -> PP_ThresholdType:
        return self.threshType

    def getThresholdScale(self) -> float:
        return self.threshScale


class dwt_subband_gain(tf):
    """DWT Subband Gain block: applies per-subband scalar gains.

    Inputs:
        coeffs: input 0 (from associated DWT)
    Outputs:
        scaled_coeffs: output 0
    """

    def __init__(self, associated_dwt: dwt,
                 gains: Optional[Sequence[float]] = None) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        self.associatedDWT = associated_dwt
        # One LINEAR gain multiplier per subband, in firmware subband_ptr_len()
        # order, length = parent decomposition_levels + 1.  gains=None omits the
        # param entirely -> firmware fills unity (backward-compatible).
        num_bands = int(associated_dwt.levels) + 1

        if gains is None:
            self.gains = None
            serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewDwtSubbandGain, self.getId())
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, associated_dwt.getId())
            CTX.handle_cmd(cmd, serial_size)
        else:
            # Auto-reconcile the vector length to the linked DWT's CURRENT
            # levels: pad new/coarser bands with unity, drop extras.  This keeps
            # a stored gains vector valid after the parent's `levels` changes and
            # guarantees the firmware's fixed numBands copy never reads OOB.
            gains_list = [float(g) for g in gains]
            if len(gains_list) < num_bands:
                gains_list += [1.0] * (num_bands - len(gains_list))
            elif len(gains_list) > num_bands:
                gains_list = gains_list[:num_bands]
            self.gains = gains_list

            arr_size = num_bands * PP_REAL_SIZE
            serial_size = (
                PP_FIXED_SIZE
                + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
                + (PP_PARAM_INFO_SIZE + arr_size)
            )
            # use_global_command=False mirrors CustFir: an array-carrying command
            # is emitted from a fresh PP_CommandInfo (matches the C++ lib).
            cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2, PP_SubFuncId.NewDwtSubbandGain, self.getId(), use_global_command=False)
            CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, associated_dwt.getId())
            CTX.prepare_param(cmd, 1, arr_size, PP_FuncParamId.TYPE_RealArray, gains_list)
            CTX.handle_cmd(cmd, serial_size)

        # SubbandGain rescales the parent DWT's coefficients in-place;
        # the board's probe exposes the parent DWT's N-sample coeff buffer.
        self.dataLines = int(associated_dwt.getNbSamples())
        self.dataRaw = 1

    def getAssociatedDWT(self) -> dwt:
        return self.associatedDWT

    def getGains(self) -> Optional[Sequence[float]]:
        return self.gains


class dwt_subband_energy(tf):
    """DWT Subband Energy block: measures energy per subband (vector output).

    Inputs:
        coeffs: input 0 (from associated DWT)
    Outputs:
        energies: output 0 (vector, one value per subband)
    """

    def __init__(self, associated_dwt: dwt) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        self.associatedDWT = associated_dwt

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1, PP_SubFuncId.NewDwtSubbandEnergy, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, associated_dwt.getId())
        CTX.handle_cmd(cmd, serial_size)

        # Firmware exposes one float32 of energy per subband
        # (= decomposition_levels + 1).
        self.dataLines = int(associated_dwt.levels) + 1
        self.dataRaw = 1

    def getAssociatedDWT(self) -> dwt:
        return self.associatedDWT


# ─────────────────────────────────────────────────────────────────────────────
#  Infrastructure blocks
# ─────────────────────────────────────────────────────────────────────────────
class quatMult(node):
    r"""Hamilton product (multiplication) of two quaternions: q3 = q1 \otimes q2.

    Implemented as a Node (variable-arity at the framework level, but always
    8 inputs and 4 outputs in practice), following the same convention as
    ``mag2`` and ``mag3``.

    Component form (Diebel 2006):

        qw = w1*w2 - x1*x2 - y1*y2 - z1*z2
        qx = w1*x2 + x1*w2 + y1*z2 - z1*y2
        qy = w1*y2 - x1*z2 + y1*w2 + z1*x2
        qz = w1*z2 + x1*y2 - y1*x2 + z1*w2

    Inputs:
        q1w, q1x, q1y, q1z: inputs 0-3  (first  quaternion)
        q2w, q2x, q2y, q2z: inputs 4-7  (second quaternion)
    Outputs:
        qw, qx, qy, qz:    outputs 0-3

    Foundation block for AHRS pipelines and rigid-body kinematics. Composition
    convention: ``q1 \otimes q2`` applies q2 first, then q1. If both inputs are
    unit quaternions, the output is unit (no renormalisation needed per step).

    Reference: Diebel 2006 - Representing Attitude (Stanford tech report).
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE  # zero-parameter block
        cmd = CTX.prepare_cmd_header(
            serial_size,
            PP_FuncId.Createblock,
            0,
            PP_SubFuncId.NewQuatMult,
            self.getId(),
        )
        CTX.handle_cmd(cmd, serial_size)


class quatFromEuler(node):
    """Convert Euler angles (roll, pitch, yaw) to a quaternion (ZYX order).

    Inputs:
        roll:  input 0 (radians)
        pitch: input 1 (radians)
        yaw:   input 2 (radians)
    Outputs:
        w, x, y, z: outputs 0-3

    Aerospace ZYX intrinsic Tait-Bryan convention (matches PX4 / Mahony /
    Madgwick).

    Reference: Diebel 2006 §5.6.
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(
            PP_FIXED_SIZE, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewQuatFromEuler, self.getId(),
        )
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class quatToEuler(node):
    """Convert a quaternion to Euler angles (roll, pitch, yaw) in ZYX order.

    Pitch is clipped to ±π/2 (gimbal-lock guard).

    Inputs:
        w, x, y, z: inputs 0-3
    Outputs:
        roll:  output 0 (radians)
        pitch: output 1 (radians)
        yaw:   output 2 (radians)

    Reference: Diebel 2006 §5.6.
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(
            PP_FIXED_SIZE, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewQuatToEuler, self.getId(),
        )
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class quatToRotmat(node):
    """Convert a quaternion to a 3×3 rotation matrix (row-major, 9 scalar outputs).

    Inputs:
        w, x, y, z: inputs 0-3
    Outputs:
        r00, r01, r02, r10, r11, r12, r20, r21, r22: outputs 0-8 (row-major)

    Reference: Diebel 2006 §5.5.
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(
            PP_FIXED_SIZE, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewQuatToRotmat, self.getId(),
        )
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class quatNormConj(node):
    """Quaternion normalise / conjugate / inverse selector.

    Inputs:
        w, x, y, z: inputs 0-3
        mode:       input 4 (0=NORMALIZE, 1=CONJUGATE, 2=INVERSE)
    Outputs:
        w', x', y', z': outputs 0-3
    """

    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1
        cmd = CTX.prepare_cmd_header(
            PP_FIXED_SIZE, PP_FuncId.Createblock, 0,
            PP_SubFuncId.NewQuatNormConj, self.getId(),
        )
        CTX.handle_cmd(cmd, PP_FIXED_SIZE)


class windowFramer(tf):
    """Sliding-window framer with hop H.

    Every H input samples, emits a length-N frame snapshot (host-visible via
    VectorProbe) and pulses ``frame_ready = 1.0`` on output 0.

    Inputs:
        x: input 0  (scalar sample per cycle)
    Outputs:
        frame_ready: output 0 (1.0 on frame-emit cycle, else 0.0)

    Parameters:
        N: int,   frame length in samples  (1 <= N <= 2048)
        H: int,   hop length in samples    (1 <= H <= N)

    Notes:
        - The framed buffer is exposed via VectorProbe (rows=N, lines=1),
          oldest-to-newest order.
        - N is capped at 2048, the board's 8192-byte per-probe payload
          ceiling divided by 4 bytes per float.
        - Setting H = N produces non-overlapping frames; H = N/2 gives 50%
          overlap (the STFT default).

    Reference: Allen & Rabiner 1977 - Proc-IEEE 65.
    """

    def __init__(self, N: int, H: int) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 2,
            PP_SubFuncId.NewWindowFramer, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(N))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(H))
        CTX.handle_cmd(cmd, serial_size)

        # Frame-buffer dimensions for the host's VectorProbe consumer.
        self.dataLines = int(N)
        self.dataRaw = 1


class zScoreNorm(node):
    """Welford running z-score normalizer.

    While training (count < train_window), maintains μ/M2 via Welford's
    one-pass algorithm and emits rolling-stat z-scores. Auto-freezes when
    count reaches train_window; or freezes immediately when input 1
    (``freeze``) is pulsed > 0.5.

    Inputs:
        x:      input 0  (sample)
        freeze: input 1  (>0.5 to force-freeze; <=0.5 to continue training)
    Outputs:
        z:      output 0 (z-scored)

    Parameters:
        train_window: int,   auto-freeze threshold (0 = never auto-freeze)
        epsilon: float,      additive guard on σ to prevent /0 (default 1e-9)
    """

    def __init__(self, train_window: int = 256, epsilon: float = 1e-9) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                                    + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 2,
            PP_SubFuncId.NewZScoreNorm, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(train_window))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(epsilon))
        CTX.handle_cmd(cmd, serial_size)


class innovationChi2(node):
    """Chi-square innovation gate.

    Computes ``chi2 = Σ y_i² / σ_i²`` over n_meas channels and pulses
    ``fault`` high when chi2 exceeds the chi-square threshold.

    Inputs:
        y_0..y_{n-1}:   inputs 0..n-1     (innovation per channel)
        σ_0..σ_{n-1}:   inputs n..2n-1   (per-channel standard deviation)
    Outputs:
        chi2:  output 0
        fault: output 1 (0.0/1.0)

    Parameters:
        n_meas: int,     number of measurement channels (1..16)
        threshold: float,  chi-square threshold (from χ²₀.₉₉(n_meas) table)
    """

    def __init__(self, n_meas: int, threshold: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                                    + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 2,
            PP_SubFuncId.NewInnovationChi2, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(n_meas))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(threshold))
        CTX.handle_cmd(cmd, serial_size)


class imuBiasEst(node):
    """IMU accelerometer + gyroscope bias estimator.

    Variance-gated EMA bias estimator. Detects "at rest" via rolling
    variance of |a|² over var_window samples; on rest cycles, blends the
    current reading into the EMA bias estimate with gain α.

    Inputs (6):
        ax, ay, az: inputs 0-2 (accelerometer, raw)
        gx, gy, gz: inputs 3-5 (gyroscope, raw)
    Outputs (12):
        ax̃, ãy, ãz, ω̃x, ω̃y, ω̃z: outputs 0-5 (bias-subtracted)
        bias_ax, bias_ay, bias_az: outputs 6-8
        bias_gx, bias_gy, bias_gz: outputs 9-11

    Parameters:
        var_window: int,        sliding-window size for accel-magnitude variance
        rest_threshold: float,  variance threshold below which rest is detected
        alpha: float,           EMA gain (0 < α ≤ 1; typical 0.01)
    """

    def __init__(self, var_window: int = 64, rest_threshold: float = 1e-3,
                 alpha: float = 0.01) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                                    + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 3,
            PP_SubFuncId.NewImuBiasEst, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(var_window))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(rest_threshold))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(alpha))
        CTX.handle_cmd(cmd, serial_size)


class madgwickAhrs(node):
    """Madgwick gradient-descent AHRS.

    Inputs (9):
        ax, ay, az, gx, gy, gz, mx, my, mz   (accelerometer + gyro + mag)
    Outputs (4):
        q0, q1, q2, q3   (Hamilton-convention orientation quaternion)

    Parameter:
        beta: float   - gradient-descent gain (typical 0.1)

    Sample period is taken from the design's global Fs, read on the
    board at runtime.

    Reference: Madgwick 2010, An efficient orientation filter for IMU and MARG sensor arrays (PhD thesis).
    """
    def __init__(self, beta: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewMadgwickAhrs, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(beta))
        CTX.handle_cmd(cmd, serial_size)


class mahonyAhrs(node):
    """Mahony complementary AHRS with gyro-bias estimation.

    Inputs (9): ax, ay, az, gx, gy, gz, mx, my, mz
    Outputs (7): q0, q1, q2, q3, bias_x, bias_y, bias_z

    Parameters:
        Kp: float   - proportional gain (typical 2.0)
        Ki: float   - integral gain     (typical 0.005)

    Sample period is taken from the design's global Fs, read on the
    board at runtime.

    Reference: Mahony, Hamel, Pflimlin 2008 - IEEE-TAC 53 (nonlinear complementary filters on SO(3)).
    """
    def __init__(self, Kp: float, Ki: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        serial_size = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 2,
                                     PP_SubFuncId.NewMahonyAhrs, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Kp))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Ki))
        CTX.handle_cmd(cmd, serial_size)


class complementaryAhrs(node):
    """Simple complementary AHRS: accel/mag static + gyro dynamic blend.

    Inputs (9): ax, ay, az, gx, gy, gz, mx, my, mz
    Outputs (4): q0, q1, q2, q3

    Parameter:
        alpha: float - gyro/static blend (0 < α < 1; typical 0.98)

    Sample period is taken from the design's global Fs, read on the
    board at runtime.
    """
    def __init__(self, alpha: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewComplementaryAhrs, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(alpha))
        CTX.handle_cmd(cmd, serial_size)


class mixerMultirotor(node):
    """Multirotor mixer: thrust + body-torques → per-motor PWM.

    Inputs (4): T (thrust), tx (roll), ty (pitch), tz (yaw)
    Outputs (8): motor_0..motor_7 (PWM values, clipped to [pwm_min, pwm_max])

    Parameters:
        frame_type: int  - 0=X4, 1=+4, 2=Y6, 3=X6, 4=X8 coax, 5=octo
        pwm_min: float   - lower PWM limit (e.g. 1000 µs)
        pwm_max: float   - upper PWM limit (e.g. 2000 µs)
    """
    def __init__(self, frame_type: int = 0, pwm_min: float = 1000.0, pwm_max: float = 2000.0) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                                    + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 3,
                                     PP_SubFuncId.NewMixerMultirotor, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(frame_type))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(pwm_min))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(pwm_max))
        CTX.handle_cmd(cmd, serial_size)


class lqrServo(node):
    """LQR state-feedback with servo integrator.

    Port layout:
        Inputs (n + 2p):
            x_0 .. x_{n-1}   plant state
            r_0 .. r_{p-1}   reference for each tracked output
            y_0 .. y_{p-1}   measured tracked output
        The block forms the tracking error e = r - y and integrates it
        INTERNALLY: wire the raw reference and raw measured output, NOT a
        pre-computed error (no external Sum node).
        Outputs (m):
            u_0 .. u_{m-1}   control signal, saturated to [-u_max, +u_max].

    Internal recursion (this is exactly what the board computes):
        x_i[k]    = x_i[k] + Ts · (r[k] - y[k])   (integrator update first)
        u[k]      = -K_x · x[k] - K_i · x_i[k]
        u[k]      = clip(u[k], -u_max, +u_max)

    Parameters:
        n: int          state dimension (1..16)
        m: int          control dimension (1..8)
        p: int          tracked-output / integrator dimension (0..8;
                        p=0 disables the integrator and reduces to a
                        plain LQR with n inputs and m outputs).
        K: list[float]  gain matrix, length m·(n+p), row-major
        u_max: float    symmetric saturation rail (0 disables clipping;
                        applied uniformly to every control channel;
                        for per-channel rails use external clip blocks).

    Sample period Ts is taken from the design's global Fs, read on the
    board at runtime. Design K with the LQR Designer in the block's Design tab
    inside the LQR_SERVO block, or offline by solving the discrete algebraic
    Riccati equation for the servo-augmented plant
    (``scipy.linalg.solve_discrete_are``) and forming
    ``K = (R + B.T @ P @ B)^-1 @ B.T @ P @ A``.
    """
    def __init__(self, n: int, m: int, p: int, K, u_max: float) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        k_arr = [float(v) for v in K]
        if len(k_arr) != m * (n + p):
            raise ValueError(f"LQR_SERVO: K length {len(k_arr)} != m*(n+p) = {m*(n+p)}")
        # 3 uint16 (n,m,p) + 1 float-array (K) + 1 float (u_max)
        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                                    + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE * len(k_arr)) \
                                    + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(serial_size, PP_FuncId.Createblock, 5,
                                     PP_SubFuncId.NewLqrServo, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(n))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(m))
        CTX.prepare_param(cmd, 2, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(p))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE * len(k_arr),
                          PP_FuncParamId.TYPE_RealArray, k_arr)
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(u_max))
        CTX.handle_cmd(cmd, serial_size)


class trajScurve(node):
    """7-segment S-curve (jerk-limited) trajectory generator.

    Inputs (5): p_target, v_max, a_max, j_max, start (>0.5 to begin)
    Outputs (4): p, v, a, j

    Sample period is taken from the design's global Fs, read on the
    board at runtime.
    """
    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 0,
                                     PP_SubFuncId.NewTrajScurve, self.getId())
        CTX.handle_cmd(cmd, ss)


class trajTrapezoid(node):
    """Trapezoidal-velocity trajectory generator.

    Inputs (4): p_target, v_max, a_max, start
    Outputs (3): p, v, a

    Sample period is taken from the design's global Fs, read on the
    board at runtime.
    """
    def __init__(self) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 0,
                                     PP_SubFuncId.NewTrajTrapezoid, self.getId())
        CTX.handle_cmd(cmd, ss)


class frictionStribeck(tf):
    """Static Stribeck friction feedforward.

    F(v) = sign(v) · ( Fc + (Fs−Fc) · exp(−(v/vs)²) ) + Bv · v

    Inputs (1): v (velocity)
    Outputs (1): F (friction force feedforward)

    Parameters:
        Fc: Coulomb friction (N)
        Fs: static friction  (N; Fs ≥ Fc)
        vs: Stribeck velocity (m/s; > 0)
        Bv: viscous coefficient (N·s/m)
    """
    def __init__(self, Fc: float, Fs: float, vs: float, Bv: float) -> None:
        super().__init__()
        self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + 4 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 4,
                                     PP_SubFuncId.NewFrictionStribeck, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fc))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Fs))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(vs))
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(Bv))
        CTX.handle_cmd(cmd, ss)


class inputShaper(tf):
    """ZV / ZVD / EI input shaper for vibration suppression.

    Inputs (1): x  (reference command to be shaped)
    Outputs (1): y  (shaped command)

    Parameters:
        mode: int,     0=ZV (2 impulses), 1=ZVD (3 impulses), 2=EI (3 impulses)
        wn:   float,   natural frequency of the resonant mode (rad/s)
        zeta: float,   damping ratio (0 ≤ ζ < 1)

    Sample period is taken from the design's global Fs at create time,
    and the board uses it when computing the impulse delays.
    """
    def __init__(self, mode: int = 0, wn: float = 10.0, zeta: float = 0.05) -> None:
        super().__init__()
        self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                           + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 3,
                                     PP_SubFuncId.NewInputShaper, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(mode))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(wn))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(zeta))
        CTX.handle_cmd(cmd, ss)


class hjorth(node):
    """Hjorth time-domain complexity stats.

    Inputs (1): x
    Outputs (3): activity (= var(x)), mobility (= sqrt(var(dx)/var(x))),
                 complexity (= mobility(dx) / mobility(x))

    Parameter: window_N (sliding-window size).
    Reference: Hjorth 1970 - EEG-Clin-Neuro 29.
    """
    def __init__(self, window_N: int = 128) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewHjorth, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.handle_cmd(cmd, ss)


class emgEnvelope(tf):
    """EMG envelope detector: TKEO + 1-pole LP.

    Inputs (1): raw EMG sample
    Outputs (1): envelope

    Parameter: cutoff_hz (LP corner).
    Sample period is taken from the design's global Fs at create time,
    and the board uses it when computing the low-pass coefficient.
    Reference: Kaiser 1990 (TKEO).
    """
    def __init__(self, cutoff_hz: float = 5.0) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewEmgEnvelope, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(cutoff_hz))
        CTX.handle_cmd(cmd, ss)


class emgHudgins(node):
    """EMG Hudgins time-domain feature set.

    Inputs (1): EMG sample
    Outputs (4): MAV, ZC, SSC, WL

    Parameters: window_N (sliding-window size), zc_threshold (>0).
    Reference: Hudgins 1993 - IEEE-TBME 40(1).
    """
    def __init__(self, window_N: int = 256, zc_threshold: float = 0.02) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                           + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 2,
                                     PP_SubFuncId.NewEmgHudgins, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(zc_threshold))
        CTX.handle_cmd(cmd, ss)


class ecgBlRemove(tf):
    """ECG baseline-wander remover.

    Subtracts the rolling minimum over W samples (cheap morphological-opening
    approximation). 1 in -> 1 out.

    Parameter: window_W (~200 ms worth of samples typical at ECG Fs).
    """
    def __init__(self, window_W: int = 50) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewEcgBlRemove, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_W))
        CTX.handle_cmd(cmd, ss)


class hrvTime(node):
    """HRV time-domain stats.

    Inputs (2): rr_s (RR-interval in seconds), beat_flag (>0.5 to push RR)
    Outputs (5): mean_rr, sdnn, rmssd, pnn50, hr_mean

    Parameter: ring_N (RR ring size; typical 64 or 128).
    Reference: ESC/Task-Force 1996 - short-term HRV standard.
    """
    def __init__(self, ring_N: int = 64) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewHrvTime, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(ring_N))
        CTX.handle_cmd(cmd, ss)


class eegBandpower(node):
    """EEG band-power (δ/θ/α/β/γ) from an upstream FFT_MAG block.

    Dependent block: pass the ``fftMagResolver`` instance to the
    constructor; the firmware reads its magnitude spectrum directly. Band
    edges are derived from the design's global sampling rate and the FFT
    length (taken from the FFT_MAG buffer), so no parameters are needed.

    Inputs:
        fft_mag: input 0  (scheduling link from the FFT_MAG block)
    Outputs (5): delta, theta, alpha, beta, gamma band power
    """
    def __init__(self, fft_mag_instance: fftMagResolver) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewEegBandpower, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          fft_mag_instance.getId())
        CTX.handle_cmd(cmd, ss)


class skewKurt(node):
    """Welford 3rd/4th moments.
    Inputs (1): x → Outputs (2): skewness, kurtosis (excess).
    Param: window_N (0 = never reset; >0 = reset after N samples).
    Reference: Pébay 2008 (Welford generalisation).
    """
    def __init__(self, window_N: int = 0) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1, PP_SubFuncId.NewSkewKurt, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.handle_cmd(cmd, ss)

class percentile(tf):
    """Jain-Chlamtac P² streaming percentile.
    Inputs (1): x → Outputs (1): estimated quantile value.
    Param: quantile (0 < q < 1; e.g. 0.5 for median, 0.95 for 95th percentile).
    """
    def __init__(self, quantile: float = 0.5) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1, PP_SubFuncId.NewPercentile, self.getId())
        CTX.prepare_param(cmd, 0, PP_REAL_SIZE, PP_FuncParamId.TYPE_Real, float(quantile))
        CTX.handle_cmd(cmd, ss)

class peakToPeak(tf):
    """Sliding-window peak-to-peak.
    Inputs (1): x → Outputs (1): max−min over window_N samples.
    """
    def __init__(self, window_N: int = 64) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1, PP_SubFuncId.NewPeakToPeak, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.handle_cmd(cmd, ss)

class crestFactor(tf):
    """Crest factor.
    Inputs (1): x → Outputs (1): peak / RMS over window_N samples.
    """
    def __init__(self, window_N: int = 64) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1, PP_SubFuncId.NewCrestFactor, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.handle_cmd(cmd, ss)

class zcr(tf):
    """Zero-crossing rate.
    Inputs (1): x → Outputs (1): ZCR over each window_N (emitted at window boundaries).
    Params: window_N, zc_threshold (>0; samples within ±threshold count as zero).
    """
    def __init__(self, window_N: int = 256, zc_threshold: float = 0.0) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 2, PP_SubFuncId.NewZcr, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(window_N))
        CTX.prepare_param(cmd, 1, PP_REAL_SIZE,   PP_FuncParamId.TYPE_Real,   float(zc_threshold))
        CTX.handle_cmd(cmd, ss)

class spectralFeatures(node):
    """Spectral features from an upstream FFT_MAG block.

    Dependent block: pass the ``fftMagResolver`` instance; the firmware
    reads its magnitude spectrum directly. The bin count is taken from the
    FFT_MAG buffer; spectral rolloff is fixed at the standard 0.85 fraction.

    Inputs:
        fft_mag: input 0  (scheduling link from the FFT_MAG block)
    Outputs (7): centroid, spread, skew, kurt, flatness, rolloff, flux
    """
    def __init__(self, fft_mag_instance: fftMagResolver) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewSpectralFeatures, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          fft_mag_instance.getId())
        CTX.handle_cmd(cmd, ss)

class cepstrum(node):
    """Real cepstrum c = IFFT(log|X|) from an upstream FFT_MAG block.

    Dependent block: pass the ``fftMagResolver`` instance to the
    constructor; the firmware reads its magnitude spectrum directly. The
    N-point cepstrum is exposed via VectorProbe (rows=1, lines=N_bins);
    scalar output 0 carries c[1].
    """
    def __init__(self, fft_mag_instance: fftMagResolver) -> None:
        super().__init__()
        self.setId(node.currentNodeId); node.currentNodeId += 1
        ss = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 1,
                                     PP_SubFuncId.NewCepstrum, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16,
                          fft_mag_instance.getId())
        CTX.handle_cmd(cmd, ss)
        self.dataLines = int(fft_mag_instance.dataLines)
        self.dataRaw = 1

class autocorrLags(tf):
    """Lag-windowed autocorrelation.
    Inputs (1): x → Outputs via VectorProbe (rows=L, lines=1).
    Params: N (ring length), L (lags), D (refresh decimation).
    """
    def __init__(self, N: int = 256, L: int = 64, D: int = 32) -> None:
        super().__init__(); self.setId(tf.currentSysId); tf.currentSysId += 1
        ss = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 3, PP_SubFuncId.NewAutocorrLags, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(N))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(L))
        CTX.prepare_param(cmd, 2, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(D))
        CTX.handle_cmd(cmd, ss)
        self.dataLines = int(L); self.dataRaw = 1

class pcaProject(node):
    """Offline-trained PCA projection y = W·(x−μ).
    Inputs (K): feature vector → Outputs (P): projected vector.
    Params: K, P, W (P·K row-major), mu (K).
    """
    def __init__(self, K: int, P: int, W, mu) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        w_arr  = [float(v) for v in W]
        mu_arr = [float(v) for v in mu]
        if len(w_arr) != P * K:  raise ValueError(f"W must be P*K = {P*K} elements")
        if len(mu_arr) != K:     raise ValueError(f"mu must be K = {K} elements")
        ss = PP_FIXED_SIZE + 2 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                           + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE * len(w_arr)) \
                           + (PP_PARAM_INFO_SIZE + PP_REAL_SIZE * len(mu_arr))
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 4, PP_SubFuncId.NewPcaProject, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(K))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(P))
        CTX.prepare_param(cmd, 2, PP_REAL_SIZE * len(w_arr),  PP_FuncParamId.TYPE_RealArray, w_arr)
        CTX.prepare_param(cmd, 3, PP_REAL_SIZE * len(mu_arr), PP_FuncParamId.TYPE_RealArray, mu_arr)
        CTX.handle_cmd(cmd, ss)
        self.dataLines = int(P); self.dataRaw = 1

class decisionTree(node):
    """Tiny decision-tree inference.
    Inputs (K): feature vector → Outputs (C): one-hot class indicator.

    Tree representation: per-node arrays feat_idx, thresh, left_child,
    right_child, leaf_val. Leaf nodes have left_child = 0xFFFF (sentinel).
    """
    def __init__(self, K: int, C: int, feat_idx, thresh, left, right, leaf_val) -> None:
        super().__init__(); self.setId(node.currentNodeId); node.currentNodeId += 1
        fi = [int(v) for v in feat_idx]
        th = [float(v) for v in thresh]
        lc = [int(v) for v in left]
        rc = [int(v) for v in right]
        lv = [float(v) for v in leaf_val]
        n_nodes = len(fi)
        for arr, name in ((th, "thresh"), (lc, "left"), (rc, "right"), (lv, "leaf_val")):
            if len(arr) != n_nodes:
                raise ValueError(f"{name} length {len(arr)} != n_nodes {n_nodes}")
        # Wire layout: 3 uint16 scalars (K, C, NNodes) + 5 arrays.
        # feat_idx / left / right are UINT16 arrays (2 B/elem): the board
        # copies them as uint16_t[NNodes].  They MUST be sent as
        # TYPE_Uint16Array -- packing them as TYPE_RealArray (4 B/elem float)
        # made the board read the 16-bit halves of each float as node
        # indices, producing a garbage tree on the USB/Studio path (the
        # C++/Arduino lib already sends raw uint16 bytes).  thresh / leaf_val
        # stay genuine float32 arrays.
        ss = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE) \
                           + 2 * (PP_PARAM_INFO_SIZE + PP_REAL_SIZE * n_nodes) \
                           + 3 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE * n_nodes)
        cmd = CTX.prepare_cmd_header(ss, PP_FuncId.Createblock, 8, PP_SubFuncId.NewDecisionTree, self.getId())
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(K))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(C))
        CTX.prepare_param(cmd, 2, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(n_nodes))
        CTX.prepare_param(cmd, 3, PP_UINT16_SIZE * n_nodes, PP_FuncParamId.TYPE_Uint16Array, fi)
        CTX.prepare_param(cmd, 4, PP_REAL_SIZE * n_nodes, PP_FuncParamId.TYPE_RealArray, th)
        CTX.prepare_param(cmd, 5, PP_UINT16_SIZE * n_nodes, PP_FuncParamId.TYPE_Uint16Array, lc)
        CTX.prepare_param(cmd, 6, PP_UINT16_SIZE * n_nodes, PP_FuncParamId.TYPE_Uint16Array, rc)
        CTX.prepare_param(cmd, 7, PP_REAL_SIZE * n_nodes, PP_FuncParamId.TYPE_RealArray, lv)
        CTX.handle_cmd(cmd, ss)
        self.dataLines = int(C); self.dataRaw = 1


class featureStack(node):
    """Variable-K feature-vector concatenator.

    K scalar inputs are packed, in port order, into one length-K feature
    vector every cycle. The vector is published to a VectorProbe; no block
    consumes it. pcaProject and decisionTree read their own K scalar inputs,
    so wire the feature sources into those as well.

    Inputs:
        in_0 .. in_{K-1}: inputs 0..K-1
    Outputs:
        out_0: 1.0 on every cycle in which the stack was refreshed, which is
            every cycle. It carries no feature data. Its purpose is to give
            the block a linkable output: a block with no connected output is
            never placed on the execution schedule. Connect this output or
            the VectorProbe (or both), or the block never runs.
        The feature vector itself: read it from a VectorProbe attached to
            this block (rows = K, lines = 1).

    Parameters:
        K: int,   number of input ports (1..32)
    """

    def __init__(self, K: int) -> None:
        super().__init__()
        self.setId(node.currentNodeId)
        node.currentNodeId += 1

        serial_size = PP_FIXED_SIZE + (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 1,
            PP_SubFuncId.NewFeatureStack, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(K))
        CTX.handle_cmd(cmd, serial_size)

        # Feature vector exposed via VectorProbe.
        self.dataLines = int(K)
        self.dataRaw = 1


class stftFramer(tf):
    """STFT framer: sliding-window framer with analysis window applied.

    Same ring + hop pattern as ``windowFramer``, but the emitted frame is
    element-wise multiplied by a Hann / Hamming / Blackman LUT computed once
    at construction.

    Inputs:
        x: input 0  (scalar sample per cycle)
    Outputs:
        frame_ready: output 0 (1.0 on emit cycle, else 0.0)

    Parameters:
        N: int            frame length (1 <= N <= 2048)
        H: int            hop length   (1 <= H <= N)
        stft_window: int  0 = Hann (default), 1 = Hamming, 2 = Blackman
                          (the parameter is called ``stft_window`` rather
                          than ``window_type`` so it cannot be confused
                          with the FIR blocks' window parameter, which
                          takes a different set of values)

    Reference: Harris 1978 - On the use of windows for harmonic analysis with the DFT.
    """

    def __init__(self, N: int, H: int, stft_window: int = 0) -> None:
        super().__init__()
        self.setId(tf.currentSysId)
        tf.currentSysId += 1

        serial_size = PP_FIXED_SIZE + 3 * (PP_PARAM_INFO_SIZE + PP_UINT16_SIZE)
        cmd = CTX.prepare_cmd_header(
            serial_size, PP_FuncId.Createblock, 3,
            PP_SubFuncId.NewStftFramer, self.getId(),
        )
        CTX.prepare_param(cmd, 0, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(N))
        CTX.prepare_param(cmd, 1, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(H))
        CTX.prepare_param(cmd, 2, PP_UINT16_SIZE, PP_FuncParamId.TYPE_Uint16, int(stft_window))
        CTX.handle_cmd(cmd, serial_size)

        self.dataLines = int(N)
        self.dataRaw = 1

