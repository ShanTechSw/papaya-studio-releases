/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 8000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe chorus_2;
probe flanger_2;
probe phaser_2;
probe ring_modulated;

input Ring_mod_p1;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(8000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(250.0f, 0.0f);
  Ring_mod_p1 = input("Ring mod_p1", 0.0f);
  expander fan_4 = expander(4);
  chorus Chorus = chorus(1.0, 5.0, 0.5);
  flanger Flanger = flanger(0.5, 3.0, 0.6, 0.5);
  phaser Phaser = phaser(0.3, 0.8, 0.5, 4, 0.5);
  ringMod Ring_mod = ringMod();
  chorus_2 = probe("chorus");
  flanger_2 = probe("flanger");
  phaser_2 = probe("phaser");
  ring_modulated = probe("ring_modulated");

  /* Connect Blocks */
  Source > fan_4;
  Ring_mod_p1 > Ring_mod.in(1);
  fan_4.out(0) > Chorus;
  fan_4.out(1) > Flanger;
  fan_4.out(2) > Phaser;
  fan_4.out(3) > Ring_mod.in(0);
  Chorus > chorus_2;
  Flanger > flanger_2;
  Phaser > phaser_2;
  Ring_mod > ring_modulated;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    chorus_2.show();
    flanger_2.show();
    phaser_2.show();
    ring_modulated.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}