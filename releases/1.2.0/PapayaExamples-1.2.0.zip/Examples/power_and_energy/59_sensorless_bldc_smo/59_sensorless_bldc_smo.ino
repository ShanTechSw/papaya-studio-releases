/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe estimated_angle_2;
probe estimated_speed_2;
probe Park__sensorless__tap;
probe Park__sensorless__tap_2;
probe angle_error;
probe torque_command;

input speed_ref;

/* Global Array Declarations */
float SIM__stator_winding_numerator[] = {1.0f};
float SIM__stator_winding_denominator[] = {0.001f, 0.5f};
float observer_model_numerator[] = {1.0f};
float observer_model_denominator[] = {0.001f, 0.5f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  speed_ref = input("speed_ref", 80.0f);
  signalSource SIM__phase_voltage = signalSource::sine(40.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 10.0f);
  signalSource SIM__true_angle = signalSource::sawtooth(40.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 6.283f);
  signalSource SIM__back_EMF = signalSource::sine(40.0f, 90.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 3.0f);
  expander fan_2 = expander(2);
  node winding_drive = node("[1.0 -1.0]", "[1.0]", Sum);
  tf SIM__stator_winding = tf(SIM__stator_winding_numerator, 1, SIM__stator_winding_denominator, 2);
  expander fan_3 = expander(3);
  node observer_input = node("[1.0 1.0]", "[1.0]", Sum);
  tf observer_model = tf(observer_model_numerator, 1, observer_model_denominator, 2);
  node current_error = node("[1.0 -1.0]", "[1.0]", Sum);
  sign sliding_injection = sign();
  gain switching_gain = gain(2.0);
  expander fan_2_2 = expander(2);
  clarke Clarke = clarke();
  butter equivalent_control_LPF = butter(2, 200.0, passLow);
  expander fan_2_3 = expander(2);
  derivative quadrature_back_EMF = derivative(0.002);
  atan2Block estimated_angle = atan2Block();
  expander fan_3_2 = expander(3);
  derivative estimated_speed = derivative(0.01);
  park Park__sensorless_ = park();
  node estimation_error = node("[1.0 -1.0]", "[1.0]", Sum);
  node speed_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid speed_PI = pid(10.0, 0.5, 0.0, 0.005);
  estimated_angle_2 = probe("estimated_angle");
  estimated_speed_2 = probe("estimated_speed");
  Park__sensorless__tap = probe("Park (sensorl_0");
  Park__sensorless__tap_2 = probe("Park (sensorl_1");
  angle_error = probe("angle_error_rad");
  torque_command = probe("torque_command");

  /* Connect Blocks */
  speed_ref > speed_error.in(0);
  SIM__phase_voltage > fan_2;
  SIM__true_angle > estimation_error.in(1);
  SIM__back_EMF > winding_drive.in(1);
  fan_2.out(0) > winding_drive.in(0);
  fan_2.out(1) > observer_input.in(0);
  winding_drive > SIM__stator_winding;
  SIM__stator_winding > fan_3;
  fan_3.out(0) > current_error.in(0);
  fan_3.out(1) > Clarke.in(0);
  fan_3.out(2) > Clarke.in(1);
  observer_input > observer_model;
  observer_model > current_error.in(1);
  current_error > sliding_injection;
  sliding_injection > switching_gain;
  switching_gain > fan_2_2;
  fan_2_2.out(0) > observer_input.in(1);
  fan_2_2.out(1) > equivalent_control_LPF;
  Clarke.out(0) > Park__sensorless_.in(0);
  Clarke.out(1) > Park__sensorless_.in(1);
  equivalent_control_LPF > fan_2_3;
  fan_2_3.out(0) > quadrature_back_EMF;
  fan_2_3.out(1) > estimated_angle.in(0);
  quadrature_back_EMF > estimated_angle.in(1);
  estimated_angle > fan_3_2;
  estimated_angle > estimated_angle_2;
  fan_3_2.out(0) > estimated_speed;
  fan_3_2.out(1) > Park__sensorless_.in(2);
  fan_3_2.out(2) > estimation_error.in(0);
  estimated_speed > speed_error.in(1);
  estimated_speed > estimated_speed_2;
  Park__sensorless_.out(0) > Park__sensorless__tap;
  Park__sensorless_.out(1) > Park__sensorless__tap_2;
  estimation_error > angle_error;
  speed_error > speed_PI;
  speed_PI > torque_command;

  /* Enable Remote Input Control */
  speed_ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    estimated_angle_2.show();
    estimated_speed_2.show();
    Park__sensorless__tap.show();
    Park__sensorless__tap_2.show();
    angle_error.show();
    torque_command.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}