var classquat_norm_conj =
[
    [ "quatNormConj", "classquat_norm_conj.html#ac19ca974b3a302950201f69d913ee286", null ]
];