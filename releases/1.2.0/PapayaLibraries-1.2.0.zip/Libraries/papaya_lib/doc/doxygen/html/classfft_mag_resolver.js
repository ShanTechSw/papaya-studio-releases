var classfft_mag_resolver =
[
    [ "fftMagResolver", "classfft_mag_resolver.html#aa5682a52ec5f67bec0339da2a57e8ac4", null ],
    [ "fftMagResolver", "classfft_mag_resolver.html#a8976dca151c765a32d9416dedd2c33d1", null ]
];