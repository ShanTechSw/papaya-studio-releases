/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe maximum_2;
probe minimum_2;
probe abs_max;
probe abs_min;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(3.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.0f, /*offset=*/ 0.2f);
  expander fan_4 = expander(4);
  maximum Highest = maximum(200);
  minimum Lowest = minimum(200);
  absMax Largest_size = absMax(200);
  absMin Smallest_size = absMin(200);
  maximum_2 = probe("maximum");
  minimum_2 = probe("minimum");
  abs_max = probe("abs_max");
  abs_min = probe("abs_min");

  /* Connect Blocks */
  Source > fan_4;
  fan_4.out(0) > Highest;
  fan_4.out(1) > Lowest;
  fan_4.out(2) > Largest_size;
  fan_4.out(3) > Smallest_size;
  Highest > maximum_2;
  Lowest > minimum_2;
  Largest_size > abs_max;
  Smallest_size > abs_min;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    maximum_2.show();
    minimum_2.show();
    abs_max.show();
    abs_min.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}