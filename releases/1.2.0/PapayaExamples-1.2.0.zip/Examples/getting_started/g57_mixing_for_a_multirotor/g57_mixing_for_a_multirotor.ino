/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe motor_0;
probe motor_1;
probe motor_2;
probe motor_3;
probe motor_4;
probe motor_5;
probe motor_6;
probe motor_7;

input thrust;
input roll_torque;
input pitch_torque;
input yaw_torque;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  thrust = input("thrust", 0.5f);
  roll_torque = input("roll_torque", 0.0f);
  pitch_torque = input("pitch_torque", 0.0f);
  yaw_torque = input("yaw_torque", 0.0f);
  mixerMultirotor Mixer = mixerMultirotor(0, 1000.0, 2000.0);
  motor_0 = probe("motor_0");
  motor_1 = probe("motor_1");
  motor_2 = probe("motor_2");
  motor_3 = probe("motor_3");
  motor_4 = probe("motor_4");
  motor_5 = probe("motor_5");
  motor_6 = probe("motor_6");
  motor_7 = probe("motor_7");

  /* Connect Blocks */
  thrust > Mixer.in(0);
  roll_torque > Mixer.in(1);
  pitch_torque > Mixer.in(2);
  yaw_torque > Mixer.in(3);
  Mixer.out(0) > motor_0;
  Mixer.out(1) > motor_1;
  Mixer.out(2) > motor_2;
  Mixer.out(3) > motor_3;
  Mixer.out(4) > motor_4;
  Mixer.out(5) > motor_5;
  Mixer.out(6) > motor_6;
  Mixer.out(7) > motor_7;

  /* Enable Remote Input Control */
  thrust.enableRemote();
  roll_torque.enableRemote();
  pitch_torque.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    motor_0.show();
    motor_1.show();
    motor_2.show();
    motor_3.show();
    motor_4.show();
    motor_5.show();
    motor_6.show();
    motor_7.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}