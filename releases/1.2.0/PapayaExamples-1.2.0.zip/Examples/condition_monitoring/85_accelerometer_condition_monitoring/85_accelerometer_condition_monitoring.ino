/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:49
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ax_g;
probe ay_g;
probe az_g;
probe rms_ref_sim;
probe kurt_ref_sim;
probe a_total_g;
probe chan_g;
probe ac_g;
probe p2p_g;
probe crest;
probe kurtosis;
probe mobility;
VectorProbe spectrum;
probe zcr_2;
probe rms_g;
probe peak_g;
VectorProbe spectral;
VectorProbe features;
probe stacks_updated;

input sel_xy;
input sel_z;
input floor;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  sel_xy = input("sel_xy", 1.0f);
  sel_z = input("sel_z", 1.0f);
  floor = input("floor", 1e-06f);
  imu Accelerometer = imu(IMU_ACC, 1.0);
  signalSource Expected_RMS = signalSource::square(0.5f, 3.141592653589793f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.017825f, /*offset=*/ 0.040404999999999996f);
  signalSource Expected_kurtosis = signalSource::square(0.5f, 3.141592653589793f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.12423f, /*offset=*/ 0.18750000000000006f);
  expander ax_fan = expander(2);
  expander ay_fan = expander(2);
  expander az_fan = expander(2);
  expander floor_fan = expander(2);
  mag3 Total_specific_force = mag3();
  switchBlock x_or_y = switchBlock();
  switchBlock that_or_z = switchBlock();
  expander channel_fan = expander(2);
  mean Standing_level = mean(200);
  expander level_fan = expander(2);
  node Vibration_only = node("[1.0 -1.0]", "[1.0]", Sum);
  expander vibration_fan = expander(11);
  rootMeanSquare RMS = rootMeanSquare(200);
  absMax Peak = absMax(200);
  peakToPeak Peak_to_peak = peakToPeak(200);
  crestFactor Crest_factor = crestFactor(200);
  standardDeviation Std_dev = standardDeviation(200);
  skewKurt Skew_and_kurtosis = skewKurt(200);
  hjorth Hjorth = hjorth(200);
  zcr Zero_crossings = zcr(200, 0.0);
  percentile _95th_percentile_since_start = percentile(0.95);
  absVal Rectify = absVal();
  fft_HannWindow Hann_FFT = fft_HannWindow(256);
  maximum Hold_the_crossing_count = maximum(200);
  expander rms_fan = expander(2);
  expander peak_fan = expander(3);
  expander rectified_fan = expander(2);
  fftMagResolver Magnitude_spectrum = fftMagResolver(Hann_FFT);
  mean Rectified_mean = mean(200);
  sqrtBlock Root_amplitude = sqrtBlock();
  spectralFeatures Spectral_shape = spectralFeatures(Magnitude_spectrum);
  expander rect_fan = expander(2);
  mean Root_amplitude_mean = mean(200);
  featureStack Spectral_vector = featureStack(7);
  sqrMath Squared_again = sqrMath();
  node Guarded_mean = node("[1.0 1.0]", "[1.0]", Sum);
  inverse Reciprocal = inverse();
  node Guarded_root_mean = node("[1.0 1.0]", "[1.0]", Sum);
  expander reciprocal_fan = expander(2);
  inverse Root_reciprocal = inverse();
  node Shape_factor = node("[1.0 1.0]", "[1.0]", Mul);
  node Impulse_factor = node("[1.0 1.0]", "[1.0]", Mul);
  node Clearance_factor = node("[1.0 1.0]", "[1.0]", Mul);
  featureStack Feature_vector = featureStack(17);
  merger Stack_refresh_flags = merger(2);
  ax_g = probe("ax_g");
  ay_g = probe("ay_g");
  az_g = probe("az_g");
  rms_ref_sim = probe("rms_ref_sim");
  kurt_ref_sim = probe("kurt_ref_sim");
  a_total_g = probe("a_total_g");
  chan_g = probe("chan_g");
  ac_g = probe("ac_g");
  p2p_g = probe("p2p_g");
  crest = probe("crest");
  kurtosis = probe("kurtosis");
  mobility = probe("mobility");
  spectrum = VectorProbe("spectrum");
  zcr_2 = probe("zcr");
  rms_g = probe("rms_g");
  peak_g = probe("peak_g");
  spectral = VectorProbe("spectral");
  features = VectorProbe("features");
  stacks_updated = probe("stacks_updated");

  /* Connect Blocks */
  sel_xy > x_or_y.in(0);
  sel_z > that_or_z.in(0);
  floor > floor_fan;
  Accelerometer.out(0) > ax_fan;
  Accelerometer.out(1) > ay_fan;
  Accelerometer.out(2) > az_fan;
  Accelerometer.out(0) > ax_g;
  Accelerometer.out(1) > ay_g;
  Accelerometer.out(2) > az_g;
  Expected_RMS > rms_ref_sim;
  Expected_kurtosis > kurt_ref_sim;
  ax_fan.out(1) > Total_specific_force.in(0);
  ax_fan.out(0) > x_or_y.in(1);
  ay_fan.out(1) > Total_specific_force.in(1);
  ay_fan.out(0) > x_or_y.in(2);
  az_fan.out(1) > Total_specific_force.in(2);
  az_fan.out(0) > that_or_z.in(2);
  floor_fan.out(0) > Guarded_mean.in(1);
  floor_fan.out(1) > Guarded_root_mean.in(1);
  Total_specific_force > a_total_g;
  x_or_y > that_or_z.in(1);
  that_or_z > channel_fan;
  that_or_z > chan_g;
  channel_fan.out(0) > Standing_level;
  channel_fan.out(1) > Vibration_only.in(0);
  Standing_level > level_fan;
  level_fan.out(0) > Vibration_only.in(1);
  level_fan.out(1) > Feature_vector.in(13);
  Vibration_only > vibration_fan;
  Vibration_only > ac_g;
  vibration_fan.out(0) > RMS;
  vibration_fan.out(1) > Peak;
  vibration_fan.out(2) > Peak_to_peak;
  vibration_fan.out(3) > Crest_factor;
  vibration_fan.out(4) > Std_dev;
  vibration_fan.out(5) > Skew_and_kurtosis;
  vibration_fan.out(6) > Hjorth;
  vibration_fan.out(7) > Zero_crossings;
  vibration_fan.out(8) > _95th_percentile_since_start;
  vibration_fan.out(9) > Rectify;
  vibration_fan.out(10) > Hann_FFT;
  RMS > rms_fan;
  Peak > peak_fan;
  Peak_to_peak > Feature_vector.in(2);
  Peak_to_peak > p2p_g;
  Crest_factor > Feature_vector.in(3);
  Crest_factor > crest;
  Std_dev > Feature_vector.in(4);
  Skew_and_kurtosis.out(0) > Feature_vector.in(5);
  Skew_and_kurtosis.out(1) > Feature_vector.in(6);
  Skew_and_kurtosis.out(1) > kurtosis;
  Hjorth.out(0) > Feature_vector.in(7);
  Hjorth.out(1) > Feature_vector.in(8);
  Hjorth.out(2) > Feature_vector.in(9);
  Hjorth.out(1) > mobility;
  Zero_crossings > Hold_the_crossing_count;
  _95th_percentile_since_start > Feature_vector.in(11);
  Rectify > rectified_fan;
  Hann_FFT > Magnitude_spectrum;
  Hann_FFT >> spectrum;
  Hold_the_crossing_count > Feature_vector.in(10);
  Hold_the_crossing_count > zcr_2;
  rms_fan.out(1) > Shape_factor.in(0);
  rms_fan.out(0) > Feature_vector.in(0);
  rms_fan.out(1) > rms_g;
  peak_fan.out(1) > Impulse_factor.in(0);
  peak_fan.out(2) > Clearance_factor.in(0);
  peak_fan.out(0) > Feature_vector.in(1);
  peak_fan.out(1) > peak_g;
  rectified_fan.out(0) > Rectified_mean;
  rectified_fan.out(1) > Root_amplitude;
  Magnitude_spectrum > Spectral_shape;
  Rectified_mean > rect_fan;
  Root_amplitude > Root_amplitude_mean;
  Spectral_shape.out(0) > Spectral_vector.in(0);
  Spectral_shape.out(1) > Spectral_vector.in(1);
  Spectral_shape.out(2) > Spectral_vector.in(2);
  Spectral_shape.out(3) > Spectral_vector.in(3);
  Spectral_shape.out(4) > Spectral_vector.in(4);
  Spectral_shape.out(5) > Spectral_vector.in(5);
  Spectral_shape.out(6) > Spectral_vector.in(6);
  rect_fan.out(1) > Guarded_mean.in(0);
  rect_fan.out(0) > Feature_vector.in(14);
  Root_amplitude_mean > Squared_again;
  Spectral_vector > Stack_refresh_flags.in(1);
  Spectral_vector >> spectral;
  Squared_again > Guarded_root_mean.in(0);
  Guarded_mean > Reciprocal;
  Reciprocal > reciprocal_fan;
  Guarded_root_mean > Root_reciprocal;
  reciprocal_fan.out(0) > Shape_factor.in(1);
  reciprocal_fan.out(1) > Impulse_factor.in(1);
  Root_reciprocal > Clearance_factor.in(1);
  Shape_factor > Feature_vector.in(15);
  Impulse_factor > Feature_vector.in(16);
  Clearance_factor > Feature_vector.in(12);
  Feature_vector > Stack_refresh_flags.in(0);
  Feature_vector >> features;
  Stack_refresh_flags > stacks_updated;

  /* Enable Remote Input Control */
  sel_xy.enableRemote();
  sel_z.enableRemote();
  floor.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    ax_g.show();
    ay_g.show();
    az_g.show();
    rms_ref_sim.show();
    kurt_ref_sim.show();
    a_total_g.show();
    chan_g.show();
    ac_g.show();
    p2p_g.show();
    crest.show();
    kurtosis.show();
    mobility.show();
    spectrum.show();
    zcr_2.show();
    rms_g.show();
    peak_g.show();
    spectral.show();
    features.show();
    stacks_updated.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}