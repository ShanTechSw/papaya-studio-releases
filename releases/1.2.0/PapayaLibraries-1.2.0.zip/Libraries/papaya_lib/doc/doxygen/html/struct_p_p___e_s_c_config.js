var struct_p_p___e_s_c_config =
[
    [ "a", "struct_p_p___e_s_c_config.html#a521fcabb16b98b14a98baacbb1149396", null ],
    [ "hpf_wc", "struct_p_p___e_s_c_config.html#a71eb36e5c800c367353c466bb25b7757", null ],
    [ "k", "struct_p_p___e_s_c_config.html#a0b6f6c4b6906339e04c65e2d822852a8", null ],
    [ "lpf_wc", "struct_p_p___e_s_c_config.html#aa55c276301266a7739c0b3a81aeb02ac", null ],
    [ "omega", "struct_p_p___e_s_c_config.html#aa294033093119bde57c4aba66b810de9", null ]
];