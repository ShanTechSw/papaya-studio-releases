var struct_p_p__comp_filter =
[
    [ "alpha", "struct_p_p__comp_filter.html#a311e5e8512dacd155cc7ceffc60e20a7", null ]
];