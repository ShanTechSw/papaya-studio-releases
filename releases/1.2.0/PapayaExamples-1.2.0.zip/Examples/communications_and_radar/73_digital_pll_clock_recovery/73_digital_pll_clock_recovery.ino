/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe loop_phase_erro;
probe recovered_clock_2;
probe recovered_data;

input const_;
input bit_high;
input bit_low;
input slice_high;
input slice_low;
input nominal_clock;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  bit_high = input("bit_high", 1.0f);
  bit_low = input("bit_low", -1.0f);
  slice_high = input("slice_high", 0.1f);
  slice_low = input("slice_low", -0.1f);
  nominal_clock = input("nominal_clock", 3141.5927f);
  signalSource SIM__NRZ_data = signalSource::square(500.0f, 0.0f);
  const_ = input("const", 0.0f);
  noise SIM__timing_jitter = noise(-0.05, 0.05, uniform);
  butter SIM__ISI_channel = butter(3, 1500.0, passLow);
  node channel___jitter = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_2 = expander(2);
  derivative edge_detector = derivative(0.0005);
  schmidt data_slicer = schmidt();
  node phase_detector = node("[1.0 1.0]", "[1.0]", Mul);
  pid PI_loop_filter = pid(120.0, 0.8, 0.0, 0.001);
  node NCO_centre___correction = node("[1.0 1.0]", "[1.0]", Sum);
  integrator NCO_phase = integrator();
  cosineFunc recovered_clock = cosineFunc();
  expander fan_2_2 = expander(2);
  sampleHold retimed_data = sampleHold();
  loop_phase_erro = probe("loop_phase_erro");
  recovered_clock_2 = probe("recovered_clock");
  recovered_data = probe("recovered_data");

  /* Connect Blocks */
  bit_high > data_slicer.in(1);
  bit_low > data_slicer.in(2);
  slice_high > data_slicer.in(3);
  slice_low > data_slicer.in(4);
  nominal_clock > NCO_centre___correction.in(1);
  SIM__NRZ_data > SIM__ISI_channel;
  const_ > SIM__timing_jitter;
  SIM__timing_jitter > channel___jitter.in(1);
  SIM__ISI_channel > channel___jitter.in(0);
  channel___jitter > fan_2;
  fan_2.out(0) > edge_detector;
  fan_2.out(1) > data_slicer.in(0);
  edge_detector > phase_detector.in(0);
  data_slicer > retimed_data.in(0);
  phase_detector > PI_loop_filter;
  PI_loop_filter > NCO_centre___correction.in(0);
  PI_loop_filter > loop_phase_erro;
  NCO_centre___correction > NCO_phase;
  NCO_phase > recovered_clock;
  recovered_clock > fan_2_2;
  recovered_clock > recovered_clock_2;
  fan_2_2.out(0) > phase_detector.in(1);
  fan_2_2.out(1) > retimed_data.in(1);
  retimed_data > recovered_data;

  /* Enable Remote Input Control */
  bit_high.enableRemote();
  bit_low.enableRemote();
  slice_high.enableRemote();
  slice_low.enableRemote();
  nominal_clock.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    loop_phase_erro.show();
    recovered_clock_2.show();
    recovered_data.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}