"""The keys Papaya Studio trusts to have published an update list.

WHY THIS EXISTS
---------------
A secure connection authenticates the SERVER. It gives no protection at
all in the one case worth protecting against: somebody who legitimately
controls the hosting account obtains a valid certificate and serves a
hostile list over a connection that verifies perfectly. A signature made
by a key the website never holds is the only control that survives that.

WHAT IS IN THIS FILE
--------------------
Public keys only. A verification key is not a secret and cannot sign
anything, so it is an ordinary committed constant: no generated module to
forget, no scrub step to fail, no chance of shipping a redacted stub.

The private seeds are never here and never in the repository. They are a
build input, resolved the way the board key already is.

THERE IS NO OVERRIDE PATH, AND THAT IS DELIBERATE
-------------------------------------------------
The neighbouring board-attestation code resolves its authority from an
environment variable FIRST. That pattern must not be copied here. The
address of the update list is already overridable by an environment
variable and by a setting, so a key that could also be overridden would
let anyone who can set an environment variable publish updates to that
machine. The tuple below is the only answer, in every build.

KEY IDS
-------
Four bytes, big-endian, carried in the signed part of the container so a
flipped id cannot be used to steer anything. Ids 0 and 0xFFFFFFFF are
permanently invalid, which costs nothing and removes a class of
uninitialised-value and null-confusion mistakes. Ids start at 1, only ever
increase, and are never reused, because retiring a key means refusing
every id below a floor.

WHAT SIGNING CANNOT DO
----------------------
Written down because it is easy to believe it does more.

* It does not survive compromise of the build machine, where the signing
  seed lives.
* It does not protect the FIRST install. These keys arrive inside an
  installer downloaded from the same hosting the threat model treats as
  hostile. Signing protects every install made from an honest download,
  for the life of that install; it cannot protect the download itself.
* It does not stop an attacker serving today's genuine list forever, so a
  user never learns a fix exists. The floor stops the list going
  backwards, not standing still.
* It does not defend against somebody who already has the user's own
  privileges on the user's own machine.
"""
from __future__ import annotations

from . import ed25519

#: Domain separation. A list signed for one purpose must never verify as
#: another, so the purpose is part of what was signed.
#:
#: The NUL byte that follows the context in the signed message is what
#: makes this safe FOREVER rather than safe today: without it,
#: ``PP-FEED-v1`` is a byte-prefix of a future ``PP-FEED-v10``, and two
#: contexts where one is a prefix of the other can be made to collide by
#: choosing the body. Contexts are ASCII and can never contain a NUL, so
#: the separator cannot appear inside one.
CONTEXT_FEED = b"PP-FEED-v1"
CONTEXT_PACKAGE_INDEX = b"PP-PKGINDEX-v1"
CONTEXT_FIRMWARE_INDEX = b"PP-FWINDEX-v1"

#: Every context this product signs anything with, including the board
#: attestation one, so the prefix-freedom test covers them together.
ALL_CONTEXTS = (
    CONTEXT_FEED,
    CONTEXT_PACKAGE_INDEX,
    CONTEXT_FIRMWARE_INDEX,
    b"PP-ATTEST-",
)

#: Reserved forever.
KEY_ID_RESERVED = (0x00000000, 0xFFFFFFFF)

#: The trusted publishing keys, as ``(key_id, public_key_hex)``.
#:
#: EMPTY UNTIL THE KEY CEREMONY. That is not an oversight and it is not a
#: placeholder to be filled with a development key: with no keys, every
#: list is refused, which is the correct behaviour for a build that cannot
#: verify anything. The release build refuses to package while this is
#: empty, the same way it already refuses an unprovisioned board key.
#:
#: Two keys from the first day. Key 1 is provisioned onto the build
#: machine. Key 2 is generated at the same ceremony, never touches a
#: networked machine, and exists so that publishing can continue after key
#: 1 is retired. Key 2 is the CONTINUITY key. On its own it is not
#: recovery from a compromise: an attacker holding key 1 keeps verifying
#: on every install until that install fetches an honest list carrying a
#: higher ``min_key_id``, which is what actually retires key 1.
#: Both provisioned on 2026-09-02. Key 1's seed lives on the build
#: machine, which is where it has to be to sign a release. Key 2 was
#: generated at an air-gapped ceremony and its seed has never been on a
#: networked machine; only the public half below ever left that room.
#:
#: Public halves are safe to commit BY CONSTRUCTION. That is the whole
#: point of signing the feed with an asymmetric key: what ships to a user
#: can verify a list and cannot produce one.
_RELEASE_KEYS: tuple[tuple[int, str], ...] = (
    (1, "daf2d03abadfc13dc692a068555937605d2ac9c6a40fdc18fafba9b8b9a81d83"),
    (2, "c7a74db57cdd84423a7d474a7c6f12ce20cc46ab4cc1c506e3db12e66813f40e"),
)


class KeyProblem(Exception):
    """A public key is not usable for verification."""


def validate_public_key(public: bytes) -> list[str]:
    """Everything wrong with *public*, as a list. Empty means usable.

    The small-order check is the one that matters and the one that is
    easy to leave out. The signature check in this product accepts ANY
    message when the public key is the identity point, which is a
    property of the algorithm's plain form rather than a defect in the
    implementation. It is harmless here because these keys are committed
    constants rather than anything a stranger supplies, but "harmless
    because of how it is used today" is exactly the kind of reasoning that
    stops being true. So the key is checked instead.
    """
    problems: list[str] = []
    if not isinstance(public, (bytes, bytearray)):
        return ["not bytes"]
    public = bytes(public)
    if len(public) != ed25519.PUBLIC_KEY_LEN:
        return [f"wrong length ({len(public)}, expected "
                f"{ed25519.PUBLIC_KEY_LEN})"]

    try:
        point = ed25519._point_decompress(public)
    except Exception:                                       # noqa: BLE001
        point = None
    if point is None:
        return ["not a point on the curve"]

    if ed25519._point_compress(point) != public:
        problems.append("not a canonical encoding")

    # 8 * A == identity for every small-order point, and those are the
    # ones that verify anything at all.
    eightfold = ed25519._point_mul(8, point)
    identity = ed25519._point_mul(0, point)
    if ed25519._point_equal(eightfold, identity):
        problems.append("small order, so it would verify any message")
    return problems


def public_key_for(key_id: int) -> bytes | None:
    """The key with this id, or ``None``. Never falls back to another.

    Trying every key in turn would be pointless once the id is part of
    what was signed, and pointless choices in verification code are where
    the next mistake grows.
    """
    for known_id, hex_text in _RELEASE_KEYS:
        if known_id == key_id:
            try:
                return bytes.fromhex(hex_text)
            except ValueError:                              # pragma: no cover
                return None
    return None


def known_key_ids() -> tuple[int, ...]:
    return tuple(sorted(k for k, _ in _RELEASE_KEYS))


def keys_are_provisioned() -> bool:
    """False in a tree whose ceremony has not happened."""
    return bool(_RELEASE_KEYS)


def _self_check() -> None:
    """Refuse to import with a key that cannot safely verify.

    At import rather than at first use: a key that would accept anything
    must stop the application, not wait for the day somebody serves it a
    forged list.
    """
    seen: set[int] = set()
    for key_id, hex_text in _RELEASE_KEYS:
        if not isinstance(key_id, int) or key_id in KEY_ID_RESERVED:
            raise KeyProblem(f"key id {key_id!r} is reserved or not a number")
        if key_id in seen:
            raise KeyProblem(f"key id {key_id} appears twice")
        seen.add(key_id)
        try:
            public = bytes.fromhex(hex_text)
        except ValueError as exc:
            raise KeyProblem(f"key {key_id} is not hexadecimal") from exc
        problems = validate_public_key(public)
        if problems:
            raise KeyProblem(
                f"key {key_id} is unusable: {'; '.join(problems)}")


_self_check()
