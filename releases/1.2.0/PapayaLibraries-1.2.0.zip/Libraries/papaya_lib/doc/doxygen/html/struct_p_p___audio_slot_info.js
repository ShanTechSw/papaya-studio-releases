var struct_p_p___audio_slot_info =
[
    [ "crc32", "struct_p_p___audio_slot_info.html#aa7475f5690e86aca5b6c038478c27e6e", null ],
    [ "format", "struct_p_p___audio_slot_info.html#ab18e646fba28e358b07659ed1c45da38", null ],
    [ "lengthSamples", "struct_p_p___audio_slot_info.html#aee02a57cdc6b2d6fb79a352f7c7a15fc", null ],
    [ "sampleRateHz", "struct_p_p___audio_slot_info.html#abdd1f109b28aedce3598c6279ad758e7", null ],
    [ "slotId", "struct_p_p___audio_slot_info.html#a9aa3422386989295309b58146d716cb0", null ],
    [ "state", "struct_p_p___audio_slot_info.html#a90745333247da6b02c140fa5431f3edc", null ],
    [ "timestamp", "struct_p_p___audio_slot_info.html#a89d2def2cf50df8193c186c33b1fee41", null ]
];