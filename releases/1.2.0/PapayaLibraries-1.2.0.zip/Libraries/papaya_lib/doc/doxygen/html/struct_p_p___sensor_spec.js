var struct_p_p___sensor_spec =
[
    [ "ConvConst1", "struct_p_p___sensor_spec.html#a232efb33fe7d520b704442a419a4ebf6", null ],
    [ "ConvConst2", "struct_p_p___sensor_spec.html#a3500e6a227420c60f9178df8e48a7244", null ],
    [ "HwId", "struct_p_p___sensor_spec.html#a1ddfd8bcd4ad96d3f1e9c79b02148ad5", null ]
];