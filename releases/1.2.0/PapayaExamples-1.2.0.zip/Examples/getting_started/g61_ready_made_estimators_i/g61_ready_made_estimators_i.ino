/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe thermal_ekf_0;
probe thermal_ekf_1;
probe baro_alt_ekf_0;
probe baro_alt_ekf_1;
probe Baro_Alt_Ekf_tap;
probe sin_track_ekf_0;
probe sin_track_ekf_1;
probe Sin_Track_Ekf_tap;
probe grid_sync_ekf_0;
probe grid_sync_ekf_1;
probe Grid_Sync_Ekf_tap;

input const_;
input const__2;

/* Global Struct Declarations */
// Configuration for Thermal_Ekf
static float Thermal_Ekf_Q_data[4] = {0.01f, 0.0f, 0.0f, 0.01f};
static float Thermal_Ekf_R_data[1] = {0.1f};
static float Thermal_Ekf_x_init[2] = {0.0f, 0.0f};
PP_Thermal_EKF Thermal_Ekf_config = {
  .R_th = 1.0f,
  .C_core = 10.0f,
  .C_surf = 5.0f,
  .R_conv = 2.0f,
  .T_amb = 25.0f,
  .Q_data = Thermal_Ekf_Q_data,
  .R_data = Thermal_Ekf_R_data,
  .x_init = Thermal_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Baro_Alt_Ekf
static float Baro_Alt_Ekf_Q_data[9] = {0.01f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Baro_Alt_Ekf_R_data[1] = {0.5f};
static float Baro_Alt_Ekf_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_BaroAlt_EKF Baro_Alt_Ekf_config = {
  .Q_data = Baro_Alt_Ekf_Q_data,
  .R_data = Baro_Alt_Ekf_R_data,
  .x_init = Baro_Alt_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Sin_Track_Ekf
static float Sin_Track_Ekf_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Sin_Track_Ekf_R_data[1] = {0.1f};
static float Sin_Track_Ekf_x_init[3] = {1.0f, 314.159265359f, 0.0f};
PP_SinTrack_EKF Sin_Track_Ekf_config = {
  .Q_data = Sin_Track_Ekf_Q_data,
  .R_data = Sin_Track_Ekf_R_data,
  .x_init = Sin_Track_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Grid_Sync_Ekf
static float Grid_Sync_Ekf_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Grid_Sync_Ekf_R_data[1] = {0.1f};
static float Grid_Sync_Ekf_x_init[3] = {0.0f, 314.159265359f, 325.0f};
PP_GridSync_EKF Grid_Sync_Ekf_config = {
  .nom_freq = 50.0f,
  .nom_amplitude = 325.0f,
  .Q_data = Grid_Sync_Ekf_Q_data,
  .R_data = Grid_Sync_Ekf_R_data,
  .x_init = Grid_Sync_Ekf_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(2.0f, 0.0f);
  const_ = input("const", 0.0f);
  const__2 = input("const", 0.0f);
  expander shared_measurement = expander(4);
  thermalEKF Thermal_Ekf = thermalEKF(&Thermal_Ekf_config);
  baroAltEKF Baro_Alt_Ekf = baroAltEKF(&Baro_Alt_Ekf_config);
  sinTrackEKF Sin_Track_Ekf = sinTrackEKF(&Sin_Track_Ekf_config);
  gridSyncEKF Grid_Sync_Ekf = gridSyncEKF(&Grid_Sync_Ekf_config);
  thermal_ekf_0 = probe("thermal_ekf_0");
  thermal_ekf_1 = probe("thermal_ekf_1");
  baro_alt_ekf_0 = probe("baro_alt_ekf_0");
  baro_alt_ekf_1 = probe("baro_alt_ekf_1");
  Baro_Alt_Ekf_tap = probe("Baro Alt Ekf_o2");
  sin_track_ekf_0 = probe("sin_track_ekf_0");
  sin_track_ekf_1 = probe("sin_track_ekf_1");
  Sin_Track_Ekf_tap = probe("Sin Track Ekf_2");
  grid_sync_ekf_0 = probe("grid_sync_ekf_0");
  grid_sync_ekf_1 = probe("grid_sync_ekf_1");
  Grid_Sync_Ekf_tap = probe("Grid Sync Ekf_2");

  /* Connect Blocks */
  Source > shared_measurement;
  const_ > Thermal_Ekf.in(1);
  const__2 > Baro_Alt_Ekf.in(1);
  shared_measurement.out(0) > Thermal_Ekf.in(0);
  shared_measurement.out(1) > Baro_Alt_Ekf.in(0);
  shared_measurement.out(2) > Sin_Track_Ekf;
  shared_measurement.out(3) > Grid_Sync_Ekf;
  Thermal_Ekf.out(0) > thermal_ekf_0;
  Thermal_Ekf.out(1) > thermal_ekf_1;
  Baro_Alt_Ekf.out(0) > baro_alt_ekf_0;
  Baro_Alt_Ekf.out(1) > baro_alt_ekf_1;
  Baro_Alt_Ekf.out(2) > Baro_Alt_Ekf_tap;
  Sin_Track_Ekf.out(0) > sin_track_ekf_0;
  Sin_Track_Ekf.out(1) > sin_track_ekf_1;
  Sin_Track_Ekf.out(2) > Sin_Track_Ekf_tap;
  Grid_Sync_Ekf.out(0) > grid_sync_ekf_0;
  Grid_Sync_Ekf.out(1) > grid_sync_ekf_1;
  Grid_Sync_Ekf.out(2) > Grid_Sync_Ekf_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    thermal_ekf_0.show();
    thermal_ekf_1.show();
    baro_alt_ekf_0.show();
    baro_alt_ekf_1.show();
    Baro_Alt_Ekf_tap.show();
    sin_track_ekf_0.show();
    sin_track_ekf_1.show();
    Sin_Track_Ekf_tap.show();
    grid_sync_ekf_0.show();
    grid_sync_ekf_1.show();
    Grid_Sync_Ekf_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}