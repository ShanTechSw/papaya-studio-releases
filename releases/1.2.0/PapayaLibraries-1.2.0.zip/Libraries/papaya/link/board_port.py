"""Binding the relay engine to a real board.

The engine speaks transactions; a transport moves bytes framed by
chip-select. This is the twenty lines between them, and the reason it is
its own file is that every one of those lines is a protocol constant that
has to match the board rather than a choice anyone gets to make.

The response poll
-----------------
A command's status is not simply the next bytes back. The board holds it
until asked, and the asking is a nine-byte frame carrying the sequence
number the command used, checksummed. It answers a seven-byte frame, and
until the answer is ready it answers the request back unchanged, so the
poll repeats until the deadline.

**The sequence number is the far end's, not ours.** The relay did not
compose the command, so it reads the number out of the header it was given
and polls with that. Getting this wrong does not fail loudly: the board
answers perfectly well, the frame fails its sequence compare, and every
command appears to time out on a link that is working.
"""
from __future__ import annotations

import struct
import time
import zlib
from typing import Optional

#: Board protocol constants. Not tunable: these are the board's.
HEADER_SIZE = 18
RESPONSE_REQUEST_SIZE = 9
STATUS_SIZE = 7
CHECKSUM_SIZE = 4

SEQ_OFFSET = 0x00
READ_WRITE_OFFSET = 0x02
SIZE_LOW_OFFSET = 0x03

CMD_WRITE = 0x00
CMD_READ = 0x01
CMD_READ_VECTOR_PROBE = 0x02

RESPONSE_ID = 0xFFFF

#: How long to keep asking, and how often.
RESPONSE_TIMEOUT_MS = 1000
RESPONSE_POLL_INTERVAL_MS = 2

#: The board needs a moment between a vector-probe request and its
#: payload, the same wait the C++ library takes.
VECTOR_PROBE_DELAY_MS = 2


def _checksummed(frame: bytearray) -> bytes:
    """Append the CRC-32 the board's protocol uses over the frame body."""
    body = bytes(frame[:-CHECKSUM_SIZE])
    struct.pack_into("<I", frame, len(frame) - CHECKSUM_SIZE,
                     zlib.crc32(body) & 0xFFFFFFFF)
    return bytes(frame)


class TransportBoardPort:
    """A :class:`~papaya.link.gateway.BoardPort` over a byte transport.

    The transport supplies ``_write`` and ``_read``, each of which is one
    chip-select pulse. Everything below is which pulses, in what order.
    """

    def __init__(self, transport) -> None:
        self._transport = transport
        self._sequence = 0

    # -- config commands ----------------------------------------------

    def begin_command(self, header: bytes) -> None:
        # Adopt the far end's numbering before anything else: the poll
        # built later has to carry the number the board will answer with.
        if len(header) >= SEQ_OFFSET + 2:
            self._sequence = struct.unpack_from("<H", header, SEQ_OFFSET)[0]
        self._transport._write(bytes(header))

    def send_body_chunk(self, chunk: bytes) -> None:
        self._transport._write(bytes(chunk))

    def await_status(self) -> Optional[bytes]:
        request = bytearray(RESPONSE_REQUEST_SIZE)
        struct.pack_into("<H", request, SEQ_OFFSET, self._sequence)
        request[READ_WRITE_OFFSET] = CMD_READ
        struct.pack_into("<H", request, SIZE_LOW_OFFSET, RESPONSE_ID)
        frame = _checksummed(request)

        deadline = time.monotonic() + RESPONSE_TIMEOUT_MS / 1000.0
        while time.monotonic() < deadline:
            self._transport._write(frame)
            answer = self._transport._read(STATUS_SIZE, RESPONSE_POLL_INTERVAL_MS)
            if answer and len(answer) == STATUS_SIZE and _status_valid(answer):
                return answer
            time.sleep(RESPONSE_POLL_INTERVAL_MS / 1000.0)
        return None

    def read_data_payload(self, length: int) -> Optional[bytes]:
        if length <= 0:
            return b""
        return self._transport._read(length, RESPONSE_TIMEOUT_MS)

    # -- sampling-mode exchanges --------------------------------------

    def read_probes(self, length: int, vector: bool = False) -> Optional[bytes]:
        if length <= 0:
            return b""
        opcode = CMD_READ_VECTOR_PROBE if vector else CMD_READ
        self._transport._write(bytes([opcode]))
        if vector:
            time.sleep(VECTOR_PROBE_DELAY_MS / 1000.0)
        return self._transport._read(length, RESPONSE_TIMEOUT_MS)

    def write_inputs(self, values: bytes) -> bool:
        # The opcode and the values are two exchanges, and the values are
        # ONE of them. Splitting them leaves the firmware waiting for
        # floats and mis-parsing the next frame's opening bytes as input
        # data.
        if not self._transport._write(bytes([CMD_WRITE])):
            return False
        return bool(self._transport._write(bytes(values)))

    def send_opcode(self, opcode: int) -> bool:
        """One byte, one chip-select pulse, and nothing else.

        The board's wire carries several exchanges that are a lone
        opcode; a cable writes them as one byte and this is the same
        write. Nothing is polled afterwards because these opcodes do not
        answer.
        """
        return bool(self._transport._write(bytes([opcode & 0xFF])))

    # -- the line a cable does not own --------------------------------

    def reset(self) -> bool:
        reset = getattr(self._transport, "reset_board", None)
        if not callable(reset):
            return False
        ok = bool(reset())
        if ok:
            # The board came up fresh, so its numbering restarted at zero
            # and ours has to agree or the next command is refused.
            self._sequence = 0
        return ok


def _status_valid(status: bytes) -> bool:
    """A status frame is its own checksum's witness.

    Checked here rather than trusted, because until the board has an
    answer ready it echoes the request back, and an echo is exactly the
    right length to be mistaken for a reply.
    """
    body = status[:STATUS_SIZE - CHECKSUM_SIZE]
    seen = struct.unpack_from("<I", status, STATUS_SIZE - CHECKSUM_SIZE)[0]
    return seen == (zlib.crc32(body) & 0xFFFFFFFF)


__all__ = ["TransportBoardPort"]
