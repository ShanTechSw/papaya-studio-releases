/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 19:58:06
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ref_radps;
probe u_volts;
VectorProbe state_x_k_;
probe omega_radps;

/* Global Struct Declarations */
// Configuration for DC_motor__discrete_
static float DC_motor__discrete__A_data[4] = {0.998882f, 0.047592f, -0.004759f, 0.904649f};
static float DC_motor__discrete__B_data[2] = {0.00238f, 0.095232f};
static float DC_motor__discrete__C_data[6] = {1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f};
static float DC_motor__discrete__D_data[3] = {0.0f, 0.0f, 0.0f};
static float DC_motor__discrete__x_init[2] = {0.0f, 0.0f};
PP_stateSpace DC_motor__discrete__config = {
  .n = 2,
  .m = 1,
  .p = 3,
  .A_data = DC_motor__discrete__A_data,
  .B_data = DC_motor__discrete__B_data,
  .C_data = DC_motor__discrete__C_data,
  .D_data = DC_motor__discrete__D_data,
  .x_init = DC_motor__discrete__x_init
};


/* Global Array Declarations */
float LQR_servo__n_2__p_1__K[] = {2.989f, 1.004f, -94.98f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Speed_setpoint = signalSource::square(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 50.0f, /*offset=*/ 100.0f);
  lqrServo LQR_servo__n_2__p_1_ = lqrServo(2, 1, 1, LQR_servo__n_2__p_1__K, 24.0);
  expander u_fan = expander(2);
  stateSpace DC_motor__discrete_ = stateSpace(&DC_motor__discrete__config);
  expander y_fan = expander(2);
  ref_radps = probe("ref_omega_radps");
  u_volts = probe("u_volts");
  state_x_k_ = VectorProbe("state_x_omega_i");
  omega_radps = probe("omega_radps");

  /* Connect Blocks */
  Speed_setpoint > LQR_servo__n_2__p_1_.in(2);
  Speed_setpoint > ref_radps;
  LQR_servo__n_2__p_1_ > u_fan;
  u_fan.out(0) > DC_motor__discrete_;
  u_fan.out(1) > u_volts;
  DC_motor__discrete_.out(1) > LQR_servo__n_2__p_1_.in(0);
  DC_motor__discrete_.out(2) > LQR_servo__n_2__p_1_.in(1);
  DC_motor__discrete_.out(0) > y_fan;
  DC_motor__discrete_.out(0) >> state_x_k_;
  y_fan.out(1) > LQR_servo__n_2__p_1_.in(3);
  y_fan.out(0) > omega_radps;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    ref_radps.show();
    u_volts.show();
    state_x_k_.show();
    omega_radps.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}