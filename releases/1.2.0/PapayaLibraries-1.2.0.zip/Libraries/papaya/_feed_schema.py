"""The shape of a published list, named once.

Every field name, channel name and limit lives here, and both the client
that reads a list and the tool that writes one import them. Nothing
restates a literal. The existing generator already does this for the
per-platform keys, on the stated reasoning that a typo in one of those
strings is invisible until a user on that platform is silently told there
is no update for them, and the same applies to everything else.

THE DOCUMENT-LEVEL FIELDS, AND WHY EACH IS CONTRACT
---------------------------------------------------
These become permanent the moment one list is published, so the reasoning
is written down rather than left to be re-derived.

``serial``
    A publish counter on the DOCUMENT, not on the version it advertises.
    It goes up on every publish, including a publish that withdraws a bad
    release and points users back at an older one. Had it tracked the
    version, retracting a release would have meant moving the counter
    backwards, which the replay check refuses, and the channel would have
    been stuck. Format ``YYYYMMDDNN``: readable by a person, sortable as
    an integer, and bounded, so a fat-fingered enormous value cannot brick
    the channel with no way back down.

``min_key_id``
    The lowest signing key this list still considers valid. A client
    raises its own floor to this after accepting a list, and never lowers
    it. This is the only revocation the channel can physically deliver:
    without it, a leaked key verifies forever on every install that has
    not updated, and a second key buys nothing.

``published``
    When the list was written, as a plain date. Used only to notice that a
    list has stopped changing, which is the one thing a replay floor
    cannot see: an attacker who can serve today's genuine list forever
    keeps a user from learning a fix exists. In this version that produces
    a quiet note and never a refusal, because a fail-closed staleness rule
    at a small company takes the product down during any quiet quarter.

``history``
    The last few versions that may still be installed, each with its own
    address and checksum. Deliberate downgrade is served from HERE, out of
    the list that was just verified. No historical list is ever fetched,
    which is what lets the replay floor and the owner's requirement that
    downgrade be offered both hold at once.
"""
from __future__ import annotations

import re

#: Bumped only for a change that an older client could not read. Adding a
#: field does not need it; removing or repurposing one does.
SCHEMA_VERSION = 1

# --- document level --------------------------------------------------------
FIELD_SCHEMA = "schema"
FIELD_SERIAL = "serial"
FIELD_MIN_KEY_ID = "min_key_id"
FIELD_PUBLISHED = "published"

#: Top-level names the document itself uses, so a channel can never be
#: called one of them. Checked by the generator rather than left to luck.
RESERVED_TOP_LEVEL = frozenset(
    {FIELD_SCHEMA, FIELD_SERIAL, FIELD_MIN_KEY_ID, FIELD_PUBLISHED})

# --- channel level ---------------------------------------------------------
FIELD_VERSION = "version"
FIELD_URL = "url"
FIELD_SHA256 = "sha256"
FIELD_SIZE_BYTES = "size_bytes"
FIELD_NOTES_URL = "notes_url"
FIELD_DOWNLOADS = "downloads"
FIELD_HISTORY = "history"
FIELD_MIN_STUDIO = "min_studio_version"

CHANNEL_STABLE = "stable"
CHANNEL_BETA = "beta"
CHANNEL_DEV = "dev"
CHANNELS = (CHANNEL_STABLE, CHANNEL_BETA, CHANNEL_DEV)

#: How many past versions a list carries for deliberate downgrade. Ten is
#: enough to reach back through a year of releases and small enough that
#: the document stays far inside the read cap every client applies.
HISTORY_DEPTH = 10

#: A list must stay well under the client's read cap. Half, so there is
#: room for the history to grow without a published list suddenly becoming
#: unreadable by every copy in the field.
MAX_FEED_BYTES = 131072

#: The quiet note, not a refusal.
STALE_AFTER_DAYS = 56

_SERIAL_RE = re.compile(r"\A(20\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])"
                        r"(\d{2})\Z")


def make_serial(year: int, month: int, day: int, sequence: int) -> int:
    """``YYYYMMDDNN`` for the *sequence*-th publish on a given day."""
    if not 0 <= sequence <= 99:
        raise ValueError("at most 100 publishes in one day")
    text = f"{year:04d}{month:02d}{day:02d}{sequence:02d}"
    if _SERIAL_RE.match(text) is None:
        raise ValueError(f"not a usable date: {year}-{month}-{day}")
    return int(text)


def parse_serial(value: object) -> int | None:
    """The serial as an integer, or ``None`` when it is not one.

    Bounded on purpose. An unbounded counter lets one mistaken publish put
    the floor somewhere no honest release can ever reach.
    """
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    if _SERIAL_RE.match(f"{value:010d}") is None:
        return None
    return value
