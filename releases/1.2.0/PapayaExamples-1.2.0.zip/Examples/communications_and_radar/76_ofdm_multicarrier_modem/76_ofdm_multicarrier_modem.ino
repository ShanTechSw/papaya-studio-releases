/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-11 03:53:07
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ofdm_waveform;
VectorProbe ofdm_spectrum;
probe subcarrier_symbols_tap;
probe rx_bits_1;
probe rx_bits_2;
probe rx_bits_3;

input const_;
input bit_high;
input bit_low;
input on_above;
input off_below;
input bit_high_2;
input bit_low_2;
input on_above_2;
input off_below_2;
input bit_high_3;
input bit_low_3;
input on_above_3;
input off_below_3;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  bit_high = input("bit_high_1", 1.0f);
  bit_low = input("bit_low_1", 0.0f);
  on_above = input("on_above_1", 0.6f);
  off_below = input("off_below_1", 0.3f);
  bit_high_2 = input("bit_high_2", 1.0f);
  bit_low_2 = input("bit_low_2", 0.0f);
  on_above_2 = input("on_above_2", 0.6f);
  off_below_2 = input("off_below_2", 0.3f);
  bit_high_3 = input("bit_high_3", 1.0f);
  bit_low_3 = input("bit_low_3", 0.0f);
  on_above_3 = input("on_above_3", 0.6f);
  off_below_3 = input("off_below_3", 0.3f);
  signalSource SIM__bits_1 = signalSource::square(150.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 0.5f);
  signalSource subcarrier_1 = signalSource::sine(600.0f, 0.0f);
  signalSource SIM__bits_2 = signalSource::square(160.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 0.5f);
  signalSource subcarrier_2 = signalSource::sine(1500.0f, 0.0f);
  signalSource SIM__bits_3 = signalSource::square(170.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f, /*offset=*/ 0.5f);
  signalSource subcarrier_3 = signalSource::sine(2400.0f, 0.0f);
  const_ = input("const", 0.0f);
  node modulator_1 = node("[1.0 1.0]", "[1.0]", Mul);
  node modulator_2 = node("[1.0 1.0]", "[1.0]", Mul);
  node modulator_3 = node("[1.0 1.0]", "[1.0]", Mul);
  noise SIM__channel_noise = noise(-0.1, 0.1, uniform);
  node OFDM_sum = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  node channel_output = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_4 = expander(4);
  fft demod_FFT = fft(512);
  peak subcarrier_BPF_1 = peak(600.0, 2.0);
  peak subcarrier_BPF_2 = peak(1500.0, 5.0);
  peak subcarrier_BPF_3 = peak(2400.0, 8.0);
  fftMagResolver subcarrier_symbols = fftMagResolver(demod_FFT);
  envFollower symbol_detect_1 = envFollower(0.0004, 0.0012);
  envFollower symbol_detect_2 = envFollower(0.0004, 0.0012);
  envFollower symbol_detect_3 = envFollower(0.0004, 0.0012);
  schmidt slicer_1 = schmidt();
  schmidt slicer_2 = schmidt();
  schmidt slicer_3 = schmidt();
  ofdm_waveform = probe("ofdm_waveform");
  ofdm_spectrum = VectorProbe("ofdm_spectrum");
  subcarrier_symbols_tap = probe("subcarrier_0");
  rx_bits_1 = probe("rx_bits_1");
  rx_bits_2 = probe("rx_bits_2");
  rx_bits_3 = probe("rx_bits_3");

  /* Connect Blocks */
  bit_high > slicer_1.in(1);
  bit_low > slicer_1.in(2);
  on_above > slicer_1.in(3);
  off_below > slicer_1.in(4);
  bit_high_2 > slicer_2.in(1);
  bit_low_2 > slicer_2.in(2);
  on_above_2 > slicer_2.in(3);
  off_below_2 > slicer_2.in(4);
  bit_high_3 > slicer_3.in(1);
  bit_low_3 > slicer_3.in(2);
  on_above_3 > slicer_3.in(3);
  off_below_3 > slicer_3.in(4);
  SIM__bits_1 > modulator_1.in(0);
  subcarrier_1 > modulator_1.in(1);
  SIM__bits_2 > modulator_2.in(0);
  subcarrier_2 > modulator_2.in(1);
  SIM__bits_3 > modulator_3.in(0);
  subcarrier_3 > modulator_3.in(1);
  const_ > SIM__channel_noise;
  modulator_1 > OFDM_sum.in(0);
  modulator_2 > OFDM_sum.in(1);
  modulator_3 > OFDM_sum.in(2);
  SIM__channel_noise > channel_output.in(1);
  OFDM_sum > channel_output.in(0);
  channel_output > fan_4;
  channel_output > ofdm_waveform;
  fan_4.out(0) > demod_FFT;
  fan_4.out(1) > subcarrier_BPF_1;
  fan_4.out(2) > subcarrier_BPF_2;
  fan_4.out(3) > subcarrier_BPF_3;
  demod_FFT > subcarrier_symbols;
  subcarrier_BPF_1 > symbol_detect_1;
  subcarrier_BPF_2 > symbol_detect_2;
  subcarrier_BPF_3 > symbol_detect_3;
  subcarrier_symbols >> ofdm_spectrum;
  subcarrier_symbols > subcarrier_symbols_tap;
  symbol_detect_1 > slicer_1.in(0);
  symbol_detect_2 > slicer_2.in(0);
  symbol_detect_3 > slicer_3.in(0);
  slicer_1 > rx_bits_1;
  slicer_2 > rx_bits_2;
  slicer_3 > rx_bits_3;

  /* Enable Remote Input Control */
  bit_high.enableRemote();
  bit_low.enableRemote();
  on_above.enableRemote();
  off_below.enableRemote();
  bit_high_2.enableRemote();
  bit_low_2.enableRemote();
  on_above_2.enableRemote();
  off_below_2.enableRemote();
  bit_high_3.enableRemote();
  bit_low_3.enableRemote();
  on_above_3.enableRemote();
  off_below_3.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    ofdm_waveform.show();
    ofdm_spectrum.show();
    subcarrier_symbols_tap.show();
    rx_bits_1.show();
    rx_bits_2.show();
    rx_bits_3.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}