var struct_p_p___m_r_a_c_config =
[
    [ "Am", "struct_p_p___m_r_a_c_config.html#acc1407b20046b4fb37f1df90e51cf547", null ],
    [ "Bm", "struct_p_p___m_r_a_c_config.html#a5ed609e6c810157337e8d3f600772df5", null ],
    [ "gamma_r", "struct_p_p___m_r_a_c_config.html#af37b44c2e99f593f9341770cf0c9a6ad", null ],
    [ "gamma_x", "struct_p_p___m_r_a_c_config.html#ad5b32dd0a57e0e38a6aa65b12f387f75", null ]
];