var _papaya_pc_usb_device_8cpp =
[
    [ "PAPAYA_LIBUSB_CALL", "_papaya_pc_usb_device_8cpp.html#a1277496a01914be3a72d85e0149bf9b5", null ]
];