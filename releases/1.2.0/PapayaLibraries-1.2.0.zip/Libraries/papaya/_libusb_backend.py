"""One place that decides which libusb pyusb talks to.

Every consumer of pyusb in this tree needs the same answer to the same
question, and getting it wrong is not a degradation: the board becomes
unopenable. Before this module the answer was copy-pasted per call site and
each copy handled Windows only.

The problem, precisely
----------------------
``usb.core.find(backend=None)`` asks pyusb to discover libusb for itself.
pyusb's ``usb.libloader.locate_library`` does that through
``ctypes.util.find_library``, which on Linux consults, in order, the
``ldconfig`` cache, then ``gcc``, then ``ld``. **None of those is the
dynamic loader, so none of them honours LD_LIBRARY_PATH.**

That matters because the frozen Linux build carries its own
``libusb-1.0.so.0`` inside the bundle, precisely so the application works on
a desktop that has never had libusb installed. The outcome splits in a way
that is close to the worst possible for testing:

* Machine WITH a system libusb: ``find_library`` returns a bare soname, the
  subsequent ``CDLL`` goes through the loader, and the loader *does* read
  LD_LIBRARY_PATH, so the bundled copy is what gets used. Works.
* Machine WITHOUT one (the case the bundling exists for): discovery fails
  before any ``dlopen`` is attempted. The bundled file is never tried.
  ``usb.core.find`` raises ``NoBackendError`` and the board is reported
  missing while the library sits inside the application.

So it works on every machine a developer owns and fails at the customer.
The fix is to stop asking pyusb to search and hand it the path, which is
what the Windows branch had always done with the bundled DLL.

Usage
-----
    from papaya._libusb_backend import get_backend
    dev = usb.core.find(idVendor=VID, idProduct=PID, backend=get_backend())

``get_backend()`` returns None when nothing can be resolved, which is also
what pyusb's own accessor returns; passing None to ``usb.core.find`` means
"discover it yourself", so a None here leaves behaviour exactly as it was
rather than breaking a working machine.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

#: Filenames to look for, per platform, inside the frozen bundle.
_BUNDLED_NAMES = {
    "win32": ("libusb-1.0.dll",),
    "darwin": ("libusb-1.0.dylib",),
}
_BUNDLED_NAMES_LINUX = ("libusb-1.0.so.0", "libusb-1.0.so")

#: Set once, because pyusb caches its backend globally anyway and repeating
#: the filesystem search on every reconnect is pure waste.
_cached: object | None = None
_resolved = False


def _candidate_names() -> tuple[str, ...]:
    if sys.platform.startswith("linux"):
        return _BUNDLED_NAMES_LINUX
    return _BUNDLED_NAMES.get(sys.platform, _BUNDLED_NAMES_LINUX)


#: Directories to add to the search, supplied by whatever embeds this
#: package. A frozen application that stages its own copy of libusb
#: somewhere unusual appends to this at import time rather than having its
#: layout described here.
EXTRA_SEARCH_DIRS: list[Path] = []


def _search_dirs() -> list[Path]:
    """Directories that may hold a libusb shipped alongside this package.

    In a frozen application, the bundle's own resource directory and the
    directory holding the executable. Outside one, the directories beside
    this package that carry a vendored library. Anything else an embedder
    knows about goes in :data:`EXTRA_SEARCH_DIRS`.
    """
    out: list[Path] = []
    bundle = getattr(sys, "_MEIPASS", None)
    if bundle:
        base = Path(bundle)
        out += [base, base.parent]
    if getattr(sys, "frozen", False):
        try:
            out.append(Path(sys.executable).resolve().parent)
        except OSError:
            pass
    here = Path(__file__).resolve().parent
    out += [here, here.parent / "firmware_updater"]
    out += list(EXTRA_SEARCH_DIRS)

    seen: set[str] = set()
    unique: list[Path] = []
    for d in out:
        key = str(d)
        if key not in seen:
            seen.add(key)
            unique.append(d)
    return unique


def find_bundled_libusb() -> str | None:
    """Absolute path to a libusb we ship, or None.

    An explicit ``PAPAYA_LIBUSB`` overrides everything, for diagnosing a
    machine where the shipped copy is the suspect.
    """
    # LIBUSB_DLL is the older, Windows-flavoured spelling that two call
    # sites already honoured; kept so an existing machine that sets it does
    # not silently change behaviour.
    for var in ("PAPAYA_LIBUSB", "LIBUSB_DLL"):
        override = (os.environ.get(var) or "").strip()
        if override and os.path.isfile(override):
            return override
    for d in _search_dirs():
        for name in _candidate_names():
            cand = d / name
            try:
                if cand.is_file():
                    return str(cand)
            except OSError:
                continue
    return None


def get_backend():
    """The libusb1 backend to pass as ``backend=`` to ``usb.core.find``.

    Returns None if pyusb is absent or no library resolves, which callers
    must treat as "let pyusb decide" rather than as an error.
    """
    global _cached, _resolved
    if _resolved:
        return _cached

    _resolved = True
    try:
        import usb.backend.libusb1  # noqa: PLC0415
    except ImportError:
        _cached = None
        return None

    path = find_bundled_libusb()
    if path:
        # find_library is handed a constant, bypassing the search that
        # cannot see inside our own bundle.
        _cached = usb.backend.libusb1.get_backend(find_library=lambda _n, p=path: p)
        if _cached is not None:
            return _cached

    # Nothing bundled, or the bundled copy failed to load (wrong
    # architecture, missing dependency of its own). Fall back to pyusb's
    # own discovery so a machine with a working system libusb is unaffected.
    _cached = usb.backend.libusb1.get_backend()
    return _cached


def describe() -> str:
    """One line for diagnostics and problem reports."""
    path = find_bundled_libusb()
    if path:
        return f"bundled libusb: {path}"
    return "no bundled libusb found; relying on the system library"


def _reset_for_tests() -> None:
    """Drop the cache. Tests only."""
    global _cached, _resolved
    _cached = None
    _resolved = False
