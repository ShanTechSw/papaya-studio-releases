/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:41:23
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe switched;
probe muxed;
probe routed;
probe Route_tap;

input select;
input Pick_p2;
input Select_p1;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  select = input("select", 0.0f);
  signalSource Source = signalSource::sine(6.0f, 0.0f);
  Pick_p2 = input("Pick_p2", 0.0f);
  Select_p1 = input("Select_p1", 0.0f);
  expander fan_3 = expander(3);
  expander fan_3_2 = expander(3);
  switchBlock Pick = switchBlock();
  mux Select = mux(2);
  demux Route = demux(2);
  switched = probe("switched");
  muxed = probe("muxed");
  routed = probe("routed");
  Route_tap = probe("Route_o1");

  /* Connect Blocks */
  select > fan_3_2;
  Source > fan_3;
  Pick_p2 > Pick.in(2);
  Select_p1 > Select.in(1);
  fan_3.out(0) > Pick.in(1);
  fan_3.out(1) > Select.in(0);
  fan_3.out(2) > Route.in(0);
  fan_3_2.out(0) > Pick.in(0);
  fan_3_2.out(1) > Select.in(2);
  fan_3_2.out(2) > Route.in(1);
  Pick > switched;
  Select > muxed;
  Route.out(0) > routed;
  Route.out(1) > Route_tap;

  /* Enable Remote Input Control */
  select.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    switched.show();
    muxed.show();
    routed.show();
    Route_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}