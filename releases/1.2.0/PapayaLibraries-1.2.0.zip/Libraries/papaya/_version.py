"""
Single source of truth for the PAPAYA Studio application version.

Every consumer of the version string (splash, About dialog, installer
AppVersion, build report, update-manifest emitter, window title) MUST
read from here. The release engine rewrites `__version__` in place
during a release; nothing else should write to this file.

The version follows Semantic Versioning 2.0.0 (https://semver.org/):
    MAJOR.MINOR.PATCH[-PRERELEASE][+BUILD]
"""

from __future__ import annotations

__version__ = "1.2.0"

# Release channel: "stable" | "beta" | "dev". The release build rewrites
# this in place: "beta" when the version carries a pre-release tag
# (e.g. 1.2.0-rc1), "dev" for a development build, "stable" otherwise.
# Drives the channel label in the About
# dialog / window title and which feed the update checker polls.
__channel__ = "dev"

__app_name__ = "PAPAYA Studio"
__publisher__ = "Shanon Technologies SAS"
__publisher_url__ = "https://shanon-technologies.com"
__copyright__ = "Copyright (C) Shanon Technologies SAS. All rights reserved."


def version_display() -> str:
    """Version string for the UI, with the channel shown when not stable.

    ``1.0.0`` (stable) · ``1.2.0-rc1 (Beta)`` · ``1.0.0 (Dev)``
    """
    label = {"beta": " (Beta)", "dev": " (Dev)"}.get(__channel__, "")
    return f"{__version__}{label}"


def version_tuple() -> tuple[int, int, int]:
    """Return (MAJOR, MINOR, PATCH) for numeric comparison.

    Strips any pre-release / build suffix. Raises ValueError on a
    malformed `__version__` so the release engine fails loudly rather
    than shipping a broken version string.
    """
    core = __version__.split("-", 1)[0].split("+", 1)[0]
    parts = core.split(".")
    if len(parts) != 3:
        raise ValueError(f"Malformed __version__: {__version__!r}")
    return (int(parts[0]), int(parts[1]), int(parts[2]))
