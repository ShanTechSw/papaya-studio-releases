var struct_p_p___remote_design =
[
    [ "inputCount", "struct_p_p___remote_design.html#adacd296c2b7703d8e5ea8206df9917aa", null ],
    [ "inputNames", "struct_p_p___remote_design.html#a98c6e1f3088478ada0f869e78b896408", null ],
    [ "inputValues", "struct_p_p___remote_design.html#a265ef5b8ace974bd2e8a63989b3e7ba2", null ],
    [ "probeCount", "struct_p_p___remote_design.html#af09ad8e8ccfb9392e5bd7f754e83055f", null ],
    [ "probeNames", "struct_p_p___remote_design.html#a12a8e2572fd394c6058ba8163e97cf82", null ],
    [ "sampleRateHz", "struct_p_p___remote_design.html#a6cca6323014e59d5e9251de8048e69a7", null ],
    [ "samplesPerProbe", "struct_p_p___remote_design.html#ae21bddd9946a70de83a0a4594d91ec57", null ]
];