/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe trapezoid_profile_tap;
probe sway_unshaped;
probe trolley_position;
probe sway_shaped;

input trolley_target;
input v_max;
input a_max;
input drive_min;
input drive_max;

/* Global Struct Declarations */
// Configuration for SIM__pendulum__no_shaper_
static float SIM__pendulum__no_shaper__A_data[4] = {0.0f, 1.0f, -0.999911413524f, 1.99990650858f};
static float SIM__pendulum__no_shaper__B_data[2] = {0.0f, 1.0f};
static float SIM__pendulum__no_shaper__C_data[2] = {4.90494253491e-06f, 0.0f};
static float SIM__pendulum__no_shaper__D_data[1] = {0.0f};
static float SIM__pendulum__no_shaper__x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__pendulum__no_shaper__config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__pendulum__no_shaper__A_data,
  .B_data = SIM__pendulum__no_shaper__B_data,
  .C_data = SIM__pendulum__no_shaper__C_data,
  .D_data = SIM__pendulum__no_shaper__D_data,
  .x_init = SIM__pendulum__no_shaper__x_init
};

// Configuration for SIM__payload_pendulum
static float SIM__payload_pendulum_A_data[4] = {0.0f, 1.0f, -0.999911413524f, 1.99990650858f};
static float SIM__payload_pendulum_B_data[2] = {0.0f, 1.0f};
static float SIM__payload_pendulum_C_data[2] = {4.90494253491e-06f, 0.0f};
static float SIM__payload_pendulum_D_data[1] = {0.0f};
static float SIM__payload_pendulum_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__payload_pendulum_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__payload_pendulum_A_data,
  .B_data = SIM__payload_pendulum_B_data,
  .C_data = SIM__payload_pendulum_C_data,
  .D_data = SIM__payload_pendulum_D_data,
  .x_init = SIM__payload_pendulum_x_init
};


/* Global Array Declarations */
float SIM__trolley_drive_numerator[] = {1.0f};
float SIM__trolley_drive_denominator[] = {1.0f, 3.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  trolley_target = input("trolley_target", 2.0f);
  v_max = input("v_max", 1.0f);
  a_max = input("a_max", 2.0f);
  drive_min = input("drive_min", -1.0f);
  drive_max = input("drive_max", 1.0f);
  signalSource start = signalSource::step(0.1f, 0.0f, 1.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  trajTrapezoid trapezoid_profile = trajTrapezoid();
  inputShaper anti_sway_shaper = inputShaper(2, 2.2147, 0.02);
  stateSpace SIM__pendulum__no_shaper_ = stateSpace(&SIM__pendulum__no_shaper__config);
  node position_error = node("[1.0 -1.0]", "[1.0]", Sum);
  node damped_command = node("[1.0 1.0]", "[1.0]", Sum);
  pid trolley_PID = pid(0.2, 3.0, 1.1, 0.02);
  sat drive_clamp = sat();
  tf SIM__trolley_drive = tf(SIM__trolley_drive_numerator, 1, SIM__trolley_drive_denominator, 2);
  expander fan_2 = expander(2);
  derivative trolley_accel = derivative(0.03);
  stateSpace SIM__payload_pendulum = stateSpace(&SIM__payload_pendulum_config);
  derivative sway_rate = derivative(0.05);
  gain sway_damping = gain(-0.8);
  trapezoid_profile_tap = probe("trapezoid pro_1");
  sway_unshaped = probe("sway_unshaped");
  trolley_position = probe("trolley_positio");
  sway_shaped = probe("sway_shaped_rad");

  /* Connect Blocks */
  trolley_target > trapezoid_profile.in(0);
  v_max > trapezoid_profile.in(1);
  a_max > trapezoid_profile.in(2);
  drive_min > drive_clamp.in(1);
  drive_max > drive_clamp.in(0);
  start > trapezoid_profile.in(3);
  trapezoid_profile.out(0) > anti_sway_shaper;
  trapezoid_profile.out(2) > SIM__pendulum__no_shaper_;
  trapezoid_profile.out(1) > trapezoid_profile_tap;
  anti_sway_shaper > position_error.in(0);
  SIM__pendulum__no_shaper_ > sway_unshaped;
  position_error > damped_command.in(0);
  damped_command > trolley_PID;
  trolley_PID > drive_clamp.in(2);
  drive_clamp > SIM__trolley_drive;
  SIM__trolley_drive > fan_2;
  SIM__trolley_drive > trolley_position;
  fan_2.out(0) > position_error.in(1);
  fan_2.out(1) > trolley_accel;
  trolley_accel > SIM__payload_pendulum;
  SIM__payload_pendulum > sway_rate;
  SIM__payload_pendulum > sway_shaped;
  sway_rate > sway_damping;
  sway_damping > damped_command.in(1);

  /* Enable Remote Input Control */
  trolley_target.enableRemote();
  v_max.enableRemote();
  a_max.enableRemote();
  drive_min.enableRemote();
  drive_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    trapezoid_profile_tap.show();
    sway_unshaped.show();
    trolley_position.show();
    sway_shaped.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}