/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe unused_signals;

input az_mps2;
input ground_raw;
input alt_ref_m;
input roll_ref_rad;
input pitch_ref_rad;
input yaw_ref_rad;
input hover_frac;
input T_hi;
input T_lo;

/* Global Struct Declarations */
// Configuration for Baro_alt_EKF
static float Baro_alt_EKF_Q_data[9] = {0.01f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Baro_alt_EKF_R_data[1] = {0.5f};
static float Baro_alt_EKF_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_BaroAlt_EKF Baro_alt_EKF_config = {
  .Q_data = Baro_alt_EKF_Q_data,
  .R_data = Baro_alt_EKF_R_data,
  .x_init = Baro_alt_EKF_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  az_mps2 = input("az_mps2", 0.0f);
  ground_raw = input("ground_raw", 2048.0f);
  alt_ref_m = input("alt_ref_m", 1.5f);
  roll_ref_rad = input("roll_ref_rad", 0.0f);
  pitch_ref_rad = input("pitch_ref_rad", 0.0f);
  yaw_ref_rad = input("yaw_ref_rad", 0.0f);
  hover_frac = input("hover_frac", 0.5f);
  T_hi = input("T_hi", 1.0f);
  T_lo = input("T_lo", 0.0f);
  imu IMU = imu(IMU_ACC, 1.0);
  analogIn Barometer = analogIn(AIN1, 1.0, 0.0);
  imu Gyro = imu(IMU_GYR, 0.017453293);
  imu Magnetometer = imu(IMU_MAG, 1.0);
  madgwickAhrs Madgwick_AHRS = madgwickAhrs(0.1);
  node above_ground = node("[1.0 -1.0]", "[1.0]", Sum);
  quatToEuler Quat_to_Euler = quatToEuler();
  gain raw_to_metres = gain(-0.0836);
  baroAltEKF Baro_alt_EKF = baroAltEKF(&Baro_alt_EKF_config);
  node roll_err = node("[-1.0 1.0]", "[1.0]", Sum);
  node pitch_err = node("[1.0 -1.0]", "[1.0]", Sum);
  node yaw_err = node("[-1.0 1.0]", "[1.0]", Sum);
  pid Roll_PID = pid(0.005, 0.04, 0.008, 0.01);
  pid Pitch_PID = pid(0.005, 0.04, 0.008, 0.01);
  pid Yaw_PID = pid(0.002, 0.02, 0.004, 0.01);
  node alt_err = node("[1.0 -1.0]", "[1.0]", Sum);
  pid Altitude_PID = pid(0.004, 0.03, 0.012, 0.01);
  node thrust = node("[1.0 1.0]", "[1.0]", Sum);
  sat thrust_clamp = sat();
  mixerMultirotor Quad_X_mixer = mixerMultirotor(0, 0.0, 1.0);
  pwmOut ESC_1 = pwmOut(FO1, 1000.0, 0.0, 1.0);
  pwmOut ESC_2 = pwmOut(FO2, 1000.0, 0.0, 1.0);
  pwmOut ESC_3 = pwmOut(FO3, 1000.0, 0.0, 1.0);
  pwmOut ESC_4 = pwmOut(FO4, 1000.0, 0.0, 1.0);
  merger unused_bus = merger(6);
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  az_mps2 > Baro_alt_EKF.in(1);
  ground_raw > above_ground.in(1);
  alt_ref_m > alt_err.in(0);
  roll_ref_rad > roll_err.in(0);
  pitch_ref_rad > pitch_err.in(0);
  yaw_ref_rad > yaw_err.in(0);
  hover_frac > thrust.in(0);
  T_hi > thrust_clamp.in(0);
  T_lo > thrust_clamp.in(1);
  IMU.out(0) > Madgwick_AHRS.in(0);
  IMU.out(1) > Madgwick_AHRS.in(1);
  IMU.out(2) > Madgwick_AHRS.in(2);
  Barometer > above_ground.in(0);
  Gyro.out(0) > Madgwick_AHRS.in(3);
  Gyro.out(1) > Madgwick_AHRS.in(4);
  Gyro.out(2) > Madgwick_AHRS.in(5);
  Magnetometer.out(0) > Madgwick_AHRS.in(6);
  Magnetometer.out(1) > Madgwick_AHRS.in(7);
  Magnetometer.out(2) > Madgwick_AHRS.in(8);
  Madgwick_AHRS.out(0) > Quat_to_Euler.in(0);
  Madgwick_AHRS.out(1) > Quat_to_Euler.in(1);
  Madgwick_AHRS.out(2) > Quat_to_Euler.in(2);
  Madgwick_AHRS.out(3) > Quat_to_Euler.in(3);
  above_ground > raw_to_metres;
  Quat_to_Euler.out(0) > roll_err.in(1);
  Quat_to_Euler.out(1) > pitch_err.in(1);
  Quat_to_Euler.out(2) > yaw_err.in(1);
  raw_to_metres > Baro_alt_EKF.in(0);
  Baro_alt_EKF.out(0) > alt_err.in(1);
  Baro_alt_EKF.out(1) > unused_bus.in(0);
  Baro_alt_EKF.out(2) > unused_bus.in(1);
  roll_err > Roll_PID;
  pitch_err > Pitch_PID;
  yaw_err > Yaw_PID;
  Roll_PID > Quad_X_mixer.in(1);
  Pitch_PID > Quad_X_mixer.in(2);
  Yaw_PID > Quad_X_mixer.in(3);
  alt_err > Altitude_PID;
  Altitude_PID > thrust.in(1);
  thrust > thrust_clamp.in(2);
  thrust_clamp > Quad_X_mixer.in(0);
  Quad_X_mixer.out(0) > ESC_1;
  Quad_X_mixer.out(1) > ESC_2;
  Quad_X_mixer.out(2) > ESC_3;
  Quad_X_mixer.out(3) > ESC_4;
  Quad_X_mixer.out(4) > unused_bus.in(2);
  Quad_X_mixer.out(5) > unused_bus.in(3);
  Quad_X_mixer.out(6) > unused_bus.in(4);
  Quad_X_mixer.out(7) > unused_bus.in(5);
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  az_mps2.enableRemote();
  ground_raw.enableRemote();
  alt_ref_m.enableRemote();
  roll_ref_rad.enableRemote();
  pitch_ref_rad.enableRemote();
  yaw_ref_rad.enableRemote();
  hover_frac.enableRemote();
  T_hi.enableRemote();
  T_lo.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}