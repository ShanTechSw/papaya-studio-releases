var classdecimation =
[
    [ "decimation", "classdecimation.html#a860e718f9ed80b294f18becc7c9794fa", null ],
    [ "decimation", "classdecimation.html#a35fc932e10a4947a16988640648f568b", null ]
];