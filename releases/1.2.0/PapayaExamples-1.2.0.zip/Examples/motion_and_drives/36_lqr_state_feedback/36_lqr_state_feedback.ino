/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe reg_error;

input ref;

/* Global Struct Declarations */
// Configuration for Plant_A_B_C_D
static float Plant_A_B_C_D_A_data[4] = {1.0f, 0.01f, 0.0f, 0.99f};
static float Plant_A_B_C_D_B_data[2] = {0.0f, 0.01f};
static float Plant_A_B_C_D_C_data[8] = {1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f};
static float Plant_A_B_C_D_D_data[4] = {0.0f, 0.0f, 0.0f, 0.0f};
static float Plant_A_B_C_D_x_init[2] = {0.0f, 0.0f};
PP_stateSpace Plant_A_B_C_D_config = {
  .n = 2,
  .m = 1,
  .p = 4,
  .A_data = Plant_A_B_C_D_A_data,
  .B_data = Plant_A_B_C_D_B_data,
  .C_data = Plant_A_B_C_D_C_data,
  .D_data = Plant_A_B_C_D_D_data,
  .x_init = Plant_A_B_C_D_x_init
};


/* Global Array Declarations */
float LQR_servo_K[] = {2.1234f, 1.4997f, -7.0181f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 1.0f);
  expander ref_fan = expander(2);
  lqrServo LQR_servo = lqrServo(2, 1, 1, LQR_servo_K, 10.0);
  stateSpace Plant_A_B_C_D = stateSpace(&Plant_A_B_C_D_config);
  node Tracking_error = node("[1.0 -1.0]", "[1.0]", Sum);
  reg_error = probe("regulation_erro");

  /* Connect Blocks */
  ref > ref_fan;
  ref_fan.out(0) > LQR_servo.in(2);
  ref_fan.out(1) > Tracking_error.in(0);
  LQR_servo > Plant_A_B_C_D;
  Plant_A_B_C_D.out(0) > LQR_servo.in(3);
  Plant_A_B_C_D.out(1) > LQR_servo.in(0);
  Plant_A_B_C_D.out(2) > LQR_servo.in(1);
  Plant_A_B_C_D.out(3) > Tracking_error.in(1);
  Tracking_error > reg_error;

  /* Enable Remote Input Control */
  ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    reg_error.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}