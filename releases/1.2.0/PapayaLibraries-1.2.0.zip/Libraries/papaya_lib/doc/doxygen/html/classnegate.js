var classnegate =
[
    [ "negate", "classnegate.html#aa367dd60d162a7ee6f4367dc94ee26cc", null ]
];