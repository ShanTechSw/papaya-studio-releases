/**
 * @file    papaya_link_board_port.cpp
 * @brief   See papaya_link_board_port.h.
 */
#include "papaya_link_board_port.h"

namespace papaya {
namespace link {

void LibraryBoardPort::beginCommand(const uint8_t *header, uint16_t length)
{
  /* The header is a fixed size on this wire. A shorter one is not a
   * shorter header, it is a caller that has lost track of the frame, and
   * putting it on the wire would leave the board reading the next thing
   * that arrives as the rest of it. */
  if ((header == 0) || (length != PP_CMD_HEADER_SIZE)) { return; }
  device_.relayBeginCommand(header);
}

void LibraryBoardPort::sendBodyChunk(const uint8_t *chunk, uint32_t length)
{
  if ((chunk == 0) || (length == 0u)) { return; }

  /* The engine never hands over more than one board chunk, but this is
   * the layer that would silently truncate if it ever did, and a
   * truncated body is a command the board waits forever to finish. Split
   * rather than trust, and never drop. */
  uint32_t sent = 0u;
  while (sent < length)
  {
    const uint32_t remaining = length - sent;
    const uint16_t piece = (remaining > (uint32_t)PP_CMD_CHUNK_SIZE)
                         ? (uint16_t)PP_CMD_CHUNK_SIZE
                         : (uint16_t)remaining;
    device_.relaySendBodyChunk(&chunk[sent], piece);
    sent += piece;
  }
}

uint16_t LibraryBoardPort::awaitStatus(uint8_t *status, uint16_t capacity)
{
  if ((status == 0) || (capacity < PP_RESPONSE_SIZE)) { return 0u; }
  if (!device_.relayAwaitResponse(status)) { return 0u; }
  return (uint16_t)PP_RESPONSE_SIZE;
}

uint32_t LibraryBoardPort::readDataPayload(uint8_t *out, uint32_t length)
{
  if ((out == 0) || (length == 0u) || (length > 0xFFFFu)) { return 0u; }
  if (!device_.relayReadDataPayload(out, (uint16_t)length)) { return 0u; }
  return length;
}

uint32_t LibraryBoardPort::readProbes(uint8_t *out, uint32_t length,
                                      bool vector)
{
  /* The count is the far end's, always. The library's own probe read
   * sizes itself from probe objects the running program constructed, and
   * a gateway constructs none, so without a count it asks for nothing. */
  if ((out == 0) || (length == 0u) || (length > 0xFFFFu)) { return 0u; }
  return vector ? device_.relayReadVectorProbes(out, (uint16_t)length)
                : device_.relayReadProbes(out, (uint16_t)length);
}

bool LibraryBoardPort::sendOpcode(uint8_t opcode)
{
  return device_.relaySendOpcode(opcode);
}


bool LibraryBoardPort::writeInputs(const uint8_t *values, uint32_t length)
{
  /* All slots in ONE exchange. Splitting them leaves the firmware waiting
   * for floats and mis-parsing whatever arrives next as input data, so a
   * write too large to send whole is refused rather than divided. */
  if ((values == 0) || (length == 0u) || (length > 0xFFFFu)) { return false; }
  return device_.relayWriteInputs(values, (uint16_t)length);
}

bool LibraryBoardPort::resetBoard(void)
{
  return device_.resetBoard();
}

void LibraryBoardPort::quiesce(void)
{
  /* stopSampling() and not a bare opcode, and the difference matters on
   * this wire. It sends PP_CMD_SWITCH_BACK_TO_CFG only when the library
   * knows data exchange is actually running, then a whole StopSampling
   * command. A lone opcode byte sent to a board in CONFIGURATION mode is
   * not a mode change there: a configuration chip-select is expected to
   * carry an eighteen-byte header, so a single byte is a header that
   * stopped, and the board has no inter-frame timeout to escape it. The
   * same trap catches a host that connects over the cable, and for the
   * same reason: it is one wire and one rule. */
  device_.stopSampling();
}

}  /* namespace link */
}  /* namespace papaya */
