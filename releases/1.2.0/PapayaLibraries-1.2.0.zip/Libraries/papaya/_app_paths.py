r"""
Per-user data + log + crash + cache directories.

Centralised so every consumer (logger, crash reporter, autosave, Help
menu) agrees on locations, and so each platform gets the location its
users and its backup tools expect rather than a Windows layout spelled
with forward slashes.

    Windows   %LOCALAPPDATA%\Papaya Studio\{,logs,crashes,cache}
    Linux     $XDG_DATA_HOME/papaya-studio          (data)
              $XDG_STATE_HOME/papaya-studio/logs    (logs, crashes)
              $XDG_CACHE_HOME/papaya-studio         (cache)
    macOS     ~/Library/Application Support/Papaya Studio
              ~/Library/Logs/Papaya Studio
              ~/Library/Caches/Papaya Studio

The split matters on Linux and macOS in a way it does not on Windows.
Cache contents are regenerable and a backup tool is entitled to skip
them; logs are diagnostic state a user may be asked to send in. Putting
all three under one root, as the Windows layout does, means either the
cache gets backed up or the logs get discarded. Windows resolution is
unchanged from the layout the installer and the support documentation
already describe.

Directories are created on first call to each getter.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Display name, used where the platform's convention is title case.
_APP_NAME = "Papaya Studio"
# freedesktop convention: lowercase, no spaces, usable as a directory
# name in $XDG_* roots and as the .desktop / MIME basename.
_APP_ID = "papaya-studio"


def _platform() -> str:
    """The platform selector, isolated so tests can pin it.

    Every branch below reads this rather than ``sys.platform`` directly,
    so the Linux and macOS layouts are assertable from a Windows test
    run. Without that the branches would only ever be exercised on the
    machine that cannot check them.
    """
    return sys.platform


def _home() -> Path:
    return Path.home()


def _xdg_root(var: str, default_rel: str) -> Path:
    """Resolve one XDG base directory, then append the app id.

    The spec is explicit that a relative value is invalid and must be
    treated as unset, which matters here because a stray ``XDG_CACHE_HOME=.``
    in a user's shell profile would otherwise scatter cache directories
    into whatever the working directory happened to be.
    """
    raw = (os.environ.get(var) or "").strip()
    base = Path(raw) if raw and os.path.isabs(raw) else _home() / default_rel
    return base / _APP_ID


def _data_root() -> Path:
    """Per-user data: settings, autosave snapshots, anything user-owned."""
    plat = _platform()
    if plat == "win32":
        base = (os.environ.get("LOCALAPPDATA")
                or os.environ.get("APPDATA")
                or str(_home()))
        return Path(base) / _APP_NAME
    if plat == "darwin":
        return _home() / "Library" / "Application Support" / _APP_NAME
    return _xdg_root("XDG_DATA_HOME", ".local/share")


def _logs_root() -> Path:
    """Diagnostic state: the log file and the crash dumps."""
    plat = _platform()
    if plat == "win32":
        return _data_root()
    if plat == "darwin":
        return _home() / "Library" / "Logs" / _APP_NAME
    # XDG_STATE_HOME is the correct home for logs; it is newer than the
    # rest of the basedir spec, so the default is spelled out here rather
    # than assumed present in the environment.
    return _xdg_root("XDG_STATE_HOME", ".local/state")


def _cache_root() -> Path:
    """Regenerable artefacts only. Safe to delete at any time."""
    plat = _platform()
    if plat == "win32":
        return _data_root() / "cache"
    if plat == "darwin":
        return _home() / "Library" / "Caches" / _APP_NAME
    return _xdg_root("XDG_CACHE_HOME", ".cache")


def _appdata_base() -> Path:
    """The per-user data root.

    Retained under its original name because callers outside this module
    build their own subdirectories under it (autosave).
    """
    return _data_root()


def logs_dir() -> Path:
    d = _logs_root() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def crashes_dir() -> Path:
    d = _logs_root() / "crashes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def settings_dir() -> Path:
    """The per-user data directory.

    On Windows this also contains the logs, crashes and cache; on Linux
    and macOS those live under their own platform roots, so do not derive
    them from this path. Use :func:`logs_dir`, :func:`crashes_dir` and
    :func:`cache_dir`.
    """
    d = _data_root()
    d.mkdir(parents=True, exist_ok=True)
    return d


def cache_dir(*sub: str) -> Path:
    """Per-user cache root for regenerable artefacts (rendered doc images, ...).

    Distinct from settings/logs/crashes: the contents are a pure cache,
    safe to delete at any time, rebuilt on demand. Optional ``sub`` path
    components are appended and the leaf directory is created.
    """
    d = _cache_root()
    for part in sub:
        d = d / part
    d.mkdir(parents=True, exist_ok=True)
    return d


def describe() -> dict[str, str]:
    """Every resolved root, for the About dialog and problem reports.

    Resolution only; nothing is created, so this is safe to call when
    diagnosing a machine where one of the directories cannot be made.
    """
    return {
        "platform": _platform(),
        "data": str(_data_root()),
        "logs": str(_logs_root() / "logs"),
        "crashes": str(_logs_root() / "crashes"),
        "cache": str(_cache_root()),
    }
