/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 19:58:06
 *  Fs (Hz)      : 16000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe speech_envelope;
probe gated_speech;
VectorProbe noisy_spectrum;
probe noise_floor_2;

input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(16000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__clean_speech = signalSource::multisine(100.0f, 50.0f, 7, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.7f);
  const_ = input("const", 0.0f);
  noise SIM__background_noise = noise(0.0, 0.01, gaussian);
  node noisy_speech = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_3 = expander(3);
  fft_HannWindow windowed_FFT = fft_HannWindow(512);
  envFollower broadband_envelope = envFollower(0.005, 0.05);
  noiseGate residual_gate = noiseGate(0.005, 0.1, -34.0, -80.0);
  fftMagResolver magnitude = fftMagResolver(windowed_FFT);
  minObserver noise_floor = minObserver(65);
  speech_envelope = probe("speech_envelope");
  gated_speech = probe("gated_speech");
  noisy_spectrum = VectorProbe("noisy_spectrum");
  noise_floor_2 = probe("noise_floor");

  /* Connect Blocks */
  SIM__clean_speech > noisy_speech.in(0);
  const_ > SIM__background_noise;
  SIM__background_noise > noisy_speech.in(1);
  noisy_speech > fan_3;
  fan_3.out(0) > windowed_FFT;
  fan_3.out(1) > broadband_envelope;
  fan_3.out(2) > residual_gate;
  windowed_FFT > magnitude;
  broadband_envelope > noise_floor;
  broadband_envelope > speech_envelope;
  residual_gate > gated_speech;
  magnitude >> noisy_spectrum;
  noise_floor > noise_floor_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    speech_envelope.show();
    gated_speech.show();
    noisy_spectrum.show();
    noise_floor_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}