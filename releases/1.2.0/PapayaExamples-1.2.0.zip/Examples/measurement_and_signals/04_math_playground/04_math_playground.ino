/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe x2_out;
probe neg_out;
probe squared_out;
probe abs_out;
probe biased_out;
probe recip_out;
probe sqrt_out;

input bias;
input recip_bias;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  bias = input("bias", 0.25f);
  recip_bias = input("recip_bias", 2.0f);
  signalSource Triangle = signalSource::triangle(5.0f, 0.0f, 0.5f);
  expander fan_6 = expander(6);
  gain x2 = gain(2.0);
  negate neg = negate();
  sqrMath squared = sqrMath();
  absVal abs = absVal();
  node biased = node("[1.0 1.0]", "[1.0]", Sum);
  node recip_bias_sum = node("[1.0 1.0]", "[1.0]", Sum);
  inverse recip = inverse();
  sqrtBlock sqrt = sqrtBlock();
  x2_out = probe("x2");
  neg_out = probe("neg");
  squared_out = probe("squared");
  abs_out = probe("abs");
  biased_out = probe("biased");
  recip_out = probe("recip");
  sqrt_out = probe("sqrt_root");

  /* Connect Blocks */
  bias > biased.in(1);
  recip_bias > recip_bias_sum.in(1);
  Triangle > fan_6;
  fan_6.out(0) > x2;
  fan_6.out(1) > neg;
  fan_6.out(3) > squared;
  fan_6.out(4) > abs;
  fan_6.out(5) > biased.in(0);
  fan_6.out(2) > recip_bias_sum.in(0);
  x2 > x2_out;
  neg > neg_out;
  squared > squared_out;
  abs > sqrt;
  abs > abs_out;
  biased > biased_out;
  recip_bias_sum > recip;
  recip > recip_out;
  sqrt > sqrt_out;

  /* Enable Remote Input Control */
  bias.enableRemote();
  recip_bias.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    x2_out.show();
    neg_out.show();
    squared_out.show();
    abs_out.show();
    biased_out.show();
    recip_out.show();
    sqrt_out.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}