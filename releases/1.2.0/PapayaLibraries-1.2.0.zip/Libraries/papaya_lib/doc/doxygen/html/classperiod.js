var classperiod =
[
    [ "period", "classperiod.html#a3f1951dbf214c3c96690e66da3ef0816", null ]
];