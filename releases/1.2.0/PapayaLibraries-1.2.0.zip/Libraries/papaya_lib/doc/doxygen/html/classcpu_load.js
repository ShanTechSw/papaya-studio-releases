var classcpu_load =
[
    [ "cpuLoad", "classcpu_load.html#a97d21c3244195a501b67e56c36996575", null ]
];