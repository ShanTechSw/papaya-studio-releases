from __future__ import annotations
from enum import IntEnum

class PP_C2dAlgo(IntEnum):
    Tustin = 0
    EulerBackward = 1
    EulerForward = 2
    NoC2dAlgo = 255

class PP_NodeType(IntEnum):
    Sum = 0
    Mul = 1
    NoNodeType = 255

class PP_DesignStatus(IntEnum):
    DesignOk = 0
    MemError = 1
    TfError = 2
    UnknownC2dAlgo = 3
    TextOk = 4
    TxtError = 5
    BadParam = 6
    BadConnection = 7
    BadRequest = 8
    SamplingFreqOutOfLimit = 9
    GPIO_Failure = 10
    TIM_Failure = 11
    ADC_Failure = 12
    DAC_Failure = 13
    COMP_Failure = 14
    DMA_Failure = 15
    OPAMP_Failure = 16
    SPI_Failure = 17
    UART_Failure = 18
    I2C_Failure = 19
    USB_Failure = 20
    UndefinedFailure = 21
    NoDesignStatus = 255

class PP_ComStatus(IntEnum):
    ComOk = 0
    WrongSeqNumber = 1
    WrongCrc = 2
    UnknownComError = 3
    NoComStatus = 255

class PP_FuncId(IntEnum):
    Createblock = 0
    Linkblock = 1
    Manageblock = 2
    NoFuncId = 255

class PP_SubFuncId(IntEnum):
    NewSys = 0
    NewSysLightC = 1
    NewSysLightD = 2
    NewInput = 3
    NewHwInput = 4
    NewHwOutput = 5
    NewNode = 6
    NewFlexNode = 7
    NewMacro = 8
    NewProbe = 9
    NewVectorProbe = 10
    NewSine = 11
    NewTri = 12
    NewSqr = 13
    NewSaw = 14
    NewNoise = 15
    NewSineAm = 16
    NewButterLow = 17
    NewButterHigh = 18
    NewButterBand = 19
    NewButterStop = 20
    NewBiquadButterLow = 21
    NewBiquadButterHigh = 22
    NewBiquadButterBand = 23
    NewBiquadButterStop = 24
    NewChebyshev1Low = 25
    NewChebyshev1High = 26
    NewChebyshev1Band = 27
    NewChebyshev1Stop = 28
    NewBiquadCheby1Low = 29
    NewBiquadCheby1High = 30
    NewBiquadCheby1Band = 31
    NewBiquadCheby1Stop = 32
    NewChebyshev2Low = 33
    NewChebyshev2High = 34
    NewChebyshev2Band = 35
    NewChebyshev2Stop = 36
    NewBiquadCheby2Low = 37
    NewBiquadCheby2High = 38
    NewBiquadCheby2Band = 39
    NewBiquadCheby2Stop = 40
    NewEllipLow = 41
    NewEllipHigh = 42
    NewEllipBand = 43
    NewEllipStop = 44
    NewBiquadEllipLow = 45
    NewBiquadEllipHigh = 46
    NewBiquadEllipBand = 47
    NewBiquadEllipStop = 48
    NewNotch = 49
    NewPeak = 50
    NewAllPass = 51
    NewFirLow = 52
    NewFirHigh = 53
    NewFirBand = 54
    NewFirStop = 55
    NewCustFir = 56
    NewParamEQLow = 57
    NewParamEQHigh = 58
    NewParamEQBand = 59
    NewParamEQPeak = 60
    NewCompressor = 61
    NewDecibelsConverter = 62
    NewCombFeedForward = 63
    NewCombFeedBack = 64
    NewInterpolation = 65
    NewMovingAverage = 66
    NewDelayOp = 67
    NewForwardFFT = 68
    NewForwardFFT_HannWindow = 69
    NewFftResolver = 70
    NewPhaseResolver = 71
    NewDWT = 72
    NewIDWT = 73
    NewAbsMax = 74
    NewAbsMin = 75
    NewEntropy = 76
    NewPower = 77
    NewMean = 78
    NewMaximum = 79
    NewMinimum = 80
    NewRootMeanSquare = 81
    NewStandardDeviation = 82
    NewVariance = 83
    NewPeriodMeter = 84
    NewUpDwnPeriodMeter = 85
    NewMag2 = 86
    NewMag3 = 87
    NewPid = 88
    NewTunePID = 89
    NewTunePI = 90
    NewTunePD = 91
    NewTune2PID = 92

    # Anti-windup controllers. A separate opcode rather than an extra
    # parameter on the four above, because the block behind it is a
    # different thing on the board: the plain PID is a transfer function
    # discretised once at creation, with no integrator state anything
    # could hold, while a controller that limits its own output has to be
    # an explicit parallel form. Keeping them separate is also what makes
    # a design with anti-windup switched off byte-identical on the wire to
    # the same design before this feature existed.
    #
    # There is deliberately no live-PD entry: a PD controller has no
    # integrator and cannot wind up. The number after NewTune2PIDAw is
    # left unallocated rather than given to a block that will never send
    # it.
    NewPidAw = 242
    NewTunePIDAw = 243
    NewTunePIAw = 244
    NewTune2PIDAw = 245
    # Identified model to live PID gains. 246 (0x00F6) is the next free
    # value: 241 is retired twice over (it belonged to NewPercentile, and
    # NewRLSMacro squats on it host-only), and 242-245 are the anti-windup
    # PID family above.
    NewPidFromModel = 246
    NewIntegratorIC = 247  # integrator with an initial condition and a reset
    NewModulo = 248  # floored modulo, the sign of the divisor
    NewComp = 93
    NewSchmidt = 94
    NewSat = 95
    NewDeadZone = 96
    NewBacklashDeadBand = 97
    NewSign = 98
    NewGain = 115
    # Math / DSP
    NewSqrMath = 116
    NewSqrt = 117
    NewSineFunc = 118
    NewCosineFunc = 119
    NewAbsVal = 120
    NewAtan2 = 121
    NewLogFunc = 122
    NewExpFunc = 123
    NewNegate = 124
    NewInverse = 125
    # Control
    NewSwitch = 126
    NewQuantizer = 127
    NewIntegrator = 128
    NewDerivative = 129
    NewRateLimiter = 130
    NewSampleHold = 131
    # Motor control transforms
    NewClarke = 132
    NewInvClarke = 133
    NewPark = 134
    NewInvPark = 135
    # Classical compensators
    NewLeadLag = 136
    NewWashout = 137
    # State-space system
    NewStateSpace = 138
    # Observers
    NewCompFilter = 139
    NewSMO = 140
    # Application-specific EKF blocks
    NewPMSM_EKF = 141
    NewAHRS_EKF = 142
    NewBatterySOC_EKF = 143
    NewTilt_EKF = 144
    NewLoadTorque_EKF = 145
    # New EKF application blocks
    NewThermal_EKF = 146
    NewBaroAlt_EKF = 147
    NewRobotLoc_EKF = 148
    NewSinTrack_EKF = 149
    NewGridSync_EKF = 150
    NewACIM_EKF = 151
    NewBatterySOH_EKF = 152
    NewWMR_EKF = 153
    NewGPSINS_EKF = 154
    # Adaptive control blocks
    NewLMS = 155
    NewAdaptiveNotch = 156
    NewDOB = 157
    NewESC = 158
    NewADRC = 159
    NewMRAC = 160
    NewMRAC_Lyapunov = 161
    NewRepetitiveCtrl = 162
    NewSTR = 163
    NewILC = 164
    # Self-tuning PID blocks
    NewGainSchedulePID = 165
    NewGainScheduler = 166
    NewRelayAutoTune = 167
    NewStepAutoTune = 168
    NewSTR_PID = 169
    NewMRAC_PID = 170
    NewESC_PID = 171
    NewPerfMonitor_PID = 172
    NewFuzzyPID = 173
    # Additional blocks
    NewMomentaryPower = 174
    NewMaxObserver = 175
    NewMinObserver = 176
    NewMux = 177
    NewDemux = 178
    NewLoudness = 179
    NewCpuLoad = 180
    NewExtSensor = 181
    # Audio processing blocks
    NewLimiter = 182
    NewNoiseGate = 183
    NewEnvFollower = 184
    NewADSR = 185
    NewFracDelay = 186
    NewChorus = 187
    NewFlanger = 188
    NewPhaser = 189
    NewReverb = 190
    NewStereoPan = 191
    NewDistortion = 192
    NewBitcrusher = 193
    NewRingMod = 194
    NewPitchDetect = 195
    NewVUMeter = 196
    NewStereoMixer = 197
    # Wavelet-domain processing blocks
    NewDwtDenoise = 198
    NewDwtSubbandGain = 199
    NewDwtSubbandEnergy = 200
    # Unified signal-source engine. One opcode, one engine, one TLV-like
    # parameter list; the shape field steers which sub-fields are consumed
    # downstream; the board decodes the same layout.
    NewSignalSource          = 202
    SetSignalSourceParams    = 203
    SignalSourceManualTrigger = 204
    # ──────────────────────────────────────────────────────────────────────
    # Infrastructure blocks, sub-function ids 0x00D0 - 0x00DF
    # ──────────────────────────────────────────────────────────────────────
    NewQuatMult              = 205   # Hamilton product of two quaternions
    NewWindowFramer          = 206   # Sliding-window framer (ring + hop)
    NewStftFramer            = 207   # STFT framer (windowed ring + hop)
    NewImuBiasEst            = 212   # IMU accel+gyro bias estimator
    NewFeatureStack          = 213   # Variable-K feature vector concatenator
    NewZScoreNorm            = 214   # Welford running z-score normalizer
    NewInnovationChi2        = 215   # Chi-square innovation gate
    NewMadgwickAhrs          = 216   # Madgwick gradient-descent AHRS
    NewMahonyAhrs            = 217   # Mahony complementary AHRS (+ bias)
    NewComplementaryAhrs     = 218   # Simple complementary AHRS
    NewMixerMultirotor       = 219   # Multirotor thrust/torque mixer
    NewLqrServo              = 220   # LQR state-feedback with servo integrator
    # ------------------------------------------------------------------------
    # Motion, biomedical and feature-extraction ids (221-240 = 0xDD-0xF0,
    # plus the quaternion atoms 208-211 = 0xD0-0xD3 below).
    #
    # NOTE (2026-07): these are now FULLY IMPLEMENTED across every layer --
    # Python builders, Model Builder blocks, and the board-side runtime all
    # exist and ship.  The earlier "reserved but NO
    # Python builder / NO firmware body / NO dispatch case yet" note was STALE
    # and has been removed: it wrongly told the sync linter these were free
    # reserved slots, inviting the opcode values to be reused/renumbered.
    # Do NOT reassign these values.
    # ------------------------------------------------------------------------
    NewTrajScurve            = 221   # 7-segment S-curve trajectory generator
    NewTrajTrapezoid         = 222   # trapezoidal-velocity trajectory generator
    NewFrictionStribeck      = 223   # Stribeck friction feedforward
    NewInputShaper           = 224   # ZV/ZVD/EI input shaper
    NewHjorth                = 225   # Hjorth activity/mobility/complexity
    NewEmgEnvelope           = 226   # TKEO + LP EMG envelope
    NewEmgHudgins            = 227   # Hudgins MAV/ZC/SSC/WL
    NewEcgBlRemove           = 228   # ECG baseline remover (morph open)
    NewHrvTime               = 229   # HRV time-domain stats
    NewEegBandpower          = 230   # EEG delta/theta/alpha/beta/gamma bandpower
    NewSkewKurt              = 231   # Welford 3rd/4th moments
    NewPercentile            = 232   # P² streaming percentile
    NewPeakToPeak            = 233   # sliding-window peak-to-peak
    NewCrestFactor           = 234   # peak / RMS
    NewZcr                   = 235   # zero-crossing rate
    NewSpectralFeatures      = 236   # spectral centroid/spread/etc.
    NewCepstrum              = 237   # real cepstrum
    NewAutocorrLags          = 238   # lag-windowed autocorr
    NewPcaProject            = 239   # offline-trained PCA projection
    NewDecisionTree          = 240   # tiny decision-tree inference
    NewQuatFromEuler         = 208   # Euler (roll,pitch,yaw) -> quaternion
    NewQuatToEuler           = 209   # quaternion -> Euler (roll,pitch,yaw)
    NewQuatToRotmat          = 210   # quaternion -> 3x3 rotation matrix
    NewQuatNormConj          = 211   # quaternion normalise / conjugate / inverse
    NewAdaptiveKF = 99
    NewIdealKF = 100
    NewRLS = 101
    NewRRLS = 102
    # The `rls` MACRO's own sub-function id. It used to share NewRLS
    # (101 = 0x65) with the plain RLS block while sending a completely
    # different parameter layout, and for that opcode the board reads its
    # first parameter as an array of floats, so the macro made the board
    # read a uint8 as if it were a pointer to floats. 241 (0xF1) is the
    # first id past the end of the block-creation range (which stops at
    # NewDecisionTree = 240 = 0xF0; Link starts at 0x1000), so it squats
    # on none of the documented reserved sub-ranges. **The board does not
    # implement this id yet**: the
    # board answers "unknown sub-function" and refuses, which is the point:
    # a clean refusal instead of a wild pointer read. See the `rls`
    # docstring in blocks.py.
    #
    # HAZARD, read before adding a block opcode: 241 is HOST-ONLY, and it
    # sits directly on the firmware's next free block-creation id. A new
    # block appended after NewDecisionTree (240) would land on 241 and
    # silently turn this "safely refused" id into a live constructor with
    # a different parameter layout. 241 itself must not move (wire values
    # never move), so the next block id must skip 241 and take 242.
    NewRLSMacro = 241
    NewMerger = 103
    NewExpander = 104
    NewSingleAnIn = 105
    NewListOfAnIn = 106
    NewSinglePwmIn = 107
    NewListOfPwmIn = 108
    NewSinglePwmOut = 109
    NewListOfPwmOut = 110
    NewAccelerometer = 111
    NewGyroscope = 112
    NewMagnetometer = 113
    NewMotor = 114
    NewEncoder = 201
    LinkSys2Sys = 4096
    LinkNode2Node = 4097
    LinkSys2Node = 4098
    LinkIn2Node = 4099
    LinkNode2Probe = 4100
    LinkSys2Probe = 4101
    LinkIn2Sys = 4102
    LinkNode2Sys = 4103
    LinkMacro2Macro = 4104
    LinkMacro2Sys = 4105
    LinkSys2Macro = 4106
    LinkMacro2Node = 4107
    LinkNode2Macro = 4108
    LinkIn2Macro = 4109
    LinkMacro2Probe = 4110
    LinkSys2VectorProbe = 4111
    LinkNode2VectorProbe = 4112
    DesignInit = 8192
    SetInput = 8193
    StopDesign = 8194
    StartMacro = 8195
    StopMacro = 8196
    StartSampling = 8197
    StopSampling = 8198
    EnableRemoteInput = 8199
    SetMonInterface = 8200
    # Design information query
    GetDesignInfo = 0x2009
    # Sampling-mode exit, Manageblock form. DEAD on the wire: the firmware
    # marks 0x200D deprecated and its handler answers BadRequest
    # unconditionally. The disconnect path that actually stops sampling is
    # the one-byte sampling-mode opcode PP_CMD_SWITCH_BACK_TO_CFG, which
    # device.switchToCfg() sends. The value is kept so the numbering
    # never moves.
    SwitchToCfg = 0x200D
    # EEPROM application storage
    EnableStorage = 0x200E
    CommitToEeprom = 0x200F
    AbortStorage = 0x2024
    GetDebugLog = 0x2025
    ClearDebugLog = 0x2026
    # Online-feasibility check: the board builds the design, runs one
    # execution pass under a cycle-accurate timer, and returns a 17-byte
    # data response {cycle_us, usb_overhead_us, total_us, period_us,
    # feasible}.
    MeasureCycleTime = 0x2027
    LoadApp = 0x2010
    DumpApp = 0x2011
    UploadApp = 0x2012
    ListApps = 0x2013
    DeleteApp = 0x2014
    SyncEeprom = 0x2015
    McuReset = 0x2016
    SoftReset = 0x2017
    # Offline monitoring
    SetMonitorMode = 0x2018
    SetTraceSize = 0x2019
    SetLiveRate = 0x201A
    GetCaptureStatus = 0x201B
    DownloadTrace = 0x201C
    # Boot configuration
    SetBootApp = 0x201D
    GetBootCfg = 0x201E
    # Bulk maintenance
    EraseAll = 0x201F
    # Board identity
    GetBoardInfo = 0x2020
    # Monitoring metadata queries
    DescribeVectProbes = 0x2021
    # HMAC-SHA256 challenge-response authentication.  Body: 32-byte
    # nonce.  Response payload: 32-byte HMAC = HMAC-SHA256(PSK,
    # nonce || mcu_unique_id_12bytes).  Required before Papaya Studio will
    # treat the device as a genuine board (see papaya/auth.py and the
    # reference implementation in papaya_lib/papaya_auth_reference.c).
    Authenticate = 0x2022
    # Reboot the board into its firmware-update mode.  In that mode the
    # board enumerates with USB product id 0x15B4 instead of the running
    # application's 0x15B3, so Studio's ordinary Connect path skips it;
    # only the firmware updater looks for both product ids.  The board
    # stays in update mode until a host has finished uploading a new
    # firmware image, and a complete update is TWO images, not one: the
    # board is not back in its application until both have been sent, so
    # an update interrupted after the first leaves it still enumerating
    # as the updater and needing the sequence run again.
    EnterBootloader = 0x2023
    # ---- DC Motor data capture ("Collect DC Motor Data" feature) ----
    StartDcMotorCapture     = 0x2028
    GetDcMotorCaptureStatus = 0x2029
    DownloadDcMotorCapture  = 0x202A
    StopDcMotorCapture      = 0x202B
    GetDcMotorCaptureBoardState = 0x202C
    # 16-byte LE response = {TimerTickCount, MissedTickCount,
    # ScalarDropCount, EdlRunCount}.  Diagnostic for the
    # "live + ANALOG_IN = corrupted, offline + ANALOG_IN = clean"
    # investigation -- D2 confirmation when MissedTickCount grows
    # during the bad design but stays near zero on simulated / offline.
    GetLiveDiagCounters     = 0x202D
    # ---- FreqIn comparator-mode + pin-swap controls (Session 1) ----
    SetFreqInCh2Source       = 0x2030
    SetFreqInSwapPins        = 0x2031
    # Query the board's live-sampling deadline counters, counted since the
    # sampling frequency was last set.  Data response: 8 bytes =
    # {u32 tick_total, u32 missed_total}.  Used at Monitor Start to surface
    # a "board cannot sustain Fs" warning when missed_total > 0.
    GetExtSamplingDeadlineInfo = 0x2032
    # The board builds the design, walks its application heap with padding
    # included, times five execution passes with a cycle-accurate counter,
    # then tears the design down.  32-byte LE
    # response = {u32 cpu_cycle_us, u32 period_us, u32 heap_used_bytes,
    # u32 heap_free_bytes, u32 heap_total_bytes, u32 heap_largest_free,
    # u16 heap_used_blocks, u16 heap_free_blocks, u16 cpu_load_pct_x100,
    # u8 heap_used_pct, u8 reserved}.  Issued right before StartSampling
    # so Studio and generated Python programs can both show the design's
    # actual on-board CPU and memory footprint.
    GetDesignInstrumentation = 0x2033
    # ---- Audio recording slot management (2026-05-20) ----
    # Host-facing storage commands for the RECORDER / REPLAY blocks.
    ListAudioSlots           = 0x2034
    GetAudioSlotInfo         = 0x2035
    EraseAudioSlot           = 0x2036
    EraseAllAudioSlots       = 0x2037
    DownloadAudioSlot        = 0x2038
    UploadAudioSlotStart     = 0x2039
    UploadAudioSlotChunk     = 0x203A
    UploadAudioSlotCommit    = 0x203B
    # ---- DWT live tuning (runtime block-param updates, Manageblock) ----
    # Overwrite a live DWT child block's stored knobs (the runtime routine reads
    # them each frame).  BlockId in the header = target block.
    SetDwtSubbandGains       = 0x203C   # param[0] = gains RealArray (len=J+1, linear)
    SetDwtDenoiseScale       = 0x203D   # param[0] = thresh_scale (Real)
    # ---- Dataset storage slot management (2026-07) ----
    # Multi-slot dataset store in the board's external FLASH: 8 slots x
    # 512 KB in the 4-8 MB region of that flash. STORAGE ONLY: the Signal
    # Source "Dataset" shape that played a slot back is retired
    # (PP_WaveShape.Dataset is refused; a recording travels inside the
    # signalSource create command as an Arbitrary lookup table). These
    # Manageblock opcodes manage the store (BlockId in the header is
    # unused / 0xFFFF, like the audio-slot commands).
    ListDatasets             = 0x2040   # -> u8 count, then 8 x 20B records
    GetDatasetInfo           = 0x2041   # param[0]=u8 slot -> 20B record
    EraseDataset             = 0x2042   # param[0]=u8 slot
    UploadDatasetStart       = 0x2043   # u8 slot, u16 fmt, u32 rate, u32 len, [str name]
    UploadDatasetChunk       = 0x2044   # u8 slot, u32 offset, u8[] segment(s)
    UploadDatasetCommit      = 0x2045   # u8 slot, u32 crc32(zlib), u32 timestamp
    DownloadDataset          = 0x2046   # u8 slot, u32 offset, u32 length -> float32 bytes
    # ---- SPI monitoring batch depth (2026-08-18) ----
    # One u16 parameter: how many samples per probe the board gathers
    # between probe reads on its SPI monitoring wire, 1..128. Accepted
    # only while the monitoring interface is SPI, sampling is stopped and
    # the monitor mode is Live; refused with BadParam out of range and
    # BadRequest otherwise. Acceptance switches every scalar probe read
    # to the headered batch payload ([u32 seq][u16 valid][u16 depth
    # echo] then probes x depth float32, probe-major); a board that
    # never accepted it keeps the bare one-sample payload byte for byte.
    # Old firmware answers BadRequest and never halts, so the refusal IS
    # the capability probe. The interface command resets the depth, so
    # the order is SetMonInterface, then this, then StartSampling.
    # The values between DownloadDataset and here are not free: 0x2050
    # onward is the board-attestation family (issued from papaya.attest,
    # not through this enum), and the gap below it stays a gap. Appended
    # per the wire rule: values never move, nothing is renumbered.
    SetMonBatchDepth         = 0x2060   # u16 depth (1..128)

    # Where the offline trace's two regions are, and how much of each is
    # valid. No params; a fixed 32-byte data response, little-endian:
    #   u8  layout_version (1)     u8  scalar_probe_count
    #   u8  vector_probe_count     u8  flags
    #   u16 scalar_batch_depth     u16 vector_decim_factor
    #   u32 scalar_region_bytes    u32 scalar_valid_bytes
    #   u32 vector_region_bytes    u32 vector_valid_bytes
    #   u32 snapshot_stride_bytes
    #   u16 vector_snapshots_dropped_late
    #   u16 vector_snapshots_dropped_full
    # flags: bit0 complete, bit1 active, bit2 buffer allocated,
    #        bit3 vector region unsized; bits 4-7 reserved, written 0.
    #
    # scalar_region_bytes IS the vector region's base offset in
    # DownloadTrace's address space, which already spans both regions, so
    # there is no second download opcode. The host cannot derive it: the
    # region is sized from the REQUESTED sample count while
    # GetCaptureStatus reports the COMMITTED one, and an early stop makes
    # them differ. vector_decim_factor cannot be derived either.
    #
    # layout_version gates MEANING, flags bits are ADDITIVE: refuse a
    # version you do not know, ignore flag bits you do not know. The
    # 32-byte length is itself a contract with flashed boards, so a
    # future field takes a NEW opcode rather than growing this one -
    # exactly as GetCaptureStatus stays 9 bytes.
    #
    # Firmware that predates it answers BadRequest and keeps working, and
    # that refusal IS the capability probe, as with SetMonBatchDepth.
    #
    # 0x2070, not 0x202E or 0x2061: 0x202E-0x202F and 0x2047-0x204F are
    # the separators after the DC-motor and dataset families, and both
    # 0x2050 and 0x2060 state that a new kind of thing opens a new decade
    # rather than consuming a gap. The offline family's own block
    # 0x2018-0x201C is exhausted; 0x201D is SetBootApp.
    GetOfflineTraceGeometry  = 0x2070   # -> 32-byte geometry record
    NoSubFuncId = 65535

class PP_WaveForm(IntEnum):
    """Shape selector for the ``amOscillator`` block (alias ``wave``).

    These four shapes are wire-encoded as distinct ``PP_SubFuncId`` opcodes
    on Createblock. That's why each entry maps to its own opcode rather
    than to a sequential integer.

    For the unified generator with 17 shapes + run modes + triggering,
    use ``signalSource`` + ``PP_WaveShape`` instead.
    """
    Sine = PP_SubFuncId.NewSine
    Tri = PP_SubFuncId.NewTri
    Sqr = PP_SubFuncId.NewSqr
    Saw = PP_SubFuncId.NewSaw
    NoWaveForm = 65535


class PP_WaveShape(IntEnum):
    """Shape catalogue for the unified ``signalSource`` block.

    Values are wire-stable: never renumber after a release. New shapes
    extend the end of the list. The board uses the value to dispatch to
    the matching per-shape waveform computation.
    """

    # Periodic
    Sine        = 0
    Square      = 1
    Triangle    = 2
    Sawtooth    = 3
    Pulse       = 4   # square with user duty cycle (0..1)
    Sinc        = 5   # periodic sinc / Dirichlet kernel
    Gauspuls    = 6   # Gaussian-modulated sinusoidal pulse, repeating at PRF
    DC          = 7   # constant value (== offset, no time dependence)
    Arbitrary   = 8   # user-uploaded LUT, replayed at `freq`

    # Sweep
    LinearChirp = 9
    LogChirp    = 10

    # Stochastic / structured
    Multisine   = 11
    PRBS        = 12

    # Transient (typically one-shot)
    Step        = 13
    Ramp        = 14
    Impulse     = 15
    PulseTrain  = 16

    # RETIRED wire value, kept so the numbering never moves. Shape 17 named
    # a flash slot and the board played the slot in place; that path is gone
    # (a table read every tick must live in the fast heap, and a slot is not
    # fast memory), so the board refuses shape 17 with BadParam and the
    # library refuses it before it reaches the wire. Play a recording with
    # signalSource.dataset(samples): the samples travel inside the create
    # command as an Arbitrary lookup table. Flash slots remain as plain
    # storage (device.uploadDataset); nothing plays them.
    Dataset     = 17

    NoWaveShape = 65535


class PP_WaveMode(IntEnum):
    """How a signalSource progresses over time.

    - Perpetual: run forever (default for naturally-periodic shapes).
    - RepeatN:   run exactly `n_periods` cycles, then hold the terminal value.
    - OneShot:   convenience alias for ``RepeatN(n_periods=1)``.
    - TrigEdge:  idle until a trigger edge fires; one RepeatN run per trigger.
    - TrigGate:  output runs while the gate input is asserted; holds otherwise.
    """

    Perpetual = 0
    RepeatN   = 1
    OneShot   = 2
    TrigEdge  = 3
    TrigGate  = 4

    NoWaveMode = 255


class PP_WaveTrigPol(IntEnum):
    """Trigger polarity for ``PP_WaveMode.TrigEdge`` / ``TrigGate``.

    Edge modes use Rising/Falling; gate modes use GateHigh/GateLow.
    """

    Rising   = 0
    Falling  = 1
    GateHigh = 2
    GateLow  = 3

    NoWaveTrigPol = 255


class PP_WaveMultisinePhase(IntEnum):
    """Phase scheme for Multisine shape."""
    Schroeder = 0   # default: low crest factor
    Random    = 1   # uniform random in [0, 2pi)
    AllZero   = 2   # all bins in phase (high crest factor, diagnostic only)

    NoWaveMultisinePhase = 255


class PP_AnOutMode(IntEnum):
    """Drive mode of an ``analogOut`` block.

    - InputDriven:        the block has a voltage input; the value is written
                          to the DAC every design cycle (the classic behaviour).
    - PredefinedWaveform: the block has no input; it carries a waveform spec
                          (any of the 17 source-generator shapes) that the
                          board synthesises and plays back autonomously,
                          with no per-cycle CPU cost.
    """
    InputDriven        = 0
    PredefinedWaveform = 1

    NoAnOutMode = 255

class PP_ThresholdType(IntEnum):
    PP_THRESH_HARD = 0
    PP_THRESH_SOFT = 1
    PP_THRESH_GARROTE = 2

class PP_HwId(IntEnum):
    MOTOR1 = 0
    MOTOR2 = 1
    FI1_PULSE = 256
    FI2_PULSE = 257
    FI3_PULSE = 258
    FI4_PULSE = 259
    FI5_PULSE = 260
    FI1_PERIOD = 512
    FI2_PERIOD = 513
    FI3_PERIOD = 514
    FI4_PERIOD = 515
    FI5_PERIOD = 516
    FI1_DELAY = 768
    FI2_DELAY = 769
    FI3_DELAY = 770
    FI4_DELAY = 771
    FI5_DELAY = 772
    FO1 = 1024
    FO2 = 1025
    FO3 = 1026
    FO4 = 1027
    FO5 = 1028
    FO6 = 1029
    FO7 = 1030
    FO8 = 1031
    AO1 = 1280
    AO2 = 1281
    AO3 = 1282
    AO4 = 1283
    AO5 = 1284
    AIN1 = 1536
    AIN2 = 1537
    AIN3 = 1538
    AIN4 = 1539
    AIN5 = 1540
    AIN6 = 1541
    AIN7 = 1542
    AIN8 = 1543
    AIN9 = 1544
    AIN10 = 1545
    # The board prints MIC-L and MIC-R (it printed MIC 1 and MIC 2
    # before 2026-08-21). The wire values are unchanged and must not
    # move: they are a contract with boards already flashed.
    MIC_L = 1792
    MIC_R = 1793
    SPEAKER1 = 2048
    SPEAKER2 = 2049
    # Audio recording slot routines (2026-05-20). RECORDER is a NewHwOutput
    # sink and REPLAY a NewHwInput source; both address the board's single
    # recording flash slot.
    RECORDER_1 = 3072   # 0x0C00
    REPLAY_1 = 3328     # 0x0D00
    IMU_ACC = 2304
    IMU_GYR = 2305
    IMU_MAG = 2306
    SPI1 = 0x0A00
    SPI2 = 0x0A01
    SPI3 = 0x0A02
    SPI4 = 0x0A03
    I2C1 = 0x0A04
    I2C2 = 0x0A05
    I2C3 = 0x0A06
    I2C4 = 0x0A07
    ENC1 = 0x0B00
    ENC2 = 0x0B01
    NoHwRoutine = 65535


class PP_MotorOutput(IntEnum):
    MotorVelocity = 0
    MotorPosition = 1
    MotorCurrent = 2
    NoMotorOutput = 255


class PP_EncoderOutput(IntEnum):
    EncoderVelocity = 0
    EncoderPosition = 1
    NoEncoderOutput = 255

class PP_FilterType(IntEnum):
    passLow = 0
    passHigh = 1
    passBand = 2
    stopBand = 3
    NoFilterType = 255

class PP_FirWindowType(IntEnum):
    # Values are the raw wire codes the board's FIR window selector expects:
    # the value is sent as a Uint32 and used directly to pick the window.
    # hann must be 3, NOT 0: index 0 is Hamming on the board.
    hamming = 0
    blackMan = 1
    rectangular = 2
    hann = 3
    bartlett = 4
    flatTop = 5
    blackManHarris = 6
    kaiser5 = 7
    kaiser8 = 8
    NoFirWindowType = 255

class PP_NoiseType(IntEnum):
    uniform = 0
    gaussian = 1

class PP_Tune(IntEnum):
    PP_LiveTune = 0
    PP_NoLiveTune = 1

class PP_Cheby1Cfg(IntEnum):
    Cheby1Cfg1 = 0
    Cheby1Cfg2 = 1
    Cheby1Cfg3 = 2
    Cheby1Cfg4 = 3
    Cheby1Cfg5 = 4
    NoCheby1Cfg = 255

class PP_Cheby2Cfg(IntEnum):
    Cheby2Cfg1 = 0
    Cheby2Cfg2 = 1
    Cheby2Cfg3 = 2
    Cheby2Cfg4 = 3
    Cheby2Cfg5 = 4
    NoCheby2Cfg = 255

class PP_EllipCfg(IntEnum):
    EllipCfg1 = 0
    EllipCfg2 = 1
    EllipCfg3 = 2
    EllipCfg4 = 3
    NoEllipCfg = 255

class PP_WaveletType(IntEnum):
    """Discrete wavelet families the board's DWT engine supports.

    Values mirror ``PP_WaveletType`` in ``papaya_lib/PAPAYA.h`` and are
    the codes the board expects. DO NOT renumber. Papaya Studio offers
    the same 9 wavelet choices in the block dialog, so picking any of them
    must resolve to a real Python enum value.
    """
    HAAR  = 0   # Haar / DB1  (2 taps)
    DB4   = 1   # Daubechies-4  (8 taps)
    DB6   = 2   # Daubechies-6  (12 taps)
    DB8   = 3   # Daubechies-8  (16 taps)
    DB10  = 4   # Daubechies-10 (20 taps)
    SYM4  = 5   # Symlet-4      (8 taps)
    SYM8  = 6   # Symlet-8      (16 taps)
    COIF2 = 7   # Coiflet-2     (12 taps)
    COIF4 = 8   # Coiflet-4     (24 taps)
    NoWaveletType = 255

class PP_MonInterface(IntEnum):
    MonitoringOverUsb = 0
    MonitoringOverSpi = 1
    NoMonInterface = 255

class PP_MonitorMode(IntEnum):
    Live = 0
    Offline = 1
    Dual = 2
    NoMonitorMode = 255

class PP_SensorPartNumber(IntEnum):
    """The external sensor parts the board can read directly."""
    SENSOR_NONE = 0
    # Accelerometers
    LIS3DH = 1
    ADXL345 = 2
    ADXL362 = 3
    BMA400 = 4
    LIS2DW12 = 5
    # 6-axis IMU
    MPU6050 = 6
    LSM6DSO = 7
    BMI270 = 8
    ICM42688P = 9
    ISM330DHCX = 10
    LSM6DSV16X = 11
    # 9-axis IMU
    MPU9250 = 12
    ICM20948 = 13
    LSM9DS1 = 14
    # Magnetometers
    BMM150 = 15
    MMC5983MA = 16
    LIS3MDL = 17
    # Environmental
    BME280 = 18
    BMP280 = 19
    BME680 = 20
    BMP390 = 21
    LPS22HH = 22
    DPS310 = 23
    MS5611 = 24
    HTS221 = 25
    # Biomedical (SPI)
    MAX86141 = 26
    MAX30001 = 27
    ADS1292R = 28
    ADS1298R = 29
    ADS1299 = 30
    AFE4900 = 31
    # External ADC (SPI)
    MCP3008 = 32
    MCP3208 = 33
    ADS1220 = 34
    ADS131M08 = 35
    # External DAC (SPI)
    DAC8552 = 36
    MCP4922 = 37
    # Biomedical (I2C)
    MAX30102 = 38
    MAX30105 = 39
    MAX86150 = 40
    AFE4404 = 41
    # Temperature (I2C)
    TMP117 = 42
    MCP9808 = 43
    # Humidity + Temperature (I2C)
    SHT40 = 44
    SHT31 = 45
    HDC1080 = 46
    SI7021 = 47
    # External ADC (I2C)
    ADS1115 = 48
    NAU7802 = 49
    # External DAC (I2C)
    MCP4725 = 50
    MCP4728 = 51
    AD5693R = 52


# How many channels each sensor part exposes is metadata Papaya Studio
# carries in its own block catalogue, not here. The duplicated dict this
# comment replaces was never imported and could silently drift out of sync
# with that catalogue.


class PP_FuncParamId(IntEnum):
    TYPE_String = 0
    TYPE_RealArray = 1
    TYPE_Uint32Array = 2
    TYPE_Uint16Array = 3
    TYPE_Uint8Array = 4
    TYPE_Uint32 = 5
    TYPE_Real = 6
    TYPE_Uint16 = 7
    TYPE_Uint8 = 8
    TYPE_NoType = 255
