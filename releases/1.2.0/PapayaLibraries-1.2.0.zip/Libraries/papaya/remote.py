"""Attach to a diagram the board is already carrying.

Interaction code is host-side code that works *with* a design while the
board runs it: read what the design measures, decide something, write
values back. This module is the whole surface it needs.

Why it exists
-------------
Interaction code used to be written by copying the generated diagram
program and adding a loop to it. That coupled two things that have no
reason to be coupled. The diagram is authored in the Model Builder and
deployed to the board; the interaction script is the user's own
application. Making the script rebuild the diagram meant:

* the script broke whenever the diagram changed, because it carried a
  stale copy of it;
* the reader had to understand the whole diagram to find the three lines
  that were actually theirs;
* and (the part that made it unworkable) the live read APIs derive the
  probe count from probe objects the script created **locally**. A script
  that did not rebuild the diagram had zero of them and could read
  nothing at all.

The board already knows everything needed. It reports its sampling rate,
its remote-writable inputs and its probes, all by name and in the order
their values appear on the wire. So a script can attach to whatever is
loaded, ask what is there, and work with it by name, knowing nothing
about how the diagram was built.

Typical use::

    from papaya.remote import attach

    with attach() as design:
        print(design.probe_names)   # what this diagram measures
        print(design.input_names)   # what it lets you drive

        design.start()
        for _ in range(200):
            values = design.read()               # {name: value}
            if values["temperature"] > 40.0:
                design.write("fan_speed", 1.0)   # by name
        design.stop()

Nothing above mentions a block, a wire, or a sampling frequency the
script had to know in advance.
"""

from __future__ import annotations

import struct
import time
from typing import Dict, List, Optional

from .constants import PP_FIXED_SIZE, PP_REAL_SIZE
from .context import CTX
from .enums import (
    PP_ComStatus, PP_DesignStatus, PP_FuncId, PP_MonInterface, PP_SubFuncId,
)

#: The board's design-info payload is text and its length is not carried
#: in the response, so the read asks for the firmware's whole buffer.
#: Reading MORE than was sent is harmless (the transfer ends on its own);
#: reading less strands the remainder and desynchronises the link.
_DESIGN_INFO_MAX_BYTES = 1024


class RemoteDesignError(RuntimeError):
    """Raised when the board cannot be reached or has no usable design."""


def _parse_design_info(text: str) -> Dict[str, object]:
    """Split the board's design-info string into its four groups.

    Wire shape of the design-info text the board returns::

        {Fs,samplesPerProbe},{input labels},{input values},{probe labels}

    Empty groups are normal: a diagram with no remote inputs reports
    ``{}`` for both input groups, and that is a design you can read from
    but not drive, which the caller should be able to discover rather
    than crash on.
    """
    groups: List[str] = []
    depth = 0
    current: List[str] = []
    for ch in text:
        if ch == "{":
            depth += 1
            if depth == 1:
                current = []
                continue
        elif ch == "}":
            depth -= 1
            if depth == 0:
                groups.append("".join(current))
                continue
        if depth >= 1:
            current.append(ch)

    if len(groups) < 4:
        raise RemoteDesignError(
            f"the board's design description was not understood: {text!r}"
        )

    header = [p for p in groups[0].split(",") if p != ""]
    try:
        fs = float(header[0]) if header else 0.0
        samples_per_probe = int(header[1]) if len(header) > 1 else 0
    except ValueError as exc:
        raise RemoteDesignError(f"bad sampling header {groups[0]!r}") from exc

    def _names(raw: str) -> List[str]:
        return [n.strip() for n in raw.split(",") if n.strip() != ""]

    values: List[float] = []
    for part in groups[2].split(","):
        part = part.strip()
        if not part:
            continue
        try:
            values.append(float(part))
        except ValueError:
            values.append(0.0)

    return {
        "fs": fs,
        "samples_per_probe": samples_per_probe,
        "input_names": _names(groups[1]),
        "input_values": values,
        "probe_names": _names(groups[3]),
    }


def _return_to_cfg(transport) -> bool:
    """Bring the link out of data-exchange mode and drain what is queued.

    Both ends of a session need this -- :func:`attach` before it asks the
    board anything, and :meth:`RemoteDesign.stop` before it sends the
    StopSampling that ends the run -- so it lives in one place.

    Two things have to happen and the order matters. The 0x03 opcode
    (SWITCH_BACK_TO_CFG) is the only way out of data-exchange mode: while
    data exchange is running, the board routes inbound USB bytes through a
    path that parses ONLY the 1-byte opcodes, so an 18-byte config header
    is not a command there at all. And the opcode alone does not do it: an
    auto-push IN transfer the host stopped consuming stalls the device USB
    stack so it no longer services OUT, and a 0x03 sent blind is never
    received. force_to_cfg_mode drains IN first, sends, repeats in case a
    fresh batch re-armed IN in between, and verifies with is_streaming()
    rather than assuming.

    Returns False if the board is still streaming afterwards, which on
    this host means a physical replug: dev.reset() raises "Access denied".
    """
    forcer = getattr(transport, "force_to_cfg_mode", None)
    if forcer is None:
        return True
    ok = bool(forcer())
    # Match the board's counter, in lockstep.
    #
    # The board zeroes its own sequence counter when 0x03 returns it to
    # configuration mode. device.switchToCfg() mirrors that on the host, but
    # force_to_cfg_mode writes the opcode straight to the transport and
    # never goes through it, so the host counter is left wherever it was.
    # In a fresh process that is 0 and the bug hides completely; from a
    # process that has already sent a config command it is not, and every
    # frame after this bounces on a sequence mismatch.
    CTX.sequence_number = 0
    CTX.data_exchange_started = False
    return ok


class RemoteDesign:
    """A diagram running on the board, addressed by name.

    Obtained from :func:`attach`. Every value is discovered from the
    board; this object never assumes what the diagram contains.
    """

    def __init__(self, device, info: Dict[str, object]) -> None:
        self._device = device
        self.fs: float = float(info["fs"])                       # type: ignore[arg-type]
        self.samples_per_probe: int = int(info["samples_per_probe"])  # type: ignore[arg-type]
        self.input_names: List[str] = list(info["input_names"])  # type: ignore[arg-type]
        self.probe_names: List[str] = list(info["probe_names"])  # type: ignore[arg-type]
        #: Values the inputs held when the design was described.
        self.input_values: List[float] = list(info["input_values"])  # type: ignore[arg-type]
        self._running = False
        self._index_of_input = {n: i for i, n in enumerate(self.input_names)}
        # A NAME THAT APPEARS TWICE CANNOT ADDRESS EITHER INPUT.
        #
        # The dict above keeps the LAST index for a repeated name, so a
        # write by that name reaches one input and leaves the others
        # unreachable with nothing said. That is a real corpus case:
        # 66_redundant_sensor_voting labels three inputs 'rail_hi' and
        # three 'dev_thr', and four of its ten inputs could not be
        # written by name at all.
        #
        # Kept as a set rather than refused here, because reading, the
        # positional write and everything else about the design are fine.
        # Only the ambiguous write is refused; see write_many.
        _seen = {}
        for _n in self.input_names:
            _seen[_n] = _seen.get(_n, 0) + 1
        self._ambiguous_inputs = {n for n, c in _seen.items() if c > 1}
        self._pending = bytearray(max(1, len(self.input_names)) * PP_REAL_SIZE)
        for i, v in enumerate(self.input_values[: len(self.input_names)]):
            struct.pack_into("<f", self._pending, i * PP_REAL_SIZE, float(v))

    # -- description ---------------------------------------------------
    def describe(self) -> str:
        """A one-look summary of what this design offers."""
        ins = ", ".join(self.input_names) or "(none)"
        outs = ", ".join(self.probe_names) or "(none)"
        return (
            f"Design on the board: {self.fs:g} Hz\n"
            f"  inputs you can write : {ins}\n"
            f"  probes you can read  : {outs}"
        )

    # -- session -------------------------------------------------------
    def start(self) -> None:
        """Begin streaming so :meth:`read` has something to return.

        Re-arms the monitoring interface first, and that is not
        belt-and-braces. Getting here meant leaving data-exchange mode,
        and when the board returns from data exchange to configuration it
        deliberately un-assigns the monitoring interface, so the auto-push
        stops at once and the next session can claim the interface. The
        design survives and StartSampling still answers
        DesignOk, but with no interface assigned the board pushes nothing
        and every read times out. Measured: reads returned empty forever
        against a design that was demonstrably running.
        """
        self._device.setMonitoringInterface(PP_MonInterface.MonitoringOverUsb)
        self._device.startSampling()
        self._running = True

    def stop(self) -> None:
        """Stop streaming and hand the board back.

        Leaves data-exchange mode the same way :func:`attach` enters it,
        and for the same reason. ``device.stopSampling()`` does send the
        0x03 opcode first, but sending it is not enough on its own: the
        bulk-IN endpoint is still full of queued probe batches, so the
        StopSampling response that follows arrives behind them and the
        host times out waiting for it. That leaves the link mid-frame,
        and the NEXT process to attach finds a board that answers
        nothing -- which is how a clean-looking teardown wedged the board
        twice, one run later and with no visible connection to the cause.
        """
        if self._running:
            _return_to_cfg(CTX.usb_transport)
            self._device.stopSampling()
            self._running = False

    # -- reading -------------------------------------------------------
    def read(self, timeout_ms: int = 250) -> Dict[str, float]:
        """Newest value of every probe, keyed by name.

        Discards any backlog and returns the most recent batch: in a loop
        that acts on what it reads, stale data is a stability hazard, and
        reading the oldest queued batch is how a slow loop silently falls
        further behind on every pass.

        Returns an empty dict when no batch arrived before *timeout_ms*.
        """
        values = self.read_values(timeout_ms=timeout_ms)
        if not values:
            return {}
        return dict(zip(self.probe_names, values))

    def read_values(self, timeout_ms: int = 250) -> List[float]:
        """Same as :meth:`read` but positional, in probe order."""
        if not self._running:
            raise RemoteDesignError("read() needs the design to be started")
        n = len(self.probe_names)
        if n == 0:
            return []
        transport = CTX.usb_transport
        if transport is None:
            raise RemoteDesignError("the link is not open")

        getter = getattr(transport, "poll_probe_batch_latest", None)
        if getter is not None:
            batch = getter(n, timeout_ms)
            if batch is None or len(batch.values) < n * PP_REAL_SIZE:
                return []
            raw = bytes(batch.values[: n * PP_REAL_SIZE])
        else:
            payload = transport.poll_probes(n, timeout_ms)
            if payload is None or len(payload) < n * PP_REAL_SIZE:
                return []
            raw = bytes(payload[: n * PP_REAL_SIZE])
        return list(struct.unpack_from(f"<{n}f", raw, 0))

    # -- writing -------------------------------------------------------
    def write(self, name: str, value: float) -> bool:
        """Set one remote input by name and push it to the board."""
        return self.write_many({name: value})

    def write_many(self, values: Dict[str, float]) -> bool:
        """Set several inputs and push them in ONE transfer.

        One transfer matters: written separately, the board would act on
        a half-updated set between them, which for anything coordinated
        (a pair of motor speeds, a setpoint and its feed-forward) is a
        transient the design never should have seen.
        """
        if not self.input_names:
            raise RemoteDesignError(
                "this design has no remote-writable inputs: nothing to write to"
            )
        for name, value in values.items():
            if name in getattr(self, "_ambiguous_inputs", ()):  # noqa: SIM118
                raise RemoteDesignError(
                    f"{name!r} is the label of "
                    f"{self.input_names.count(name)} different inputs in "
                    f"this design, so writing it by name would reach one of "
                    f"them and silently leave the rest. Give each input its "
                    f"own label in the Model Builder and deploy again."
                )
            idx = self._index_of_input.get(name)
            if idx is None:
                raise RemoteDesignError(
                    f"no remote input named {name!r}; this design offers: "
                    + ", ".join(self.input_names)
                )
            struct.pack_into("<f", self._pending, idx * PP_REAL_SIZE, float(value))

        transport = CTX.usb_transport
        if transport is None:
            raise RemoteDesignError("the link is not open")
        payload = bytes(self._pending[: len(self.input_names) * PP_REAL_SIZE])
        sender = getattr(transport, "send_inputs", None)
        if sender is None:
            raise RemoteDesignError("this transport cannot write inputs")
        return bool(sender(payload))

    # -- lifecycle -----------------------------------------------------
    def close(self) -> None:
        self.stop()
        try:
            from .usb_transport import disconnect_usb
            disconnect_usb()
        except Exception:
            pass

    def __enter__(self) -> "RemoteDesign":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()


def _read_design_info(device) -> str:
    """Ask the board to describe its design; return the raw text."""
    cmd = CTX.prepare_cmd_header(
        PP_FIXED_SIZE, PP_FuncId.Manageblock, 0,
        PP_SubFuncId.GetDesignInfo, 0xFFFF,
    )
    CTX.handle_cmd(cmd, PP_FIXED_SIZE)
    # BOTH statuses matter, and the com one first. A command that never
    # got a response leaves the design status at whatever it already was
    # -- so checking only that reports "the board is fine, it just sent no
    # payload", which points the reader at the payload rather than at the
    # dead link that actually caused it.
    if CTX.current_com_status != PP_ComStatus.ComOk:
        raise RemoteDesignError(
            "the board did not answer. It may be busy streaming from an "
            "earlier run, or wedged: stop any running design and try again."
        )
    if CTX.current_design_status != PP_DesignStatus.DesignOk:
        raise RemoteDesignError(
            f"the board refused to describe its design "
            f"(status {CTX.current_design_status})"
        )

    transport = CTX.usb_transport
    reader = getattr(transport, "read_data_response", None)
    if reader is None:
        raise RemoteDesignError("this transport cannot read the board's reply")
    # exact=False: the description's length is not on the wire, so
    # _DESIGN_INFO_MAX_BYTES is only a ceiling. Waiting for exactly
    # that many bytes would time out on every real design.
    raw = reader(_DESIGN_INFO_MAX_BYTES, timeout_ms=2000, exact=False)
    if not raw:
        raise RemoteDesignError("the board sent no description")
    return raw.split(b"\x00", 1)[0].decode("utf-8", "replace")


def attach(board_id: int = 0, *, connect: bool = True,
           source: str = "auto", design: Optional[str] = None) -> RemoteDesign:
    """Connect to the board and describe whatever design it is carrying.

    Call this BEFORE starting the design streaming. Asking the board to
    describe itself returns a data payload, and reading one while the
    board is pushing probe batches puts both on the same pipe: they
    contend, and that can wedge the link. Discovery happens first,
    streaming second, which is the order :meth:`RemoteDesign.start`
    enforces anyway.

    The board is NOT reset. A reset would discard the very design this
    script exists to work with.

    :raises RemoteDesignError: if no board answers, or it has no design.

    **Running with no board.** PAPAYA Studio can run the design on the
    computer instead and let this attach to that: open the program in the
    Source Editor and set **Run on** to **Simulation**. The program is not
    changed, in either language, because what answers is a simulated board
    speaking the board's own link.

    ``source="board"`` insists on hardware, which is what a script that must
    never quietly run against a model should say.

    A PAPAYA Studio source tree additionally lets a script ask for a
    simulation directly, with ``source="sim"`` and a ``.pap`` path in
    ``design`` or in ``PAPAYA_SIM_DESIGN``. That needs the simulation engine
    importable by the interpreter running the script, which an installed copy
    of this library does not have; there, the request is refused with a
    sentence rather than an import error, and the Source Editor route above
    is the one to use.
    """
    if source not in ("auto", "board", "sim"):
        raise RemoteDesignError(
            f"source must be 'auto', 'board' or 'sim', not {source!r}.")
    if source != "board":
        # THE COPY YOU HOLD MAY NOT BE ABLE TO DO THIS, and that is not a
        # failure to hide behind an ImportError on line one. Running a
        # design on the computer needs the simulation engine, which ships
        # with PAPAYA Studio and not with this library. Where it is
        # absent, ``source="auto"`` (the default, and what every example
        # uses) falls through to the board exactly as it does when no
        # simulation was asked for; a request that cannot be honoured
        # gets a sentence that says what to do instead.
        try:
            from .sim_link import attach_simulation, simulation_requested
        except ImportError:
            asked = bool(design) or bool(
                __import__("os").environ.get("PAPAYA_SIM_DESIGN", "").strip())
            if source == "sim" or asked:
                raise RemoteDesignError(
                    "this copy of the papaya library attaches to a board. "
                    "To run a design on the computer instead, open the "
                    "program in PAPAYA Studio and set Run on to Simulation "
                    "in the Source Editor."
                ) from None
            attach_simulation = simulation_requested = None      # noqa: F841
        wanted = (design or simulation_requested()) if simulation_requested \
            else None
        if wanted:
            import os as _os
            raw = _os.environ.get("PAPAYA_SIM_SPEED", "") or "1.0"
            try:
                speed = float(raw)
            except ValueError:
                # A mistyped environment variable is a user error, and it must
                # arrive as the error type every other failure of this call
                # uses rather than a bare ValueError from the parse.
                raise RemoteDesignError(
                    f"PAPAYA_SIM_SPEED must be a number, not {raw!r}.") from None
            return attach_simulation(wanted, speed=speed)
        if source == "sim":
            raise RemoteDesignError(
                "source='sim' needs a design: pass design='<path>.pap' or set "
                "PAPAYA_SIM_DESIGN.")

    if connect:
        from .usb_transport import connect_usb
        # The PAPAYA constructor hard-resets the MCU when a transport is
        # already open. That is right for a script that is about to build
        # a design and wrong for one attaching to a design that already
        # exists, so it is turned off before the device is created.
        CTX.usb_auto_hard_reset = False
        if not connect_usb():
            raise RemoteDesignError(
                "no PAPAYA board answered. Check it is plugged in and powered, "
                "then try again."
            )

    from .device import PAPAYA
    device = PAPAYA(int(board_id))

    # Leave data-exchange mode FIRST, unconditionally.
    #
    # Every diagram PAPAYA Studio deploys ends with startSampling(), so by
    # the time interaction code runs the board is already streaming. That
    # is the normal case, not an edge case, and it changes what the wire
    # accepts: while data exchange is running, the board routes inbound USB
    # bytes through a path that understands ONLY the 1-byte
    # opcodes -- WRITE, READ, READ_VECT_PROBE, SWITCH_BACK_TO_CFG and
    # FLOW_CREDIT. An 18-byte config header is not a command there at all,
    # so GetDesignInfo does not fail: it is never parsed, nothing answers,
    # and the link is left mid-frame. Measured, twice, each time needing a
    # physical replug.
    #
    # Unconditional because asking the board whether it is sampling is
    # itself a config round-trip -- the exact thing that is unsafe. 0x03
    # to a board already in config mode is harmless.
    #
    # See _return_to_cfg for why the opcode alone is not enough and why
    # the sequence counters have to move together.
    if not _return_to_cfg(CTX.usb_transport):
        raise RemoteDesignError(
            "the board is still streaming and would not return to config "
            "mode. Its USB link is wedged; unplug it and plug it back in, "
            "then run this again."
        )

    info = _parse_design_info(_read_design_info(device))
    if not info["probe_names"] and not info["input_names"]:
        raise RemoteDesignError(
            "the board is not carrying a design with any probes or remote "
            "inputs. Deploy a diagram from PAPAYA Studio first. Interaction "
            "code works with a design, it does not create one."
        )
    return RemoteDesign(device, info)


__all__ = ["attach", "RemoteDesign", "RemoteDesignError"]
