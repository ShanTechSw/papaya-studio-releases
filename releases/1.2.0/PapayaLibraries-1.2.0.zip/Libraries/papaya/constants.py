from __future__ import annotations

# ---------------------------------------------------------------------------
# Low-level protocol constants
# ---------------------------------------------------------------------------

# Command direction opcodes (match C++ PP_CMD_WRITE/READ/…)
PP_CMD_WRITE = 0x00
PP_CMD_READ = 0x01
PP_CMD_READ_VECT_PROBE = 0x02
PP_CMD_SWITCH_BACK_TO_CFG = 0x03
PP_CMD_FLOW_CREDIT = 0x04  # V2: host grants TX credits

# V2 Protocol constants
PP_V2_HANDSHAKE_MAGIC = 0x5041       # "PA"
PP_V2_BATCH_MAGIC = 0x44455347       # "DESG"
PP_V2_PROTOCOL_VERSION = 0x02

# Version of the BLOCK OPCODE TABLE this host speaks.  Distinct from
# PP_V2_PROTOCOL_VERSION: that versions how a frame is PACKED, this versions
# what the sub-function numbers inside it MEAN.  Renumbering the block opcodes
# does not change the framing, so the framing version cannot detect it.
#
# Must equal the block-ABI version the board was built with.  Bump both
# together whenever an opcode is removed, inserted in the middle, or otherwise
# changes meaning.  Appending after the last opcode does not need a bump.
#
#   1 = original numbering, with the gaps and the duplicate PassAll opcode
#   2 = SOLAR_MPPT_EKF and the duplicate PassAll removed, opcodes contiguous
BLOCK_ABI_VERSION = 0x0002

# What a board reports when it predates the field.  GetBoardInfo returned a
# 14-byte record before the version was appended; a short reply therefore means
# "older than ABI 2" rather than "unknown", which is why the check is on the
# response LENGTH and never on the part number.
LEGACY_BLOCK_ABI_VERSION = 0x0001

BLOCK_ABI_MISMATCH_MESSAGE = (
    "This board's firmware does not match this version of PAPAYA Studio.\n\n"
    "The two disagree about what the block command numbers mean, so deploying "
    "would build the wrong blocks on the board, or stop it responding until it "
    "is reset. Nothing has been sent to the board.\n\n"
    "Flash the firmware that shipped with this Studio, then try again."
)
PP_V2_HANDSHAKE_SIZE = 8
PP_V2_BATCH_HEADER_SIZE = 14
PP_V2_BATCH_RESPONSE_SIZE = 13

PP_NODE_ID_BASE = 0x1000
PP_SYS_ID_BASE = 0x2000
PP_MACRO_ID_BASE = 0x3000
PP_INPUT_ID_BASE = 0x4000
PP_PROBE_ID_BASE = 0x5000
PP_VECTOR_PROBE_ID_BASE = 0x6000

PP_INT_SIZE = 4
PP_REAL_SIZE = 4
PP_UINT8_SIZE = 1
PP_UINT16_SIZE = 2
PP_UINT32_SIZE = 4

PP_PARAM_DESC_SIZE = PP_UINT16_SIZE
PP_PARAM_DESC_ID_SHIFT = 12
PP_PARAM_DESC_ID_MASK = 0xF000
PP_PARAM_DESC_SIZE_MASK = 0x0FFF
PP_PARAM_DESC_MAX_ID = 0x0F
PP_PARAM_DESC_MAX_SIZE = PP_PARAM_DESC_SIZE_MASK
PP_PARAM_ID_SIZE = 0
PP_PARAM_SIZE_SIZE = PP_PARAM_DESC_SIZE
PP_PARAM_INFO_SIZE = PP_PARAM_DESC_SIZE

PP_ELLIP_CFG_SIZE = PP_UINT8_SIZE
PP_CHEBYX_CFG_SIZE = PP_UINT8_SIZE
PP_C2D_ALGO_SIZE = PP_UINT8_SIZE
PP_NODE_TYPE_SIZE = PP_UINT8_SIZE
PP_DESIGN_STATUS_SIZE = PP_UINT8_SIZE
PP_COM_STATUS_SIZE = PP_UINT8_SIZE
PP_HW_ROUTINE_ID_SIZE = PP_UINT16_SIZE
PP_WAVE_FORM_SIZE = PP_UINT16_SIZE
PP_SPECIAL_SYS_FUNC_SIZE = PP_UINT16_SIZE
PP_ONE_BAND_FILTER_SIZE = PP_UINT32_SIZE
PP_TWO_BANDS_FILTER_SIZE = PP_UINT32_SIZE
PP_SPECIAL_FILTER_SIZE = PP_UINT16_SIZE
PP_MON_INTERFACE_SIZE = PP_UINT8_SIZE
PP_FUNC_PARAM_ID_SIZE = PP_UINT8_SIZE
PP_blockID_SIZE = PP_UINT16_SIZE
PP_BAUDRATE_SIZE = PP_UINT32_SIZE

PP_FUNC_PARAM_MAX_NBR = 20
PP_MAX_PROBES_NUMBER = 16
PP_MAX_INPUTS_NUMBER = 16
PP_MAX_VECTOR_PROBES_NUMBER = 9

# How many characters of a probe or input label actually survive to the
# board. The label slots are 16 bytes each and the board stores a label by
# copying at most (slot - 1) characters and then forcing a terminator, so
# 15 is the real limit and the 16th character onwards is DISCARDED, not
# rejected: a longer label is accepted by every layer and then reported
# back shortened.
#
# That silence is the whole reason this constant exists. A design naming a
# probe "cart_position_mm" deploys clean, runs, and reports its probe as
# "cart_position_m", so a panel or a script asking for the name it wrote
# matches nothing and reads an empty dict for ever. It looks exactly like a
# dead probe. Worse, two labels sharing their first 15 characters collide
# into ONE name on the board while remaining distinct in the design, which
# the duplicate-label check cannot see.
PP_MON_LABEL_SLOT_BYTES = 16
PP_MON_LABEL_MAX_CHARS = PP_MON_LABEL_SLOT_BYTES - 1

# THERE IS NO PROBE BUDGET KEYED ON THE SAMPLING FREQUENCY.
#
# A PROBE_TIERS table used to live here (16 probes up to 5 kHz, 8 up to
# 20 kHz, 4 above that) and three gates read it: connection validation,
# design validation and the sim-forms attach toggle. The owner removed it
# on 2026-08-24, for the whole product and for good.
#
# It was described as mirroring the board's monitor tiering. It does not:
# the firmware has no rule pairing probe count with sampling rate
# anywhere. Its only probe bound is a fixed 16, the length of the
# statically allocated probe and label arrays it samples into, and that
# is the same number at every sampling rate. The tiers were an estimate
# of how much the board could
# keep up with, enforced as if it were a hardware fact, and it refused
# designs the hardware has no objection to.
#
# The absolute limits below stay, because those ARE the firmware's
# arrays. What used to be prevented is now reported instead: the board's
# own instrumentation returns the CPU load per sampling period, so a
# design that genuinely asks for too much says so with a measurement of
# itself rather than being refused a wire on a guess.
# Per-probe payload ceiling: the board refuses a vector probe that would
# push more than this in one batch. Sized to fit FFT(256) (1024 B) and
# FFT_MAG of FFT(256) (516 B) in the default Studio wiring.
PP_MAX_VECTOR_PROBES_BYTES = 8192

# Command byte layout indices
PP_CMD_SEQ_NUMBER_IDX = 0x00
PP_CMD_READ_WRITE_IDX = 0x02
PP_CMD_SIZEL_IDX = 0x03
PP_CMD_SIZEH_IDX = 0x04
PP_CMD_blockIDL_IDX = 0x05
PP_CMD_blockIDH_IDX = 0x06
PP_CMD_FUNC_ID_IDX = 0x07
PP_CMD_SUB_FUNC_IDL_IDX = 0x08
PP_CMD_SUB_FUNC_IDH_IDX = 0x09
PP_CMD_NBR_OF_PARAMS_IDX = 0x0A
PP_CMD_NBR_OF_CHUNKS_IDX = 0x0B
PP_CMD_LAST_CHUNK_SIZEL_IDX = 0x0C
PP_CMD_LAST_CHUNK_SIZEH_IDX = 0x0D
PP_CMD_BODY_START_IDX = 0x00
PP_CMD_HEADER_CRC_IDX = 0x0E

PP_CMD_HEADER_SIZE = 0x12
PP_CMD_CRC_SIZE = 0x04
PP_CMD_CHUNK_SIZE = 400
PP_CHUNK_MAX_SIZE = PP_CMD_CHUNK_SIZE  # alias
PP_CMD_BODY_MAX_SIZE = PP_CMD_CHUNK_SIZE
# Hard cap on the wire-level ``DataSize`` field (body bytes + CRC trailer).
# The wire header carries ``DataSize`` as a u16, so 65535 is the absolute
# protocol ceiling.  The board's own command buffer is 65536 bytes, so it
# accepts anything the wire can carry.  History: 4000 -> 65535
# (2026-05-02, full u16 range).
PP_CMD_BODY_HARD_MAX_SIZE = 65535

PP_RESPONSE_REQ_CRC_IDX = 0x05
PP_RESPONSE_REQ_SIZE = 0x09
PP_RESPONSE_SIZE = 0x07
PP_RESPONSE_POLL_INTERVAL_MS = 2
PP_RESPONSE_TIMEOUT_MS = 1000
PP_USB_RESPONSE_TIMEOUT_MS = PP_RESPONSE_TIMEOUT_MS  # alias
PP_VECTOR_PROBE_REQUEST_DELAY_MS = 2  # C++: static constexpr uint16_t PP_VECTOR_PROBE_REQUEST_DELAY_MS = 2u;

# Buffer size for the Python flat serializer.  The wire DataSize already
# counts the body+CRC trailer (i.e. PP_CMD_BODY_HARD_MAX_SIZE is itself
# the body+CRC limit), so the +CRC margin here is purely defensive
# headroom for any CRC-suffix double-count in the serializer path.  The
# C++ master uses a 400-byte buffer because it streams chunk-by-chunk;
# Python serializes the entire body at once so the buffer must be larger.
PP_CMD_MAX_SIZE = PP_CMD_BODY_HARD_MAX_SIZE + PP_CMD_CRC_SIZE

# Response byte indices
PP_RES_SEQ_NUMBER_IDX = 0x00
PP_RES_RESCODE_IDX = 0x02
PP_RES_CRC_IDX = 0x03

# Special size IDs used on the wire
PP_CMD_RESPONSE_ID = 0xFFFF

# Fixed body size when there are zero params
PP_FIXED_SIZE = PP_CMD_CRC_SIZE

# EEPROM Application Storage
PP_EEP_MAX_APPS = 16
PP_EEP_APP_LABEL_MAX_SIZE = 128
