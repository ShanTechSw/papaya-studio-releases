var classmomentary_power =
[
    [ "momentaryPower", "classmomentary_power.html#aa0d804a1b2050941598f49c71ff5dfb5", null ]
];