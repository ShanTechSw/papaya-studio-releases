var class_papaya_spi_backend =
[
    [ "~PapayaSpiBackend", "class_papaya_spi_backend.html#a2cac76781045dfaea603d1fd7d72ea52", null ],
    [ "begin", "class_papaya_spi_backend.html#aa785ef5cea939ddd3e5efcc962a88d24", null ],
    [ "end", "class_papaya_spi_backend.html#a670cfd6a32d9f5ef0958d42ae5d7d769", null ],
    [ "transfer", "class_papaya_spi_backend.html#ad9cb44141bebd1072cac98fdd54ea26c", null ]
];