/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 4000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe sepoint_prb;
probe drive_voltage_V;
probe position_rad;
probe shaft_speed_rad;
probe armature_curren;

input deadband_rad;
input volt_max;
input volt_min;
input encoder_count;

/* Global Array Declarations */
float Winding_L_R_numerator[] = {1.0f};
float Winding_L_R_denominator[] = {0.005f, 4.0f};
float Rotor_J_b_numerator[] = {1.0f};
float Rotor_J_b_denominator[] = {0.15f, 0.03f};

macro build_DC_motor()
{
  macro retMacro;

  // Create Empty Macro
  retMacro = macro(1, 3);

  // Start Macro
  retMacro.start();

  // Create Blocks
  signalSource Coulomb_friction = signalSource::dc(0.025f);
  node Armature_loop = node("[1.0 -3.3]", "[1.0]", Sum);
  tf Winding_L_R = tf(Winding_L_R_numerator, 1, Winding_L_R_denominator, 2);
  expander current_fan = expander(2);
  gain Torque_constant_Kt = gain(3.3);
  backlashDeadBand Static_friction = backlashDeadBand();
  tf Rotor_J_b = tf(Rotor_J_b_numerator, 1, Rotor_J_b_denominator, 2);
  expander speed_fan = expander(3);
  integrator Speed_to_angle = integrator();

  // Connect Blocks
  retMacro.in(0) > Armature_loop.in(0);
  Coulomb_friction > Static_friction.in(0);
  Armature_loop > Winding_L_R;
  Winding_L_R > current_fan;
  current_fan.out(0) > Torque_constant_Kt;
  current_fan.out(1) > retMacro.out(2);
  Torque_constant_Kt > Static_friction.in(1);
  Static_friction > Rotor_J_b;
  Rotor_J_b > speed_fan;
  speed_fan.out(0) > Armature_loop.in(1);
  speed_fan.out(1) > Speed_to_angle;
  speed_fan.out(2) > retMacro.out(1);
  Speed_to_angle > retMacro.out(0);

  // Stop Macro
  retMacro.stop();

  return retMacro;
}


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(4000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  deadband_rad = input("deadband_rad", 0.0046019423636569235f);
  volt_max = input("volt_max", 12.0f);
  volt_min = input("volt_min", -12.0f);
  encoder_count = input("encoder_count", 0.0030679615757712823f);
  signalSource Position_setpoint = signalSource::square(0.1f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.5723303075827821f);
  node Position_error = node("[1.0 -1.0]", "[1.0]", Sum);
  backlashDeadBand Error_dead_band = backlashDeadBand();
  pid Position_PID = pid(600.0, 120.0, 2.4, 0.002);
  sat Supply_rail = sat();
  macro DC_motor = build_DC_motor();
  quantizer Encoder = quantizer();
  sepoint_prb = probe("sepoint_prb");
  drive_voltage_V = probe("drive_voltage_V");
  position_rad = probe("position_rad");
  shaft_speed_rad = probe("shaft_speed_rad");
  armature_curren = probe("armature_curren");

  /* Connect Blocks */
  deadband_rad > Error_dead_band.in(0);
  volt_max > Supply_rail.in(0);
  volt_min > Supply_rail.in(1);
  encoder_count > Encoder.in(1);
  Position_setpoint > Position_error.in(0);
  Position_setpoint > sepoint_prb;
  Position_error > Error_dead_band.in(1);
  Error_dead_band > Position_PID;
  Position_PID > Supply_rail.in(2);
  Supply_rail > DC_motor;
  Supply_rail > drive_voltage_V;
  DC_motor.out(0) > Encoder.in(0);
  DC_motor.out(0) > position_rad;
  DC_motor.out(1) > shaft_speed_rad;
  DC_motor.out(2) > armature_curren;
  Encoder > Position_error.in(1);

  /* Enable Remote Input Control */
  deadband_rad.enableRemote();
  volt_max.enableRemote();
  volt_min.enableRemote();
  encoder_count.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    sepoint_prb.show();
    drive_voltage_V.show();
    position_rad.show();
    shaft_speed_rad.show();
    armature_curren.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}