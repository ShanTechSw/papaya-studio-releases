/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:46
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe output;

/* Global Struct Declarations */
// Configuration for Model
static float Model_A_data[4] = {0.9f, 0.1f, 0.0f, 0.9f};
static float Model_B_data[2] = {0.0f, 1.0f};
static float Model_C_data[2] = {1.0f, 0.0f};
static float Model_D_data[1] = {0.0f};
static float Model_x_init[2] = {0.0f, 0.0f};
PP_stateSpace Model_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = Model_A_data,
  .B_data = Model_B_data,
  .C_data = Model_C_data,
  .D_data = Model_D_data,
  .x_init = Model_x_init
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::square(1.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  stateSpace Model = stateSpace(&Model_config);
  output = probe("output");

  /* Connect Blocks */
  Source > Model;
  Model > output;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    output.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}