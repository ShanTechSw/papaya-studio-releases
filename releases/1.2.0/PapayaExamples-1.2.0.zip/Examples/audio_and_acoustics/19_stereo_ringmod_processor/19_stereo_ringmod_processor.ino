/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe Stereo_mixer_tap;
probe Stereo_mixer_tap_2;

input pan;
input carrier_level;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  pan = input("pan", 0.0f);
  carrier_level = input("carrier_level", 0.8f);
  microphone Microphone = microphone(MIC_L);
  replay Replay_clip = replay();
  amOscillator Carrier = amOscillator(Sine, 200.0, 0.0);
  expander fan_2 = expander(2);
  stereoPan Stereo_pan = stereoPan();
  expander fan_2_2 = expander(2);
  speaker Speaker_L = speaker(SPEAKER1);
  speaker Speaker_R = speaker(SPEAKER2);
  ringMod Ring_mod = ringMod();
  stereoMixer Stereo_mixer = stereoMixer(3);
  Stereo_mixer_tap = probe("Stereo mixer_o0");
  Stereo_mixer_tap_2 = probe("Stereo mixer_o1");

  /* Connect Blocks */
  pan > Stereo_pan.in(1);
  carrier_level > Carrier;
  Microphone > fan_2;
  Replay_clip > Stereo_mixer.in(1);
  Carrier > fan_2_2;
  fan_2.out(0) > Stereo_pan.in(0);
  fan_2.out(1) > Ring_mod.in(0);
  Stereo_pan.out(0) > Speaker_L;
  Stereo_pan.out(1) > Speaker_R;
  fan_2_2.out(0) > Ring_mod.in(1);
  fan_2_2.out(1) > Stereo_mixer.in(2);
  Ring_mod > Stereo_mixer.in(0);
  Stereo_mixer.out(0) > Stereo_mixer_tap;
  Stereo_mixer.out(1) > Stereo_mixer_tap_2;

  /* Enable Remote Input Control */
  pan.enableRemote();
  carrier_level.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    Stereo_mixer_tap.show();
    Stereo_mixer_tap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}