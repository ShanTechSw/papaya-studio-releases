var structpp__wave__detail_1_1_builder_1_1_entry =
[
    [ "fp", "structpp__wave__detail_1_1_builder_1_1_entry.html#a0cabd15adc6ffefaf86a73cb3837e913", null ],
    [ "sz", "structpp__wave__detail_1_1_builder_1_1_entry.html#a7636f2fa2788924cca2df2bf655bece2", null ],
    [ "t", "structpp__wave__detail_1_1_builder_1_1_entry.html#a6bcc3023678ba484c3e3e188c00b3285", null ]
];