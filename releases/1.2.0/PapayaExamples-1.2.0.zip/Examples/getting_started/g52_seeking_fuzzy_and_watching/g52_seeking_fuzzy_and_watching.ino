/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe esc_pid_kp;
probe esc_pid_ki;
probe esc_pid_measure;
probe fuzzy_pid_kp;
probe fuzzy_pid_ki;
probe fuzzy_pid_measu;
probe perf_kp;
probe perf_status;
probe perf_measured;
probe identifier_erro;
probe from_model_kp;
probe from_model_ki;
probe unused_signals;

input ESC_PID_p1;

/* Global Struct Declarations */
// Configuration for Esc_Pid
PP_ESC_PID_Config Esc_Pid_config = {
  .Kp_init = 1.0f,
  .Ki_init = 0.5f,
  .Kd_init = 0.1f,
  .a = 0.05f,
  .omega_p = 3.0f,
  .omega_i = 5.0f,
  .omega_d = 7.0f,
  .esc_gain = 0.1f,
  .lpf_wc = 1.0f,
  .Tau = 0.01f,
  .iae_window = 2.0f
};

// Configuration for Fuzzy_Pid
PP_FuzzyPIDConfig Fuzzy_Pid_config = {
  .Kp_base = 1.0f,
  .Ki_base = 0.5f,
  .Kd_base = 0.1f,
  .e_range = 10.0f,
  .de_range = 5.0f,
  .Tau = 0.01f,
  .out_min = -100.0f,
  .out_max = 100.0f
};

// Configuration for Perf_Monitor_Pid
PP_PerfMonPID_Config Perf_Monitor_Pid_config = {
  .Kp_init = 1.0f,
  .Ki_init = 0.5f,
  .Kd_init = 0.1f,
  .Tau = 0.01f,
  .iae_threshold = 5.0f,
  .out_min = -100.0f,
  .out_max = 100.0f,
  .eval_window = 2.0f
};

// Configuration for Identifier
// Order 2: num is {b0..b2}, denom is {1, a1..a2}, both 3 long
float Identifier_num[3]   = {0.0f, 0.0f, 0.0f};   // no prior model
float Identifier_denom[3] = {1.0f, 0.0f, 0.0f};   // monic, leading 1

// Covariance and system order
PP_RLSParam Identifier_config = {Identifier_num, 3, Identifier_denom, 3, 1000.0f, 2, 1};
// Replace num and denom with a starting model if you have one; the denominator's leading coefficient must not be zero.


/* Global Array Declarations */
float ESC_PID_plant_numerator[] = {1.0f};
float ESC_PID_plant_denominator[] = {0.2f, 1.0f};
float FUZZY_PID_plant_numerator[] = {1.0f};
float FUZZY_PID_plant_denominator[] = {0.2f, 1.0f};
float PERF_MONITOR_PID_plant_numerator[] = {1.0f};
float PERF_MONITOR_PID_plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::square(0.3f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  ESC_PID_p1 = input("ESC_PID_p1", 0.0f);
  expander fan_4 = expander(4);
  expander ESC_PID_ref = expander(1);
  expander FUZZY_PID_ref = expander(1);
  expander PERF_MONITOR_PID_ref = expander(1);
  expander ident_split = expander(2);
  node ESC_PID_error = node("[1.0 -1.0]", "[1.0]", Sum);
  escPID Esc_Pid = escPID(&Esc_Pid_config);
  tf ESC_PID_plant = tf(ESC_PID_plant_numerator, 1, ESC_PID_plant_denominator, 2);
  expander ESC_PID_fb = expander(2);
  node FUZZY_PID_error = node("[1.0 -1.0]", "[1.0]", Sum);
  fuzzyPID Fuzzy_Pid = fuzzyPID(&Fuzzy_Pid_config);
  tf FUZZY_PID_plant = tf(FUZZY_PID_plant_numerator, 1, FUZZY_PID_plant_denominator, 2);
  expander FUZZY_PID_fb = expander(2);
  node PERF_MONITOR_PID_error = node("[1.0 -1.0]", "[1.0]", Sum);
  perfMonitorPID Perf_Monitor_Pid = perfMonitorPID(&Perf_Monitor_Pid_config);
  tf PERF_MONITOR_PID_plant = tf(PERF_MONITOR_PID_plant_numerator, 1, PERF_MONITOR_PID_plant_denominator, 2);
  expander PERF_MONITOR_PID_fb = expander(2);
  RLS Identifier = RLS(&Identifier_config);
  pidFromModel Gains_From_Model = pidFromModel(Identifier, 0.1f, 2.0f, 0.0f, 0.0f, 0.0f);
  merger unused_bus = merger(6);
  esc_pid_kp = probe("esc_pid_kp");
  esc_pid_ki = probe("esc_pid_ki");
  esc_pid_measure = probe("esc_pid_measure");
  fuzzy_pid_kp = probe("fuzzy_pid_kp");
  fuzzy_pid_ki = probe("fuzzy_pid_ki");
  fuzzy_pid_measu = probe("fuzzy_pid_measu");
  perf_kp = probe("perf_kp");
  perf_status = probe("perf_status");
  perf_measured = probe("perf_measured");
  identifier_erro = probe("identifier_erro");
  from_model_kp = probe("from_model_kp");
  from_model_ki = probe("from_model_ki");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  Source > fan_4;
  ESC_PID_p1 > Esc_Pid.in(1);
  fan_4.out(0) > ESC_PID_ref;
  fan_4.out(1) > FUZZY_PID_ref;
  fan_4.out(2) > PERF_MONITOR_PID_ref;
  fan_4.out(3) > ident_split;
  ESC_PID_ref > ESC_PID_error.in(0);
  FUZZY_PID_ref > FUZZY_PID_error.in(0);
  PERF_MONITOR_PID_ref > PERF_MONITOR_PID_error.in(0);
  ident_split.out(0) > Identifier.in(0);
  ident_split.out(1) > Identifier.in(1);
  ESC_PID_error > Esc_Pid.in(0);
  Esc_Pid.out(0) > ESC_PID_plant;
  Esc_Pid.out(3) > unused_bus.in(0);
  Esc_Pid.out(1) > esc_pid_kp;
  Esc_Pid.out(2) > esc_pid_ki;
  ESC_PID_plant > ESC_PID_fb;
  ESC_PID_fb.out(0) > ESC_PID_error.in(1);
  ESC_PID_fb.out(1) > esc_pid_measure;
  FUZZY_PID_error > Fuzzy_Pid;
  Fuzzy_Pid.out(0) > FUZZY_PID_plant;
  Fuzzy_Pid.out(3) > unused_bus.in(1);
  Fuzzy_Pid.out(1) > fuzzy_pid_kp;
  Fuzzy_Pid.out(2) > fuzzy_pid_ki;
  FUZZY_PID_plant > FUZZY_PID_fb;
  FUZZY_PID_fb.out(0) > FUZZY_PID_error.in(1);
  FUZZY_PID_fb.out(1) > fuzzy_pid_measu;
  PERF_MONITOR_PID_error > Perf_Monitor_Pid;
  Perf_Monitor_Pid.out(0) > PERF_MONITOR_PID_plant;
  Perf_Monitor_Pid.out(2) > unused_bus.in(2);
  Perf_Monitor_Pid.out(3) > unused_bus.in(3);
  Perf_Monitor_Pid.out(1) > perf_kp;
  Perf_Monitor_Pid.out(4) > perf_status;
  PERF_MONITOR_PID_plant > PERF_MONITOR_PID_fb;
  PERF_MONITOR_PID_fb.out(0) > PERF_MONITOR_PID_error.in(1);
  PERF_MONITOR_PID_fb.out(1) > perf_measured;
  Identifier.out(0) > Gains_From_Model;
  Identifier.out(1) > identifier_erro;
  Gains_From_Model.out(2) > unused_bus.in(4);
  Gains_From_Model.out(3) > unused_bus.in(5);
  Gains_From_Model.out(0) > from_model_kp;
  Gains_From_Model.out(1) > from_model_ki;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    esc_pid_kp.show();
    esc_pid_ki.show();
    esc_pid_measure.show();
    fuzzy_pid_kp.show();
    fuzzy_pid_ki.show();
    fuzzy_pid_measu.show();
    perf_kp.show();
    perf_status.show();
    perf_measured.show();
    identifier_erro.show();
    from_model_kp.show();
    from_model_ki.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}