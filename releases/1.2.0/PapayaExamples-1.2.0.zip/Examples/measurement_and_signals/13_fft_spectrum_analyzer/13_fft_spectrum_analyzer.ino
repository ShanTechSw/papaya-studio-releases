/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe magnitude;
probe Magnitude_tap;
VectorProbe mag_hann;
probe Magnitude_Hann_tap;
VectorProbe phase;
probe Phase_tap;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  microphone Microphone = microphone(MIC_L);
  expander fan_3 = expander(3);
  fft FFT_512 = fft(512);
  fft_HannWindow FFT_Hann_mag = fft_HannWindow(512);
  fft_HannWindow FFT_Hann_phase = fft_HannWindow(512);
  fftMagResolver Magnitude = fftMagResolver(FFT_512);
  fftMagResolver Magnitude_Hann = fftMagResolver(FFT_Hann_mag);
  fft_phaseResolver Phase = fft_phaseResolver(FFT_Hann_phase);
  magnitude = VectorProbe("magnitude");
  Magnitude_tap = probe("Magnitude_o0");
  mag_hann = VectorProbe("mag_hann");
  Magnitude_Hann_tap = probe("Magnitude Han_0");
  phase = VectorProbe("phase");
  Phase_tap = probe("Phase_o0");

  /* Connect Blocks */
  Microphone > fan_3;
  fan_3.out(0) > FFT_512;
  fan_3.out(1) > FFT_Hann_mag;
  fan_3.out(2) > FFT_Hann_phase;
  FFT_512 > Magnitude;
  FFT_Hann_mag > Magnitude_Hann;
  FFT_Hann_phase > Phase;
  Magnitude >> magnitude;
  Magnitude > Magnitude_tap;
  Magnitude_Hann >> mag_hann;
  Magnitude_Hann > Magnitude_Hann_tap;
  Phase >> phase;
  Phase > Phase_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    magnitude.show();
    Magnitude_tap.show();
    mag_hann.show();
    Magnitude_Hann_tap.show();
    phase.show();
    Phase_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}