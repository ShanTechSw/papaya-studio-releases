"""Ed25519, on the standard library alone.

Why this is here rather than a dependency
-----------------------------------------
PAPAYA Studio ships as an installer. Adding ``cryptography`` or
``PyNaCl`` would put a native wheel inside it, with its own size, its own
licence surface and its own release cadence, to perform **one signature
verification per board connection**. Verification is the eighty lines
below and runs in a few milliseconds. The dependency buys nothing and
costs packaging.

This is the reference algorithm from RFC 8032, transcribed, not invented.
Nothing here is a novel construction, and it is checked against the RFC's
own test vectors rather than against itself.

What it is and is not suitable for
----------------------------------
It is suitable for **verifying a board's attestation**, which is a public
operation on public data: there is no secret on this side to leak.

``sign`` is present because the provisioning tools need it and because a
verifier tested only against its own output tests nothing. **It is not
constant-time.** Signing here is done offline, on an operator's machine,
against keys that are being created at that moment. Do not use it to sign
with a long-lived key on a machine an attacker can measure.

The board does its own signing in firmware and never uses this.
"""
from __future__ import annotations

import hashlib

__all__ = ["public_key_from_seed", "sign", "verify",
           "PUBLIC_KEY_LEN", "SIGNATURE_LEN", "SEED_LEN"]

SEED_LEN = 32
PUBLIC_KEY_LEN = 32
SIGNATURE_LEN = 64

#: The curve, as RFC 8032 defines it. These are not tunable.
_P = 2 ** 255 - 19
#: Order of the base point's subgroup.
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
#: A square root of -1, used when recovering x from y.
_I = pow(2, (_P - 1) // 4, _P)


# ==========================================================================
# Curve arithmetic, in extended coordinates (X, Y, Z, T)
# ==========================================================================
def _point_add(p, q):
    """Twisted Edwards addition. Complete: no special case for doubling,
    for the neutral element, or for p == q, which is what makes a
    constant-time-shaped ladder possible and removes a class of bugs."""
    a = (p[1] - p[0]) * (q[1] - q[0]) % _P
    b = (p[1] + p[0]) * (q[1] + q[0]) % _P
    c = 2 * p[3] * q[3] * _D % _P
    d = 2 * p[2] * q[2] % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _point_mul(scalar: int, point):
    result = (0, 1, 1, 0)                       # the neutral element
    while scalar > 0:
        if scalar & 1:
            result = _point_add(result, point)
        point = _point_add(point, point)
        scalar >>= 1
    return result


def _point_equal(p, q) -> bool:
    """Projective coordinates are not unique, so compare cross-multiplied
    rather than component by component."""
    if (p[0] * q[2] - q[0] * p[2]) % _P != 0:
        return False
    if (p[1] * q[2] - q[1] * p[2]) % _P != 0:
        return False
    return True


def _recover_x(y: int, sign: int):
    """The x that goes with this y, or None if the point is not on the
    curve. Returning None rather than raising matters: a malformed public
    key is an ordinary thing to be handed and must produce a refusal, not
    a traceback."""
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _I % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != sign:
        x = _P - x
    return x


def _point_compress(p) -> bytes:
    z_inv = pow(p[2], _P - 2, _P)
    x = p[0] * z_inv % _P
    y = p[1] * z_inv % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _point_decompress(data: bytes):
    if len(data) != 32:
        return None
    value = int.from_bytes(data, "little")
    sign = value >> 255
    y = value & ((1 << 255) - 1)
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


_BASE_Y = 4 * pow(5, _P - 2, _P) % _P
_BASE_X = _recover_x(_BASE_Y, 0)
_BASE = (_BASE_X, _BASE_Y, 1, _BASE_X * _BASE_Y % _P)


# ==========================================================================
# The three operations anyone here needs
# ==========================================================================
def _expand_seed(seed: bytes):
    if len(seed) != SEED_LEN:
        raise ValueError(f"seed must be {SEED_LEN} bytes, got {len(seed)}")
    digest = hashlib.sha512(seed).digest()
    scalar = int.from_bytes(digest[:32], "little")
    # The clamping RFC 8032 requires: clear the low three bits so the
    # scalar is a multiple of the cofactor, and set bit 254 so it has a
    # fixed length. Skipping either is a small-subgroup or a timing bug.
    scalar &= (1 << 254) - 8
    scalar |= 1 << 254
    return scalar, digest[32:]


def public_key_from_seed(seed: bytes) -> bytes:
    """The 32-byte public key for a 32-byte seed."""
    scalar, _prefix = _expand_seed(seed)
    return _point_compress(_point_mul(scalar, _BASE))


def sign(seed: bytes, message: bytes) -> bytes:
    """A 64-byte signature. Offline use only; see the module note."""
    scalar, prefix = _expand_seed(seed)
    public = _point_compress(_point_mul(scalar, _BASE))

    # Deterministic: the per-signature secret comes from the key and the
    # message, never from a random number generator. That is what makes
    # Ed25519 safe on a device whose RNG may be weak or unseeded, and it
    # is why this and not ECDSA.
    r = int.from_bytes(hashlib.sha512(prefix + message).digest(),
                       "little") % _L
    r_point = _point_compress(_point_mul(r, _BASE))
    challenge = int.from_bytes(
        hashlib.sha512(r_point + public + message).digest(), "little") % _L
    s = (r + challenge * scalar) % _L
    return r_point + int.to_bytes(s, 32, "little")


def verify(public: bytes, message: bytes, signature: bytes) -> bool:
    """True only if *signature* is valid. Never raises on bad input.

    Everything reaching this comes off a wire from a device that has not
    proved anything yet, so a malformed key or a malformed signature is
    the ordinary case and must return False rather than throw.
    """
    if len(public) != PUBLIC_KEY_LEN or len(signature) != SIGNATURE_LEN:
        return False

    point = _point_decompress(public)
    if point is None:
        return False
    r_point = _point_decompress(signature[:32])
    if r_point is None:
        return False

    s = int.from_bytes(signature[32:], "little")
    # Refusing s >= L is not pedantry: accepting it makes signatures
    # malleable, so a valid signature can be turned into a different
    # valid signature for the same message.
    if s >= _L:
        return False

    challenge = int.from_bytes(
        hashlib.sha512(signature[:32] + public + message).digest(),
        "little") % _L
    return _point_equal(_point_mul(s, _BASE),
                        _point_add(r_point, _point_mul(challenge, point)))
