var struct_p_p___adaptive_notch_config =
[
    [ "init_freq", "struct_p_p___adaptive_notch_config.html#a398d6d289f6c0b223d5550bd74ec2f5e", null ],
    [ "mu", "struct_p_p___adaptive_notch_config.html#ac57751dc79d349ede3a940f24c80d52c", null ],
    [ "Q_factor", "struct_p_p___adaptive_notch_config.html#a0396c41f90a3328ab77477f9681a6fd5", null ]
];