var classcheby2_bq =
[
    [ "cheby2Bq", "classcheby2_bq.html#a0adc30ffb9277598105328b6f5f441fb", null ],
    [ "cheby2Bq", "classcheby2_bq.html#aa31fdac3a5c748f8b846d93f80571259", null ]
];