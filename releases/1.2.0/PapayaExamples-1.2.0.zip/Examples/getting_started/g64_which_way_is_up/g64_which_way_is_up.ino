/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-11 03:53:13
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe madgwick_ahrs_0;
probe madgwick_ahrs_1;
probe mahony_ahrs_0;
probe mahony_ahrs_1;
probe complementary_0;
probe complementary_1;
probe ahrs_ekf_out0;
probe ahrs_ekf_out1;
probe tilt_ekf_out0;
probe tilt_ekf_out1;
probe comp_filter_0;
probe imu_bias_est_0;
probe imu_bias_est_1;
probe unused_signals;

/* Global Struct Declarations */
// TODO: populate fields of Ahrs_Ekf_config before deploying.
//       See PAPAYA.h for the PP_AHRS_EKF struct layout.
PP_AHRS_EKF Ahrs_Ekf_config = {};

// TODO: populate fields of Tilt_Ekf_config before deploying.
//       See PAPAYA.h for the PP_Tilt_EKF struct layout.
PP_Tilt_EKF Tilt_Ekf_config = {};

// Configuration for Comp_Filter
PP_compFilter Comp_Filter_config = {
  .alpha = 0.98f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(0.5f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  signalSource const_ = signalSource::dc(0.0f);
  signalSource const__2 = signalSource::dc(0.0f);
  signalSource const__3 = signalSource::dc(0.0f);
  signalSource const__4 = signalSource::dc(0.0f);
  signalSource const__5 = signalSource::dc(0.0f);
  signalSource const__6 = signalSource::dc(0.0f);
  signalSource const__7 = signalSource::dc(0.0f);
  signalSource const__8 = signalSource::dc(0.0f);
  signalSource const__9 = signalSource::dc(0.0f);
  signalSource const__10 = signalSource::dc(0.0f);
  signalSource const__11 = signalSource::dc(0.0f);
  signalSource const__12 = signalSource::dc(0.0f);
  signalSource const__13 = signalSource::dc(0.0f);
  signalSource const__14 = signalSource::dc(0.0f);
  signalSource const__15 = signalSource::dc(0.0f);
  signalSource const__16 = signalSource::dc(0.0f);
  signalSource const__17 = signalSource::dc(0.0f);
  signalSource const_az = signalSource::dc(1.0f);
  signalSource const__18 = signalSource::dc(0.0f);
  signalSource const__19 = signalSource::dc(0.0f);
  signalSource const__20 = signalSource::dc(0.0f);
  signalSource const_mx = signalSource::dc(1.0f);
  signalSource const__21 = signalSource::dc(0.0f);
  signalSource const__22 = signalSource::dc(0.0f);
  signalSource const__23 = signalSource::dc(0.0f);
  signalSource const__24 = signalSource::dc(0.0f);
  signalSource const__25 = signalSource::dc(0.0f);
  signalSource const__26 = signalSource::dc(0.0f);
  signalSource const__27 = signalSource::dc(0.0f);
  signalSource const__28 = signalSource::dc(0.0f);
  signalSource const__29 = signalSource::dc(0.0f);
  signalSource const__30 = signalSource::dc(0.0f);
  signalSource const__31 = signalSource::dc(0.0f);
  signalSource const__32 = signalSource::dc(0.0f);
  signalSource const__33 = signalSource::dc(0.0f);
  signalSource const__34 = signalSource::dc(0.0f);
  signalSource const__35 = signalSource::dc(0.0f);
  signalSource const__36 = signalSource::dc(0.0f);
  signalSource const__37 = signalSource::dc(0.0f);
  expander shared_measurement = expander(7);
  madgwickAhrs Madgwick_Ahrs = madgwickAhrs(0.1);
  mahonyAhrs Mahony_Ahrs = mahonyAhrs(2.0, 0.005);
  complementaryAhrs Complementary_Ahrs = complementaryAhrs(0.98);
  ahrsEKF Ahrs_Ekf = ahrsEKF(&Ahrs_Ekf_config);
  tiltEKF Tilt_Ekf = tiltEKF(&Tilt_Ekf_config);
  compFilter Comp_Filter = compFilter(&Comp_Filter_config);
  imuBiasEst Imu_Bias_Est = imuBiasEst(64, 0.001, 0.01);
  merger unused_bus = merger(24);
  madgwick_ahrs_0 = probe("madgwick_ahrs_0");
  madgwick_ahrs_1 = probe("madgwick_ahrs_1");
  mahony_ahrs_0 = probe("mahony_ahrs_0");
  mahony_ahrs_1 = probe("mahony_ahrs_1");
  complementary_0 = probe("complementary_0");
  complementary_1 = probe("complementary_1");
  ahrs_ekf_out0 = probe("ahrs_ekf_out0");
  ahrs_ekf_out1 = probe("ahrs_ekf_out1");
  tilt_ekf_out0 = probe("tilt_ekf_out0");
  tilt_ekf_out1 = probe("tilt_ekf_out1");
  comp_filter_0 = probe("comp_filter_0");
  imu_bias_est_0 = probe("imu_bias_est_0");
  imu_bias_est_1 = probe("imu_bias_est_1");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  Source > shared_measurement;
  const_ > Madgwick_Ahrs.in(1);
  const__2 > Madgwick_Ahrs.in(2);
  const__3 > Madgwick_Ahrs.in(3);
  const__4 > Madgwick_Ahrs.in(4);
  const__5 > Madgwick_Ahrs.in(5);
  const__6 > Madgwick_Ahrs.in(6);
  const__7 > Madgwick_Ahrs.in(7);
  const__8 > Madgwick_Ahrs.in(8);
  const__9 > Mahony_Ahrs.in(1);
  const__10 > Mahony_Ahrs.in(2);
  const__11 > Mahony_Ahrs.in(3);
  const__12 > Mahony_Ahrs.in(4);
  const__13 > Mahony_Ahrs.in(5);
  const__14 > Mahony_Ahrs.in(6);
  const__15 > Mahony_Ahrs.in(7);
  const__16 > Mahony_Ahrs.in(8);
  const__17 > Complementary_Ahrs.in(1);
  const_az > Complementary_Ahrs.in(2);
  const__18 > Complementary_Ahrs.in(3);
  const__19 > Complementary_Ahrs.in(4);
  const__20 > Complementary_Ahrs.in(5);
  const_mx > Complementary_Ahrs.in(6);
  const__21 > Complementary_Ahrs.in(7);
  const__22 > Complementary_Ahrs.in(8);
  const__23 > Ahrs_Ekf.in(1);
  const__24 > Ahrs_Ekf.in(2);
  const__25 > Ahrs_Ekf.in(3);
  const__26 > Ahrs_Ekf.in(4);
  const__27 > Ahrs_Ekf.in(5);
  const__28 > Ahrs_Ekf.in(6);
  const__29 > Ahrs_Ekf.in(7);
  const__30 > Ahrs_Ekf.in(8);
  const__31 > Tilt_Ekf.in(1);
  const__32 > Comp_Filter.in(1);
  const__33 > Imu_Bias_Est.in(1);
  const__34 > Imu_Bias_Est.in(2);
  const__35 > Imu_Bias_Est.in(3);
  const__36 > Imu_Bias_Est.in(4);
  const__37 > Imu_Bias_Est.in(5);
  shared_measurement.out(0) > Madgwick_Ahrs.in(0);
  shared_measurement.out(1) > Mahony_Ahrs.in(0);
  shared_measurement.out(2) > Complementary_Ahrs.in(0);
  shared_measurement.out(3) > Ahrs_Ekf.in(0);
  shared_measurement.out(4) > Tilt_Ekf.in(0);
  shared_measurement.out(5) > Comp_Filter.in(0);
  shared_measurement.out(6) > Imu_Bias_Est.in(0);
  Madgwick_Ahrs.out(2) > unused_bus.in(0);
  Madgwick_Ahrs.out(3) > unused_bus.in(1);
  Madgwick_Ahrs.out(0) > madgwick_ahrs_0;
  Madgwick_Ahrs.out(1) > madgwick_ahrs_1;
  Mahony_Ahrs.out(2) > unused_bus.in(2);
  Mahony_Ahrs.out(3) > unused_bus.in(3);
  Mahony_Ahrs.out(4) > unused_bus.in(4);
  Mahony_Ahrs.out(5) > unused_bus.in(5);
  Mahony_Ahrs.out(6) > unused_bus.in(6);
  Mahony_Ahrs.out(0) > mahony_ahrs_0;
  Mahony_Ahrs.out(1) > mahony_ahrs_1;
  Complementary_Ahrs.out(2) > unused_bus.in(7);
  Complementary_Ahrs.out(3) > unused_bus.in(8);
  Complementary_Ahrs.out(0) > complementary_0;
  Complementary_Ahrs.out(1) > complementary_1;
  Ahrs_Ekf.out(2) > unused_bus.in(9);
  Ahrs_Ekf.out(3) > unused_bus.in(10);
  Ahrs_Ekf.out(4) > unused_bus.in(11);
  Ahrs_Ekf.out(5) > unused_bus.in(12);
  Ahrs_Ekf.out(6) > unused_bus.in(13);
  Ahrs_Ekf.out(0) > ahrs_ekf_out0;
  Ahrs_Ekf.out(1) > ahrs_ekf_out1;
  Tilt_Ekf.out(0) > tilt_ekf_out0;
  Tilt_Ekf.out(1) > tilt_ekf_out1;
  Comp_Filter > comp_filter_0;
  Imu_Bias_Est.out(2) > unused_bus.in(14);
  Imu_Bias_Est.out(3) > unused_bus.in(15);
  Imu_Bias_Est.out(4) > unused_bus.in(16);
  Imu_Bias_Est.out(5) > unused_bus.in(17);
  Imu_Bias_Est.out(6) > unused_bus.in(18);
  Imu_Bias_Est.out(7) > unused_bus.in(19);
  Imu_Bias_Est.out(8) > unused_bus.in(20);
  Imu_Bias_Est.out(9) > unused_bus.in(21);
  Imu_Bias_Est.out(10) > unused_bus.in(22);
  Imu_Bias_Est.out(11) > unused_bus.in(23);
  Imu_Bias_Est.out(0) > imu_bias_est_0;
  Imu_Bias_Est.out(1) > imu_bias_est_1;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    madgwick_ahrs_0.show();
    madgwick_ahrs_1.show();
    mahony_ahrs_0.show();
    mahony_ahrs_1.show();
    complementary_0.show();
    complementary_1.show();
    ahrs_ekf_out0.show();
    ahrs_ekf_out1.show();
    tilt_ekf_out0.show();
    tilt_ekf_out1.show();
    comp_filter_0.show();
    imu_bias_est_0.show();
    imu_bias_est_1.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}