var classemg_envelope =
[
    [ "emgEnvelope", "classemg_envelope.html#ad84c3e8fc9ca28d0f78d5e760a24d95f", null ]
];