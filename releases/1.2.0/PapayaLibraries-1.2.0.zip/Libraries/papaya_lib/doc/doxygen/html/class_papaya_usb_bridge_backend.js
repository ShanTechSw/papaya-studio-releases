var class_papaya_usb_bridge_backend =
[
    [ "BridgeCommand", "class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6cae", [
      [ "ConfigureSpi", "class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6caea5f7d0634848000ed70b99853cfb949eb", null ],
      [ "SpiTransfer", "class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6caeac9b1dd3504df66164bb778da09e8e684", null ],
      [ "PinMode", "class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6caea552aa9e74d9f0df9dc1fd8f87529b6e9", null ],
      [ "DigitalWrite", "class_papaya_usb_bridge_backend.html#a48e4a021f7f03cf1ea8299cfbd8c6caea974604e564f7c4aafde1df292b3cad16", null ]
    ] ],
    [ "BridgeStatus", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20", [
      [ "Ok", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20aa60852f204ed8028c1c58808b746d115", null ],
      [ "InvalidCommand", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20ae01b8763e8076df4395e3fa649286e67", null ],
      [ "InvalidPayload", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a2d730f4aa6a660e8825d5294008a4ef7", null ],
      [ "SpiError", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a4a9f044cba37c05b591c75f44fa85a8d", null ],
      [ "GpioError", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a32445a4acf92934280bee3c99f89d2fd", null ],
      [ "InternalError", "class_papaya_usb_bridge_backend.html#ae5233e18176b97f3e59848ac37edef20a8462b58246e70e5c83e5b939a9332cb5", null ]
    ] ],
    [ "PapayaUsbBridgeBackend", "class_papaya_usb_bridge_backend.html#ae332874e0d2b7368d76f144d9781de90", null ],
    [ "begin", "class_papaya_usb_bridge_backend.html#a65e78e5df8502791e6559819da4f7929", null ],
    [ "digitalWrite", "class_papaya_usb_bridge_backend.html#adb7b770fcf6e2ff8d17cccddec43c636", null ],
    [ "end", "class_papaya_usb_bridge_backend.html#a42d1190d6756af3fc676fd364e798d8e", null ],
    [ "ensureConfigured", "class_papaya_usb_bridge_backend.html#a43225fdeefc4eac6823f5138865fc5b3", null ],
    [ "ensureOpen", "class_papaya_usb_bridge_backend.html#a9892892d943bd776a50d8136ce5210af", null ],
    [ "installPinIoHandlers", "class_papaya_usb_bridge_backend.html#acc448a0b70a485394cf6aca0e602d6a4", null ],
    [ "pinMode", "class_papaya_usb_bridge_backend.html#ad1122d1b6db52f954e34e7d5734f2e84", null ],
    [ "sendConfigureSpi", "class_papaya_usb_bridge_backend.html#aec599a80e0c0694986318477d80bbb46", null ],
    [ "sendDigitalWrite", "class_papaya_usb_bridge_backend.html#abe6e3ab6121046d2d21168b9848af873", null ],
    [ "sendPinMode", "class_papaya_usb_bridge_backend.html#af42d63e9822fe8ba5df3f2012c513c6d", null ],
    [ "staticDigitalWriteHandler", "class_papaya_usb_bridge_backend.html#af0c9060333f9cc6ef81e488aea8e921c", null ],
    [ "staticPinModeHandler", "class_papaya_usb_bridge_backend.html#a21b862336d861087ed41897235d9ba51", null ],
    [ "transact", "class_papaya_usb_bridge_backend.html#a457d557e8d2226ac65d6897102a384d5", null ],
    [ "transfer", "class_papaya_usb_bridge_backend.html#ad3844f71e2ef6aa3cad6f6a52c90b9e7", null ],
    [ "uninstallPinIoHandlers", "class_papaya_usb_bridge_backend.html#a2abdf20f469b002de80950c939cbe2ae", null ],
    [ "_configured", "class_papaya_usb_bridge_backend.html#ae3e183b3a217a8bcc583c5fd4013649f", null ],
    [ "_currentSettings", "class_papaya_usb_bridge_backend.html#afd9629e01b8d0835aa9cafee5bb98353", null ],
    [ "_serialPort", "class_papaya_usb_bridge_backend.html#a938d623d4d260bb57ffb541c5b1ed53c", null ],
    [ "s_activeInstance", "class_papaya_usb_bridge_backend.html#ac184807d7997cdcddc1c2d2cf72d5a9c", null ]
];