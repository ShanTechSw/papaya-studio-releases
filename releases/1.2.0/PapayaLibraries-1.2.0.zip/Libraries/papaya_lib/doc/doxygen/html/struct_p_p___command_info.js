var struct_p_p___command_info =
[
    [ "FuncInfo", "struct_p_p___command_info.html#aa0130d6e5ed3a00a3aa13ab8cef454fc", null ],
    [ "TransactionInfo", "struct_p_p___command_info.html#a13a5a313b7f00ed80cdd19bd03ab9f85", null ]
];