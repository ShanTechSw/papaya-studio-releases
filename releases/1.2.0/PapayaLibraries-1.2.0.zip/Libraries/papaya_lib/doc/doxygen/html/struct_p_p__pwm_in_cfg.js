var struct_p_p__pwm_in_cfg =
[
    [ "id", "struct_p_p__pwm_in_cfg.html#a5ce4899b547f918f4e1d55d45d447c8b", null ],
    [ "outScale", "struct_p_p__pwm_in_cfg.html#a5d21784f344d102d8fcf2ca2b78e8da5", null ]
];