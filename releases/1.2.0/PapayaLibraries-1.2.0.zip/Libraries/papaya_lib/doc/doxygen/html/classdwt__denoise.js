var classdwt__denoise =
[
    [ "dwt_denoise", "classdwt__denoise.html#afd08bbfdb5a59b973623d09d6186eea3", null ],
    [ "getAssociatedDWT", "classdwt__denoise.html#a6cf0b77af5b371cc0663e05ed29ac36f", null ],
    [ "getThresholdScale", "classdwt__denoise.html#a036f5df996ff333fd31895b7c1f7d3e5", null ],
    [ "getThresholdType", "classdwt__denoise.html#af3bcf42afe6d2283620f071435c01d82", null ],
    [ "operator>", "classdwt__denoise.html#a7f447cadda06ddacb5b44739fab64b7e", null ],
    [ "operator>", "classdwt__denoise.html#a415429f9747cde2c64aea3024bbf293b", null ],
    [ "operator>", "classdwt__denoise.html#a78d79c933deb229c291eae92bf458341", null ],
    [ "operator>", "classdwt__denoise.html#a2f82c5ee8956b81ffba861695ec0c999", null ],
    [ "setScaleLive", "classdwt__denoise.html#ad550abdb5ada1c225e1b563a654a7dbd", null ],
    [ "associatedDWT", "classdwt__denoise.html#ac47d08c85c255d996d338abb8664fdaf", null ],
    [ "threshScale", "classdwt__denoise.html#a085aa381c15f9073cdd8128a9cce9d95", null ],
    [ "threshType", "classdwt__denoise.html#a284c9623bb55718a1e8d303daf229e88", null ]
];