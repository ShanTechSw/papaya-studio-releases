var classemg_hudgins =
[
    [ "emgHudgins", "classemg_hudgins.html#a28ec9e09654c5161b37e95680115a79e", null ]
];