"""Bearing envelope: the board separates the lines, this script names the race.

Run this beside example 88.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  is there a defect   the envelope level against the machine's own quiet
                      state, and the crest factor of the raw signal. Either
                      alone is weaker than the pair.

  which race          the outer share and the inner share. Both are
                      fractions of the envelope's own level, so neither
                      depends on how hard the machine is running, and each
                      is quiet where the other speaks.

  how sure            the sideband share, which is the modulation depth of
                      the inner-race line. It is only read when the inner
                      share says that line is there at all: dividing by a
                      line that is at the noise floor gives noise over
                      noise, and this script says so rather than printing
                      the number.

The bearing table at the top is the part to change for your own machine.
Everything else follows from it.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LEARN_SECONDS = 6.0

# How many feature vectors the quiet state is built from. A COUNT, not
# a duration: the median of the quietest half needs something to be a
# half of, and the board emits one vector per analysis window, so the
# seconds above are the minimum wait and this is what must arrive.
QUIET_ROWS = 8
WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "outer race", "inner race")

# The bearing this design is set up for: nine balls on a 2880 rpm shaft.
# Change these four numbers for your own bearing AND change the four band
# centres in the diagram to match, or the script and the board will be
# talking about different frequencies.
SHAFT_HZ = 48.0
BPFO_HZ = 168.0
BPFI_HZ = 264.0
BALLS = 9

FEATURES = ("e_bpfo", "e_bpfi", "e_sb_lo", "e_sb_hi", "env_rms",
            "raw_rms", "crest", "outer_share", "inner_share",
            "sideband_share", "state")

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

ENVELOPE_ALERT = 3.0        # multiple of the quiet envelope level
CREST_IMPULSIVE = 3.0
SHARE_PRESENT = 0.15        # a line holding this much of the envelope is there
# 0.15 and not 0.20: the inner-race share settles at 0.226 on this record,
# and a threshold that close to the value it has to clear turns ordinary
# scatter into a changed verdict.
SHARE_ABSENT = 0.05         # and below this it is not
MODULATION_DEEP = 0.4       # sidebands this big mean a rotating defect


def bearing_check():
    """Outer plus inner is always the ball count times the shaft rate.

    A bearing table that fails this has been copied wrongly, and it is the
    cheapest check there is.
    """
    expected = BALLS * SHAFT_HZ
    actual = BPFO_HZ + BPFI_HZ
    return abs(actual - expected) < 0.01 * expected, expected, actual


def learn_quiet(rows):
    """What this bearing looks like when it is behaving.

    The median of the quietest half by envelope level. Taking all of them
    would be wrong on a bearing that is already failing; taking the minimum
    would measure the noise instead of the machine.
    """
    if len(rows) < QUIET_ROWS:
        raise ValueError(
            f"only {len(rows)} feature vectors arrived, and the quiet state "
            f"needs {QUIET_ROWS}. The board emits one per analysis window, "
            f"so either it is not sampling or this needs a longer wait.")
    cut = statistics.median(r["env_rms"] for r in rows)
    quiet = [r for r in rows if r["env_rms"] <= cut] or rows
    return {k: statistics.median(r[k] for r in quiet)
            for k in FEATURES if rows[0][k] is not None}


def classify(row, quiet):
    """Returns (verdict, headline, reasons)."""
    reasons = []
    level = row["env_rms"] / max(quiet["env_rms"], 1e-12)
    crest = row["crest"]
    outer, inner = row["outer_share"], row["inner_share"]

    reasons.append(f"envelope level {level:.2f}x the quiet state "
                   f"({row['env_rms']:.5f} g against "
                   f"{quiet['env_rms']:.5f})")
    reasons.append(f"crest factor {crest:.2f} on the raw signal")

    impacting = level >= ENVELOPE_ALERT or crest >= CREST_IMPULSIVE
    if not impacting:
        return "ok", "nothing impacting this bearing", reasons

    reasons.append(f"outer-race share {outer:.3f}, inner-race share "
                   f"{inner:.3f}")

    if outer >= SHARE_PRESENT and inner <= SHARE_ABSENT:
        headline = ("OUTER-race defect: the impacts are all the same "
                    "height, so the damage is not moving through the load "
                    "zone")
        verdict = "outer"
    elif inner >= SHARE_PRESENT and outer <= SHARE_ABSENT:
        headline = ("INNER-race defect: the ball-pass line is at the inner "
                    "rate and it is modulated once per shaft turn")
        verdict = "inner"
    elif outer >= SHARE_PRESENT and inner >= SHARE_PRESENT:
        headline = "damage on both races, or a band that is catching both"
        verdict = "both"
    else:
        headline = ("impacts present but at neither ball-pass rate: a "
                    "rolling element, the cage, or something outside the "
                    "bearing")
        verdict = "elsewhere"

    # The ratio that is only worth reading when its denominator is real.
    if inner >= SHARE_PRESENT:
        depth = row["sideband_share"]
        reasons.append(
            f"sideband share {depth:.2f}, which is the modulation depth of "
            f"the inner-race line" +
            (", deep enough to be a rotating defect rather than leakage"
             if depth >= MODULATION_DEEP else ", shallow"))
    else:
        reasons.append(
            "sideband share not reported: the inner-race line it divides "
            "by is at the noise floor, so the ratio would be noise over "
            "noise. A ratio is only as meaningful as its denominator")

    return verdict, headline, reasons


def score_line(verdict, reference):
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    truth = CONDITIONS[index]
    called = {"ok": "healthy", "outer": "outer race",
              "inner": "inner race"}.get(verdict, verdict)
    return called == truth, truth


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 88_bearing_envelope_which_race.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    raw = d.papaya0.readVectProbeLive(d.bearing, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds, min_rows=0):
    """Readings for *seconds*, and at least *min_rows* of them.

    A FIXED WINDOW IS NOT A ROW COUNT. Each row is a whole feature
    vector, produced only when the board's analysis window is full, so
    how many arrive in six seconds is set by the design rather than by
    this script. Requiring eight rows after a six second wait is a guess
    about that cadence, and when the guess is wrong the run stops with
    "not enough to learn", which reads as a broken board instead of a
    window that was too short.

    The seconds are therefore a MINIMUM and *min_rows* is the real
    requirement. The hard bound still returns rather than hanging when a
    board has genuinely stopped producing.
    """
    rows = []
    started = time.monotonic()
    deadline = started + seconds
    hard_stop = started + max(seconds * 4.0, seconds + 20.0)
    while True:
        row = read_row(d)
        if row is not None:
            rows.append(row)
        now = time.monotonic()
        if now >= hard_stop:
            return rows
        if now >= deadline and len(rows) >= min_rows:
            return rows


def smooth(rows):
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA bearing envelope analyser")
    print("=" * 72)
    ok, expected, actual = bearing_check()
    print(f"Bearing: {BALLS} balls, shaft {SHAFT_HZ:.1f} Hz, "
          f"BPFO {BPFO_HZ:.1f} Hz, BPFI {BPFI_HZ:.1f} Hz")
    print(f"  outer + inner = {actual:.1f} Hz, balls x shaft = "
          f"{expected:.1f} Hz  ->  " + ("consistent" if ok else "WRONG"))
    if not ok:
        print("  That identity always holds. One of the four numbers above "
              "is copied wrongly,\n  and every band in the diagram is "
              "therefore pointed at the wrong frequency.")

    d = load_design()
    print(f"\nLearning the quiet state for {LEARN_SECONDS:.0f} s.")
    quiet = learn_quiet(collect(d, LEARN_SECONDS, min_rows=QUIET_ROWS))
    print(f"  quiet envelope level {quiet['env_rms']:.5f} g, "
          f"crest {quiet['crest']:.2f}")
    print(f"  alert at {ENVELOPE_ALERT:.0f}x that level or crest "
          f"{CREST_IMPULSIVE:.1f}")

    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)
    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row, quiet)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper():9s} {headline}")
            for r in reasons:
                print(f"           {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine: {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:10s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} ({100.0 * right / (right + wrong):.0f} "
              f"per cent)")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
