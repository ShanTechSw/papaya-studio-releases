"""Studio's end of the link.

The mirror of :mod:`papaya.link.server`. It composes commands, splits them
by the board's own chunk size, and waits for the result.

Telemetry arrives whenever it likes
-----------------------------------
This is the part that makes a naive client wrong. A gateway streams
probe batches on its own schedule, so a telemetry frame can land in the
middle of waiting for a command's result. A reader that took the next
frame to arrive as its answer would read a batch of samples as a status,
and a reader that discarded whatever was not its answer would drop the
samples on the floor.

So the receive path sorts: results satisfy the caller, telemetry queues
for whoever is drawing, events queue for whoever is diagnosing. Nothing
that arrived is thrown away because it was unexpected, because on this
link everything except the reply is unexpected.

Three threads, one socket
-------------------------
Once telemetry is running there are three callers: the command layer on
whatever thread issued a command, the reader draining batches, and the
input writer pushing setpoints. One socket and one decoder cannot serve
three of those at once -- two interleaved ``sendall`` calls produce a
frame that is half one command and half another, and two ``recv`` calls
split a frame across two decoders that each then resynchronise past it.
So every touch of the socket is serialised. A command holds the lock for
its whole exchange, which is correct rather than merely safe: batches
that arrive meanwhile are filed by the receive path that is already
running, so they are delayed and never lost.
"""
from __future__ import annotations

import socket
import threading
import time
from collections import deque
from typing import Deque, List, Optional, Tuple

from .protocol import (
    BOARD_CHUNK_SIZE, CommandOutcome, FrameDecoder, LinkFrame, MessageType,
    TransactionShape, command_messages, decode_command_result,
    decode_telemetry, encode, encode_subscribe, decode_welcome,
    LinkProtocolError,
)

#: A command's own deadline is the board's; this is the link's patience on
#: top of it, so a gateway that is merely slow is not mistaken for one that
#: has gone away.
DEFAULT_TIMEOUT_S = 5.0

#: How long :meth:`LinkClient.reset_board` is allowed to take.
#:
#: Deliberately separate from the timeout above, and much larger, because
#: it is not waiting for a message: it is waiting for a BOARD TO BOOT.
#: The gateway asserts reset for ``PP_RESET_ASSERT_MS`` (100 ms), releases
#: it, then waits ``PP_BOOT_SETTLE_MS`` (3000 ms) before it can answer,
#: and it is not reading its socket for any of that.
#:
#: 12 s is those 3.1 s with room for a slow network and a gateway that is
#: also relaying, and it is a CEILING rather than a cost: the call returns
#: as soon as the gateway answers. Nothing waits 12 s in the normal case.
#:
#: The number must stay above the library's own two constants. If a future
#: board boots slower, this is the line that has to move with it, and the
#: symptom of forgetting is a reset that works while reporting failure.
RESET_TIMEOUT_S = 12.0

_READ_SIZE = 8192

#: What :meth:`LinkClient.ping_if_free` returns when the link is in use.
#: A distinct object rather than True or None because it is neither: it
#: is proof of life obtained without asking, and a caller that treated it
#: as a round-trip time would report nonsense.
LINK_BUSY = object()


class LinkClientError(RuntimeError):
    """The link, not the board. A board that answers with an error status
    is a successful exchange; this is for exchanges that did not happen."""


class LinkClient:
    """One gateway, one board."""

    def __init__(self, timeout_s: float = DEFAULT_TIMEOUT_S) -> None:
        self._sock: Optional[socket.socket] = None
        self._decoder = FrameDecoder()
        self._timeout_s = float(timeout_s)
        self._seq = 0
        #: Serialises every touch of the socket and the decoder. See the
        #: three-threads note in the module docstring.
        self._lock = threading.RLock()
        #: Batches that arrived while something else was being waited for.
        self.telemetry: Deque[tuple] = deque(maxlen=256)
        #: Vector batches, kept apart from scalar ones because they are
        #: drawn by a different panel and arrive at a different rate.
        self.vector_telemetry: Deque[tuple] = deque(maxlen=64)
        #: Things the gateway wanted to say. Diagnosis is most of the
        #: support story for a link nobody can see.
        self.events: Deque[str] = deque(maxlen=64)
        #: Replies of the right type carrying a number no live request is
        #: waiting for. Non-zero means a command answered after its own
        #: wait had given up, which is the one thing that makes a
        #: reply-to-request mismatch possible at all.
        self.stale_replies = 0
        #: The largest telemetry batch this gateway said it can carry,
        #: or 0 when it said nothing.
        #:
        #: 0 IS NOT AN ERROR AND MUST NOT BE TREATED AS ONE. A gateway
        #: flashed before the welcome existed announces nothing, and the
        #: caller then keeps the conservative figure it has always used.
        #: That is the whole compatibility story in one attribute: an
        #: older gateway behaves exactly as it does today.
        self.gateway_max_batch_bytes = 0
        #: Batches this end threw away because the queue above was full.
        #: Host-side loss, and the reason it is counted separately is
        #: that it used to be reported as the gateway's.
        self.dropped_telemetry = 0
        self.dropped_vector_telemetry = 0

    # -- lifecycle ----------------------------------------------------

    def connect(self, host: str, port: int) -> bool:
        self.close()
        try:
            sock = socket.create_connection((host, port), timeout=self._timeout_s)
        except OSError:
            return False
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        sock.settimeout(self._timeout_s)
        with self._lock:
            self._sock = sock
            self._decoder = FrameDecoder()
            # The decoder was already rebuilt here; the queues were not,
            # so a fresh connection could deliver the previous one's
            # batches as its own.
            self.telemetry.clear()
            self.vector_telemetry.clear()
            self.events.clear()
            self.stale_replies = 0
        return True

    def close(self) -> None:
        with self._lock:
            sock, self._sock = self._sock, None
            if sock is None:
                return
            try:
                # Say goodbye if we can. The gateway flushes a half-sent
                # command on any exit, but a clean one lets it do that
                # without first waiting out a socket timeout.
                sock.sendall(encode(LinkFrame(type=MessageType.BYE)))
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    @property
    def is_connected(self) -> bool:
        return self._sock is not None

    # -- commands -----------------------------------------------------

    def execute(self, shape: TransactionShape, header: bytes, body: bytes = b"",
                expected_data: int = 0,
                timeout_s: Optional[float] = None) -> Tuple[CommandOutcome, bytes, bytes]:
        """Run one board command and return ``(outcome, status, data)``.

        An error status is a successful exchange: the board answered, and
        judging what it said is the caller's business because the caller
        knows what it asked for.
        """
        with self._lock:
            if self._sock is None:
                raise LinkClientError("not connected")

            self._seq = (self._seq + 1) & 0xFFFF
            frames = command_messages(shape, header, body, expected_data,
                                      self._seq)

            for frame in frames:
                if not self._send(frame):
                    raise LinkClientError(
                        "the link closed while sending a command")

            reply = self._await(MessageType.CMD_RESULT, timeout_s,
                                seq=self._seq)
            if reply is None:
                # Not a board timeout: the gateway itself never answered.
                return CommandOutcome.NO_ANSWER, b"", b""
            return decode_command_result(reply.payload)

    def reset_board(self, timeout_s: Optional[float] = None) -> bool:
        """Ask the gateway to drive the board's reset line.

        The one operation a cable cannot offer, and the reason a wedged
        board on a robot stops meaning a trip out to it.

        **This one waits longer than everything else, and it has to.**
        Every other request is a message the gateway answers as fast as
        its wire allows. This one makes the gateway assert reset, hold
        it, release it and then WAIT OUT THE BOARD'S BOOT before it can
        answer at all: about 3.1 seconds on the shipped timings, during
        which it is not reading its socket.

        Timed at the link's ordinary timeout it therefore reported
        failure on an operation that had SUCCEEDED. The connect dialog
        builds its client with a two second timeout, so connecting to a
        board that needed recovery went: probe silent, reset the board,
        give up after two seconds, refuse the connection -- while the
        board, three seconds later, came up perfectly. The next attempt
        then found a healthy board and worked.

        That is the "connecting takes several tries" complaint exactly,
        and it is measurable: a 20-cycle connect stress test scored ten
        of twenty, alternating pass and fail with mechanical regularity,
        because every failure left behind the healthy board the next
        attempt needed. Not flakiness. A deadline shorter than the thing
        it was waiting for.
        """
        with self._lock:
            if self._sock is None:
                raise LinkClientError("not connected")
            if timeout_s is None:
                timeout_s = max(self._timeout_s, RESET_TIMEOUT_S)
            return self._gateway_op(MessageType.RESET, b"", timeout_s)

    def ping(self, timeout_s: Optional[float] = None) -> Optional[float]:
        """Round-trip time in seconds, or None if nothing came back.

        Liveness, deliberately not discovery: a link that starts hunting
        the network the moment a packet is late turns a hiccup into a scan
        storm.
        """
        with self._lock:
            return self._ping_locked(timeout_s)

    def ping_if_free(self, timeout_s: Optional[float] = None):
        """Ping, but only if nothing else is using the link this instant.

        Returns the round trip, ``None`` when nothing came back, or
        :data:`LINK_BUSY` when somebody else holds it.

        For a heartbeat, and the distinction is the whole point. A
        heartbeat runs on the interface thread, and :meth:`ping` holds the
        link for its whole exchange, so a heartbeat tick that arrives
        during a design upload waits for the upload -- on the thread that
        draws. The window freezes, and it freezes hardest exactly when
        the most is happening.

        Busy is not a failure to be retried, either: another caller
        holding the link is a stronger proof of life than any ping,
        because that caller is mid-conversation with the board.
        """
        if not self._lock.acquire(blocking=False):
            return LINK_BUSY
        try:
            return self._ping_locked(timeout_s)
        finally:
            self._lock.release()

    def _ping_locked(self, timeout_s: Optional[float]) -> Optional[float]:
        """The exchange itself. The caller must hold the lock."""
        if self._sock is None:
            return None
        self._seq = (self._seq + 1) & 0xFFFF
        started = time.monotonic()
        if not self._send(LinkFrame(type=MessageType.PING, seq=self._seq)):
            return None
        if self._await(MessageType.PONG, timeout_s) is None:
            return None
        return time.monotonic() - started

    # -- telemetry ----------------------------------------------------

    def subscribe(self, probe_count: int, samples_per_batch: int,
                  scalar_bytes: int, vector_count: int = 0,
                  vector_bytes: int = 0, interval_ms: int = 20,
                  timeout_s: Optional[float] = None) -> bool:
        """Put the gateway on a polling schedule and start the stream.

        The lengths are stated here because this is the only end that can
        know them. On the board's wire a probe read is an opcode and then
        a payload, with no count anywhere in the exchange, and the board's
        own sizing comes from probe objects the running PROGRAM built -- a
        relay builds none, so a gateway that was not told would ask for
        nothing and get nothing back.
        """
        with self._lock:
            if self._sock is None:
                raise LinkClientError("not connected")
            # A NEW SUBSCRIPTION STARTS EMPTY. Frames the gateway had
            # already sent for the PREVIOUS one are still in these
            # queues, and nothing used to clear them: the next session
            # drained them and drew the old design's samples under the
            # new design's probe names. Worse, the stale batch set the
            # reader's first sequence number, and both gateways restart
            # their batch numbering per subscription, so the span the
            # drop figure is computed over wrapped to about 2^32 and the
            # strip reported a loss near 100% for the whole session.
            #
            # Cleared HERE rather than in the reader because the queues
            # belong to the link: whoever subscribes next inherits them
            # whether or not it is the same reader object.
            self.telemetry.clear()
            self.vector_telemetry.clear()
            payload = encode_subscribe(probe_count, samples_per_batch,
                                       scalar_bytes, vector_count,
                                       vector_bytes, interval_ms)
            return self._gateway_op(MessageType.SUBSCRIBE, payload, timeout_s)

    def unsubscribe(self, timeout_s: Optional[float] = None) -> bool:
        """Stop the stream. Safe to call on a link that is already down."""
        with self._lock:
            if self._sock is None:
                return True
            return self._gateway_op(MessageType.UNSUBSCRIBE, b"", timeout_s)

    def drain_telemetry(self) -> List[tuple]:
        """Take everything that has arrived, oldest first.

        Batches carry the sequence the board's own SPI monitoring does
        not, so a gap in it is the only honest signal that something was
        dropped.
        """
        return _drain(self.telemetry)

    def drain_vector_telemetry(self) -> List[tuple]:
        """The same, for the vector panel's own batches."""
        return _drain(self.vector_telemetry)

    def pump(self, timeout_s: float = 0.0) -> int:
        """Read whatever is waiting without expecting anything.

        For a caller that is only drawing: it wants telemetry to keep
        arriving between commands, not to issue one.
        """
        with self._lock:
            return len(self._receive(timeout_s, expect=None))

    # -- plumbing -----------------------------------------------------

    def _gateway_op(self, kind: MessageType, payload: bytes,
                    timeout_s: Optional[float]) -> bool:
        """One request the gateway performs locally, and its acknowledgement.

        Reset, subscribe and unsubscribe are the same exchange: ask, then
        wait for the same ``CMD_RESULT`` a relayed command answers with.
        They share it because they are the same KIND of thing -- something
        Studio asks for as an outcome, which the gateway carries out on
        its own side of the wire.

        The caller must hold the lock.
        """
        self._seq = (self._seq + 1) & 0xFFFF
        if not self._send(LinkFrame(type=kind, payload=payload,
                                    seq=self._seq)):
            return False
        reply = self._await(MessageType.CMD_RESULT, timeout_s,
                            seq=self._seq)
        if reply is None:
            return False
        outcome, _status, _data = decode_command_result(reply.payload)
        return outcome is CommandOutcome.ANSWERED

    def _send(self, frame: LinkFrame) -> bool:
        try:
            self._sock.sendall(encode(frame))
            return True
        except OSError:
            self._sock = None
            return False

    def _await(self, kind: MessageType, timeout_s: Optional[float],
               seq: Optional[int] = None) -> Optional[LinkFrame]:
        """Wait for the reply to ONE request, identified by its number.

        The header's sequence field exists for exactly this and both
        gateways echo the request's number into the result. Matching on
        the type alone credited a late reply to whichever command came
        next.

        That is not a tidiness point. When a wait times out -- a slow
        board exchange, or the multi-second write stall the Arduino sink
        tolerates -- the answer arrives afterwards and sits in the
        socket. The next command then took it, and the skew persisted
        one-for-one until a further timeout absorbed a frame. On a probe
        read there is no status to catch it with, so another command's
        payload reached the Monitor as samples; and subscribe,
        unsubscribe and reset accept any result at all, so a stale one
        could confirm an operation the gateway had refused.

        A frame of the right type carrying the wrong number is DROPPED
        rather than left in the stream: leaving it would only move the
        failure to the command after this one. ``seq`` is None only for
        callers that have no request to match, which is why it stays
        optional rather than becoming a silent no-op.
        """
        deadline = time.monotonic() + (
            self._timeout_s if timeout_s is None else timeout_s)
        want = None if seq is None else (int(seq) & 0xFFFF)
        while time.monotonic() < deadline:
            for frame in self._receive(0.1, expect=kind):
                if frame.type is not kind:
                    continue
                if want is not None and (frame.seq & 0xFFFF) != want:
                    self.stale_replies += 1
                    continue
                return frame
            if self._sock is None:
                return None
        return None

    def _receive(self, timeout_s: float,
                 expect: Optional[MessageType]) -> List[LinkFrame]:
        """Read, sort, and hand back only what the caller asked for.

        Telemetry and events are filed rather than returned or dropped:
        everything except the reply is unexpected on this link, so
        "unexpected" cannot mean "discard".
        """
        if self._sock is None:
            return []
        try:
            self._sock.settimeout(max(0.0, timeout_s))
            chunk = self._sock.recv(_READ_SIZE)
        except socket.timeout:
            return []
        except BlockingIOError:
            # A TIMEOUT OF EXACTLY ZERO IS NOT A SHORT TIMEOUT. It puts
            # the socket in non-blocking mode, and an idle socket then
            # raises BlockingIOError, which is an OSError but not a
            # socket.timeout. Falling into the clause below declared a
            # perfectly healthy link dead on the first quiet poll.
            #
            # ``pump`` and ``pump_telemetry`` both DEFAULT to 0.0, so
            # this was live for any caller that took the documented
            # default; the only shipped caller happens to pass 0.05.
            # An empty read is an empty read whichever way the socket
            # says so.
            return []
        except OSError:
            self._sock = None
            return []
        if not chunk:
            self._sock = None
            return []

        wanted: List[LinkFrame] = []
        for frame in self._decoder.feed(chunk):
            if frame.type is MessageType.TELEMETRY:
                # A FULL BOUNDED DEQUE DISCARDS THE OLDEST WITHOUT A
                # WORD, and that loss used to be invisible: the reader
                # saw the resulting jump in the gateway's slot numbering
                # and booked it as "the gateway let a poll go by", which
                # is exactly backwards. The gateway delivered them and
                # this end binned them. A command can hold the lock for
                # its whole exchange, so at a 20 ms interval one slow
                # exchange is easily a queue's worth.
                if len(self.telemetry) == self.telemetry.maxlen:
                    self.dropped_telemetry += 1
                self.telemetry.append(decode_telemetry(frame.payload))
            elif frame.type is MessageType.VECTOR_TELEMETRY:
                if (len(self.vector_telemetry)
                        == self.vector_telemetry.maxlen):
                    self.dropped_vector_telemetry += 1
                self.vector_telemetry.append(decode_telemetry(frame.payload))
            elif frame.type is MessageType.WELCOME:
                # UNSOLICITED, so it must be consumed here rather than
                # returned. A caller waiting for the reply to whatever it
                # sent first would otherwise be handed this instead, and
                # a welcome is not an answer to anything.
                try:
                    self.gateway_max_batch_bytes = decode_welcome(
                        frame.payload)
                except LinkProtocolError:
                    # A welcome nobody can read is not a reason to drop a
                    # working session. Keeping 0 means the caller uses
                    # the conservative default, which is what it would
                    # have done had the gateway never spoken.
                    self.gateway_max_batch_bytes = 0
            elif frame.type is MessageType.EVENT:
                self.events.append(frame.payload.decode("utf-8", "replace"))
            elif expect is None or frame.type is expect:
                wanted.append(frame)
        return wanted


def _drain(queue: Deque[tuple]) -> List[tuple]:
    """Empty a queue one item at a time, oldest first.

    ``list(q)`` then ``q.clear()`` looks equivalent and is not: anything
    the receive path appends between the two is cleared without ever
    having been read. One ``popleft`` per item cannot lose a batch that
    way, and a lost batch here is indistinguishable from a dropped one on
    the link -- which is exactly the diagnosis the sequence number exists
    to make possible.
    """
    out: List[tuple] = []
    while True:
        try:
            out.append(queue.popleft())
        except IndexError:
            return out


__all__ = ["LinkClient", "LinkClientError", "DEFAULT_TIMEOUT_S", "LINK_BUSY"]
