"""Host-side helpers for the unified ``signalSource`` block.

Two responsibilities:

1. **Wire encoding**: pack the ``signalSource`` parameter set into the
   PAPAYA command-frame parameter list expected by ``PP_SubFuncId.NewSignalSource``.
   The parameter layout is *positional and shape-aware*: positions 0..5 are
   the common header (shape / mode / trig_pol / n_periods / amplitude /
   offset); positions 6.. are shape-specific. See
   ``_SHAPE_PARAM_LAYOUT`` for the per-shape ordering.

2. **Reference compute**: pure-NumPy implementations of every shape.
   These formulas are the specification: the board's waveform engine
   reproduces them exactly, and any divergence is a bug on the board, not
   in the spec.

Adding a new shape:
  1. Append it to ``PP_WaveShape`` in ``papaya/enums.py`` (never renumber).
  2. Add the param-id list to ``_SHAPE_PARAM_LAYOUT`` below.
  3. Implement ``compute_<shape>`` in this file (NumPy reference).
  4. Implement the matching shape function on the board and wire its
     dispatch case.
  5. Add a golden-vector fixture so host and board are compared sample by
     sample.
  6. Add the block's documentation entry so the shape is described to
     users.
  7. (Optional) Add an ergonomic factory on ``signalSource`` for cleaner
     notebook use (e.g. ``signalSource.chirp(...)``).

The whole scheme is designed so that adding a shape NEVER breaks the wire
protocol: both old hosts and old firmware keep recognising every existing
opcode and shape ID. Only the **last** shape position changes per release.
"""

from __future__ import annotations

import math
import struct
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .enums import (
    PP_FuncParamId,
    PP_WaveMode,
    PP_WaveMultisinePhase,
    PP_WaveShape,
    PP_WaveTrigPol,
)


# ---------------------------------------------------------------------------
# Per-shape parameter layout
# ---------------------------------------------------------------------------
#
# Each entry maps the shape to the ordered list of "shape-specific" param
# names that follow the common header. The Python ``signalSource`` class
# and the firmware decoder share this ordering. Keep them in lockstep.
#
# Common header (positions 0..5) is implicit and always present:
#     0: shape       (Uint16)
#     1: mode        (Uint16)
#     2: trig_pol    (Uint16)
#     3: n_periods   (Uint32)
#     4: amplitude   (Real)
#     5: offset      (Real)
#
# All shape-specific params are emitted as ``TYPE_Real`` (float32) or
# ``TYPE_Uint16`` / ``TYPE_Uint32`` according to ``_PARAM_TYPE`` below.
# ---------------------------------------------------------------------------
_SHAPE_PARAM_LAYOUT: Dict[PP_WaveShape, Tuple[str, ...]] = {
    PP_WaveShape.Sine:        ("freq", "phase"),
    PP_WaveShape.Square:      ("freq", "phase"),
    PP_WaveShape.Triangle:    ("freq", "phase", "symmetry"),
    PP_WaveShape.Sawtooth:    ("freq", "phase", "direction"),  # 0=up, 1=down
    PP_WaveShape.Pulse:       ("freq", "phase", "duty"),
    PP_WaveShape.Sinc:        ("freq", "phase", "n_lobes"),
    PP_WaveShape.Gauspuls:    ("freq", "bw_fraction", "prf"),
    PP_WaveShape.DC:          (),  # uses only the offset header param
    PP_WaveShape.Arbitrary:   ("freq", "phase", "n_samples", "samples"),
    PP_WaveShape.LinearChirp: ("f0", "f1", "t_sweep", "phase"),
    PP_WaveShape.LogChirp:    ("f0", "f1", "t_sweep", "phase"),
    PP_WaveShape.Multisine:   ("f0", "df", "n_lines", "phase_scheme", "lfsr_seed"),
    PP_WaveShape.PRBS:        ("bits", "clock_div", "lfsr_seed"),
    PP_WaveShape.Step:        ("t_step", "value_before", "value_after"),
    PP_WaveShape.Ramp:        ("slope", "t_start", "sat_low", "sat_high"),
    PP_WaveShape.Impulse:     ("t_impulse",),
    PP_WaveShape.PulseTrain:  ("freq", "phase", "duty", "n_pulses", "prf"),
    # Dataset (17) is RETIRED on the board: slot playback is gone and the
    # firmware refuses shape 17 with BadParam, so signalSource refuses it
    # before the wire, naming signalSource.dataset(samples) as the
    # replacement. Positions: 6=freq, 7=phase, 8=dataset_slot.
    #
    # THIS ENTRY STAYS. That is a ratified decision, not an oversight, and
    # it was reviewed once precisely because the entry LOOKS like leftovers
    # from the retired mechanism. Three reasons, any one of which is enough:
    #
    #   1. The wire numbering is a contract with boards already in the
    #      field. 17 is a permanent hole; it is never reused and its
    #      neighbours never move.
    #   2. The PC simulation lane sends this small form, and cannot send
    #      the inline one. A simulated recording is unlimited in length by
    #      contract, while the inline create command has a hard ceiling of
    #      about eleven thousand samples (20 params of 1023 floats). A long
    #      recording physically cannot ride it: an attempt is on record
    #      that froze the app for a minute and then refused a 60001-sample
    #      recording, which is exactly the case simulation exists to serve.
    #   3. Shape 17 is the DISCRIMINATOR the simulator matches on to take
    #      the next out-of-band recording rather than read the block as an
    #      ordinary lookup table. Removing it means inventing a replacement
    #      convention, which is a protocol change for no user-visible gain.
    #
    # Removing it therefore costs either the any-length simulation promise
    # or a new wire convention, and buys nothing: the value is already
    # refused on the board lane and on the public API above.
    # Guarded by test_the_simulation_wire_keeps_the_small_dataset_command.
    PP_WaveShape.Dataset:     ("freq", "phase", "dataset_slot"),
}


# Per-param storage type. Anything not listed defaults to TYPE_Real (float32).
_PARAM_TYPE: Dict[str, PP_FuncParamId] = {
    "direction":     PP_FuncParamId.TYPE_Uint8,
    "n_lobes":       PP_FuncParamId.TYPE_Uint16,
    "n_samples":     PP_FuncParamId.TYPE_Uint16,
    "samples":       PP_FuncParamId.TYPE_RealArray,
    "n_lines":       PP_FuncParamId.TYPE_Uint16,
    "phase_scheme":  PP_FuncParamId.TYPE_Uint8,
    "lfsr_seed":     PP_FuncParamId.TYPE_Uint32,
    "bits":          PP_FuncParamId.TYPE_Uint8,
    "clock_div":     PP_FuncParamId.TYPE_Uint32,
    "n_pulses":      PP_FuncParamId.TYPE_Uint16,
    "dataset_slot":  PP_FuncParamId.TYPE_Uint16,
}


# Default values for every known param. Used when the user constructs a
# signalSource with a shape that requires a param the user didn't supply:
# we prefer a sensible default over a confusing error.
_PARAM_DEFAULTS: Dict[str, Any] = {
    "freq":         1.0,
    "phase":        0.0,
    "symmetry":     0.5,
    "direction":    0,
    "duty":         0.5,
    "n_lobes":      5,
    "bw_fraction":  0.5,
    "prf":          10.0,
    "f0":           1.0,
    "f1":           100.0,
    "t_sweep":      1.0,
    "df":           1.0,
    "n_lines":      8,
    "phase_scheme": int(PP_WaveMultisinePhase.Schroeder),
    "lfsr_seed":    0xACE1,
    "bits":         9,           # default m-sequence length = 511
    "clock_div":    1,
    "t_step":       0.0,
    "value_before": 0.0,
    "value_after":  1.0,
    "slope":        1.0,
    "t_start":      0.0,
    "sat_low":      -1.0e9,
    "sat_high":     1.0e9,
    "t_impulse":    0.0,
    "n_pulses":     1,
    "samples":      (0.0,),       # at least one sample
    "n_samples":    1,
    "dataset_slot": 0,
}


# Hard limits that mirror the firmware compile-time caps. The host enforces
# them BEFORE sending so the user gets a clear Python-side error rather than
# a silent firmware reject.
# Floats in ONE wire parameter. A descriptor packs its length into 12 bits,
# so 4092 bytes is the ceiling and 1023 floats is what fits whole.
PP_WAVE_ARB_SAMPLES_PER_PARAM = 1023
# Floats in a whole Arbitrary LUT. The samples travel as SEVERAL params and
# the firmware reassembles them, so the limit is how many params are left
# after the nine a signal source already uses, out of PP_FUNC_PARAM_MAX_NBR.
#
# This was 1023 - one parameter - and that was never a protocol limit. Frame
# chunking already lets a command body span as many frames as it needs; what
# capped the LUT was reading a single param at the other end.
PP_WAVE_ARB_PARAMS_MAX = 11             # params 9..19 of 20
#: What the WIRE could carry: 11253 samples. Not the limit that binds.
PP_WAVE_ARB_WIRE_MAX_SAMPLES = (PP_WAVE_ARB_SAMPLES_PER_PARAM
                                * PP_WAVE_ARB_PARAMS_MAX)

#: What actually binds, and the only restriction a table is under: the
#: board's FAST HEAP. The board copies the samples into its 110 KB fast
#: heap (shared with every other block) and iterates them there, because a
#: table read every tick has to be in fast memory and the board's large
#: heap is too slow for that. One table gets 20 KB of the 110 KB: 5120
#: float32 samples. The board enforces the same ceiling and refuses a
#: longer table rather than truncating it.
#:
#: It is comfortably under the wire's own 11253, which is why a recording
#: needs no upload and no slot: 20 KB is 6 of the 20 parameters a command
#: carries, so it travels in the block's own create command.
#:
#: It is a property of the TARGET's heap, not of this library, so a host
#: driving something other than the board raises it with
#: :func:`set_arb_max_samples`. The C++ library makes the same number
#: overridable for the same reason, and the PC simulator lifts both.
PP_WAVE_ARB_MAX_SAMPLES = 5120


def set_arb_max_samples(n_samples: int) -> None:
    """Set the table ceiling for a target whose heap is not the board's.

    The default is the board's: a table is copied into its 110 KB fast heap
    and one recording gets 20 KB of that. A PC simulation runs the same
    runtime with the host machine's heap behind it, where that number means
    nothing, and the deploy gate's advice to simulate a long recording
    instead is only true because this can be lifted.
    """
    global PP_WAVE_ARB_MAX_SAMPLES
    PP_WAVE_ARB_MAX_SAMPLES = int(n_samples)


def split_real_array(values: Sequence[float]) -> List[List[float]]:
    """A float array as the wire carries it: one list per parameter.

    Always at least one list, so a caller can loop over the result without
    special-casing an empty LUT.
    """
    out: List[List[float]] = [
        list(values[i:i + PP_WAVE_ARB_SAMPLES_PER_PARAM])
        for i in range(0, len(values), PP_WAVE_ARB_SAMPLES_PER_PARAM)
    ]
    return out or [[]]
PP_WAVE_MULTISINE_MAX_LINES = 64
PP_WAVE_N_PERIODS_MAX = 65535           # u16; 0 means "perpetual"
PP_WAVE_PRBS_BITS_MAX = 15              # m-sequence up to 2^15 - 1 = 32767 clocks

# Dataset FLASH slots: these are what the board reports and expects.
# STORAGE only: nothing plays a slot. A block's table is copied into the
# fast heap and iterated there, and a slot is not fast memory, so slot
# playback was retired. These describe what the flash holds, for a program
# that uses it as storage.
PP_DATASET_SLOT_COUNT = 8               # 8 fixed slots in the 4-8 MB flash region
PP_DATASET_MAX_SAMPLES = 114688         # 458752 B / 4 stored per slot on flash
# What a Dataset BLOCK plays, which is a fast-heap question and nothing to do
# with the flash: PP_WAVE_ARB_MAX_SAMPLES, because a recording IS an Arbitrary
# table now. Kept as a name because everything that asks "how long may a
# recording be" reads this one.
PP_DATASET_MAX_PLAY_SAMPLES = PP_WAVE_ARB_MAX_SAMPLES


def dataset_playback_freq(n_samples: int, fs: float) -> float:
    """Lookup-table traversals a second that play a recording once.

    A recording has one natural speed: the rate it was captured at. Playing
    it once over its own duration means traversing its N samples in N ticks
    of the design clock, so ``freq = Fs / N``.

    This is why a Dataset block takes no frequency. For a generated
    waveform a frequency is the signal and the user picks it; for a
    recording the traversal rate is a consequence of the recording. Studio,
    the two generated languages and this library all compute it here-shaped,
    so none of them can drift from the others.

    N is the WHOLE recording, never a clamped N. Clamping it here was a way
    of describing a recording that had been cut, and nothing cuts one any
    more: what fits on the board is a question validation answers by
    refusing. A clamp would have played a longer recording N/5120 times too
    fast, silently, which is worse than either.
    """
    n = max(1, int(n_samples))
    return float(fs) / float(n)


# ---------------------------------------------------------------------------
# Param-size helpers (used by Python code that builds wire frames)
# ---------------------------------------------------------------------------
_TYPE_TO_SIZE: Dict[PP_FuncParamId, int] = {
    PP_FuncParamId.TYPE_Real: 4,
    PP_FuncParamId.TYPE_Uint8: 1,
    PP_FuncParamId.TYPE_Uint16: 2,
    PP_FuncParamId.TYPE_Uint32: 4,
}


def param_type(name: str) -> PP_FuncParamId:
    """Return the wire type for a known signalSource param."""
    return _PARAM_TYPE.get(name, PP_FuncParamId.TYPE_Real)


def param_size(name: str, value: Any) -> int:
    """Return the wire size in bytes for `name`, given its current `value`.

    Variable-length params (TYPE_RealArray) size depends on the array length.
    """
    ptype = param_type(name)
    if ptype == PP_FuncParamId.TYPE_RealArray:
        seq = list(value or ())
        return 4 * len(seq)
    return _TYPE_TO_SIZE[ptype]


def header_params() -> Tuple[str, ...]:
    """Common header param names in wire order (positions 0..5)."""
    return ("shape", "mode", "trig_pol", "n_periods", "amplitude", "offset")


def shape_params(shape: PP_WaveShape) -> Tuple[str, ...]:
    """Shape-specific param names in wire order (positions 6+)."""
    return _SHAPE_PARAM_LAYOUT.get(shape, ())


#: Shape params whose wire value is a small integer but whose documented
#: spelling is a name. ``phase_scheme=PP_WaveMultisinePhase.Schroeder`` and
#: ``phase_scheme="Schroeder"`` must mean the same thing: the name is what the
#: parameter help, the manual and the block catalogue all show, so refusing it
#: made a Multisine unbuildable from the value the user was told to use.
_PARAM_ENUM: Dict[str, Any] = {
    "phase_scheme": PP_WaveMultisinePhase,
}


def coerce_param_value(name: str, value: Any) -> Any:
    """Validate + coerce a user-supplied param to its wire-ready Python type."""
    ptype = param_type(name)
    enum_cls = _PARAM_ENUM.get(name)
    if enum_cls is not None and isinstance(value, str):
        token = value.strip()
        if token and not token.lstrip("+-").isdigit():
            try:
                return int(enum_cls[token])
            except KeyError:
                # The trailing "No<name>" member of every wire enum is the
                # not-set sentinel, not something a user picks.
                choices = [m.name for m in enum_cls
                           if not m.name.startswith("No")]
                raise ValueError(
                    f"{name} '{token}' is not one of {', '.join(choices)}."
                ) from None
    if ptype == PP_FuncParamId.TYPE_RealArray:
        seq = list(value or ())
        if name == "samples":
            if not seq:
                raise ValueError("Arbitrary LUT requires at least one sample")
            if len(seq) > PP_WAVE_ARB_MAX_SAMPLES:
                raise ValueError(
                    f"Arbitrary LUT length {len(seq)} exceeds the firmware "
                    f"cap of {PP_WAVE_ARB_MAX_SAMPLES} samples. Resample or split."
                )
        return [float(x) for x in seq]
    if ptype == PP_FuncParamId.TYPE_Real:
        return float(value)
    return int(value)


def header_param_specs(
    shape: PP_WaveShape,
    mode: PP_WaveMode,
    trig_pol: PP_WaveTrigPol,
    n_periods: int,
    amplitude: float,
    offset: float,
) -> List[Tuple[str, PP_FuncParamId, int, Any]]:
    """Return the six common-header param descriptors as
    ``(name, type, size, value)`` tuples in wire order.
    """
    return [
        ("shape",     PP_FuncParamId.TYPE_Uint16, 2, int(shape) & 0xFFFF),
        ("mode",      PP_FuncParamId.TYPE_Uint16, 2, int(mode) & 0xFFFF),
        ("trig_pol",  PP_FuncParamId.TYPE_Uint16, 2, int(trig_pol) & 0xFFFF),
        ("n_periods", PP_FuncParamId.TYPE_Uint32, 4, int(n_periods) & 0xFFFFFFFF),
        ("amplitude", PP_FuncParamId.TYPE_Real,   4, float(amplitude)),
        ("offset",    PP_FuncParamId.TYPE_Real,   4, float(offset)),
    ]


def build_param_specs(
    shape: PP_WaveShape,
    mode: PP_WaveMode,
    trig_pol: PP_WaveTrigPol,
    n_periods: int,
    amplitude: float,
    offset: float,
    shape_kwargs: Dict[str, Any],
) -> List[Tuple[str, PP_FuncParamId, int, Any]]:
    """Build the full ordered list of param specs for a signalSource frame.

    Returns the list in the exact wire order the firmware expects.
    Validates user inputs (shape-specific constraints, n_periods cap, …).
    """
    if n_periods < 0 or n_periods > PP_WAVE_N_PERIODS_MAX:
        raise ValueError(
            f"n_periods must be 0..{PP_WAVE_N_PERIODS_MAX} (0 means perpetual)"
        )
    # Catch the n_periods=0 + RepeatN footgun at the host: the value
    # would otherwise be silently coerced to 1 by the run-time engine,
    # which is surprising (users expect 0 == perpetual everywhere).
    # Make the user pick: Perpetual mode OR n_periods >= 1.
    if mode == PP_WaveMode.RepeatN and n_periods == 0:
        raise ValueError(
            "RepeatN requires n_periods >= 1; use mode=Perpetual for unbounded run"
        )
    # TrigEdge fires n_periods cycles per edge; 0 is the block default and both
    # the firmware (clamps 0->1) and compute_reference (eff_n=max(n,1)) treat it
    # as one cycle. Coerce to 1 here so the wire ships an explicit, honest value
    # (never raise: unlike RepeatN, one-cycle-per-edge is a sensible default).
    if mode == PP_WaveMode.TrigEdge and n_periods == 0:
        n_periods = 1

    # Coerce trig_pol to be consistent with the trigger mode so a mode-invalid
    # polarity can never reach the firmware: edge modes use Rising/Falling, gate
    # modes use GateHigh/GateLow. The firmware + compute_reference already fall
    # back gracefully, but coercing here keeps the stored/wire value honest and
    # matches the GUI's mode<->polarity combo coupling. Non-trigger modes ignore
    # trig_pol, so leave it untouched there.
    _tp = int(trig_pol)
    if mode == PP_WaveMode.TrigEdge and _tp in (int(PP_WaveTrigPol.GateHigh),
                                                int(PP_WaveTrigPol.GateLow)):
        trig_pol = PP_WaveTrigPol.Rising
    elif mode == PP_WaveMode.TrigGate and _tp in (int(PP_WaveTrigPol.Rising),
                                                  int(PP_WaveTrigPol.Falling)):
        trig_pol = PP_WaveTrigPol.GateHigh

    specs = header_param_specs(shape, mode, trig_pol, n_periods, amplitude, offset)

    # Shape-specific params: fill defaults for anything the caller omitted,
    # validate per-shape constraints, then append in declared wire order.
    layout = shape_params(shape)
    resolved: Dict[str, Any] = {}
    for name in layout:
        if name in shape_kwargs and shape_kwargs[name] is not None:
            resolved[name] = coerce_param_value(name, shape_kwargs[name])
        elif name in _PARAM_DEFAULTS:
            resolved[name] = coerce_param_value(name, _PARAM_DEFAULTS[name])
        else:
            raise ValueError(
                f"signalSource(shape={shape.name}) is missing required param "
                f"'{name}' and no default exists"
            )

    # Shape-aware cross-validation
    _validate_shape_kwargs(shape, resolved)

    # Auto-fill n_samples from the actual LUT length so the user can't lie.
    if shape == PP_WaveShape.Arbitrary:
        resolved["n_samples"] = len(resolved["samples"])

    for name in layout:
        ptype = param_type(name)
        if ptype == PP_FuncParamId.TYPE_RealArray:
            # One param cannot carry the whole LUT: a descriptor packs its
            # length into 12 bits, so 1023 floats is the most that fits.
            # A longer one is split across consecutive params, which the
            # board reassembles into one table.
            # That is what makes an 11253-sample LUT reachable at all, and
            # it is the same technique UploadDatasetChunk has always used.
            for chunk in split_real_array(resolved[name]):
                specs.append((name, ptype, 4 * len(chunk), chunk))
            continue
        size = param_size(name, resolved[name])
        specs.append((name, ptype, size, resolved[name]))

    return specs


def _validate_shape_kwargs(shape: PP_WaveShape, kw: Dict[str, Any]) -> None:
    """Per-shape sanity checks that produce friendly host-side errors."""
    if shape in (PP_WaveShape.Sine, PP_WaveShape.Square, PP_WaveShape.Triangle,
                 PP_WaveShape.Sawtooth, PP_WaveShape.Pulse, PP_WaveShape.Sinc,
                 PP_WaveShape.Arbitrary):
        if kw.get("freq", 0.0) <= 0:
            raise ValueError(f"{shape.name}: freq must be > 0")
    if shape == PP_WaveShape.Pulse and not (0.0 < kw["duty"] < 1.0):
        raise ValueError("Pulse: duty must be in (0, 1)")
    if shape == PP_WaveShape.Triangle and not (0.0 < kw["symmetry"] < 1.0):
        raise ValueError("Triangle: symmetry must be in (0, 1)")
    if shape == PP_WaveShape.Sawtooth and kw["direction"] not in (0, 1):
        raise ValueError("Sawtooth: direction must be 0 (up) or 1 (down)")
    if shape == PP_WaveShape.Sinc and kw["n_lobes"] < 1:
        raise ValueError("Sinc: n_lobes must be >= 1")
    if shape == PP_WaveShape.Gauspuls:
        if not (0.0 < kw["bw_fraction"] < 1.0):
            raise ValueError("Gauspuls: bw_fraction must be in (0, 1)")
        if kw["prf"] <= 0:
            raise ValueError("Gauspuls: prf must be > 0")
    if shape in (PP_WaveShape.LinearChirp, PP_WaveShape.LogChirp):
        if kw["f0"] <= 0 or kw["f1"] <= 0:
            raise ValueError(f"{shape.name}: f0 and f1 must be > 0")
        if kw["t_sweep"] <= 0:
            raise ValueError(f"{shape.name}: t_sweep must be > 0")
        if shape == PP_WaveShape.LogChirp and kw["f0"] == kw["f1"]:
            raise ValueError("LogChirp: f0 == f1 collapses to a constant freq")
    if shape == PP_WaveShape.Multisine:
        if kw["df"] <= 0:
            raise ValueError("Multisine: df must be > 0")
        if not (1 <= kw["n_lines"] <= PP_WAVE_MULTISINE_MAX_LINES):
            raise ValueError(
                f"Multisine: n_lines must be 1..{PP_WAVE_MULTISINE_MAX_LINES}"
            )
    if shape == PP_WaveShape.PRBS:
        if not (2 <= kw["bits"] <= PP_WAVE_PRBS_BITS_MAX):
            raise ValueError(
                f"PRBS: bits must be 2..{PP_WAVE_PRBS_BITS_MAX} "
                f"(m-sequence length = 2^bits - 1)"
            )
        if kw["clock_div"] < 1:
            raise ValueError("PRBS: clock_div must be >= 1")
        if int(kw["lfsr_seed"]) == 0:
            raise ValueError("PRBS: lfsr_seed must be non-zero (all-zero state is a fixed point)")
    if shape == PP_WaveShape.Step:
        if kw["t_step"] < 0:
            raise ValueError("Step: t_step must be >= 0")
    if shape == PP_WaveShape.Ramp:
        if kw["sat_low"] > kw["sat_high"]:
            raise ValueError("Ramp: sat_low must be <= sat_high")
    if shape == PP_WaveShape.Impulse and kw["t_impulse"] < 0:
        raise ValueError("Impulse: t_impulse must be >= 0")
    if shape == PP_WaveShape.PulseTrain:
        if not (0.0 < kw["duty"] < 1.0):
            raise ValueError("PulseTrain: duty must be in (0, 1)")
        if kw["n_pulses"] < 1:
            raise ValueError("PulseTrain: n_pulses must be >= 1")
        if kw["prf"] <= 0:
            raise ValueError("PulseTrain: prf must be > 0")
    if shape == PP_WaveShape.Dataset:
        if kw.get("freq", 0.0) <= 0:
            raise ValueError("Dataset: freq (playback rate) must be > 0")
        if not (0 <= int(kw["dataset_slot"]) < PP_DATASET_SLOT_COUNT):
            raise ValueError(
                f"Dataset: dataset_slot must be 0..{PP_DATASET_SLOT_COUNT - 1}"
            )


def serial_body_size(specs: Sequence[Tuple[str, PP_FuncParamId, int, Any]]) -> int:
    """Total bytes the param descriptors+payloads contribute to the frame body.

    Mirrors ``CTX.serialize_command_body``: each param takes a 2-byte
    descriptor (PP_PARAM_INFO_SIZE) + ``size`` payload bytes. The final
    body-CRC the firmware appends is NOT counted here; callers add
    PP_FIXED_SIZE (header) to get the value to feed to prepare_cmd_header.
    """
    return sum(2 + size for (_n, _t, size, _v) in specs)


# ---------------------------------------------------------------------------
# Reference compute: the pure-NumPy specification of every shape
# ---------------------------------------------------------------------------
#
# Every function returns a 1-D NumPy array of float32 samples. The board
# produces numerically-identical output (within atol=1e-6) when fed the
# same params at the same Fs; golden-vector fixtures compare host against
# device with this as the reference.
#
# Notes:
#   * `t` is sample time in seconds: t = np.arange(n) / fs
#   * `amplitude` and `offset` are applied as a final post-scale; the
#     per-shape function returns the unscaled shape.
#   * Mode/trigger logic lives in `compute_with_mode` below; the per-shape
#     functions are stateless.


def compute_sine(t: np.ndarray, freq: float, phase: float) -> np.ndarray:
    return np.sin(2 * np.pi * freq * t + phase).astype(np.float32)


def compute_square(t: np.ndarray, freq: float, phase: float) -> np.ndarray:
    return np.sign(np.sin(2 * np.pi * freq * t + phase)).astype(np.float32)


def compute_triangle(t: np.ndarray, freq: float, phase: float, symmetry: float = 0.5) -> np.ndarray:
    # Asymmetric triangle: rises for `symmetry` fraction of period, falls otherwise.
    # symmetry=0.5 → symmetric triangle; symmetry→0 → backwards sawtooth; symmetry→1 → sawtooth.
    period_frac = ((freq * t + phase / (2 * np.pi)) % 1.0)
    rising = period_frac < symmetry
    y = np.empty_like(t, dtype=np.float32)
    y[rising] = -1.0 + 2.0 * (period_frac[rising] / max(symmetry, 1e-9))
    y[~rising] = 1.0 - 2.0 * ((period_frac[~rising] - symmetry) / max(1.0 - symmetry, 1e-9))
    return y


def compute_sawtooth(t: np.ndarray, freq: float, phase: float, direction: int = 0) -> np.ndarray:
    period_frac = ((freq * t + phase / (2 * np.pi)) % 1.0)
    y = (2.0 * period_frac - 1.0).astype(np.float32)
    if direction:
        y = -y
    return y


def compute_pulse(t: np.ndarray, freq: float, phase: float, duty: float) -> np.ndarray:
    period_frac = ((freq * t + phase / (2 * np.pi)) % 1.0)
    return np.where(period_frac < duty, 1.0, -1.0).astype(np.float32)


def compute_sinc(t: np.ndarray, freq: float, phase: float, n_lobes: int) -> np.ndarray:
    # Periodic sinc: place a main lobe + (n_lobes-1) side lobes per period
    # T = 1/freq. Each repetition is centred at k*T.
    T = 1.0 / freq
    centred = ((t + phase / (2 * np.pi * freq)) + T / 2.0) % T - T / 2.0
    x = 2 * n_lobes * centred / T
    # Avoid the divide-by-zero at x==0 entirely (sin(0)/0 is the limit = 1).
    numer = np.sin(np.pi * x)
    denom = np.pi * x
    y = np.divide(numer, denom, out=np.ones_like(x, dtype=np.float64),
                  where=np.abs(denom) > 1e-12)
    return y.astype(np.float32)


def compute_gauspuls(t: np.ndarray, freq: float, bw_fraction: float, prf: float) -> np.ndarray:
    # Gaussian-modulated sinusoid with fractional bandwidth `bw_fraction`,
    # repeating at PRF (pulse repetition frequency).
    # Bandwidth-to-sigma conversion: the fractional bandwidth is measured
    # at the -6 dB points of the Gaussian envelope's spectrum.
    T = 1.0 / prf
    # centre each pulse mid-period so the envelope decays toward both edges
    centred = ((t + T / 2.0) % T) - T / 2.0
    fv = -(bw_fraction * freq) ** 2 / (4 * np.log(0.5))   # variance of envelope
    envelope = np.exp(-centred ** 2 / (2 * fv))
    carrier = np.cos(2 * np.pi * freq * centred)
    return (envelope * carrier).astype(np.float32)


def compute_dc(t: np.ndarray) -> np.ndarray:
    # DC's value is the `offset` header param; the shape contribution is 0.
    return np.zeros_like(t, dtype=np.float32)


def compute_arbitrary(t: np.ndarray, freq: float, phase: float,
                      samples: Sequence[float]) -> np.ndarray:
    arr = np.asarray(samples, dtype=np.float32)
    N = len(arr)
    if N == 0:
        return np.zeros_like(t, dtype=np.float32)
    period_frac = ((freq * t + phase / (2 * np.pi)) % 1.0)
    idx_f = period_frac * N
    i0 = np.floor(idx_f).astype(int) % N
    i1 = (i0 + 1) % N
    frac = idx_f - np.floor(idx_f)
    return ((1.0 - frac) * arr[i0] + frac * arr[i1]).astype(np.float32)


def compute_dataset(t: np.ndarray, freq: float, phase: float,
                    samples: Optional[Sequence[float]] = None) -> np.ndarray:
    """Host reference for the Dataset shape.

    A recording IS an Arbitrary table: the block carries its samples and
    iterates them, so the reference is exactly :func:`compute_arbitrary`
    over the WHOLE recording.

    Nothing is cut here. The prefix this used to take was the old
    play-from-flash model, and against an uncut recording it was actively
    wrong: paired with the traversal rate Fs/N of the full recording, it
    stretched the first 5120 samples over the whole period and played a
    signal nobody chose. What fits on the board is a question validation
    answers, by refusing before anything is generated.

    ``samples`` must be passed by the caller that wants a reference; with
    none available the reference is silent (zeros).
    """
    if samples is None:
        return np.zeros_like(t, dtype=np.float32)
    arr = np.asarray(samples, dtype=np.float32)
    return compute_arbitrary(t, freq, phase, arr)


def _chirp_time_for_mode(shape: "PP_WaveShape", mode: "PP_WaveMode",
                        t: np.ndarray, kw: Dict[str, Any]) -> np.ndarray:
    """The time a chirp is evaluated at, given the run mode.

    EVERY MODE EXCEPT OneShot REPEATS THE SWEEP. A chirp's period is t_sweep,
    so a mode that runs for several periods runs several sweeps, and one that
    runs for ever sweeps for ever. That is what these modes mean for every
    other shape, and a chirp is not special.

    Until 2026-08-29 no mode repeated: a chirp swept once and then held f1 for
    ever, so a capture longer than t_sweep was mostly one fixed tone. Measured,
    a 40 s capture of a 10 s sweep put 55 % of its power in the single line at
    f1, and 2.3 % once the sweep repeated. Perpetual was fixed then; RepeatN,
    TrigGate and TrigEdge above one period had the same defect and are fixed
    here, because "repeat 3 times" plainly means three sweeps and not one
    sweep followed by two sweeps' worth of a held tone.

    OneShot is deliberately excluded. It means sweep once, its run ends when
    the sweep does, and the hold past the end is documented behaviour of a
    tail its own termination never reaches.

    The board wraps the time; this wraps it the same way, because this file is
    the reference the board is checked against and a preview that disagreed
    with the board would be worse than no preview.

    The run LENGTH is untouched in both lanes: termination counts raw samples,
    and the wrap changes only which point of the sweep each sample sits at.
    """
    if mode == PP_WaveMode.OneShot:
        return t
    if shape not in (PP_WaveShape.LinearChirp, PP_WaveShape.LogChirp):
        return t
    t_sweep = float(kw.get("t_sweep", 0.0) or 0.0)
    if t_sweep <= 0.0:
        return t
    return np.mod(t, t_sweep)


def compute_linear_chirp(t: np.ndarray, f0: float, f1: float, t_sweep: float,
                         phase: float) -> np.ndarray:
    # Linear instantaneous frequency: f(t) = f0 + (f1-f0) * t / t_sweep.
    # Phase = 2π ∫₀^t f(τ) dτ = 2π (f0·t + (f1-f0) t²/(2·t_sweep)).
    # After t_sweep, hold at f1 (so the post-sweep output is sin(2π f1 t + …)).
    sweep_mask = t <= t_sweep
    t_eff = np.where(sweep_mask, t, t_sweep)
    k = (f1 - f0) / t_sweep
    inst_phase = 2 * np.pi * (f0 * t_eff + 0.5 * k * t_eff ** 2) + phase
    # Past t_sweep: keep advancing at f1
    tail = np.maximum(t - t_sweep, 0.0)
    inst_phase = inst_phase + 2 * np.pi * f1 * tail
    return np.sin(inst_phase).astype(np.float32)


def compute_log_chirp(t: np.ndarray, f0: float, f1: float, t_sweep: float,
                      phase: float) -> np.ndarray:
    # Exponential / log chirp: f(t) = f0 * (f1/f0)^(t/t_sweep).
    # Phase = 2π ∫₀^t f(τ) dτ = 2π f0 t_sweep / ln(f1/f0) * ((f1/f0)^(t/t_sweep) − 1).
    ratio = f1 / f0
    if ratio == 1.0:
        return compute_sine(t, f0, phase)
    sweep_mask = t <= t_sweep
    t_eff = np.where(sweep_mask, t, t_sweep)
    K = f0 * t_sweep / np.log(ratio)
    sweep_phase = 2 * np.pi * K * (ratio ** (t_eff / t_sweep) - 1.0) + phase
    tail = np.maximum(t - t_sweep, 0.0)
    sweep_phase = sweep_phase + 2 * np.pi * f1 * tail
    return np.sin(sweep_phase).astype(np.float32)


def compute_multisine(t: np.ndarray, f0: float, df: float, n_lines: int,
                      phase_scheme: int, lfsr_seed: int = 0xACE1) -> np.ndarray:
    # Sum of n_lines equally-spaced sinusoids starting at f0, spaced by df.
    # Schroeder phases minimise crest factor; random uses an LCG seeded by lfsr_seed;
    # all-zero is the diagnostic high-crest case.
    n_lines = int(n_lines)
    if phase_scheme == int(PP_WaveMultisinePhase.Schroeder):
        # Schroeder phase_k = -π k (k-1) / N
        phases = -np.pi * np.arange(n_lines) * (np.arange(n_lines) - 1) / max(n_lines, 1)
    elif phase_scheme == int(PP_WaveMultisinePhase.Random):
        # Park-Miller LCG to get reproducible host/firmware-parity phases.
        rng = np.empty(n_lines, dtype=np.float64)
        s = int(lfsr_seed) & 0x7FFFFFFF
        if s == 0:
            s = 1
        for k in range(n_lines):
            # True Park-Miller/Lehmer MINSTD: x = (a*x) mod (2**31 - 1), a=48271.
            # This MUST match the board, which uses `% 0x7FFFFFFF`.
            # The previous
            # `& 0x7FFFFFFF` computed x mod 2**31 -- NOT the MINSTD generator --
            # so the host-preview phases diverged from the on-device phases for
            # every line k >= 1, making the Studio preview mismatch the hardware.
            s = (s * 48271) % 0x7FFFFFFF
            rng[k] = s / 2147483647.0
        phases = 2 * np.pi * rng
    else:
        phases = np.zeros(n_lines, dtype=np.float64)

    out = np.zeros_like(t, dtype=np.float64)
    for k in range(n_lines):
        out += np.sin(2 * np.pi * (f0 + k * df) * t + phases[k])
    # Normalise so the peak amplitude is ~1 (independent of n_lines)
    out *= 1.0 / max(n_lines, 1)
    return out.astype(np.float32)


def compute_prbs(t: np.ndarray, fs: float, bits: int, clock_div: int,
                 lfsr_seed: int) -> np.ndarray:
    # Fibonacci LFSR: one bit per `clock_div` host samples. Output ±1.
    # Taps match maximal-length sequences for bits = 2..15. The shift register
    # is `bits` wide; the new bit is XOR of the tapped positions.
    taps_table = {
        2:  (2, 1),
        3:  (3, 2),
        4:  (4, 3),
        5:  (5, 3),
        6:  (6, 5),
        7:  (7, 6),
        8:  (8, 6, 5, 4),
        9:  (9, 5),
        10: (10, 7),
        11: (11, 9),
        12: (12, 11, 10, 4),
        13: (13, 12, 11, 8),
        14: (14, 13, 12, 2),
        15: (15, 14),
    }
    taps = taps_table[int(bits)]
    state = int(lfsr_seed) & ((1 << int(bits)) - 1)
    if state == 0:
        state = 1
    n = len(t)
    out = np.empty(n, dtype=np.float32)
    bit = 1
    clock_count = 0
    for i in range(n):
        if clock_count == 0:
            new = 0
            for tap in taps:
                new ^= (state >> (tap - 1)) & 1
            state = ((state << 1) | new) & ((1 << int(bits)) - 1)
            bit = 1 if (state & 1) else -1
        out[i] = bit
        clock_count = (clock_count + 1) % max(int(clock_div), 1)
    return out


def compute_step(t: np.ndarray, t_step: float, value_before: float, value_after: float) -> np.ndarray:
    return np.where(t >= t_step, value_after, value_before).astype(np.float32)


def compute_ramp(t: np.ndarray, slope: float, t_start: float,
                 sat_low: float, sat_high: float) -> np.ndarray:
    raw = np.where(t >= t_start, slope * (t - t_start), 0.0)
    return np.clip(raw, sat_low, sat_high).astype(np.float32)


def compute_impulse(t: np.ndarray, fs: float, t_impulse: float) -> np.ndarray:
    # Single-sample Kronecker δ at the sample nearest t_impulse.
    out = np.zeros_like(t, dtype=np.float32)
    if t_impulse < 0:
        return out
    idx = int(round(t_impulse * fs))
    if 0 <= idx < len(out):
        out[idx] = 1.0
    return out


def compute_pulse_train(t: np.ndarray, freq: float, phase: float, duty: float,
                        n_pulses: int, prf: float) -> np.ndarray:
    # `n_pulses` rectangular pulses of frequency `freq` and duty `duty`,
    # repeated as a group at `prf`. Outside the active pulses → 0.
    period_pulse = 1.0 / freq                      # within a pulse
    period_group = max(n_pulses * period_pulse, 1.0 / max(prf, 1e-9))
    out = np.zeros_like(t, dtype=np.float32)
    rel = (t + phase / (2 * np.pi * freq)) % period_group
    in_burst = rel < (n_pulses * period_pulse)
    within = rel % period_pulse
    out = np.where(in_burst & (within < duty * period_pulse), 1.0, 0.0).astype(np.float32)
    return out


# ---------------------------------------------------------------------------
# High-level compute (shape dispatch + mode/trigger state machine)
# ---------------------------------------------------------------------------
def _shape_period_seconds(shape: PP_WaveShape, kw: Dict[str, Any]) -> float:
    """Return what 'one period' means in seconds for the given shape.

    Used by RepeatN/OneShot to translate ``n_periods`` into a duration.
    """
    if shape in (PP_WaveShape.Sine, PP_WaveShape.Square, PP_WaveShape.Triangle,
                 PP_WaveShape.Sawtooth, PP_WaveShape.Pulse, PP_WaveShape.Arbitrary,
                 PP_WaveShape.Dataset):
        return 1.0 / float(kw["freq"])
    if shape == PP_WaveShape.Sinc:
        return 1.0 / float(kw["freq"])
    if shape == PP_WaveShape.Gauspuls:
        return 1.0 / float(kw["prf"])
    if shape == PP_WaveShape.DC:
        return float("inf")
    if shape in (PP_WaveShape.LinearChirp, PP_WaveShape.LogChirp):
        return float(kw["t_sweep"])
    if shape == PP_WaveShape.Multisine:
        return 1.0 / float(kw["df"])
    if shape == PP_WaveShape.PRBS:
        period_samples = ((1 << int(kw["bits"])) - 1) * int(kw["clock_div"])
        return period_samples  # caller multiplies by 1/fs when in samples form
    if shape in (PP_WaveShape.Step, PP_WaveShape.Ramp, PP_WaveShape.Impulse):
        return float("inf")    # transients have no natural period; OneShot only
    if shape == PP_WaveShape.PulseTrain:
        return float(kw["n_pulses"]) / float(kw["freq"])
    return float("inf")


def _shape_terminal_value(shape: PP_WaveShape, kw: Dict[str, Any], offset: float, amplitude: float) -> float:
    """Output held after Finished / between triggers / when gate is off."""
    if shape == PP_WaveShape.DC:
        return offset
    if shape == PP_WaveShape.Step:
        return amplitude * float(kw["value_after"]) + offset
    if shape == PP_WaveShape.Ramp:
        return amplitude * float(kw["sat_high"]) + offset
    if shape == PP_WaveShape.Impulse:
        return offset
    # Sinusoidal / periodic / sweep shapes settle at offset (DC component is 0)
    return offset


def _compute_shape(shape: PP_WaveShape, t: np.ndarray, fs: float, kw: Dict[str, Any]) -> np.ndarray:
    if shape == PP_WaveShape.Sine:        return compute_sine(t, kw["freq"], kw["phase"])
    if shape == PP_WaveShape.Square:      return compute_square(t, kw["freq"], kw["phase"])
    if shape == PP_WaveShape.Triangle:    return compute_triangle(t, kw["freq"], kw["phase"], kw["symmetry"])
    if shape == PP_WaveShape.Sawtooth:    return compute_sawtooth(t, kw["freq"], kw["phase"], kw["direction"])
    if shape == PP_WaveShape.Pulse:       return compute_pulse(t, kw["freq"], kw["phase"], kw["duty"])
    if shape == PP_WaveShape.Sinc:        return compute_sinc(t, kw["freq"], kw["phase"], kw["n_lobes"])
    if shape == PP_WaveShape.Gauspuls:    return compute_gauspuls(t, kw["freq"], kw["bw_fraction"], kw["prf"])
    if shape == PP_WaveShape.DC:          return compute_dc(t)
    if shape == PP_WaveShape.Arbitrary:   return compute_arbitrary(t, kw["freq"], kw["phase"], kw["samples"])
    if shape == PP_WaveShape.LinearChirp: return compute_linear_chirp(t, kw["f0"], kw["f1"], kw["t_sweep"], kw["phase"])
    if shape == PP_WaveShape.LogChirp:    return compute_log_chirp(t, kw["f0"], kw["f1"], kw["t_sweep"], kw["phase"])
    if shape == PP_WaveShape.Multisine:   return compute_multisine(t, kw["f0"], kw["df"], kw["n_lines"], kw["phase_scheme"], kw["lfsr_seed"])
    if shape == PP_WaveShape.PRBS:        return compute_prbs(t, fs, kw["bits"], kw["clock_div"], kw["lfsr_seed"])
    if shape == PP_WaveShape.Step:        return compute_step(t, kw["t_step"], kw["value_before"], kw["value_after"])
    if shape == PP_WaveShape.Ramp:        return compute_ramp(t, kw["slope"], kw["t_start"], kw["sat_low"], kw["sat_high"])
    if shape == PP_WaveShape.Impulse:     return compute_impulse(t, fs, kw["t_impulse"])
    if shape == PP_WaveShape.PulseTrain:  return compute_pulse_train(t, kw["freq"], kw["phase"], kw["duty"], kw["n_pulses"], kw["prf"])
    if shape == PP_WaveShape.Dataset:     return compute_dataset(t, kw["freq"], kw["phase"], kw.get("samples"))
    raise ValueError(f"Unknown shape: {shape}")


def compute_reference(
    shape: PP_WaveShape,
    fs: float,
    n_samples: int,
    *,
    mode: PP_WaveMode = PP_WaveMode.Perpetual,
    n_periods: int = 0,
    amplitude: float = 1.0,
    offset: float = 0.0,
    trigger: Optional[np.ndarray] = None,
    trig_pol: PP_WaveTrigPol = PP_WaveTrigPol.Rising,
    **shape_kwargs: Any,
) -> np.ndarray:
    """Host-side reference for the full signalSource pipeline (shape + mode).

    This is the function the golden-vector fixtures compare against. The
    board produces numerically-identical output (to within float32
    round-off) when fed the same params.

    ``trigger`` is required when mode is TrigEdge or TrigGate; it must be a
    1-D array of length ``n_samples`` whose values are interpreted as
    high (>0.5) or low (<=0.5).
    """
    t_all = np.arange(n_samples, dtype=np.float64) / fs

    # Resolve defaults into a complete shape_kwargs dict
    kw: Dict[str, Any] = {}
    for name in shape_params(shape):
        if name in shape_kwargs and shape_kwargs[name] is not None:
            kw[name] = coerce_param_value(name, shape_kwargs[name])
        elif name in _PARAM_DEFAULTS:
            kw[name] = coerce_param_value(name, _PARAM_DEFAULTS[name])

    # Dataset carries only the slot index on the wire; the samples (needed for a
    # host preview/reference) ride alongside as a non-wire kwarg. Mirror the
    # on-device Arbitrary playback of the uploaded FLASH payload.
    if shape == PP_WaveShape.Dataset and shape_kwargs.get("samples") is not None:
        kw["samples"] = [float(x) for x in shape_kwargs["samples"]]

    terminal = _shape_terminal_value(shape, kw, offset, amplitude)

    if mode == PP_WaveMode.Perpetual:
        shape_vals = _compute_shape(
            shape, _chirp_time_for_mode(shape, mode, t_all, kw), fs, kw)
        return (amplitude * shape_vals + offset).astype(np.float32)

    if mode in (PP_WaveMode.RepeatN, PP_WaveMode.OneShot):
        eff_n = 1 if mode == PP_WaveMode.OneShot else max(int(n_periods), 1)
        period_s = _shape_period_seconds(shape, kw)
        # PRBS's "period" comes back in samples, so convert to seconds for the gate
        if shape == PP_WaveShape.PRBS:
            period_s = period_s / fs
        duration_s = period_s * eff_n if math.isfinite(period_s) else float("inf")
        if math.isinf(duration_s):
            # Transients (Step/Ramp/Impulse): one "period" = the whole run; just compute.
            shape_vals = _compute_shape(shape, t_all, fs, kw)
            return (amplitude * shape_vals + offset).astype(np.float32)
        active = t_all < duration_s        # the RAW clock sets the run length
        # ...and the WRAPPED one sets the waveform, so a RepeatN chirp runs
        # for exactly as long as it always did and now sweeps throughout.
        shape_vals = _compute_shape(
            shape, _chirp_time_for_mode(shape, mode, t_all, kw), fs, kw)
        scaled = amplitude * shape_vals + offset
        return np.where(active, scaled, terminal).astype(np.float32)

    if mode in (PP_WaveMode.TrigEdge, PP_WaveMode.TrigGate):
        if trigger is None:
            raise ValueError("trigger array required for TrigEdge/TrigGate modes")
        trig = np.asarray(trigger, dtype=np.float64)
        if len(trig) != n_samples:
            raise ValueError("trigger length must match n_samples")
        out = np.full(n_samples, terminal, dtype=np.float32)

        period_s = _shape_period_seconds(shape, kw)
        if shape == PP_WaveShape.PRBS:
            period_s = period_s / fs
        eff_n = max(int(n_periods), 1) if n_periods > 0 else 1
        run_samples = (int(round(period_s * eff_n * fs))
                       if math.isfinite(period_s)
                       else n_samples)
        # Pre-compute the full shape; we slice it per run using fresh phase.
        # Each TrigEdge run starts a new local timeline at 0; that's the
        # cleanest semantic for system-ID workflows.
        #
        # This one feeds TrigGate, whose clock free runs from the start of the
        # design and is merely blanked while the gate is shut, so a chirp on it
        # needs the same wrap every other repeating mode gets.
        shape_vals = _compute_shape(
            shape, _chirp_time_for_mode(shape, mode, t_all, kw), fs, kw)
        scaled = amplitude * shape_vals + offset

        # Detect edges / gate windows from the trigger signal.
        if mode == PP_WaveMode.TrigEdge:
            prev = np.concatenate(([0.0], trig[:-1]))
            if trig_pol == PP_WaveTrigPol.Falling:
                edges = (prev > 0.5) & (trig <= 0.5)
            else:
                edges = (prev <= 0.5) & (trig > 0.5)
            i = 0
            while i < n_samples:
                if not edges[i]:
                    i += 1
                    continue
                # Restart timeline at i; play `run_samples` of the shape
                end = min(i + run_samples, n_samples)
                local_t = np.arange(end - i, dtype=np.float64) / fs
                # Wrapped as well. One edge with n_periods = 1 is a single
                # sweep and the wrap does nothing there, which is why TrigEdge
                # looked correct; with n_periods above 1 it had the same defect
                # as RepeatN and the local clock is what has to wrap.
                local_shape = _compute_shape(
                    shape, _chirp_time_for_mode(shape, mode, local_t, kw),
                    fs, kw)
                out[i:end] = amplitude * local_shape + offset
                i = end
            return out

        # TrigGate: gate windows
        if trig_pol == PP_WaveTrigPol.GateLow:
            gate = trig <= 0.5
        else:
            gate = trig > 0.5
        # Free-running shape, blanked when gate is off.
        return np.where(gate, scaled, terminal).astype(np.float32)

    raise ValueError(f"Unsupported mode: {mode}")


# ===========================================================================
# Analog-output predefined-waveform frame  ("source generator on the DAC")
# ===========================================================================
#
# The analogOut block in PredefinedWaveform mode ships a compact 36-byte frame
# to the board, which synthesises ONE natural cycle of the shape and
# loops it forever (zero runtime CPU).
# The 17 shapes and their formulas are exactly those of signalSource (the
# compute_* reference above).  This frame layout mirrors, byte for byte, the
# firmware AO_WaveCfg (an_out_drv.h) and EXT_AO_PredefCfgTypeDef (extmcu.h):
#
#   offset 0  : shape      uint16
#   offset 2  : dac_fs_hz  float32   (DAC sample / trigger rate)
#   offset 6  : lut_len    uint16    (samples in one cycle, 1..AO_MAX_SAMPLES)
#   offset 8  : amplitude  float32
#   offset 12 : offset     float32
#   offset 16 : params[20] shape-specific (see _AO_PARAM_PACK)
#
# The host owns the cadence: it picks dac_fs_hz and lut_len so that lut_len
# samples span one seamless natural cycle; the firmware just evaluates.

AO_CFG_PREDEF_LEN     = 36    # total predefined-waveform frame size (bytes)
AO_PREDEF_PARAM_BYTES = 20    # shape-specific param area
AO_MAX_SAMPLES        = 2048  # firmware circular-LUT capacity (an_out_drv.h)
_AO_DEFAULT_LUT_LEN   = 1024
_AO_MIN_LUT_LEN       = 8
_AO_DAC_FS_MAX        = 1_000_000.0  # practical playback ceiling (Hz)

# Shapes the analogOut predefined-waveform path supports.  DC is emitted as a
# constant (the firmware bypasses the LUT); Arbitrary keeps the user-buffer
# upload path and is NOT a predefined-waveform shape.
AO_PREDEF_SHAPES = (
    PP_WaveShape.Sine, PP_WaveShape.Square, PP_WaveShape.Triangle,
    PP_WaveShape.Sawtooth, PP_WaveShape.Pulse, PP_WaveShape.Sinc,
    PP_WaveShape.Gauspuls, PP_WaveShape.DC, PP_WaveShape.LinearChirp,
    PP_WaveShape.LogChirp, PP_WaveShape.Multisine, PP_WaveShape.PRBS,
    PP_WaveShape.Step, PP_WaveShape.Ramp, PP_WaveShape.Impulse,
    PP_WaveShape.PulseTrain,
)


# Per-shape packing of the 20-byte param area: (param_name, byte_offset, fmt).
# Offsets/types mirror the an_out_drv.h AO_WaveCfg layout table exactly.
_AO_PARAM_PACK: Dict[PP_WaveShape, Tuple[Tuple[str, int, str], ...]] = {
    PP_WaveShape.Sine:        (("freq", 0, "<f"), ("phase", 4, "<f")),
    PP_WaveShape.Square:      (("freq", 0, "<f"), ("phase", 4, "<f")),
    PP_WaveShape.Triangle:    (("freq", 0, "<f"), ("phase", 4, "<f"), ("symmetry", 8, "<f")),
    PP_WaveShape.Sawtooth:    (("freq", 0, "<f"), ("phase", 4, "<f"), ("direction", 8, "<B")),
    PP_WaveShape.Pulse:       (("freq", 0, "<f"), ("phase", 4, "<f"), ("duty", 8, "<f")),
    PP_WaveShape.Sinc:        (("freq", 0, "<f"), ("phase", 4, "<f"), ("n_lobes", 8, "<H")),
    PP_WaveShape.Gauspuls:    (("freq", 0, "<f"), ("bw_fraction", 4, "<f"), ("prf", 8, "<f")),
    PP_WaveShape.DC:          (),
    PP_WaveShape.LinearChirp: (("f0", 0, "<f"), ("f1", 4, "<f"), ("t_sweep", 8, "<f"), ("phase", 12, "<f")),
    PP_WaveShape.LogChirp:    (("f0", 0, "<f"), ("f1", 4, "<f"), ("t_sweep", 8, "<f"), ("phase", 12, "<f")),
    PP_WaveShape.Multisine:   (("f0", 0, "<f"), ("df", 4, "<f"), ("n_lines", 8, "<H"),
                               ("phase_scheme", 10, "<B"), ("lfsr_seed", 12, "<I")),
    PP_WaveShape.PRBS:        (("bits", 0, "<B"), ("clock_div", 4, "<I"), ("lfsr_seed", 8, "<I")),
    PP_WaveShape.Step:        (("t_step", 0, "<f"), ("value_before", 4, "<f"), ("value_after", 8, "<f")),
    PP_WaveShape.Ramp:        (("slope", 0, "<f"), ("t_start", 4, "<f"),
                               ("sat_low", 8, "<f"), ("sat_high", 12, "<f")),
    PP_WaveShape.Impulse:     (("t_impulse", 0, "<f"),),
    PP_WaveShape.PulseTrain:  (("freq", 0, "<f"), ("phase", 4, "<f"), ("duty", 8, "<f"),
                               ("n_pulses", 12, "<H"), ("prf", 16, "<f")),
}


def _ao_clamp_lut(lut_len: int) -> int:
    return max(_AO_MIN_LUT_LEN, min(int(lut_len), AO_MAX_SAMPLES))


def ao_predef_cadence(shape: PP_WaveShape, kw: Dict[str, Any]) -> Tuple[float, int]:
    """Pick (dac_fs_hz, lut_len) so lut_len samples span one seamless cycle.

    The host owns this choice; the firmware just plays the LUT back at
    dac_fs_hz.  Periodic shapes get a full natural period; transient shapes
    (Step/Ramp/Impulse) get a sensible repeating window: under the AO
    circular-LUT model every shape is periodic.

    Raises:
        ValueError: when the waveform cannot be played. Either the sequence
            does not fit the 2048-sample table (a PRBS of too many bits, or
            too large a clock divider), or the cycle is too short: one cycle
            needs at least 8 samples and the output plays at up to 1000000
            samples per second, so the fastest waveform it can repeat is
            125 kHz.
    """
    if shape == PP_WaveShape.DC:
        return (1000.0, 1)  # unused: firmware bypasses the LUT for DC

    if shape == PP_WaveShape.PRBS:
        chips = ((1 << int(kw["bits"])) - 1) * int(kw["clock_div"])
        if chips > AO_MAX_SAMPLES:
            raise ValueError(
                f"PRBS sequence is {chips} samples; the analog-output LUT caps "
                f"at {AO_MAX_SAMPLES}. Lower 'bits' or 'clock_div'.")
        lut_len = _ao_clamp_lut(chips)
        return (float(lut_len) * 100.0, lut_len)  # whole sequence repeats 100x/s

    # Natural cycle period (seconds).
    if shape in (PP_WaveShape.Sine, PP_WaveShape.Square, PP_WaveShape.Triangle,
                 PP_WaveShape.Sawtooth, PP_WaveShape.Pulse, PP_WaveShape.Sinc):
        period = 1.0 / float(kw["freq"])
    elif shape == PP_WaveShape.Gauspuls:
        period = 1.0 / float(kw["prf"])
    elif shape in (PP_WaveShape.LinearChirp, PP_WaveShape.LogChirp):
        period = float(kw["t_sweep"])
    elif shape == PP_WaveShape.Multisine:
        period = 1.0 / float(kw["df"])
    elif shape == PP_WaveShape.PulseTrain:
        period = max(float(kw["n_pulses"]) / float(kw["freq"]),
                     1.0 / float(kw["prf"]))
    elif shape == PP_WaveShape.Step:
        period = 2.0 * max(float(kw["t_step"]), 1.0e-3)
    elif shape == PP_WaveShape.Impulse:
        period = 2.0 * max(float(kw["t_impulse"]), 1.0e-3)
    elif shape == PP_WaveShape.Ramp:
        period = 1.0  # transient, fixed 1 s repeating window
    else:
        period = 1.0

    if period <= 0.0:
        raise ValueError(f"{shape.name}: computed a non-positive waveform period")

    lut_len = _AO_DEFAULT_LUT_LEN
    if lut_len / period > _AO_DAC_FS_MAX:
        lut_len = int(_AO_DAC_FS_MAX * period)
    lut_len = _ao_clamp_lut(lut_len)
    dac_fs = float(lut_len) / period
    # A table shorter than _AO_MIN_LUT_LEN is not a waveform, so the length
    # floor wins over the rate ceiling above.  When it does, the cycle is too
    # short to play at all and the rate asked of the converter runs away: a
    # 500 kHz sine used to ask for 4 MHz and a 10 MHz one for 80 MHz, with no
    # error at any of them, because the firmware checks only that the rate is
    # positive.  Refuse instead, naming the fastest cycle that does fit.
    if dac_fs > _AO_DAC_FS_MAX:
        raise ValueError(
            f"{shape.name}: one cycle of this waveform lasts "
            f"{period * 1e6:.4g} us, so playing it would need "
            f"{dac_fs:,.0f} samples per second. The analog output plays at up "
            f"to {_AO_DAC_FS_MAX:,.0f} samples per second and needs at least "
            f"{_AO_MIN_LUT_LEN} samples per cycle, so the shortest cycle it can "
            f"play lasts {_AO_MIN_LUT_LEN / _AO_DAC_FS_MAX * 1e6:.4g} us, which "
            f"is a repetition rate of "
            f"{_AO_DAC_FS_MAX / _AO_MIN_LUT_LEN / 1e3:.4g} kHz. Slow the "
            f"waveform down.")
    return (dac_fs, lut_len)


def ao_predef_frame(shape: PP_WaveShape, amplitude: float, offset: float,
                    **shape_kwargs: Any) -> bytes:
    """Build the 36-byte analog-output predefined-waveform wire frame.

    Resolves shape defaults, runs the same per-shape validation as
    signalSource, picks the cadence, and packs the frame.  Returns exactly
    AO_CFG_PREDEF_LEN bytes.
    """
    shape = shape if isinstance(shape, PP_WaveShape) else PP_WaveShape(int(shape))
    if shape not in AO_PREDEF_SHAPES:
        raise ValueError(
            f"{getattr(shape, 'name', shape)} is not a predefined-waveform shape "
            f"for analog output (Arbitrary uses the user-buffer path)")

    # Resolve + validate the shape params, reusing the signalSource layout.
    kw: Dict[str, Any] = {}
    for name in shape_params(shape):
        if name in ("samples", "n_samples"):
            continue  # Arbitrary-only; never reached for AO predef shapes
        if name in shape_kwargs and shape_kwargs[name] is not None:
            kw[name] = coerce_param_value(name, shape_kwargs[name])
        elif name in _PARAM_DEFAULTS:
            kw[name] = coerce_param_value(name, _PARAM_DEFAULTS[name])
        else:
            raise ValueError(
                f"analogOut(shape={shape.name}) is missing required param '{name}'")
    _validate_shape_kwargs(shape, kw)

    dac_fs, lut_len = ao_predef_cadence(shape, kw)

    area = bytearray(AO_PREDEF_PARAM_BYTES)
    for (name, off, fmt) in _AO_PARAM_PACK.get(shape, ()):
        struct.pack_into(fmt, area, off, kw[name])

    header = struct.pack("<HfHff", int(shape) & 0xFFFF, float(dac_fs),
                         int(lut_len) & 0xFFFF, float(amplitude), float(offset))
    frame = header + bytes(area)
    assert len(frame) == AO_CFG_PREDEF_LEN, len(frame)
    return frame


def ao_predef_span(shape: PP_WaveShape, amplitude: float, offset: float,
                   **shape_kwargs: Any) -> Tuple[float, float]:
    """Return ``(lowest, highest)`` volts one cycle of this waveform reaches.

    Args:
        shape: one of :data:`AO_PREDEF_SHAPES`.
        amplitude: the post-scale amplitude, the same number
            :func:`ao_predef_frame` packs.
        offset: the post-scale DC offset in volts.
        **shape_kwargs: the shape's own parameters; anything omitted takes
            the same default :func:`ao_predef_frame` would use.

    Returns:
        The minimum and maximum of ``amplitude * shape + offset`` sampled
        over exactly one played cycle, at the cadence
        :func:`ao_predef_cadence` picks. These are the two numbers to compare
        against the output's own span before deciding that a waveform clips.

    Raises:
        ValueError: for anything :func:`ao_predef_frame` would refuse, and
            for a cycle the output cannot play.

    Why this exists rather than ``abs(amplitude) + abs(offset)``: that sum is
    the exact peak only for the shapes that run the full -1 to +1, which are
    Sine, Square, Triangle, Pulse, PRBS, Sawtooth and the two chirps. It is
    wrong in both directions for the rest.

    Fourteen of the sixteen shapes stay inside -1 to +1, so the sum
    OVERSTATES those and a waveform with metres to spare looks as though it
    clips: a PulseTrain and an Impulse sit between 0 and 1, a Sinc between
    -0.22 and +1, a Multisine of eight lines between -0.41 and +0.43 because
    its lines do not all peak at the same instant, and a Gauspuls whose
    pulses do not overlap holds between +0.94 and +1 and never goes negative
    at all, so the sum is wrong about the bottom of it too. A DC holds the
    offset alone and its amplitude never reaches the pin.

    Step and Ramp are the two that can leave -1 to +1, and for them the sum
    is not even a bound, because their level comes from their own parameters
    rather than from the amplitude, so the sum UNDERSTATES them and a
    waveform that slams into the rail looks safe. A Step sits at
    ``amplitude * value_after + offset``. A Ramp reaches
    ``amplitude * min(sat_high, slope * cycle) + offset`` over a played cycle
    of one second, so raising ``sat_high`` alone moves nothing until the
    slope can climb that far inside the second: at the default slope of 1 the
    ramp tops out just under 1 whatever ``sat_high`` says, while at slope 100
    it reaches 50 with ``sat_high`` 50. ``sat_low`` bounds the descent the
    same way.
    """
    shape = shape if isinstance(shape, PP_WaveShape) else PP_WaveShape(int(shape))
    if shape not in AO_PREDEF_SHAPES:
        raise ValueError(
            f"{getattr(shape, 'name', shape)} is not a predefined-waveform shape "
            f"for analog output (Arbitrary uses the user-buffer path)")

    kw: Dict[str, Any] = {}
    for name in shape_params(shape):
        if name in ("samples", "n_samples"):
            continue
        if name in shape_kwargs and shape_kwargs[name] is not None:
            kw[name] = coerce_param_value(name, shape_kwargs[name])
        elif name in _PARAM_DEFAULTS:
            kw[name] = coerce_param_value(name, _PARAM_DEFAULTS[name])
        else:
            raise ValueError(
                f"analogOut(shape={shape.name}) is missing required param '{name}'")
    _validate_shape_kwargs(shape, kw)

    if shape == PP_WaveShape.DC:
        # The firmware bypasses the LUT for DC and holds the offset, so the
        # amplitude never reaches the pin. compute_dc returns zeros, which
        # gives the same answer; saying so here keeps the special case from
        # looking like an accident.
        return (float(offset), float(offset))

    dac_fs, lut_len = ao_predef_cadence(shape, kw)
    cycle = compute_reference(shape, float(dac_fs), int(lut_len),
                              amplitude=float(amplitude), offset=float(offset),
                              **kw)
    return (float(np.min(cycle)), float(np.max(cycle)))


def ao_predef_unframe(frame: bytes) -> Dict[str, Any]:
    """Decode a 36-byte analog-output predefined-waveform frame.

    Inverse of :func:`ao_predef_frame`, used by the Studio reverse-decoder
    (save/load).  Returns ``shape`` (PP_WaveShape), ``amplitude``, ``offset``,
    ``dac_fs_hz``, ``lut_len`` and every shape-specific param.
    """
    buf = bytes(frame)
    if len(buf) < AO_CFG_PREDEF_LEN:
        raise ValueError(
            f"analog-output predefined-waveform frame is {len(buf)} bytes, "
            f"expected {AO_CFG_PREDEF_LEN}")
    shape_id, dac_fs, lut_len, amplitude, offset = struct.unpack("<HfHff", buf[:16])
    shape = PP_WaveShape(shape_id)
    out: Dict[str, Any] = {
        "shape": shape,
        "amplitude": float(amplitude),
        "offset": float(offset),
        "dac_fs_hz": float(dac_fs),
        "lut_len": int(lut_len),
    }
    area = buf[16:16 + AO_PREDEF_PARAM_BYTES]
    for (name, off, fmt) in _AO_PARAM_PACK.get(shape, ()):
        out[name] = struct.unpack_from(fmt, area, off)[0]
    return out
