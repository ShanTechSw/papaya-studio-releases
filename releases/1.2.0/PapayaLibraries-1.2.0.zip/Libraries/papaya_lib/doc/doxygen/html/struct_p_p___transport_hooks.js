var struct_p_p___transport_hooks =
[
    [ "begin", "struct_p_p___transport_hooks.html#a8e434acb4764a197c96574d342b4dddb", null ],
    [ "beginTransaction", "struct_p_p___transport_hooks.html#a5802a24fa529c99b1f642c52bd235ff3", null ],
    [ "chipSelect", "struct_p_p___transport_hooks.html#afce81921748064cbde3bbad57aea8f48", null ],
    [ "context", "struct_p_p___transport_hooks.html#ae42e78a4cb4b4af94900a44438ee9abf", null ],
    [ "delayMs", "struct_p_p___transport_hooks.html#ac494626dc32da90f22bee7dcf4ecccfb", null ],
    [ "delayUs", "struct_p_p___transport_hooks.html#a12f7116eec1f044d8c82dcfaf257b8f1", null ],
    [ "digitalWrite", "struct_p_p___transport_hooks.html#a200a673121b41ee5daa5a388b0b52f52", null ],
    [ "end", "struct_p_p___transport_hooks.html#a7c52521548de5ab83ae67a4df9b304c5", null ],
    [ "endTransaction", "struct_p_p___transport_hooks.html#a3f08d5b346f3acfb30b1ca03c3f97f7a", null ],
    [ "millis", "struct_p_p___transport_hooks.html#ab0f68538e2fc19da9301a04f41fb0565", null ],
    [ "pinMode", "struct_p_p___transport_hooks.html#aac58498c587077b3c96f6f72cb536d34", null ],
    [ "selectBoard", "struct_p_p___transport_hooks.html#ad11a9100ded69dc904e1b16da3f188f6", null ],
    [ "setReset", "struct_p_p___transport_hooks.html#ae9a6a9b67485e688c69e67c5d1052cf0", null ],
    [ "transferBuffer", "struct_p_p___transport_hooks.html#adf3c3407acc76b1831b4c298e2f65b65", null ],
    [ "transferByte", "struct_p_p___transport_hooks.html#acc7facb6f6d8eaf7d3a97ec35005cd16", null ]
];