var classmoving_average =
[
    [ "movingAverage", "classmoving_average.html#a04bcb070c98a953f517049d58159b954", null ]
];