/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Axes   three voltages forming a rotating vector: a 1 V sine and cosine pair
 *             at 2 Hz on the first two axes and a 0.75 V sine at 0.25 Hz on the
 *             third. The fast pair keeps x^2 + y^2 at exactly 1 V^2, so
 *             vector_norm_V ignores the rotation and breathes slowly between 1.0 V
 *             and 1.25 V, moved only by the third axis
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe p_sin;
probe p_cos;
probe p_id;
probe p_ang;
probe p_db;
probe p_norm;

input x;
input y;

/* Global Struct Declarations */
// Configuration for Axes (3 channels)
PP_anInCfg Axes_config[3] = {
  {1.0f, 0.0f, AIN1},
  {1.0f, 0.0f, AIN2},
  {1.0f, 0.0f, AIN3}
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  x = input("x", 1.0f);
  y = input("y", 1.0f);
  signalSource Phase_0__2pi = signalSource::sawtooth(1.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 3.14159265f, /*offset=*/ 3.14159265f);
  analogIn Axes = analogIn(Axes_config, 3);
  expander fan_3 = expander(3);
  sineFunc sin = sineFunc();
  cosineFunc cos = cosineFunc();
  expFunc exp = expFunc();
  logFunc ln = logFunc();
  expander fan_2 = expander(2);
  expander fan_2_2 = expander(2);
  atan2Block atan2 = atan2Block();
  mag2 mag2_2 = mag2();
  decibelsConverter dB = decibelsConverter();
  mag3 mag3_2 = mag3();
  p_sin = probe("sin");
  p_cos = probe("cos");
  p_id = probe("identity");
  p_ang = probe("angle_rad");
  p_db = probe("magnitude_dB");
  p_norm = probe("vector_norm_V");

  /* Connect Blocks */
  x > fan_2;
  y > fan_2_2;
  Phase_0__2pi > fan_3;
  Axes.out(0) > mag3_2.in(0);
  Axes.out(1) > mag3_2.in(1);
  Axes.out(2) > mag3_2.in(2);
  fan_3.out(0) > sin;
  fan_3.out(1) > cos;
  fan_3.out(2) > exp;
  sin > p_sin;
  cos > p_cos;
  exp > ln;
  ln > p_id;
  fan_2.out(0) > atan2.in(1);
  fan_2.out(1) > mag2_2.in(0);
  fan_2_2.out(0) > atan2.in(0);
  fan_2_2.out(1) > mag2_2.in(1);
  atan2 > p_ang;
  mag2_2 > dB;
  dB > p_db;
  mag3_2 > p_norm;

  /* Enable Remote Input Control */
  x.enableRemote();
  y.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    p_sin.show();
    p_cos.show();
    p_id.show();
    p_ang.show();
    p_db.show();
    p_norm.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}