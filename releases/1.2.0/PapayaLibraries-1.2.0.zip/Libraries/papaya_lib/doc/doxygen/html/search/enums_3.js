var searchData=
[
  ['wavemode_0',['WaveMode',['../_p_a_p_a_y_a_8h.html#afc76a1d56804ae716d7596f864eb3f6b',1,'PAPAYA.h']]],
  ['waveshape_1',['WaveShape',['../_p_a_p_a_y_a_8h.html#a64dec478c6b69695e161832095a9083c',1,'PAPAYA.h']]],
  ['wavetrigpol_2',['WaveTrigPol',['../_p_a_p_a_y_a_8h.html#aeed95cc7296ac13fd114ff2597b5ab76',1,'PAPAYA.h']]]
];
