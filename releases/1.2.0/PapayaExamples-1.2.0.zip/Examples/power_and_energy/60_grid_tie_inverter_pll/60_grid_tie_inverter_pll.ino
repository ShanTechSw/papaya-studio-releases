/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 12800.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe grid_amplitude;
probe grid_vrms;
probe real_power_2;
probe grid_frequency;
probe inverter_v_alph;
probe inverse_Park_tap;

input iq_ref;

/* Global Struct Declarations */
// Configuration for EKF_phase_locked_loop
static float EKF_phase_locked_loop_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float EKF_phase_locked_loop_R_data[1] = {0.1f};
static float EKF_phase_locked_loop_x_init[3] = {0.0f, 314.159265359f, 325.0f};
PP_GridSync_EKF EKF_phase_locked_loop_config = {
  .nom_freq = 50.0f,
  .nom_amplitude = 325.0f,
  .Q_data = EKF_phase_locked_loop_Q_data,
  .R_data = EKF_phase_locked_loop_R_data,
  .x_init = EKF_phase_locked_loop_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(12800.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  iq_ref = input("iq_ref_A", 8.0f);
  signalSource SIM__grid_voltage = signalSource::sine(50.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 325.0f);
  signalSource SIM__5th_harmonic = signalSource::sine(250.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 15.0f);
  signalSource SIM__injected_current = signalSource::sine(50.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 8.0f);
  node distorted_grid = node("[1.0 1.0]", "[1.0]", Sum);
  expander fan_3_2 = expander(3);
  clarke current_Clarke = clarke();
  expander fan_3 = expander(3);
  gridSyncEKF EKF_phase_locked_loop = gridSyncEKF(&EKF_phase_locked_loop_config);
  rootMeanSquare grid_Vrms = rootMeanSquare(128);
  node instantaneous_V_I = node("[1.0 1.0]", "[1.0]", Mul);
  mean real_power = mean(128);
  expander fan_2 = expander(2);
  gain rad_s_to_Hz = gain(0.15915494309189535);
  park current_Park = park();
  node current_error = node("[1.0 -1.0]", "[1.0]", Sum);
  pid current_PI = pid(300.0, 8.0, 0.0, 0.001);
  invPark inverse_Park = invPark();
  grid_amplitude = probe("grid_amplitude");
  grid_vrms = probe("grid_vrms_V");
  real_power_2 = probe("real_power_W");
  grid_frequency = probe("grid_frequency");
  inverter_v_alph = probe("inverter_v_alph");
  inverse_Park_tap = probe("inverse Park_o1");

  /* Connect Blocks */
  iq_ref > current_error.in(0);
  SIM__grid_voltage > distorted_grid.in(0);
  SIM__5th_harmonic > distorted_grid.in(1);
  SIM__injected_current > fan_3_2;
  distorted_grid > fan_3;
  fan_3_2.out(0) > current_Clarke.in(0);
  fan_3_2.out(1) > current_Clarke.in(1);
  fan_3_2.out(2) > instantaneous_V_I.in(1);
  current_Clarke.out(0) > current_Park.in(0);
  current_Clarke.out(1) > current_Park.in(1);
  fan_3.out(0) > EKF_phase_locked_loop;
  fan_3.out(1) > grid_Vrms;
  fan_3.out(2) > instantaneous_V_I.in(0);
  EKF_phase_locked_loop.out(0) > fan_2;
  EKF_phase_locked_loop.out(1) > rad_s_to_Hz;
  EKF_phase_locked_loop.out(2) > grid_amplitude;
  grid_Vrms > grid_vrms;
  instantaneous_V_I > real_power;
  real_power > real_power_2;
  fan_2.out(0) > current_Park.in(2);
  fan_2.out(1) > inverse_Park.in(2);
  rad_s_to_Hz > grid_frequency;
  current_Park.out(1) > current_error.in(1);
  current_Park.out(0) > inverse_Park.in(1);
  current_error > current_PI;
  current_PI > inverse_Park.in(0);
  inverse_Park.out(0) > inverter_v_alph;
  inverse_Park.out(1) > inverse_Park_tap;

  /* Enable Remote Input Control */
  iq_ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    grid_amplitude.show();
    grid_vrms.show();
    real_power_2.show();
    grid_frequency.show();
    inverter_v_alph.show();
    inverse_Park_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}