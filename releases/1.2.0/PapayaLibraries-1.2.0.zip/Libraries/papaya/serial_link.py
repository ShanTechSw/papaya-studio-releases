"""Talk to another board over a serial port, from the same script.

Most rigs are not one board. There is a PAPAYA board closing a loop, and
beside it something else on a serial port: an Arduino reading a scale, a
sensor that speaks NMEA, a motor driver that takes ASCII commands, a
laboratory instrument with a documented text protocol. Whatever it is,
the PC is the one thing that can see both, and this is what it uses to
see the second one.

    from papaya.serial_link import SerialLink, list_ports
    import papaya.remote as remote

    print(list_ports())                       # what is plugged in

    design = remote.attach()
    design.start()
    with SerialLink("COM7", 115200) as arduino:
        arduino.write_line("READ")
        grams = float(arduino.read_line(timeout_s=1.0) or "nan")
        design.write("load", grams)

Nothing here is PAPAYA specific: it is a small, honest wrapper over
pyserial that makes the line-oriented case short and the failures
readable. If you want pyserial itself, import it; this module gets out
of the way.

WHAT IT ADDS OVER pyserial

* A message when the port cannot be opened that names the likely cause.
  "Access is denied" on a serial port means something else has it, and
  on a bench that something is nearly always a serial monitor left open
  in another program.
* Line reads with a real timeout, returning None instead of a partial
  line, so a device that went quiet reads as quiet rather than as a
  corrupt reply.
* A close that runs on every exit path, including an exception, so the
  port is free for the next run. A port left open is the most common
  reason a second run of a working script fails.

WHAT IT DOES NOT DO

It does not guess baud rates, frame anything, or retry. A serial device
has a protocol and only you know it.
"""

from __future__ import annotations

import time
from typing import List, Optional, Tuple

__all__ = ["SerialLink", "SerialLinkError", "list_ports"]


class SerialLinkError(RuntimeError):
    """The port could not be used, and the message says what to do."""


def _require_pyserial():
    try:
        import serial                                      # noqa: F401
        import serial.tools.list_ports as list_ports_mod   # noqa: F401
    except Exception as exc:                               # noqa: BLE001
        raise SerialLinkError(
            "This needs the pyserial package and it is not installed for "
            "the Python running this script. In PAPAYA Studio open the "
            "Source Editor and use Packages to add pyserial, then run "
            "this again. Original error: " + str(exc)
        ) from exc
    import serial
    import serial.tools.list_ports as list_ports_mod
    return serial, list_ports_mod


def list_ports() -> List[Tuple[str, str]]:
    """Every serial port this computer can see: ``(port, description)``.

    Print it when a device is not answering. A port that is not in this
    list is not plugged in, or its driver is not installed, and no amount
    of changing the baud rate will help.
    """
    _serial, list_ports_mod = _require_pyserial()
    found = []
    for entry in list_ports_mod.comports():
        found.append((str(entry.device), str(entry.description or "")))
    return found


class SerialLink:
    """One serial port, opened on construction and closed on exit.

    ``newline`` is what :meth:`write_line` appends and what
    :meth:`read_line` splits on. It defaults to ``"\\n"``, which is what
    an Arduino's ``Serial.println`` sends.
    """

    def __init__(self, port: str, baudrate: int = 115200, *,
                 timeout_s: float = 1.0, newline: str = "\n",
                 encoding: str = "utf-8",
                 settle_s: float = 0.0) -> None:
        serial, _ = _require_pyserial()
        self.port = str(port)
        self.baudrate = int(baudrate)
        self.newline = str(newline)
        self.encoding = str(encoding)
        self._buffer = bytearray()
        try:
            self._serial = serial.Serial(
                self.port, self.baudrate, timeout=float(timeout_s))
        except Exception as exc:                           # noqa: BLE001
            raise SerialLinkError(self._why_it_would_not_open(exc)) from exc
        if settle_s > 0:
            # An Arduino RESETS when the port is opened, and it is not
            # listening for about a second and a half afterwards. A
            # command sent into that window is not answered late, it is
            # not received at all, which reads as a dead device. Pass a
            # settle time when the board at the other end reboots on
            # open.
            time.sleep(float(settle_s))
            try:
                self._serial.reset_input_buffer()
            except Exception:                              # noqa: BLE001
                pass

    def _why_it_would_not_open(self, exc: Exception) -> str:
        text = str(exc)
        lower = text.lower()
        if "access is denied" in lower or "permission" in lower:
            return (
                f"{self.port} is open in something else, so it cannot be "
                f"opened here: a serial monitor in another program is the "
                f"usual reason. Close it and run this again. "
                f"Original error: {text}")
        if "could not open" in lower or "filenotfound" in lower \
                or "no such file" in lower:
            try:
                seen = ", ".join(p for p, _d in list_ports()) or "(none)"
            except SerialLinkError:
                seen = "(could not be listed)"
            return (
                f"{self.port} is not there. The ports this computer can "
                f"see are: {seen}. Check the cable and the device's "
                f"driver. Original error: {text}")
        return f"{self.port} could not be opened: {text}"

    # -- writing --------------------------------------------------------
    def write(self, data) -> int:
        """Send raw bytes (or a string, encoded). Returns bytes written."""
        if isinstance(data, str):
            data = data.encode(self.encoding)
        try:
            return int(self._serial.write(bytes(data)))
        except Exception as exc:                           # noqa: BLE001
            raise SerialLinkError(self._why_it_stopped(exc)) from exc

    def write_line(self, text: str) -> int:
        """Send one line, terminator included."""
        return self.write(str(text) + self.newline)

    # -- reading --------------------------------------------------------
    def _read_some(self, deadline: float) -> bool:
        """Take whatever is there, waiting no longer than *deadline*.

        THE PORT'S OWN TIMEOUT IS THE ONE THAT DECIDES, unless it is told
        otherwise. A read of one byte blocks for the timeout the port was
        opened with, which is a second by default, so a caller asking for
        a fiftieth of a second used to wait the full second anyway.
        Measured: read_line(timeout_s=0.05) returned after 1.00 s. In a
        panel refresh that is a frozen window once per tick. So the
        remaining budget is pushed onto the port before each read.

        Returns False when the link died, which is different from
        nothing having arrived yet.
        """
        remaining = max(0.0, deadline - time.monotonic())
        try:
            waiting = int(self._serial.in_waiting)
        except Exception:                                  # noqa: BLE001
            waiting = 0
        try:
            if not waiting:
                # Nothing buffered, so this read is the wait. Give the
                # port the budget, with a floor that keeps a zero-timeout
                # caller from spinning: measured at 65,000 calls in 60 ms
                # on a non-blocking port before this existed.
                self._serial.timeout = max(0.001, min(remaining, 0.05))
            chunk = self._serial.read(waiting or 1)
        except Exception as exc:                           # noqa: BLE001
            raise SerialLinkError(self._why_it_stopped(exc)) from exc
        if chunk:
            self._buffer.extend(chunk)
        return True

    def _why_it_stopped(self, exc: Exception) -> str:
        """A mid-session failure, in words that name the remedy."""
        return (f"{self.port} stopped responding: {exc}. The usual cause "
                f"is the adapter being unplugged or its driver dropping "
                f"it. Check the cable, then run this again.")

    def read_line(self, timeout_s: float = 1.0) -> Optional[str]:
        """One line without its terminator, or None if none arrived.

        None means the device said nothing complete in time. A PARTIAL
        line is never returned: half a reading looks like a valid smaller
        reading, and a script that acts on it acts on a number the device
        never sent.
        """
        terminator = self.newline.encode(self.encoding)
        if not terminator:
            raise SerialLinkError(
                "this link was opened with no line terminator, so there is "
                "no such thing as a line on it. Use read_bytes, or give "
                "SerialLink a newline.")
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        first = True
        while True:
            cut = self._buffer.find(terminator)
            if cut >= 0:
                line = bytes(self._buffer[:cut])
                del self._buffer[:cut + len(terminator)]
                return line.decode(self.encoding, errors="replace").rstrip("\r")
            # The deadline is checked AFTER one attempt, never before it.
            # Checked first, timeout_s=0 returned without ever touching
            # the port, so a zero-timeout poll could only ever hand back
            # what was already buffered and a polling loop starved.
            if not first and time.monotonic() >= deadline:
                return None
            first = False
            if not self._read_some(deadline):
                return None

    def read_lines(self, count: int, timeout_s: float = 1.0) -> List[str]:
        """Up to *count* lines, stopping early if the device goes quiet."""
        out: List[str] = []
        for _ in range(max(0, int(count))):
            line = self.read_line(timeout_s=timeout_s)
            if line is None:
                break
            out.append(line)
        return out

    def read_bytes(self, n: int, timeout_s: float = 1.0) -> bytes:
        """Exactly *n* bytes, or fewer if the device went quiet first."""
        n = int(n)
        if n <= 0:
            # Negative used to slice from the end, quietly consuming all
            # but the last few bytes.
            return b""
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        first = True
        while len(self._buffer) < n:
            if not first and time.monotonic() >= deadline:
                break
            first = False
            if not self._read_some(deadline):
                break
        take = bytes(self._buffer[:n])
        del self._buffer[:len(take)]
        return take

    def flush_input(self) -> None:
        """Throw away anything already received.

        Worth doing before a request whose answer you are about to wait
        for: without it the first line you read may be the tail of the
        previous exchange.
        """
        self._buffer.clear()
        try:
            self._serial.reset_input_buffer()
        except Exception:                                  # noqa: BLE001
            pass

    # -- lifecycle ------------------------------------------------------
    @property
    def is_open(self) -> bool:
        try:
            return bool(self._serial.is_open)
        except Exception:                                  # noqa: BLE001
            return False

    def close(self) -> None:
        """Free the port. Safe to call twice."""
        try:
            self._serial.close()
        except Exception:                                  # noqa: BLE001
            pass

    def __enter__(self) -> "SerialLink":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
