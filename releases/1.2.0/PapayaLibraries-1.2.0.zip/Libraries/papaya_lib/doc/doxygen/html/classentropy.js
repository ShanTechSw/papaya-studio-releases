var classentropy =
[
    [ "entropy", "classentropy.html#a2169a1ef871d75a6e357373ba0c916a6", null ]
];