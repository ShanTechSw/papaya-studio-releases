var struct_p_p___dataset_info =
[
    [ "crc32", "struct_p_p___dataset_info.html#a321a630d9a3b41c7c07c4021026544c7", null ],
    [ "format", "struct_p_p___dataset_info.html#ad6cfc0af82c372d01072abb2ccfd484f", null ],
    [ "lengthSamples", "struct_p_p___dataset_info.html#a0d6c65ab17224b803e216f052e900e3a", null ],
    [ "occupied", "struct_p_p___dataset_info.html#a581ef67af0af0fff5fd73a9e04821e50", null ],
    [ "sampleRateHz", "struct_p_p___dataset_info.html#a14427a39c2166d89cdd8c6b8996c7027", null ],
    [ "slotId", "struct_p_p___dataset_info.html#adf13f1f4700c0bcd567248c6c44e05e8", null ],
    [ "timestamp", "struct_p_p___dataset_info.html#a7975e10e05a12d6143acda574a6ead93", null ]
];