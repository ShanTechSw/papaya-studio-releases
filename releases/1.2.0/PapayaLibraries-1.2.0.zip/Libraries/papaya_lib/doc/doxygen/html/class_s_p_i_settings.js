var class_s_p_i_settings =
[
    [ "SPISettings", "class_s_p_i_settings.html#a4476ac10d4312c401b0413b823d62f55", null ],
    [ "SPISettings", "class_s_p_i_settings.html#a4476ac10d4312c401b0413b823d62f55", null ],
    [ "bitOrder", "class_s_p_i_settings.html#af03a4836d9fc85d92cc8b4d8c0d8186c", null ],
    [ "bitOrder", "class_s_p_i_settings.html#af03a4836d9fc85d92cc8b4d8c0d8186c", null ],
    [ "clock", "class_s_p_i_settings.html#a5e541bbcdc30cac3e7b8abf6d61ac337", null ],
    [ "clock", "class_s_p_i_settings.html#a5e541bbcdc30cac3e7b8abf6d61ac337", null ],
    [ "dataMode", "class_s_p_i_settings.html#ab82c5ea39eaf9431a87d0850fd78b710", null ],
    [ "dataMode", "class_s_p_i_settings.html#ab82c5ea39eaf9431a87d0850fd78b710", null ],
    [ "_bitOrder", "class_s_p_i_settings.html#a6e4b3900ac4fafb01108ff80d4128aa2", null ],
    [ "_clock", "class_s_p_i_settings.html#ac06439063cf52a51a8d69471f9f3445f", null ],
    [ "_dataMode", "class_s_p_i_settings.html#ab90a6cdd1bbd3aeb8fc7a5c6b64a1ee5", null ]
];