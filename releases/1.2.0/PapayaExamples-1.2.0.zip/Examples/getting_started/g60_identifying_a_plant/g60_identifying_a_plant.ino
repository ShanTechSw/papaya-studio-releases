/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe rls_prediction;
probe rls_error;
VectorProbe rls_theta;
probe rrls_prediction;
probe rrls_error;
VectorProbe rrls_theta;
probe smo_state;
probe estimated_distu;

input dob_command;

/* Global Struct Declarations */
// Configuration for RLS_2
// Order 2: num is {b0..b2}, denom is {1, a1..a2}, both 3 long
float RLS_2_num[3]   = {0.0f, 0.0f, 0.0f};   // no prior model
float RLS_2_denom[3] = {1.0f, 0.0f, 0.0f};   // monic, leading 1

// Covariance and system order
PP_RLSParam RLS_2_config = {RLS_2_num, 3, RLS_2_denom, 3, 1000.0f, 2, 1};
// Replace num and denom with a starting model if you have one; the denominator's leading coefficient must not be zero.

// Configuration for RRLS_2
// denom is {1, a1..a2}, num is {b0..b2}
float RRLS_2_num[3]   = {0.0f, 0.0f, 0.0f};
float RRLS_2_denom[3] = {1.0f, 0.0f, 0.0f};
PP_RRLSParam RRLS_2_config = {RRLS_2_num, 3, RRLS_2_denom, 3, 1000.0f, 2, 0.99f, 1};

// Configuration for Sliding_observer
static float Sliding_observer_A_data[4] = {0.9f, 0.1f, 0.0f, 0.95f};
static float Sliding_observer_B_data[2] = {0.0f, 0.1f};
static float Sliding_observer_C_data[2] = {1.0f, 0.0f};
static float Sliding_observer_L_data[2] = {0.3f, 0.05f};
static float Sliding_observer_K_data[2] = {0.5f, 0.1f};
static float Sliding_observer_x_init[2] = {0.0f, 0.0f};
PP_SMO Sliding_observer_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = Sliding_observer_A_data,
  .B_data = Sliding_observer_B_data,
  .C_data = Sliding_observer_C_data,
  .L_data = Sliding_observer_L_data,
  .K_data = Sliding_observer_K_data,
  .x_init = Sliding_observer_x_init,
  .epsilon = 0.05f
};

// Configuration for Disturbance
static float Disturbance_Gn_num[2] = {1.0f, 0.0f};
static float Disturbance_Gn_den[2] = {1.0f, -0.9f};
static float Disturbance_Qf_num[2] = {0.1f, 0.0f};
static float Disturbance_Qf_den[2] = {1.0f, -0.9f};
PP_DOBConfig Disturbance_config = {
  .Gn_num = Disturbance_Gn_num,
  .Gn_den = Disturbance_Gn_den,
  .Qf_num = Disturbance_Qf_num,
  .Qf_den = Disturbance_Qf_den,
  .plant_ord = 1,
  .qf_ord = 1
};


/* Global Array Declarations */
float Plant_numerator[] = {1.0f};
float Plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::chirpLinear(0.5f, 50.0f, 5.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  dob_command = input("dob_command", 0.0f);
  expander excitation = expander(4);
  tf Plant = tf(Plant_numerator, 1, Plant_denominator, 2);
  expander response = expander(4);
  RLS RLS_2 = RLS(&RLS_2_config);
  RRLS RRLS_2 = RRLS(&RRLS_2_config);
  slidingModeObserver Sliding_observer = slidingModeObserver(&Sliding_observer_config);
  dob Disturbance = dob(&Disturbance_config);
  rls_prediction = probe("rls_prediction");
  rls_error = probe("rls_error");
  rls_theta = VectorProbe("rls_theta");
  rrls_prediction = probe("rrls_prediction");
  rrls_error = probe("rrls_error");
  rrls_theta = VectorProbe("rrls_theta");
  smo_state = probe("smo_state");
  estimated_distu = probe("estimated_distu");

  /* Connect Blocks */
  Source > excitation;
  dob_command > Disturbance.in(0);
  excitation.out(0) > Plant;
  excitation.out(1) > RLS_2.in(1);
  excitation.out(2) > RRLS_2.in(1);
  excitation.out(3) > Sliding_observer.in(0);
  Plant > response;
  response.out(0) > RLS_2.in(0);
  response.out(1) > RRLS_2.in(0);
  response.out(2) > Sliding_observer.in(1);
  response.out(3) > Disturbance.in(1);
  RLS_2.out(0) > rls_prediction;
  RLS_2.out(1) > rls_error;
  RLS_2.out(0) >> rls_theta;
  RRLS_2.out(0) > rrls_prediction;
  RRLS_2.out(1) > rrls_error;
  RRLS_2.out(0) >> rrls_theta;
  Sliding_observer > smo_state;
  Disturbance > estimated_distu;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    rls_prediction.show();
    rls_error.show();
    rls_theta.show();
    rrls_prediction.show();
    rrls_error.show();
    rrls_theta.show();
    smo_state.show();
    estimated_distu.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}