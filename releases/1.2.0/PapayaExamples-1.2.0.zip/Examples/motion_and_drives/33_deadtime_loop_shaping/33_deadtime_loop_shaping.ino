/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe model_est;
probe response;

input ref;

/* Global Array Declarations */
const float Discrete_plant_model_numerator_array[] = {
  2.4975e-07f, 4.99501e-07f, 2.4975e-07f
};
const float Discrete_plant_model_denominator_array[] = {
  1.0f, -1.9980005f, 0.9980015f
};
float Plant_numerator[] = {1.0f};
float Plant_denominator[] = {1.0f, 2.0f, 1.0f};

macro build_Compensator()
{
  macro retMacro;

  // Create Empty Macro
  retMacro = macro(1, 1);

  // Start Macro
  retMacro.start();

  // Create Blocks
  gain Pregain = gain(1.0);
  leadLag Lead_lag = leadLag(2.0, 1.0, 10.0);
  gain Comp_gain = gain(1.5);

  // Connect Blocks
  retMacro.in(0) > Pregain;
  Pregain > Lead_lag;
  Lead_lag > Comp_gain;
  Comp_gain > retMacro.out(0);

  // Stop Macro
  retMacro.stop();

  return retMacro;
}


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 1.0f);
  node error = node("[1.0 -1.0 -1.0 1.0]", "[1.0]", Sum);
  macro Compensator_macro = build_Compensator();
  expander fan_2 = expander(2);
  tfd Discrete_plant_model = tfd(const_cast<float*>(Discrete_plant_model_numerator_array), const_cast<float*>(Discrete_plant_model_denominator_array), 2);
  expander fan_2b = expander(2);
  delayop Model_delay = delayop(50);
  tf Plant = tf(Plant_numerator, 1, Plant_denominator, 3);
  delayop Plant_delay = delayop(50);
  model_est = probe("predictor_model");
  response = probe("shaped_response");

  /* Connect Blocks */
  ref > error.in(0);
  error > Compensator_macro;
  Compensator_macro > fan_2;
  fan_2.out(1) > Discrete_plant_model;
  fan_2.out(0) > Plant;
  Discrete_plant_model > fan_2b;
  Discrete_plant_model > model_est;
  fan_2b.out(0) > error.in(1);
  fan_2b.out(1) > Model_delay;
  Model_delay > error.in(3);
  Plant > Plant_delay;
  Plant_delay > error.in(2);
  Plant_delay > response;

  /* Enable Remote Input Control */
  ref.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    model_est.show();
    response.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}