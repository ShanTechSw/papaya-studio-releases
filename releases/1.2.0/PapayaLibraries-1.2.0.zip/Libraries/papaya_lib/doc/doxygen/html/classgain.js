var classgain =
[
    [ "gain", "classgain.html#ab3125f1a3980b5e52a8e978aabe47639", null ]
];