"""
Build a "problem report" bundle for support.

Collects everything a support engineer needs into a single zip the user
can attach to a support message: Studio version + build metadata, OS /
Python / Qt info, the resolved libraries & examples state, the
application logs, and any crash dumps.

Nothing is sent anywhere: :func:`build_report` only writes a local zip.
That keeps the feature free (no backend) and private by design. The
user decides what to do with the file.
"""

from __future__ import annotations

import datetime as dt
import platform
import sys
import zipfile
from pathlib import Path

from . import _app_paths


def _system_info() -> str:
    """Return the human-readable system-info text embedded in the report."""
    lines = ["PAPAYA Studio: problem report", "=" * 60]
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines.append(f"Generated:    {ts}")

    try:
        from . import _version
        lines.append(f"Studio:       {_version.__version__}")
        lines.append(f"Channel:      {getattr(_version, '__channel__', '?')}")
    except Exception:
        lines.append("Studio:       ?")

    try:
        from . import _build_metadata as bm
        lines.append(f"Build date:   {getattr(bm, 'BUILD_DATE', '') or '(dev)'}")
        fw = getattr(bm, "FIRMWARE_COMMITS", {}) or {}
        if fw:
            lines.append("Firmware:     "
                         + ", ".join(f"{k}={v or '-'}" for k, v in fw.items()))
    except Exception:
        pass

    lines.append(f"Python:       {platform.python_version()}")
    try:
        from PyQt6.QtCore import QT_VERSION_STR
        lines.append(f"Qt:           {QT_VERSION_STR}")
    except Exception:
        lines.append("Qt:           ?")
    lines.append(f"Platform:     {platform.platform()}")
    lines.append(f"Frozen:       {bool(getattr(sys, 'frozen', False))}")

    try:
        from . import _libraries_path as lp
        lines += [
            "",
            f"Libraries root:    {lp.get_libraries_root()}",
            f"Libraries source:  {lp.libraries_origin()}",
            f"Libraries version: {lp.libraries_version() or '(unstamped)'}",
            f"Libraries OK:      {lp.libraries_ok()}",
            f"Examples root:     {lp.get_examples_root()}",
            f"Examples version:  {lp.examples_version() or '(unstamped)'}",
        ]
    except Exception as exc:
        lines.append(f"(libraries info unavailable: {exc})")

    # Board-verification key: the FINGERPRINT only (a short, one-way
    # digest that identifies which key this install holds without
    # revealing it). Nearly every "my board will not connect" report comes
    # down to a host and a board holding different keys, and comparing two
    # fingerprints settles that in one line.
    try:
        from . import auth as _auth
        status = _auth.psk_status()
        lines += [
            "",
            f"Board key source:  {status['source']}",
            f"Board key id:      {status['fingerprint'] or '(none)'}",
        ]
    except Exception as exc:
        lines.append(f"(board key info unavailable: {exc})")

    return "\n".join(lines) + "\n"


def _desktop_or_home() -> Path:
    desktop = Path.home() / "Desktop"
    return desktop if desktop.is_dir() else Path.home()


def default_report_path() -> Path:
    """A sensible default location + name for a new report zip."""
    ts = dt.datetime.now().strftime("%Y%m%dT%H%M%S")
    return _desktop_or_home() / f"papaya-problem-report-{ts}.zip"


def build_report(dest_zip: Path | None = None) -> Path:
    """Write a problem-report zip and return its path.

    The zip contains ``system_info.txt``, every file from the logs
    directory under ``logs/``, and every ``crash_*.txt`` from the
    crashes directory under ``crashes/``.
    """
    dest = Path(dest_zip) if dest_zip else default_report_path()
    dest.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("system_info.txt", _system_info())
        try:
            for p in sorted(_app_paths.logs_dir().glob("*")):
                if p.is_file():
                    zf.write(p, f"logs/{p.name}")
        except Exception:
            pass
        try:
            for p in sorted(_app_paths.crashes_dir().glob("crash_*.txt")):
                if p.is_file():
                    zf.write(p, f"crashes/{p.name}")
        except Exception:
            pass

    return dest
