var namespaces_dup =
[
    [ "pp_ao_detail", "namespacepp__ao__detail.html", "namespacepp__ao__detail" ],
    [ "pp_wave_detail", "namespacepp__wave__detail.html", "namespacepp__wave__detail" ]
];