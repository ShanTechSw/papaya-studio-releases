/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 12800.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Line voltage   a mains voltage in volts: 325 V peak (230 V rms) at exactly
 *                     50 Hz, with a realistic 3 percent 5th, 2 percent 3rd and 1
 *                     percent 7th harmonic and 0.15 V of noise, so the spectrum
 *                     view has true harmonics to show and grid_freq settles at 50.0
 *                     Hz
 *      Line current   a load current in amps: 3.0 A rms fundamental lagging the
 *                     voltage by 32 degrees (0.85 displacement power factor), with
 *                     the larger low-order harmonics of a rectifier load. Expect
 *                     real_power_W near 585 W against about 700 VA apparent
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe grid_phase_rad;
probe grid_amplitude;
probe vrms;
probe irms;
VectorProbe v_spectrum;
probe Spectrum_tap;
probe real_power;
probe grid_freq;
probe apparent_power;

/* Global Struct Declarations */
// Configuration for Grid_sync_EKF
static float Grid_sync_EKF_Q_data[9] = {0.001f, 0.0f, 0.0f, 0.0f, 0.001f, 0.0f, 0.0f, 0.0f, 0.001f};
static float Grid_sync_EKF_R_data[1] = {0.1f};
static float Grid_sync_EKF_x_init[3] = {0.0f, 314.159265359f, 325.0f};
PP_GridSync_EKF Grid_sync_EKF_config = {
  .nom_freq = 50.0f,
  .nom_amplitude = 325.0f,
  .Q_data = Grid_sync_EKF_Q_data,
  .R_data = Grid_sync_EKF_R_data,
  .x_init = Grid_sync_EKF_x_init,
  .P_init = 1.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(12800.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  analogIn Line_voltage = analogIn(AIN1, 1.0, 0.0);
  analogIn Line_current = analogIn(AIN2, 1.0, 0.0);
  expander fan_4 = expander(4);
  expander fan_2 = expander(2);
  gridSyncEKF Grid_sync_EKF = gridSyncEKF(&Grid_sync_EKF_config);
  rootMeanSquare Vrms = rootMeanSquare(128);
  fft_HannWindow FFT_Hann_2048 = fft_HannWindow(2048);
  rootMeanSquare Irms = rootMeanSquare(128);
  node V_I = node("[1.0 1.0]", "[1.0]", Mul);
  fftMagResolver Spectrum = fftMagResolver(FFT_Hann_2048);
  mean Real_power = mean(128);
  gain rad_s_to_Hz = gain(0.159155);
  node Apparent_power_S = node("[1.0 1.0]", "[1.0]", Mul);
  grid_phase_rad = probe("grid_phase_rad");
  grid_amplitude = probe("grid_amplitude");
  vrms = probe("Vrms");
  irms = probe("Irms");
  v_spectrum = VectorProbe("V_spectrum");
  Spectrum_tap = probe("Spectrum_o0");
  real_power = probe("real_power_W");
  grid_freq = probe("grid_freq");
  apparent_power = probe("apparent_power");

  /* Connect Blocks */
  Line_voltage > fan_4;
  Line_current > fan_2;
  fan_4.out(0) > Grid_sync_EKF;
  fan_4.out(1) > Vrms;
  fan_4.out(2) > FFT_Hann_2048;
  fan_4.out(3) > V_I.in(0);
  fan_2.out(0) > Irms;
  fan_2.out(1) > V_I.in(1);
  Grid_sync_EKF.out(1) > rad_s_to_Hz;
  Grid_sync_EKF.out(0) > grid_phase_rad;
  Grid_sync_EKF.out(2) > grid_amplitude;
  Vrms > Apparent_power_S.in(0);
  Vrms > vrms;
  FFT_Hann_2048 > Spectrum;
  Irms > Apparent_power_S.in(1);
  Irms > irms;
  V_I > Real_power;
  Spectrum >> v_spectrum;
  Spectrum > Spectrum_tap;
  Real_power > real_power;
  rad_s_to_Hz > grid_freq;
  Apparent_power_S > apparent_power;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    grid_phase_rad.show();
    grid_amplitude.show();
    vrms.show();
    irms.show();
    v_spectrum.show();
    Spectrum_tap.show();
    real_power.show();
    grid_freq.show();
    apparent_power.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}