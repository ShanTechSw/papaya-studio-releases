/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 00:55:26
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe robot_loc_ekf_0;
probe robot_loc_ekf_1;
probe wmr_ekf_out0;
probe wmr_ekf_out1;
probe gpsins_ekf_out0;
probe gpsins_ekf_out1;
probe unused_signals;

/* Global Struct Declarations */
// Configuration for Robot_Loc_Ekf
static float Robot_Loc_Ekf_Q_data[9] = {0.01f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Robot_Loc_Ekf_R_data[4] = {0.1f, 0.0f, 0.0f, 0.1f};
static float Robot_Loc_Ekf_x_init[3] = {0.0f, 0.0f, 0.0f};
PP_RobotLoc_EKF Robot_Loc_Ekf_config = {
  .wheel_radius = 0.05f,
  .wheel_base = 0.3f,
  .landmark_x = 1.0f,
  .landmark_y = 0.0f,
  .Q_data = Robot_Loc_Ekf_Q_data,
  .R_data = Robot_Loc_Ekf_R_data,
  .x_init = Robot_Loc_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Wmr_Ekf
static float Wmr_Ekf_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Wmr_Ekf_R_data[49] = {0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.1f};
static float Wmr_Ekf_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_WMR_EKF Wmr_Ekf_config = {
  .wheel_base = 0.3f,
  .mag_ref = { 1.0f, 0.0f },
  .Q_data = Wmr_Ekf_Q_data,
  .R_data = Wmr_Ekf_R_data,
  .x_init = Wmr_Ekf_x_init,
  .P_init = 1.0f
};

// Configuration for Gpsins_Ekf
static float Gpsins_Ekf_Q_data[49] = {0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.01f};
static float Gpsins_Ekf_R_data[16] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
static float Gpsins_Ekf_x_init[7] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
PP_GPSINS_EKF Gpsins_Ekf_config = {
  .Q_data = Gpsins_Ekf_Q_data,
  .R_data = Gpsins_Ekf_R_data,
  .x_init = Gpsins_Ekf_x_init,
  .P_init = 10.0f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(0.5f, 0.0f);
  signalSource const_ = signalSource::dc(0.0f);
  signalSource const__2 = signalSource::dc(0.0f);
  signalSource const__3 = signalSource::dc(0.0f);
  signalSource const__4 = signalSource::dc(0.0f);
  signalSource const__5 = signalSource::dc(0.0f);
  signalSource const__6 = signalSource::dc(0.0f);
  signalSource const__7 = signalSource::dc(0.0f);
  signalSource const__8 = signalSource::dc(0.0f);
  signalSource const__9 = signalSource::dc(0.0f);
  signalSource const__10 = signalSource::dc(0.0f);
  signalSource const__11 = signalSource::dc(0.0f);
  signalSource const__12 = signalSource::dc(0.0f);
  signalSource const__13 = signalSource::dc(0.0f);
  signalSource const__14 = signalSource::dc(0.0f);
  signalSource const__15 = signalSource::dc(0.0f);
  signalSource const__16 = signalSource::dc(0.0f);
  signalSource const__17 = signalSource::dc(0.0f);
  expander shared_measurement = expander(3);
  robotLocEKF Robot_Loc_Ekf = robotLocEKF(&Robot_Loc_Ekf_config);
  wmrEKF Wmr_Ekf = wmrEKF(&Wmr_Ekf_config);
  gpsinsEKF Gpsins_Ekf = gpsinsEKF(&Gpsins_Ekf_config);
  merger unused_bus = merger(11);
  robot_loc_ekf_0 = probe("robot_loc_ekf_0");
  robot_loc_ekf_1 = probe("robot_loc_ekf_1");
  wmr_ekf_out0 = probe("wmr_ekf_out0");
  wmr_ekf_out1 = probe("wmr_ekf_out1");
  gpsins_ekf_out0 = probe("gpsins_ekf_out0");
  gpsins_ekf_out1 = probe("gpsins_ekf_out1");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  Source > shared_measurement;
  const_ > Robot_Loc_Ekf.in(1);
  const__2 > Robot_Loc_Ekf.in(2);
  const__3 > Robot_Loc_Ekf.in(3);
  const__4 > Wmr_Ekf.in(1);
  const__5 > Wmr_Ekf.in(2);
  const__6 > Wmr_Ekf.in(3);
  const__7 > Wmr_Ekf.in(4);
  const__8 > Wmr_Ekf.in(5);
  const__9 > Wmr_Ekf.in(6);
  const__10 > Wmr_Ekf.in(7);
  const__11 > Wmr_Ekf.in(8);
  const__12 > Gpsins_Ekf.in(1);
  const__13 > Gpsins_Ekf.in(2);
  const__14 > Gpsins_Ekf.in(3);
  const__15 > Gpsins_Ekf.in(4);
  const__16 > Gpsins_Ekf.in(5);
  const__17 > Gpsins_Ekf.in(6);
  shared_measurement.out(0) > Robot_Loc_Ekf.in(0);
  shared_measurement.out(1) > Wmr_Ekf.in(0);
  shared_measurement.out(2) > Gpsins_Ekf.in(0);
  Robot_Loc_Ekf.out(2) > unused_bus.in(0);
  Robot_Loc_Ekf.out(0) > robot_loc_ekf_0;
  Robot_Loc_Ekf.out(1) > robot_loc_ekf_1;
  Wmr_Ekf.out(2) > unused_bus.in(1);
  Wmr_Ekf.out(3) > unused_bus.in(2);
  Wmr_Ekf.out(4) > unused_bus.in(3);
  Wmr_Ekf.out(5) > unused_bus.in(4);
  Wmr_Ekf.out(6) > unused_bus.in(5);
  Wmr_Ekf.out(0) > wmr_ekf_out0;
  Wmr_Ekf.out(1) > wmr_ekf_out1;
  Gpsins_Ekf.out(2) > unused_bus.in(6);
  Gpsins_Ekf.out(3) > unused_bus.in(7);
  Gpsins_Ekf.out(4) > unused_bus.in(8);
  Gpsins_Ekf.out(5) > unused_bus.in(9);
  Gpsins_Ekf.out(6) > unused_bus.in(10);
  Gpsins_Ekf.out(0) > gpsins_ekf_out0;
  Gpsins_Ekf.out(1) > gpsins_ekf_out1;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    robot_loc_ekf_0.show();
    robot_loc_ekf_1.show();
    wmr_ekf_out0.show();
    wmr_ekf_out1.show();
    gpsins_ekf_out0.show();
    gpsins_ekf_out1.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}