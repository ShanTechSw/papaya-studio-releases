"""9-DOF pose: the board estimates, this script decides whether to believe it.

Run this beside example 86. It builds the diagram, watches the gyroscope
offset settle, then reports the pose along with a judgement about how much of
it is trustworthy at that moment and why.

    python main.py

An orientation estimate is never simply right or wrong. Roll and pitch are
observable from gravity, so they are worth nothing while the platform is
accelerating. Yaw is observable only from the magnetic field, so it is worth
nothing near a motor or a steel bench. Position is a double integral, so it
is worth something for seconds and nothing for minutes. A number that does
not say which of those it is in is a number nobody should act on, and
deciding that is what this script does.

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  motion state    from the gyroscope magnitude and from how far the
                  accelerometer magnitude has left 1 g. Still, rotating,
                  translating, or both.

  tilt trust      an accelerometer measures gravity PLUS the platform's own
                  acceleration and cannot separate them. While the magnitude
                  is away from 1 g, roll and pitch are leaning into the
                  manoeuvre by roughly atan(a/g) and no filter setting
                  prevents it.

  heading trust   the magnetic field magnitude is a constant of the place.
                  Rotating the sensor cannot change it. If it changes, iron
                  or a current has, and the heading is following that
                  instead of north.

  bias trust      the offset the filter has found for the gyroscope. It
                  settles in about Kp/Ki seconds. Before that it is a
                  transient, not a measurement, and this script says so
                  rather than printing it as though it were.

  position trust  the vertical channel is immune to tilt error in the first
                  order and the horizontal ones are not, so they are
                  reported separately and with different expectations.
"""
from __future__ import annotations

import math
import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SETTLE_SECONDS = 90.0       # the offset loop and three high passes need it
WATCH_SECONDS = 45.0
DECIDE_EVERY = 0.25
DEMONSTRATE_GRAVITY_INPUT = True    # briefly set g_local_g to 0 and report

# Set this to False on a real platform. The design plays six reference
# traces that are only meaningful while the sensors' simulated models are
# active; with it on, the script prints the error against them.
SCORE_AGAINST_REFERENCE = True

SENSORS = ("ax", "ay", "az", "gx", "gy", "gz", "mx", "my", "mz")
ESTIMATOR = ("qw", "qx", "qy", "qz", "bias_x", "bias_y", "bias_z")
POSE = ("roll", "pitch", "yaw", "roll_ref", "pitch_ref", "yaw_ref",
        "x", "y", "z", "x_ref", "y_ref", "z_ref")

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

STILL_RATE = 0.05           # rad/s, gyroscope magnitude
STILL_ACCEL = 0.02          # g away from 1
MOVING_ACCEL = 0.03         # g away from 1 before it counts as translating
TILT_SUSPECT = 0.05         # g away from 1 before roll and pitch are suspect
FIELD_SUSPECT = 0.15        # fraction the field magnitude may drift
GIMBAL_PITCH = 80.0         # degrees
BIAS_SETTLED = 0.0005       # rad/s of change over the settling check
RAD2DEG = 180.0 / math.pi


def magnitude(a, b, c):
    return math.sqrt(a * a + b * b + c * c)


def describe_motion(row):
    """Still, rotating, translating, or a combination, with the numbers."""
    rate = magnitude(row["gx"], row["gy"], row["gz"])
    accel = magnitude(row["ax"], row["ay"], row["az"])
    off = abs(accel - 1.0)
    turning = rate >= STILL_RATE
    moving = off >= MOVING_ACCEL
    if not turning and off < STILL_ACCEL:
        return "still", rate, accel
    if turning and moving:
        return "rotating and translating", rate, accel
    if turning:
        return "rotating", rate, accel
    if moving:
        return "translating", rate, accel
    return "drifting", rate, accel


def assess(row, field_reference, bias_settled):
    """What of this pose is worth acting on right now.

    Returns (trust, notes). *trust* is full, tilt_suspect, heading_suspect,
    both_suspect or warming_up.
    """
    notes = []
    accel = magnitude(row["ax"], row["ay"], row["az"])
    field = magnitude(row["mx"], row["my"], row["mz"])

    tilt_bad = abs(accel - 1.0) > TILT_SUSPECT
    if tilt_bad:
        lean = math.degrees(math.atan2(abs(accel - 1.0), 1.0))
        notes.append(
            f"specific force is {accel:.3f} g, not 1. Roll and pitch are "
            f"leaning into the manoeuvre by up to about {lean:.1f} degrees, "
            f"and no gain setting removes that")

    field_bad = False
    if field_reference:
        drift = abs(field - field_reference) / field_reference
        field_bad = drift > FIELD_SUSPECT
        if field_bad:
            notes.append(
                f"the magnetic field reads {field:.1f} uT against the "
                f"{field_reference:.1f} uT learned at rest, a change of "
                f"{100 * drift:.0f} per cent. Rotating a sensor cannot do "
                f"that; iron or a current has. The heading is following it")

    if abs(row["pitch"]) > GIMBAL_PITCH:
        notes.append(f"pitch is {row['pitch']:+.1f} degrees, close to "
                     f"vertical, where roll and yaw stop being distinct")

    if not bias_settled:
        return "warming_up", notes + [
            "the gyroscope offset has not settled yet, so every angle here "
            "still carries part of it"]
    if tilt_bad and field_bad:
        return "both_suspect", notes
    if tilt_bad:
        return "tilt_suspect", notes
    if field_bad:
        return "heading_suspect", notes
    return "full", notes or ["gravity and the magnetic field both read as "
                             "they should"]


def position_report(row, since):
    """Displacement since the last still moment, and what to make of it."""
    dx = row["x"] - since["x"]
    dy = row["y"] - since["y"]
    dz = row["z"] - since["z"]
    horizontal = math.hypot(dx, dy)
    return (f"moved {horizontal * 100:.1f} cm horizontally and "
            f"{dz * 100:+.1f} cm vertically since it was last still. The "
            f"vertical figure is the one to trust: a tilt error tips gravity "
            f"straight into the horizontal channels and only touches the "
            f"vertical one in the second order.")


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 86_imu_pose_and_strapdown.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def _vector(d, probe_obj, names):
    raw = d.papaya0.readVectProbeLive(probe_obj, len(names))
    if raw is None or len(raw) < 4 * len(names):
        return None
    return dict(zip(names, struct.unpack(f"<{len(names)}f", raw[:4 * len(names)])))


def read_row(d):
    """The nine channels, the estimator state and the pose, in one reading."""
    sensors = _vector(d, d.sensors, SENSORS)
    estimator = _vector(d, d.estimator, ESTIMATOR)
    pose = _vector(d, d.pose, POSE)
    if sensors is None or estimator is None or pose is None:
        return None
    row = {}
    row.update(sensors)
    row.update(estimator)
    row.update(pose)
    return row


def collect(d, seconds, min_rows=0):
    """Readings for *seconds*, and at least *min_rows* of them.

    THE SECONDS ARE A MINIMUM, NOT A PROMISE OF ROWS. A row here is a
    whole vector read, and how many arrive in half a second is set by the
    board's window rather than by this script. The loops below can shrug
    off an empty return and read again, but the gravity demonstration
    wants one particular average and used to index straight into an
    empty list, ending the run with IndexError after everything else had
    already reported. The bound still returns rather than hanging when a
    board has genuinely stopped producing.
    """
    rows = []
    started = time.monotonic()
    deadline = started + seconds
    hard_stop = started + max(seconds * 6.0, seconds + 15.0)
    while True:
        row = read_row(d)
        if row is not None:
            rows.append(row)
        now = time.monotonic()
        if now >= hard_stop:
            return rows
        if now >= deadline and len(rows) >= min_rows:
            return rows


def average(rows):
    """Mean of every channel across *rows*.

    Refuses an empty list by name. ``rows[0]`` on nothing is an
    IndexError several frames away from the read that came back empty,
    which says nothing about what went wrong.
    """
    if not rows:
        raise ValueError(
            "no readings to average: the board produced no vector inside "
            "the window. Check that it is still sampling.")
    return {k: statistics.fmean(r[k] for r in rows) for k in rows[0]}


def main():
    print("PAPAYA 9-DOF pose monitor")
    print("=" * 72)
    d = load_design()

    print(f"\nSettling for {SETTLE_SECONDS:.0f} s. The gyroscope offset loop "
          f"needs about ten seconds and the three high passes in the position\n"
          f"path need about sixty between them. Keep the platform still for "
          f"the first few seconds if you can.")
    start = time.monotonic()
    first = None
    field_reference = None
    bias_settled = False
    last_bias = None
    settled_at = None
    while time.monotonic() - start < SETTLE_SECONDS:
        rows = collect(d, 2.0)
        if not rows:
            continue
        row = average(rows)
        if first is None:
            first = row
        state, rate, accel = describe_motion(row)
        if state == "still":
            field = magnitude(row["mx"], row["my"], row["mz"])
            field_reference = field if field_reference is None else \
                0.9 * field_reference + 0.1 * field
        bias = (row["bias_x"], row["bias_y"], row["bias_z"])
        if last_bias is not None and not bias_settled:
            change = max(abs(a - b) for a, b in zip(bias, last_bias))
            if change < BIAS_SETTLED:
                bias_settled = True
                settled_at = time.monotonic() - start
                print(f"\n  [{settled_at:5.1f} s] gyroscope offset settled at "
                      f"({bias[0] * RAD2DEG:+.3f}, {bias[1] * RAD2DEG:+.3f}, "
                      f"{bias[2] * RAD2DEG:+.3f}) degrees per second")
                print("            read the AHRS ports directly and you "
                      "get the same three numbers with the OPPOSITE sign: "
                      "those ports carry the correction, not the offset")
        last_bias = bias
    if field_reference:
        print(f"  magnetic field at rest: {field_reference:.1f} uT. Anything "
              f"more than {100 * FIELD_SUSPECT:.0f} per cent away from that "
              f"is a disturbance, not a rotation.")
    else:
        print("  the platform was never still, so no field reference was "
              "learned and the heading cannot be checked")
    if not bias_settled:
        print("  the gyroscope offset never stopped moving. Either the "
              "platform never rested or the offset is not constant.")

    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)
    started = time.monotonic()
    last_still = None
    last_key = None
    tally = {}
    errors = {k: [] for k in ("roll", "pitch", "yaw", "x", "y", "z")}
    while time.monotonic() - started < WATCH_SECONDS:
        rows = collect(d, DECIDE_EVERY)
        if len(rows) < 2:
            continue
        row = average(rows)
        motion, rate, accel = describe_motion(row)
        trust, notes = assess(row, field_reference, bias_settled)
        tally[(motion, trust)] = tally.get((motion, trust), 0) + 1
        if motion == "still":
            last_still = row
        if SCORE_AGAINST_REFERENCE:
            for k in ("roll", "pitch", "yaw", "x", "y", "z"):
                errors[k].append(row[k] - row[k + "_ref"])

        key = (motion, trust)
        if key != last_key:
            t = time.monotonic() - started
            print(f"\n[{t:6.1f} s] {motion.upper()}  "
                  f"rate {rate * RAD2DEG:6.1f} deg/s   |a| {accel:.3f} g")
            print(f"           attitude  roll {row['roll']:+7.2f}  "
                  f"pitch {row['pitch']:+7.2f}  yaw {row['yaw']:+7.2f} degrees")
            if SCORE_AGAINST_REFERENCE:
                print(f"           truth     roll {row['roll_ref']:+7.2f}  "
                      f"pitch {row['pitch_ref']:+7.2f}  "
                      f"yaw {row['yaw_ref']:+7.2f} degrees")
            print(f"           verdict   {trust.replace('_', ' ')}")
            for n in notes:
                print(f"             - {n}")
            if last_still is not None and motion != "still":
                print(f"           position  {position_report(row, last_still)}")
            last_key = key

    print("\n" + "-" * 72)
    print("Summary")
    for (motion, trust), n in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {n:4d} x  {motion:24s} {trust}")
    if SCORE_AGAINST_REFERENCE and errors["roll"]:
        print("\nError against the simulated truth, root mean square:")
        for k, unit, scale in (("roll", "degrees", 1.0),
                               ("pitch", "degrees", 1.0),
                               ("yaw", "degrees", 1.0),
                               ("x", "cm", 100.0), ("y", "cm", 100.0),
                               ("z", "cm", 100.0)):
            e = errors[k]
            rms = math.sqrt(sum(v * v for v in e) / len(e)) * scale
            print(f"  {k:6s} {rms:8.3f} {unit}")
        print("  set SCORE_AGAINST_REFERENCE to False on a real platform: "
              "the reference traces keep playing whatever the sensors do.")

    if DEMONSTRATE_GRAVITY_INPUT:
        print("\nWhat the gravity input is for. Setting g_local_g to 0 for "
              "three seconds:")
        before = average(collect(d, 1.0, min_rows=1))
        d.papaya0.setInput(d.gravity, 0.0)
        time.sleep(3.0)
        during = average(collect(d, 0.5, min_rows=1))
        d.papaya0.setInput(d.gravity, 1.0)
        print(f"  vertical channel went from {before['z'] * 100:+.1f} cm to "
              f"{during['z'] * 100:+.1f} cm")
        print("  with gravity no longer added back, the standing -1 g on the "
              "vertical accelerometer is integrated as motion. The leak is "
              "what stops it running away entirely.")
        time.sleep(5.0)
        after = average(collect(d, 0.5, min_rows=1))
        print(f"  restored, and back to {after['z'] * 100:+.1f} cm")

    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
