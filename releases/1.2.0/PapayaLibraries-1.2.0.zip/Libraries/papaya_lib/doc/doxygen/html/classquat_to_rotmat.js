var classquat_to_rotmat =
[
    [ "quatToRotmat", "classquat_to_rotmat.html#ab8d0f9f739cdeb9a0b570162a16645d3", null ]
];