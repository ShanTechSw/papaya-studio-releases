"""Fetch the board's own diagnosis after a refusal: GetDebugLog (0x2025).

Why this module exists
----------------------
When the board refuses a config-phase command it answers design status
8, BadRequest.  The number is all the host shows the user; the REASON is
already written down on the board.  The board logs every header
rejection into a 16 KB debug ring with the exact diagnosis the user
lacks::

    USB cfg rx: header invalid (seq cmd=%u board=%u crc rx=... calc=...) sub=0x%04X

There is a matching line for a rejected body frame.  Both include the
board's OWN expected sequence number, which is precisely the datum a
desync investigation needs.  ``GetDebugLog`` (0x2025) returns that ring
as a data response, it is one of the few commands the board still
accepts after a failure, and debug logging is on by default.  The
snapshot also ends with a build identity stamp of the form
``FW build <date> <time> | tag=...``, so the tail doubles as proof of
WHICH firmware build is doing the logging.

Why raw primitives and not the connection-level helper
------------------------------------------------------
Papaya Studio has its own GetDebugLog helper, and it is right for a link
Studio owns.  It cannot serve the one caller that needs a mid-session
fetch, the loopback bridge: while a debugged program is attached, every
Studio-side command path is gated off, and Studio's own counter is not
the counter the board is following (the CLIENT numbers the session's
commands).  The bridge owns the link on its session thread and relays
through the raw ``write`` / ``read_upto`` primitives, so the fetch
speaks through those same two injected callables and nothing else.
Qt-free, thread-agnostic, fake-testable.

The sequence choreography (why this cannot desync the client)
-------------------------------------------------------------
The fetch needs a sequence number the board will accept, and it runs
precisely BECAUSE sequence numbers went wrong.  The escape is the
1-byte ``SwitchBackToCfg`` (0x03): it is sequence-less, answer-less, and
makes the board release its configuration session.  The NEXT command to
arrive re-claims that session, and re-claiming ZEROES the board's
sequence counter.  So the fetch brackets itself:

1. ``SwitchBackToCfg``: release, whatever the counter was;
2. ``GetDebugLog`` at seq 0: re-claims, board zeroes, 0 == 0 accepted;
3. drain the WHOLE data payload (see the trap below);
4. ``SwitchBackToCfg`` again: release, so the CLIENT's next command
   re-claims at zero.

Step 4 is what keeps the client's own recovery working: the C++ library
reacts to a config-phase BadRequest by re-anchoring its counter to 0 and
retrying ONCE, without sending any SwitchToCfg, because the board is
provably at 0 right then (the rejected packet's arrival re-claimed the
session and zeroed the counter, and a refusal response never advances
it).  Our successful step 2 ADVANCES the board to 1, which would
sabotage that retry; step 4 restores exactly the zero-on-next-claim
state the retry assumes.

The full-drain trap
-------------------
On success the board ships the ring's whole content, up to 16 KB, as one
data response.  A short read leaves the rest in the pipe and EVERY
SUBSEQUENT COMMAND FAILS, the documented "board appears dead after a
successful GetDebugLog" failure (papaya_lib/PAPAYA.h, ``getDebugLog``
doc).  So the payload loop here never stops at a "short" transfer: it
stops at the 16 KB ceiling (``PP_DEBUG_LOG_MAX_BYTES``, which is the
board's own ring size) or on a read that returns NOTHING after data has
flowed (the pipe provably empty), and the trailing drain eats any
straggler even on the failure paths.  An EMPTY log sends no data
response at all, yet still answers DesignOk; that is the ``"empty"``
outcome, not an error.

The time budget
---------------
The bridge runs this synchronously on its session thread while the
debugged program blocks on a TCP reply, and the client's socket deadline
is its op timeout plus a fixed 2000 ms grace
(``PAPAYA_BRIDGE_SOCKET_GRACE_MS``, papaya_lib/ports/pc_usb/include/
PapayaStudioBridge.h).  Overrun it and the diagnostic KILLS the session
it is diagnosing.  Every wait below is therefore bounded by ATTEMPT
COUNTS, not just deadlines: worst case is roughly 2*3*30 ms (drains) +
3*150 ms (response polls) + 3*150 ms (empty data polls) ~= 1.1 s,
comfortably under the grace; fakes whose ``read_upto`` returns instantly
finish in microseconds.  On a healthy board the response is prepared
before the response request is even sent (the single-shot rule in
``_send_prebuilt_frame_unlocked``), so the success path costs one poll
slice plus the payload reads.
"""

from __future__ import annotations

import struct
from typing import Callable, List, NamedTuple, Optional

from papaya.constants import (
    PP_CMD_CRC_SIZE,
    PP_CMD_HEADER_SIZE,
    PP_CMD_READ,
    PP_CMD_RESPONSE_ID,
    PP_CMD_SWITCH_BACK_TO_CFG,
    PP_CMD_WRITE,
    PP_FIXED_SIZE,
    PP_RESPONSE_REQ_SIZE,
    PP_RESPONSE_SIZE,
)
from papaya.context import PapayaContext
from papaya.enums import PP_DesignStatus, PP_FuncId, PP_SubFuncId

__all__ = [
    "DebugLogFetch",
    "PP_DEBUG_LOG_MAX_BYTES",
    "TAIL_MAX_CHARS",
    "TAIL_MAX_LINES",
    "build_get_debug_log_frame",
    "fetch_debug_log",
    "refusal_note_details",
    "tail_lines",
]

#: The board's debug-ring size, 16 KB: the same number the C++ library
#: publishes as ``PP_DEBUG_LOG_MAX_SIZE`` in papaya_lib/PAPAYA.h.
#: The payload can never legitimately exceed this.
PP_DEBUG_LOG_MAX_BYTES = 16 * 1024

#: What "the relevant tail" means, in console terms: rejection lines are
#: ~80-100 characters each, and one refusal burst (a command, its retry,
#: the build stamp) fits in a dozen lines.  More than this drowns the
#: very exchange lines the tail is meant to explain.
TAIL_MAX_LINES = 12
TAIL_MAX_CHARS = 1600

# -- bounded-wait knobs (attempt counts, per the time-budget note) -------
_DRAIN_ATTEMPTS = 3
_DRAIN_TIMEOUT_MS = 30
_RESPONSE_POLL_ATTEMPTS = 3
_RESPONSE_POLL_TIMEOUT_MS = 150
_DATA_EMPTY_POLL_ATTEMPTS = 3
_DATA_POLL_TIMEOUT_MS = 150
#: Defensive ceiling on accumulated payload: the ring plus one transfer
#: of slack.  Beyond this something is lying and we stop feeding it.
_PAYLOAD_HARD_CAP = PP_DEBUG_LOG_MAX_BYTES + 4096

_U16 = struct.Struct("<H")
_U32 = struct.Struct("<I")


class DebugLogFetch(NamedTuple):
    """One fetch attempt's outcome, honestly labelled.

    ``outcome``:
      * ``"ok"``:       the board answered and sent log text (``text``);
      * ``"empty"``:    the board answered DesignOk but sent no text
        (nothing has been logged yet, or this firmware build has debug
        logging turned off);
      * ``"refused"``:  the board answered with a non-OK ``status``;
      * ``"silent"``:   no decodable answer arrived (firmware that
        predates 0x2025, or a link already gone).
    """

    outcome: str
    status: Optional[int]
    text: str


def build_get_debug_log_frame(seq: int = 0) -> bytes:
    """The 22-byte GetDebugLog command: 18-byte header + empty body.

    Byte-identical to the frame Papaya Studio builds for the same
    command, reproduced here so this module stays importable without
    Qt.  The header layout on the wire is ``u16 seq @0 | u8 rw @2 |
    u16 size @3 | u16 block @5 | u8 func @7 | u16 subfunc @8 |
    u8 nparams @10 | u8 nchunks @11 | u16 last_chunk @12 | u32 crc @14``
    over bytes 0..13; the zero-param body is the CRC32 of nothing.
    """
    header = bytearray(PP_CMD_HEADER_SIZE)
    _U16.pack_into(header, 0x00, seq & 0xFFFF)
    header[0x02] = PP_CMD_WRITE
    _U16.pack_into(header, 0x03, PP_FIXED_SIZE)        # body = bare CRC
    _U16.pack_into(header, 0x05, 0xFFFF)               # no block targeted
    header[0x07] = int(PP_FuncId.Manageblock) & 0xFF
    _U16.pack_into(header, 0x08, int(PP_SubFuncId.GetDebugLog) & 0xFFFF)
    header[0x0A] = 0                                   # zero params
    header[0x0B] = 1                                   # one chunk
    _U16.pack_into(header, 0x0C, PP_FIXED_SIZE)
    crc = PapayaContext.calculate_crc(bytes(header),
                                      PP_CMD_HEADER_SIZE - PP_CMD_CRC_SIZE)
    _U32.pack_into(header, PP_CMD_HEADER_SIZE - PP_CMD_CRC_SIZE, crc)
    body_crc = PapayaContext.calculate_crc(b"", 0)
    return bytes(header) + _U32.pack(body_crc)


def _build_response_request(seq: int = 0) -> bytes:
    request = bytearray(PP_RESPONSE_REQ_SIZE)
    _U16.pack_into(request, 0x00, seq & 0xFFFF)
    request[0x02] = PP_CMD_READ
    _U16.pack_into(request, 0x03, PP_CMD_RESPONSE_ID)
    crc = PapayaContext.calculate_crc(bytes(request),
                                      PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE)
    _U32.pack_into(request, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE, crc)
    return bytes(request)


def _decode_response(raw: bytes, expected_seq: int) -> Optional[int]:
    """The status byte of a valid 7-byte response for *expected_seq*."""
    if raw is None or len(raw) != PP_RESPONSE_SIZE:
        return None
    crc_at = PP_RESPONSE_SIZE - PP_CMD_CRC_SIZE
    if (_U32.unpack_from(raw, crc_at)[0]
            != PapayaContext.calculate_crc(bytes(raw), crc_at)):
        return None
    if _U16.unpack_from(raw, 0)[0] != (expected_seq & 0xFFFF):
        return None
    return int(raw[2])


def _drain(read_upto: Callable, attempts: int = _DRAIN_ATTEMPTS) -> None:
    """Eat stale RX bytes; stops at the first empty read."""
    for _ in range(attempts):
        try:
            if not read_upto(4096, _DRAIN_TIMEOUT_MS):
                return
        except Exception:                              # noqa: BLE001
            return          # a dead link has nothing left to drain


def _checked_write(write: Callable, data: bytes, what: str) -> None:
    if not write(bytes(data)):
        raise RuntimeError(f"USB write failed during the debug-log "
                           f"fetch ({what})")


def fetch_debug_log(write: Callable[[bytes], bool],
                    read_upto: Callable[[int, int], Optional[bytes]],
                    ) -> DebugLogFetch:
    """One bracketed GetDebugLog round-trip over raw link primitives.

    *write* sends raw bytes to the board and returns True on success;
    *read_upto* takes a byte count and a timeout in milliseconds and
    returns what arrived, or None.  Any pair with that shape works,
    including fakes.  Returns
    a :class:`DebugLogFetch`; raises only when the link itself fails
    mid-fetch (a failed write / a raising primitive); the caller turns
    that into one honest console sentence.  Whatever happens, the
    trailing ``SwitchBackToCfg`` + drain still run, so the board is
    handed back released and the pipe empty (the choreography and the
    full-drain trap in the module docstring).
    """
    try:
        # 1. Release the config interface: our command, not the client's
        #    stale counter, decides what the board expects next.
        _checked_write(write, bytes([PP_CMD_SWITCH_BACK_TO_CFG]),
                       "leading SwitchBackToCfg")
        _drain(read_upto)

        # 2. GetDebugLog at seq 0: the re-claim zeroes the board's
        #    counter, so 0 is the one number that cannot be refused.
        frame = build_get_debug_log_frame(seq=0)
        _checked_write(write, frame[:PP_CMD_HEADER_SIZE], "command header")
        _checked_write(write, frame[PP_CMD_HEADER_SIZE:], "command body")
        # Response request EXACTLY once: re-sending queues stale 9-byte
        # frames that the board later mis-reads as a command header,
        # which halts it.  Every path that sends a response request
        # obeys the same single-shot rule.
        _checked_write(write, _build_response_request(seq=0),
                       "response request")

        status: Optional[int] = None
        for _ in range(_RESPONSE_POLL_ATTEMPTS):
            raw = read_upto(64, _RESPONSE_POLL_TIMEOUT_MS)
            if not raw:
                continue
            status = _decode_response(bytes(raw), 0)
            if status is not None:
                break
        if status is None:
            return DebugLogFetch("silent", None, "")
        if status != int(PP_DesignStatus.DesignOk):
            return DebugLogFetch("refused", status, "")

        # 3. The data payload, drained to pipe-empty, never cut short
        #    (the full-drain trap: leftovers make the board appear dead).
        chunks = bytearray()
        empty_polls = 0
        while len(chunks) < _PAYLOAD_HARD_CAP:
            data = read_upto(4096, _DATA_POLL_TIMEOUT_MS)
            if data:
                chunks.extend(data)
                if len(chunks) >= PP_DEBUG_LOG_MAX_BYTES:
                    break              # the ring's ceiling, all of it
                continue
            if chunks:
                break                  # nothing after data: pipe empty
            empty_polls += 1
            if empty_polls >= _DATA_EMPTY_POLL_ATTEMPTS:
                break                  # DesignOk with no payload: empty log
        if not chunks:
            return DebugLogFetch("empty", int(status), "")
        text = bytes(chunks).decode("utf-8", errors="replace")
        return DebugLogFetch("ok", int(status), text.replace("\x00", ""))
    finally:
        # 4. Hand the board back the way the client's own BadRequest
        #    retry (9b8e1bf) assumes it: interface released, counter
        #    zeroed on the next claim, pipe empty.  Best-effort on the
        #    failure paths: a raising write has nothing left to fix.
        try:
            write(bytes([PP_CMD_SWITCH_BACK_TO_CFG]))
        except Exception:                              # noqa: BLE001
            pass
        _drain(read_upto)


def tail_lines(text: str, max_lines: int = TAIL_MAX_LINES,
               max_chars: int = TAIL_MAX_CHARS) -> List[str]:
    """The last *max_lines* non-empty lines, within a *max_chars* budget.

    Newest lines win: when the character budget cannot hold all
    *max_lines*, the OLDEST of them are dropped first, and a single
    oversized line is head-truncated (the end of a log line carries the
    values; the start carries the prefix already known from context).
    """
    lines = [ln.rstrip() for ln in text.replace("\r\n", "\n").split("\n")]
    lines = [ln for ln in lines if ln.strip()]
    picked: List[str] = []
    total = 0
    for ln in reversed(lines[-int(max_lines):]):
        if len(ln) > max_chars:
            ln = "…" + ln[-(max_chars - 1):]
        if picked and total + len(ln) > max_chars:
            break
        picked.append(ln)
        total += len(ln)
    return list(reversed(picked))


def _status_label(status: Optional[int]) -> str:
    if status is None:
        return "no status"
    try:
        return f"{PP_DesignStatus(int(status)).name} (status {int(status)})"
    except ValueError:
        return f"status {int(status)}"


def refusal_note_details(result: DebugLogFetch) -> List[str]:
    """Console-ready detail lines for one fetch result, one authority.

    Feeds a ``kind="note"`` conversation event, the free-text shape the
    console already renders, so the bridge and any future caller word
    every outcome identically.  Each
    degraded outcome is ONE clear sentence, never a traceback, never
    silence (the honesty rule this feature was specified with).
    """
    if result.outcome == "ok":
        all_lines = [ln for ln in result.text.replace("\r\n", "\n").split("\n")
                     if ln.strip()]
        tail = tail_lines(result.text)
        header = (f"the board's own debug log after the refusal "
                  f"(GetDebugLog 0x2025, last {len(tail)} of "
                  f"{len(all_lines)} lines):")
        return [header] + [f"  {ln}" for ln in tail]
    if result.outcome == "refused":
        return [f"asked the board why (GetDebugLog 0x2025): the board "
                f"refused the log request itself with "
                f"{_status_label(result.status)}; no diagnosis available"]
    if result.outcome == "empty":
        return ["asked the board why (GetDebugLog 0x2025): the board "
                "answered but its debug log is empty; this firmware build "
                "may have debug logging turned off"]
    return ["asked the board why (GetDebugLog 0x2025): no answer; this "
            "firmware may predate the debug-log opcode (if the board "
            "stops responding now, replug it)"]
