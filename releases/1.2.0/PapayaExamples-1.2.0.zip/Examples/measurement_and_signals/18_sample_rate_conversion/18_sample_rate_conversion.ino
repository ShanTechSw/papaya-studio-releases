/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 10000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe down;
probe up;
probe box;
probe err;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(10000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Sine_sweep = signalSource::chirpLinear(10.0f, 4000.0f, 2.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  expander fan_5 = expander(5);
  movingAverage Anti_alias__8 = movingAverage(8);
  interpolation Interpolate_x4 = interpolation(4);
  movingAverage Anti_alias__8_b = movingAverage(8);
  movingAverage Boxcar__32 = movingAverage(32);
  interpolation Interpolate_x8 = interpolation(8);
  node Smoother_residual = node("[1.0 -1.0]", "[1.0]", Sum);
  down = probe("boxcar_8");
  up = probe("upsampled");
  box = probe("boxcar_32");
  err = probe("smoother_residu");

  /* Connect Blocks */
  Sine_sweep > fan_5;
  fan_5.out(0) > Anti_alias__8;
  fan_5.out(1) > Interpolate_x4;
  fan_5.out(2) > Anti_alias__8_b;
  fan_5.out(4) > Boxcar__32;
  fan_5.out(3) > Smoother_residual.in(1);
  Anti_alias__8 > down;
  Interpolate_x4 > up;
  Anti_alias__8_b > Interpolate_x8;
  Boxcar__32 > box;
  Interpolate_x8 > Smoother_residual.in(0);
  Smoother_residual > err;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    down.show();
    up.show();
    box.show();
    err.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}