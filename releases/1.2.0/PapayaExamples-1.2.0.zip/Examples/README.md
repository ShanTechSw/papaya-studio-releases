# PAPAYA Studio: 173 Example Designs (.pap)

There are two tiers, and they answer two different questions.

**`getting_started/`, 78 designs.** Three to six blocks each, no application,
one idea per file. Open one when you want to know what a block DOES: what it
puts out when you put a sine into it, which port its threshold arrives on, what
its parameters change. Between them they touch every block type in the
catalogue bar six that cannot appear in a running design at all (see below).

**The eight application folders, 95 designs.** Real machines doing real jobs,
grouped by APPLICATION FIELD because that is what a reader with a problem
arrives with. They used to be grouped by difficulty, which is the one thing
nobody can search by: somebody who wants to watch a bearing does not know, and
should not have to guess, whether that counts as advanced.

**Every design is a PROJECT FOLDER**, named after the design it holds:

    getting_started/g02_an_input_you_can_turn/
        g02_an_input_you_can_turn.pap     the diagram, opened in Papaya Studio
        g02_an_input_you_can_turn.ino     the sketch exported from it
        papaya_design.py                  the Python exported from it
        main.py                           the program that drives it

That is the arrangement Papaya Studio generates into: `papaya_design.py` is
the diagram, and `main.py` is yours. Generating the design again rewrites the
first and never touches the second, so a project you have been writing code in
survives every regeneration.

`main.py` is optional; a folder without one is a design and its exports,
nothing more. When it is there, Papaya Studio offers it: choose Python for a
folder holding `main.py` and it asks whether to use that file as the main or
generate an empty one, and it checks first that every probe and input the file
names really is in the diagram. A folder can hold `main.cpp` as well, or
instead, and the same offer is made when you generate C++.

Designs that read the board's hardware also carry an attached simulated model
on every hardware block, so the same file is a bench experiment with a board
attached and a self-contained simulation without one.

The application designs are numbered 1 to 96 and there are 95 of them: number
41 was withdrawn and its number was not reused. The getting-started designs are
numbered g01 to g78, so the two sets never collide.

**All 173 files pass diagram validation**: every port connected, no fan-out, no
multi-driver. They open with **File -> Open** in Papaya Studio.

**173/173 also generate code** on every export target: self-contained Python,
C++ and Arduino.

Auto-completion: fan-out is split with EXPANDER blocks, unconnected inputs get constant INPUT blocks (`const`, value 0), and unconsumed outputs are probed (or bundled through a MERGER when that would exceed the Fs-dependent probe budget). Auto-added blocks sit in a labelled row below the main diagram.

## getting started

Small designs whose subject is a block rather than a machine. One generator, the
blocks the example is about, a probe on each of them, and a project comment that
says what to look at. The median design has four blocks that are not plumbing.

Every one of the 78 ships a `main.py`, and the fourteen that carry an
input you can write while the design runs ship a **PyQt6 control panel** in it:
a slider, a dial, a switch or a number box per input, a live readout of every
probe, and a line that says what the readings mean. That panel is USER code. It
is in the script, it is not something the Studio provides, and it is there so
that the panel you ship with your own product is one you wrote and can change.

| # | What it is about |
|---|---|
| g01 to g09 | The canvas itself: wires, probes, inputs, expanders, mergers, switches, macros, vector probes, CPU load |
| g10 to g16 | Making signals, and the arithmetic blocks |
| g17 to g21 | Time: integrating, differentiating, delaying, transfer functions, state space |
| g22 to g26 | Nonlinearities: clipping, dead zones, hysteresis, backlash, rate limits, friction |
| g27 to g34 | Filters, from a first low-pass to the ones that adapt while they run |
| g35 to g38 | Spectra, windows and wavelets |
| g39 to g46 | Features, statistics and a tiny classifier |
| g47 to g55 | Control: a first loop, live gains, auto-tuning, adaptive controllers, motion profiles |
| g56 to g58 | Machines, mixers and quaternions |
| g59 to g64 | Estimation: Kalman filters, identification, the packaged EKFs, attitude |
| g65 to g71 | Audio, and the biosignal blocks |
| g72 to g78 | Hardware: analog, PWM, motor, IMU, audio, record and replay, expansion |

**Seven block types are not in any design, and cannot be.** Alt Hold Cascade,
Attitude Control Cascade, Smith Predictor and Two-DOF Feedforward PID are
containers: validation refuses each with "it is a picture of a structure you
build yourself", so you place the blocks it describes and wire them. Decimation
is a placeholder for a downsampling block the board does not have; constructing
it raises. Notch Multi is no longer placed by the palette at all, which now asks
for the frequencies and places a populated macro of notch stages instead. Audio
File embeds a clip into the deploy stream, so building the design opens the file
and no recording that shipped with an example could be found: drop one in beside
the microphone in g76 and point it at a file of your own.

## The eight application fields

Each folder is a field, not a difficulty. Numbers are unchanged and
unique across the whole corpus, so example 51 is example 51 wherever
it lives.

| Field | Designs | What is in it |
|---|---:|---|
| [`measurement_and_signals/`](measurement_and_signals/) | 16 | Reading a signal and shaping it: meters, arithmetic, filters, transforms and rate conversion. Start here. |
| [`audio_and_acoustics/`](audio_and_acoustics/) | 21 | Anything a microphone hears or a speaker plays: effects, synthesis, analysis, and the adaptive filters that clean a room up. |
| [`motion_and_drives/`](motion_and_drives/) | 19 | Making a mechanism do what it is told: servo loops, cascades, state feedback, and the classic unstable plants a control course is built on. |
| [`power_and_energy/`](power_and_energy/) | 7 | Converters, inverters, machine drives and batteries, where the loop closes around something that carries current. |
| [`condition_monitoring/`](condition_monitoring/) | 14 | Deciding whether a machine is healthy from what it vibrates, radiates and how fast it turns. |
| [`navigation_and_attitude/`](navigation_and_attitude/) | 7 | Where a thing is and which way it is pointing: attitude filters, dead reckoning and inertial fusion. |
| [`estimation_and_identification/`](estimation_and_identification/) | 6 | Recovering what cannot be measured: observers, Kalman filters, online identification, and voting between sensors that disagree. |
| [`communications_and_radar/`](communications_and_radar/) | 5 | Carrying bits or finding targets: loops that lock, pulses that compress and carriers that carry. |


## measurement and signals

Reading a signal and shaping it: meters, arithmetic, filters, transforms and rate conversion. Start here.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 1 | `measurement_and_signals/01_hello_sine.pap` | Hello Sine | 3 | 2 | 1000 | OK | OK |
| 3 | `measurement_and_signals/03_usb_voltmeter_thermometer.pap` | USB Voltmeter & Thermometer | 6 | 4 | 1000 | OK | OK |
| 4 | `measurement_and_signals/04_math_playground.pap` | Math Playground | 19 | 18 | 1000 | OK | OK |
| 5 | `measurement_and_signals/05_transcendental_explorer.pap` | Transcendental Function Explorer | 21 | 21 | 1000 | OK | OK |
| 6 | `measurement_and_signals/06_signal_routing_patchbay.pap` | Signal-Routing Patchbay | 19 | 22 | 1000 | OK | OK |
| 7 | `measurement_and_signals/07_pwm_dimmer_tachometer.pap` | PWM Dimmer & Tachometer Loopback | 14 | 12 | 1000 | OK | OK |
| 8 | `measurement_and_signals/08_integrator_derivative_sandbox.pap` | Integrator / Derivative Sandbox | 18 | 15 | 1000 | OK | OK |
| 10 | `measurement_and_signals/10_iir_filter_bench.pap` | IIR Filter Comparison Bench | 21 | 20 | 10000 | OK | OK |
| 11 | `measurement_and_signals/11_fir_allpass_workshop.pap` | Linear-Phase FIR & All-Pass Workshop | 8 | 7 | 10000 | OK | OK |
| 12 | `measurement_and_signals/12_mains_hum_killer.pap` | 50/60 Hz Mains-Hum Killer | 11 | 10 | 1000 | OK | OK |
| 13 | `measurement_and_signals/13_fft_spectrum_analyzer.pap` | Real-Time FFT Spectrum Analyzer | 14 | 13 | 44100 | OK | OK |
| 14 | `measurement_and_signals/14_stft_spectrogram.pap` | STFT Spectrogram & Spectral Features | 13 | 20 | 44100 | OK | OK |
| 15 | `measurement_and_signals/15_wavelet_denoiser.pap` | Wavelet ECG/Vibration Denoiser | 9 | 8 | 2000 | OK | OK |
| 18 | `measurement_and_signals/18_sample_rate_conversion.pap` | Multirate Sample-Rate-Conversion Lab | 12 | 12 | 10000 | OK | OK |
| 46 | `measurement_and_signals/46_biomedical_monitor.pap` | Multi-Modal Biomedical Monitor | 27 | 39 | 1000 | OK | OK |
| 77 | `measurement_and_signals/77_wavelet_packet_denoiser.pap` | Wavelet-Packet Best-Basis Denoiser | 23 | 22 | 2000 | OK | OK |


## audio and acoustics

Anything a microphone hears or a speaker plays: effects, synthesis, analysis, and the adaptive filters that clean a room up.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 2 | `audio_and_acoustics/02_knob_tone_generator.pap` | Knob-Controlled Tone Generator | 5 | 4 | 44100 | OK | OK |
| 9 | `audio_and_acoustics/09_parametric_equalizer.pap` | 4-Band Parametric Equalizer | 10 | 9 | 44100 | OK | OK |
| 16 | `audio_and_acoustics/16_wavelet_subband_processor.pap` | Wavelet Subband Audio Processor | 13 | 12 | 44100 | OK | OK |
| 17 | `audio_and_acoustics/17_cepstral_pitch_echo.pap` | Cepstral Pitch Detector | 8 | 7 | 44100 | OK | OK |
| 19 | `audio_and_acoustics/19_stereo_ringmod_processor.pap` | Stereo-Field & Ring-Mod Processor | 14 | 14 | 44100 | OK | OK |
| 20 | `audio_and_acoustics/20_lofi_sound_mangler.pap` | Lo-Fi / Retro Sound Mangler | 11 | 11 | 44100 | OK | OK |
| 21 | `audio_and_acoustics/21_guitar_pedalboard.pap` | Guitar-Pedalboard Multi-FX | 8 | 7 | 44100 | OK | OK |
| 22 | `audio_and_acoustics/22_mastering_chain.pap` | Studio Dynamics & Mastering Chain | 14 | 13 | 44100 | OK | OK |
| 23 | `audio_and_acoustics/23_polyphonic_synth.pap` | Polyphonic Subtractive Synthesizer | 13 | 14 | 44100 | OK | OK |
| 24 | `audio_and_acoustics/24_vocal_autotune.pap` | Real-Time Vocal Auto-Tune | 21 | 21 | 44100 | OK | OK |
| 25 | `audio_and_acoustics/25_karplus_strong_strings.pap` | Karplus-Strong Plucked-String Ensemble | 14 | 13 | 44100 | OK | OK |
| 26 | `audio_and_acoustics/26_loop_station.pap` | Live Two-Source Audio Mixer | 8 | 7 | 44100 | OK | OK |
| 43 | `audio_and_acoustics/43_lms_interference_canceller.pap` | LMS Adaptive Interference Canceller | 9 | 8 | 1000 | OK | OK |
| 48 | `audio_and_acoustics/48_acoustic_event_classifier.pap` | Edge-AI Acoustic-Event Classifier | 23 | 35 | 44100 | OK | OK |
| 49 | `audio_and_acoustics/49_anc_headphones.pap` | Active-Noise-Cancelling Headphones | 9 | 8 | 44100 | OK | OK |
| 67 | `audio_and_acoustics/67_acoustic_echo_canceller.pap` | Acoustic Echo Canceller | 18 | 19 | 16000 | OK | OK |
| 68 | `audio_and_acoustics/68_adaptive_beamformer.pap` | Microphone-Array Adaptive Beamformer | 16 | 18 | 16000 | OK | OK |
| 69 | `audio_and_acoustics/69_spectral_subtraction_denoise.pap` | Spectral-Subtraction Speech Enhancement | 14 | 13 | 16000 | OK | OK |
| 70 | `audio_and_acoustics/70_acoustic_feedback_suppressor.pap` | Acoustic Feedback / Howling Suppressor | 22 | 23 | 16000 | OK | OK |
| 75 | `audio_and_acoustics/75_phase_vocoder_timestretch.pap` | Phase-Vocoder Time-Stretch | 12 | 12 | 20000 | OK | OK |
| 79 | `audio_and_acoustics/79_multiband_mastering.pap` | Psychoacoustic Multiband Mastering | 20 | 21 | 20000 | OK | OK |


## motion and drives

Making a mechanism do what it is told: servo loops, cascades, state feedback, and the classic unstable plants a control course is built on.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 27 | `motion_and_drives/27_pid_position_servo.pap` | PID Position Servo on a DC Motor | 12 | 12 | 1000 | OK | OK |
| 28 | `motion_and_drives/28_cascaded_motor_control.pap` | Cascaded Velocity + Position Control | 38 | 40 | 1000 | OK | OK |
| 30 | `motion_and_drives/30_auto_tuned_controller.pap` | Self-Optimizing Auto-Tuned Controller | 13 | 26 | 1000 | OK | OK |
| 31 | `motion_and_drives/31_adaptive_control_arena.pap` | Adaptive-Control Arena | 25 | 57 | 1000 | OK | OK |
| 32 | `motion_and_drives/32_disturbance_rejection.pap` | Active Disturbance Rejection | 19 | 23 | 1000 | OK | OK |
| 33 | `motion_and_drives/33_deadtime_loop_shaping.pap` | Dead-Time Compensation & Loop Shaping | 11 | 13 | 1000 | OK | OK |
| 34 | `motion_and_drives/34_nonlinear_characterization.pap` | Nonlinear-Element Characterization | 39 | 38 | 1000 | OK | OK |
| 35 | `motion_and_drives/35_motion_profiling.pap` | Jerk-Limited Motion Profiling | 28 | 29 | 1000 | OK | OK |
| 36 | `motion_and_drives/36_lqr_state_feedback.pap` | LQR State-Feedback Regulator | 6 | 9 | 1000 | OK | OK |
| 50 | `motion_and_drives/50_digital_twin_testbed.pap` | Mechatronic Digital-Twin Testbed | 39 | 51 | 2000 | OK | OK |
| 51 | `motion_and_drives/51_inverted_pendulum_swingup.pap` | Cart Pendulum: Swing-Up and Balance on a Rail | 75 | 99 | 1000 | OK | OK |
| 52 | `motion_and_drives/52_magnetic_levitation.pap` | Magnetic-Levitation Stabilizer | 20 | 20 | 1000 | OK | OK |
| 53 | `motion_and_drives/53_ball_and_beam.pap` | Ball-and-Beam Cascade Control | 21 | 22 | 1000 | OK | OK |
| 54 | `motion_and_drives/54_flexible_servo_antiresonance.pap` | Two-Mass Flexible-Servo Anti-Resonance | 29 | 29 | 2000 | OK | OK |
| 55 | `motion_and_drives/55_active_suspension_control.pap` | Active Quarter-Car Suspension | 22 | 25 | 1000 | OK | OK |
| 56 | `motion_and_drives/56_gantry_crane_antisway.pap` | Gantry-Crane Anti-Sway Control | 23 | 24 | 1000 | OK | OK |
| 81 | `motion_and_drives/81_dc_motor_lqr_state_feedback.pap` | DC Motor LQR State-Feedback with Integral Servo | 9 | 11 | 1000 | OK | OK |
| 82 | `motion_and_drives/82_real_dc_motor_lqr_observer.pap` | Real DC Motor + SS Luenberger Observer + LQR Servo | 10 | 14 | 1000 | OK | OK |
| 83 | `motion_and_drives/83_pid_deadband_standstill_dither.pap` | DC Motor Position Control with an Error Dead Band | 16 | 16 | 4000 | OK | OK |


## power and energy

Converters, inverters, machine drives and batteries, where the loop closes around something that carries current.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 29 | `power_and_energy/29_foc_transform_pipeline.pap` | Field-Oriented-Control Transforms | 14 | 15 | 16000 | OK | OK |
| 47 | `power_and_energy/47_grid_power_analyzer.pap` | Smart-Grid Power-Quality Analyzer | 22 | 22 | 12800 | OK | OK |
| 57 | `power_and_energy/57_buck_converter_control.pap` | Buck-Converter Voltage-Mode Control | 20 | 20 | 10000 | OK | OK |
| 58 | `power_and_energy/58_pmsm_field_oriented_control.pap` | PMSM Field-Oriented Control | 31 | 34 | 16000 | OK | OK |
| 59 | `power_and_energy/59_sensorless_bldc_smo.pap` | Sensorless BLDC with Sliding-Mode Observer | 31 | 36 | 16000 | OK | OK |
| 60 | `power_and_energy/60_grid_tie_inverter_pll.pap` | Grid-Tied Inverter with EKF-PLL | 24 | 28 | 12800 | OK | OK |
| 61 | `power_and_energy/61_battery_soc_soh_ekf.pap` | Battery SoC/SoH Co-Estimation | 26 | 26 | 1000 | OK | OK |


## condition monitoring

Deciding whether a machine is healthy from what it vibrates, radiates and how fast it turns.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 45 | `condition_monitoring/45_predictive_maintenance.pap` | Predictive-Maintenance Vibration Monitor | 37 | 65 | 20000 | OK | OK |
| 78 | `condition_monitoring/78_bearing_fault_envelope.pap` | Bearing-Fault Envelope Analyzer | 26 | 28 | 20000 | OK | OK |
| 80 | `condition_monitoring/80_structural_health_monitor.pap` | Multi-Sensor Structural-Health Monitor | 34 | 46 | 20000 | OK | OK |
| 85 | `condition_monitoring/85_accelerometer_condition_monitoring.pap` | Accelerometer Condition-Monitoring Feature Bench | 70 | 99 | 2000 | OK | OK |
| 87 | `condition_monitoring/87_iso_20816_severity_meter.pap` | ISO 20816 Vibration Severity Meter | 48 | 60 | 2000 | OK | OK |
| 88 | `condition_monitoring/88_bearing_envelope_which_race.pap` | Bearing Envelope Analyser: Which Race Is It | 61 | 80 | 2000 | OK | OK |
| 89 | `condition_monitoring/89_imbalance_misalignment_looseness.pap` | Imbalance, Misalignment and Looseness Triage | 57 | 71 | 2000 | OK | OK |
| 90 | `condition_monitoring/90_gear_mesh_sidebands.pap` | Gear Mesh and Sideband Monitor | 50 | 61 | 2000 | OK | OK |
| 91 | `condition_monitoring/91_speed_normalised_imbalance.pap` | Speed-Normalised Imbalance with a Magnetic Keyphasor | 39 | 42 | 2000 | OK | OK |
| 92 | `condition_monitoring/92_torsional_vibration_gyroscope.pap` | Torsional Vibration and Speed Ripple | 49 | 63 | 2000 | OK | OK |
| 93 | `condition_monitoring/93_stray_flux_electrical_faults.pap` | Stray-Flux Electrical Fault Monitor | 53 | 67 | 500 | OK | OK |
| 94 | `condition_monitoring/94_spectral_kurtosis_band_selector.pap` | Spectral-Kurtosis Band Selector | 46 | 62 | 2000 | OK | OK |
| 95 | `condition_monitoring/95_multisensor_machine_health.pap` | Multi-Sensor Machine-Health Monitor | 54 | 61 | 2000 | OK | OK |
| 96 | `condition_monitoring/96_three_plane_condition_station.pap` | Three-Plane Machine Condition Station | 66 | 82 | 2000 | OK | OK |


## navigation and attitude

Where a thing is and which way it is pointing: attitude filters, dead reckoning and inertial fusion.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 38 | `navigation_and_attitude/38_imu_ahrs.pap` | 9-DOF IMU Attitude & Heading Reference | 43 | 128 | 500 | OK | OK |
| 42 | `navigation_and_attitude/42_robot_localization.pap` | Autonomous-Robot Localization | 32 | 70 | 200 | OK | OK |
| 44 | `navigation_and_attitude/44_quadcopter_flight_controller.pap` | Quadcopter Flight Controller | 35 | 50 | 1000 | OK | OK |
| 63 | `navigation_and_attitude/63_ins_gps_fusion.pap` | INS/GPS Loosely-Coupled Fusion | 34 | 36 | 200 | OK | OK |
| 64 | `navigation_and_attitude/64_wmr_dead_reckoning.pap` | Wheeled-Robot Dead Reckoning | 35 | 58 | 200 | OK | OK |
| 65 | `navigation_and_attitude/65_ahrs_gyro_bias_calibration.pap` | AHRS with Online Gyro-Bias Calibration | 31 | 67 | 500 | OK | OK |
| 86 | `navigation_and_attitude/86_imu_pose_and_strapdown.pap` | 9-DOF Pose Lab: Attitude and Strapdown Position | 82 | 129 | 200 | OK | OK |


## estimation and identification

Recovering what cannot be measured: observers, Kalman filters, online identification, and voting between sensors that disagree.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 37 | `estimation_and_identification/37_kalman_sensor_fusion.pap` | Kalman-Filter Sensor Fusion | 15 | 16 | 1000 | OK | OK |
| 39 | `estimation_and_identification/39_online_system_id.pap` | Online System Identification | 12 | 13 | 150 | OK | OK |
| 40 | `estimation_and_identification/40_process_ekf_pack.pap` | Process-Estimation EKF Pack | 21 | 17 | 1000 | OK | OK |
| 62 | `estimation_and_identification/62_pendulum_ekf_estimator.pap` | Inverted-Pendulum EKF State Estimator | 29 | 31 | 1000 | OK | OK |
| 66 | `estimation_and_identification/66_redundant_sensor_voting.pap` | Triple-Redundant Sensor Voting | 46 | 51 | 1000 | OK | OK |
| 84 | `estimation_and_identification/84_identify_then_tune_a_pid.pap` | Identify a plant, then tune a PID from it | 15 | 15 | 200 | OK | OK |


## communications and radar

Carrying bits or finding targets: loops that lock, pulses that compress and carriers that carry.

| # | File | Application | Blocks | Wires | Fs (Hz) | Validation | Codegen |
|---|---|---|---|---|---|---|---|
| 71 | `communications_and_radar/71_chirp_radar_pulse_compression.pap` | Chirp-Radar Pulse Compression | 22 | 24 | 20000 | OK | OK |
| 72 | `communications_and_radar/72_costas_loop_bpsk.pap` | Costas-Loop BPSK Receiver | 21 | 23 | 20000 | OK | OK |
| 73 | `communications_and_radar/73_digital_pll_clock_recovery.pap` | Digital-PLL Clock & Data Recovery | 23 | 24 | 20000 | OK | OK |
| 74 | `communications_and_radar/74_sdr_fm_receiver.pap` | Software-Defined FM Receiver | 30 | 34 | 20000 | OK | OK |
| 76 | `communications_and_radar/76_ofdm_multicarrier_modem.pap` | OFDM Multicarrier Modem | 43 | 42 | 20000 | OK | OK |

## The condition-monitoring set (87 to 96)

Ten laboratories, each on one named technique. Every one reads the inertial
sensors as hardware, carries a simulated model on each of them, and plays the
condition its recorded machine is in on its own probe, so a decision can be
marked against the truth without leaving the Monitor.

| # | Technique | Sensors |
|---|---|---|
| 87 | Broadband velocity severity, ISO 20816 zones and a band split | accelerometer |
| 88 | Bearing envelope analysis, and the sidebands that name the race | accelerometer |
| 89 | Unbalance, misalignment and looseness from four ratios | accelerometer, three axes |
| 90 | Gear mesh sidebands, sideband energy ratio and a cepstrum | accelerometer |
| 91 | Speed normalisation, with a magnet on the shaft for a keyphasor | accelerometer, magnetometer |
| 92 | Torsional vibration and speed ripple | gyroscope, accelerometer |
| 93 | Stray-flux rotor-bar and eccentricity detection | magnetometer, accelerometer |
| 94 | Spectral kurtosis: measuring which band to analyse in | accelerometer |
| 95 | Four faults across three sensors, and the hole in using one | all three |
| 96 | Three measurement directions, with a running interlock | all three |

Every number quoted in a design's Project Description was measured by running
that design in the host simulator, and the build tool re-measures all of them
and fails if one has moved.

## Interaction scripts

An interaction script is the project folder's `main.py`. It is a complete
program, not a fragment: it imports `papaya_design`, calls
`papaya_design_init()` to build the diagram on the board, then reads the probes
and decides something out loud. It is the USER's program. Studio does not write
it while you work and does not run it for you; it ships beside the example and
it is yours to edit from the moment you open it.

It reads the design THROUGH the module (`papaya_design.measured`) rather than
with `from papaya_design import *`. The blocks do not exist until
`papaya_design_init()` runs, so a star import would copy the names before any
of them had been created and every one of them would be undefined at the moment
you used it.

**Every getting-started design has one**, and fourteen of those open a PyQt6
control panel because their design carries an input that can be written while it
runs. The panel is in the script: a slider, a dial, a switch or a number box per
input, chosen per design, a readout of every probe refreshed 20 times a second,
and one line saying what the readings mean. The libraries it needs are the ones
the Source Editor's runtime already pre-imports, so Run works on it unchanged,
and the editor's toolchain panel now names any of them your interpreter is
missing rather than letting the script stop on an import three seconds in.

**Thirteen application designs have one too** (51, and 85 to 96), and those are
longer, because deciding whether a bearing is damaged is a longer argument than
deciding whether a gain of two doubled something.

| Script | What it decides |
|---|---|
| `motion_and_drives/51_inverted_pendulum_swingup/main.py` | Names what the rig is doing (hanging, pumping, arriving, catching, balanced, or at the end stop), then runs three measurements: the swing-up against the rail and the amplifier, the catch envelope by bisection, and the wrong-way motion at the start of a cart move. |
| `condition_monitoring/85_accelerometer_condition_monitoring/main.py` | Learns the machine's healthy state, then names what changed: severity against that baseline, impulsiveness from crest factor and kurtosis, a spectral shift from Hjorth mobility, and whether the sensor is still on the machine. |
| `navigation_and_attitude/86_imu_pose_and_strapdown/main.py` | Reports the pose with a judgement about how much of it to trust: whether the platform is accelerating (roll and pitch lean into it), whether the magnetic field magnitude has moved (the heading is following iron), and whether the gyroscope offset has settled. |
| `condition_monitoring/87_iso_20816_severity_meter/main.py` | Places the machine in an ISO evaluation zone, names the loudest direction and the loudest band, and prints the acceleration reading beside the velocity one so the difference is visible rather than asserted. |
| `condition_monitoring/88_bearing_envelope_which_race/main.py` | Learns the bearing's quiet state, then names the damaged race from the outer and inner shares. Refuses to report the sideband share when the line it divides by is at the noise floor. |
| `condition_monitoring/89_imbalance_misalignment_looseness/main.py` | Four ratio tests in the order a vibration analyst applies them: the tests that discriminate first, the level that says how bad afterwards. |
| `condition_monitoring/90_gear_mesh_sidebands/main.py` | Reads wear from the sideband energy ratio and a crack from impulsiveness, and prints the mesh line for comparison without ever deciding on it. |
| `condition_monitoring/91_speed_normalised_imbalance/main.py` | Reports both the raw and the speed-normalised amplitude so the normalisation can be seen working, and watches the keyphasor for a speed that jumps by a factor near two. |
| `condition_monitoring/92_torsional_vibration_gyroscope/main.py` | Names a rotor-bar torque ripple or a knocking coupling from the gyroscope, and prints what the accelerometer made of the same moment. |
| `condition_monitoring/93_stray_flux_electrical_faults/main.py` | Separates a broken rotor bar from an eccentric air gap, and refuses both verdicts when the supply line says the motor is not running. |
| `condition_monitoring/94_spectral_kurtosis_band_selector/main.py` | Names the band to take into an envelope analysis, and says so when the band with the highest kurtosis is not the band with the most energy. |
| `condition_monitoring/95_multisensor_machine_health/main.py` | Asks the electrical question first, because a quiet accelerometer is what an electrical fault looks like. Requires both electrical indicators to agree. |
| `condition_monitoring/96_three_plane_condition_station/main.py` | Checks the interlock before anything else, then names the fault from the direction of the largest reading and the 2x content with it. |

Every one keeps its decision rules in pure functions near the top of the file,
with no board in them, so a rule can be changed and re-run without rebuilding
the design. The condition-monitoring scripts carry a `SCORE_AGAINST_REFERENCE` switch: on while the
sensors' simulated models are active, the script marks its own verdicts against
the recorded truth the design plays; turn it off on a real machine.
