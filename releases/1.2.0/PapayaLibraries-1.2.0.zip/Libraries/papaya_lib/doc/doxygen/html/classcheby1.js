var classcheby1 =
[
    [ "cheby1", "classcheby1.html#a90c14079b7ed732d2e18e5ac2f67b773", null ],
    [ "cheby1", "classcheby1.html#a6e6435ee7bf2bc9c6a3645207fc61755", null ]
];