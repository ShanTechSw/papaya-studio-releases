var _papaya_linux_spidev_backend_8h =
[
    [ "PapayaLinuxSpidevBackend", "class_papaya_linux_spidev_backend.html", "class_papaya_linux_spidev_backend" ]
];