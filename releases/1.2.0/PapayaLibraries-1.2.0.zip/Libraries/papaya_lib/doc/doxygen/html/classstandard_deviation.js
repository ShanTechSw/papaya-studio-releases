var classstandard_deviation =
[
    [ "standardDeviation", "classstandard_deviation.html#a1178b405d9eb50ed14f6a45aebcaf710", null ]
];