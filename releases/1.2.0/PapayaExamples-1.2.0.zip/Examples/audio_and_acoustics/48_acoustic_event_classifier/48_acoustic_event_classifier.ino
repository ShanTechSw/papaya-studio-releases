/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe band_energy;
probe unused_signals;

input freeze;

/* Global Array Declarations */
uint16_t Event_classifier_feat_idx[] = {2, 65535, 65535};
float Event_classifier_thresh[] = {0.15f, 0.0f, 0.0f};
uint16_t Event_classifier_left[] = {1, 65535, 65535};
uint16_t Event_classifier_right[] = {2, 65535, 65535};
float Event_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  freeze = input("freeze", 0.0f);
  microphone Microphone = microphone(MIC_L);
  signalSource alert_tone = signalSource::sine(1000.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.3f);
  expander fan_7 = expander(7);
  stftFramer STFT_framer = stftFramer(512, 128, 0);
  dwt DWT_db4_L5 = dwt(256, DB4, 5, 44100.0);
  zScoreNorm Z_score_norm = zScoreNorm(441000, 1e-09);
  zcr Zcr = zcr(256, 0.0);
  rootMeanSquare Rms = rootMeanSquare(10);
  crestFactor Crest_Factor = crestFactor(64);
  absVal Abs = absVal();
  fft FFT_512 = fft(512);
  dwt_subband_energy Subband_energy = dwt_subband_energy(DWT_db4_L5);
  decisionTree Event_classifier = decisionTree(4, 2, 3, Event_classifier_feat_idx, Event_classifier_thresh, Event_classifier_left, Event_classifier_right, Event_classifier_leaf_val);
  entropy Entropy = entropy(10);
  fftMagResolver Magnitude = fftMagResolver(FFT_512);
  expander fan_event = expander(2);
  spectralFeatures Spectral_features = spectralFeatures(Magnitude);
  node gate_tone = node("[1.0 1.0]", "[1.0]", Mul);
  speaker Alert_out = speaker(SPEAKER1);
  merger unused_bus = merger(11);
  band_energy = VectorProbe("band_energy");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  freeze > Z_score_norm.in(1);
  Microphone > fan_7;
  alert_tone > gate_tone.in(0);
  fan_7.out(0) > STFT_framer;
  fan_7.out(1) > DWT_db4_L5;
  fan_7.out(2) > Z_score_norm.in(0);
  fan_7.out(3) > Zcr;
  fan_7.out(4) > Rms;
  fan_7.out(5) > Crest_Factor;
  fan_7.out(6) > Abs;
  STFT_framer > FFT_512;
  DWT_db4_L5 > Subband_energy;
  Z_score_norm > Event_classifier.in(0);
  Zcr > Event_classifier.in(1);
  Rms > Event_classifier.in(2);
  Crest_Factor > Event_classifier.in(3);
  Abs > Entropy;
  FFT_512 > Magnitude;
  Subband_energy > unused_bus.in(7);
  Subband_energy >> band_energy;
  Event_classifier.out(1) > fan_event;
  Event_classifier.out(0) > unused_bus.in(10);
  Entropy > unused_bus.in(9);
  Magnitude > Spectral_features;
  fan_event.out(0) > gate_tone.in(1);
  fan_event.out(1) > unused_bus.in(8);
  Spectral_features.out(0) > unused_bus.in(0);
  Spectral_features.out(1) > unused_bus.in(1);
  Spectral_features.out(2) > unused_bus.in(2);
  Spectral_features.out(3) > unused_bus.in(3);
  Spectral_features.out(4) > unused_bus.in(4);
  Spectral_features.out(5) > unused_bus.in(5);
  Spectral_features.out(6) > unused_bus.in(6);
  gate_tone > Alert_out;
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  freeze.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    band_energy.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}