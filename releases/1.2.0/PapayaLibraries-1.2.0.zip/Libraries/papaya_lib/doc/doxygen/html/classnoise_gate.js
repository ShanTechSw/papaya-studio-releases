var classnoise_gate =
[
    [ "noiseGate", "classnoise_gate.html#a2fde2dd7fda69244ab476189734bf7b1", null ]
];