"""A Transfer Function: read the probes and print them once a second.

A plant written as a ratio of polynomials.

Press Ctrl+C to stop.

Everything below is yours to change. The lists at the top are the
obvious place to start.
"""
import time

import papaya_design

# The probes this design carries.
PROBES = ['continuous', 'discrete']
PRINT_EVERY = 1.0       # seconds

# Build the diagram on the board and start it sampling. Reached
# through the module rather than with "from papaya_design import *",
# because the blocks do not exist until this call has created them.
try:
    papaya_design.papaya_design_init()
except RuntimeError as exc:
    raise SystemExit(
        "The board would not build this design: " + str(exc)
        + ". If the design reads something plugged into the "
        "expansion connector, check that it is attached."
    ) from exc

board = papaya_design.papaya0

print(f"\nReading every {PRINT_EVERY:.0f} s. Press Ctrl+C to stop.\n")

next_print = time.monotonic()

try:
    while True:
        now = time.monotonic()

        if now >= next_print and board.readProbesLatest(timeout_ms=250):
            values = {name: getattr(papaya_design, name).getVal()
                      for name in PROBES}
            reading = "   ".join(f"{n}={v:+8.4f}"
                                 for n, v in values.items())
            # The derived number. This is the line worth changing.
            mean = sum(values.values()) / len(values)
            print(f"{reading}   mean={mean:+8.4f}")
            next_print = now + PRINT_EVERY

        time.sleep(0.02)

except KeyboardInterrupt:
    print("\nStopped. The board is left in configuration mode, so "
          "the next program can use it.")
