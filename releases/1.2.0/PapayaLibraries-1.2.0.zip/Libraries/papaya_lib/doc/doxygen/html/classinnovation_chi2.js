var classinnovation_chi2 =
[
    [ "innovationChi2", "classinnovation_chi2.html#a6ab03d338140bd21ecd888a135a797cb", null ]
];