var classmax_observer =
[
    [ "maxObserver", "classmax_observer.html#a5d88d281cd981042b40b5e7fa3983121", null ]
];