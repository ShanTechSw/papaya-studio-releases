/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 00:13:02
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

input gate;
input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  gate = input("gate", 1.0f);
  signalSource Sawtooth_osc = signalSource::sawtooth(220.0f, 0.0f, 0, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.6f);
  const_ = input("const", 0.2f);
  adsr ADSR = adsr(0.01, 0.1, 0.7, 0.3);
  amOscillator Sub_osc = amOscillator(Sine, 110.0, 0.0);
  expander fan_2 = expander(2);
  node VCA = node("[1.0 1.0]", "[1.0]", Mul);
  expander fan_2_2 = expander(2);
  butterBq Lowpass_1_2_kHz = butterBq(4, 1200.0, passLow);
  ringMod Ring_mod_voice = ringMod();
  stereoMixer Voice_mixer = stereoMixer(3);
  speaker Speaker_L = speaker(SPEAKER1);
  speaker Speaker_R = speaker(SPEAKER2);

  /* Connect Blocks */
  gate > ADSR;
  Sawtooth_osc > fan_2;
  const_ > Sub_osc;
  ADSR > VCA.in(1);
  Sub_osc > fan_2_2;
  fan_2.out(0) > VCA.in(0);
  fan_2.out(1) > Ring_mod_voice.in(1);
  VCA > Lowpass_1_2_kHz;
  fan_2_2.out(0) > Ring_mod_voice.in(0);
  fan_2_2.out(1) > Voice_mixer.in(1);
  Lowpass_1_2_kHz > Voice_mixer.in(0);
  Ring_mod_voice > Voice_mixer.in(2);
  Voice_mixer.out(0) > Speaker_L;
  Voice_mixer.out(1) > Speaker_R;

  /* Enable Remote Input Control */
  gate.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */

    /* Read probe values */
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}