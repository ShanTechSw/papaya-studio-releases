/**
 * @file    papaya_link_board_port.h
 * @brief   Binding the relay engine to a real board through the library.
 *
 * The engine speaks transactions; the library speaks to the board. This
 * is the layer between them, and the reason it is small is that it is
 * meant to be: every timing figure it would otherwise have to know -- the
 * chip-select guard, the chunk size, the response poll interval and its
 * deadline, the wait a vector-probe request needs before its payload --
 * belongs to the library and stays there. A gateway that carried its own
 * copy of those would be a second place for them to drift from the
 * board.
 *
 * The one thing this file does own is the obligation that comes with
 * sending a command in pieces: **the board has no inter-frame timeout**.
 * A command begun and not finished leaves its receive state machine
 * waiting forever. The engine above guarantees the pieces always add up,
 * by sending filler when a link dies mid-command, and this layer must not
 * quietly drop one on the way past.
 */
#pragma once

#include <stdint.h>

#include "PAPAYA.h"
#include "papaya_link_gateway.h"

namespace papaya {
namespace link {

/**
 * A BoardPort over the PAPAYA library's relay entry points.
 *
 * Streaming rather than whole-command, which is the whole point: a
 * command reaches a gateway a chunk at a time so that the gateway never
 * needs a buffer larger than one chunk, and a board port that reassembled
 * the body to call relayCommand() would put that buffer straight back.
 */
class LibraryBoardPort : public BoardPort
{
public:
  /** @param device an already-constructed PAPAYA on the board's wire. */
  explicit LibraryBoardPort(PAPAYA &device) : device_(device) {}

  void beginCommand(const uint8_t *header, uint16_t length);
  void sendBodyChunk(const uint8_t *chunk, uint32_t length);
  uint16_t awaitStatus(uint8_t *status, uint16_t capacity);
  uint32_t readDataPayload(uint8_t *out, uint32_t length);
  uint32_t readProbes(uint8_t *out, uint32_t length, bool vector);
  bool writeInputs(const uint8_t *values, uint32_t length);
  bool sendOpcode(uint8_t opcode);
  bool resetBoard(void);
  void quiesce(void);

private:
  PAPAYA &device_;
};

}  /* namespace link */
}  /* namespace papaya */
