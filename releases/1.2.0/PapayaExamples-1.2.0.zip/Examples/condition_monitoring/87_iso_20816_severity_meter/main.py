"""ISO 20816 severity: the board measures, this script judges.

Run this beside example 87. It builds the diagram, reads the three
velocity measurements, places the machine in an evaluation zone, and says
which direction and which band the reading came from.

    python main.py

The board's job is the 2 kHz work: integrate, band-limit, average. The
judgement is here, in ZONES and BANDS below, because the zone table is the
part that changes with the machine and a class has to be able to change it
and re-run without rebuilding anything.

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  zone            the largest of the three directions, against the four
                  ISO 20816 evaluation zones for the machine class set
                  below. The standard evaluates the WORST direction, not
                  an average of them, so that is what is compared.

  direction       which axis is loudest. A machine whose vertical reading
                  beats its horizontal one is telling you about its feet
                  rather than about its rotor.

  band            which of the three bands holds the energy. A machine can
                  sit inside its limit and still be shouting in one band,
                  and the band names the family of causes.

  units           the acceleration reading is reported beside the velocity
                  one, so the difference between them is visible rather
                  than asserted.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with the real sensor that trace
# is still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("zone A", "zone B", "zone C", "zone D")

# The feature vector, in the order the design's Feature Stack publishes it.
FEATURES = ("vx_mms", "vy_mms", "vz_mms", "vmax_mms",
            "v_sub_mms", "v_1x_mms", "v_rest_mms", "a_rms_g", "state")

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

# ISO 20816-3 evaluation zones, in mm/s RMS over 10 Hz to 1 kHz. These are
# the boundaries for a MEDIUM machine, 15 to 300 kW, on a RIGID mount.
# Every machine class has its own column in the standard and this is the
# single most important number to set for your own rig.
ZONES = (("A", 1.4, "newly commissioned or freshly overhauled"),
         ("B", 2.8, "acceptable for unrestricted long-term running"),
         ("C", 4.5, "unsatisfactory for continuous running, plan the work"),
         ("D", float("inf"), "dangerous, damage can occur, act now"))

# Bands, and what a machine that is loudest in each is usually telling you.
BANDS = (
    ("v_sub_mms", "below the shaft line",
     "rub, oil whirl, a slipping belt, or a foundation that is moving"),
    ("v_1x_mms", "on the shaft line",
     "unbalance, which is what most of it usually is"),
    ("v_rest_mms", "above the shaft line",
     "bearings, gears, cavitation, or something electrical"),
)

DIRECTIONS = (("vx_mms", "horizontal"), ("vy_mms", "vertical"),
              ("vz_mms", "axial"))

# A vertical reading above the horizontal one is unusual on a machine
# bolted to a floor, because the structure is stiffer that way.
VERTICAL_FLAG = 1.0


def zone_of(mms: float):
    """Which evaluation zone a velocity reading falls in."""
    for name, limit, meaning in ZONES:
        if mms < limit:
            return name, meaning
    return ZONES[-1][0], ZONES[-1][2]


def loudest(row, entries):
    """The largest of a set of named readings, with its share."""
    values = [(row.get(key, 0.0), label, *rest)
              for key, label, *rest in entries]
    values.sort(reverse=True)
    total = sum(v[0] for v in values) or 1e-12
    top = values[0]
    return top[1], top[0], top[0] / total, (top[2] if len(top) > 2 else "")


def classify(row):
    """One verdict from one smoothed reading."""
    worst = row["vmax_mms"]
    zone, meaning = zone_of(worst)
    axis, axis_value, axis_share, _ = loudest(row, DIRECTIONS)
    band, band_value, band_share, band_meaning = loudest(row, BANDS)

    reasons = [
        f"worst direction {worst:.3f} mm/s, which is zone {zone}: {meaning}",
        f"loudest axis is {axis} at {axis_value:.3f} mm/s, "
        f"{100 * axis_share:.0f} per cent of the three",
        f"loudest band is {band} at {band_value:.3f} mm/s, "
        f"{100 * band_share:.0f} per cent of the three: {band_meaning}",
    ]

    vertical, horizontal = row["vy_mms"], row["vx_mms"]
    if vertical > VERTICAL_FLAG * horizontal:
        reasons.append(
            f"the vertical reading ({vertical:.3f}) is above the horizontal "
            f"one ({horizontal:.3f}). On a machine bolted to a floor that "
            f"is backwards, and it usually means the feet, the grout or the "
            f"baseplate rather than the rotor")

    # The comparison the example exists for. The acceleration reading moves
    # with the vibration too, and it is not what the standard asks for.
    reasons.append(
        f"for comparison, the acceleration is {row['a_rms_g']:.4f} g. "
        f"There is no ISO zone for that number, and converting it to one "
        f"needs the frequency it is at")
    return zone, reasons


def score_line(zone, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    expected = CONDITIONS[index].split()[-1]
    return zone == expected, CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 87_iso_20816_severity_meter.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    raw = d.papaya0.readVectProbeLive(d.severity, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    values = struct.unpack(f"<{len(FEATURES)}f", raw[:4 * len(FEATURES)])
    row = dict(zip(FEATURES, values))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst. The standard wants a settled reading, and a
    single sample of an RMS that is still sliding is not one."""
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA ISO 20816 severity meter")
    print("=" * 72)
    print("Zone boundaries in use, mm/s RMS over 10 Hz to 1 kHz:")
    for name, limit, meaning in ZONES:
        edge = "and above" if limit == float("inf") else f"below {limit}"
        print(f"  zone {name}  {edge:>12s}   {meaning}")
    print("These are for a medium machine on a rigid mount. Set them for "
          "yours before\nbelieving any verdict below.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        zone, reasons = classify(row)
        tally[zone] = tally.get(zone, 0) + 1
        scored = score_line(zone, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if zone != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  ZONE {zone}")
            for r in reasons:
                print(f"           {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is in "
                      f"{scored[1]}")
            last = zone

    print("\n" + "-" * 72)
    print("Summary")
    for name, _limit, _meaning in ZONES:
        if name in tally:
            print(f"  zone {name}  {tally[name]:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} ({100.0 * right / (right + wrong):.0f} "
              f"per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
