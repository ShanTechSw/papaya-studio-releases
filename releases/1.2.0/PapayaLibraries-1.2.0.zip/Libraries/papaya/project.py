"""A PAPAYA project: the design, and the code a person runs beside it.

A design on its own is a complete project, and most are. But a design meant
to be driven by hand comes with interaction code as well: a Python panel
with sliders and plots, or a C++ program doing the same from a build. Those
files sit beside the ``.pap`` and, until now, nothing recorded that they
belonged together. Move the folder, rename it, hand it to a colleague, and
the only thing tying the panel to its design was the folder's name.

A design can therefore list its interaction scripts, and this module reads
that list back:

    from papaya.project import interaction_scripts

    for path in interaction_scripts("cart_control.pap"):
        print(path)

Paths are stored relative to the ``.pap`` and returned absolute, so a
project folder can be moved or copied whole and still resolve.

Nothing here requires the list to exist. A design that does not name any
scripts returns an empty list, which is not an error and not a warning: it
is the ordinary case.
"""
from __future__ import annotations

import json
import os
from typing import List

__all__ = ["interaction_scripts", "design_settings", "ProjectError"]

#: The key a design stores its script list under.
SCRIPTS_KEY = "interaction_scripts"


class ProjectError(RuntimeError):
    """A project file that cannot be read, phrased for whoever asked."""


def design_settings(pap_path: str) -> dict:
    """The settings block of a ``.pap``, or an empty dict if it has none.

    Reads the file directly rather than through the editor, because this
    library runs on machines that have no PAPAYA Studio installed.
    """
    try:
        with open(pap_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        raise ProjectError(f"no design file at {pap_path!r}.") from None
    except (OSError, ValueError) as exc:
        raise ProjectError(
            f"{pap_path!r} could not be read as a design: "
            f"{type(exc).__name__}: {exc}") from exc

    if not isinstance(data, dict):
        return {}
    settings = data.get("settings")
    return settings if isinstance(settings, dict) else {}


def interaction_scripts(pap_path: str, *, existing_only: bool = True) -> List[str]:
    """Absolute paths of the interaction scripts *pap_path* names.

    Returns an empty list when the design names none, which is the ordinary
    case for a design that is a complete project on its own.

    With ``existing_only`` (the default) a listed path that is not on disk
    is dropped rather than returned, because a caller almost always wants
    the files it can actually open. Pass ``False`` to see what the design
    claims, which is what you want when diagnosing a project whose scripts
    were moved or never copied.
    """
    settings = design_settings(pap_path)
    raw = settings.get(SCRIPTS_KEY, [])
    if isinstance(raw, str):
        raw = [raw]                   # a single path, written by hand
    if not isinstance(raw, (list, tuple)):
        return []

    base = os.path.dirname(os.path.abspath(pap_path))
    out: List[str] = []
    for entry in raw:
        name = str(entry).strip()
        if not name:
            continue
        # Relative to the design, so a project folder moves as one thing.
        # An absolute path is honoured as given, for the rarer case of a
        # shared panel that several designs point at.
        full = name if os.path.isabs(name) else os.path.join(base, name)
        full = os.path.normpath(full)
        if existing_only and not os.path.isfile(full):
            continue
        if full not in out:
            out.append(full)
    return out
