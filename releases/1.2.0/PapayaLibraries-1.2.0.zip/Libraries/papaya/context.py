from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple, Union

import os
import struct
import time

from .constants import (
    PP_CMD_WRITE,
    PP_CMD_READ,
    PP_CMD_READ_VECT_PROBE,
    PP_REAL_SIZE,
    PP_UINT8_SIZE,
    PP_UINT16_SIZE,
    PP_UINT32_SIZE,
    PP_PARAM_DESC_SIZE,
    PP_PARAM_DESC_ID_SHIFT,
    PP_PARAM_DESC_MAX_ID,
    PP_PARAM_DESC_MAX_SIZE,
    PP_PARAM_DESC_SIZE_MASK,
    PP_PARAM_INFO_SIZE,
    PP_CMD_HEADER_SIZE,
    PP_CMD_CRC_SIZE,
    PP_CHUNK_MAX_SIZE,
    PP_CMD_BODY_HARD_MAX_SIZE,
    PP_RESPONSE_REQ_SIZE,
    PP_RESPONSE_SIZE,
    PP_RESPONSE_TIMEOUT_MS,
    PP_CMD_MAX_SIZE,
    PP_CMD_RESPONSE_ID,
    PP_CMD_SEQ_NUMBER_IDX,
    PP_CMD_READ_WRITE_IDX,
    PP_CMD_SIZEL_IDX,
    PP_CMD_blockIDL_IDX,
    PP_CMD_FUNC_ID_IDX,
    PP_CMD_SUB_FUNC_IDL_IDX,
    PP_CMD_NBR_OF_PARAMS_IDX,
    PP_CMD_NBR_OF_CHUNKS_IDX,
    PP_CMD_LAST_CHUNK_SIZEL_IDX,
    PP_CMD_BODY_START_IDX,
    PP_CMD_HEADER_CRC_IDX,
    PP_MAX_INPUTS_NUMBER,
    PP_MAX_PROBES_NUMBER,
    PP_MAX_VECTOR_PROBES_NUMBER,
    PP_MAX_VECTOR_PROBES_BYTES,
)
from .enums import (
    PP_ComStatus,
    PP_DesignStatus,
    PP_FuncId,
    PP_FuncParamId,
    PP_SubFuncId,
)
from .frames import FrameField, PapayaFrame, PapayaTransaction


ErrorHandler = Callable[[], None]

#: The board releases its CONFIGURATION session after 3000 ms of command
#: silence, and the packet that re-claims it ZEROES the board's sequence
#: counter.  A host frame still carrying the old number is then refused,
#: and the refusal ECHOES the host's own sequence number while reporting
#: BadRequest, a perfectly valid response carrying a design error, the
#: "[papaya] design status = 8" from a live board.
#:
#: Same bound as the C++ library's ``PP_HOST_CFG_IDLE_RESYNC_MS``
#: (``papaya_lib/PAPAYA.cpp``), and the same bound Papaya Studio applies
#: when it decides that a board has restarted its numbering.
PP_HOST_CFG_IDLE_RESYNC_MS = 3000.0


def _monotonic_ms() -> float:
    """Milliseconds from a clock that cannot be moved by the wall clock."""
    return time.monotonic() * 1000.0


def _env_flag(name: str) -> bool:
    return bool(os.environ.get(name, "").strip())


@dataclass
class TransactionInfo:
    ReceivedCrc: int = 0
    CalculatedCrc: int = 0
    SeqNbr: int = 0
    ReadWrite: int = PP_CMD_WRITE


@dataclass
class FuncInfo:
    FuncParams: List[bytes] = field(default_factory=lambda: [b"" for _ in range(20)])
    FuncParamIds: List[int] = field(default_factory=lambda: [0 for _ in range(20)])
    FuncParamSizes: List[int] = field(default_factory=lambda: [0 for _ in range(20)])
    DataSize: int = 0
    LastChunkSize: int = 0
    blockId: int = 0
    SubFuncId: int = int(PP_SubFuncId.NoSubFuncId)
    FuncId: int = int(PP_FuncId.NoFuncId)
    NbrOfParams: int = 0
    NbrOfChunks: int = 0


@dataclass
class CommandInfo:
    FuncInfo: FuncInfo = field(default_factory=FuncInfo)
    TransactionInfo: TransactionInfo = field(default_factory=TransactionInfo)


class PapayaContext:
    """
    A faithful Python port of the provided Arduino C++ library's internal state.

    Critical detail:
    - The Arduino code uses *static global* buffers (SerialData) and a *static global*
      Command struct. It does NOT clear them between commands.
    - Some constructors in the C++ sources contain inconsistencies between:
        * SerialDataSize passed to HandleCmd()
        * NbrOfParams passed to PrepareCmdHeader()
        * number of PrepareParam() calls
      As a result, extra trailing bytes in the transmitted frame-body can be
      leftovers from previous commands.

    This context intentionally replicates that behavior so you can analyze the *exact*
    frames that would be put on the SPI bus by the provided code.
    """

    def __init__(self) -> None:
        self.sequence_number: int = 0  # (C++: static uint16_t SequenceNumber)
        self.data_exchange_started: bool = False

        #: The design's sampling frequency, as given to ``startDesign``.
        #: A recording plays once over its natural duration when the block
        #: traverses its lookup table ``Fs / N`` times a second, so a block
        #: carrying a recording needs this to work out its own playback
        #: rate. Neither is something the user
        #: chooses, which is why neither is a constructor argument.
        self.sampling_freq_hz: float = 0.0
        #: Samples held by each flash slot this program has FILLED, keyed by
        #: slot index, recorded by ``uploadDataset``. Storage bookkeeping
        #: only: the slots are somewhere to keep a recording, and nothing
        #: plays one. Flash is non-volatile, so a slot filled by a previous
        #: run is not in here.
        self.dataset_slot_samples: Dict[int, int] = {}

        self.current_design_status: PP_DesignStatus = PP_DesignStatus.DesignOk
        self.current_com_status: PP_ComStatus = PP_ComStatus.ComOk

        self.com_error_handler: Optional[ErrorHandler] = None
        self.design_error_handler: Optional[ErrorHandler] = None

        # Global buffers (static in C++)
        self.serial_data: bytearray = bytearray(PP_CMD_MAX_SIZE)  # reused for all frames
        self.response: bytearray = bytearray(PP_RESPONSE_SIZE)  # unused in this no-IO phase

        self.command: CommandInfo = CommandInfo()

        self.inputs_buffer: bytearray = bytearray(PP_MAX_INPUTS_NUMBER * PP_REAL_SIZE)
        self.probes_buffer: bytearray = bytearray(PP_MAX_PROBES_NUMBER * PP_REAL_SIZE)
        self.vector_probes_buffer: bytearray = bytearray(
            PP_MAX_VECTOR_PROBES_NUMBER * PP_MAX_VECTOR_PROBES_BYTES
        )

        # Optional registries (for nicer prints)
        self._input_labels_by_idx: Dict[int, str] = {}
        self._probe_labels_by_idx: Dict[int, str] = {}
        self._vector_probe_labels_by_idx: Dict[int, str] = {}

        # Output / logging controls
        self.auto_print: bool = True
        self.transaction_log: List[PapayaTransaction] = []

        # Optional USB transport: when set, handle_cmd() sends frames
        # to the PAPAYA board and prints real response codes.
        self.usb_transport = None  # type: Optional[Any]

        #: Optional observer of every command, called with the decoded
        #: CommandInfo before it is serialised.
        #:
        #: A command carries everything that describes a block: which
        #: sub-function builds it, which wire id names it, and its
        #: parameters in order. Serialising that and parsing it back is
        #: only worth doing when there is a wire in the way. When there is
        #: not, as when running a design on this machine, a reader
        #: attached here sees exactly what the board would have been told,
        #: with nothing in between to disagree with.
        #:
        #: Setting this changes nothing else: the frames are still built,
        #: so a caller that wants both the commands and the bytes gets
        #: both.
        self.command_sink = None  # type: Optional[Any]

        #: Keep sending after a refusal instead of latching, C++-unlike.
        #:
        #: This used to be unconditional whenever a transport was
        #: attached, and it turned a refused command into a SILENT WRONG
        #: ANSWER: the board rejected StartSampling with status 8, the
        #: program carried on against a design that was never
        #: configured, and the session reported "Finished".  The C++
        #: library latches instead (``HandleCmd`` refuses to transmit
        #: while either status is non-OK) and only ``startDesign()``
        #: clears it, so a refusal is visible and terminal there.
        #:
        #: It is kept (off by default) because it has a real user:
        #: batch harnesses that run a WHOLE generated program to the end
        #: and then read stdout for the ``[USB] Auto-recovering`` marker
        #: to decide pass or fail.  Latching would stop such a run at the
        #: first refusal and hide every later one.  Those harnesses opt in
        #: explicitly; a user's own program does not.
        self.auto_recover_errors: bool = _env_flag("PAPAYA_AUTO_RECOVER")

        #: Monotonic ms at the END of the last exchange with the board,
        #: or None before the first.  Measuring from the END (not from
        #: the TX) is the safe direction: the board restarts its own idle
        #: countdown at every inbound packet it accepts, including the
        #: response-request polls, so its last restart is at least as late
        #: as this stamp.  This client therefore UNDER-measures idle: it
        #: may miss a genuine release right at the 3.000 s edge (which
        #: merely reproduces the old behaviour: one BadRequest, and the
        #: retry below recovers it) but it can never FABRICATE one and
        #: inject seq 0 into a session the board still holds.
        self._last_exchange_end_ms: Optional[float] = None

        #: The clock the idle rule reads.  An attribute so a test can
        #: drive it without sleeping.
        self.clock_ms: Callable[[], float] = _monotonic_ms

    # ---------------------------------------------------------------------
    # CRC32 (mirrors the C++ / C slave implementation)
    # ---------------------------------------------------------------------
    @staticmethod
    def calculate_crc(data: Union[bytes, bytearray], data_length: int) -> int:
        crc = 0xFFFFFFFF
        for byte in data[:data_length]:
            crc ^= byte
            for _ in range(8):
                if crc & 0x00000001:
                    crc = (crc >> 1) ^ 0xEDB88320
                else:
                    crc >>= 1
                crc &= 0xFFFFFFFF
        return crc ^ 0xFFFFFFFF

    def calculate_and_set_crc(self, data: bytearray, data_length: int) -> int:
        crc = self.calculate_crc(data, data_length)
        # store little-endian, as the C++ code does
        struct.pack_into("<I", data, data_length, crc & 0xFFFFFFFF)
        return crc

    # ---------------------------------------------------------------------
    # PrepareCmdHeader / PrepareParam (stateful, like the C++ globals)
    # ---------------------------------------------------------------------
    def prepare_cmd_header(
        self,
        serial_data_size: int,
        func_id: PP_FuncId,
        nbr_of_params: int,
        sub_func_id: PP_SubFuncId,
        block_id: int,
        *,
        use_global_command: bool = True,
    ) -> CommandInfo:
        cmd = self.command if use_global_command else CommandInfo()
        # The link's own counter wins when it publishes one: it sees
        # traffic this context never sent.  Only when nothing was adopted
        # is this context the sole authority, and only then may the idle
        # rule move the counter.  Both must happen BEFORE the frame is
        # built, because the header CRC covers the sequence number.
        if not self._adopt_link_sequence_number():
            self._reanchor_after_config_idle()
        cmd.TransactionInfo.SeqNbr = self.sequence_number & 0xFFFF
        cmd.TransactionInfo.ReadWrite = PP_CMD_WRITE

        cmd.FuncInfo.DataSize = int(serial_data_size)
        cmd.FuncInfo.blockId = int(block_id) & 0xFFFF
        cmd.FuncInfo.FuncId = int(func_id) & 0xFF
        cmd.FuncInfo.SubFuncId = int(sub_func_id) & 0xFFFF
        cmd.FuncInfo.NbrOfParams = int(nbr_of_params) & 0xFF
        return cmd

    def prepare_param(
        self,
        cmd: CommandInfo,
        param_index: int,
        size_of_param: int,
        func_param_id: PP_FuncParamId,
        value: Union[str, bytes, bytearray, int, float, Sequence[int], Sequence[float]],
    ) -> None:
        # Store raw id/size; protocol-range validation is done during serialization.
        cmd.FuncInfo.FuncParamIds[param_index] = int(func_param_id)
        cmd.FuncInfo.FuncParamSizes[param_index] = int(size_of_param)

        # Convert value to payload bytes, mirroring memcpy() on little-endian MCU.
        payload = self._encode_param_payload(func_param_id, size_of_param, value)
        cmd.FuncInfo.FuncParams[param_index] = payload

    def _encode_param_payload(
        self,
        func_param_id: PP_FuncParamId,
        size_of_param: int,
        value: Union[str, bytes, bytearray, int, float, Sequence[int], Sequence[float]],
    ) -> bytes:
        fpid = int(func_param_id)
        if fpid == int(PP_FuncParamId.TYPE_String):
            if isinstance(value, (bytes, bytearray)):
                b = bytes(value)
            else:
                b = str(value).encode("utf-8")
            # C++ includes the null terminator in the size and payload.
            if not b.endswith(b"\x00"):
                b += b"\x00"
            return b[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Real):
            return struct.pack("<f", float(value))[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint8):
            return struct.pack("<B", int(value) & 0xFF)[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint16):
            return struct.pack("<H", int(value) & 0xFFFF)[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint32):
            return struct.pack("<I", int(value) & 0xFFFFFFFF)[:size_of_param].ljust(size_of_param, b"\x00")

        # Array types:
        if fpid == int(PP_FuncParamId.TYPE_RealArray):
            arr = list(value) if not isinstance(value, (bytes, bytearray)) else None
            if arr is None:
                b = bytes(value)
            else:
                b = b"".join(struct.pack("<f", float(x)) for x in arr)
            return b[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint32Array):
            arr = list(value) if not isinstance(value, (bytes, bytearray)) else None
            if arr is None:
                b = bytes(value)
            else:
                b = b"".join(struct.pack("<I", int(x) & 0xFFFFFFFF) for x in arr)
            return b[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint16Array):
            arr = list(value) if not isinstance(value, (bytes, bytearray)) else None
            if arr is None:
                b = bytes(value)
            else:
                b = b"".join(struct.pack("<H", int(x) & 0xFFFF) for x in arr)
            return b[:size_of_param].ljust(size_of_param, b"\x00")

        if fpid == int(PP_FuncParamId.TYPE_Uint8Array):
            if isinstance(value, (bytes, bytearray)):
                b = bytes(value)
            else:
                b = bytes(int(x) & 0xFF for x in value)
            return b[:size_of_param].ljust(size_of_param, b"\x00")

        # Fallback: raw bytes if provided, else 0s
        if isinstance(value, (bytes, bytearray)):
            b = bytes(value)
            return b[:size_of_param].ljust(size_of_param, b"\x00")
        return b"\x00" * size_of_param

    # ---------------------------------------------------------------------
    # Serialization helpers (write into the shared serial_data buffer)
    # ---------------------------------------------------------------------
    def serialize_header(self, cmd: CommandInfo) -> bytes:
        sd = self.serial_data
        struct.pack_into("<H", sd, PP_CMD_SEQ_NUMBER_IDX, cmd.TransactionInfo.SeqNbr & 0xFFFF)
        sd[PP_CMD_READ_WRITE_IDX] = cmd.TransactionInfo.ReadWrite & 0xFF

        struct.pack_into("<H", sd, PP_CMD_SIZEL_IDX, cmd.FuncInfo.DataSize & 0xFFFF)
        struct.pack_into("<H", sd, PP_CMD_blockIDL_IDX, cmd.FuncInfo.blockId & 0xFFFF)
        sd[PP_CMD_FUNC_ID_IDX] = cmd.FuncInfo.FuncId & 0xFF
        struct.pack_into("<H", sd, PP_CMD_SUB_FUNC_IDL_IDX, cmd.FuncInfo.SubFuncId & 0xFFFF)
        sd[PP_CMD_NBR_OF_PARAMS_IDX] = cmd.FuncInfo.NbrOfParams & 0xFF

        # Compute chunk info (mirrors C++ HandleCmd logic before SerializeHeader)
        body_size = cmd.FuncInfo.DataSize
        if body_size <= PP_CHUNK_MAX_SIZE:
            nbr_of_chunks = 1
            last_chunk_size = body_size
        else:
            nbr_of_chunks = (body_size + PP_CHUNK_MAX_SIZE - 1) // PP_CHUNK_MAX_SIZE
            last_chunk_size = body_size - (nbr_of_chunks - 1) * PP_CHUNK_MAX_SIZE
        # Store in FuncInfo like C++ does
        cmd.FuncInfo.NbrOfChunks = nbr_of_chunks
        cmd.FuncInfo.LastChunkSize = last_chunk_size
        sd[PP_CMD_NBR_OF_CHUNKS_IDX] = nbr_of_chunks & 0xFF
        struct.pack_into("<H", sd, PP_CMD_LAST_CHUNK_SIZEL_IDX, last_chunk_size & 0xFFFF)

        self.calculate_and_set_crc(sd, PP_CMD_HEADER_CRC_IDX)
        return bytes(sd[:PP_CMD_HEADER_SIZE])

    def serialize_response_request(self, cmd: CommandInfo, *, vect: bool = False) -> bytes:
        sd = self.serial_data
        struct.pack_into("<H", sd, PP_CMD_SEQ_NUMBER_IDX, cmd.TransactionInfo.SeqNbr & 0xFFFF)
        # C++ uses PP_CMD_READ (0x01) for normal, PP_CMD_READ_VECT_PROBE (0x02) for vector probes
        sd[PP_CMD_READ_WRITE_IDX] = (PP_CMD_READ_VECT_PROBE if vect else PP_CMD_READ) & 0xFF
        struct.pack_into("<H", sd, PP_CMD_SIZEL_IDX, PP_CMD_RESPONSE_ID)
        self.calculate_and_set_crc(sd, PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE)
        return bytes(sd[:PP_RESPONSE_REQ_SIZE])

    def serialize_command_body(self, cmd: CommandInfo) -> Tuple[int, List[Tuple[int, int, int, int, bytes]]]:
        """
        Serialize the command body into the shared buffer.
        Returns:
          - actual_serialized_length (including CRC)
          - a list of param descriptors: (param_index, param_id, size, payload_offset, payload_bytes)
        """
        sd = self.serial_data

        current = PP_CMD_BODY_START_IDX
        param_desc: List[Tuple[int, int, int, int, bytes]] = []

        for i in range(cmd.FuncInfo.NbrOfParams):
            pid = int(cmd.FuncInfo.FuncParamIds[i])
            psz = int(cmd.FuncInfo.FuncParamSizes[i])

            if pid < 0 or pid > PP_PARAM_DESC_MAX_ID:
                raise ValueError(
                    f"Param[{i}] id={pid} is out of range for packed descriptor (0..{PP_PARAM_DESC_MAX_ID})."
                )
            if psz < 0 or psz > PP_PARAM_DESC_MAX_SIZE:
                raise ValueError(
                    f"Param[{i}] size={psz} exceeds packed descriptor limit ({PP_PARAM_DESC_MAX_SIZE} bytes)."
                )
            if (current + PP_PARAM_DESC_SIZE) > len(sd):
                raise ValueError("Command body serialization overflow while writing parameter descriptor.")

            packed_param_desc = ((pid & PP_PARAM_DESC_MAX_ID) << PP_PARAM_DESC_ID_SHIFT) | (
                psz & PP_PARAM_DESC_SIZE_MASK
            )
            struct.pack_into("<H", sd, current, packed_param_desc & 0xFFFF)
            current += PP_PARAM_DESC_SIZE

            payload_offset = current
            payload = cmd.FuncInfo.FuncParams[i] if i < len(cmd.FuncInfo.FuncParams) else b""
            if payload is None:
                payload = b""
            # memcpy(payload, size)
            if (current + psz) > len(sd):
                raise ValueError("Command body serialization overflow while writing parameter payload.")
            sd[current : current + psz] = payload[:psz].ljust(psz, b"\x00")
            current += psz

            param_desc.append((i, pid, psz, payload_offset, bytes(sd[payload_offset : payload_offset + psz])))

        # CRC at [current:current+4]
        if (current + PP_CMD_CRC_SIZE) > len(sd):
            raise ValueError("Command body serialization overflow while writing command CRC.")
        self.calculate_and_set_crc(sd, current)
        actual_len = current + PP_CMD_CRC_SIZE
        return actual_len, param_desc

    # ---------------------------------------------------------------------
    # Command handling (NO IO: produces frames for analysis)
    # ---------------------------------------------------------------------
    def handle_cmd(self, cmd: CommandInfo, serial_data_size: int, *, vect: bool = False,
                   expect_response: bool = True) -> PapayaTransaction:
        # OPT-IN ONLY.  Clearing a latched refusal before every command
        # keeps a whole program running after the board said no, which
        # is what the batch example harnesses need (they run the program
        # to the end and grep stdout for "[USB] Auto-recovering"), and
        # exactly what must NOT happen to a user's debuggee: it turned a
        # refused StartSampling into a run that reported "Finished"
        # against a design the board never configured.  The C++ library
        # latches; so does this one now, unless a harness asks otherwise
        # (``CTX.auto_recover_errors = True`` or PAPAYA_AUTO_RECOVER).
        if self.usb_transport is not None and self.auto_recover_errors:
            if self.current_com_status != PP_ComStatus.ComOk:
                print(f"[USB] Auto-recovering from ComStatus={self.current_com_status.name}")
                self.current_com_status = PP_ComStatus.ComOk
            if self.current_design_status != PP_DesignStatus.DesignOk:
                print(f"[USB] Auto-recovering from DesignStatus={self.current_design_status.name}")
                self.current_design_status = PP_DesignStatus.DesignOk

        # Mirror C++ precondition: skip if previous error still active
        if self.current_com_status != PP_ComStatus.ComOk or self.current_design_status != PP_DesignStatus.DesignOk:
            raise RuntimeError(
                f"Cannot send command: ComStatus={self.current_com_status.name}, "
                f"DesignStatus={self.current_design_status.name} (must both be OK)"
            )

        # Mirror C++ overflow check (PAPAYA.cpp lines 1037-1040):
        # The C++ just sets BadParam and returns: no error handler, no exception.
        if serial_data_size > PP_CMD_BODY_HARD_MAX_SIZE:
            self.current_design_status = PP_DesignStatus.BadParam
            return PapayaTransaction(title="OVERFLOW", frames=[], seq=self.sequence_number)

        # Show the command to any observer before it becomes bytes. Placed
        # after the precondition checks above so a sink sees the same
        # commands the board would have been sent and not one the library
        # was about to refuse.
        if self.command_sink is not None:
            self.command_sink(cmd)

        func_name = PP_FuncId(cmd.FuncInfo.FuncId).name if cmd.FuncInfo.FuncId in [e.value for e in PP_FuncId] else str(cmd.FuncInfo.FuncId)
        subf_name = PP_SubFuncId(cmd.FuncInfo.SubFuncId).name if cmd.FuncInfo.SubFuncId in [e.value for e in PP_SubFuncId] else str(cmd.FuncInfo.SubFuncId)

        # 1) Header (18 bytes)
        header_bytes = self.serialize_header(cmd)
        header_frame = PapayaFrame(
            direction="TX",
            name="CFG Header",
            data=header_bytes,
            fields=[
                FrameField("SeqNbr", PP_CMD_SEQ_NUMBER_IDX, 2, cmd.TransactionInfo.SeqNbr),
                FrameField("ReadWrite", PP_CMD_READ_WRITE_IDX, 1, cmd.TransactionInfo.ReadWrite, "PP_CMD_WRITE" if cmd.TransactionInfo.ReadWrite == PP_CMD_WRITE else None),
                FrameField("BodySize", PP_CMD_SIZEL_IDX, 2, cmd.FuncInfo.DataSize),
                FrameField("BlockId", PP_CMD_blockIDL_IDX, 2, cmd.FuncInfo.blockId),
                FrameField("FuncId", PP_CMD_FUNC_ID_IDX, 1, f"{cmd.FuncInfo.FuncId} ({func_name})"),
                FrameField("SubFuncId", PP_CMD_SUB_FUNC_IDL_IDX, 2, f"0x{cmd.FuncInfo.SubFuncId:04X} ({subf_name})"),
                FrameField("NbrOfParams", PP_CMD_NBR_OF_PARAMS_IDX, 1, cmd.FuncInfo.NbrOfParams),
                FrameField("NbrOfChunks", PP_CMD_NBR_OF_CHUNKS_IDX, 1, cmd.FuncInfo.NbrOfChunks),
                FrameField("LastChunkSize", PP_CMD_LAST_CHUNK_SIZEL_IDX, 2, cmd.FuncInfo.LastChunkSize),
                FrameField(
                    "HeaderCRC",
                    PP_CMD_HEADER_CRC_IDX,
                    PP_CMD_CRC_SIZE,
                    header_bytes[PP_CMD_HEADER_CRC_IDX : PP_CMD_HEADER_CRC_IDX + PP_CMD_CRC_SIZE],
                ),
            ],
        )

        # 2) Command body (SerialDataSize bytes are transmitted, even if serializer produced fewer bytes)
        actual_len, param_desc = self.serialize_command_body(cmd)
        body_bytes = bytes(self.serial_data[:serial_data_size])
        body_fields: List[FrameField] = []

        # Params as fields (for quick visual parsing)
        for (i, pid, psz, payload_offset, payload_bytes) in param_desc:
            pid_name = self._param_type_name(pid)
            decoded = self._decode_payload(pid, payload_bytes)
            body_fields.append(
                FrameField(
                    f"Param[{i}] id={pid} (0x{pid:02X}) type={pid_name} size={psz} (0x{psz:04X})",
                    payload_offset - PP_PARAM_INFO_SIZE,
                    PP_PARAM_INFO_SIZE + psz,
                    decoded,
                )
            )

        notes: List[str] = []
        crc_offset = actual_len - PP_CMD_CRC_SIZE
        if crc_offset >= 0 and crc_offset + PP_CMD_CRC_SIZE <= len(body_bytes):
            body_fields.append(
                FrameField(
                    "BodyCRC",
                    crc_offset,
                    PP_CMD_CRC_SIZE,
                    body_bytes[crc_offset : crc_offset + PP_CMD_CRC_SIZE],
                )
            )
            notes.append(
                f"Body CRC (computed over bytes[0:{crc_offset}]): "
                f"0x{struct.unpack('<I', body_bytes[crc_offset : crc_offset + PP_CMD_CRC_SIZE])[0]:08X}"
            )
        else:
            notes.append("CRC location falls outside transmitted frame (size mismatch).")

        if actual_len != serial_data_size:
            if actual_len < serial_data_size:
                notes.append(
                    f"WARNING: serializer produced {actual_len} bytes, but the transmitted size is SerialDataSize={serial_data_size}. "
                    f"Trailing {serial_data_size-actual_len} byte(s) are leftovers from previous SerialData buffer contents."
                )
            else:
                notes.append(
                    f"WARNING: serializer produced {actual_len} bytes, which exceeds SerialDataSize={serial_data_size}. "
                    f"Only SerialDataSize bytes are transmitted (truncation)." 
                )

        body_frame = PapayaFrame(
            direction="TX",
            name=f"Command Body ({func_name}.{subf_name})",
            data=body_bytes,
            fields=body_fields,
            notes=notes,
        )

        response_request_bytes = self.serialize_response_request(cmd, vect=vect)
        response_request_frame = PapayaFrame(
            direction="TX",
            name="Response Request",
            data=response_request_bytes,
            fields=[
                FrameField("SeqNbr", PP_CMD_SEQ_NUMBER_IDX, 2, cmd.TransactionInfo.SeqNbr),
                FrameField(
                    "ReadWrite",
                    PP_CMD_READ_WRITE_IDX,
                    1,
                    PP_CMD_READ_VECT_PROBE if vect else PP_CMD_READ,
                    "PP_CMD_READ_VECT_PROBE" if vect else "PP_CMD_READ",
                ),
                FrameField("BodySize", PP_CMD_SIZEL_IDX, 2, PP_CMD_RESPONSE_ID),
                FrameField(
                    "ReqCRC",
                    PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE,
                    PP_CMD_CRC_SIZE,
                    response_request_bytes[PP_RESPONSE_REQ_SIZE - PP_CMD_CRC_SIZE : PP_RESPONSE_REQ_SIZE],
                ),
            ],
        )

        tx = PapayaTransaction(
            title=f"{func_name}.{subf_name}",
            frames=[header_frame, body_frame, response_request_frame],
            seq=cmd.TransactionInfo.SeqNbr,
            func=func_name,
            subfunc=subf_name,
            block_id=cmd.FuncInfo.blockId,
            notes=[
                f"Host polls with a {PP_RESPONSE_REQ_SIZE}-byte response-request frame until the slave answers or {PP_RESPONSE_TIMEOUT_MS} ms elapse.",
            ],
        )

        self.transaction_log.append(tx)

        # ── USB transport: send frame to board and get real response ──
        _usb_sent = False
        if self.usb_transport is not None and hasattr(self.usb_transport, 'send_frame'):
            _usb_sent = True
            try:
                usb_status = self.usb_transport.send_frame(
                    header_bytes, body_bytes, cmd.TransactionInfo.SeqNbr, vect=vect,
                    expect_response=expect_response,
                )
            except Exception as _usb_exc:
                usb_status = None
                if expect_response:
                    print(f"[USB] seq={cmd.TransactionInfo.SeqNbr:04d}  {func_name}.{subf_name}  ->  USB ERROR: {_usb_exc}")
                    self.current_com_status = PP_ComStatus.UnknownComError
            else:
                if not expect_response:
                    # Fire-and-forget command (e.g. mcuReset): the board
                    # will not respond because it is about to reboot /
                    # disappear. Log success of the send itself and skip
                    # the NO-RESPONSE status path.
                    print(f"[USB] seq={cmd.TransactionInfo.SeqNbr:04d}  {func_name}.{subf_name}  ->  SENT (no-response)")
                else:
                    # No exception: process the response
                    try:
                        status_name = PP_DesignStatus(usb_status).name if usb_status is not None else "None"
                    except (ValueError, KeyError):
                        status_name = str(usb_status)
                    if usb_status is not None and usb_status == 0:
                        print(f"[USB] seq={cmd.TransactionInfo.SeqNbr:04d}  {func_name}.{subf_name}  ->  {status_name}")
                    elif usb_status is not None:
                        print(f"[USB] seq={cmd.TransactionInfo.SeqNbr:04d}  {func_name}.{subf_name}  ->  FAILED: {status_name} (code={usb_status})")
                        try:
                            self.current_design_status = PP_DesignStatus(usb_status)
                        except (ValueError, KeyError):
                            self.current_design_status = PP_DesignStatus.BadRequest
                    else:
                        print(f"[USB] seq={cmd.TransactionInfo.SeqNbr:04d}  {func_name}.{subf_name}  ->  NO RESPONSE (timeout)")
                        self.current_com_status = PP_ComStatus.UnknownComError

            if expect_response:
                self._retry_once_after_badrequest(
                    cmd, body_bytes, tx, func_name, subf_name, vect=vect)

            # The END of the exchange, whatever its outcome: the stamp
            # the idle rule measures from.  Set here rather than at the
            # TX so the measurement stays on the safe side of the
            # board's own clock (see ``_last_exchange_end_ms``).
            try:
                self._last_exchange_end_ms = float(self.clock_ms())
            except Exception:
                self._last_exchange_end_ms = None

        if not _usb_sent and self.auto_print:
            print(tx.render())
            print()  # spacing

        # Sequence-number rule, verified against a real board: the board
        # advances its sequence counter after ANY response it transmits,
        # including responses that embed a design failure status.  Only
        # its refusal of a sequence-mismatched frame leaves the counter
        # alone.  So the host must advance whenever a response ARRIVED,
        # regardless of the status inside it.
        #
        # The previous rule ("only increment when no errors occurred",
        # mirroring the old C++ library) desynchronised host and board
        # after the first failed command: host at N, board at N+1, so
        # every subsequent frame, including the small set of commands
        # the board still accepts after a failure (StopSampling,
        # GetDesignInfo, GetDebugLog...), bounced with BadRequest or
        # was silently seq-dropped.  Only a com error (no response at
        # all) leaves the counter untouched, because then the board may
        # never have processed the frame.
        self._finish_command_cycle()

        return tx

    def _retry_once_after_badrequest(
        self,
        cmd: CommandInfo,
        body_bytes: bytes,
        tx: PapayaTransaction,
        func_name: str,
        subf_name: str,
        *,
        vect: bool = False,
    ) -> None:
        """Re-anchor to 0 and re-send this command exactly once.

        The Python twin of the one-shot BadRequest recovery in
        ``papaya_lib/PAPAYA.cpp`` (``HandleCmd`` / ``HandleCmdVect``),
        and the complement of the time-based rule in
        :meth:`_reanchor_after_config_idle`. It closes the two windows
        that rule is structurally blind to:

        1. The skew band.  The board's idle countdown restarts at the
           last packet it accepted, EARLIER than this client's
           exchange-end stamp, so board-idle >= host-idle always.  In the
           band between them the board released its configuration session
           and zeroed its counter while the host still measured < 3000 ms.
        2. A mid-exchange pause.  A breakpoint hit between the command
           TX and the response read runs the board's clock the whole
           time, yet on resume the exchange completes and the host's
           exchange-end gap reads ~0, invisible to ANY host-side idle
           measurement by construction.  This is the ordinary way a
           debugger is used, so it is not a corner case here.

        The single retry is deterministic, not a hopeful repeat: a
        refusal response never advances the board's counter, while the
        rejected packet's own arrival already re-claimed the session and
        ZEROED that counter.  The board is therefore provably at 0, so
        the retry either succeeds or fails identically, never a third
        state.

        Config phase only: the board's config-idle watchdog stops running
        once data exchange is started, so a BadRequest there means
        something else and must surface unchanged.
        """
        transport = self.usb_transport
        if transport is None or not hasattr(transport, "send_frame"):
            return
        if self.data_exchange_started:
            return
        if self.current_com_status != PP_ComStatus.ComOk:
            return
        if self.current_design_status != PP_DesignStatus.BadRequest:
            return

        refused_seq = cmd.TransactionInfo.SeqNbr
        print(
            f"[USB] seq={refused_seq:04d}  {func_name}.{subf_name}  ->  "
            f"BadRequest in the configuration phase: the board released "
            f"its configuration session and restarted its numbering; "
            f"re-sending once at seq 0"
        )

        self.sequence_number = 0
        cmd.TransactionInfo.SeqNbr = 0
        self.current_design_status = PP_DesignStatus.DesignOk
        # Re-sign the header: the CRC covers the sequence number, so the
        # frame has to be rebuilt, never patched.  ``body_bytes`` was
        # snapshotted before this and its own CRC does not cover the
        # sequence, so the body is re-sent unchanged.
        retry_header = self.serialize_header(cmd)

        try:
            retry_status = transport.send_frame(
                retry_header, body_bytes, 0, vect=vect, expect_response=True)
        except Exception as exc:  # noqa: BLE001
            print(f"[USB] seq=0000  {func_name}.{subf_name}  ->  "
                  f"USB ERROR on the re-send: {exc}")
            self.current_com_status = PP_ComStatus.UnknownComError
            tx.notes.append("Re-sent once at seq 0 after BadRequest; the "
                            "re-send failed on the link.")
            return

        if retry_status is not None and retry_status == 0:
            print(f"[USB] seq=0000  {func_name}.{subf_name}  ->  DesignOk "
                  f"(recovered by re-anchoring to 0)")
            tx.notes.append(
                f"Refused with BadRequest at seq {refused_seq}, re-sent "
                f"once at seq 0 and accepted.")
            return

        if retry_status is None:
            print(f"[USB] seq=0000  {func_name}.{subf_name}  ->  "
                  f"NO RESPONSE (timeout) on the re-send")
            self.current_com_status = PP_ComStatus.UnknownComError
            tx.notes.append("Re-sent once at seq 0 after BadRequest; no "
                            "response to the re-send.")
            return

        try:
            self.current_design_status = PP_DesignStatus(retry_status)
        except (ValueError, KeyError):
            self.current_design_status = PP_DesignStatus.BadRequest
        print(f"[USB] seq=0000  {func_name}.{subf_name}  ->  FAILED: "
              f"{self.current_design_status.name} (code={retry_status}) on "
              f"the re-send, surfacing it")
        tx.notes.append(
            f"Refused with BadRequest at seq {refused_seq}; the single "
            f"re-send at seq 0 was refused too (code={retry_status}).")

    def _finish_command_cycle(self) -> None:
        """Run error handlers and advance the sequence counter.

        Separated from ``handle_cmd`` so the rule is directly testable:
        the counter advances whenever a response ARRIVED (even one that
        embeds a design failure: the firmware increments after every
        transmitted response), and holds only on a com error, where the
        board may never have processed the frame.
        """
        design_error = self.current_design_status != PP_DesignStatus.DesignOk
        com_error = self.current_com_status != PP_ComStatus.ComOk
        if design_error and self.design_error_handler:
            self.design_error_handler()
        if com_error and self.com_error_handler:
            self.com_error_handler()
        if not com_error:
            self.sequence_number = (self.sequence_number + 1) & 0xFFFF

    def _adopt_link_sequence_number(self) -> None:
        """Take the sequence number from the link when the link knows it.

        The board keeps ONE counter and rejects any frame not carrying the
        value it expects. When this library shares a link with the Studio
        there are two host-side counters against that one board counter:
        this ``sequence_number``, which advances only for commands sent
        from here, and the Studio's own, which advances for everything it
        sends. Anything the Studio sends in between leaves this one
        behind, and the next command is rejected.

        That is the "random failing sequence number": WHICH command dies
        depends on how much traffic the Studio happened to interleave, so
        it moves from run to run. Measured on 2026-07-31: a
        GetDesignInstrumentation took the link from 61 to 62, the next
        StartSampling still carried 61, and the board refused it with
        status 8, while the debug session reported "Finished".

        A transport that shares a link publishes ``link_sequence_number``;
        a transport that owns its link does not, and nothing changes for
        it. The frame itself is never rewritten: the value is adopted
        BEFORE the frame is built, because the CRC covers it.

        Returns True when a value was adopted, so the caller knows this
        context is not the sole authority on the counter.
        """
        transport = getattr(self, "usb_transport", None)
        if transport is None:
            return False
        try:
            link_seq = getattr(transport, "link_sequence_number", None)
        except Exception:
            return False
        if link_seq is None:
            return False
        try:
            self.sequence_number = int(link_seq) & 0xFFFF
        except (TypeError, ValueError):
            return False
        return True

    def _reanchor_after_config_idle(self) -> None:
        """Zero the counter when the board has certainly released it.

        The Python twin of ``PrepareCmdHeader``'s idle re-anchor in
        ``papaya_lib/PAPAYA.cpp``, and of the same check Papaya Studio
        makes when it steps a design. A Python program running over the
        Studio bridge had NEITHER, because
        ``PapayaStudioBridgeTransport`` overrides only the byte-level
        ``_write``/``_read`` and publishes no ``link_sequence_number``
        and no board-renumbering signal.  A breakpoint held for
        more than three seconds (the normal way to use a debugger)
        therefore ended the run with "design status = 8" from a board
        that was alive and waiting.

        The three guards, each dictated by how the board behaves:

        * a transport must be attached: with no board there is no
          board counter to re-anchor to, and the frame log would drift;
        * the CONFIG phase only: the board's config-idle watchdog stops
          running once data exchange is started, so a started exchange
          still legitimately holds the counter;
        * a previous exchange must exist, and the gap is measured from
          its END (see ``_last_exchange_end_ms``) so the rule can only
          ever under-measure.
        """
        if self.usb_transport is None:
            return
        if self.data_exchange_started:
            return
        stamp = self._last_exchange_end_ms
        if stamp is None:
            return
        try:
            idle_ms = float(self.clock_ms()) - float(stamp)
        except Exception:
            return
        if idle_ms <= PP_HOST_CFG_IDLE_RESYNC_MS:
            return
        if self.sequence_number == 0:
            return  # already where the board will be; say nothing
        print(
            f"[USB] {idle_ms / 1000.0:.1f} s without a command: the board "
            f"released its configuration session and restarted its command "
            f"numbering; continuing from 0 instead of "
            f"{self.sequence_number}"
        )
        self.sequence_number = 0

    @staticmethod
    def _param_type_name(pid: int) -> str:
        try:
            return PP_FuncParamId(pid).name
        except Exception:
            return "TYPE_Unknown"

    @staticmethod
    def _format_bytes_dec_hex(data: bytes, *, max_items: int = 16) -> str:
        shown = list(data[:max_items])
        dec_values = ", ".join(str(v) for v in shown)
        hex_values = ", ".join(f"0x{v:02X}" for v in shown)
        tail = ", ..." if len(data) > max_items else ""
        return f"dec=[{dec_values}{tail}], hex=[{hex_values}{tail}]"

    @staticmethod
    def _format_ints_dec_hex(values: Sequence[int], *, bits: int, max_items: int) -> str:
        mask = (1 << bits) - 1
        width = max(2, bits // 4)
        shown = [(int(v) & mask) for v in values[:max_items]]
        dec_values = ", ".join(str(v) for v in shown)
        hex_values = ", ".join(f"0x{v:0{width}X}" for v in shown)
        tail = ", ..." if len(values) > max_items else ""
        return f"dec=[{dec_values}{tail}], hex=[{hex_values}{tail}]"

    def _decode_payload(self, pid: int, payload: bytes) -> str:
        """Human-friendly payload decoding with decimal + hex value formats."""
        if pid == int(PP_FuncParamId.TYPE_String):
            # decode up to first null
            s = payload.split(b"\x00", 1)[0]
            try:
                txt = s.decode("utf-8", errors="replace")
            except Exception:
                txt = "<decode-error>"
            return f"text=\"{txt}\" ({len(payload)}B), {self._format_bytes_dec_hex(payload, max_items=24)}"

        if pid == int(PP_FuncParamId.TYPE_Real):
            if len(payload) >= 4:
                dec_v = struct.unpack("<f", payload[:4])[0]
                hex_v = struct.unpack("<I", payload[:4])[0]
                return f"dec={dec_v} (float32), hex=0x{hex_v:08X}"
            return f"<float payload {len(payload)}B>, {self._format_bytes_dec_hex(payload)}"

        if pid == int(PP_FuncParamId.TYPE_Uint8):
            if payload:
                v = payload[0]
                return f"dec={v} (uint8), hex=0x{v:02X}"
            return "<uint8 empty>"

        if pid == int(PP_FuncParamId.TYPE_Uint16):
            if len(payload) >= 2:
                v = struct.unpack("<H", payload[:2])[0]
                return f"dec={v} (uint16), hex=0x{v:04X}"
            return f"<uint16 payload {len(payload)}B>, {self._format_bytes_dec_hex(payload)}"

        if pid == int(PP_FuncParamId.TYPE_Uint32):
            if len(payload) >= 4:
                v = struct.unpack("<I", payload[:4])[0]
                return f"dec={v} (uint32), hex=0x{v:08X}"
            return f"<uint32 payload {len(payload)}B>, {self._format_bytes_dec_hex(payload)}"

        if pid == int(PP_FuncParamId.TYPE_RealArray):
            # show first few floats
            n = len(payload) // 4
            if n == 0:
                return "float[0]: dec=[], hex=[]"
            show_n = min(n, 8)
            parts = []
            for i in range(show_n):
                b4 = payload[i * 4 : (i + 1) * 4]
                dec_v = struct.unpack("<f", b4)[0]
                hex_v = struct.unpack("<I", b4)[0]
                parts.append(f"{dec_v} (0x{hex_v:08X})")
            tail = ", ..." if n > show_n else ""
            trailing = len(payload) % 4
            trailing_desc = ""
            if trailing:
                trailing_desc = f"; trailing_bytes {self._format_bytes_dec_hex(payload[n*4:], max_items=8)}"
            return f"float[{n}]: [{', '.join(parts)}{tail}]{trailing_desc}"

        if pid == int(PP_FuncParamId.TYPE_Uint16Array):
            n = len(payload) // 2
            vals = [struct.unpack("<H", payload[i * 2 : (i + 1) * 2])[0] for i in range(n)]
            trailing = len(payload) % 2
            trailing_desc = ""
            if trailing:
                trailing_desc = f"; trailing_bytes {self._format_bytes_dec_hex(payload[n*2:], max_items=8)}"
            return f"uint16[{n}]: {self._format_ints_dec_hex(vals, bits=16, max_items=10)}{trailing_desc}"

        if pid == int(PP_FuncParamId.TYPE_Uint32Array):
            n = len(payload) // 4
            vals = [struct.unpack("<I", payload[i * 4 : (i + 1) * 4])[0] for i in range(n)]
            trailing = len(payload) % 4
            trailing_desc = ""
            if trailing:
                trailing_desc = f"; trailing_bytes {self._format_bytes_dec_hex(payload[n*4:], max_items=8)}"
            return f"uint32[{n}]: {self._format_ints_dec_hex(vals, bits=32, max_items=10)}{trailing_desc}"

        if pid == int(PP_FuncParamId.TYPE_Uint8Array):
            n = len(payload)
            vals = list(payload)
            return f"uint8[{n}]: {self._format_ints_dec_hex(vals, bits=8, max_items=16)}"

        return f"raw[{len(payload)}]: {self._format_bytes_dec_hex(payload, max_items=16)}"

    # ---------------------------------------------------------------------
    # Non-DLP data exchange frames (setInputs/getProbes/getVectorProbes/etc.)
    # ---------------------------------------------------------------------
    def record_sampling_transaction(
        self,
        title: str,
        data: bytes,
        *,
        frame_name: str,
        rx_data: Optional[bytes] = None,
        rx_frame_name: Optional[str] = None,
        inter_frame_delay_ms: int = 0,
        notes: Optional[List[str]] = None,
    ) -> PapayaTransaction:
        """Record a sampling-mode transaction.

        Mirrors the C++ SPI framing where opcode and payload/response are
        sent/received as separate CS-framed SPI transactions.

        Parameters
        ----------
        data : bytes
            TX frame bytes (typically the 1-byte opcode).
        rx_data : bytes, optional
            Second frame bytes (TX payload for writes, RX placeholder for reads).
        rx_frame_name : str, optional
            Name for the second frame.
        inter_frame_delay_ms : int
            Delay between the two SPI transactions (e.g. 2 ms for vector probes).
        """
        frames: List[PapayaFrame] = [PapayaFrame(direction="TX", name=frame_name, data=data, notes=notes or [])]
        if rx_data is not None:
            direction = "TX" if title.endswith("WriteInputs") else "RX"
            delay_notes: List[str] = []
            if inter_frame_delay_ms > 0:
                delay_notes.append(f"Preceded by {inter_frame_delay_ms} ms inter-frame delay.")
            frames.append(PapayaFrame(
                direction=direction,
                name=rx_frame_name or "Payload",
                data=rx_data,
                notes=delay_notes,
            ))
        tx = PapayaTransaction(
            title=title,
            frames=frames,
            seq=self.sequence_number,
            func="SamplingMode",
            notes=["Sampling-mode frames use raw opcodes instead of the configuration header/body format."],
        )
        self.transaction_log.append(tx)
        if self.auto_print:
            print(tx.render())
            print()
        return tx

    def spi_tx_bytes(self, name: str, data: bytes, notes: Optional[List[str]] = None) -> PapayaFrame:
        frame = PapayaFrame(direction="TX", name=name, data=data, notes=notes or [])
        if self.auto_print:
            print(frame.render())
            print()
        return frame

    # Convenience: register labels (optional)
    def register_input_label(self, idx: int, label: str) -> None:
        self._input_labels_by_idx[idx] = label

    def register_probe_label(self, idx: int, label: str) -> None:
        self._probe_labels_by_idx[idx] = label

    def register_vector_probe_label(self, idx: int, label: str) -> None:
        self._vector_probe_labels_by_idx[idx] = label

    def reset_command_sequence(self, *, clear_transaction_log: bool = False) -> None:
        """Reset command transport sequencing for a new design/debug session."""
        self.sequence_number = 0
        self.data_exchange_started = False
        if clear_transaction_log:
            self.transaction_log.clear()


# Global singleton context, mirroring the C++ file-scope statics.
CTX = PapayaContext()
