/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe scurve_position;
probe scurve_velocity;
probe scurve_accelera;
probe scurve_jerk;
probe trapezoid_posit;
probe trapezoid_veloc;
probe trapezoid_accel;
probe shaped_command;

input target;
input start;
input scurve_v_max;
input scurve_a_max;
input scurve_j_max;
input trap_v_max;
input trap_a_max;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  target = input("target", 1.0f);
  start = input("start", 0.0f);
  scurve_v_max = input("scurve_v_max", 1.0f);
  scurve_a_max = input("scurve_a_max", 2.0f);
  scurve_j_max = input("scurve_j_max", 20.0f);
  trap_v_max = input("trap_v_max", 1.0f);
  trap_a_max = input("trap_a_max", 2.0f);
  signalSource Step = signalSource::square(0.4f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.5f);
  expander target_split = expander(2);
  expander start_split = expander(2);
  trajScurve S_curve = trajScurve();
  trajTrapezoid Trapezoid = trajTrapezoid();
  inputShaper Shaper = inputShaper(0, 10.0, 0.05);
  scurve_position = probe("scurve_position");
  scurve_velocity = probe("scurve_velocity");
  scurve_accelera = probe("scurve_accelera");
  scurve_jerk = probe("scurve_jerk");
  trapezoid_posit = probe("trapezoid_posit");
  trapezoid_veloc = probe("trapezoid_veloc");
  trapezoid_accel = probe("trapezoid_accel");
  shaped_command = probe("shaped_command");

  /* Connect Blocks */
  target > target_split;
  start > start_split;
  scurve_v_max > S_curve.in(1);
  scurve_a_max > S_curve.in(2);
  scurve_j_max > S_curve.in(3);
  trap_v_max > Trapezoid.in(1);
  trap_a_max > Trapezoid.in(2);
  Step > Shaper;
  target_split.out(0) > S_curve.in(0);
  target_split.out(1) > Trapezoid.in(0);
  start_split.out(0) > S_curve.in(4);
  start_split.out(1) > Trapezoid.in(3);
  S_curve.out(0) > scurve_position;
  S_curve.out(1) > scurve_velocity;
  S_curve.out(2) > scurve_accelera;
  S_curve.out(3) > scurve_jerk;
  Trapezoid.out(0) > trapezoid_posit;
  Trapezoid.out(1) > trapezoid_veloc;
  Trapezoid.out(2) > trapezoid_accel;
  Shaper > shaped_command;

  /* Enable Remote Input Control */
  target.enableRemote();
  start.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    scurve_position.show();
    scurve_velocity.show();
    scurve_accelera.show();
    scurve_jerk.show();
    trapezoid_posit.show();
    trapezoid_veloc.show();
    trapezoid_accel.show();
    shaped_command.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}