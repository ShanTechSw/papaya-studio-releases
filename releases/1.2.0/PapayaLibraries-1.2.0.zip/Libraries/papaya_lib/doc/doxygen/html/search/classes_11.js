var searchData=
[
  ['updwnperiod_0',['UpDwnperiod',['../class_up_dwnperiod.html',1,'']]]
];
