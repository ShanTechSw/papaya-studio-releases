from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Optional

from .enums import PP_HwId, PP_MotorOutput


# ---------------------------------------------------------------------------
# Struct-like configuration holders (mirroring the C++ typedef structs)
# ---------------------------------------------------------------------------

@dataclass
class PP_compFilter:
    """Configuration for the complementary filter node."""
    alpha: float                        # Blend factor (0..1)


@dataclass
class PP_SMO:
    """Configuration for the sliding mode observer node (SISO / MIMO).

    x̂[k+1] = A·x̂ + B·u + L·e + K·sat(e/ε),  e = y − C·x̂
    """
    n: int                              # Number of states
    m: int                              # Number of control inputs
    p: int                              # Number of measured outputs
    A_data: Sequence[float]             # n × n, row-major
    B_data: Sequence[float]             # n × m, row-major
    C_data: Sequence[float]             # p × n, row-major
    L_data: Sequence[float]             # n × p, row-major (linear gain)
    K_data: Sequence[float]             # n × p, row-major (sliding gain)
    x_init: Sequence[float]             # n × 1, initial state
    epsilon: float                      # Boundary layer thickness


@dataclass
class PP_PMSM_EKF:
    """Sensorless PMSM observer config."""
    Rs: float
    Ls: float
    lambda_pm: float
    Q_data: Sequence[float]     # [4*4]
    R_data: Sequence[float]     # [2*2]
    x_init: Sequence[float]     # [4]
    P_init: float


@dataclass
class PP_AHRS_EKF:
    """AHRS quaternion estimator config."""
    mag_ref: Sequence[float]    # [3] normalized magnetic reference
    Q_data: Sequence[float]     # [7*7]
    R_data: Sequence[float]     # [6*6]
    x_init: Sequence[float]     # [7]
    P_init: float


@dataclass
class PP_BatterySOC_EKF:
    """Battery SOC estimator config (1-RC Thevenin)."""
    R0: float
    R1: float
    C1: float
    Q_cap: float
    ocv_coef: Sequence[float]   # [4] polynomial a0+a1*SOC+a2*SOC^2+a3*SOC^3
    Q_data: Sequence[float]     # [2*2]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [2]
    P_init: float


@dataclass
class PP_Tilt_EKF:
    """Single-axis tilt estimator config."""
    Q_data: Sequence[float]     # [2*2]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [2]
    P_init: float


@dataclass
class PP_LoadTorque_EKF:
    """Load torque estimator config."""
    J: float
    B: float
    Q_data: Sequence[float]     # [2*2]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [2]
    P_init: float


@dataclass
class PP_Thermal_EKF:
    """Thermal model EKF config (2-node lumped RC)."""
    R_th: float
    C_core: float
    C_surf: float
    R_conv: float
    T_amb: float
    Q_data: Sequence[float]     # [2*2]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [2]
    P_init: float


@dataclass
class PP_BaroAlt_EKF:
    """Barometric altitude EKF config."""
    Q_data: Sequence[float]     # [3*3]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [3]
    P_init: float


@dataclass
class PP_RobotLoc_EKF:
    """2D robot localization EKF config."""
    wheel_radius: float
    wheel_base: float
    landmark_x: float
    landmark_y: float
    Q_data: Sequence[float]     # [3*3]
    R_data: Sequence[float]     # [2*2]
    x_init: Sequence[float]     # [3]
    P_init: float


@dataclass
class PP_SinTrack_EKF:
    """Sinusoidal signal tracker EKF config."""
    Q_data: Sequence[float]     # [3*3]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [3]
    P_init: float


@dataclass
class PP_GridSync_EKF:
    """Grid frequency and phase tracker EKF config."""
    nom_freq: float
    nom_amplitude: float
    Q_data: Sequence[float]     # [3*3]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [3]
    P_init: float


@dataclass
class PP_ACIM_EKF:
    """Sensorless AC induction motor EKF config."""
    Rs: float
    Rr: float
    Ls: float
    Lr: float
    Lm: float
    P_pairs: float
    Q_data: Sequence[float]     # [5*5]
    R_data: Sequence[float]     # [2*2]
    x_init: Sequence[float]     # [5]
    P_init: float


@dataclass
class PP_BatterySOH_EKF:
    """Battery SOH EKF config."""
    R1: float
    C1: float
    ocv_coef: Sequence[float]   # [4]
    Q_data: Sequence[float]     # [3*3]
    R_data: Sequence[float]     # [1]
    x_init: Sequence[float]     # [3]
    P_init: float


@dataclass
class PP_WMR_EKF:
    """Wheeled Mobile Robot EKF config."""
    wheel_base: float
    mag_ref: Sequence[float]    # [2]
    Q_data: Sequence[float]     # [7*7]
    R_data: Sequence[float]     # [7*7]
    x_init: Sequence[float]     # [7]
    P_init: float


@dataclass
class PP_GPSINS_EKF:
    """GPS/INS fusion EKF config."""
    Q_data: Sequence[float]     # [7*7]
    R_data: Sequence[float]     # [4*4]
    x_init: Sequence[float]     # [7]
    P_init: float


@dataclass
class PP_LMSConfig:
    """LMS / NLMS adaptive filter config."""
    mu: float
    N: int
    normalize: int
    delta: float


@dataclass
class PP_AdaptiveNotchConfig:
    """Adaptive notch filter config."""
    init_freq: float
    Q_factor: float
    mu: float


@dataclass
class PP_DOBConfig:
    """Disturbance observer config."""
    Gn_num: Sequence[float]
    Gn_den: Sequence[float]
    Qf_num: Sequence[float]
    Qf_den: Sequence[float]
    plant_ord: int
    qf_ord: int


@dataclass
class PP_ESCConfig:
    """Extremum seeking control config."""
    a: float
    omega: float
    k: float
    hpf_wc: float
    lpf_wc: float


@dataclass
class PP_ADRCConfig:
    """Active Disturbance Rejection Control config."""
    b0: float
    omega_o: float
    omega_c: float
    order: int


@dataclass
class PP_MRACConfig:
    """Model Reference Adaptive Control config."""
    Am: float
    Bm: float
    gamma_x: float
    gamma_r: float


@dataclass
class PP_MRACLyapunovConfig:
    """MRAC with Lyapunov stability guarantee config."""
    Am: float
    Bm: float
    gamma_x: float
    gamma_r: float
    sigma: float
    theta_max: float


@dataclass
class PP_RepCtrlConfig:
    """Repetitive controller config."""
    period_samples: int
    Q_gain: float
    Kr: float


@dataclass
class PP_STRConfig:
    """Self-Tuning Regulator config."""
    na: int
    nb: int
    lambda_: float
    P_init: float
    desired_poles: Sequence[float]


@dataclass
class PP_ILCConfig:
    """Iterative Learning Control config."""
    trial_length: int
    L_gain: float
    Q_gain: float


@dataclass
class PP_GainSchedulePIDConfig:
    """Gain-scheduled PID config."""
    schedule_points: Sequence[float]
    Kp_table: Sequence[float]
    Ki_table: Sequence[float]
    Kd_table: Sequence[float]
    Tau: float
    out_min: float
    out_max: float
    num_points: int


@dataclass
class PP_GainSchedulerConfig:
    """Generic gain scheduler config."""
    breakpoints: Sequence[float]
    values: Sequence[float]
    num_points: int
    num_outputs: int


@dataclass
class PP_RelayAutoTuneConfig:
    """Relay feedback PID auto-tuner config."""
    relay_amplitude: float
    hysteresis: float
    setpoint: float
    tuning_rule: int
    min_cycles: int


@dataclass
class PP_StepAutoTuneConfig:
    """Step response PID auto-tuner config."""
    step_size: float
    settle_pct: float
    tuning_rule: int
    id_method: int


@dataclass
class PP_STR_PID_Config:
    """Self-Tuning PID config."""
    lambda_: float
    P_init: float
    Tau: float
    desired_cl_bw: float
    #: Fit the model one tick in N, 1 to 64. The identifier runs at Fs/N with
    #: both its inputs anti-alias filtered; the PID keeps running every tick,
    #: so the loop is unchanged and only the fit is decimated. 1 is the
    #: behaviour every design had before this parameter existed.
    UpdateDivider_u16: int = 1


@dataclass
class PP_MRAC_PID_Config:
    """Model Reference Adaptive PID config."""
    Am: float
    Bm: float
    gamma_p: float
    gamma_i: float
    gamma_d: float
    Tau: float


@dataclass
class PP_ESC_PID_Config:
    """Extremum Seeking PID Optimizer config."""
    Kp_init: float
    Ki_init: float
    Kd_init: float
    a: float
    omega_p: float
    omega_i: float
    omega_d: float
    esc_gain: float
    lpf_wc: float
    Tau: float
    iae_window: float


@dataclass
class PP_PerfMonPID_Config:
    """Performance-Monitoring Adaptive PID config."""
    Kp_init: float
    Ki_init: float
    Kd_init: float
    Tau: float
    iae_threshold: float
    out_min: float
    out_max: float
    eval_window: float


@dataclass
class PP_FuzzyPIDConfig:
    """Fuzzy logic PID config."""
    Kp_base: float
    Ki_base: float
    Kd_base: float
    e_range: float
    de_range: float
    Tau: float
    out_min: float
    out_max: float


@dataclass
class PP_stateSpace:
    """Configuration for the state-space system node (SISO / MIMO).

    Discrete-time equations:
        x[k+1] = A·x[k] + B·u[k]
        y[k]   = C·x[k] + D·u[k]
    """
    n: int                              # Number of states
    m: int                              # Number of inputs
    p: int                              # Number of outputs
    A_data: Sequence[float]             # n × n, row-major
    B_data: Sequence[float]             # n × m, row-major
    C_data: Sequence[float]             # p × n, row-major
    D_data: Sequence[float]             # p × m, row-major
    x_init: Sequence[float]             # n × 1, initial state


@dataclass
class PP_adaptiveKF:
    dim_x: int
    dim_z: int
    dim_u: int
    x_init: Sequence[float]
    F_data: Sequence[float]  # dim_x * dim_x
    H_data: Sequence[float]  # dim_z * dim_x
    Q_data: Sequence[float]  # dim_x * dim_x
    B_data: Optional[Sequence[float]]  # dim_x * dim_u (can be None in C++ code path)
    R_init: float
    P_init: float
    alpha: float


@dataclass
class PP_linearKF:
    dim_x: int
    dim_z: int
    dim_u: int
    x_init: Sequence[float]
    F_data: Sequence[float]  # dim_x * dim_x
    H_data: Sequence[float]  # dim_z * dim_x
    Q_data: Sequence[float]  # dim_x * dim_x
    B_data: Optional[Sequence[float]]  # dim_x * dim_u (can be None in C++ code path)
    R_init: float
    P_init: float


@dataclass
class PP_RLSParam:
    num: Sequence[float]
    lenNum: int
    denom: Sequence[float]
    lenDenom: int
    InitVariance_f32: float
    ModelOrder_u8: int
    UpdateDivider_u16: int = 1

    @staticmethod
    def from_arrays(
        num: Sequence[float],
        denom: Sequence[float],
        InitVariance_f32: float,
        ModelOrder_u8: int,
        UpdateDivider_u16: int = 1,
    ) -> "PP_RLSParam":
        return PP_RLSParam(
            num=num,
            lenNum=len(num),
            denom=denom,
            lenDenom=len(denom),
            InitVariance_f32=InitVariance_f32,
            ModelOrder_u8=ModelOrder_u8,
            UpdateDivider_u16=UpdateDivider_u16,
        )


@dataclass
class PP_RRLSParam:
    num: Sequence[float]
    lenNum: int
    denom: Sequence[float]
    lenDenom: int
    InitVariance_f32: float
    ModelOrder_u8: int
    sensParam_f32: float
    UpdateDivider_u16: int = 1

    @staticmethod
    def from_arrays(
        num: Sequence[float],
        denom: Sequence[float],
        InitVariance_f32: float,
        ModelOrder_u8: int,
        sensParam_f32: float,
        UpdateDivider_u16: int = 1,
    ) -> "PP_RRLSParam":
        return PP_RRLSParam(
            num=num,
            lenNum=len(num),
            denom=denom,
            lenDenom=len(denom),
            InitVariance_f32=InitVariance_f32,
            ModelOrder_u8=ModelOrder_u8,
            sensParam_f32=sensParam_f32,
            UpdateDivider_u16=UpdateDivider_u16,
        )


@dataclass
class PP_anInCfg:
    outScale: float
    offset: float
    id: PP_HwId


@dataclass
class PP_pwmInCfg:
    """One row of a multi-channel :class:`papaya.blocks.pwmIn` block.

    Attributes:
        outScale: Measurement RANGE in SECONDS, the longest interval this
            channel can time. Not a multiplier: the output is the measured
            time in seconds whatever this is set to. Default 1.0.
        id: Frequency input and mode, ``FI1_PULSE``..``FI5_DELAY``. One
            block per physical channel, whichever of the three modes it is
            in. A PULSE or DELAY row contributes TWO outputs to the block,
            its measurement and the period of the same signal, while a
            PERIOD row contributes one, and the board starts the block only
            once every one of them is connected. Wire them all, or the
            block never runs and every output reads 0.0 with no error
            reported.
    """
    outScale: float
    id: PP_HwId


@dataclass
class PP_pwmOutCfg:
    """One row of a multi-channel :class:`papaya.blocks.pwmOut` block.

    Every row is held to the same ranges as the single-channel form.

    Attributes:
        frequency: Carrier frequency in Hz. Realisable span 0.06403 to
            137500000; outside it the board runs the channel at a different
            frequency and reports nothing.
        dutyLowerLimit: Lower duty clamp, a FRACTION in 0.0 to 1.0.
        dutyUpperLimit: Upper duty clamp, same fraction and range. Must not
            be below ``dutyLowerLimit``: the board swaps a reversed pair
            silently.
        id: Frequency output channel, ``FO1``..``FO8``.
    """
    frequency: float
    dutyLowerLimit: float
    dutyUpperLimit: float
    id: PP_HwId


@dataclass
class PP_anOutCfg:
    """One row of a multi-channel input-driven analog output block.

    Attributes:
        lowerLimit: Lower output clamp in VOLTS, within -10.0 to +10.0. The
            clamp can only narrow the output span, never extend it.
            Default -10.0.
        upperLimit: Upper output clamp in VOLTS, same range. Must not be
            below ``lowerLimit``: the board swaps a reversed pair silently.
            Default +10.0.
        id: Analog output channel, ``AO1``..``AO5``.
    """
    lowerLimit: float
    upperLimit: float
    id: PP_HwId


@dataclass
class PP_motorCfg:
    """Configuration parameters for a brushed-DC motor channel.

    Wire format on the host -> board path is identical to the field order
    declared here; the board forwards the relevant subset to the
    subsystem which owns the physical PWM + ADC + encoder timer.

    Attributes:
        pwm_hz: H-bridge PWM frequency in Hz, > 0. Typical 20_000 (above
            audible range). It sets the duty resolution: about 8500 steps
            at 20 kHz, and proportionally fewer as the carrier rises.
        cur_min_mA: Lower bound of the current MEASUREMENT window in mA,
            default -5000. It does NOT trip: this firmware measures the
            winding current and never cuts the drive out when the current
            leaves the window, so protect the drive with a fuse, a supply
            current limit or your own logic on the current output. The
            sense chain resolves about -5470 to +5470 mA, so a bound
            outside that span can never be reached.
        cur_max_mA: Upper bound of the same measurement window in mA,
            default +5000. Must be > ``cur_min_mA``. Same span and the same
            measurement-only caveat as ``cur_min_mA``.
        vel_conv: Velocity scale: an **empirical timer-calibration
            constant**, not a kinematic ratio. Firmware speed is
            ``omega = VEL_CONV * vel_conv / ccr`` where ``ccr`` is the
            board's input-capture period count for one encoder edge
            interval and ``VEL_CONV = 275000``; it is
            **not** ``2*pi/PPR``. Calibrate at a known no-load speed
            (see the DC-motor velocity-calibration note in the manual) and correct
            with ``vel_conv_correct = vel_conv_used *
            (omega_true / omega_reported)``.
        pos_conv: Position conversion scale, rad per encoder tick. Unlike
            ``vel_conv``, this one IS the kinematic ``2*pi/PPR`` ratio
            (position is a raw quadrature count).
        vel_tau: Velocity LPF time constant in seconds. The board applies a
            bilinear first-order LPF at ``MainSamplingFrequency`` with
            DC gain 1; ``vel_tau`` only sets settling time / noise
            rejection. Default 0.01 s.
        dutyLowerLimit: Lower clamp on the duty input, a SIGNED FRACTION
            in -1.0 to +1.0 whose sign is the direction: -1 is full
            reverse, 0 is stopped, +1 is full forward. Default -1.0. The
            drive clamps to -1..+1 again afterwards, so a wider limit does
            nothing. It is not a percentage.
        dutyUpperLimit: Upper clamp on the duty input, same signed fraction
            and range. Must be > ``dutyLowerLimit``. Default +1.0.
    """
    pwm_hz: float
    cur_min_mA: float
    cur_max_mA: float
    vel_conv: float
    pos_conv: float
    vel_tau: float
    dutyLowerLimit: float
    dutyUpperLimit: float


@dataclass
class PP_motorBlockCfg:
    """Full motor block descriptor: identifier + config + output selection.

    Attributes:
        id: Physical motor channel (``PP_HwId.MOTOR1`` or
            ``PP_HwId.MOTOR2``).
        config: Numeric configuration (see :class:`PP_motorCfg`).
        outputCount: Number of selected measurement outputs (1..3).
            Must match ``len(outputs)``.
        outputs: Ordered measurement port list, each entry is a
            :class:`papaya.enums.PP_MotorOutput`. Allowed combinations:
            any non-empty subset of {velocity, position, current}.
            ``current``-only releases the encoder peripheral for a
            standalone :class:`papaya.blocks.encoder` block on the same
            channel.
    """
    id: PP_HwId
    config: PP_motorCfg
    outputCount: int
    outputs: Sequence[PP_MotorOutput]


@dataclass
class PP_encoderCfg:
    """Configuration parameters for a standalone quadrature encoder block.

    The encoder shares its physical timer pair with the motor block on
    the same channel; the firmware enforces mutual exclusivity (see the
    encoder class docstring). Velocity is low-pass filtered on the board
    with the same bilinear LPF as :class:`PP_motorCfg`, sampled at the
    design's ``MainSamplingFrequency``.

    Attributes:
        vel_conv: Velocity scale: an **empirical timer-calibration
            constant**, not a kinematic ratio (same ``omega = VEL_CONV *
            vel_conv / ccr`` relation as :class:`PP_motorCfg`, with
            ``VEL_CONV = 275000``); it is **not** ``2*pi/PPR``.
            Independent of the motor block's ``vel_conv``. Calibrate
            this block's own value separately (see
            the DC-motor velocity-calibration note in the manual).
        pos_conv: Position scale, rad per encoder tick. This one IS the
            kinematic ``2*pi/PPR`` ratio.
        vel_tau: Velocity LPF time constant in seconds. Default 0.01 s.
    """
    vel_conv: float
    pos_conv: float
    vel_tau: float = 0.01


@dataclass
class PP_encoderBlockCfg:
    """Full encoder block descriptor: identifier + config + output selection.

    Attributes:
        id: Physical encoder channel (``PP_HwId.ENC1`` or
            ``PP_HwId.ENC2``). At deploy time the Studio validator
            grays out the channel if the matching ``DC_MOT_N`` motor
            block has velocity or position in its ``output_mode``.
        config: Numeric configuration (see :class:`PP_encoderCfg`).
        outputCount: Number of selected measurement outputs (1 or 2).
            Must match ``len(outputs)``.
        outputs: Ordered measurement port list, each entry is a
            :class:`papaya.enums.PP_EncoderOutput`. Allowed: any
            non-empty subset of {velocity, position}. Current is not
            available on an encoder peripheral (no shunt).
    """
    id: PP_HwId
    config: PP_encoderCfg
    outputCount: int
    outputs: Sequence["PP_EncoderOutput"]  # forward ref, defined in enums.py


@dataclass
class PP_SensorSpec:
    ConvConst1: float
    ConvConst2: float
    HwId: PP_HwId


@dataclass
class PP_ActuatorSpec:
    ConvConst1: float
    LowerLimit: float
    UpperLimit: float
    HwId: PP_HwId
