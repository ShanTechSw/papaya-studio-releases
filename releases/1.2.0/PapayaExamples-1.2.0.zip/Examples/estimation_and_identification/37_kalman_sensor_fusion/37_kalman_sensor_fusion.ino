/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:10
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Noisy sensor   the true level, a 1 V sine at 0.2 Hz, with 0.03 V of white
 *                     noise and a 0.5 V glitch every second or so: the fast but
 *                     noisy reading, in volts. The glitches are there for the
 *                     chi-square gate: each one drives chi2 far above the 6.63
 *                     threshold and raises outlier_flag for a few milliseconds
 *      Slow sensor    the same level seen through a first-order lag with a 0.5 Hz
 *                     corner: attenuated to 0.93 V and 22 degrees late, with only
 *                     0.01 V of noise: the slow but clean second measurement, of
 *                     the same quantity the noisy sensor reads
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe kf_estimate;
probe Linear_KF_tap;
probe akf_estimate;
probe Adaptive_KF_tap;
probe chi2;
probe outlier;

input resid_sigma;

/* Global Struct Declarations */
// Linear_KF: PP_linearKF config
float Linear_KF_F[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float Linear_KF_B[1] = {0.0f};
float Linear_KF_H[4] = {1.0f, 0.0f, 0.0f, 0.0f};
float Linear_KF_Q[4] = {0.0001f, 0.0f, 0.0f, 0.0001f};
float Linear_KF_R = 0.1f;
float Linear_KF_x[2] = {0.0f, 0.0f};
float Linear_KF_P = 1.0f;
PP_linearKF Linear_KF_config = {
  2, 2, 0,
  Linear_KF_x, Linear_KF_F, Linear_KF_H, Linear_KF_Q, Linear_KF_B,
  Linear_KF_R, Linear_KF_P
};

// Adaptive_KF: PP_adaptiveKF config
float Adaptive_KF_F[4] = {1.0f, 0.0f, 0.0f, 1.0f};
float Adaptive_KF_H[4] = {1.0f, 0.0f, 0.0f, 0.0f};
float Adaptive_KF_Q[4] = {0.0001f, 0.0f, 0.0f, 0.0001f};
float Adaptive_KF_B[1] = {0.0f};
float Adaptive_KF_x0[2] = {0.0f, 0.0f};
PP_adaptiveKF Adaptive_KF_config = {
  2, 2, 0,
  Adaptive_KF_x0, Adaptive_KF_F, Adaptive_KF_H, Adaptive_KF_Q, Adaptive_KF_B,
  0.1f /* R_init */, 1.0f /* P_init */, 0.98f
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  resid_sigma = input("resid_sigma", 0.05f);
  analogIn Noisy_sensor = analogIn(AIN1, 1.0, 0.0);
  analogIn Slow_sensor = analogIn(AIN2, 1.0, 0.0);
  expander fan_3 = expander(3);
  expander fan_2 = expander(2);
  linearKF Linear_KF = linearKF(&Linear_KF_config);
  adaptiveKF Adaptive_KF = adaptiveKF(&Adaptive_KF_config);
  node residual = node("[1.0 -1.0]", "[1.0]", Sum);
  innovationChi2 Chi_square_gate = innovationChi2(1, 6.63);
  kf_estimate = probe("state_estimate");
  Linear_KF_tap = probe("Linear KF_o1");
  akf_estimate = probe("adaptive_estima");
  Adaptive_KF_tap = probe("Adaptive KF_o1");
  chi2 = probe("chi2");
  outlier = probe("outlier_flag");

  /* Connect Blocks */
  resid_sigma > Chi_square_gate.in(1);
  Noisy_sensor > fan_3;
  Slow_sensor > fan_2;
  fan_3.out(0) > Linear_KF.in(0);
  fan_3.out(1) > Adaptive_KF.in(0);
  fan_3.out(2) > residual.in(0);
  fan_2.out(0) > Linear_KF.in(1);
  fan_2.out(1) > Adaptive_KF.in(1);
  Linear_KF.out(0) > residual.in(1);
  Linear_KF.out(0) > kf_estimate;
  Linear_KF.out(1) > Linear_KF_tap;
  Adaptive_KF.out(0) > akf_estimate;
  Adaptive_KF.out(1) > Adaptive_KF_tap;
  residual > Chi_square_gate.in(0);
  Chi_square_gate.out(0) > chi2;
  Chi_square_gate.out(1) > outlier;

  /* Enable Remote Input Control */
  resid_sigma.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    kf_estimate.show();
    Linear_KF_tap.show();
    akf_estimate.show();
    Adaptive_KF_tap.show();
    chi2.show();
    outlier.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}