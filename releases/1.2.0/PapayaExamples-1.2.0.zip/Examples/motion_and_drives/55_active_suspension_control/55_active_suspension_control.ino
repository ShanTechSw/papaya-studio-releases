/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe body_travel;
probe passive_travel;
probe active_comfort;
probe passive_comfort;

input lqr_ref;
input ctrl_mode;
input force_min;
input force_max;

/* Global Struct Declarations */
// Configuration for SIM__quarter_car
static float SIM__quarter_car_A_data[4] = {0.0f, 1.0f, -0.996988614398f, 1.99693185139f};
static float SIM__quarter_car_B_data[2] = {0.0f, 1.0f};
static float SIM__quarter_car_C_data[2] = {5.67630124026e-05f, 0.0f};
static float SIM__quarter_car_D_data[1] = {0.0f};
static float SIM__quarter_car_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__quarter_car_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__quarter_car_A_data,
  .B_data = SIM__quarter_car_B_data,
  .C_data = SIM__quarter_car_C_data,
  .D_data = SIM__quarter_car_D_data,
  .x_init = SIM__quarter_car_x_init
};

// Configuration for SIM__passive_car
static float SIM__passive_car_A_data[4] = {0.0f, 1.0f, -0.996988614398f, 1.99693185139f};
static float SIM__passive_car_B_data[2] = {0.0f, 1.0f};
static float SIM__passive_car_C_data[2] = {5.67630124026e-05f, 0.0f};
static float SIM__passive_car_D_data[1] = {0.0f};
static float SIM__passive_car_x_init[2] = {0.0f, 0.0f};
PP_stateSpace SIM__passive_car_config = {
  .n = 2,
  .m = 1,
  .p = 1,
  .A_data = SIM__passive_car_A_data,
  .B_data = SIM__passive_car_B_data,
  .C_data = SIM__passive_car_C_data,
  .D_data = SIM__passive_car_D_data,
  .x_init = SIM__passive_car_x_init
};


/* Global Array Declarations */
float LQR_optimal_K[] = {20.0f, 3.0f, 0.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  lqr_ref = input("lqr_ref", 0.0f);
  ctrl_mode = input("ctrl_mode", 0.0f);
  force_min = input("force_min", -10.0f);
  force_max = input("force_max", 10.0f);
  signalSource SIM__road_profile = signalSource::multisine(1.0f, 1.0f, 6, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.05f);
  expander fan_2 = expander(2);
  node road___actuator = node("[1.0 1.0]", "[1.0]", Sum);
  stateSpace SIM__quarter_car = stateSpace(&SIM__quarter_car_config);
  expander fan_3 = expander(3);
  derivative body_velocity = derivative(0.01);
  expander fan_3_2 = expander(3);
  lqrServo LQR_optimal = lqrServo(2, 1, 1, LQR_optimal_K, 10.0);
  gain skyhook_damper = gain(-2.5);
  switchBlock control_mode = switchBlock();
  sat actuator_limit = sat();
  stateSpace SIM__passive_car = stateSpace(&SIM__passive_car_config);
  rootMeanSquare ride_comfort_RMS = rootMeanSquare(255);
  rootMeanSquare passive_RMS = rootMeanSquare(255);
  body_travel = probe("body_travel_m");
  passive_travel = probe("passive_travel");
  active_comfort = probe("active_comfort");
  passive_comfort = probe("passive_comfort");

  /* Connect Blocks */
  lqr_ref > LQR_optimal.in(2);
  ctrl_mode > control_mode.in(0);
  force_min > actuator_limit.in(1);
  force_max > actuator_limit.in(0);
  SIM__road_profile > fan_2;
  fan_2.out(0) > road___actuator.in(0);
  fan_2.out(1) > SIM__passive_car;
  road___actuator > SIM__quarter_car;
  SIM__quarter_car > fan_3;
  SIM__quarter_car > body_travel;
  fan_3.out(0) > body_velocity;
  fan_3.out(1) > LQR_optimal.in(0);
  fan_3.out(2) > ride_comfort_RMS;
  body_velocity > fan_3_2;
  fan_3_2.out(1) > LQR_optimal.in(1);
  fan_3_2.out(2) > LQR_optimal.in(3);
  fan_3_2.out(0) > skyhook_damper;
  LQR_optimal > control_mode.in(2);
  skyhook_damper > control_mode.in(1);
  control_mode > actuator_limit.in(2);
  actuator_limit > road___actuator.in(1);
  SIM__passive_car > passive_RMS;
  SIM__passive_car > passive_travel;
  ride_comfort_RMS > active_comfort;
  passive_RMS > passive_comfort;

  /* Enable Remote Input Control */
  lqr_ref.enableRemote();
  ctrl_mode.enableRemote();
  force_min.enableRemote();
  force_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    body_travel.show();
    passive_travel.show();
    active_comfort.show();
    passive_comfort.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}