var struct_p_p___fuzzy_p_i_d_config =
[
    [ "de_range", "struct_p_p___fuzzy_p_i_d_config.html#a4dd9b4320614ec11caf558b851b2c008", null ],
    [ "e_range", "struct_p_p___fuzzy_p_i_d_config.html#a357ada98f9e4ce325cc5d24f01d7cb25", null ],
    [ "Kd_base", "struct_p_p___fuzzy_p_i_d_config.html#abfa59a4e91f10cf4fb93df01312bb63b", null ],
    [ "Ki_base", "struct_p_p___fuzzy_p_i_d_config.html#a2e53f5c7e41d4db6cd61baff7500633c", null ],
    [ "Kp_base", "struct_p_p___fuzzy_p_i_d_config.html#afd744652444c759c7cc7fdcb7b6d1606", null ],
    [ "out_max", "struct_p_p___fuzzy_p_i_d_config.html#ad01f5b8c0be2b6af193abcd1c971bac9", null ],
    [ "out_min", "struct_p_p___fuzzy_p_i_d_config.html#a6d1e1a6ffc029cd9fdd661eb61f80d1b", null ],
    [ "Tau", "struct_p_p___fuzzy_p_i_d_config.html#a9568170839ecc9b6c4bfd906db74119c", null ]
];