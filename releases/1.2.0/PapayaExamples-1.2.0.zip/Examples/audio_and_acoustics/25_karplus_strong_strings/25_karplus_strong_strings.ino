/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:47
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe comb_cmp;

input pan_pos;
input gate;
input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  pan_pos = input("pan_pos", 0.0f);
  gate = input("gate", 1.0f);
  const_ = input("const", 0.0f);
  noise Pluck_burst = noise(0.0, 0.02, gaussian);
  adsr Pluck_envelope = adsr(0.001, 0.005, 0.0, 0.005);
  node Pluck_VCA = node("[1.0 1.0]", "[1.0]", Mul);
  expander fan_2 = expander(2);
  combFeedBack String_feedback = combFeedBack(200, 0.99);
  delayop Comparison_comb = delayop(150);
  combFeedForward Body_resonance = combFeedForward(100, -0.5);
  stereoPan String_pan = stereoPan();
  speaker Speaker_L = speaker(SPEAKER1);
  speaker Speaker_R = speaker(SPEAKER2);
  comb_cmp = probe("comb_compare");

  /* Connect Blocks */
  pan_pos > String_pan.in(1);
  gate > Pluck_envelope;
  const_ > Pluck_burst;
  Pluck_burst > Pluck_VCA.in(0);
  Pluck_envelope > Pluck_VCA.in(1);
  Pluck_VCA > fan_2;
  fan_2.out(0) > String_feedback;
  fan_2.out(1) > Comparison_comb;
  String_feedback > Body_resonance;
  Comparison_comb > comb_cmp;
  Body_resonance > String_pan.in(0);
  String_pan.out(0) > Speaker_L;
  String_pan.out(1) > Speaker_R;

  /* Enable Remote Input Control */
  pan_pos.enableRemote();
  gate.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    comb_cmp.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}