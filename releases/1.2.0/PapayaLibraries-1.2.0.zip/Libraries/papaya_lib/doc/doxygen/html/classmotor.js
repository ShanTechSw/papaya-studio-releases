var classmotor =
[
    [ "motor", "classmotor.html#ac377e8cfb25ed7a759ff405030ae0942", null ],
    [ "motor", "classmotor.html#abb0275d7327bf9b31ed26055920d2335", null ]
];