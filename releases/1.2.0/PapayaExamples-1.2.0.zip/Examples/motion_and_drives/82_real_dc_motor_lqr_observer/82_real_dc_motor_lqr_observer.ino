/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:12
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ref_radps;
probe omega_meas_radp;
VectorProbe x_hat_k_;

/* Global Struct Declarations */
// Configuration for DC_motor__HW_
PP_motorBlockCfg DC_motor__HW__config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 0.000961761106257f, 0.000961761106257f, 0.01f, -1.0f, 1.0f},
  1,
  {MotorVelocity, NoMotorOutput, NoMotorOutput}
};

// Configuration for SS_observer__3_state__balanced_modal_
static float SS_observer__3_state__balanced_modal__A_data[9] = {0.56788064f, -1.13233706f, 1.12734353f, 0.00443147f, 0.88271809f, 0.02194661f, -0.00392597f, 0.01952926f, 0.95940128f};
static float SS_observer__3_state__balanced_modal__B_data[6] = {0.00093658f, -0.24304749f, 0.00465891f, -0.00473154f, 0.00463837f, 0.00419181f};
static float SS_observer__3_state__balanced_modal__C_data[9] = {1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
static float SS_observer__3_state__balanced_modal__D_data[6] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
static float SS_observer__3_state__balanced_modal__x_init[3] = {0.0f, 0.0f, 0.0f};
PP_stateSpace SS_observer__3_state__balanced_modal__config = {
  .n = 3,
  .m = 2,
  .p = 3,
  .A_data = SS_observer__3_state__balanced_modal__A_data,
  .B_data = SS_observer__3_state__balanced_modal__B_data,
  .C_data = SS_observer__3_state__balanced_modal__C_data,
  .D_data = SS_observer__3_state__balanced_modal__D_data,
  .x_init = SS_observer__3_state__balanced_modal__x_init
};


/* Global Array Declarations */
float LQR_servo__n_3__p_1__K[] = {0.512246788513f, -28.4590922215f, 56.2650335459f, -310.596134025f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Speed_setpoint = signalSource::square(0.1f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.0f, /*offset=*/ 5.0f);
  lqrServo LQR_servo__n_3__p_1_ = lqrServo(3, 1, 1, LQR_servo__n_3__p_1__K, 12.0);
  expander u_fan = expander(2);
  gain block = gain(0.08333333333333333);
  motor DC_motor__HW_ = motor(&DC_motor__HW__config);
  expander y_fan = expander(3);
  stateSpace SS_observer__3_state__balanced_modal_ = stateSpace(&SS_observer__3_state__balanced_modal__config);
  ref_radps = probe("ref_omega_radps");
  omega_meas_radp = probe("omega_meas_radp");
  x_hat_k_ = VectorProbe("state_estimate");

  /* Connect Blocks */
  Speed_setpoint > LQR_servo__n_3__p_1_.in(3);
  Speed_setpoint > ref_radps;
  LQR_servo__n_3__p_1_ > u_fan;
  u_fan.out(0) > block;
  u_fan.out(1) > SS_observer__3_state__balanced_modal_.in(0);
  block > DC_motor__HW_;
  DC_motor__HW_ > y_fan;
  y_fan.out(1) > LQR_servo__n_3__p_1_.in(4);
  y_fan.out(2) > SS_observer__3_state__balanced_modal_.in(1);
  y_fan.out(0) > omega_meas_radp;
  SS_observer__3_state__balanced_modal_.out(0) > LQR_servo__n_3__p_1_.in(0);
  SS_observer__3_state__balanced_modal_.out(1) > LQR_servo__n_3__p_1_.in(1);
  SS_observer__3_state__balanced_modal_.out(2) > LQR_servo__n_3__p_1_.in(2);
  SS_observer__3_state__balanced_modal_.out(0) >> x_hat_k_;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    ref_radps.show();
    omega_meas_radp.show();
    x_hat_k_.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}