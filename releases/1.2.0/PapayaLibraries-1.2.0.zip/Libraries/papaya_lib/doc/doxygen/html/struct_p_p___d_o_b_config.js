var struct_p_p___d_o_b_config =
[
    [ "Gn_den", "struct_p_p___d_o_b_config.html#a85969c7fe6dbe05abdfcc2006c757e8f", null ],
    [ "Gn_num", "struct_p_p___d_o_b_config.html#a9bdbbfb6ee43422d29c0878fd6058105", null ],
    [ "plant_ord", "struct_p_p___d_o_b_config.html#a32d5f9992de3625e72bf89993e9b01fb", null ],
    [ "Qf_den", "struct_p_p___d_o_b_config.html#aae740d2aabc43807abb7f5b341fe5bbe", null ],
    [ "Qf_num", "struct_p_p___d_o_b_config.html#a2c70d8a110fc91dc2ab2c6b8465e48cc", null ],
    [ "qf_ord", "struct_p_p___d_o_b_config.html#ac296976a4c4ceb3cbe15dee5455c787e", null ]
];