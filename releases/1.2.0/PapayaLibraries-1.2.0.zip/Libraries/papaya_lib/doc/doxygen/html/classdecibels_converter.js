var classdecibels_converter =
[
    [ "decibelsConverter", "classdecibels_converter.html#aa4e991d4aac4deb32ef67d7694123029", null ]
];