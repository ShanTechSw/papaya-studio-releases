var classwindow_framer =
[
    [ "windowFramer", "classwindow_framer.html#ab0a2457300211e000ce4c3aafb99af30", null ]
];