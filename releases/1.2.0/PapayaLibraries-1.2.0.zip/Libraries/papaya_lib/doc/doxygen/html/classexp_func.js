var classexp_func =
[
    [ "expFunc", "classexp_func.html#a1e2bcefd4f4de7fc381586956b05fa5f", null ]
];