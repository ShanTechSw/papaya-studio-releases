/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe relay_kp;
probe relay_ki;
probe relay_kd;
probe relay_done;
probe relay_plant;
probe step_autotun1_p;
probe step_autotune_i;
probe step_autotun1_d;
probe step_autotune;
probe step_autotune1;

/* Global Struct Declarations */
// Configuration for Relay_Autotune
PP_RelayAutoTuneConfig Relay_Autotune_config = {
  .relay_amplitude = 1.0f,
  .hysteresis = 0.05f,
  .setpoint = 0.0f,
  .tuning_rule = 0,
  .min_cycles = 5
};

// Configuration for Step_Autotune
PP_StepAutoTuneConfig Step_Autotune_config = {
  .step_size = 1.0f,
  .settle_pct = 0.02f,
  .tuning_rule = 0,
  .id_method = 0
};


/* Global Array Declarations */
float RELAY_AUTOTUNE_plant_numerator[] = {1.0f};
float RELAY_AUTOTUNE_plant_denominator[] = {0.2f, 1.0f};
float STEP_AUTOTUNE_plant_numerator[] = {1.0f};
float STEP_AUTOTUNE_plant_denominator[] = {0.2f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  relayAutoTune Relay_Autotune = relayAutoTune(&Relay_Autotune_config);
  tf RELAY_AUTOTUNE_plant = tf(RELAY_AUTOTUNE_plant_numerator, 1, RELAY_AUTOTUNE_plant_denominator, 2);
  expander RELAY_AUTOTUNE_fan = expander(2);
  stepAutoTune Step_Autotune = stepAutoTune(&Step_Autotune_config);
  tf STEP_AUTOTUNE_plant = tf(STEP_AUTOTUNE_plant_numerator, 1, STEP_AUTOTUNE_plant_denominator, 2);
  expander STEP_AUTOTUNE_fan = expander(2);
  relay_kp = probe("relay_kp");
  relay_ki = probe("relay_ki");
  relay_kd = probe("relay_kd");
  relay_done = probe("relay_done");
  relay_plant = probe("relay_plant");
  step_autotun1_p = probe("step_autotun1_p");
  step_autotune_i = probe("step_autotune_i");
  step_autotun1_d = probe("step_autotun1_d");
  step_autotune = probe("step_autotune");
  step_autotune1 = probe("step_autotune1");

  /* Connect Blocks */
  Relay_Autotune.out(0) > RELAY_AUTOTUNE_plant;
  Relay_Autotune.out(1) > relay_kp;
  Relay_Autotune.out(2) > relay_ki;
  Relay_Autotune.out(3) > relay_kd;
  Relay_Autotune.out(4) > relay_done;
  RELAY_AUTOTUNE_plant > RELAY_AUTOTUNE_fan;
  RELAY_AUTOTUNE_fan.out(0) > Relay_Autotune;
  RELAY_AUTOTUNE_fan.out(1) > relay_plant;
  Step_Autotune.out(0) > STEP_AUTOTUNE_plant;
  Step_Autotune.out(1) > step_autotun1_p;
  Step_Autotune.out(2) > step_autotune_i;
  Step_Autotune.out(3) > step_autotun1_d;
  Step_Autotune.out(4) > step_autotune;
  STEP_AUTOTUNE_plant > STEP_AUTOTUNE_fan;
  STEP_AUTOTUNE_fan.out(0) > Step_Autotune;
  STEP_AUTOTUNE_fan.out(1) > step_autotune1;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    relay_kp.show();
    relay_ki.show();
    relay_kd.show();
    relay_done.show();
    relay_plant.show();
    step_autotun1_p.show();
    step_autotune_i.show();
    step_autotun1_d.show();
    step_autotune.show();
    step_autotune1.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}