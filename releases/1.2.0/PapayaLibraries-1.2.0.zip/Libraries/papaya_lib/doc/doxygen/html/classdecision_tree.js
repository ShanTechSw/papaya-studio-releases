var classdecision_tree =
[
    [ "decisionTree", "classdecision_tree.html#af02d6e6d155d43459a07f48eecffbf35", null ]
];