var classnoise =
[
    [ "noise", "classnoise.html#aa3af8da1209a54d1acd18d9b41982461", null ]
];