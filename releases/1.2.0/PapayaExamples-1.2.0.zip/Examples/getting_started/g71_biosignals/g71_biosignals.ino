/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:38:47
 *  Fs (Hz)      : 500.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe ecg_clean;
probe emg_envelope;
probe emg_mav;
probe EMG_features_tap;
probe EMG_features_tap_2;
probe EMG_features_tap_3;
probe hrv_mean_rr;
probe hrv_sdnn;
probe hrv_rmssd;
probe hrv_pnn50;
probe hrv_heart_rate;
probe eeg_delta;
probe eeg_theta;
probe eeg_alpha;
probe eeg_beta;
probe eeg_gamma;

input beat_flag;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(500.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(1.2f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 1.0f, /*offset=*/ 0.1f);
  beat_flag = input("beat_flag", 1.0f);
  expander fan_4 = expander(4);
  ecgBlRemove Baseline = ecgBlRemove(50);
  emgEnvelope EMG_envelope = emgEnvelope(5.0);
  emgHudgins EMG_features = emgHudgins(256, 0.02);
  expander physio = expander(2);
  hrvTime Heart_rate_variability = hrvTime(64);
  fft Transform = fft(256);
  fftMagResolver Magnitude = fftMagResolver(Transform);
  eegBandpower Band_power = eegBandpower(Magnitude);
  ecg_clean = probe("ecg_clean");
  emg_envelope = probe("emg_envelope");
  emg_mav = probe("emg_mav");
  EMG_features_tap = probe("EMG features_o1");
  EMG_features_tap_2 = probe("EMG features_o2");
  EMG_features_tap_3 = probe("EMG features_o3");
  hrv_mean_rr = probe("hrv_mean_rr");
  hrv_sdnn = probe("hrv_sdnn");
  hrv_rmssd = probe("hrv_rmssd");
  hrv_pnn50 = probe("hrv_pnn50");
  hrv_heart_rate = probe("hrv_heart_rate");
  eeg_delta = probe("eeg_delta");
  eeg_theta = probe("eeg_theta");
  eeg_alpha = probe("eeg_alpha");
  eeg_beta = probe("eeg_beta");
  eeg_gamma = probe("eeg_gamma");

  /* Connect Blocks */
  Source > fan_4;
  beat_flag > Heart_rate_variability.in(1);
  fan_4.out(0) > Baseline;
  fan_4.out(1) > EMG_envelope;
  fan_4.out(2) > EMG_features;
  fan_4.out(3) > physio;
  Baseline > ecg_clean;
  EMG_envelope > emg_envelope;
  EMG_features.out(0) > emg_mav;
  EMG_features.out(1) > EMG_features_tap;
  EMG_features.out(2) > EMG_features_tap_2;
  EMG_features.out(3) > EMG_features_tap_3;
  physio.out(0) > Heart_rate_variability.in(0);
  physio.out(1) > Transform;
  Heart_rate_variability.out(0) > hrv_mean_rr;
  Heart_rate_variability.out(1) > hrv_sdnn;
  Heart_rate_variability.out(2) > hrv_rmssd;
  Heart_rate_variability.out(3) > hrv_pnn50;
  Heart_rate_variability.out(4) > hrv_heart_rate;
  Transform > Magnitude;
  Magnitude > Band_power;
  Band_power.out(0) > eeg_delta;
  Band_power.out(1) > eeg_theta;
  Band_power.out(2) > eeg_alpha;
  Band_power.out(3) > eeg_beta;
  Band_power.out(4) > eeg_gamma;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    ecg_clean.show();
    emg_envelope.show();
    emg_mav.show();
    EMG_features_tap.show();
    EMG_features_tap_2.show();
    EMG_features_tap_3.show();
    hrv_mean_rr.show();
    hrv_sdnn.show();
    hrv_rmssd.show();
    hrv_pnn50.show();
    hrv_heart_rate.show();
    eeg_delta.show();
    eeg_theta.show();
    eeg_alpha.show();
    eeg_beta.show();
    eeg_gamma.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}