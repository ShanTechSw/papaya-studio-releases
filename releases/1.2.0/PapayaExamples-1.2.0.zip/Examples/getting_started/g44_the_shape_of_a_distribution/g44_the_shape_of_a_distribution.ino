/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe skew;
probe Skew_and_kurtosis_tap;
probe percentile_2;
probe hjorth_activity;
probe Hjorth_tap;
probe Hjorth_tap_2;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(4.0f, 0.0f);
  expander fan_3 = expander(3);
  skewKurt Skew_and_kurtosis = skewKurt(0);
  percentile Percentile = percentile(0.5);
  hjorth Hjorth = hjorth(128);
  skew = probe("skew");
  Skew_and_kurtosis_tap = probe("Skew and kurt_1");
  percentile_2 = probe("percentile");
  hjorth_activity = probe("hjorth_activity");
  Hjorth_tap = probe("Hjorth_o1");
  Hjorth_tap_2 = probe("Hjorth_o2");

  /* Connect Blocks */
  Source > fan_3;
  fan_3.out(0) > Skew_and_kurtosis;
  fan_3.out(1) > Percentile;
  fan_3.out(2) > Hjorth;
  Skew_and_kurtosis.out(0) > skew;
  Skew_and_kurtosis.out(1) > Skew_and_kurtosis_tap;
  Percentile > percentile_2;
  Hjorth.out(0) > hjorth_activity;
  Hjorth.out(1) > Hjorth_tap;
  Hjorth.out(2) > Hjorth_tap_2;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    skew.show();
    Skew_and_kurtosis_tap.show();
    percentile_2.show();
    hjorth_activity.show();
    Hjorth_tap.show();
    Hjorth_tap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}