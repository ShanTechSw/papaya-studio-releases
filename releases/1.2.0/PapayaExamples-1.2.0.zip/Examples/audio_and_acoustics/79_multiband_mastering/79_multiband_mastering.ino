/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 00:13:04
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe mastered_output;
probe vu_level;
probe loudness_dB;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__program_audio = signalSource::multisine(100.0f, 50.0f, 8, MultisinePhase::Schroeder, 44257, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0, /*trig_pol=*/ WaveTrigPol::Rising, /*amplitude=*/ 0.6f);
  expander fan_3 = expander(3);
  butter low_band = butter(4, 200.0, passLow);
  butterBq mid_band = butterBq(4, 200.0, 4000.0, passBand);
  butter high_band = butter(4, 4000.0, passHigh);
  compressor low_compressor = compressor(0.01, 0.1, -24.0, 3.0);
  compressor mid_compressor = compressor(0.01, 0.1, -20.0, 4.0);
  compressor high_compressor = compressor(0.01, 0.1, -18.0, 2.5);
  gain low_make_up = gain(1.4);
  gain mid_make_up = gain(1.1);
  gain high_make_up = gain(1.2);
  node band_recombine = node("[1.0 1.0 1.0]", "[1.0]", Sum);
  limiter brick_wall_limiter = limiter(0.001, 0.1, -0.3);
  expander fan_2 = expander(2);
  vuMeter VU_meter = vuMeter(0.3, 0.3);
  momentaryPower mean_square_power = momentaryPower(65);
  loudness LUFS_loudness = loudness();
  mastered_output = probe("mastered_output");
  vu_level = probe("vu_level");
  loudness_dB = probe("loudness_dB");

  /* Connect Blocks */
  SIM__program_audio > fan_3;
  fan_3.out(0) > low_band;
  fan_3.out(1) > mid_band;
  fan_3.out(2) > high_band;
  low_band > low_compressor;
  mid_band > mid_compressor;
  high_band > high_compressor;
  low_compressor > low_make_up;
  mid_compressor > mid_make_up;
  high_compressor > high_make_up;
  low_make_up > band_recombine.in(0);
  mid_make_up > band_recombine.in(1);
  high_make_up > band_recombine.in(2);
  band_recombine > brick_wall_limiter;
  brick_wall_limiter > fan_2;
  brick_wall_limiter > mastered_output;
  fan_2.out(0) > VU_meter;
  fan_2.out(1) > mean_square_power;
  VU_meter > vu_level;
  mean_square_power > LUFS_loudness;
  LUFS_loudness > loudness_dB;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    mastered_output.show();
    vu_level.show();
    loudness_dB.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}