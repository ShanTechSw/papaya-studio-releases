/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:09
 *  Fs (Hz)      : 20000.0
 *  C2D Algo     : Tustin
 *
 *  Project description:
 *    RUNNING THIS WITHOUT A BOARD
 *
 *    Every hardware block here carries a simulated model, attached and not
 *    active. Right-click the block, pick the model and activate it, and Studio
 *    replaces it on the canvas with what stands in for it, wired to the same
 *    places. Switch back and the block returns with its settings intact.
 *
 *      Accelerometer   machine vibration in g: a 0.35 g shaft fundamental at 48 Hz
 *                      (2880 rpm) with harmonics at 96 and 144 Hz, a bearing fault
 *                      ringing at 3.6 kHz struck 108 times a second with 0.8 g
 *                      peaks, and 0.05 g of broadband noise. The impacts make the
 *                      waveform spiky, which is exactly what the crest factor,
 *                      kurtosis and the other features are there to see
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe fault;
probe unused_signals;

input z_score_norm;
input env_hi;
input env_lo;

/* Global Array Declarations */
float PCA_projection_W[] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
float PCA_projection_mu[] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
uint16_t Fault_classifier_feat_idx[] = {0, 65535, 65535};
float Fault_classifier_thresh[] = {0.5f, 0.0f, 0.0f};
uint16_t Fault_classifier_left[] = {1, 65535, 65535};
uint16_t Fault_classifier_right[] = {2, 65535, 65535};
float Fault_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(20000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  z_score_norm = input("z_score_norm", 0.0f);
  env_hi = input("env_hi", 1000.0f);
  env_lo = input("env_lo", 1e-06f);
  analogIn Accelerometer = analogIn(AIN1, 1.0, 0.0);
  expander fan_20 = expander(20);
  fft FFT_1024 = fft(1024);
  zScoreNorm Z_score_norm = zScoreNorm(200000, 1e-09);
  rootMeanSquare Rms = rootMeanSquare(255);
  power Power = power(255);
  momentaryPower Momentary_Power = momentaryPower(255);
  variance Variance = variance(255);
  standardDeviation Std_Dev = standardDeviation(255);
  skewKurt Skew_Kurt = skewKurt(255);
  crestFactor Crest_Factor = crestFactor(255);
  maximum Maximum = maximum(255);
  minimum Minimum = minimum(255);
  absMax Abs_Max = absMax(255);
  absMin Abs_Min = absMin(255);
  peakToPeak Peak_To_Peak = peakToPeak(255);
  maxObserver Max_Observer = maxObserver(255);
  minObserver Min_Observer = minObserver(255);
  percentile Percentile = percentile(0.5);
  zcr Zcr = zcr(255, 0.0);
  expander fan_2 = expander(2);
  absVal rectify = absVal();
  fftMagResolver Magnitude = fftMagResolver(FFT_1024);
  hjorth Hjorth = hjorth(255);
  autocorrLags Autocorr_Lags = autocorrLags(256, 64, 32);
  sat keep_positive = sat();
  spectralFeatures Spectral_features = spectralFeatures(Magnitude);
  gain scale_to_1_length = gain(0.1);
  entropy Log_energy = entropy(10);
  pcaProject PCA_projection = pcaProject(19, 2, PCA_projection_W, PCA_projection_mu);
  decisionTree Fault_classifier = decisionTree(2, 2, 3, Fault_classifier_feat_idx, Fault_classifier_thresh, Fault_classifier_left, Fault_classifier_right, Fault_classifier_leaf_val);
  merger unused_bus = merger(11);
  fault = probe("fault_class");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  z_score_norm > Z_score_norm.in(1);
  env_hi > keep_positive.in(0);
  env_lo > keep_positive.in(1);
  Accelerometer > fan_20;
  fan_20.out(0) > FFT_1024;
  fan_20.out(1) > Z_score_norm.in(0);
  fan_20.out(2) > Rms;
  fan_20.out(3) > Power;
  fan_20.out(4) > Momentary_Power;
  fan_20.out(5) > Variance;
  fan_20.out(6) > Std_Dev;
  fan_20.out(7) > Skew_Kurt;
  fan_20.out(9) > Crest_Factor;
  fan_20.out(10) > Maximum;
  fan_20.out(11) > Minimum;
  fan_20.out(12) > Abs_Max;
  fan_20.out(13) > Abs_Min;
  fan_20.out(14) > Peak_To_Peak;
  fan_20.out(15) > Max_Observer;
  fan_20.out(16) > Min_Observer;
  fan_20.out(17) > Percentile;
  fan_20.out(18) > Zcr;
  fan_20.out(19) > fan_2;
  fan_20.out(8) > rectify;
  FFT_1024 > Magnitude;
  Z_score_norm > PCA_projection.in(0);
  Rms > PCA_projection.in(1);
  Power > PCA_projection.in(2);
  Momentary_Power > PCA_projection.in(3);
  Variance > PCA_projection.in(4);
  Std_Dev > PCA_projection.in(5);
  Skew_Kurt.out(0) > PCA_projection.in(6);
  Skew_Kurt.out(1) > unused_bus.in(7);
  Crest_Factor > PCA_projection.in(8);
  Maximum > PCA_projection.in(9);
  Minimum > PCA_projection.in(10);
  Abs_Max > PCA_projection.in(11);
  Abs_Min > PCA_projection.in(12);
  Peak_To_Peak > PCA_projection.in(13);
  Max_Observer > PCA_projection.in(14);
  Min_Observer > PCA_projection.in(15);
  Percentile > PCA_projection.in(16);
  Zcr > PCA_projection.in(17);
  fan_2.out(0) > Hjorth;
  fan_2.out(1) > Autocorr_Lags;
  rectify > keep_positive.in(2);
  Magnitude > Spectral_features;
  Hjorth.out(0) > PCA_projection.in(18);
  Hjorth.out(1) > unused_bus.in(8);
  Hjorth.out(2) > unused_bus.in(9);
  keep_positive > scale_to_1_length;
  Spectral_features.out(0) > unused_bus.in(0);
  Spectral_features.out(1) > unused_bus.in(1);
  Spectral_features.out(2) > unused_bus.in(2);
  Spectral_features.out(3) > unused_bus.in(3);
  Spectral_features.out(4) > unused_bus.in(4);
  Spectral_features.out(5) > unused_bus.in(5);
  Spectral_features.out(6) > unused_bus.in(6);
  scale_to_1_length > Log_energy;
  Log_energy > PCA_projection.in(7);
  PCA_projection.out(0) > Fault_classifier.in(0);
  PCA_projection.out(1) > Fault_classifier.in(1);
  Fault_classifier.out(0) > unused_bus.in(10);
  Fault_classifier.out(1) > fault;
  unused_bus > unused_signals;

  /* Enable Remote Input Control */
  z_score_norm.enableRemote();
  env_hi.enableRemote();
  env_lo.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    fault.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}