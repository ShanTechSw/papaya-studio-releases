var struct_p_p___capture_status =
[
    [ "capturedSamples", "struct_p_p___capture_status.html#af0f8a7a62c46e4e08d1219130322c163", null ],
    [ "complete", "struct_p_p___capture_status.html#a113f5b06d7442c7a0d86fbb05c922669", null ],
    [ "requestedSamples", "struct_p_p___capture_status.html#ab6dc4a6c19443f993063e368be365528", null ]
];