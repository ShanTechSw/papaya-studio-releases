/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-22 19:58:05
 *  Fs (Hz)      : 44100.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

VectorProbe spectrum_mag;
probe centroid;
probe flatness;
probe rolloff;
probe unused_signals;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(44100.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource SIM__Mic_input = signalSource::chirpLinear(200.0f, 8000.0f, 2.0f, 0.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  expander fan_3 = expander(3);
  windowFramer Window_framer = windowFramer(1024, 256);
  stftFramer STFT_framer = stftFramer(1024, 256, 0);
  fft FFT_1024 = fft(1024);
  fftMagResolver Magnitude = fftMagResolver(FFT_1024);
  spectralFeatures Spectral_features = spectralFeatures(Magnitude);
  merger unused_bus = merger(9);
  spectrum_mag = VectorProbe("spectrum_mag");
  centroid = probe("centroid");
  flatness = probe("flatness");
  rolloff = probe("rolloff");
  unused_signals = probe("unused_signals");

  /* Connect Blocks */
  SIM__Mic_input > fan_3;
  fan_3.out(0) > Window_framer;
  fan_3.out(1) > STFT_framer;
  fan_3.out(2) > FFT_1024;
  Window_framer > unused_bus.in(0);
  STFT_framer > unused_bus.in(8);
  FFT_1024 > Magnitude;
  Magnitude > Spectral_features;
  Magnitude >> spectrum_mag;
  Spectral_features.out(0) > unused_bus.in(1);
  Spectral_features.out(1) > unused_bus.in(2);
  Spectral_features.out(2) > unused_bus.in(3);
  Spectral_features.out(3) > unused_bus.in(4);
  Spectral_features.out(4) > unused_bus.in(5);
  Spectral_features.out(5) > unused_bus.in(6);
  Spectral_features.out(6) > unused_bus.in(7);
  Spectral_features.out(0) > centroid;
  Spectral_features.out(4) > flatness;
  Spectral_features.out(5) > rolloff;
  unused_bus > unused_signals;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    spectrum_mag.show();
    centroid.show();
    flatness.show();
    rolloff.show();
    unused_signals.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}