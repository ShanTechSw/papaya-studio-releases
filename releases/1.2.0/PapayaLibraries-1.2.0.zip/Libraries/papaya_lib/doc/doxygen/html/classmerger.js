var classmerger =
[
    [ "merger", "classmerger.html#a862a6e1287e9aa31060ccf9e7f3eb10c", null ]
];