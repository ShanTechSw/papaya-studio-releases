r"""
Local crash reporter.

Frozen-mode only: dev runs (`python main.py`) want raw tracebacks
straight to stderr. In the frozen bundle, an uncaught exception is
captured to a file under %LOCALAPPDATA%\Papaya Studio\crashes\ along
with environment info, the last ~200 lines of structured log, and any
detected board UID. A non-modal Qt dialog tells the user the path and
offers "Open log" / "Copy path" / "Close". No data leaves the machine.

Per decision #22 in project_studio_packaging_decisions.
"""

from __future__ import annotations

import datetime as dt
import platform
import sys
import traceback
from pathlib import Path

from . import _app_paths
from ._no_console import no_window


def _read_last_lines(path: Path, n: int = 200) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    lines = text.splitlines()
    return "\n".join(lines[-n:])


def _capture(exc_type, exc, tb) -> Path:
    """Write the crash dump file. Returns the dump path."""
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dump_path = _app_paths.crashes_dir() / f"crash_{timestamp}.txt"

    # Studio version / build metadata (best-effort)
    try:
        from . import _version
        version = _version.__version__
    except Exception:
        version = "?"
    try:
        from . import _build_metadata as bm
        build_date = getattr(bm, "BUILD_DATE", "") or "(dev)"
        builder = getattr(bm, "BUILD_BUILDER", "") or "(dev)"
        fw = getattr(bm, "FIRMWARE_COMMITS", {}) or {}
    except Exception:
        build_date = builder = "?"
        fw = {}

    # Qt version (optional: may not be importable in some failure modes)
    try:
        from PyQt6.QtCore import QT_VERSION_STR
        qt_version = QT_VERSION_STR
    except Exception:
        qt_version = "?"

    # Last log lines
    log_path = _app_paths.logs_dir() / "studio.log"
    last_log = _read_last_lines(log_path, 200)

    parts = [
        "PAPAYA Studio crash report",
        "=" * 60,
        f"Timestamp:    {timestamp}",
        f"Studio:       {version}",
        f"Build date:   {build_date}",
        f"Builder:      {builder}",
        f"Firmware:     " + ", ".join(f"{k}={v or '-'}" for k, v in fw.items()),
        f"Python:       {platform.python_version()}",
        f"Qt:           {qt_version}",
        f"Platform:     {platform.platform()}",
        f"Frozen:       {bool(getattr(sys, 'frozen', False))}",
        "",
        "Traceback:",
        "-" * 60,
        "".join(traceback.format_exception(exc_type, exc, tb)),
        "",
        "Last log lines:",
        "-" * 60,
        last_log or "(no log file)",
    ]
    try:
        dump_path.write_text("\n".join(parts), encoding="utf-8")
    except OSError:
        pass
    return dump_path


def _show_dialog(dump_path: Path) -> None:
    """Show a non-modal crash notification. Imports Qt lazily."""
    try:
        from PyQt6.QtWidgets import (
            QApplication, QMessageBox, QPushButton,
        )
    except Exception:
        sys.stderr.write(f"[CRASH] Dump written to {dump_path}\n")
        return

    app = QApplication.instance()
    if app is None:
        sys.stderr.write(f"[CRASH] Dump written to {dump_path}\n")
        return

    box = QMessageBox()
    box.setWindowTitle("PAPAYA Studio · Unexpected error")
    box.setIcon(QMessageBox.Icon.Critical)
    box.setText(
        "PAPAYA Studio encountered an unexpected error.\n\n"
        "A crash log has been written. Nothing was sent over the network. "
        "You can email it to support if you'd like help."
    )
    box.setInformativeText(f"Log: {dump_path}")
    open_btn = box.addButton("Open log", QMessageBox.ButtonRole.ActionRole)
    copy_btn = box.addButton("Copy path", QMessageBox.ButtonRole.ActionRole)
    box.addButton(QMessageBox.StandardButton.Close)
    box.exec()

    clicked = box.clickedButton()
    if clicked is open_btn:
        try:
            import os
            import subprocess
            import sys as _sys
            if os.name == "nt":
                os.startfile(str(dump_path))  # type: ignore[attr-defined]
            elif _sys.platform == "darwin":
                subprocess.Popen(["open", str(dump_path)], **no_window())
            else:
                subprocess.Popen(["xdg-open", str(dump_path)], **no_window())
        except Exception:
            pass
    elif clicked is copy_btn:
        QApplication.clipboard().setText(str(dump_path))


def install() -> None:
    """Install a `sys.excepthook` that captures + reports + re-raises.

    Frozen mode only: dev runs want raw stderr tracebacks.
    Idempotent (no-op if already installed).
    """
    if not getattr(sys, "frozen", False):
        return
    if getattr(install, "_installed", False):  # type: ignore[attr-defined]
        return

    _previous = sys.excepthook

    def _hook(exc_type, exc, tb):
        try:
            dump = _capture(exc_type, exc, tb)
        except Exception:
            dump = None
        # Chain to the previous hook (prints to stderr) so the app's
        # stdout/stderr capture still records the failure.
        try:
            _previous(exc_type, exc, tb)
        except Exception:
            pass
        if dump is not None:
            try:
                _show_dialog(dump)
            except Exception:
                pass

    sys.excepthook = _hook
    install._installed = True  # type: ignore[attr-defined]
