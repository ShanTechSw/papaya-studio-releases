var files_dup =
[
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", null ],
    [ "ports", "dir_01538ad46ba247002bef53366126b333.html", "dir_01538ad46ba247002bef53366126b333" ],
    [ "PAPAYA.cpp", "_p_a_p_a_y_a_8cpp.html", "_p_a_p_a_y_a_8cpp" ],
    [ "PAPAYA.h", "_p_a_p_a_y_a_8h.html", "_p_a_p_a_y_a_8h" ],
    [ "papaya_entrypoint.cpp", "papaya__entrypoint_8cpp.html", "papaya__entrypoint_8cpp" ],
    [ "papaya_transport_api.h", "papaya__transport__api_8h.html", "papaya__transport__api_8h" ]
];