var class_papaya_linux_spidev_backend =
[
    [ "PapayaLinuxSpidevBackend", "class_papaya_linux_spidev_backend.html#a8bf2f636c6abe5291735efe4d32c43d6", null ],
    [ "~PapayaLinuxSpidevBackend", "class_papaya_linux_spidev_backend.html#a3b768634ba93283855a12a92aa54d33b", null ],
    [ "applySettings", "class_papaya_linux_spidev_backend.html#a2760bca169db19169b5e4ec3a6b21d67", null ],
    [ "begin", "class_papaya_linux_spidev_backend.html#a4a31717c964e6497f3cbfe37b7688c14", null ],
    [ "device", "class_papaya_linux_spidev_backend.html#a240c8c783e1a6084c58cd428375810e7", null ],
    [ "disableKernelChipSelect", "class_papaya_linux_spidev_backend.html#a0529e67b48d03bcc1b99d53071ccca14", null ],
    [ "end", "class_papaya_linux_spidev_backend.html#a1dfeca48b47644e6b2d890571ece1a70", null ],
    [ "ensureOpen", "class_papaya_linux_spidev_backend.html#a1f876c339ab81e38724396c990a0e348", null ],
    [ "isOpen", "class_papaya_linux_spidev_backend.html#a9e5c32599376bf951403b34b0ca0f105", null ],
    [ "setDevice", "class_papaya_linux_spidev_backend.html#aec3a3fdb69eb8bd583719e59bd7b1f7c", null ],
    [ "setDisableKernelChipSelect", "class_papaya_linux_spidev_backend.html#a90292c4a525863b2ebc9afc0a3519cdc", null ],
    [ "transfer", "class_papaya_linux_spidev_backend.html#a72ec2f47b5473d0b53a71579e201f04a", null ],
    [ "_devicePath", "class_papaya_linux_spidev_backend.html#af034ae8a9be9168be88b453a0b3eb998", null ],
    [ "_disableKernelChipSelect", "class_papaya_linux_spidev_backend.html#a01f6aae34d0eab10c26fdac602cdbb74", null ],
    [ "_fd", "class_papaya_linux_spidev_backend.html#acc1ae3826e07d4d98b8ab2f4f3a4f88e", null ]
];