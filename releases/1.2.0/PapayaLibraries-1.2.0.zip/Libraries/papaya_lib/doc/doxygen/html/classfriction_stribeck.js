var classfriction_stribeck =
[
    [ "frictionStribeck", "classfriction_stribeck.html#ac18af607384fa3bc3c0777d8a76e479f", null ]
];