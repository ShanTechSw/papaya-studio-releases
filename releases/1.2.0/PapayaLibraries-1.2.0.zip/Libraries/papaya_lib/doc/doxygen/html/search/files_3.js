var searchData=
[
  ['spi_2ecpp_0',['SPI.cpp',['../host__arduino__compat_2src_2_s_p_i_8cpp.html',1,'(Global Namespace)'],['../stm32cubeide__hal_2src_2_s_p_i_8cpp.html',1,'(Global Namespace)']]],
  ['spi_2eh_1',['SPI.h',['../host__arduino__compat_2include_2_s_p_i_8h.html',1,'(Global Namespace)'],['../stm32cubeide__hal_2include_2_s_p_i_8h.html',1,'(Global Namespace)']]]
];
