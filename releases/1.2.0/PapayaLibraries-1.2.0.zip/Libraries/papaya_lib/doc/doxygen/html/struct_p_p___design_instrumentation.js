var struct_p_p___design_instrumentation =
[
    [ "appMemFreeBytes", "struct_p_p___design_instrumentation.html#aa34326e3321f4ffc587cbcd1293057c7", null ],
    [ "appMemHighWatermark", "struct_p_p___design_instrumentation.html#a98cdb9ead386b0c791e4477d688ca766", null ],
    [ "appMemTotalBytes", "struct_p_p___design_instrumentation.html#aa843f7aac962f3db4df2473e55cc965f", null ],
    [ "appMemUsedBytes", "struct_p_p___design_instrumentation.html#a592135bdcea22b10b5178a63c1a810ab", null ],
    [ "appMemUsedPct", "struct_p_p___design_instrumentation.html#a56ec546722998a6b4e7debf6ab90cbcd", null ],
    [ "cpuCycleUs", "struct_p_p___design_instrumentation.html#a503ded8385045914284cb84eb8c15ec8", null ],
    [ "cpuLoadPctX100", "struct_p_p___design_instrumentation.html#a766b545f6900ac4f0eaca3e0e97befb7", null ],
    [ "periodUs", "struct_p_p___design_instrumentation.html#a5cab8abb658481896fe52cd0d935e451", null ]
];