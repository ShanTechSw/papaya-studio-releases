var struct_p_p__state_space =
[
    [ "A_data", "struct_p_p__state_space.html#aee4da02206351f6e38f0882f5862174a", null ],
    [ "B_data", "struct_p_p__state_space.html#ab5618411321e583524b8ca7c2af0bba3", null ],
    [ "C_data", "struct_p_p__state_space.html#ac6999990640feae69cde3468975e02d5", null ],
    [ "D_data", "struct_p_p__state_space.html#abb2e5d935441ce7a79bbd7b97bf54edf", null ],
    [ "m", "struct_p_p__state_space.html#a392b661e6800366e433b7c5cea38bd88", null ],
    [ "n", "struct_p_p__state_space.html#a80f9fab5ee47502a0117603632a8c655", null ],
    [ "p", "struct_p_p__state_space.html#a3c3cc843d2ec88f183c8b003381fdee5", null ],
    [ "x_init", "struct_p_p__state_space.html#aee3373a186dcc58bb5169a8918571068", null ]
];