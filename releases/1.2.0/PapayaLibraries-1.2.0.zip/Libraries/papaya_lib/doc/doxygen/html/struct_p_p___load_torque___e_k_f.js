var struct_p_p___load_torque___e_k_f =
[
    [ "B", "struct_p_p___load_torque___e_k_f.html#ac9b18cfbfb9124496d0ddb549e8ccb4f", null ],
    [ "J", "struct_p_p___load_torque___e_k_f.html#aa3da6674da3d6737213e539d647d5058", null ],
    [ "P_init", "struct_p_p___load_torque___e_k_f.html#a7a80df51f22ae272305e4a567f1fe7fd", null ],
    [ "Q_data", "struct_p_p___load_torque___e_k_f.html#ac44d4e6444f76f60aeb9bdec697673c1", null ],
    [ "R_data", "struct_p_p___load_torque___e_k_f.html#ad9c0333832d2879cd5219103aaad67ed", null ],
    [ "x_init", "struct_p_p___load_torque___e_k_f.html#aded342647cf2b87f60c7f20fff597fab", null ]
];