"""The relay engine: link frames in, board conversation out.

Pure logic. It owns no socket, no thread and no timer, so the whole of a
gateway's behaviour -- including the failure paths that are hard to
provoke on real hardware -- is reachable from a test with a fake board.
A transport wrapper feeds it frames and sends what it returns.

What it knows, and what it refuses to know
------------------------------------------
It performs five transaction shapes on the board's wire and parses **no
opcodes at all**. The far end composed the command and knows what it
means; the gateway knows only how a command of that shape is carried.
That is what stops a relay having to keep up with firmware it does not
model, and it is worth defending: the moment this file contains a list of
opcodes, every firmware change becomes a gateway change too.

The rules it exists to enforce
------------------------------
**A command may never be abandoned partway.** The board has no
inter-frame timeout. A body that stops arriving leaves its receive state
machine waiting forever, and nothing short of a reset clears it. So when a
command cannot be completed -- the link died, a chunk arrived out of
order, a new command barged in -- the gateway sends the chunks the header
declared anyway, as filler. The board then completes its receive, fails
the body checksum, and answers an error. An error is recoverable; a wedged
state machine is not.

**One chunk at a time.** Nothing here ever holds more than one body chunk,
whatever the size of the command passing through. That is what makes a
32 KB host viable, and it is why the link splits commands rather than
handing over whole ones.

**Some commands must never be sent.** Two opcodes are refused by value,
and this is the one place opcode knowledge is admitted, precisely because
both would damage the link rather than merely fail:

* the flow-credit opcode, whose firmware handler reads from the USB
  endpoint and is meaningless on SPI;
* the deprecated live-rate opcode, which the board rejects unconditionally
  **and latches**, so it breaks whatever the gateway does next rather than
  just itself.

**Mode changes and resets are performed, not relayed.** A lost mode byte
leaves the board streaming into an endpoint nobody drains. The gateway
runs those sequences locally, in the order the firmware requires, and
reports what happened.

**Telemetry is a pull turned into a push.** The Monitor expects samples
to arrive; the board on SPI answers only when asked. So a subscription
puts the gateway on a schedule, and :meth:`Gateway.poll_telemetry` is one
tick of it -- still no timer here, because the caller owns the clock and
passes the time in, which is also what makes a dropped batch reproducible
in a test rather than a thing you wait for.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import List, Optional, Protocol

from .protocol import (
    BOARD_CHUNK_SIZE, CommandOutcome, LinkFrame, MessageType, TransactionShape,
    LinkProtocolError,
    decode_command, decode_command_chunk, decode_subscribe,
    encode_command_result, encode_telemetry,
)

#: Offsets inside a command header, and the two sub-function values that
#: must never reach the wire. The only opcode knowledge here.
#:
#: THE FUNCTION ID IS PART OF THE TEST. A sub-function number means
#: nothing on its own: the board reads it together with the function id,
#: and the same number is a different command under a different function.
#: Sub-function 4 under MANAGE is the flow-credit opcode refused below;
#: sub-function 4 under CREATE is "make a hardware input", which is how
#: every analog input in every design is built. Testing the sub-function
#: alone ate that creation, so a design containing a hardware input could
#: not be uploaded over the link at all.
_FUNC_OFFSET = 0x07
_FUNC_MANAGE = 0x02
_SUBFUNC_OFFSET = 0x08
#: The read/write field, where the board's protocol puts a bare opcode.
_READ_WRITE_OFFSET = 0x02
_OPCODE_FLOW_CREDIT = 0x04
_OPCODE_SET_LIVE_RATE = 0x201A

#: The board's status frame.
_STATUS_SIZE = 7

#: Slack, in slots, when counting how many polls a schedule has gone past.
#: See the note where it is used: it exists to survive floating-point slop
#: in a monotonic clock, not to tolerate lateness.
_SLOT_EPSILON = 1e-6


class BoardPort(Protocol):
    """The board's wire, as the relay needs it.

    Deliberately shaped as transactions rather than bytes: on SPI the
    master frames every exchange with chip-select, so "write some bytes"
    is not a meaningful request. Each method below is one or more
    chip-select pulses with a known shape.
    """

    def begin_command(self, header: bytes) -> None: ...
    def send_body_chunk(self, chunk: bytes) -> None: ...
    def await_status(self) -> Optional[bytes]: ...
    def read_data_payload(self, length: int) -> Optional[bytes]: ...
    def read_probes(self, length: int, vector: bool = False) -> Optional[bytes]: ...
    def write_inputs(self, values: bytes) -> bool: ...
    def reset(self) -> bool: ...


@dataclass
class _PendingCommand:
    """A command whose body has not all arrived yet."""

    shape: TransactionShape
    total_body: int
    expected_data: int
    received: int = 0
    next_index: int = 1

    @property
    def outstanding(self) -> int:
        return max(0, self.total_body - self.received)


@dataclass
class _Subscription:
    """A standing instruction to poll the board's probes.

    Every number here came over the link, because nothing on the board's
    wire announces any of them: a probe read is an opcode followed by a
    payload with no length, no count and no boundary.
    """

    probe_count: int
    samples_per_batch: int
    scalar_bytes: int
    vector_count: int
    vector_bytes: int
    interval_s: float
    batch_seq: int = 0
    #: None until the first poll, which is due immediately. Absolute, in
    #: the caller's clock, because the caller owns the clock.
    next_due: Optional[float] = None


class Gateway:
    """Relays one board for one client."""

    def __init__(self, board: BoardPort) -> None:
        self._board = board
        self._pending: Optional[_PendingCommand] = None
        self._telemetry: Optional[_Subscription] = None
        #: Counted rather than merely logged: a rising number is the
        #: symptom that distinguishes a bad radio from a bad cable.
        self.flushed_commands = 0
        self.refused_commands = 0
        #: Batches whose slot went by without one being produced. The far
        #: end learns the same thing from the gap in ``batch_seq``; this
        #: is for whoever is diagnosing the gateway itself.
        self.dropped_batches = 0

    # -- entry point ---------------------------------------------------

    def handle(self, frame: LinkFrame) -> List[LinkFrame]:
        """Process one inbound frame and return what to send back."""
        if frame.type is MessageType.CMD:
            return self._on_command(frame)
        if frame.type is MessageType.CMD_CHUNK:
            return self._on_chunk(frame)
        if frame.type is MessageType.RESET:
            return self._on_reset(frame)
        if frame.type is MessageType.SUBSCRIBE:
            return self._on_subscribe(frame)
        if frame.type is MessageType.UNSUBSCRIBE:
            self._telemetry = None
            return [self._result(frame.seq, CommandOutcome.ANSWERED)]
        if frame.type is MessageType.PING:
            return [LinkFrame(type=MessageType.PONG, payload=frame.payload,
                              seq=frame.seq)]
        if frame.type is MessageType.BYE:
            self._flush_pending()
            # The subscriber is gone. Polling a board on behalf of nobody
            # spends the wire the next client will want, and the batches
            # would have nowhere to go.
            self._telemetry = None
            return []
        # Unknown-but-intact frames are the far end's business, not ours.
        return []

    # -- commands ------------------------------------------------------

    def _on_command(self, frame: LinkFrame) -> List[LinkFrame]:
        # A command arriving while another is half-sent means the far end
        # gave up on the first. Finish it before starting anything, or the
        # board is left mid-receive and the new command's header is read
        # as body bytes.
        self._flush_pending()

        try:
            shape, header, first, total_body, expected_data = decode_command(
                frame.payload)
        except LinkProtocolError as exc:
            return self._refuse(frame.seq, str(exc))

        refusal = self._refusal_reason(header)
        if refusal is not None:
            return self._refuse(frame.seq, refusal)

        if shape is TransactionShape.OPCODE_ONLY:
            # The opcode is in the header's read/write field, exactly
            # where PROBE_READ reads its own from. Nothing else about the
            # header reaches the wire.
            opcode = (header[_READ_WRITE_OFFSET]
                      if len(header) > _READ_WRITE_OFFSET else 0)
            ok = self._board.send_opcode(opcode)
            return [self._result(
                frame.seq,
                CommandOutcome.ANSWERED if ok else CommandOutcome.NO_ANSWER)]

        if shape in (TransactionShape.PROBE_READ, TransactionShape.INPUT_WRITE):
            return self._sampling_shape(frame.seq, shape, header, first,
                                        expected_data)

        self._board.begin_command(header)
        if first:
            self._board.send_body_chunk(first)

        pending = _PendingCommand(shape=shape, total_body=total_body,
                                  expected_data=expected_data,
                                  received=len(first))
        if pending.outstanding:
            # More chunks to come. Nothing is buffered here: each one goes
            # straight to the wire as it arrives.
            self._pending = pending
            return []

        return self._finish(frame.seq, pending)

    def _on_chunk(self, frame: LinkFrame) -> List[LinkFrame]:
        pending = self._pending
        if pending is None:
            # No command to attach it to. Nothing has been half-sent, so
            # there is nothing to flush; just say so.
            return self._refuse(frame.seq, "a body chunk with no command")

        try:
            index, chunk = decode_command_chunk(frame.payload)
        except LinkProtocolError as exc:
            self._flush_pending()
            return self._refuse(frame.seq, str(exc))

        if index != pending.next_index:
            # Out of order. Forwarding it would produce a body whose
            # checksum fails somewhere far from the cause, so flush the
            # command out instead and let the far end retry it whole.
            self._flush_pending()
            return self._refuse(
                frame.seq,
                f"chunk {index} arrived where {pending.next_index} was due")

        if len(chunk) > pending.outstanding:
            self._flush_pending()
            return self._refuse(frame.seq, "chunk overruns the declared body")

        self._board.send_body_chunk(chunk)
        pending.received += len(chunk)
        pending.next_index += 1

        if pending.outstanding:
            return []

        self._pending = None
        return self._finish(frame.seq, pending)

    def _finish(self, seq: int, pending: _PendingCommand) -> List[LinkFrame]:
        self._pending = None

        if pending.shape is TransactionShape.FIRE_AND_FORGET:
            # No poll: the board is rebooting and will not answer. Waiting
            # would spend the deadline and then report a failure for a
            # command that did exactly what it was asked.
            return [self._result(seq, CommandOutcome.ANSWERED)]

        status = self._board.await_status()
        if status is None:
            return [self._result(seq, CommandOutcome.NO_ANSWER)]

        data = b""
        if pending.shape is TransactionShape.CONFIG_WITH_DATA:
            # Only after a good status. Reading a payload nobody queued
            # consumes the NEXT command's response, and the link is
            # desynchronised from there on.
            if _status_is_ok(status):
                data = self._board.read_data_payload(pending.expected_data) or b""

        return [self._result(seq, CommandOutcome.ANSWERED, status, data)]

    def _sampling_shape(self, seq: int, shape: TransactionShape, header: bytes,
                        payload: bytes, expected_data: int) -> List[LinkFrame]:
        """Probe reads and input writes: one opcode, one payload, no poll."""
        if shape is TransactionShape.PROBE_READ:
            length = expected_data or _length_from_header(header)
            # The opcode sits in the header's read/write field, which is
            # where the board's own protocol puts it. Reading byte zero
            # instead would find the sequence number's low half.
            vector = len(header) > _READ_WRITE_OFFSET and \
                header[_READ_WRITE_OFFSET] == 0x02
            data = self._board.read_probes(length, vector=vector)
            if data is None:
                return [self._result(seq, CommandOutcome.NO_ANSWER)]
            return [self._result(seq, CommandOutcome.ANSWERED, b"", data)]

        ok = self._board.write_inputs(payload)
        return [self._result(
            seq,
            CommandOutcome.ANSWERED if ok else CommandOutcome.NO_ANSWER)]

    # -- gateway-local operations -------------------------------------

    def _on_reset(self, frame: LinkFrame) -> List[LinkFrame]:
        # Anything half-sent is moot once the board reboots, and the flush
        # would be talking to a board that is about to disappear.
        self._pending = None
        ok = self._board.reset()
        return [LinkFrame(
            type=MessageType.CMD_RESULT,
            payload=encode_command_result(
                CommandOutcome.ANSWERED if ok else CommandOutcome.REFUSED),
            seq=frame.seq,
        )]

    # -- telemetry -----------------------------------------------------

    def _on_subscribe(self, frame: LinkFrame) -> List[LinkFrame]:
        try:
            (probes, samples, scalar_bytes, vectors, vector_bytes,
             interval_ms) = decode_subscribe(frame.payload)
        except LinkProtocolError as exc:
            return self._refuse(frame.seq, str(exc))

        # A second subscription replaces the first rather than joining
        # it. Two schedules on one wire interleave probe reads between
        # each other's poll and payload, and the payload does not say
        # which request it belongs to.
        self._telemetry = _Subscription(
            probe_count=probes, samples_per_batch=samples,
            scalar_bytes=scalar_bytes, vector_count=vectors,
            vector_bytes=vector_bytes, interval_s=interval_ms / 1000.0)
        return [self._result(frame.seq, CommandOutcome.ANSWERED)]

    @property
    def is_subscribed(self) -> bool:
        return self._telemetry is not None

    def telemetry_due_in(self, now: float) -> Optional[float]:
        """Seconds until the next poll, or None if nothing is subscribed.

        For a transport deciding how long it may block on its socket. It
        exists so the loop waits for whichever comes first, a frame or a
        batch, instead of picking one and being late for the other.
        """
        sub = self._telemetry
        if sub is None:
            return None
        if sub.next_due is None:
            return 0.0
        return max(0.0, sub.next_due - now)

    def poll_telemetry(self, now: float) -> List[LinkFrame]:
        """One tick of the schedule: read the probes, stamp, hand back.

        Returns the frames to send, which is nothing at all when no poll
        is due. ``now`` comes from the caller because the caller owns the
        clock, and because a schedule that falls behind is then something
        a test can state rather than something it has to wait for.
        """
        sub = self._telemetry
        if sub is None:
            return []
        if sub.next_due is None:
            sub.next_due = now                     # the first is due at once
        if now < sub.next_due:
            return []

        # Advance the schedule past every slot that has gone by, and the
        # batch number with it. A slot that produced nothing still spends
        # its number, which is what puts the gap in the sequence: the
        # board's own SPI monitoring carries no sequence, no checksum and
        # no gap marker, so a host handed a late batch under the next
        # consecutive number cannot tell it is looking at a hole.
        #
        # Computed rather than looped: a suspended laptop resuming hours
        # later is a legitimate arrival, and it must not spin here.
        #
        # The epsilon is not decoration. ``now`` is a monotonic clock in
        # the thousands of seconds, and subtracting two such values leaves
        # a few parts in 1e14 of slop -- enough to turn an exact three
        # slots into 2.9999999999 and lose one from the count, which is a
        # gap that never gets reported. A millionth of a slot is a
        # nanosecond here, far below anything real.
        slots = 1 + int((now - sub.next_due) / sub.interval_s + _SLOT_EPSILON)
        sub.next_due += slots * sub.interval_s
        sub.batch_seq = (sub.batch_seq + slots) & 0xFFFFFFFF
        self.dropped_batches += slots - 1

        if self._pending is not None:
            # A command's body is part-way onto the wire. A probe read
            # here is one more chip-select pulse in the middle of it, and
            # the board would take the opcode for body. Skip the batch;
            # the sequence gap already says so, and dropping the oldest
            # beats delivering stale samples as though they were fresh.
            self.dropped_batches += 1
            return []

        stamp = int(now * 1_000_000) & 0xFFFFFFFFFFFFFFFF
        frames: List[LinkFrame] = []

        if sub.scalar_bytes:
            # The length is the far end's, always. ``getProbes`` on the
            # board sizes itself from probe objects the PROGRAM built,
            # and a relay builds none, so a read with no count asks for
            # nothing and returns nothing.
            data = self._board.read_probes(sub.scalar_bytes)
            if data:
                frames.append(LinkFrame(
                    type=MessageType.TELEMETRY,
                    payload=encode_telemetry(
                        sub.batch_seq, stamp, sub.probe_count,
                        sub.samples_per_batch, data)))

        if sub.vector_bytes:
            data = self._board.read_probes(sub.vector_bytes, vector=True)
            if data:
                frames.append(LinkFrame(
                    type=MessageType.VECTOR_TELEMETRY,
                    payload=encode_telemetry(
                        sub.batch_seq, stamp, sub.vector_count, 1, data)))

        if not frames:
            # The board had nothing, which is ordinary between batches.
            # The slot is still spent, so the gap stands and the far end
            # is not told a batch arrived that did not.
            self.dropped_batches += 1
        return frames

    # -- the rules ----------------------------------------------------

    def _refusal_reason(self, header: bytes) -> Optional[str]:
        """The only place an opcode is looked at, and only these two."""
        if len(header) < _SUBFUNC_OFFSET + 2:
            return None
        # Both refusals name MANAGE sub-functions. The same number under
        # any other function is a different command and must pass.
        if header[_FUNC_OFFSET] != _FUNC_MANAGE:
            return None
        opcode = struct.unpack_from("<H", header, _SUBFUNC_OFFSET)[0]

        if opcode == _OPCODE_SET_LIVE_RATE:
            return ("the live-rate opcode is rejected by the board "
                    "unconditionally AND latches the failure, so it breaks "
                    "the next command as well as itself")
        if opcode == _OPCODE_FLOW_CREDIT:
            return ("the flow-credit opcode reads from the USB endpoint in "
                    "firmware, so on this wire it is meaningless")
        return None

    def _flush_pending(self) -> None:
        """Complete a half-sent command with filler.

        The board has no inter-frame timeout: a body that stops arriving
        leaves its receive state machine waiting forever. Sending the rest
        as zeros lets it finish, fail the body checksum, and answer an
        error -- which is recoverable, unlike a wedged state machine.
        """
        pending, self._pending = self._pending, None
        if pending is None or not pending.outstanding:
            return

        self.flushed_commands += 1
        remaining = pending.outstanding
        while remaining > 0:
            size = min(BOARD_CHUNK_SIZE, remaining)
            self._board.send_body_chunk(bytes(size))
            remaining -= size

        # Consume whatever the board answers, so the reply to this dead
        # command is not read as the reply to the next live one.
        if pending.shape is not TransactionShape.FIRE_AND_FORGET:
            self._board.await_status()

    def _refuse(self, seq: int, reason: str) -> List[LinkFrame]:
        self.refused_commands += 1
        return [
            LinkFrame(type=MessageType.EVENT, payload=reason.encode("utf-8"),
                      seq=seq),
            self._result(seq, CommandOutcome.REFUSED),
        ]

    @staticmethod
    def _result(seq: int, outcome: CommandOutcome, status: bytes = b"",
                data: bytes = b"") -> LinkFrame:
        return LinkFrame(type=MessageType.CMD_RESULT,
                         payload=encode_command_result(outcome, status, data),
                         seq=seq)


def _status_is_ok(status: bytes) -> bool:
    """Byte 2 of the status frame is the design status; 0 is success."""
    return len(status) >= 3 and status[2] == 0


def _length_from_header(header: bytes) -> int:
    """Fallback probe length, when the far end did not state one."""
    if len(header) >= 5:
        return struct.unpack_from("<H", header, 3)[0]
    return 0


__all__ = ["Gateway", "BoardPort"]
