var classstereo_pan =
[
    [ "stereoPan", "classstereo_pan.html#af9055ee865d0047ac98e2fd7b9c49fdf", null ]
];