var classlog_func =
[
    [ "logFunc", "classlog_func.html#a374a606873eb451b0f4eb69f187d7ee7", null ]
];