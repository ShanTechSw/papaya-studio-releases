/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-26 14:58:31
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe sine_raw;
probe ramp;
probe spikes;
probe noisy_deriv;
probe delayed;
probe held;

input const_;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Square = signalSource::square(2.0f, 0.0f);
  const_ = input("const", 0.0f);
  signalSource Sine = signalSource::sine(5.0f, 0.0f);
  signalSource Trigger = signalSource::pulse(4.0f, 0.5f, 0.0f);
  expander fan_2 = expander(2);
  integrator Integrator = integrator();
  derivative Derivative = derivative(0.005);
  noise Noise = noise(-0.5, 0.5, uniform);
  derivative d_dt_noise = derivative(0.002);
  expander fan_2_2 = expander(2);
  delayop Delay_50 = delayop(50);
  sampleHold Sample_Hold = sampleHold();
  sine_raw = probe("sine_raw");
  ramp = probe("ramp");
  spikes = probe("spikes");
  noisy_deriv = probe("noisy_deriv");
  delayed = probe("delayed");
  held = probe("held");

  /* Connect Blocks */
  Square > fan_2;
  const_ > Noise;
  Sine > fan_2_2;
  Sine > sine_raw;
  Trigger > Sample_Hold.in(1);
  fan_2.out(0) > Integrator;
  fan_2.out(1) > Derivative;
  Integrator > ramp;
  Derivative > spikes;
  Noise > d_dt_noise;
  d_dt_noise > noisy_deriv;
  fan_2_2.out(0) > Delay_50;
  fan_2_2.out(1) > Sample_Hold.in(0);
  Delay_50 > delayed;
  Sample_Hold > held;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    sine_raw.show();
    ramp.show();
    spikes.show();
    noisy_deriv.show();
    delayed.show();
    held.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}