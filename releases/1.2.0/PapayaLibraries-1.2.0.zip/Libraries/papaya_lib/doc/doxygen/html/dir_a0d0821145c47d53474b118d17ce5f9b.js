var dir_a0d0821145c47d53474b118d17ce5f9b =
[
    [ "Arduino.h", "stm32cubeide__hal_2include_2_arduino_8h.html", "stm32cubeide__hal_2include_2_arduino_8h" ],
    [ "PapayaStm32CubeIdeConfig.h", "_papaya_stm32_cube_ide_config_8h.html", "_papaya_stm32_cube_ide_config_8h" ],
    [ "SPI.h", "stm32cubeide__hal_2include_2_s_p_i_8h.html", "stm32cubeide__hal_2include_2_s_p_i_8h" ]
];