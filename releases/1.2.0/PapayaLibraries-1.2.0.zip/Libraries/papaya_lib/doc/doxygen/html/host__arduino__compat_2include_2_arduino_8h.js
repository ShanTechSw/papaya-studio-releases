var host__arduino__compat_2include_2_arduino_8h =
[
    [ "DesktopSerial", "class_desktop_serial.html", "class_desktop_serial" ],
    [ "byte", "host__arduino__compat_2include_2_arduino_8h.html#a3918133105dc994def94df7a502323cc", null ],
    [ "DigitalWriteHandler", "host__arduino__compat_2include_2_arduino_8h.html#ae20561b4fc7f679ed291c1c616d39090", null ],
    [ "PinModeHandler", "host__arduino__compat_2include_2_arduino_8h.html#aa582f33aa76d236c93a5990ded9dd62e", null ],
    [ "delay", "host__arduino__compat_2include_2_arduino_8h.html#a6bc5f943544a887f8b23cadfb26a5e30", null ],
    [ "delayMicroseconds", "host__arduino__compat_2include_2_arduino_8h.html#a62e0a53bc261f9de8700cc5a92307e85", null ],
    [ "digitalWrite", "host__arduino__compat_2include_2_arduino_8h.html#ae9647a9a056bb33fd1206da70c83bde3", null ],
    [ "millis", "host__arduino__compat_2include_2_arduino_8h.html#a6ff7f2532a22366f0013bc41397129fd", null ],
    [ "pinMode", "host__arduino__compat_2include_2_arduino_8h.html#ac7bdb53335528ad073ca13eb2b1bdc00", null ],
    [ "registerDigitalWriteHandler", "host__arduino__compat_2include_2_arduino_8h.html#a8b437eef8737447653d823ae48c5af6f", null ],
    [ "registerPinModeHandler", "host__arduino__compat_2include_2_arduino_8h.html#a2cfb4fc82d03e32047564095ed88a110", null ],
    [ "HIGH", "host__arduino__compat_2include_2_arduino_8h.html#a3cc93929bc2e3992202317d8bef5c1e7", null ],
    [ "INPUT", "host__arduino__compat_2include_2_arduino_8h.html#ac55cd9e1b802cb6cb7c4dcf03fe8f0fd", null ],
    [ "LOW", "host__arduino__compat_2include_2_arduino_8h.html#afd8f55435bd59bebefd8372748942114", null ],
    [ "OUTPUT", "host__arduino__compat_2include_2_arduino_8h.html#aef789dfcf03d8f75a2a37474c5ac17b2", null ],
    [ "Serial", "host__arduino__compat_2include_2_arduino_8h.html#a67e14daf2286fd0b0f84ad20ac2b5e17", null ]
];