"""Torsional vibration: the gyroscope hears what the accelerometer cannot.

Run this beside example 92.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  torque ripple   the slip-beat share: how much of the torsional vibration
                  sits at twice the slip frequency. That beat is the
                  classic broken or cracked rotor-bar signature and it is
                  torsional, not translational, so a vibration meter that
                  measures shaking does not see it.

  backlash        the knock share, plus crest factor. A worn coupling or a
                  loose key does not produce a tone, it produces one impact
                  per revolution, and an impact is broadband and sharp.

  and the point   the accelerometer is read at the same moment and printed
                  beside the verdict. If it has not moved while the
                  gyroscope has, that is the example working, not a fault
                  in the accelerometer.

The slip band is the one setting to get right: twice the slip frequency
depends on LOAD, so measure it on a loaded machine and set it from the
speed you observe rather than from the nameplate.
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "torque ripple", "coupling backlash")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "torsional"
FEATURES = ("e_slip", "e_1x", "e_knock", "ripple", "slip_share",
            "knock_share", "crest", "a_rms", "state")

SLIP_SHARE = 0.50           # of the torsional level
KNOCK_SHARE = 0.30
CREST_IMPACT = 2.2
RIPPLE_ALERT = 2.0          # multiple of the healthy torsional level
BASELINE_RIPPLE = 0.0143    # rad/s, this machine when it was behaving
ACCEL_BASELINE = 0.0140     # g, the accelerometer at the same moment

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def classify(row):
    ripple = row["ripple"]
    level = ripple / max(BASELINE_RIPPLE, 1e-12)
    accel_level = row["a_rms"] / max(ACCEL_BASELINE, 1e-12)
    reasons = [
        f"torsional level {ripple:.4f} rad/s, {level:.2f}x the healthy "
        f"value",
        f"bands: slip {row['e_slip']:.5f}, shaft {row['e_1x']:.5f}, knock "
        f"{row['e_knock']:.5f} rad/s",
        f"shares: slip {row['slip_share']:.3f}, knock "
        f"{row['knock_share']:.3f}, crest {row['crest']:.2f}",
        f"the accelerometer, at the same moment, reads "
        f"{row['a_rms']:.4f} g, which is {accel_level:.2f}x ITS healthy "
        f"value",
    ]

    if row["slip_share"] >= SLIP_SHARE:
        reasons.append(
            "most of the torsional energy is at twice the slip frequency, "
            "which is electrical and not mechanical")
        if accel_level < 1.3:
            reasons.append(
                "and the accelerometer has not moved at all. A vibration "
                "programme measuring only translation would have passed "
                "this machine")
        return ("torque ripple",
                "rotor-bar torque ripple: a broken or cracked bar, or a "
                "bad joint in the cage", reasons)

    if row["knock_share"] >= KNOCK_SHARE or row["crest"] >= CREST_IMPACT:
        reasons.append(
            "the energy is broadband and the crest factor is up, which is "
            "an impact rather than a ripple")
        return ("coupling backlash",
                "something knocks once per revolution: a worn coupling, a "
                "loose key, or backlash in a gear", reasons)

    if level >= RIPPLE_ALERT:
        return ("torque ripple",
                "the torsional level is up but in no band this script "
                "names. Look at the spectrum", reasons)
    return ("healthy", "the shaft is turning smoothly", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 92_torsional_vibration_gyroscope.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA torsional vibration monitor")
    print("=" * 72)
    print("A machine with uneven torque twists rather than shakes. This "
          "reads the\ngyroscope's z channel, which is rotation about the "
          "shaft axis, and prints\nwhat the accelerometer made of the same "
          "moment.")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
