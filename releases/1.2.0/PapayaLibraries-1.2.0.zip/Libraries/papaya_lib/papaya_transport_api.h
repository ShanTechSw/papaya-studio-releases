/**
 * @file    papaya_transport_api.h
 * @brief   Per-board transport (SPI / serial) tx / rx hook declarations.
 *
 * Every concrete port under @c ports/ implements one set of
 * @c papaya_boardN_tx / @c papaya_boardN_rx (N = 0..3) plus
 * @c papaya_example_platform_setup. @c PAPAYA.cpp calls these to move
 * bytes; everything above this layer is platform-agnostic.
 */
#pragma once

#include <stdint.h>

void papaya_example_platform_setup();

void papaya_board0_tx(uint8_t *tx_buffer, uint16_t number_of_bytes);
void papaya_board0_rx(uint8_t *rx_buffer, uint16_t number_of_bytes);

/**
 * @brief Read one whole pushed packet from board 0, returning its length.
 *
 * OPTIONAL and provided only by ports whose transport actually has a
 * push stream: the PC USB port does; the SPI ports do not, because on
 * SPI the master drives every exchange and nothing arrives unprompted.
 *
 * Pass it to PAPAYA::setPacketReader() to enable readProbesLive() and
 * readProbesLatest(). Returns 0 when no packet arrived within the
 * timeout, which is a normal answer rather than an error.
 */
uint16_t papaya_board0_rx_packet(uint8_t *buffer, uint16_t capacity, uint32_t timeout_ms);

void papaya_board1_tx(uint8_t *tx_buffer, uint16_t number_of_bytes);
void papaya_board1_rx(uint8_t *rx_buffer, uint16_t number_of_bytes);

void papaya_board2_tx(uint8_t *tx_buffer, uint16_t number_of_bytes);
void papaya_board2_rx(uint8_t *rx_buffer, uint16_t number_of_bytes);

void papaya_board3_tx(uint8_t *tx_buffer, uint16_t number_of_bytes);
void papaya_board3_rx(uint8_t *rx_buffer, uint16_t number_of_bytes);
