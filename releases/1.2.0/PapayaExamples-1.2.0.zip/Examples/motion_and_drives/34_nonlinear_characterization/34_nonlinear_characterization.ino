/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-07 01:01:11
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe saturation;
probe deadzone;
probe backlash;
probe friction_stribe;
probe rate_limiter;
probe quantizer_2;
probe sign_2;
probe comparator;
probe schmitt;
probe Motor_tap;

input Vsatm;
input Vsatp;
input deadzone_dead_l;
input deadzone_dead;
input backlash_deadba;
input rate_limiter_up;
input rate_limiter_dn;
input const_;
input comparator_min;
input comparator_max;
input const__2;
input schmitt_out_hig;
input schmitt_out_low;
input schmitt_trip;
input schmitt_trip1;

/* Global Struct Declarations */
// Configuration for Motor
PP_motorBlockCfg Motor_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  1,
  {MotorVelocity, NoMotorOutput, NoMotorOutput}
};


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  Vsatm = input("Vsatm", -0.5f);
  Vsatp = input("Vsatp", 0.5f);
  deadzone_dead_l = input("deadzone_dead_l", -0.2f);
  deadzone_dead = input("deadzone_dead", 0.2f);
  backlash_deadba = input("backlash_deadba", 0.2f);
  rate_limiter_up = input("rate_limiter_up", 8.0f);
  rate_limiter_dn = input("rate_limiter_dn", 2.0f);
  comparator_min = input("comparator_min", -1.0f);
  comparator_max = input("comparator_max", 1.0f);
  schmitt_out_hig = input("schmitt_out_hig", 1.0f);
  schmitt_out_low = input("schmitt_out_low", -1.0f);
  schmitt_trip = input("schmitt_trip", 0.3f);
  schmitt_trip1 = input("schmitt_trip1", -0.3f);
  signalSource Triangle_slow = signalSource::triangle(1.0f, 0.0f, 0.5f);
  const_ = input("const", 0.125f);
  const__2 = input("const", 0.0f);
  expander fan_2 = expander(2);
  expander Fan_out = expander(9);
  frictionStribeck Friction_feed_fwd = frictionStribeck(0.1, 0.2, 0.05, 0.01);
  sat Saturation = sat();
  deadZone Deadzone = deadZone();
  backlashDeadBand Backlash = backlashDeadBand();
  frictionStribeck Friction_Stribeck = frictionStribeck(0.05, 0.1, 0.01, 0.001);
  rateLimiter Rate_Limiter = rateLimiter();
  quantizer Quantizer = quantizer();
  sign Sign = sign();
  comp Comparator = comp();
  schmidt Schmitt = schmidt();
  motor Motor = motor(&Motor_config);
  saturation = probe("saturation");
  deadzone = probe("deadzone");
  backlash = probe("backlash");
  friction_stribe = probe("friction_stribe");
  rate_limiter = probe("rate_limiter");
  quantizer_2 = probe("quantizer");
  sign_2 = probe("sign");
  comparator = probe("comparator");
  schmitt = probe("schmitt");
  Motor_tap = probe("Motor_o0");

  /* Connect Blocks */
  Vsatm > Saturation.in(1);
  Vsatp > Saturation.in(0);
  deadzone_dead_l > Deadzone.in(0);
  deadzone_dead > Deadzone.in(1);
  backlash_deadba > Backlash.in(0);
  rate_limiter_up > Rate_Limiter.in(1);
  rate_limiter_dn > Rate_Limiter.in(2);
  comparator_min > Comparator.in(1);
  comparator_max > Comparator.in(0);
  schmitt_out_hig > Schmitt.in(1);
  schmitt_out_low > Schmitt.in(2);
  schmitt_trip > Schmitt.in(3);
  schmitt_trip1 > Schmitt.in(4);
  Triangle_slow > fan_2;
  const_ > Quantizer.in(1);
  const__2 > Comparator.in(3);
  fan_2.out(0) > Fan_out;
  fan_2.out(1) > Friction_feed_fwd;
  Fan_out.out(0) > Saturation.in(2);
  Fan_out.out(1) > Deadzone.in(2);
  Fan_out.out(2) > Backlash.in(1);
  Fan_out.out(3) > Friction_Stribeck;
  Fan_out.out(4) > Rate_Limiter.in(0);
  Fan_out.out(5) > Quantizer.in(0);
  Fan_out.out(6) > Sign;
  Fan_out.out(7) > Comparator.in(2);
  Fan_out.out(8) > Schmitt.in(0);
  Friction_feed_fwd > Motor;
  Saturation > saturation;
  Deadzone > deadzone;
  Backlash > backlash;
  Friction_Stribeck > friction_stribe;
  Rate_Limiter > rate_limiter;
  Quantizer > quantizer_2;
  Sign > sign_2;
  Comparator > comparator;
  Schmitt > schmitt;
  Motor > Motor_tap;

  /* Enable Remote Input Control */
  Vsatm.enableRemote();
  Vsatp.enableRemote();
  deadzone_dead_l.enableRemote();
  deadzone_dead.enableRemote();
  backlash_deadba.enableRemote();
  rate_limiter_up.enableRemote();
  rate_limiter_dn.enableRemote();
  comparator_min.enableRemote();
  comparator_max.enableRemote();
  schmitt_out_hig.enableRemote();
  schmitt_out_low.enableRemote();
  schmitt_trip.enableRemote();
  schmitt_trip1.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    saturation.show();
    deadzone.show();
    backlash.show();
    friction_stribe.show();
    rate_limiter.show();
    quantizer_2.show();
    sign_2.show();
    comparator.show();
    schmitt.show();
    Motor_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}