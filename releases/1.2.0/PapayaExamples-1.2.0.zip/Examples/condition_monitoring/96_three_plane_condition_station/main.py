"""Three planes: the direction of the largest reading is most of the diagnosis.

Run this beside example 96.

    python main.py

WHAT IT DECIDES, AND ON WHAT EVIDENCE

  is the machine
  even running    the magnetometer's supply line and the gyroscope's
                  torsional level. Every velocity reading is small when the
                  motor is off, and small is exactly what a healthy machine
                  looks like. This is checked FIRST and nothing else is
                  reported until it passes.

  severity        the largest of the three directions, against the ISO
                  20816 zones. The standard evaluates the worst direction,
                  not an average.

  which fault     the direction of that largest reading, and the 2x content
                  with it:
                    axial largest        misalignment
                    vertical largest,
                      with 2x            a soft foot, rocking on a corner
                    radial largest,
                      no 2x, no axial    unbalance
"""
from __future__ import annotations

import statistics
import struct
import sys
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATCH_SECONDS = 30.0
DECIDE_EVERY = 0.4

# Set this to False on a real machine. The design plays the condition the
# recorded machine is in on its own trace; with a real sensor that trace is
# still running and means nothing.
SCORE_AGAINST_REFERENCE = True
CONDITIONS = ("healthy", "imbalance", "soft foot", "misalignment")

# The feature vector, in the order the design's Feature Stack publishes it.
VECTOR = "planes"
FEATURES = ("v_h", "v_v", "v_a", "v_max", "h1x", "v1x", "a1x",
            "h2x", "v2x", "a2x", "torsion", "supply",
            "state")

# ISO 20816-3 zones for a medium machine on a rigid mount, mm/s RMS.
ZONES = (("A", 1.4), ("B", 2.8), ("C", 4.5), ("D", float("inf")))

SUPPLY_PRESENT = 1.0        # uT, the motor is energised
TURNING = 0.005             # rad/s, the shaft is turning
AXIAL_DOMINANT = 1.2        # axial over the larger radial
TWO_X_SIGNIFICANT = 0.25    # 2x over 1x in the same direction
# 0.25 and not 0.5. Measured on this record, vertical 2x over vertical 1x:
# healthy 0.15, unbalance 0.06, soft foot 0.30, misalignment 0.67. At 0.5
# the soft foot fell through and was called unbalance. Healthy is excluded
# anyway by the test that the vertical reading beats the horizontal one,
# which it does not on a machine bolted to a floor.
ALERT_ZONE = "B"

# ---------------------------------------------------------------------------
# The judgement. No board below this line, and none above the next banner.
# ---------------------------------------------------------------------------

def zone_of(mms):
    for name, limit in ZONES:
        if mms < limit:
            return name
    return ZONES[-1][0]


def classify(row):
    reasons = [
        f"horizontal {row['v_h']:.3f}, vertical {row['v_v']:.3f}, axial "
        f"{row['v_a']:.3f} mm/s",
        f"shaft line by direction: {row['h1x']:.3f}, {row['v1x']:.3f}, "
        f"{row['a1x']:.3f} mm/s",
        f"2x by direction: {row['h2x']:.3f}, {row['v2x']:.3f}, "
        f"{row['a2x']:.3f} mm/s",
        f"interlock: supply {row['supply']:.2f} uT, torsional "
        f"{row['torsion']:.4f} rad/s",
    ]

    # The interlock, and it comes first for a reason.
    if row["supply"] < SUPPLY_PRESENT or row["torsion"] < TURNING:
        return ("not running",
                "the machine is not running, so every reading below is "
                "small for the wrong reason",
                reasons + ["a station that cannot tell a good machine from "
                           "a stopped one will eventually report a good "
                           "machine that has been off for a month"])

    worst = row["v_max"]
    zone = zone_of(worst)
    reasons.append(f"worst direction {worst:.3f} mm/s, zone {zone}")

    radial = max(row["v_h"], row["v_v"])
    axial_ratio = row["v_a"] / max(radial, 1e-12)
    two_x_v = row["v2x"] / max(row["v1x"], 1e-12)

    if axial_ratio >= AXIAL_DOMINANT:
        reasons.append(
            f"the axial reading is {axial_ratio:.2f} times the larger "
            f"radial one. Only a force along the shaft does that, and a "
            f"rotating heavy spot has no axial component to give")
        return ("misalignment",
                f"misalignment, zone {zone}", reasons)

    if row["v_v"] > row["v_h"] and two_x_v >= TWO_X_SIGNIFICANT:
        reasons.append(
            f"vertical beats horizontal, which is backwards for a machine "
            f"bolted to a floor, and 2x is {two_x_v:.2f} of 1x in that "
            f"direction: the machine is lifting twice per revolution")
        return ("soft foot", f"a soft foot or a loose hold-down, zone "
                             f"{zone}", reasons)

    if zone in ("C", "D") or (zone == "B" and ALERT_ZONE == "B"):
        reasons.append(
            "radial, roughly equal in both radial directions, with little "
            "2x and nothing axial")
        return ("imbalance", f"unbalance, zone {zone}", reasons)

    return ("healthy", f"zone {zone}, nothing to report", reasons)


def score_line(verdict, reference):
    """Was the verdict right? Only meaningful against the recorded machine."""
    if reference is None:
        return None
    index = int(round(reference))
    if not 0 <= index < len(CONDITIONS):
        return None
    return verdict == CONDITIONS[index], CONDITIONS[index]


# ---------------------------------------------------------------------------
# The board
# ---------------------------------------------------------------------------

def load_design():
    """Build the diagram on the board and return the module holding it.

    The design is IMPORTED rather than copied, so this script cannot
    drift from the diagram: regenerate the design and this reads the new
    probes without being touched.

    It is used THROUGH the module, and not pulled in with
    ``from papaya_design import *``, because the blocks do not exist
    until papaya_design_init() runs. A star import copies the names
    before that call has created any of them, and every one of them is
    undefined by the time you come to use it.
    """
    try:
        import papaya_design
    except ImportError as exc:
        raise SystemExit(
            "papaya_design.py is not in this folder. Open 96_three_plane_condition_station.pap in Papaya "
            "Studio, generate the Python, and choose this file when it "
            "asks which main to use.") from exc
    papaya_design.papaya_design_init()
    return papaya_design


def read_row(d):
    probe = getattr(d, VECTOR)
    raw = d.papaya0.readVectProbeLive(probe, len(FEATURES))
    if raw is None or len(raw) < 4 * len(FEATURES):
        return None
    row = dict(zip(FEATURES,
                   struct.unpack(f"<{len(FEATURES)}f",
                                 raw[:4 * len(FEATURES)])))
    if not SCORE_AGAINST_REFERENCE:
        row["state"] = None
    return row


def collect(d, seconds):
    rows = []
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        row = read_row(d)
        if row is not None:
            rows.append(row)
    return rows


def smooth(rows):
    """The median of a burst.

    One sample of a sliding average that is still filling is not a
    measurement, and one sample of a resetting statistic is not either.
    """
    out = {k: statistics.median(r[k] for r in rows)
           for k in FEATURES if rows[0][k] is not None}
    out["state"] = rows[-1]["state"]
    return out


def main():
    print("PAPAYA three-plane condition station")
    print("=" * 72)
    print("Three directions from one sensor. The direction of the "
          "largest reading is\nmost of the diagnosis, and a single-axis "
          "meter throws it away.")
    print("\nZones, mm/s RMS, for a medium machine on a rigid mount:")
    for name, limit in ZONES:
        edge = "and above" if limit == float("inf") else f"below {limit}"
        print(f"  zone {name}  {edge}")

    d = load_design()
    print(f"\nWatching for {WATCH_SECONDS:.0f} s.")
    print("-" * 72)

    started = time.monotonic()
    last = None
    tally = {}
    right = wrong = 0
    while time.monotonic() - started < WATCH_SECONDS:
        burst = collect(d, DECIDE_EVERY)
        if len(burst) < 3:
            continue
        row = smooth(burst)
        verdict, headline, reasons = classify(row)
        tally[verdict] = tally.get(verdict, 0) + 1
        scored = score_line(verdict, row.get("state"))
        if scored is not None:
            right += scored[0]
            wrong += not scored[0]
        if verdict != last:
            print(f"\n[{time.monotonic() - started:6.1f} s]  "
                  f"{verdict.upper()}")
            print(f"           {headline}")
            for r in reasons:
                print(f"             - {r}")
            if scored is not None:
                mark = "agrees with" if scored[0] else "DISAGREES with"
                print(f"           {mark} the recorded machine, which is "
                      f"in {scored[1]}")
            last = verdict

    print("\n" + "-" * 72)
    print("Summary")
    for k, v in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {k:22s} {v:4d} decisions")
    if right + wrong:
        print(f"  agreed with the recorded machine on {right} of "
              f"{right + wrong} "
              f"({100.0 * right / (right + wrong):.0f} per cent)")
        print("  set SCORE_AGAINST_REFERENCE to False on a real machine: "
              "that trace keeps\n  playing whatever the sensor does.")
    print("\nDone. The design is still running; close it from the Monitor.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)
