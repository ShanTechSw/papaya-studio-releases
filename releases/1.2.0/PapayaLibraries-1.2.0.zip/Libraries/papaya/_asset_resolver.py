"""
Hybrid asset resolver - reads from the encrypted blob if present,
falls back to the filesystem otherwise.

One place that turns an asset's relative path into its bytes, whichever
of the two ways the assets happen to be packaged:

  1. PACKED MODE: the assets live in a single encrypted blob shipped
     alongside the application, and a generated `papaya/_asset_loader.py`
     exposes `open_asset(rel_path) -> bytes` to read out of it.

  2. LOOSE MODE: the assets sit as ordinary files in the application
     tree. Used whenever no blob is present.

Callers should NEVER branch on which mode is active. They use:

    from papaya._asset_resolver import read_asset, papaya_pixmap
    data = read_asset("Logo/PAPAYA_LOGO.png")          # bytes
    px   = papaya_pixmap("Logo/PAPAYA_MARK.png")        # QPixmap

Both modes work with or without Pillow and cryptography installed, and
in a frozen bundle as well as a plain checkout.

A failed lookup raises FileNotFoundError - call sites that want a
silent miss must wrap accordingly. Loud-by-default catches the case
where an asset is moved and a call site stops working silently.
"""

from __future__ import annotations

import sys
from pathlib import Path

_FS_BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))


def _try_blob(rel_path: str) -> bytes | None:
    """Return blob-backed bytes if the loader is available, else None."""
    try:
        from papaya._asset_loader import open_asset  # type: ignore[import-not-found]
    except ImportError:
        return None
    try:
        return open_asset(rel_path)
    except (FileNotFoundError, KeyError):
        return None


def _try_filesystem(rel_path: str) -> bytes | None:
    abs_path = _FS_BASE / rel_path
    if not abs_path.is_file():
        return None
    try:
        return abs_path.read_bytes()
    except OSError:
        return None


def read_asset(rel_path: str) -> bytes:
    """Return the bytes of an asset. Raises FileNotFoundError if unfound."""
    rel_path = rel_path.replace("\\", "/")
    data = _try_blob(rel_path)
    if data is not None:
        return data
    data = _try_filesystem(rel_path)
    if data is not None:
        return data
    raise FileNotFoundError(
        f"Asset not found in blob or filesystem: {rel_path!r} "
        f"(searched {_FS_BASE})"
    )


def has_asset(rel_path: str) -> bool:
    rel_path = rel_path.replace("\\", "/")
    if _try_blob(rel_path) is not None:
        return True
    abs_path = _FS_BASE / rel_path
    return abs_path.is_file()


def papaya_pixmap(rel_path: str):
    """Return a QPixmap for the named asset (null on miss)."""
    from PyQt6.QtGui import QPixmap
    pix = QPixmap()
    try:
        data = read_asset(rel_path)
    except FileNotFoundError:
        return pix
    pix.loadFromData(data)
    return pix


def papaya_icon(rel_path: str):
    """Return a QIcon for the named asset (null on miss)."""
    from PyQt6.QtGui import QIcon
    return QIcon(papaya_pixmap(rel_path))
