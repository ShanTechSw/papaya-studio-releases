"""Board attestation: proving a board is genuine, not merely that it knows a secret.

What is wrong with knowing a secret
-----------------------------------
The older challenge is ``HMAC-SHA256(PSK, nonce || uid)``. HMAC is
symmetric, so **verifying requires the key that forges**. PAPAYA Studio
must verify, therefore every copy of Studio shipped to every customer
contains everything needed to build a board that passes. That is not a
weakness to be hardened away; it follows from the choice of primitive.

Here the board holds a private key nobody else has, and Studio holds only
a **public** key. Reverse-engineering the installer yields a public key,
and a public key cannot sign. Extracting one board's private key
compromises that board and no other.

What crosses the wire, and what it costs
----------------------------------------
Studio sends a 32-byte nonce, as before. The board returns its 116-byte
certificate and a 64-byte signature: 180 bytes, **once, at connect**.

Nothing on the sampling path changes. No byte is added to a design frame,
a probe read or an input write, and no time is spent on them. That is a
requirement rather than an accident: the data path is real-time and the
owner ruled that its confidentiality and integrity are not wanted.

What this deliberately does not do
----------------------------------
It does not protect the data path. A gateway between Studio and the board
can still read and alter design frames, probe values and inputs. It also
means a gateway could attest genuine board A and then talk to board B, so
attestation is re-run periodically to bound that window; see
:data:`REATTEST_INTERVAL_S`.
"""
from __future__ import annotations

import os
import struct
from dataclasses import dataclass
from typing import Optional, Tuple

from . import ed25519

__all__ = [
    "CERTIFICATE_LEN", "SIGNATURE_LEN", "NONCE_LEN", "UID_LEN",
    "ATTEST_CONTEXT", "REATTEST_INTERVAL_S",
    "Certificate", "AttestationError",
    "encode_certificate", "decode_certificate", "sign_certificate",
    "attestation_message", "verify_attestation",
    "ca_public_key", "CA_IS_PROVISIONED", "CA_FINGERPRINT",
    "Policy", "POLICY_DEFAULT",
]

#: Fixed offsets, no length fields, nothing to get wrong on an MCU that
#: has to hand this over without parsing it.
#:
#:     0   4  magic
#:     4   2  format version
#:     6   2  reserved
#:     8  12  board uid, exactly as GetBoardInfo reports it
#:    20  32  board public key
#:    52  64  CA signature over bytes 0..51
CERT_MAGIC = b"PPCT"
CERT_VERSION = 1
CERT_BODY_LEN = 52
CERTIFICATE_LEN = 116

SIGNATURE_LEN = ed25519.SIGNATURE_LEN
NONCE_LEN = 32
UID_LEN = 12

#: Domain separation. Without it a signature made for one purpose can be
#: presented as one made for another, and it costs nothing to prevent.
ATTEST_CONTEXT = b"PP-ATTEST-v1"

#: How often a live connection re-proves the board is still the board it
#: attested as. Off the data path, so it costs nothing that matters.
REATTEST_INTERVAL_S = 300.0


class AttestationError(Exception):
    """A certificate or a response that cannot be read at all.

    Distinct from a refusal: a refusal is a well-formed answer that did
    not verify, and the two want different messages.
    """


@dataclass(frozen=True)
class Certificate:
    """What the factory said about one board."""

    uid: bytes
    public_key: bytes
    ca_signature: bytes
    version: int = CERT_VERSION

    @property
    def uid_hex(self) -> str:
        """Grouped the way GetBoardInfo reports it, so the two can be
        compared by eye in a support conversation."""
        raw = self.uid.hex().upper()
        return f"{raw[0:8]}-{raw[8:16]}-{raw[16:24]}"


# ==========================================================================
# The certificate
# ==========================================================================
def encode_certificate(uid: bytes, public_key: bytes,
                       ca_signature: bytes) -> bytes:
    if len(uid) != UID_LEN:
        raise ValueError(f"uid must be {UID_LEN} bytes, got {len(uid)}")
    if len(public_key) != ed25519.PUBLIC_KEY_LEN:
        raise ValueError(
            f"public key must be {ed25519.PUBLIC_KEY_LEN} bytes, "
            f"got {len(public_key)}")
    if len(ca_signature) != SIGNATURE_LEN:
        raise ValueError(
            f"CA signature must be {SIGNATURE_LEN} bytes, "
            f"got {len(ca_signature)}")
    body = (CERT_MAGIC + struct.pack("<HH", CERT_VERSION, 0)
            + bytes(uid) + bytes(public_key))
    assert len(body) == CERT_BODY_LEN
    return body + bytes(ca_signature)


def decode_certificate(blob: bytes) -> Certificate:
    """Raises AttestationError on anything that is not one.

    Called on bytes a device sent before it proved anything, so it must
    refuse rather than misread: a short read that produced a plausible
    certificate would be worse than one that produced none.
    """
    if len(blob) != CERTIFICATE_LEN:
        raise AttestationError(
            f"a certificate is {CERTIFICATE_LEN} bytes; got {len(blob)}")
    if blob[:4] != CERT_MAGIC:
        raise AttestationError("not a PAPAYA certificate")
    version, reserved = struct.unpack_from("<HH", blob, 4)
    if version != CERT_VERSION:
        raise AttestationError(
            f"certificate format version {version}; this build reads "
            f"{CERT_VERSION}. Update whichever end is older.")
    if reserved != 0:
        raise AttestationError("reserved field is not zero")
    return Certificate(uid=blob[8:20], public_key=blob[20:52],
                       ca_signature=blob[52:116], version=version)


def sign_certificate(ca_seed: bytes, uid: bytes, public_key: bytes) -> bytes:
    """Mint a certificate. Offline, at provisioning time, only.

    The CA seed is the single point of absolute trust for the product;
    everything else here is recoverable and it is not.
    """
    body = (CERT_MAGIC + struct.pack("<HH", CERT_VERSION, 0)
            + bytes(uid) + bytes(public_key))
    return encode_certificate(uid, public_key, ed25519.sign(ca_seed, body))


# ==========================================================================
# The challenge
# ==========================================================================
def attestation_message(nonce: bytes, uid: bytes) -> bytes:
    """Exactly the bytes the board signs.

    The uid is inside the signature, not merely alongside it. Without
    that, a signature captured from board A is a valid signature for the
    same nonce presented by board B, and the certificate check would be
    the only thing standing between a counterfeit and acceptance.
    """
    if len(nonce) != NONCE_LEN:
        raise ValueError(f"nonce must be {NONCE_LEN} bytes, got {len(nonce)}")
    if len(uid) != UID_LEN:
        raise ValueError(f"uid must be {UID_LEN} bytes, got {len(uid)}")
    return ATTEST_CONTEXT + bytes(nonce) + bytes(uid)


def verify_attestation(response: bytes, nonce: bytes, uid: bytes,
                       ca_public: Optional[bytes] = None,
                       ) -> Tuple[bool, str]:
    """Check a board's whole answer. Returns ``(accepted, reason)``.

    Four things must hold, and all four are checked here rather than
    spread across callers, because a caller that forgot one would produce
    a Studio that accepts counterfeits and looks correct:

    1. the certificate parses;
    2. the CA signed it;
    3. the uid it carries is the uid this board reported;
    4. the board signed THIS nonce with the key in that certificate.

    The reason is returned even on success, so a caller can log or
    display what was actually proved instead of a bare boolean.
    """
    if ca_public is None:
        ca_public = ca_public_key()

    expected = CERTIFICATE_LEN + SIGNATURE_LEN
    if len(response) != expected:
        return False, (f"an attestation is {expected} bytes; the board sent "
                       f"{len(response)}")

    try:
        certificate = decode_certificate(response[:CERTIFICATE_LEN])
    except AttestationError as exc:
        return False, str(exc)

    body = response[:CERT_BODY_LEN]
    if not ed25519.verify(ca_public, body, certificate.ca_signature):
        return False, ("the certificate was not signed by this CA. Either "
                       "the board is not genuine, or it was made for a "
                       "different factory key.")

    if certificate.uid != bytes(uid):
        # The board reported one identity and its certificate names
        # another: a genuine certificate presented by something else.
        return False, (f"the certificate is for board "
                       f"{certificate.uid_hex}, but this board reports a "
                       f"different unique id")

    signature = response[CERTIFICATE_LEN:]
    if not ed25519.verify(certificate.public_key,
                          attestation_message(nonce, uid), signature):
        return False, ("the board did not sign this challenge with the key "
                       "in its certificate")

    return True, f"attested as board {certificate.uid_hex}"


# ==========================================================================
# Where the CA public key comes from
# ==========================================================================
#: Published, and therefore worthless for security. It is the
#: zero-configuration path for a freshly cloned tree, exactly as the
#: development PSK is, and it is derived from a seed printed in the
#: provisioning tool so anyone can regenerate it and see that they can.
#:
#: A released build never carries it: the release refuses to produce one
#: until a real CA has been provisioned.
_DEV_CA_PUBLIC_HEX = (
    "14d68deedc8e2844de07e5ffb3618abaaf64b266bf40f02fd58c23827ed816b7")


def _resolve_ca() -> Tuple[bytes, bool]:
    """(public key, provisioned). First hit wins, same ladder as the PSK."""
    override = os.environ.get("PAPAYA_ATTEST_CA_HEX", "").strip()
    if override:
        try:
            raw = bytes.fromhex(override)
        except ValueError:
            raise AttestationError(
                "PAPAYA_ATTEST_CA_HEX is not hexadecimal")
        if len(raw) != ed25519.PUBLIC_KEY_LEN:
            raise AttestationError(
                f"PAPAYA_ATTEST_CA_HEX must be "
                f"{ed25519.PUBLIC_KEY_LEN} bytes")
        return raw, True

    try:
        from . import _attest_ca                       # type: ignore
    except ImportError:
        pass
    else:
        raw = bytes.fromhex(getattr(_attest_ca, "CA_PUBLIC_HEX", ""))
        if len(raw) == ed25519.PUBLIC_KEY_LEN:
            return raw, True

    return bytes.fromhex(_DEV_CA_PUBLIC_HEX), False


_CA_PUBLIC, CA_IS_PROVISIONED = _resolve_ca()

#: Identifies the CA without revealing anything. A public key is safe to
#: print in full, but a short form is what fits in a status line.
CA_FINGERPRINT = _CA_PUBLIC[:8].hex()


def ca_public_key() -> bytes:
    return _CA_PUBLIC


# ==========================================================================
# Policy
# ==========================================================================
class Policy:
    """What Studio does when a board cannot attest.

    The setting matters more than it looks. If Studio falls back to the
    old challenge whenever attestation fails, a counterfeit simply
    refuses to attest and claims to be an older board: the downgrade
    defeats the entire mechanism. Only ``REQUIRED`` delivers the
    guarantee, and its cost is that boards made before attestation stop
    being recognised.
    """

    #: Try attestation; fall back to the old challenge and mark the board
    #: legacy. For today, while boards in the field predate this.
    PREFERRED = "attest-preferred"
    #: Refuse any board that cannot attest. The guarantee.
    REQUIRED = "attest-required"
    #: The old behaviour, for bench and bring-up.
    HMAC_ONLY = "hmac-only"

    ALL = (PREFERRED, REQUIRED, HMAC_ONLY)


POLICY_DEFAULT = Policy.PREFERRED


def policy_from_environment() -> str:
    """``PAPAYA_ATTEST_POLICY``, or the default.

    An unrecognised value is refused rather than silently treated as the
    default: a typo in the setting that is meant to enforce the guarantee
    must not quietly disable it.
    """
    value = os.environ.get("PAPAYA_ATTEST_POLICY", "").strip()
    if not value:
        return POLICY_DEFAULT
    if value not in Policy.ALL:
        raise AttestationError(
            f"PAPAYA_ATTEST_POLICY={value!r} is not one of "
            f"{', '.join(Policy.ALL)}")
    return value


@dataclass(frozen=True)
class Decision:
    """What the connect path should do about one board.

    ``accept`` is the only field that gates the connection. ``attested``
    says whether identity was PROVED rather than merely consistent with a
    secret every copy of Studio carries, and the two are deliberately
    separate: under ``PREFERRED`` a board can be accepted without being
    attested, and a caller that conflated them would report a legacy
    board as proved.
    """

    accept: bool
    attested: bool
    reason: str


def decide(policy: str, response: Optional[bytes], nonce: bytes, uid: bytes,
           ca_public: Optional[bytes] = None) -> Decision:
    """Apply the downgrade policy to one board's answer.

    Pure, so the rule can be tested without a board and without a dialog.
    ``response`` is ``None`` when the board did not answer the attest
    command at all.

    The rule that matters, and the one easiest to get wrong:

    **"Did not answer" and "answered wrongly" are not the same thing.**
    A board that does not answer may genuinely predate attestation, and
    under ``PREFERRED`` that is tolerated. A board that ANSWERS and fails
    is refused under every policy including ``PREFERRED``, because a
    wrong answer is not evidence of age, it is evidence of forgery. If
    both were treated as "fall back to the old check", a counterfeit
    would just send rubbish and be waved through, and ``PREFERRED``
    would be worth nothing.
    """
    if policy not in Policy.ALL:
        raise AttestationError(f"unknown attestation policy {policy!r}")

    if policy == Policy.HMAC_ONLY:
        return Decision(True, False,
                        "attestation was not attempted, because the policy "
                        "is set to the old shared-secret check only")

    if response is None:
        if policy == Policy.REQUIRED:
            return Decision(False, False,
                            "this board cannot prove it is genuine, and the "
                            "policy requires proof")
        return Decision(True, False,
                        "this board predates attestation, so its identity "
                        "rests on the shared-secret check")

    ok, reason = verify_attestation(response, nonce, uid, ca_public=ca_public)
    if ok:
        return Decision(True, True, reason)
    # Answered and failed. Refused under PREFERRED too, deliberately.
    return Decision(False, False, reason)
