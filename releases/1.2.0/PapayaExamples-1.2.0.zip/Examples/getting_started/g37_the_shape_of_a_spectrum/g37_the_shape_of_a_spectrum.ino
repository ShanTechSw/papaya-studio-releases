/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-03 18:40:01
 *  Fs (Hz)      : 8000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe centroid;
probe Descriptors_tap;
probe Descriptors_tap_2;
probe Descriptors_tap_3;
probe Descriptors_tap_4;
probe Descriptors_tap_5;
probe Descriptors_tap_6;
VectorProbe cepstrum_2;
probe Cepstrum_tap;

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(8000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource Source = signalSource::sine(500.0f, 0.0f);
  expander signal_split = expander(2);
  fft Transform_for_descriptors = fft(256);
  fft Transform_for_cepstrum = fft(256);
  fftMagResolver Magnitude_for_descriptors = fftMagResolver(Transform_for_descriptors);
  fftMagResolver Magnitude_for_cepstrum = fftMagResolver(Transform_for_cepstrum);
  spectralFeatures Descriptors = spectralFeatures(Magnitude_for_descriptors);
  cepstrum Cepstrum = cepstrum(Magnitude_for_cepstrum);
  centroid = probe("centroid");
  Descriptors_tap = probe("Descriptors_o1");
  Descriptors_tap_2 = probe("Descriptors_o2");
  Descriptors_tap_3 = probe("Descriptors_o3");
  Descriptors_tap_4 = probe("Descriptors_o4");
  Descriptors_tap_5 = probe("Descriptors_o5");
  Descriptors_tap_6 = probe("Descriptors_o6");
  cepstrum_2 = VectorProbe("cepstrum");
  Cepstrum_tap = probe("Cepstrum_o0");

  /* Connect Blocks */
  Source > signal_split;
  signal_split.out(0) > Transform_for_descriptors;
  signal_split.out(1) > Transform_for_cepstrum;
  Transform_for_descriptors > Magnitude_for_descriptors;
  Transform_for_cepstrum > Magnitude_for_cepstrum;
  Magnitude_for_descriptors > Descriptors;
  Magnitude_for_cepstrum > Cepstrum;
  Descriptors.out(0) > centroid;
  Descriptors.out(1) > Descriptors_tap;
  Descriptors.out(2) > Descriptors_tap_2;
  Descriptors.out(3) > Descriptors_tap_3;
  Descriptors.out(4) > Descriptors_tap_4;
  Descriptors.out(5) > Descriptors_tap_5;
  Descriptors.out(6) > Descriptors_tap_6;
  Cepstrum >> cepstrum_2;
  Cepstrum > Cepstrum_tap;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    centroid.show();
    Descriptors_tap.show();
    Descriptors_tap_2.show();
    Descriptors_tap_3.show();
    Descriptors_tap_4.show();
    Descriptors_tap_5.show();
    Descriptors_tap_6.show();
    cepstrum_2.show();
    Cepstrum_tap.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}