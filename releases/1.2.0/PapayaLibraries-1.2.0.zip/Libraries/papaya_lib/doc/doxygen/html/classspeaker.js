var classspeaker =
[
    [ "speaker", "classspeaker.html#a4a31bb9c60d468be9be8b46750f97a23", null ]
];