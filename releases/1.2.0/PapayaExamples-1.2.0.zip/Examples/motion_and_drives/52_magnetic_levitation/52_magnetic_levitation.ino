/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 1000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe coil_current;
probe true_gap;
probe measured_gap_2;

input gap_offset;
input adc_step;
input gap_ramp_up;
input gap_ramp_dn;
input coil_i_max;
input coil_i_min;
input const_;

/* Global Array Declarations */
float SIM__maglev_gap_numerator[] = {1.0f};
float SIM__maglev_gap_denominator[] = {1.0f, 0.0f, -100.0f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(1000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  gap_offset = input("gap_offset_mm", 0.2f);
  adc_step = input("adc_step", 0.0024f);
  gap_ramp_up = input("gap_ramp_up", 5.0f);
  gap_ramp_dn = input("gap_ramp_dn", 5.0f);
  coil_i_max = input("coil_i_max", 6.0f);
  coil_i_min = input("coil_i_min", -6.0f);
  const_ = input("const", 0.0f);
  rateLimiter soft_start = rateLimiter();
  noise SIM__hall_noise = noise(-0.003, 0.003, uniform);
  node gap_error = node("[1.0 -1.0]", "[1.0]", Sum);
  leadLag phase_lead = leadLag(4.0, 8.0, 80.0);
  pid stabiliser = pid(20.0, 40.0, 2.0, 0.005);
  sat coil_headroom = sat();
  gain coil_force_constant = gain(20.0);
  tf SIM__maglev_gap = tf(SIM__maglev_gap_numerator, 1, SIM__maglev_gap_denominator, 3);
  node measured_gap = node("[1.0 1.0]", "[1.0]", Sum);
  quantizer _12_bit_converter = quantizer();
  coil_current = probe("coil_current_A");
  true_gap = probe("true_gap_mm");
  measured_gap_2 = probe("measured_gap_mm");

  /* Connect Blocks */
  gap_offset > soft_start.in(0);
  adc_step > _12_bit_converter.in(1);
  gap_ramp_up > soft_start.in(1);
  gap_ramp_dn > soft_start.in(2);
  coil_i_max > coil_headroom.in(0);
  coil_i_min > coil_headroom.in(1);
  const_ > SIM__hall_noise;
  soft_start > gap_error.in(0);
  SIM__hall_noise > measured_gap.in(1);
  gap_error > phase_lead;
  phase_lead > stabiliser;
  stabiliser > coil_headroom.in(2);
  coil_headroom > coil_force_constant;
  coil_headroom > coil_current;
  coil_force_constant > SIM__maglev_gap;
  SIM__maglev_gap > measured_gap.in(0);
  SIM__maglev_gap > true_gap;
  measured_gap > _12_bit_converter.in(0);
  _12_bit_converter > gap_error.in(1);
  _12_bit_converter > measured_gap_2;

  /* Enable Remote Input Control */
  gap_offset.enableRemote();
  adc_step.enableRemote();
  gap_ramp_up.enableRemote();
  gap_ramp_dn.enableRemote();
  coil_i_max.enableRemote();
  coil_i_min.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();

    /* Read probe values */
    coil_current.show();
    true_gap.show();
    measured_gap_2.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}