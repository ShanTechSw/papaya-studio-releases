var classmin_observer =
[
    [ "minObserver", "classmin_observer.html#a81c16aac7c69da9578be31601d0ce0a5", null ]
];