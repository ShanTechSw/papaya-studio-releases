var struct_p_p__encoder_cfg =
[
    [ "pos_conv", "struct_p_p__encoder_cfg.html#a5478bddb1356684573dc70953d920113", null ],
    [ "vel_conv", "struct_p_p__encoder_cfg.html#aa20d3467398abcf262bedfd351d80e8c", null ],
    [ "vel_tau", "struct_p_p__encoder_cfg.html#a349557d2b66ff3c5943904d8d5b92a7b", null ]
];