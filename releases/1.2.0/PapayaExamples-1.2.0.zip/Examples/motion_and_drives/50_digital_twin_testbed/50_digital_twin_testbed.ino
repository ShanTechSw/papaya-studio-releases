/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-09-01 22:55:48
 *  Fs (Hz)      : 2000.0
 *  C2D Algo     : Tustin
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe load_cell;
probe cpu_pct;
VectorProbe plant_params;
probe twin_mismatch;
probe health;
probe unused_signals;
probe crest_factor;

input ref;
input v_max;
input a_max;
input j_max;

/* Global Struct Declarations */
// Configuration for Motor_2
PP_motorBlockCfg Motor_2_config = {
  MOTOR2,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  2,
  {MotorVelocity, MotorCurrent, NoMotorOutput}
};

// Configuration for STR_PID
PP_STR_PID_Config STR_PID_config = {
  .lambda = 0.98f,
  .P_init = 100.0f,
  .Tau = 0.01f,
  .desired_cl_bw = 10.0f
};

// Configuration for Motor_1
PP_motorBlockCfg Motor_1_config = {
  MOTOR1,
  {20000.0f, -5000.0f, 5000.0f, 1.0f, 1.0f, 0.01f, -1.0f, 1.0f},
  2,
  {MotorVelocity, MotorCurrent, NoMotorOutput}
};

// Configuration for Disturbance_obs
static float Disturbance_obs_Gn_num[2] = {1.0f, 0.0f};
static float Disturbance_obs_Gn_den[2] = {1.0f, -0.9f};
static float Disturbance_obs_Qf_num[2] = {0.1f, 0.0f};
static float Disturbance_obs_Qf_den[2] = {1.0f, -0.9f};
PP_DOBConfig Disturbance_obs_config = {
  .Gn_num = Disturbance_obs_Gn_num,
  .Gn_den = Disturbance_obs_Gn_den,
  .Qf_num = Disturbance_obs_Qf_num,
  .Qf_den = Disturbance_obs_Qf_den,
  .plant_ord = 1,
  .qf_ord = 1
};

// Configuration for Online_ID_RRLS
// denom is {1, a1..a2}, num is {b0..b2}
float Online_ID_RRLS_num[3]   = {0.0f, 0.0f, 0.0f};
float Online_ID_RRLS_denom[3] = {1.0f, 0.0f, 0.0f};
PP_RRLSParam Online_ID_RRLS_config = {Online_ID_RRLS_num, 3, Online_ID_RRLS_denom, 3, 1.0f, 2, 0.99f, 1};

// Configuration for Digital_twin
static float Digital_twin_A_data[1] = {0.9512294245f};
static float Digital_twin_B_data[1] = {0.0487705755f};
static float Digital_twin_C_data[1] = {1.0f};
static float Digital_twin_D_data[1] = {0.0f};
static float Digital_twin_x_init[1] = {0.0f};
PP_stateSpace Digital_twin_config = {
  .n = 1,
  .m = 1,
  .p = 1,
  .A_data = Digital_twin_A_data,
  .B_data = Digital_twin_B_data,
  .C_data = Digital_twin_C_data,
  .D_data = Digital_twin_D_data,
  .x_init = Digital_twin_x_init
};


/* Global Array Declarations */
uint16_t Health_classifier_feat_idx[] = {0, 65535, 65535};
float Health_classifier_thresh[] = {0.5f, 0.0f, 0.0f};
uint16_t Health_classifier_left[] = {1, 65535, 65535};
uint16_t Health_classifier_right[] = {2, 65535, 65535};
float Health_classifier_leaf_val[] = {0.0f, 0.0f, 1.0f};

macro build_TwinController()
{
  macro retMacro;

  // Create Empty Macro
  retMacro = macro(1, 1);

  // Start Macro
  retMacro.start();

  // Create Blocks
  gain Twin_gain = gain(1.0);

  // Connect Blocks
  retMacro.in(0) > Twin_gain;
  Twin_gain > retMacro.out(0);

  // Stop Macro
  retMacro.stop();

  return retMacro;
}


void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(2000.0, Tustin);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  ref = input("ref", 100.0f);
  v_max = input("v_max", 50.0f);
  a_max = input("a_max", 200.0f);
  j_max = input("j_max", 2000.0f);
  signalSource Multisine = signalSource::multisine(100.0f, 50.0f, 10, MultisinePhase::Schroeder, 44257);
  signalSource start = signalSource::step(0.1f, 0.0f, 1.0f, /*mode=*/ WaveMode::Perpetual, /*n_periods=*/ 0);
  signalSource SIM__Aux_I_O_module = signalSource::sine(1.0f, 0.0f);
  signalSource SIM__Load_cell = signalSource::sine(0.5f, 0.0f);
  cpuLoad CPU_load = cpuLoad();
  trajScurve S_curve = trajScurve();
  expander fan_3 = expander(2);
  motor Motor_2 = motor(&Motor_2_config);
  macro Twin_controller = build_TwinController();
  strPID STR_PID = strPID(&STR_PID_config);
  node Drive_mixer = node("[1.0 -1.0 1.0]", "[1.0]", Sum);
  expander fan_drive = expander(4);
  motor Motor_1 = motor(&Motor_1_config);
  expander fan_6 = expander(5);
  dob Disturbance_obs = dob(&Disturbance_obs_config);
  expander fan_enc2 = expander(3);
  RRLS Online_ID_RRLS = RRLS(&Online_ID_RRLS_config);
  stateSpace Digital_twin = stateSpace(&Digital_twin_config);
  rootMeanSquare Vibration_RMS = rootMeanSquare(200);
  variance Vibration_variance = variance(200);
  mean Vibration_mean = mean(200);
  node Twin_mismatch = node("[1.0 -1.0]", "[1.0]", Sum);
  decisionTree Health_classifier = decisionTree(4, 2, 3, Health_classifier_feat_idx, Health_classifier_thresh, Health_classifier_left, Health_classifier_right, Health_classifier_leaf_val);
  merger unused_bus = merger(11);
  node remove_mean = node("[1.0 -1.0]", "[1.0]", Sum);
  crestFactor Crest_factor = crestFactor(256);
  inputShaper Input_shaper = inputShaper(1, 15.0, 0.05);
  analogOut Analog_out = analogOut(AO1, -9.0, 9.0);
  load_cell = probe("load_N");
  cpu_pct = probe("CPU_percent");
  plant_params = VectorProbe("plant_params");
  twin_mismatch = probe("twin_mismatch");
  health = probe("health");
  unused_signals = probe("unused_signals");
  crest_factor = probe("crest_factor");

  /* Connect Blocks */
  ref > S_curve.in(0);
  v_max > S_curve.in(1);
  a_max > S_curve.in(2);
  j_max > S_curve.in(3);
  Multisine > fan_3;
  start > S_curve.in(4);
  SIM__Aux_I_O_module > Input_shaper;
  SIM__Load_cell > load_cell;
  CPU_load > cpu_pct;
  S_curve.out(0) > Twin_controller;
  S_curve.out(1) > unused_bus.in(4);
  S_curve.out(2) > unused_bus.in(5);
  S_curve.out(3) > unused_bus.in(6);
  fan_3.out(1) > Motor_2;
  fan_3.out(0) > Drive_mixer.in(2);
  Motor_2.out(0) > fan_enc2;
  Motor_2.out(1) > unused_bus.in(1);
  Twin_controller > STR_PID.in(0);
  STR_PID.out(0) > Drive_mixer.in(0);
  STR_PID.out(1) > unused_bus.in(7);
  STR_PID.out(2) > unused_bus.in(8);
  STR_PID.out(3) > unused_bus.in(9);
  Drive_mixer > fan_drive;
  fan_drive.out(0) > Motor_1;
  fan_drive.out(1) > Disturbance_obs.in(0);
  fan_drive.out(3) > Online_ID_RRLS.in(1);
  fan_drive.out(2) > Digital_twin;
  Motor_1.out(0) > fan_6;
  Motor_1.out(1) > unused_bus.in(0);
  fan_6.out(1) > STR_PID.in(1);
  fan_6.out(2) > Disturbance_obs.in(1);
  fan_6.out(0) > Online_ID_RRLS.in(0);
  fan_6.out(4) > Vibration_RMS;
  fan_6.out(3) > Twin_mismatch.in(1);
  Disturbance_obs > Drive_mixer.in(1);
  fan_enc2.out(0) > Vibration_variance;
  fan_enc2.out(1) > Vibration_mean;
  fan_enc2.out(2) > remove_mean.in(0);
  Online_ID_RRLS.out(0) > unused_bus.in(2);
  Online_ID_RRLS.out(1) > unused_bus.in(3);
  Online_ID_RRLS.out(0) >> plant_params;
  Digital_twin > Twin_mismatch.in(0);
  Vibration_RMS > Health_classifier;
  Vibration_variance > unused_bus.in(10);
  Vibration_mean > remove_mean.in(1);
  Twin_mismatch > twin_mismatch;
  Health_classifier > health;
  unused_bus > unused_signals;
  remove_mean > Crest_factor;
  Crest_factor > crest_factor;
  Input_shaper > Analog_out;

  /* Enable Remote Input Control */
  ref.enableRemote();
  v_max.enableRemote();
  a_max.enableRemote();
  j_max.enableRemote();

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    load_cell.show();
    cpu_pct.show();
    plant_params.show();
    twin_mismatch.show();
    health.show();
    unused_signals.show();
    crest_factor.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}