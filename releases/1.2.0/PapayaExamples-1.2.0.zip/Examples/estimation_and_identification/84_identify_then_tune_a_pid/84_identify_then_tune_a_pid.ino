/*
 ******************************************************************************
 *
 *  This code is generated automatically by PAPAYA Studio Tool
 *  designed by Shanon Technologies SAS.
 *
 *  Copyright (c) Shanon Technologies SAS.
 *  All rights reserved.
 *
 *  Use of this generated file is subject to the terms of your
 *  PAPAYA Studio / PAPAYA VL license agreement.
 *
 *  Generated on : 2026-08-29 15:52:01
 *  Fs (Hz)      : 200.0
 *  C2D Algo     : Euler Backward
 *
 *  NOTE:
 *    - Modify the diagram in PAPAYA Studio and regenerate.
 *    - Generated numeric constants are emitted as single
 *      precision floats, which is what the board computes in.
 *
 ******************************************************************************
 */

#include "PAPAYA.h"


PAPAYA papaya0;

probe drive;
probe response;
probe fit_error;
probe model_output;
VectorProbe model;
probe Kd;
probe Ki;
probe Kp;
probe Tau;
VectorProbe gains;

/* Global Struct Declarations */
// Configuration for Identify_the_plant
// Order 2: num is {b0..b2}, denom is {1, a1..a2}, both 3 long
float Identify_the_plant_num[3]   = {0.0f, 0.0f, 0.0f};   // no prior model
float Identify_the_plant_denom[3] = {1.0f, 0.0f, 0.0f};   // monic, leading 1

// Covariance and system order
PP_RLSParam Identify_the_plant_config = {Identify_the_plant_num, 3, Identify_the_plant_denom, 3, 1000.0f, 2, 1};
// Replace num and denom with a starting model if you have one; the denominator's leading coefficient must not be zero.


/* Global Array Declarations */
float Unknown_plant_numerator[] = {7611.276f};
float Unknown_plant_denominator[] = {1.0f, 50.788437f, 7611.276f};

void setup()
{
  /* Initialize serial monitor for curves plotting */
  Serial.begin(115200);

  /* Create PAPAYA instance for board id 3 */
  papaya0 = PAPAYA(3);

  /* Set Sampling Frequency and Discretization Algorithm */
  papaya0.startDesign(200.0, EulerBackward);

  /* Set Monitoring Interface over SPI */
  papaya0.setMonitoringInterface(MonitoringOverSpi);

  /* Create Blocks */
  signalSource PRBS_drive = signalSource::prbs(8, 1, 44257);
  expander Split_the_drive = expander(3);
  tf Unknown_plant = tf(Unknown_plant_numerator, 1, Unknown_plant_denominator, 3);
  RLS Identify_the_plant = RLS(&Identify_the_plant_config);
  pidFromModel Model_to_gains = pidFromModel(Identify_the_plant, 0.05f, 0.0f, 0.0f, 0.0f, 0.0f);
  drive = probe("drive");
  response = probe("response");
  fit_error = probe("error");
  model_output = probe("y_hat");
  model = VectorProbe("model");
  Kd = probe("Kd");
  Ki = probe("Ki");
  Kp = probe("Kp");
  Tau = probe("Tau");
  gains = VectorProbe("gains");

  /* Connect Blocks */
  PRBS_drive > Split_the_drive;
  Split_the_drive.out(0) > Unknown_plant;
  Split_the_drive.out(1) > Identify_the_plant.in(1);
  Split_the_drive.out(2) > drive;
  Unknown_plant > Identify_the_plant.in(0);
  Unknown_plant > response;
  Identify_the_plant.out(0) > Model_to_gains;
  Identify_the_plant.out(1) > fit_error;
  Identify_the_plant.out(0) > model_output;
  Identify_the_plant.out(0) >> model;
  Model_to_gains.out(2) > Kd;
  Model_to_gains.out(1) > Ki;
  Model_to_gains.out(0) > Kp;
  Model_to_gains.out(3) > Tau;
  Model_to_gains.out(0) >> gains;

  /* Finalize Design and Check Integrity */
  papaya0.stopDesign();

  /* Report whether the design built on the board (0 = DesignOk) */
  Serial.print(F("[papaya] design status = "));
  Serial.println((int)papaya0.GetcurrentDesignStatus());
}

/* Probe reads per measurement session before the board is
 * released.  Larger = longer hold per cycle. */
#define PAPAYA_SESSION_PROBE_READS  240u

void loop()
{
  /* Re-arm the SPI monitoring interface and claim the board for a
   * fresh measurement session.  setMonitoringInterface() MUST be
   * repeated every session: stopSampling()'s SWITCH_BACK_TO_CFG
   * clears the monitoring interface when it releases the board, so
   * a second session started without this re-arm reads only NaN. */
  papaya0.setMonitoringInterface(MonitoringOverSpi);
  papaya0.startSampling();

  for (uint16_t _i = 0u; _i < PAPAYA_SESSION_PROBE_READS; _i++)
  {
    /* Update Probes to retrieve latest values */
    papaya0.getProbes();
    papaya0.getVectorProbes();

    /* Read probe values */
    drive.show();
    response.show();
    fit_error.show();
    model_output.show();
    model.show();
    Kd.show();
    Ki.show();
    Kp.show();
    Tau.show();
    gains.show();
  }

  /* Done with the probes, so stop sampling.  stopSampling() also
   * sends PP_CMD_SWITCH_BACK_TO_CFG, releasing the board so the
   * USB interface can claim it before the next session. */
  papaya0.stopSampling();
}