var struct_p_p___transaction_info =
[
    [ "CalculatedCrc", "struct_p_p___transaction_info.html#a13955ceb974c3611794e54462da1ca10", null ],
    [ "ReadWrite", "struct_p_p___transaction_info.html#a2519d293543c6166f2f1220f87f41386", null ],
    [ "ReceivedCrc", "struct_p_p___transaction_info.html#ae7a26323f297114752511f4cdd7326e7", null ],
    [ "SeqNbr", "struct_p_p___transaction_info.html#adea64bf252e38d817c9c98263cb647c5", null ]
];